import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, effect, inject, signal } from "@angular/core";
import { toObservable, toSignal } from "@angular/core/rxjs-interop";
import { AsyncContainerComponent, ClearSortButtonComponent, DataGridComponent, FilterBuilderComponent, FilterSelectComponent, GridExportComponent, GridToolbarComponent, NoticesPanelComponent, PageHeaderComponent, PagerComponent, RefreshButtonComponent, SAVED_FILTER_SCOPES, SAVED_FILTER_STORE, SearchShortcutDirective, activeRuleCount, compareBySorts, describeGroup, downloadBlob, isRuleNode, matchesGroup, matchesSearch, remoteLoading } from "@cws/shared-ui";
import { ActivatedRoute, Router } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { filter, firstValueFrom, scan, switchMap } from "rxjs";
import { CONTRACT_EXPORT_SOURCE, CONTRACT_GRID_COLUMNS, CONTRACT_LIST_SOURCE, DEFAULT_PAGE_SIZE, LOCATION_SOURCE, MAX_PAGE_SIZE, RECORD_ORIGIN_PARAM, contractRowTone, editRefusalFor, formatQuantity, fromRouteParams, hasScope, isServerSorted, toRouteParams, toSortParam, wholeDaysBetween } from "@cws/domain-contracts";
function basis(held, total, complete) {
	return held < total ? `Across ${formatQuantity(held)} of ${formatQuantity(total)} read` : complete;
}
function sumQuantity(rows, pick) {
	const quantified = rows.filter((row) => pick(row) !== null);
	const units = new Set(quantified.map((row) => row.quantityUom ?? "").filter((unit) => unit !== ""));
	if (units.size > 1) return {
		value: "—",
		mixed: true
	};
	const total = quantified.reduce((sum, row) => sum + (pick(row) ?? 0), 0);
	const unit = [...units][0] ?? "";
	return {
		value: `${formatQuantity(total)}${unit === "" ? "" : ` ${unit}`}`,
		mixed: false
	};
}
function contractPortfolioMetrics(rows, total, today) {
	const quantity = sumQuantity(rows, (row) => row.quantity);
	const open = sumQuantity(rows, (row) => row.openQuantity);
	const shippingSoon = rows.filter((row) => {
		const until = wholeDaysBetween(row.shipPeriodBegin, today);
		return until !== null && until >= -30;
	}).length;
	const attention = rows.filter((row) => contractRowTone(row) !== null).length;
	return [
		{
			label: "Open contracts",
			value: formatQuantity(total),
			hint: "In this trade unit"
		},
		{
			label: "Contract quantity",
			value: quantity.value,
			hint: quantity.mixed ? "Mixed units — no single total" : basis(rows.length, total, "Across every open contract")
		},
		{
			label: "Open quantity",
			value: open.value,
			hint: open.mixed ? "Mixed units — no single total" : basis(rows.length, total, "Still to apply against shipments")
		},
		{
			label: `Shipping within 30 days`,
			value: formatQuantity(shippingSoon),
			hint: basis(rows.length, total, "Ship period opens soon or has opened"),
			urgent: shippingSoon > 0
		},
		{
			label: "Needs attention",
			value: formatQuantity(attention),
			hint: basis(rows.length, total, "Rejected, unapproved or pending"),
			urgent: attention > 0
		}
	];
}
const PUSHDOWN_FIELDS = {
	commodity: "commodity",
	customerId: "customerId",
	traderInitials: "traderInitials",
	marketZone: "marketZone"
};
const SAVED_FILTER_SCOPE = SAVED_FILTER_SCOPES.contracts;
var HomePageComponent = class HomePageComponent {
	source = inject(CONTRACT_LIST_SOURCE);
	exportSource = inject(CONTRACT_EXPORT_SOURCE, { optional: true });
	locationSource = inject(LOCATION_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	rowActions = computed(() => {
		const actions = [];
		if (this.permissions.canWriteContracts()) actions.push({
			label: "Edit",
			tone: "outline",
			accessKey: "e",
			disabled: editRefusalFor,
			run: (row) => this.openEdit(row)
		}, {
			label: "Copy",
			tone: "secondary",
			accessKey: "c",
			run: (row) => this.openCopy(row)
		});
		if (this.permissions.canEditPricing()) actions.push({
			label: "Prices",
			tone: "secondary",
			accessKey: "p",
			run: (row) => this.openPricing(row)
		});
		if (this.permissions.canApproveContracts()) actions.push({
			label: "Approve",
			tone: "secondary",
			accessKey: "a",
			run: (row) => this.openApproval(row)
		});
		return actions;
	}, ...ngDevMode ? [{ debugName: "rowActions" }] : /* istanbul ignore next */ []);
	hostContext = inject(CMS_HOST_CONTEXT);
	router = inject(Router);
	route = inject(ActivatedRoute);
	columns = CONTRACT_GRID_COLUMNS;
	savedFilterScope = SAVED_FILTER_SCOPE;
	rowTone = contractRowTone;
	locationData = toSignal(this.locationSource.list(), { initialValue: remoteLoading() });
	locations = computed(() => {
		const data = this.locationData();
		return data.status === "loaded" ? data.value.locations : [];
	}, ...ngDevMode ? [{ debugName: "locations" }] : /* istanbul ignore next */ []);
	initialState = fromRouteParams(inject(ActivatedRoute).snapshot.queryParamMap);
	savedFilters = inject(SAVED_FILTER_STORE);
	initialView = this.resolveInitialView();
	resolveInitialView() {
		const fromUrl = {
			filter: this.initialState.filter,
			sorts: this.initialState.sorts
		};
		if (!(Object.keys(toRouteParams(this.initialState.query, fromUrl.sorts, null, fromUrl.filter)).length === 0)) return fromUrl;
		const defaultId = this.savedFilters.defaultId(SAVED_FILTER_SCOPE);
		if (defaultId === null) return fromUrl;
		const saved = this.savedFilters.list(SAVED_FILTER_SCOPE).find((candidate) => candidate.id === defaultId);
		return saved === void 0 ? fromUrl : {
			filter: saved.group,
			sorts: saved.sort ?? fromUrl.sorts
		};
	}
	filters = signal(this.initialState.query, ...ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []);
	focusKey = signal(this.initialState.focus, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	trackByContract = (row) => row.contractNumber;
	constructor() {
		effect(() => {
			this.router.navigate([], {
				relativeTo: this.route,
				queryParams: toRouteParams(this.filters(), this.sorts(), null, this.filter()),
				replaceUrl: true
			});
		});
	}
	sorts = signal(this.initialView.sorts, ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	filter = signal(this.initialView.filter, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	pushdown = computed(() => {
		const group = this.filter();
		if (group.combinator !== "and") return {};
		const pushed = {};
		for (const rule of group.rules) {
			if (!isRuleNode(rule)) continue;
			const field = PUSHDOWN_FIELDS[rule.columnKey];
			if (field !== void 0 && rule.operator === "equals" && rule.value.trim() !== "") pushed[field] = rule.value.trim();
		}
		return pushed;
	}, ...ngDevMode ? [{ debugName: "pushdown" }] : /* istanbul ignore next */ []);
	filtersLocally = computed(() => activeRuleCount(this.filter()) > 0 || (this.filters().search ?? "").trim() !== "", ...ngDevMode ? [{ debugName: "filtersLocally" }] : /* istanbul ignore next */ []);
	query = computed(() => ({
		...this.filters(),
		search: void 0,
		...this.pushdown(),
		tradeUnit: this.tradeUnit.code() ?? void 0,
		sort: toSortParam(this.sorts()),
		...this.filtersLocally() ? {
			page: 1,
			pageSize: MAX_PAGE_SIZE
		} : {}
	}), ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	needsScope = computed(() => !hasScope(this.query()), ...ngDevMode ? [{ debugName: "needsScope" }] : /* istanbul ignore next */ []);
	data = toSignal(toObservable(computed(() => ({
		query: this.query(),
		attempt: this.attempt()
	}))).pipe(scan((previous, next) => ({
		...next,
		refresh: next.attempt !== previous.attempt
	}), {
		query: this.query(),
		attempt: 0,
		refresh: false
	}), switchMap(({ query, refresh }) => hasScope(query) ? this.source.list(query, { refresh }) : [remoteLoading()])), { initialValue: remoteLoading() });
	state = computed(() => this.needsScope() ? {
		status: "loaded",
		value: emptyPage(this.query())
	} : this.data(), ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	page = computed(() => {
		const state = this.state();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	isRefreshing = computed(() => this.state().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	serverSorted = computed(() => isServerSorted(this.query().sort, this.page()?.appliedSort), ...ngDevMode ? [{ debugName: "serverSorted" }] : /* istanbul ignore next */ []);
	matched = computed(() => {
		const term = (this.filters().search ?? "").trim();
		const group = this.filter();
		const kept = (this.page()?.rows ?? []).filter((row) => matchesGroup(row, this.columns, group) && matchesSearch(row, this.columns, term));
		return this.sortRows(kept);
	}, ...ngDevMode ? [{ debugName: "matched" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		if (!this.filtersLocally()) return this.matched();
		const start = (this.localPage() - 1) * DEFAULT_PAGE_SIZE;
		return this.matched().slice(start, start + DEFAULT_PAGE_SIZE);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	localPageSignal = signal(1, ...ngDevMode ? [{ debugName: "localPageSignal" }] : /* istanbul ignore next */ []);
	localPage = computed(() => Math.min(Math.max(this.localPageSignal(), 1), this.localTotalPages()), ...ngDevMode ? [{ debugName: "localPage" }] : /* istanbul ignore next */ []);
	localTotalPages = computed(() => Math.max(1, Math.ceil(this.matched().length / DEFAULT_PAGE_SIZE)), ...ngDevMode ? [{ debugName: "localTotalPages" }] : /* istanbul ignore next */ []);
	fetchedCount = computed(() => this.page()?.rows.length ?? 0, ...ngDevMode ? [{ debugName: "fetchedCount" }] : /* istanbul ignore next */ []);
	filterIsPartial = computed(() => this.filtersLocally() && (this.page()?.totalCount ?? 0) > this.fetchedCount(), ...ngDevMode ? [{ debugName: "filterIsPartial" }] : /* istanbul ignore next */ []);
	sortRows(rows) {
		const sorts = this.sorts();
		if (sorts.length === 0) return rows;
		return [...rows].sort((left, right) => compareBySorts(this.columns, sorts, left, right));
	}
	isEmpty = computed(() => this.rows().length === 0, ...ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []);
	activeLocation = computed(() => {
		const code = this.query().tradeUnit;
		return this.locations().find((location) => location.code === code) ?? null;
	}, ...ngDevMode ? [{ debugName: "activeLocation" }] : /* istanbul ignore next */ []);
	scopeLabel = computed(() => {
		const location = this.activeLocation();
		return location ? `${location.code} — ${location.name ?? "Unnamed location"}` : "Contract list";
	}, ...ngDevMode ? [{ debugName: "scopeLabel" }] : /* istanbul ignore next */ []);
	scopeDescription = computed(() => {
		const location = this.activeLocation();
		return location ? [location.companyName, location.divisionName].filter(Boolean).join(" · ") : "Choose a trade unit to begin.";
	}, ...ngDevMode ? [{ debugName: "scopeDescription" }] : /* istanbul ignore next */ []);
	emptyMessage = computed(() => this.needsScope() ? "Choose a trade unit in the top bar to load contracts." : "No contracts match these filters.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => !this.needsScope() && this.page()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [...this.isSimulated() ? ["Simulated rows, not read from CTRM"] : [], ...this.customerNamesRedacted() ? ["Customer names are unavailable"] : []], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	customerNamesRedacted = computed(() => this.page()?.customerNames === "Redacted", ...ngDevMode ? [{ debugName: "customerNamesRedacted" }] : /* istanbul ignore next */ []);
	metrics = computed(() => contractPortfolioMetrics(this.matched(), this.filtersLocally() ? this.matched().length : this.page()?.totalCount ?? 0, /* @__PURE__ */ new Date()), ...ngDevMode ? [{ debugName: "metrics" }] : /* istanbul ignore next */ []);
	rangeLabel = computed(() => {
		if (this.filtersLocally()) {
			const total = this.matched().length;
			if (total === 0) return "";
			return `${(this.localPage() - 1) * DEFAULT_PAGE_SIZE + 1}–${Math.min(this.localPage() * DEFAULT_PAGE_SIZE, total)} of ${total}`;
		}
		const page = this.page();
		if (!page || page.totalCount === 0) return "";
		return `${(page.page - 1) * page.pageSize + 1}–${Math.min(page.page * page.pageSize, page.totalCount)} of ${page.totalCount}`;
	}, ...ngDevMode ? [{ debugName: "rangeLabel" }] : /* istanbul ignore next */ []);
	displayPage = computed(() => this.filtersLocally() ? this.localPage() : this.page()?.page ?? 1, ...ngDevMode ? [{ debugName: "displayPage" }] : /* istanbul ignore next */ []);
	displayTotalPages = computed(() => this.filtersLocally() ? this.localTotalPages() : this.page()?.totalPages ?? 1, ...ngDevMode ? [{ debugName: "displayTotalPages" }] : /* istanbul ignore next */ []);
	canPagePrevious = computed(() => (this.page()?.page ?? 1) > 1, ...ngDevMode ? [{ debugName: "canPagePrevious" }] : /* istanbul ignore next */ []);
	canPageNext = computed(() => {
		const page = this.page();
		return page ? page.page < page.totalPages : false;
	}, ...ngDevMode ? [{ debugName: "canPageNext" }] : /* istanbul ignore next */ []);
	activeFilterCount = computed(() => activeRuleCount(this.filter()), ...ngDevMode ? [{ debugName: "activeFilterCount" }] : /* istanbul ignore next */ []);
	filterSummary = computed(() => describeGroup(this.columns, this.filter()), ...ngDevMode ? [{ debugName: "filterSummary" }] : /* istanbul ignore next */ []);
	searchTerm = computed(() => this.filters().search ?? "", ...ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []);
	sortScopeNote = computed(() => {
		const page = this.page();
		if (this.sorts().length === 0 || !page || page.totalPages <= 1 || this.serverSorted()) return null;
		return `Sorted within this page (${page.pageSize} of ${page.totalCount}). Sorting the full result set needs the API's sort parameter.`;
	}, ...ngDevMode ? [{ debugName: "sortScopeNote" }] : /* istanbul ignore next */ []);
	onViewChange(view) {
		this.filter.set(view.group);
		this.sorts.set(view.sort);
		this.localPageSignal.set(1);
	}
	search(term) {
		this.patch({ search: term || void 0 });
	}
	setFilter(key, value) {
		this.patch({ [key]: value.trim() || void 0 });
	}
	clearFilters() {
		this.patch({
			customerId: void 0,
			commodity: void 0,
			traderInitials: void 0,
			marketZone: void 0
		});
	}
	goToPage(page) {
		if (this.filtersLocally()) {
			this.localPageSignal.set(Math.min(Math.max(page, 1), this.localTotalPages()));
			return;
		}
		const total = this.page()?.totalPages ?? 1;
		const target = Math.min(Math.max(page, 1), Math.max(total, 1));
		if (target !== (this.page()?.page ?? 1)) this.filters.update((query) => ({
			...query,
			page: target
		}));
	}
	stepPage(step) {
		if (this.filtersLocally()) {
			this.goToPage(this.localPage() + step);
			return;
		}
		const page = this.page();
		if (!page) return;
		const next = page.page + step;
		if (next >= 1 && next <= page.totalPages) this.filters.update((query) => ({
			...query,
			page: next
		}));
	}
	onFilterChange(group) {
		this.filter.set(group);
		this.localPageSignal.set(1);
	}
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportOutcome = signal(null, ...ngDevMode ? [{ debugName: "exportOutcome" }] : /* istanbul ignore next */ []);
	onExportFailed(message) {
		this.exportError.set(message);
		if (message !== null) this.exportOutcome.set(null);
	}
	onExportCompleted(outcome) {
		this.exportOutcome.set(outcome);
		this.exportError.set(null);
	}
	exportFilename = (scope) => {
		const query = this.query();
		const suffix = scope === "page" ? `page-${this.page()?.page ?? 1}` : "all";
		return `contracts-${query.tradeUnit ?? "all"}-${query.status.toLowerCase()}-${suffix}`;
	};
	exportAllRows = async () => {
		const first = this.page();
		if (!first) return null;
		const collected = [];
		const pages = Math.max(1, Math.ceil(first.totalCount / MAX_PAGE_SIZE));
		for (let page = 1; page <= pages; page += 1) {
			const state = await firstValueFrom(this.source.list({
				...this.query(),
				page,
				pageSize: MAX_PAGE_SIZE
			}).pipe(filter((value) => value.status !== "loading")));
			if (state.status !== "loaded") return null;
			collected.push(...state.value.rows);
		}
		const term = (this.filters().search ?? "").trim();
		const group = this.filter();
		const kept = collected.filter((row) => matchesGroup(row, this.columns, group) && matchesSearch(row, this.columns, term));
		return this.sortRows(kept);
	};
	serverExport = this.exportSource === null ? null : async (_scope, fields) => {
		if (this.filtersLocally()) return {
			ran: "skipped",
			reason: "A filter or search is applied on this screen, so the file was built here to match it."
		};
		const source = this.exportSource;
		if (source === null) return {
			ran: "skipped",
			reason: "No server export is configured."
		};
		const result = await firstValueFrom(source.export({
			query: this.query(),
			fields
		}));
		switch (result.kind) {
			case "csv":
				downloadBlob(result.filename ?? `${this.exportFilename("all")}.csv`, result.csv);
				return { ran: "server" };
			case "unavailable": return {
				ran: "skipped",
				reason: result.reason
			};
			case "refused": return {
				ran: "failed",
				message: result.message
			};
		}
	};
	onSortChange(sorts) {
		this.sorts.set(sorts);
		this.filters.update((query) => ({
			...query,
			page: 1
		}));
	}
	onRowActivate(row) {
		this.hostContext.navigate({
			kind: "contract",
			contractNumber: row.contractNumber,
			params: { returnTo: this.returnTo(row) }
		});
	}
	returnTo(row) {
		return new URLSearchParams(toRouteParams(this.filters(), this.sorts(), row.contractNumber, this.filter())).toString();
	}
	openEdit(row) {
		this.hostContext.navigate({
			kind: "contract",
			contractNumber: row.contractNumber,
			mode: "edit",
			params: { returnTo: this.returnTo(row) }
		});
	}
	openCopy(row) {
		this.hostContext.navigate({
			kind: "new-contract",
			params: { copyFrom: row.contractNumber }
		});
	}
	openPricing(row) {
		this.hostContext.navigate({
			kind: "review",
			origin: "pricing",
			contractNumber: row.contractNumber,
			params: {
				[RECORD_ORIGIN_PARAM]: "contracts",
				returnTo: this.returnTo(row)
			}
		});
	}
	openApproval(row) {
		this.hostContext.navigate({
			kind: "review",
			origin: "approvals",
			contractNumber: row.contractNumber,
			params: {
				[RECORD_ORIGIN_PARAM]: "contracts",
				returnTo: this.returnTo(row)
			}
		});
	}
	newContractIntent = {
		kind: "new-contract",
		params: {}
	};
	newContractHref = computed(() => this.hostContext.hrefFor(this.newContractIntent), ...ngDevMode ? [{ debugName: "newContractHref" }] : /* istanbul ignore next */ []);
	followNewContract(event) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(this.newContractIntent);
	}
	retry() {
		this.reissue();
	}
	refresh() {
		this.reissue();
	}
	reissue() {
		this.attempt.update((attempt) => attempt + 1);
	}
	patch(change) {
		this.filters.update((query) => ({
			...query,
			...change,
			page: 1
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HomePageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: HomePageComponent,
		isStandalone: true,
		selector: "cms-home-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <!--\r\n    The heading names the active scope rather than repeating \"Contracts\", so the page says which\r\n    trade unit is being shown. The h2-versus-h1 reasoning lives on the shared component now, along\r\n    with the `self-start` alignment of the actions — both were this screen's, and both were the\r\n    shape every other screen should have had.\r\n  -->\r\n  <cms-page-header [title]=\"scopeLabel()\" [description]=\"scopeDescription()\">\r\n    <ng-container cmsPageHeaderActions>\r\n      <!--\r\n        Creating a contract belongs to this screen rather than the shell's top bar: it acts on the\r\n        list you are looking at, where the shell's chrome is for moving between areas of the\r\n        application (docs/02a §6.1). Sitting beside the trade-unit control also puts it next to the\r\n        thing that scopes it.\r\n\r\n        An anchor rather than a button, so middle-click, Ctrl+click and \"copy link address\" work.\r\n\r\n        Its href and its click both come from the host contract (E9 PR 4, F9.10): this used to be a\r\n        routerLink to the shell's /contracts/new, which embedded drives the host's router at a path the\r\n        host may not publish (docs/02 §1a). A plain click asks the host; a modified click is left to the\r\n        browser, which opens the host's href.\r\n      -->\r\n      <!--\r\n        Sized to match Export data and the pager (JFrisbie, 2026-08-26), which are all\r\n        `scoular-btn scoular-btn-secondary`. Two deliberate details:\r\n\r\n        1. **`scoular-btn-sm` is dropped rather than overridden.** It is the only thing that made this\r\n           button smaller — `px-2.5 py-1 text-xs` against the base `px-4 py-2 text-sm`.\r\n           ✅ **Updated 2026-09-16:** the original reason was that the design system's CSS was\r\n           unlayered, so a Tailwind `h-[38px]` or `px-4` could not have beaten it at all.\r\n           `components.css` now sits in `@layer components` and a utility would win — but dropping the\r\n           class is still the right version, because matching a design-system control by wearing the\r\n           same classes it wears survives the design system changing its own padding, and an\r\n           overriding utility does not.\r\n        2. **`border border-transparent` is load-bearing, not decoration.** `scoular-btn-secondary`\r\n           carries `border border-slate-200`; `scoular-btn-primary` carries no border at all, so at\r\n           identical padding a primary button is **2px shorter** than the controls beside it. A\r\n           transparent border of the same width restores the box without touching the blue.\r\n\r\n        The colour is untouched: `scoular-btn-primary` is `bg-scoular-blue`, and the size variants\r\n        set only padding and font size, so nothing here changes the blue.\r\n      -->\r\n      <a\r\n        [attr.href]=\"newContractHref()\"\r\n        (click)=\"followNewContract($event)\"\r\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n      >\r\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\r\n        Add contract\r\n      </a>\r\n    </ng-container>\r\n  </cms-page-header>\r\n\r\n  <!--\r\n    Standing notices, in the shared collapsible panel — the same one the approval queue and both\r\n    pricing screens use (JFrisbie, 2026-09-14). It renders nothing at all when there is nothing to\r\n    say, which on this screen is the usual case.\r\n\r\n    ⚠ **The export failure below the filter is deliberately NOT in here.** This panel is for standing\r\n    conditions — environment, data origin, capability gaps — and never for the outcome of something\r\n    the user just did. A failed export belongs beside the control that produced it; behind a\r\n    collapsed panel it is a message nobody sees.\r\n  -->\r\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n    @if (isSimulated()) {\r\n      <!--\r\n        Not decoration. A demo that silently shows generated data is how generated data gets quoted\r\n        as a production readout — the API stamps every simulated response for exactly this reason.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Simulated data</div>\r\n        <div class=\"scoular-alert-description\">\r\n          These contracts are generated locally, not read from CTRM.\r\n        </div>\r\n      </div>\r\n    }\r\n    @if (customerNamesRedacted()) {\r\n      <!--\r\n        🔴 The customer directory is refusing us (#328). Without this the column falls back to ids,\r\n        which is exactly what it showed before the directory existed — so the regression and the\r\n        original gap are indistinguishable and nobody would see it go.\r\n\r\n        ⚠ The wording names no internal identifier, per the 2026-09-17 copy guard, and it says what\r\n        the user can rely on rather than what is broken: the ids are correct, so the screen is usable\r\n        and the contracts are right. It also says it will not clear on its own, because it will not —\r\n        this is a configuration entry that needs a person, unlike a transient lookup failure, which\r\n        deliberately raises nothing.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\r\n        <div class=\"scoular-alert-description\">\r\n          The customer directory is not answering for this application, so the Customer column falls\r\n          back to account numbers. The contracts and their numbers are unaffected. This will not\r\n          clear by retrying — please report it.\r\n        </div>\r\n      </div>\r\n    }\r\n  </cms-notices-panel>\r\n\r\n  <!--\r\n    🔴 **The portfolio cards** (JFrisbie, 2026-09-16) — what the book looks like before any\r\n    filtering, matching the approval queue's summary strip one click away.\r\n\r\n    `scoular-card` for the surface and the same type scale as the approvals cards, deliberately:\r\n    the two screens are a click apart, and a second card style would read as a second kind of\r\n    thing. The markup is duplicated rather than extracted into a shared component **for now** —\r\n    two consumers is where the standards say to centralise, and that is the next change rather\r\n    than this one, because extracting it while the metric shapes are still settling would freeze\r\n    an API across two features on one day's evidence.\r\n\r\n    ⚠ **Gated on a trade unit.** Without one the screen issues no request at all, so the cards\r\n    would render five zeroes — which reads as \"an empty book\" rather than \"nothing asked for\".\r\n    Same gate, same reason, as the approval queue's strip.\r\n\r\n    🔴 Colour is never the only carrier: the urgent cards are distinguished by their LABEL as much\r\n    as by the tint, because roughly 1 in 12 men has a colour vision deficiency (02a §4). \"Needs\r\n    attention\" says what it is with the colour removed.\r\n  -->\r\n  @if (!needsScope()) {\r\n    <dl class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:md:grid-cols-3 cws:xl:grid-cols-5\">\r\n      @for (metric of metrics(); track metric.label) {\r\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\r\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\r\n\r\n          <dd\r\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\r\n            [class]=\"\r\n              metric.urgent\r\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\r\n                : 'cws:text-slate-900 cws:dark:text-white'\r\n            \"\r\n          >\r\n            {{ metric.value }}\r\n          </dd>\r\n\r\n          <p class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</p>\r\n        </div>\r\n      }\r\n    </dl>\r\n  }\r\n\r\n  <!--\r\n    Filter bar (02a §6.1): a wide free-text search, then the status the request is scoped to.\r\n\r\n    🔴 The \"Filters\" dropdown that stood here is gone (JFrisbie, 2026-09-10, to a screenshot). The\r\n    filter now lives **inline below this bar** as chips plus an editor row, because a filter you can\r\n    only see by opening something is a filter people forget is applied — and an empty grid with a\r\n    hidden filter behind it is the single most confusing state this screen can be in.\r\n  -->\r\n  <cms-grid-toolbar>\r\n    <!--\r\n      `flex-1` with a floor and a ceiling: search is the control on this bar people use most, so it\r\n      takes the free space rather than sitting at input default width. The max stops it stretching to\r\n      an unreadable line length on a wide monitor.\r\n    -->\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-2xl\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <!--\r\n        🔴 `[value]` is bound to `searchTerm()`, NOT to `query().search`.\r\n\r\n        `query()` deliberately blanks `search` — the term is applied across every column here rather\r\n        than sent to a server that matches three — so binding the box to the query would render it\r\n        permanently empty: you could type, the grid would filter, and the text would vanish. Caught\r\n        by a test asserting the box reflects a term restored from the URL.\r\n      -->\r\n      <!--\r\n        ⚠ The placeholder named four fields and the search has never been limited to four:\r\n        `matchesSearch` tests **every column the grid renders** (`columns.some(...)`). The wording\r\n        was inherited from the server-side search it replaced, which does match three — so the box\r\n        had been under-claiming its own behaviour, which is the #196 class of defect with the sign\r\n        flipped.\r\n      -->\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"searchTerm()\"\r\n        (input)=\"search($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!--\r\n      `scoular-btn` without `-sm`, so the box model matches `scoular-form-input` exactly: both are\r\n      `px-4 py-2 text-sm` with a 1px border, which is what makes the three controls the same height\r\n      without a hard-coded pixel value that would drift when the design system changes its padding.\r\n    -->\r\n    <!--\r\n      The view selector, where the Status dropdown used to be (JFrisbie, 2026-09-10).\r\n\r\n      🔴 **Status is deliberately no longer selectable, and the consequence is real.** It selected\r\n      which CTRM *procedure* the request reached — `open`/`closed` are `OpenDS`, `unapproved` is a\r\n      different one returning `dsCon` — so removing the control does not narrow a filter, it fixes\r\n      the request to **open** contracts. Closed and unapproved are unreachable from this screen\r\n      until a control returns. Raised and accepted; `query().status` still carries the value, the URL\r\n      still round-trips it, and the request still sends it, so restoring the control is a template\r\n      change rather than a rebuild.\r\n\r\n      ⚠ Which is also why the baseline is called **\"All Open Contracts\"** rather than \"All\r\n      Contracts\": `contract/list` has no all-statuses option and refuses the call, so a bare \"All\"\r\n      would claim more than the grid can show — the defect #196 is open about.\r\n\r\n      Width lives here rather than on the control: `.scoular-form-input` is `@apply w-full` and the\r\n      design system compiles unlayered, so a `w-*` on the button itself would lose. Seventh instance.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <!--\r\n      \"+ Add filter\", beside the view selector rather than on a row of its own (JFrisbie,\r\n      2026-09-10, to a screenshot).\r\n\r\n      🔴 **The button is here and the editor it opens is still the builder's.** It calls\r\n      `builder.beginAdd()` through the template reference below, so the editor's open/closed state\r\n      keeps exactly one owner. Lifting that state up here would mean this button had to know that\r\n      committing a rule closes the editor and that clicking a chip re-opens it — two components\r\n      sharing one flag, which is how they end up disagreeing.\r\n\r\n      `items-end` on the row aligns it with the bottom of the two labelled controls beside it, so all\r\n      three sit on one baseline despite only two having captions.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline\"\r\n      (click)=\"builder.beginAdd()\"\r\n    >\r\n      + Add filter\r\n    </button>\r\n\r\n\r\n    <!--\r\n      Clear sort, beside Add filter and only while there is a sort to clear.\r\n\r\n      Shared with both work queues as `cms-clear-sort-button`. It carries the reasoning that used\r\n      to live here: rendered conditionally rather than shipped disabled, and a badge whose `h-5` is\r\n      what keeps the button the same height as its neighbours once a count appears.\r\n\r\n      No `defaultSorts` here, so clearing means no sort at all -- this grid arrives in the order the\r\n      server sent it. The queues pass their own arrival ordering instead.\r\n    -->\r\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"onSortChange($event)\" />\r\n\r\n    <!--\r\n      Export, on the same row as search and filters but pushed hard right by `ml-auto`.\r\n\r\n      Right-aligned rather than next to the filters because it acts on the *result* of everything to\r\n      its left — reading order is narrow, then narrow, then take what you have. `ml-auto` rather than\r\n      a spacer element so it still sits correctly when the bar wraps on a narrow viewport.\r\n    -->\r\n    <cms-grid-export\r\n      class=\"cws:ml-auto\"\r\n      [columns]=\"columns\"\r\n      [pageRows]=\"rows()\"\r\n      [totalCount]=\"page()?.totalCount ?? 0\"\r\n      [allRows]=\"exportAllRows\"\r\n      [filename]=\"exportFilename\"\r\n      [disabled]=\"isEmpty()\"\r\n      [serverExport]=\"serverExport\"\r\n      (failed)=\"onExportFailed($event)\"\r\n      (completed)=\"onExportCompleted($event)\"\r\n    />\r\n\r\n    <!--\r\n      Refresh, between Export and the pager (JFrisbie, 2026-09-03).\r\n\r\n      It re-issues the SAME query, so filters, sort and the current page all survive — see\r\n      `refresh()`. That is the whole point of it sitting here rather than being a link back to an\r\n      unfiltered workspace.\r\n\r\n      ⚠ **It is not guaranteed to re-read CTRM.** The BFF caches the contract list for 60s per\r\n      caller and scope (`Ctrm:ContractListCacheTtl`), and exposes no way for a client to ask it not\r\n      to — so inside that window this returns the same rows it already had. The button is still\r\n      honest about what it does (re-ask the server) and the cache is doing what it was built for;\r\n      it just means \"refresh\" is not a promise of freshness until the API offers a bypass. Raised for\r\n      the backend lane rather than worked around here, because a cache-busting parameter the server\r\n      ignores would be worse than no button.\r\n    -->\r\n    <cms-refresh-button\r\n      label=\"Refresh contracts\"\r\n      [busy]=\"isRefreshing()\"\r\n      [disabled]=\"needsScope()\"\r\n      (refresh)=\"refresh()\"\r\n    />\r\n\r\n    <!--\r\n      A second pager, so advancing a page does not mean scrolling to the bottom of 50 rows first.\r\n      Same component as the footer's, not a copy — two hand-written copies drift, and one gains a\r\n      disabled state or a label the other does not.\r\n    -->\r\n    <cms-pager\r\n      [page]=\"displayPage()\"\r\n      [totalPages]=\"displayTotalPages()\"\r\n      position=\"top\"\r\n      (goTo)=\"goToPage($event)\"\r\n    />\r\n  </cms-grid-toolbar>\r\n\r\n  <!--\r\n    The filter, inline and always visible — chips for what is applied, an editor row for building\r\n    the next rule.\r\n\r\n    🔴 Below the toolbar rather than inside a dropdown, which is the substance of the redesign. The\r\n    chips are the answer to \"why is this grid showing so little\", and that question is asked *while\r\n    looking at the grid* — so the answer has to be on the page rather than one click away.\r\n  -->\r\n  <!--\r\n    ⚠ `#builder` is read by the \"+ Add filter\" button on the toolbar above, and\r\n    `[showAddButton]=\"false\"` is what stops a second one rendering here. The two go together — drop\r\n    either and the screen has no way to open the editor, or two ways in two places.\r\n\r\n    The component renders **nothing at all** when there are no rules and the editor is closed, which\r\n    is why removing its own button leaves no empty band above the grid.\r\n  -->\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onFilterChange($event)\"\r\n  />\r\n\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    Which path wrote the last export (F4.3c). Beside the export failure and for the same reason:\r\n    it is the outcome of something the user just did, so it belongs by the control rather than in\r\n    the collapsible notices panel. Shown after every export, not only after a fallback — a note\r\n    that appeared only when something went sideways would leave the ordinary case unexplained.\r\n  -->\r\n  @if (exportOutcome(); as outcome) {\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\" aria-label=\"Export result\">\r\n      <div class=\"scoular-alert-description\">\r\n        @if (outcome.ran === 'server') {\r\n          Exported {{ outcome.rows }} rows by the server.\r\n        } @else if (outcome.reason) {\r\n          Exported {{ outcome.rows }} rows from this screen. {{ outcome.reason }}\r\n        } @else {\r\n          Exported {{ outcome.rows }} rows from this screen, as shown.\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <cms-async-container\r\n    [data]=\"state()\"\r\n    [empty]=\"isEmpty()\"\r\n    [emptyMessage]=\"emptyMessage()\"\r\n    loadingLabel=\"Loading contracts\"\r\n    (retry)=\"retry()\"\r\n  >\r\n    <!--\r\n      `trackBy` on the contract NUMBER rather than the row object is what makes `focusKey` able to match\r\n      at all: returning from the detail screen re-fetches, so the object for a given contract is a\r\n      different one than the row the user left, and object identity would never match.\r\n    -->\r\n    <!--\r\n      🔴 **Striped WITH tones, which the grid's own remarks warn against — measured before doing it**\r\n      (JFrisbie, 2026-09-15). This is the only grid that declares a `rowTone`, and the standing rule\r\n      was that a toned grid must not stripe, because a shaded row could then mean \"rejected\" or just\r\n      \"even\".\r\n\r\n      ✅ **The mechanism was never the risk.** `rowClassFor` emits the stripe only when the tone is\r\n      empty, so a tinted row keeps its tint — the two cannot fight, and a toned row is simply never\r\n      striped.\r\n\r\n      🔑 **What settled the ambiguity is that the cues separate by HUE, not by lightness.** Composited\r\n      over white and measured in Edge: the stripe lands on `rgb(250, 251, 253)` — cool, blue-leaning —\r\n      while `negative` is `rgb(254, 248, 246)` and `caution` is `rgb(255, 253, 242)`, both warm. The\r\n      tone-versus-stripe separations (9 and 12) are *larger* than the stripe-versus-plain one (7), so\r\n      a tinted row does not read as a striped one. Dark mode is more comfortable still: tones sit 25–28\r\n      from the stripe against its 11 from plain.\r\n\r\n      ⚠ **The residual, stated rather than smoothed over: in light mode every one of these washes is\r\n      faint**, so the distinction rests on hue. That is acceptable here only because the tint was never\r\n      the carrier — the 2026-09-03 tuning pass that softened these deliberately describes the tint as a\r\n      hint that \"competed with the status pill that says the same thing in words\". **The pill is the\r\n      answer for anyone who cannot separate the hues**, and it is in every toned row. 🔴 Do not\r\n      strengthen the tints to widen the gap: that pass softened them for a reason.\r\n\r\n      ⚠ **The zebra rhythm is irregular here and that is inherent**, not a defect — a tone displaces a\r\n      stripe, so with roughly a third of rows unapproved the alternation breaks wherever a tinted row\r\n      sits. Judged acceptable from a rendered 12-row sample at that ratio.\r\n    -->\r\n    <cms-data-grid\r\n      [rows]=\"rows()\"\r\n      [columns]=\"columns\"\r\n      label=\"Contracts\"\r\n      [striped]=\"true\"\r\n      [sorts]=\"sorts()\"\r\n      [rowTone]=\"rowTone\"\r\n      [actions]=\"rowActions()\"\r\n      [trackBy]=\"trackByContract\"\r\n      [focusKey]=\"focusKey()\"\r\n      (sortChange)=\"onSortChange($event)\"\r\n      (rowActivate)=\"onRowActivate($event)\"\r\n      (pageStep)=\"stepPage($event)\"\r\n    />\r\n\r\n    <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\r\n      <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <p>{{ rangeLabel() }}</p>\r\n        <!--\r\n          Every column is sortable now, but the server still has no sort parameter, so the sort is\r\n          applied to the current page only. On a multi-page result that is a materially different\r\n          thing from sorting the result set, and a trader looking for the highest price would\r\n          otherwise get the highest price on page 1 with no reason to doubt it.\r\n        -->\r\n        @if (sortScopeNote(); as note) {\r\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">{{ note }}</p>\r\n        }\r\n\r\n        <!--\r\n          🔴 What the filter was applied to. This is the honest half of client-side filtering and it\r\n          is not optional.\r\n\r\n          A rule can only match rows that arrived, so on a trade unit with more contracts than one\r\n          page holds, \"12 matches\" is a claim about what was read and not about the trade unit. A\r\n          filter builder that presented the first number as the second would be the\r\n          complete-looking-but-incomplete answer this project keeps recording — the same shape as\r\n          CR-4 (#31) on the CTRM side.\r\n\r\n          Shown only while filtering locally and only when the server held rows back, so an ordinary\r\n          filtered view of a small trade unit says nothing extra.\r\n        -->\r\n        @if (filterIsPartial()) {\r\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n            Matched against the {{ fetchedCount() }} contracts loaded, of\r\n            {{ page()?.totalCount ?? 0 }} in this trade unit — there may be more matches than are\r\n            listed.\r\n          </p>\r\n        }\r\n      </div>\r\n\r\n      <cms-pager\r\n        [page]=\"displayPage()\"\r\n        [totalPages]=\"displayTotalPages()\"\r\n        position=\"bottom\"\r\n        (goTo)=\"goToPage($event)\"\r\n      />\r\n    </footer>\r\n\r\n    <!--\r\n      The \"Opening SC1240000 — the contract view is F4.1b\" placeholder was here. It has been replaced\r\n      by real navigation to `/contracts/{number}` (2026-08-27), so there is nothing to stand in for.\r\n    -->\r\n    <!--\r\n      No primary action here any more: the trade-unit control lives in the shell top bar, and a\r\n      feature library reaching out to focus a shell control would be the wrong direction of\r\n      dependency. The message names where to go instead.\r\n    -->\r\n  </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep"
				]
			},
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HomePageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-home-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				FilterBuilderComponent,
				FilterSelectComponent,
				SearchShortcutDirective,
				GridExportComponent,
				GridToolbarComponent,
				NoticesPanelComponent,
				PagerComponent,
				RefreshButtonComponent,
				PageHeaderComponent
			],
			template: "<section class=\"cws:space-y-4\">\r\n  <!--\r\n    The heading names the active scope rather than repeating \"Contracts\", so the page says which\r\n    trade unit is being shown. The h2-versus-h1 reasoning lives on the shared component now, along\r\n    with the `self-start` alignment of the actions — both were this screen's, and both were the\r\n    shape every other screen should have had.\r\n  -->\r\n  <cms-page-header [title]=\"scopeLabel()\" [description]=\"scopeDescription()\">\r\n    <ng-container cmsPageHeaderActions>\r\n      <!--\r\n        Creating a contract belongs to this screen rather than the shell's top bar: it acts on the\r\n        list you are looking at, where the shell's chrome is for moving between areas of the\r\n        application (docs/02a §6.1). Sitting beside the trade-unit control also puts it next to the\r\n        thing that scopes it.\r\n\r\n        An anchor rather than a button, so middle-click, Ctrl+click and \"copy link address\" work.\r\n\r\n        Its href and its click both come from the host contract (E9 PR 4, F9.10): this used to be a\r\n        routerLink to the shell's /contracts/new, which embedded drives the host's router at a path the\r\n        host may not publish (docs/02 §1a). A plain click asks the host; a modified click is left to the\r\n        browser, which opens the host's href.\r\n      -->\r\n      <!--\r\n        Sized to match Export data and the pager (JFrisbie, 2026-08-26), which are all\r\n        `scoular-btn scoular-btn-secondary`. Two deliberate details:\r\n\r\n        1. **`scoular-btn-sm` is dropped rather than overridden.** It is the only thing that made this\r\n           button smaller — `px-2.5 py-1 text-xs` against the base `px-4 py-2 text-sm`.\r\n           ✅ **Updated 2026-09-16:** the original reason was that the design system's CSS was\r\n           unlayered, so a Tailwind `h-[38px]` or `px-4` could not have beaten it at all.\r\n           `components.css` now sits in `@layer components` and a utility would win — but dropping the\r\n           class is still the right version, because matching a design-system control by wearing the\r\n           same classes it wears survives the design system changing its own padding, and an\r\n           overriding utility does not.\r\n        2. **`border border-transparent` is load-bearing, not decoration.** `scoular-btn-secondary`\r\n           carries `border border-slate-200`; `scoular-btn-primary` carries no border at all, so at\r\n           identical padding a primary button is **2px shorter** than the controls beside it. A\r\n           transparent border of the same width restores the box without touching the blue.\r\n\r\n        The colour is untouched: `scoular-btn-primary` is `bg-scoular-blue`, and the size variants\r\n        set only padding and font size, so nothing here changes the blue.\r\n      -->\r\n      <a\r\n        [attr.href]=\"newContractHref()\"\r\n        (click)=\"followNewContract($event)\"\r\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n      >\r\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\r\n        Add contract\r\n      </a>\r\n    </ng-container>\r\n  </cms-page-header>\r\n\r\n  <!--\r\n    Standing notices, in the shared collapsible panel — the same one the approval queue and both\r\n    pricing screens use (JFrisbie, 2026-09-14). It renders nothing at all when there is nothing to\r\n    say, which on this screen is the usual case.\r\n\r\n    ⚠ **The export failure below the filter is deliberately NOT in here.** This panel is for standing\r\n    conditions — environment, data origin, capability gaps — and never for the outcome of something\r\n    the user just did. A failed export belongs beside the control that produced it; behind a\r\n    collapsed panel it is a message nobody sees.\r\n  -->\r\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n    @if (isSimulated()) {\r\n      <!--\r\n        Not decoration. A demo that silently shows generated data is how generated data gets quoted\r\n        as a production readout — the API stamps every simulated response for exactly this reason.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Simulated data</div>\r\n        <div class=\"scoular-alert-description\">\r\n          These contracts are generated locally, not read from CTRM.\r\n        </div>\r\n      </div>\r\n    }\r\n    @if (customerNamesRedacted()) {\r\n      <!--\r\n        🔴 The customer directory is refusing us (#328). Without this the column falls back to ids,\r\n        which is exactly what it showed before the directory existed — so the regression and the\r\n        original gap are indistinguishable and nobody would see it go.\r\n\r\n        ⚠ The wording names no internal identifier, per the 2026-09-17 copy guard, and it says what\r\n        the user can rely on rather than what is broken: the ids are correct, so the screen is usable\r\n        and the contracts are right. It also says it will not clear on its own, because it will not —\r\n        this is a configuration entry that needs a person, unlike a transient lookup failure, which\r\n        deliberately raises nothing.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\r\n        <div class=\"scoular-alert-description\">\r\n          The customer directory is not answering for this application, so the Customer column falls\r\n          back to account numbers. The contracts and their numbers are unaffected. This will not\r\n          clear by retrying — please report it.\r\n        </div>\r\n      </div>\r\n    }\r\n  </cms-notices-panel>\r\n\r\n  <!--\r\n    🔴 **The portfolio cards** (JFrisbie, 2026-09-16) — what the book looks like before any\r\n    filtering, matching the approval queue's summary strip one click away.\r\n\r\n    `scoular-card` for the surface and the same type scale as the approvals cards, deliberately:\r\n    the two screens are a click apart, and a second card style would read as a second kind of\r\n    thing. The markup is duplicated rather than extracted into a shared component **for now** —\r\n    two consumers is where the standards say to centralise, and that is the next change rather\r\n    than this one, because extracting it while the metric shapes are still settling would freeze\r\n    an API across two features on one day's evidence.\r\n\r\n    ⚠ **Gated on a trade unit.** Without one the screen issues no request at all, so the cards\r\n    would render five zeroes — which reads as \"an empty book\" rather than \"nothing asked for\".\r\n    Same gate, same reason, as the approval queue's strip.\r\n\r\n    🔴 Colour is never the only carrier: the urgent cards are distinguished by their LABEL as much\r\n    as by the tint, because roughly 1 in 12 men has a colour vision deficiency (02a §4). \"Needs\r\n    attention\" says what it is with the colour removed.\r\n  -->\r\n  @if (!needsScope()) {\r\n    <dl class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:md:grid-cols-3 cws:xl:grid-cols-5\">\r\n      @for (metric of metrics(); track metric.label) {\r\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\r\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\r\n\r\n          <dd\r\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\r\n            [class]=\"\r\n              metric.urgent\r\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\r\n                : 'cws:text-slate-900 cws:dark:text-white'\r\n            \"\r\n          >\r\n            {{ metric.value }}\r\n          </dd>\r\n\r\n          <p class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</p>\r\n        </div>\r\n      }\r\n    </dl>\r\n  }\r\n\r\n  <!--\r\n    Filter bar (02a §6.1): a wide free-text search, then the status the request is scoped to.\r\n\r\n    🔴 The \"Filters\" dropdown that stood here is gone (JFrisbie, 2026-09-10, to a screenshot). The\r\n    filter now lives **inline below this bar** as chips plus an editor row, because a filter you can\r\n    only see by opening something is a filter people forget is applied — and an empty grid with a\r\n    hidden filter behind it is the single most confusing state this screen can be in.\r\n  -->\r\n  <cms-grid-toolbar>\r\n    <!--\r\n      `flex-1` with a floor and a ceiling: search is the control on this bar people use most, so it\r\n      takes the free space rather than sitting at input default width. The max stops it stretching to\r\n      an unreadable line length on a wide monitor.\r\n    -->\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-2xl\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <!--\r\n        🔴 `[value]` is bound to `searchTerm()`, NOT to `query().search`.\r\n\r\n        `query()` deliberately blanks `search` — the term is applied across every column here rather\r\n        than sent to a server that matches three — so binding the box to the query would render it\r\n        permanently empty: you could type, the grid would filter, and the text would vanish. Caught\r\n        by a test asserting the box reflects a term restored from the URL.\r\n      -->\r\n      <!--\r\n        ⚠ The placeholder named four fields and the search has never been limited to four:\r\n        `matchesSearch` tests **every column the grid renders** (`columns.some(...)`). The wording\r\n        was inherited from the server-side search it replaced, which does match three — so the box\r\n        had been under-claiming its own behaviour, which is the #196 class of defect with the sign\r\n        flipped.\r\n      -->\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"searchTerm()\"\r\n        (input)=\"search($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!--\r\n      `scoular-btn` without `-sm`, so the box model matches `scoular-form-input` exactly: both are\r\n      `px-4 py-2 text-sm` with a 1px border, which is what makes the three controls the same height\r\n      without a hard-coded pixel value that would drift when the design system changes its padding.\r\n    -->\r\n    <!--\r\n      The view selector, where the Status dropdown used to be (JFrisbie, 2026-09-10).\r\n\r\n      🔴 **Status is deliberately no longer selectable, and the consequence is real.** It selected\r\n      which CTRM *procedure* the request reached — `open`/`closed` are `OpenDS`, `unapproved` is a\r\n      different one returning `dsCon` — so removing the control does not narrow a filter, it fixes\r\n      the request to **open** contracts. Closed and unapproved are unreachable from this screen\r\n      until a control returns. Raised and accepted; `query().status` still carries the value, the URL\r\n      still round-trips it, and the request still sends it, so restoring the control is a template\r\n      change rather than a rebuild.\r\n\r\n      ⚠ Which is also why the baseline is called **\"All Open Contracts\"** rather than \"All\r\n      Contracts\": `contract/list` has no all-statuses option and refuses the call, so a bare \"All\"\r\n      would claim more than the grid can show — the defect #196 is open about.\r\n\r\n      Width lives here rather than on the control: `.scoular-form-input` is `@apply w-full` and the\r\n      design system compiles unlayered, so a `w-*` on the button itself would lose. Seventh instance.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <!--\r\n      \"+ Add filter\", beside the view selector rather than on a row of its own (JFrisbie,\r\n      2026-09-10, to a screenshot).\r\n\r\n      🔴 **The button is here and the editor it opens is still the builder's.** It calls\r\n      `builder.beginAdd()` through the template reference below, so the editor's open/closed state\r\n      keeps exactly one owner. Lifting that state up here would mean this button had to know that\r\n      committing a rule closes the editor and that clicking a chip re-opens it — two components\r\n      sharing one flag, which is how they end up disagreeing.\r\n\r\n      `items-end` on the row aligns it with the bottom of the two labelled controls beside it, so all\r\n      three sit on one baseline despite only two having captions.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline\"\r\n      (click)=\"builder.beginAdd()\"\r\n    >\r\n      + Add filter\r\n    </button>\r\n\r\n\r\n    <!--\r\n      Clear sort, beside Add filter and only while there is a sort to clear.\r\n\r\n      Shared with both work queues as `cms-clear-sort-button`. It carries the reasoning that used\r\n      to live here: rendered conditionally rather than shipped disabled, and a badge whose `h-5` is\r\n      what keeps the button the same height as its neighbours once a count appears.\r\n\r\n      No `defaultSorts` here, so clearing means no sort at all -- this grid arrives in the order the\r\n      server sent it. The queues pass their own arrival ordering instead.\r\n    -->\r\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"onSortChange($event)\" />\r\n\r\n    <!--\r\n      Export, on the same row as search and filters but pushed hard right by `ml-auto`.\r\n\r\n      Right-aligned rather than next to the filters because it acts on the *result* of everything to\r\n      its left — reading order is narrow, then narrow, then take what you have. `ml-auto` rather than\r\n      a spacer element so it still sits correctly when the bar wraps on a narrow viewport.\r\n    -->\r\n    <cms-grid-export\r\n      class=\"cws:ml-auto\"\r\n      [columns]=\"columns\"\r\n      [pageRows]=\"rows()\"\r\n      [totalCount]=\"page()?.totalCount ?? 0\"\r\n      [allRows]=\"exportAllRows\"\r\n      [filename]=\"exportFilename\"\r\n      [disabled]=\"isEmpty()\"\r\n      [serverExport]=\"serverExport\"\r\n      (failed)=\"onExportFailed($event)\"\r\n      (completed)=\"onExportCompleted($event)\"\r\n    />\r\n\r\n    <!--\r\n      Refresh, between Export and the pager (JFrisbie, 2026-09-03).\r\n\r\n      It re-issues the SAME query, so filters, sort and the current page all survive — see\r\n      `refresh()`. That is the whole point of it sitting here rather than being a link back to an\r\n      unfiltered workspace.\r\n\r\n      ⚠ **It is not guaranteed to re-read CTRM.** The BFF caches the contract list for 60s per\r\n      caller and scope (`Ctrm:ContractListCacheTtl`), and exposes no way for a client to ask it not\r\n      to — so inside that window this returns the same rows it already had. The button is still\r\n      honest about what it does (re-ask the server) and the cache is doing what it was built for;\r\n      it just means \"refresh\" is not a promise of freshness until the API offers a bypass. Raised for\r\n      the backend lane rather than worked around here, because a cache-busting parameter the server\r\n      ignores would be worse than no button.\r\n    -->\r\n    <cms-refresh-button\r\n      label=\"Refresh contracts\"\r\n      [busy]=\"isRefreshing()\"\r\n      [disabled]=\"needsScope()\"\r\n      (refresh)=\"refresh()\"\r\n    />\r\n\r\n    <!--\r\n      A second pager, so advancing a page does not mean scrolling to the bottom of 50 rows first.\r\n      Same component as the footer's, not a copy — two hand-written copies drift, and one gains a\r\n      disabled state or a label the other does not.\r\n    -->\r\n    <cms-pager\r\n      [page]=\"displayPage()\"\r\n      [totalPages]=\"displayTotalPages()\"\r\n      position=\"top\"\r\n      (goTo)=\"goToPage($event)\"\r\n    />\r\n  </cms-grid-toolbar>\r\n\r\n  <!--\r\n    The filter, inline and always visible — chips for what is applied, an editor row for building\r\n    the next rule.\r\n\r\n    🔴 Below the toolbar rather than inside a dropdown, which is the substance of the redesign. The\r\n    chips are the answer to \"why is this grid showing so little\", and that question is asked *while\r\n    looking at the grid* — so the answer has to be on the page rather than one click away.\r\n  -->\r\n  <!--\r\n    ⚠ `#builder` is read by the \"+ Add filter\" button on the toolbar above, and\r\n    `[showAddButton]=\"false\"` is what stops a second one rendering here. The two go together — drop\r\n    either and the screen has no way to open the editor, or two ways in two places.\r\n\r\n    The component renders **nothing at all** when there are no rules and the editor is closed, which\r\n    is why removing its own button leaves no empty band above the grid.\r\n  -->\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onFilterChange($event)\"\r\n  />\r\n\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    Which path wrote the last export (F4.3c). Beside the export failure and for the same reason:\r\n    it is the outcome of something the user just did, so it belongs by the control rather than in\r\n    the collapsible notices panel. Shown after every export, not only after a fallback — a note\r\n    that appeared only when something went sideways would leave the ordinary case unexplained.\r\n  -->\r\n  @if (exportOutcome(); as outcome) {\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\" aria-label=\"Export result\">\r\n      <div class=\"scoular-alert-description\">\r\n        @if (outcome.ran === 'server') {\r\n          Exported {{ outcome.rows }} rows by the server.\r\n        } @else if (outcome.reason) {\r\n          Exported {{ outcome.rows }} rows from this screen. {{ outcome.reason }}\r\n        } @else {\r\n          Exported {{ outcome.rows }} rows from this screen, as shown.\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <cms-async-container\r\n    [data]=\"state()\"\r\n    [empty]=\"isEmpty()\"\r\n    [emptyMessage]=\"emptyMessage()\"\r\n    loadingLabel=\"Loading contracts\"\r\n    (retry)=\"retry()\"\r\n  >\r\n    <!--\r\n      `trackBy` on the contract NUMBER rather than the row object is what makes `focusKey` able to match\r\n      at all: returning from the detail screen re-fetches, so the object for a given contract is a\r\n      different one than the row the user left, and object identity would never match.\r\n    -->\r\n    <!--\r\n      🔴 **Striped WITH tones, which the grid's own remarks warn against — measured before doing it**\r\n      (JFrisbie, 2026-09-15). This is the only grid that declares a `rowTone`, and the standing rule\r\n      was that a toned grid must not stripe, because a shaded row could then mean \"rejected\" or just\r\n      \"even\".\r\n\r\n      ✅ **The mechanism was never the risk.** `rowClassFor` emits the stripe only when the tone is\r\n      empty, so a tinted row keeps its tint — the two cannot fight, and a toned row is simply never\r\n      striped.\r\n\r\n      🔑 **What settled the ambiguity is that the cues separate by HUE, not by lightness.** Composited\r\n      over white and measured in Edge: the stripe lands on `rgb(250, 251, 253)` — cool, blue-leaning —\r\n      while `negative` is `rgb(254, 248, 246)` and `caution` is `rgb(255, 253, 242)`, both warm. The\r\n      tone-versus-stripe separations (9 and 12) are *larger* than the stripe-versus-plain one (7), so\r\n      a tinted row does not read as a striped one. Dark mode is more comfortable still: tones sit 25–28\r\n      from the stripe against its 11 from plain.\r\n\r\n      ⚠ **The residual, stated rather than smoothed over: in light mode every one of these washes is\r\n      faint**, so the distinction rests on hue. That is acceptable here only because the tint was never\r\n      the carrier — the 2026-09-03 tuning pass that softened these deliberately describes the tint as a\r\n      hint that \"competed with the status pill that says the same thing in words\". **The pill is the\r\n      answer for anyone who cannot separate the hues**, and it is in every toned row. 🔴 Do not\r\n      strengthen the tints to widen the gap: that pass softened them for a reason.\r\n\r\n      ⚠ **The zebra rhythm is irregular here and that is inherent**, not a defect — a tone displaces a\r\n      stripe, so with roughly a third of rows unapproved the alternation breaks wherever a tinted row\r\n      sits. Judged acceptable from a rendered 12-row sample at that ratio.\r\n    -->\r\n    <cms-data-grid\r\n      [rows]=\"rows()\"\r\n      [columns]=\"columns\"\r\n      label=\"Contracts\"\r\n      [striped]=\"true\"\r\n      [sorts]=\"sorts()\"\r\n      [rowTone]=\"rowTone\"\r\n      [actions]=\"rowActions()\"\r\n      [trackBy]=\"trackByContract\"\r\n      [focusKey]=\"focusKey()\"\r\n      (sortChange)=\"onSortChange($event)\"\r\n      (rowActivate)=\"onRowActivate($event)\"\r\n      (pageStep)=\"stepPage($event)\"\r\n    />\r\n\r\n    <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\r\n      <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <p>{{ rangeLabel() }}</p>\r\n        <!--\r\n          Every column is sortable now, but the server still has no sort parameter, so the sort is\r\n          applied to the current page only. On a multi-page result that is a materially different\r\n          thing from sorting the result set, and a trader looking for the highest price would\r\n          otherwise get the highest price on page 1 with no reason to doubt it.\r\n        -->\r\n        @if (sortScopeNote(); as note) {\r\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">{{ note }}</p>\r\n        }\r\n\r\n        <!--\r\n          🔴 What the filter was applied to. This is the honest half of client-side filtering and it\r\n          is not optional.\r\n\r\n          A rule can only match rows that arrived, so on a trade unit with more contracts than one\r\n          page holds, \"12 matches\" is a claim about what was read and not about the trade unit. A\r\n          filter builder that presented the first number as the second would be the\r\n          complete-looking-but-incomplete answer this project keeps recording — the same shape as\r\n          CR-4 (#31) on the CTRM side.\r\n\r\n          Shown only while filtering locally and only when the server held rows back, so an ordinary\r\n          filtered view of a small trade unit says nothing extra.\r\n        -->\r\n        @if (filterIsPartial()) {\r\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n            Matched against the {{ fetchedCount() }} contracts loaded, of\r\n            {{ page()?.totalCount ?? 0 }} in this trade unit — there may be more matches than are\r\n            listed.\r\n          </p>\r\n        }\r\n      </div>\r\n\r\n      <cms-pager\r\n        [page]=\"displayPage()\"\r\n        [totalPages]=\"displayTotalPages()\"\r\n        position=\"bottom\"\r\n        (goTo)=\"goToPage($event)\"\r\n      />\r\n    </footer>\r\n\r\n    <!--\r\n      The \"Opening SC1240000 — the contract view is F4.1b\" placeholder was here. It has been replaced\r\n      by real navigation to `/contracts/{number}` (2026-08-27), so there is nothing to stand in for.\r\n    -->\r\n    <!--\r\n      No primary action here any more: the trade-unit control lives in the shell top bar, and a\r\n      feature library reaching out to focus a shell control would be the wrong direction of\r\n      dependency. The message names where to go instead.\r\n    -->\r\n  </cms-async-container>\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => []
});
function emptyPage(query) {
	return {
		rows: [],
		totalCount: 0,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: 1,
		dataOrigin: "Simulated",
		filteredInProcess: false,
		warnings: []
	};
}
export { HomePageComponent };

//# sourceMappingURL=cws-features-home.mjs.map
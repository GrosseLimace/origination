import { ContractListPage, ContractListQuery, ContractPrices, ContractSummary, PriceSequence, UnapprovedPrices, UnpricedOpenOutcome } from "@cws/domain-contracts";
import { AppliedView, BreadcrumbCrumb, ConfirmsNavigation, FilterGroup, GridColumn, GridRowAction, GridSort, MutationOutcome, RemoteData } from "@cws/shared-ui";
import * as i0 from "@angular/core";
import { CmsNavigationIntent } from "@cws/core-host-context";
import { Observable } from "rxjs";
export declare class PricingPageComponent {
  private readonly source;
  /**
   * #888: the save that a Save-and-close from a record opened from this queue left here. Taken once,
   * as the screen is built, so a reload or a later visit does not say it again.
   */
  protected readonly arrivedAfterSave: import("@angular/core").WritableSignal<MutationOutcome | null>;
  private readonly tradeUnit;
  private readonly permissions;
  /**
   * Opening a contract's prices and the Pricing approvals link go through the host (E9 PR 4, F9.10),
   * so neither leaves a host's prefix.
   */
  private readonly hostContext;
  private readonly route;
  /** The Pricing approvals link: a sibling module, by logical name. */
  private readonly approvalsIntent;
  protected readonly approvalsHref: import("@angular/core").Signal<string>;
  /** A plain left click is handed to the host; a modified or middle click is left to the browser. */
  protected followApprovals(event: MouseEvent): void;
  protected readonly columns: readonly import("@cws/shared-ui").GridColumn<ContractSummary>[];
  /** The Columns menu's choice, in the toolbar beside Export as on Home (JFrisbie, 2026-10-23). */
  protected readonly columnChoice: import("@cws/shared-ui").GridColumnChoice<ContractSummary>;
  /**
   * Largest unpriced quantity first — the most work outstanding at the top.
   *
   * A different default from both other grids, and deliberately so: the workspace is newest-first
   * because it is a register, the approval queue is oldest-first because it is a work queue measured
   * in waiting time, and this one is a work queue measured in *volume*. Contract date is a column
   * here and is not the ordering.
   */
  /**
   * The state this screen was reached with, from the URL — see the approvals queue's own remarks.
   * The breadcrumb hands this back so a return lands on the same row, page and ordering.
   */
  private readonly initial;
  protected readonly sorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  /** Exposed for the Clear sort button, which hides itself while the sort still matches it. */
  protected readonly defaultSorts: readonly GridSort<string>[];
  /**
   * One free-text term, matched across **every column the grid renders**.
   *
   * 🔴 **This replaced four per-field boxes** — Customer, Commodity, Trader and Price type
   * (JFrisbie, 2026-09-10). Two reasons it is not a loss of capability:
   *
   *   1. `matchesSearch` tests every column, so anything the four boxes could narrow on is still
   *      reachable, plus the seven columns they could not.
   *   2. Three of the four were sent as request parameters, and `ContractListProjector` filters
   *      **in process** — it fetches the whole status set either way. So pushing them down shrank
   *      the JSON and never the work CTRM does, which is why moving the narrowing client-side costs
   *      nothing here.
   *
   * ⚠ What it does drop is *field-scoped* matching: "ACME" in the box now matches a customer named
   * ACME **and** a contract whose remark mentions it. On a queue this size that reads as helpful
   * rather than noisy, and the filter builder is the precise tool when it is not.
   */
  protected readonly searchTerm: import("@angular/core").WritableSignal<string>;
  /** The row to re-focus on return. */
  protected readonly focusKey: import("@angular/core").WritableSignal<string | null>;
  private readonly attempt;
  protected readonly query: import("@angular/core").Signal<ContractListQuery>;
  /**
   * Every page of open contracts, as one (#1118), read the way the workspace and the approval queue
   * read theirs. A page that fails stops the read and keeps what arrived, which {@link rowCapMessage}
   * then reports as a short read rather than a complete queue.
   */
  private readonly data;
  /**
   * What the async container renders.
   *
   * 🔴 While the precondition is unmet the state is forced to `loaded` with an empty result, so the
   * container shows the empty state rather than a spinner that will never resolve. An indefinite
   * skeleton is how "you must choose something" gets mistaken for a hang -- and the screen issues no
   * request without a scope, so the read never completes to clear it.
   *
   * The workspace has done this since it was built; these screens rendered their own card instead,
   * which is what this replaces.
   */
  protected readonly containerState: import("@angular/core").Signal<RemoteData<ContractListPage>>;
  protected readonly result: import("@angular/core").Signal<ContractListPage | null>;
  /** Every open contract the server sent, before the unpriced filter. */
  protected readonly fetched: import("@angular/core").Signal<readonly ContractSummary[]>;
  /**
   * The queue — open contracts with unpriced quantity remaining, then the price-type narrowing.
   *
   * Price type is matched here rather than sent, because it is not a parameter the API takes and
   * because `needsPricing` explains why it is not the primary filter: nothing in this repository
   * establishes that §5.1's `U` is a value live contracts carry.
   */
  protected readonly queue: import("@angular/core").Signal<ContractSummary[]>;
  /**
   * Which page of the queue to show.
   *
   * 🔴 **Paged client-side, over the FILTERED set — not by asking the server for a page.** The
   * unpriced filter has no server-side equivalent, so a server page of 50 open contracts yields a
   * variable and usually small number of unpriced ones; paging that way would give pages of 3, 0, 11
   * rows and a page count that meant nothing. Paging the filtered queue means a page is a page *of
   * the queue*, and the record count below the grid counts the thing the screen is about.
   *
   * ⚠ It is still bounded by what the server sent — see {@link moreThanOnePage}, which is why that
   * caveat stays on screen.
   */
  protected readonly page: import("@angular/core").WritableSignal<number>;
  protected readonly pageSize = 50;
  protected readonly totalPages: import("@angular/core").Signal<number>;
  protected readonly rows: import("@angular/core").Signal<ContractSummary[]>;
  /**
   * The page, clamped to what exists.
   *
   * Narrowing a filter can leave the requested page past the end of the queue, and an out-of-range
   * page renders an empty grid that reads as "no matches" when there are matches on page 1.
   */
  protected readonly currentPage: import("@angular/core").Signal<number>;
  /** `1–50 of 87`, over the queue — matching the workspace grid's footer wording exactly. */
  protected readonly rangeLabel: import("@angular/core").Signal<string>;
  protected onPage(page: number): void;
  protected onPageStep(step: -1 | 1): void;
  protected readonly isRefreshing: import("@angular/core").Signal<boolean>;
  protected readonly isSimulated: import("@angular/core").Signal<boolean>;
  protected readonly warnings: import("@angular/core").Signal<readonly string[]>;
  /**
   * One line per standing notice, and — because the panel counts these — the number it reports.
   *
   * 🔴 **This list and the panel's projected content must stay in step.** The count comes from here
   * while the detail is projected markup, so a notice added to the template and not to this list is
   * one the header does not count and a collapsed reader never learns about.
   *
   * ⚠ Order matches the template, and the conditional entries are conditional in both places.
   */
  protected readonly noticeSummaries: import("@angular/core").Signal<string[]>;
  /** #1223: the environment and system caveats are the Entra Admin role's only. */
  protected readonly showSystemNotices: import("@angular/core").Signal<boolean>;
  /**
   * The sentence when the queue may not hold every open contract, else `null`.
   *
   * First the server's own verdict, shared with the workspace (`listCompletenessNotice`: #662's row
   * cap, #1087's counts, #1116's `listComplete`). Then a short read (#1118): the every-page read
   * stopped on a failed page, so fewer rows arrived than the server counted. Only an explicit claim
   * shows anything; `null` is a server that does not say, and claims nothing.
   */
  protected readonly rowCapMessage: import("@angular/core").Signal<string | null>;
  /** Fewer open contracts arrived than the server counted (#1118): a page of the read failed. */
  protected readonly shortRead: import("@angular/core").Signal<boolean>;
  protected readonly hasTradeUnit: import("@angular/core").Signal<boolean>;
  /**
   * Set when an export could not complete, so the failure is on screen rather than silent.
   *
   * ⚠ Rendered beside the grid, **not** in the notices panel: that panel holds standing conditions
   * of the screen, and this is the outcome of something the user just did.
   */
  protected readonly exportError: import("@angular/core").WritableSignal<string | null>;
  /**
   * Names an export file — `unpriced-0210-page-1.csv`.
   *
   * ⚠ An arrow property rather than a method, because it is passed to `cms-grid-export` as an input:
   * a plain method would arrive unbound and throw on the first export.
   */
  protected readonly exportFilename: (scope: "page" | "all") => string;
  /**
   * Every row the current search and filter match.
   *
   * ✅ No request: this screen asks for one large page and narrows in the browser, so the whole
   * matched set is already held. The workspace's resolver walks the server instead — same control,
   * different cost, which is why `cms-grid-export` takes a resolver rather than an array.
   */
  protected readonly exportAllRows: () => Promise<readonly ContractSummary[] | null>;
  /**
   * What the container says when it has nothing to show.
   *
   * 🔴 Two different absences, and they must not read alike: no trade unit means *nothing was
   * asked for*, while no rows means *the answer was empty*. A single message for both would tell a
   * user every contract is priced when the screen has not issued a request.
   */
  protected readonly emptyMessage: import("@angular/core").Signal<"Every open contract in this trade unit is fully priced." | "Choose a trade unit in the top bar to load unpriced contracts.">;
  /**
   * True when the server had more open contracts than arrived.
   *
   * The client-side filter cannot see past what it was given, so this is what turns "12 unpriced"
   * from a claim about the queue into a claim about what was read. ⚠ Since #1118 every page is read,
   * so this is a short read (a failed page), not "more than one page".
   */
  protected readonly moreThanOnePage: import("@angular/core").Signal<boolean>;
  protected readonly totalOpen: import("@angular/core").Signal<number>;
  protected readonly trackByContract: (row: ContractSummary) => string;
  protected onSortChange(sorts: readonly GridSort[]): void;
  /** The filter rules, evaluated over every column this grid renders. Client-side, like the search. */
  protected readonly filter: import("@angular/core").WritableSignal<FilterGroup>;
  /** Which grid the saved views belong to - see SAVED_FILTER_SCOPES. */
  protected readonly savedFilterScope: "pricing";
  protected onRulesChange(group: FilterGroup): void;
  /**
   * A saved view: its rules, and its sorting where it has any.
   *
   * 🔴 **EVERY view clears the sort, the baseline included** (JFrisbie, 2026-09-16). `sort` is always
   * a chain and an empty one means "clear it", so what you see after selecting a view is what that
   * view is — it cannot depend on which view preceded it.
   */
  protected onViewChange(view: AppliedView): void;
  protected onSearch(term: string): void;
  protected refresh(): void;
  protected retry(): void;
  /**
   * Opens the contract's **price sequences** — `/pricing/{n}` — not the record.
   *
   * 🔴 **This used to navigate to `/contracts/{n}`, and the reasoning it carried was sound when it was
   * written and had stopped being true.** It said sending the user to the record keeps one renderer
   * for CTRM's price sequences, because `PrcDS` (the aggregate's collection) and `dsPrc` (the pricing
   * API's record) are different records with different field names (Known Issue 34) — and two grids
   * would be two chances to mix them up. Both halves are still true. What changed is that the second
   * grid **already exists**: `/pricing/{n}` ships a create/edit/delete editor over
   * `/api/v1/pricing/*`, and it was reachable from nothing but the route table.
   *
   * So the queue was routing past the only screen on which its own work can be done, and the record's
   * price grid is the read-only one — the aggregate's copy, which cannot be edited at all.
   *
   * ⚠ The record is still one click away, from that screen's own "View full record" link, which is
   * why `record-origin.ts` now gives pricing a middle crumb.
   */
  protected onRowActivate(row: ContractSummary): void;
  private readonly journeys;
  static ɵfac: i0.ɵɵFactoryDeclaration<PricingPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PricingPageComponent, "cms-pricing-page", never, {}, {}, never, never, true, never>;
}
/**
 * The unpriced queue's columns — docs/02 §5.1, carrying **BR-054's settlement dimension** as far as
 * the list route can.
 *
 * 🔴 **The four quantity columns are the whole point of this screen, and they were unreachable from
 * the SPA until 2026-09-10.** `unpriced_quantity`, `applied_quantity` and `open_quantity` have been
 * on the wire since E0.6, mapped onto `ContractSummary` by #118 — and the client's own
 * `ContractSummary` interface never declared them, so they deserialised to `undefined` and rendered
 * as nothing. Declaring them is what made this queue buildable; see the model's own remarks, because
 * that is the third recorded instance of the same class of defect.
 *
 * ⚠ **BR-054's dimension is only PARTLY available here, and the screen says so rather than implying
 * otherwise.** Priced / Unpriced / Applied / Open all derive from the list row. **Unsettled,
 * Settled and every LOADS figure do not** — they live on the price sequences (`ContractPriceSequence`
 * carries `priced_loads`, `OpenQuantity`, `AppliedQuantity` per sequence), which arrive only with the
 * contract aggregate. That is why a row opens the contract rather than expanding in place.
 */
/**
 * Quantity already priced — **derived, not returned.**
 *
 * CTRM sends `quantity` and `unpriced_quantity` and no `priced_quantity` on this route, so the
 * subtraction happens here. It is safe because both are CTRM's own figures in CTRM's own unit; what
 * would not be safe is deriving it from the price sequences, which are a different route and a
 * different record (Known Issue 34 — two routes that both return "a price" return different things).
 *
 * ⚠ Returns `null` when either input is missing rather than treating a null as zero: `quantity` null
 * minus `unpriced` 500 is not `-500`, it is unknown, and a negative priced quantity on screen would
 * read as a data defect in CTRM rather than as our arithmetic.
 */
export declare function pricedQuantity(row: ContractSummary): number | null;
/**
 * Whether a contract belongs in the unpriced queue.
 *
 * 🔴 **Keyed on `unpricedQuantity > 0` and deliberately NOT on price type `U`.**
 *
 * docs/02 §5.1 says *"open contracts, price type `U`, unpriced qty > 0"*. The price-type half is
 * **not implemented as a filter, on purpose**: the simulator's `price_type_code` domain is
 * `FLAT`/`BASIS`/`HTA`/`MIN` — no `U` anywhere — and docs/04a does not enumerate the live domain, so
 * nothing in this repository establishes that `U` is a value real contracts carry.
 *
 * ⚠ **A filter on a code that never appears returns an empty queue that reads as "nothing to
 * price"** — the same silent failure as the market-months reference set that was empty on UAT and
 * looked fine for weeks. #102 flags exactly this and says to verify against live data first.
 *
 * So the queue filters on the *computed* quantity, which CTRM supplies and which directly expresses
 * "this contract needs pricing", and price type is offered as an **optional, visible** filter the
 * user can narrow with. When someone confirms `U` against live data, tightening this is one line.
 */
export declare function needsPricing(row: ContractSummary): boolean;
export declare const PRICING_GRID_COLUMNS: readonly GridColumn<ContractSummary>[];
/**
 * **The pricing screen — docs/02 §5.2, task F5.2.**
 *
 * Contract header and the price-sequence grid carrying BR-054's settlement dimension. A sequence opens
 * as its own details screen (#1149, `PriceSequenceDetailPageComponent`): double-click or Enter on a
 * row opens its view, the row menu's Edit its editor, and Add the editor for a new one. The inline
 * editor that stood above this grid is gone; deleting from the row menu stays here.
 *
 * ### 🔴 The screen NEVER updates its own copy from what it sent
 *
 * Every pricing write answers `202` with `type: Success` whatever it did, and on the delete a call
 * that removed a row is byte-comparable with one that removed nothing (#127). So the API re-reads and
 * returns what CTRM now holds, and this screen renders **that** — never a locally-patched array. That
 * is why {@link rows} reads from the last write's payload in preference to the initial load rather
 * than merging the two. The other half of #156 is that a delete is reported only when that read-back
 * no longer lists the sequence; if it still does, {@link deleteNotApplied} says so.
 *
 * ⚠ **`verified: false` means the write was accepted and the read-back failed** — not that the write
 * failed. The screen says so rather than reporting an error, because telling a user their save failed
 * when it did not is how a price gets entered twice.
 *
 * ### 🔑 BR-050 is computed live and is NOT sent as the authority
 *
 * Flat price = basis + adjustments + futures, recomputed as the user types. CTRM computes the stored
 * price itself, so this is a *preview* of what CTRM will arrive at — and where the two disagree on an
 * existing sequence the screen says so rather than silently showing our arithmetic. Presenting a
 * derived value we compute as the answer is the `*_description` mistake in a new place.
 *
 * ### ⚠ What the sequence editor does not do, and why
 *
 * **The market code and month are typed, not picked.** #201 is the pricing cascade — market code
 * derived from location + commodity, months filtered to that market, hedge fields mirroring
 * (F-18/19/20, BR-005) — and it needs the reference routes keyed per field. Guessing a domain here
 * would produce a picker that filters to nothing on live data, which is the failure the unpriced queue
 * already refuses to risk with `price_type_code`.
 *
 * **Approval lives on the approvals queue**, not here: BR-052 is cross-contract and §5.3 specifies it
 * as its own screen with bulk selection.
 */
export declare class PricingDetailPageComponent {
  private readonly source;
  /** BR-053's fresh read (#743). Required: a host without it fails loudly rather than skipping the check. */
  private readonly contractDetail;
  private readonly permissions;
  /**
   * The crumb, Escape and View full record go through the host (E9 PR 4, F9.10): its href and its
   * click. Embedded, a routerLink to `/pricing` or `/contracts` would leave the host's prefix.
   */
  private readonly hostContext;
  private readonly route;
  /**
   * The queue's packed state, from `?returnTo=`, or `null` when this screen was reached directly.
   *
   * Read from the **snapshot**, as the approval review screen and the record screen both do: it
   * describes the journey that reached this screen, so it cannot change while the screen is open.
   */
  private readonly returnTo;
  /**
   * Where the breadcrumb and Escape both go — the queue, in the state it was left in.
   *
   * 🔴 **One source for both, which is the point rather than a tidy-up.** The record screen has
   * already recorded what happens when a shortcut and the crumb beside it disagree: the crumb
   * returned the user to their queue while Escape moved them somewhere else, and nothing looked
   * broken — the queue was simply gone.
   *
   * ⚠ Unpacked into an object rather than kept as a string, so the crumb stays a real `routerLink`
   * anchor: it keeps its `href`, so middle-click and open-in-new-tab work and a keyboard user reaches
   * it with Tab. A `(click)` handler calling `navigateByUrl` would look identical and be none of
   * those things.
   */
  protected readonly returnParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * The screen behind this one.
   *
   * 🔴 **This screen used to hard-code `Pricing` → `/pricing`**, which was right while the pricing
   * queue was the only way in and wrong in the way `record-origin.ts` exists to describe: it keeps
   * working, so a user who arrives from somewhere else is quietly returned to a screen they never
   * came from. The fallback is `pricing` rather than `contracts` for the same reason the approval
   * review screen's is `approvals` — an absent `from` here means the pricing queue.
   */
  protected readonly origin: import("@angular/core").Signal<import("@cws/domain-contracts").RecordOriginDescriptor>;
  /**
   * The same origin by logical name, for the host, resolved HERE with this screen's `pricing`
   * fallback: the host's table falls back to the workspace (E9 PR 4).
   */
  private readonly originKey;
  /** Back to the queue with its state: the crumb and Escape. */
  private readonly originIntent;
  /** The full record, telling it this screen is behind it. */
  private readonly recordIntent;
  protected readonly recordHref: import("@angular/core").Signal<string>;
  /** A plain left click is handed to the host; a modified or middle click is left to the browser. */
  protected follow(event: MouseEvent, intent: CmsNavigationIntent): void;
  protected followRecord(event: MouseEvent): void;
  /**
   * The trail back, as the shared breadcrumb takes it.
   *
   * ⚠ **One crumb, deliberately.** `recordTrail` is not used here because its middle crumb is *this*
   * screen: `from=pricing` means `/pricing/{n}` is behind you, and it is what you are looking at.
   * Calling it would render a link to the current page wearing the label `Prices`.
   */
  protected readonly crumbs: import("@angular/core").Signal<readonly BreadcrumbCrumb[]>;
  /** The scope everything below is resolved under. Rendered as the leading, non-navigable crumb. */
  protected readonly tradeUnitLabel: import("@angular/core").Signal<string | null>;
  /**
   * Query parameters for "View full record", so the record screen's crumb comes back through here.
   *
   * ⚠ **`from` is what the record screen reads to label and aim its crumb**, and it defaults to the
   * workspace when absent — so omitting it does not break anything visibly, it quietly moves the user
   * to a different screen. That is the exact failure `record-origin.ts` exists for, and the record
   * screen's own "View full record" link is where it was found.
   */
  protected readonly recordLinkParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * Escape returns to the queue, exactly as the crumb does. (The editor that used to catch it first
   * is its own screen now, #1149.) Ignored when something else, such as the delete dialog, handled it.
   */
  protected onEscape(event: Event): void;
  /** From the route. */
  readonly contractNumber: import("@angular/core").InputSignal<string>;
  protected readonly columns: readonly import("@cws/shared-ui").GridColumn<PriceSequence>[];
  protected readonly sorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  /** Bumped to re-issue the read — after a write, or on an explicit refresh. */
  private readonly reload;
  private readonly loaded;
  protected readonly state: import("@angular/core").Signal<RemoteData<ContractPrices>>;
  /**
   * BR-053's re-check (F5.1, #743): the contract read FRESH from CTRM, on load and on every reload.
   *
   * 🔴 **Never the queue row.** The unpriced queue is a cached list projection, up to its TTL stale,
   * so a row can show 500 unpriced for a contract whose last price was saved a minute ago. Only a fresh
   * `GET /contracts/{n}` can say what CTRM would do with an Add now.
   */
  private readonly openCheck;
  /**
   * What the re-check found, or `null` until CTRM has answered. Success shows nothing; the other
   * outcomes are a banner. CTRM's refusal of the write stays the authority: this is BR-053's
   * pre-check, so the screen says what CTRM will do before the user types a price it would refuse.
   */
  protected readonly openOutcome: import("@angular/core").Signal<UnpricedOpenOutcome | null>;
  /** Why Add is held by the re-check, or `null`. Only an ADD: CTRM's three refusals are all for ADD. */
  protected readonly addHeld: import("@angular/core").Signal<string | null>;
  /**
   * The last write's returned state, which supersedes the load until the next read.
   *
   * 🔴 Held rather than merged. A merge would need this screen to decide which copy is authoritative
   * per row, and the answer is always "the one CTRM just gave us" — so the whole array is replaced.
   */
  protected readonly afterWrite: import("@angular/core").WritableSignal<readonly PriceSequence[] | null>;
  /** Set when a write was accepted and could not be read back. */
  protected readonly unverified: import("@angular/core").WritableSignal<string | null>;
  /** Set when a write failed outright. */
  /**
   * The last write's outcome (#803): a success with CTRM's own acknowledgement, or a refusal with the
   * server's reference. The two in-between states (accepted but not confirmed, and a delete that did
   * not take effect) keep their own warnings below, because they are neither.
   */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /**
   * Refusals that address no control — the API's `formErrors` extension member (F2.4, #373).
   *
   * 🔴 **These used to be dropped on this screen.** A CTRM rejection naming a procedure rather than
   * a field left the user with one generic sentence and nothing to act on, which the roadmap row
   * calls worse than showing it late. `errors` is not read here on purpose: there is no dynamic form
   * on this screen for a control-scoped reason to land against, and inventing a mapping would put a
   * second, weaker copy of the record screen's behaviour here.
   */
  protected readonly writeFormErrors: import("@angular/core").WritableSignal<readonly string[]>;
  /**
   * Set when a delete was accepted and the re-read still lists the sequence (#156).
   *
   * 🔴 **Neither a success nor a failure, so it has its own message.** The `202` and its populated
   * title are byte-comparable with a real delete (#127), and `verified` says only that the read-back
   * succeeded — not what it found. Reporting success would be false; reporting "not saved" would
   * misdescribe a request CTRM accepted.
   */
  protected readonly deleteNotApplied: import("@angular/core").WritableSignal<string | null>;
  /** Set from the API's own acknowledgement, so the user sees what CTRM said. */
  protected readonly lastAcknowledgement: import("@angular/core").WritableSignal<string | null>;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  /**
   * Edit and Remove, as grid row actions.
   *
   * ⚠ **An approved sequence stays editable**, because CTRM permits it and being stricter than the
   * system of record strands the user. The grid already carries an Approved column, so the marker
   * that sat beside the old buttons was a second copy of it.
   *
   * `disabled` returns a STRING because the grid renders it as the reason: a disabled button with
   * no stated reason is what makes people wonder why not this row.
   */
  /** Whether this account may add, change or remove price sequences. */
  protected readonly canEditPricing: import("@angular/core").Signal<boolean>;
  /**
   * #411, C-15 — why every CTRM write is refused in this trade unit whatever the account holds, or
   * `null`. About the trade unit, not the account, so the granted controls stay and are disabled with
   * this sentence as their title (F4.3a) rather than hidden.
   */
  protected readonly writeRefusal: import("@angular/core").Signal<string | null>;
  /**
   * Edit and Remove, when this account may price at all.
   *
   * 🔴 **An empty array removes the column entirely** — `hasActions` is a length check — so a
   * reader sees the sequences and no controls, rather than two disabled buttons on every row.
   * The notice above the grid carries the reason once.
   *
   * ⚠ The `disabled` rules are a DIFFERENT gate and both still apply: permission decides whether
   * the buttons exist, an in-flight write decides whether they are pressable. Collapsing the two
   * would lose the "a pricing write is in flight" explanation, which is the one a user meets on
   * every save.
   */
  /** Names a row in its actions menu button, "Actions for sequence 2" (#816). */
  protected readonly sequenceLabel: (row: PriceSequence) => string;
  protected readonly rowActions: import("@angular/core").Signal<readonly GridRowAction<PriceSequence>[]>;
  protected readonly rows: import("@angular/core").Signal<readonly PriceSequence[]>;
  private sortRows;
  /**
   * The queue's journey: "Record 3 of 150" and ‹ ›, over the queue's filtered, sorted order.
   *
   * An arrow asks for the next contract's price sequences with the `from` and `returnTo` this one
   * arrived with, so the crumb and Escape still return to the queue's page and state. Held while a
   * write is in flight, whose outcome belongs to this contract. This screen has no editor to lose
   * (#1149), so it has no leave guard, and the arrows need none.
   */
  protected readonly journey: import("@cws/domain-contracts").RecordJourneyControl & {
    leave(): void;
  };
  /** `from` exactly as it arrived, passed on unchanged so the next screen's crumb says the same. */
  private readonly fromParam;
  /** `from` and `returnTo` as they arrived: what the next contract and each sequence screen carry. */
  private readonly passedParams;
  /**
   * 🔴 **The router reuses this screen for the next contract** (#1148), so what belongs to the last
   * one is cleared when the number changes: the last write's read-back (which the grid prefers to the
   * load, so it would show the last contract's sequences), and every outcome. Then whatever a sequence
   * screen left for this contract (#1149: a delete, or a new sequence it could not name) is taken.
   */
  private lastContract;
  private readonly arrivals;
  private readonly resetForContract;
  /**
   * Double-click or Enter on a row: the sequence's view, stepping through this grid as displayed.
   *
   * The snapshot is the grid's rows in their displayed sort, taken now, so ‹ › on the sequence screen
   * walk exactly what was on screen. This screen's own place in the unpriced queue rides beside it, so
   * coming back here still reads "Record 2 of 5" over the queue.
   */
  protected onRowActivate(row: PriceSequence): void;
  /** A sequence's screen, in `mode`, carrying the way back and this screen's place in the queue. */
  private openSequence;
  /**
   * Opens the editor on a new sequence: its own screen, with no number.
   *
   * 🔴 **An add carries sequence `0`, and CTRM numbers it** (Lisa's CQ00132, #581). The new screen
   * sends 0 and reads the number CTRM gave it back from the response.
   */
  protected addSequence(): void;
  private readonly confirm;
  protected askDelete(row: PriceSequence): void;
  private removeSequence;
  /**
   * Runs a write and takes the returned state as the new truth.
   *
   * 🔴 The success branch never patches a local array. It replaces it with what the API read back,
   * which is the only thing that reflects what CTRM actually did.
   *
   * `notApplied` inspects that read-back for a write whose acknowledgement cannot be trusted — the
   * delete (#156). When it returns a reason, the acknowledgement is NOT shown, because CTRM's
   * "accepted" beside a row that is still there would read as success.
   */
  private run;
  protected refresh(): void;
  private clearMessages;
  static ɵfac: i0.ɵɵFactoryDeclaration<PricingDetailPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PricingDetailPageComponent, "cms-pricing-detail-page", never, {
    "contractNumber": {
      "alias": "contractNumber";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The price-sequence grid — docs/02 §5.2, carrying **BR-054's settlement dimension in full**.
 *
 * 🔴 **This is the only place the full dimension is available.** The unpriced queue derives what it can
 * from the list route and says so; unsettled, settled and all three LOADS figures exist only on a price
 * sequence, which arrives only from `GET /api/v1/pricing/{contract}/prices`. A grid that dropped them
 * would look complete and answer none of the questions §5.2 exists to answer.
 *
 * ⚠ **`sortValue` is supplied for every numeric and date column.** Sorting on `format`'s output is
 * wrong for anything that is not plain text — `10.0000` sorts before `6.4275`, and `9/12/25` after
 * `10/…` — which is a defect the contract grid already had and fixed.
 */
export declare const PRICE_SEQUENCE_COLUMNS: readonly GridColumn<PriceSequence>[];
/** Which half of the screen: the sequence read-only, its editor, or the editor for a new one. */
export type PriceSequenceMode = 'view' | 'edit' | 'new';
/** The editor's working copy. */
interface PriceDraft {
  readonly priceSequence: number;
  readonly isNew: boolean;
  pricedQuantity: string;
  pricedLoads: string;
  hedgePrice: string;
  basisPrice: string;
  adjustments: number;
  hedgeMarketCode: string;
  hedgeMarketMonthCode: string;
  priceDate: string;
  description: string;
  remark: string;
  printFlag: boolean;
}
/**
 * **One price sequence as a details screen** (#1149): view first, then Edit, as the contract record
 * works. Replaces the pricing screen's inline editor.
 *
 * Three routes, one component: `pricing/:contractNumber/sequences/:seq` (the view),
 * `.../:seq/edit` (the editor) and `pricing/:contractNumber/sequences/new` (the editor with no
 * sequence). Edit and Cancel move between the first two, so the router builds the screen again, and
 * a save's outcome and CTRM's read-back are handed across in {@link PricingArrivals}.
 *
 * ### 🔴 The screen renders what CTRM reported, never what it sent
 *
 * The rule the pricing screen states (#156) holds here unchanged: every pricing write answers `202`
 * whatever it did, so the API re-reads and returns what CTRM holds, and that read-back is what the
 * view shows after a save. A delete is reported only when the read-back no longer lists the sequence.
 *
 * ### 🔴 An add sends sequence `0`, and CTRM numbers it (CQ00132, #581)
 *
 * The new screen shows no number. After the save the number CTRM gave it is found in the read-back
 * (the one sequence it did not list before), and the view of that sequence opens. If it cannot be
 * told apart, the contract's price sequences open instead, carrying the read-back.
 *
 * ### ⚠ The market code and month stay typed
 *
 * See the pricing screen's remarks: the sequence's hedge market is a different CTRM record from the
 * contract header's, and the pricing response carries no location or commodity to filter by.
 *
 * A NEW sequence starts with the contract's market code, month and basis (#1171), still editable:
 * the market pair is the one CTRM itself fills a blank sequence from, the basis is GEstevez's ruling.
 */
export declare class PriceSequenceDetailPageComponent implements ConfirmsNavigation {
  private readonly source;
  private readonly contractDetail;
  /** The contract's raw field values (#1171). Optional: a host without it gets a blank market. */
  private readonly contractFields;
  private readonly permissions;
  private readonly hostContext;
  private readonly route;
  private readonly arrivals;
  private readonly confirm;
  /** From the route. */
  readonly contractNumber: import("@angular/core").InputSignal<string>;
  /** From the route; absent on a new sequence. */
  readonly seq: import("@angular/core").InputSignal<string | undefined>;
  /** From the route's data. Absent reads as the view. */
  readonly mode: import("@angular/core").InputSignal<PriceSequenceMode | undefined>;
  protected readonly screenMode: import("@angular/core").Signal<PriceSequenceMode>;
  protected readonly isNew: import("@angular/core").Signal<boolean>;
  /** The sequence on screen, or `null` on a new one (or a key that is not a number). */
  protected readonly sequenceNumber: import("@angular/core").Signal<number | null>;
  /** `from` and `returnTo` exactly as they arrived, passed on so every crumb goes back the same way. */
  private readonly fromParam;
  private readonly returnTo;
  /** What the pricing screen carries, and what this screen hands on to the next. */
  private readonly passedParams;
  private readonly originKey;
  private readonly origin;
  /**
   * The pricing screen's own place in the queue it was opened from, carried through this one so going
   * back there keeps it. See {@link PRICING_PARENT_JOURNEY}.
   */
  private readonly parentJourney;
  /** The queue, with its packed state: the outer crumb. */
  private readonly originIntent;
  /** The contract's price sequences: the middle crumb, Escape from the view, and where a delete goes. */
  private readonly pricingIntent;
  /** The full record, telling it the pricing screen is behind it, as that screen's own link does. */
  private readonly recordIntent;
  protected readonly recordHref: import("@angular/core").Signal<string>;
  /** `Pricing › <contract> › Sequence <n>`, each crumb through the host. */
  protected readonly crumbs: import("@angular/core").Signal<readonly BreadcrumbCrumb[]>;
  protected readonly currentCrumb: import("@angular/core").Signal<string>;
  protected readonly title: import("@angular/core").Signal<string>;
  protected readonly tradeUnitLabel: import("@angular/core").Signal<string | null>;
  /** A plain left click is handed to the host; a modified or middle click is left to the browser. */
  protected follow(event: MouseEvent, intent: CmsNavigationIntent): void;
  protected followRecord(event: MouseEvent): void;
  /**
   * "Record 2 of 5" over the sequence grid, in the order it was displayed when the row was opened. An
   * arrow opens the next sequence in the same mode; from the editor the leave guard asks first, as on
   * Back. Held while a write is in flight. A new sequence has no place in the grid and shows none.
   */
  protected readonly journey: import("@cws/domain-contracts").RecordJourneyControl & {
    leave(): void;
  };
  /** This contract's sequence `priceSequence`, carrying the way back and the journeys. */
  private sequenceIntent;
  private readonly reload;
  private readonly loaded;
  /** The last write's read-back, which supersedes the load until the next read. Never merged. */
  protected readonly afterWrite: import("@angular/core").WritableSignal<readonly PriceSequence[] | null>;
  /** The load, or the last write's read-back in its place. */
  protected readonly state: import("@angular/core").Signal<RemoteData<ContractPrices>>;
  private readonly prices;
  /** The sequence on screen, or `null` while loading, on a new one, or when CTRM does not list it. */
  protected readonly row: import("@angular/core").Signal<PriceSequence | null>;
  /** Loaded, and the sequence is not there: a stale link, or one removed elsewhere. */
  protected readonly missing: import("@angular/core").Signal<boolean>;
  /**
   * BR-053's re-check before an Add (#743), on the new screen only: the contract read fresh from CTRM.
   * The pricing screen already holds its Add button on it; this keeps a typed URL from skipping it.
   */
  private readonly freshContract;
  protected readonly openOutcome: import("@angular/core").Signal<UnpricedOpenOutcome | null>;
  /**
   * The contract's own market code and month (#1171), on the new screen only: `price_market_code`
   * and `price_market_month`, the pair CTRM itself stores when a new sequence's are blank
   * (`cntprcadd.sqlrpgle:725-732` sets `cxfumk`/`cxfumo` from `cmktcd`/`cmonth`, which
   * `contapi.sqlrpgle:672-673` reads out under those names). Not on the contract read above, so this
   * reads `/fields`. A failure is a blank start, which is what CTRM fills anyway.
   */
  private readonly contractMarket;
  /** What a new sequence starts from: the contract's market code, month and basis (#1171). */
  private readonly contractDefaults;
  /** Why Save is held on a new sequence by the re-check, or `null`. */
  protected readonly addHeld: import("@angular/core").Signal<string | null>;
  protected readonly canEditPricing: import("@angular/core").Signal<boolean>;
  protected readonly writeRefusal: import("@angular/core").Signal<string | null>;
  /** The editor shows only to an account that may price; anyone else gets the view. */
  protected readonly editing: import("@angular/core").Signal<boolean>;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly writeFormErrors: import("@angular/core").WritableSignal<readonly string[]>;
  protected readonly unverified: import("@angular/core").WritableSignal<string | null>;
  protected readonly lastAcknowledgement: import("@angular/core").WritableSignal<string | null>;
  protected readonly deleteNotApplied: import("@angular/core").WritableSignal<string | null>;
  protected readonly draft: import("@angular/core").WritableSignal<PriceDraft | null>;
  /** The draft as it was seeded, so a change can be told from none. */
  private readonly pristine;
  /** Set by a save that is leaving on purpose, so the guard does not ask about work just sent. */
  private leaving;
  /** Unsaved edits: the guard asks before ‹ ›, Back, Cancel or a crumb would drop them. */
  protected readonly dirty: import("@angular/core").Signal<boolean>;
  /**
   * Seeds the editor once its sequence is there: a blank one on a new sequence, the row on an edit.
   * Re-seeded only after a reset, never over the user's typing.
   */
  private readonly seedDraft;
  private readonly seeded;
  /**
   * A new sequence takes the contract's market code, month and basis as they arrive (#1171), into the
   * draft AND its pristine copy, so the prefill is the starting point rather than an unsaved change.
   * Only a field still blank and untouched is filled: typing is never overwritten, and a field the
   * user cleared stays clear (CTRM then fills the market itself).
   */
  private readonly prefillFromContract;
  /**
   * 🔴 **The router reuses this screen for the next sequence** (‹ ›), so what belongs to the last one is
   * cleared when the key changes: the editor (re-seeded from the new row), and every outcome. Then
   * whatever a save or a delete left for this sequence is taken.
   */
  private lastKey;
  private readonly onArrival;
  private takeArrival;
  /** BR-050 over the draft, recomputed on every keystroke. */
  protected readonly draftFlatPrice: import("@angular/core").Signal<number>;
  /** BR-050 over the stored terms, for the view's flat-price line. */
  protected readonly viewFlatPrice: import("@angular/core").Signal<number>;
  /**
   * True when the stored price disagrees with BR-050 over the terms on screen. Surfaced rather than
   * corrected: CTRM owns the stored price.
   */
  protected readonly storedPriceDisagrees: import("@angular/core").Signal<boolean>;
  /** The view's rows, in the editor's order and with its labels. */
  protected readonly viewFields: import("@angular/core").Signal<readonly {
    readonly label: string;
    readonly value: string;
    readonly wide?: boolean;
  }[]>;
  protected patch<K extends keyof PriceDraft>(key: K, value: PriceDraft[K]): void;
  /**
   * Stores a numeric field as the RAW TEXT typed. Parsing on every keystroke rewrote `-0` as `0` and
   * `4.` as `4` (see the pricing screen's history); the text is parsed only where a number is needed.
   */
  protected patchText(key: 'pricedQuantity' | 'pricedLoads' | 'hedgePrice' | 'basisPrice', raw: string): void;
  protected readonly canSave: import("@angular/core").Signal<boolean>;
  /** Edit swaps this screen into its editor, keeping the journey and the way back. */
  protected edit(): void;
  /** Back to the view; a new sequence has none, so back to the contract's price sequences. */
  protected cancel(): void;
  protected save(): void;
  /** Delete, after the shared confirmation; the same question the pricing screen asks. */
  protected askDelete(): void;
  private remove;
  /**
   * Runs a write. A refusal stays on this screen with its reasons and the server's reference; an
   * accepted write goes to `accepted` with CTRM's read-back, never with what was sent.
   */
  private write;
  protected refresh(): void;
  private clearMessages;
  /** The leave guard (`confirmNavigationGuard` on the edit and new routes). */
  confirmNavigation(): Observable<boolean> | boolean;
  /** The one exit the router cannot see: a reload or a closed tab. The wording is the browser's. */
  protected onBeforeUnload(event: BeforeUnloadEvent): void;
  /**
   * Escape: from the editor it is Cancel (the guard asks if there are changes); from the view it goes
   * back to the contract's price sequences, the crumb immediately behind. Ignored when something else,
   * such as an open dialog, has already handled it.
   */
  protected onEscape(event: Event): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<PriceSequenceDetailPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PriceSequenceDetailPageComponent, "cms-price-sequence-detail-page", never, {
    "contractNumber": {
      "alias": "contractNumber";
      "required": true;
      "isSignal": true;
    };
    "seq": {
      "alias": "seq";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** A queue row, which is a sequence plus the contract it belongs to. */
export interface ApprovalRow extends PriceSequence {
  readonly contract: string;
}
/**
 * **The pricing approval queue — docs/02 §5.3, task F5.3.**
 *
 * Cross-contract, with individual and bulk approval (BR-052).
 *
 * ### 🔴 Whose queue: the signed-in approver's own, across every trade unit (#1170)
 *
 * The screen reads `PRICING_APPROVAL_QUEUE_SOURCE` (`GET /approvals/pricing-queue`, #1168), as the
 * contract approvals screen reads its queue (#1021). Before, it listed every unapproved sequence in
 * the top bar's trade unit, so an approver saw, and could select, other approvers' sequences.
 *
 * - **`loaded`**: the approver's queue; the screen says whose, and the trade unit does not narrow it.
 * - **`refused`**: the server could not tell who the user is in CTRM. Its title and detail are shown,
 *   and **no** rows: an empty queue would read as "nothing to approve".
 * - **`failed`**: the route broke. The container says so and offers Retry.
 * - **`notDeployed`** (a `404`, or no seam): the trade unit's queue, as before the route, and the
 *   screen states that it is showing a whole unit.
 *
 * ### 🔴 Approval has no inverse, and the screen is built around that
 *
 * `spMergeGNPA09` stamps the approval with the date and the calling program and there is no
 * un-approve — so bulk selection is opt-in per row rather than select-all-by-default, the count is
 * stated before the action, and the button says how many it is about to approve. A "select all" that
 * defaulted on would make the destructive choice the one you get by not looking.
 *
 * ### 🔴 Approval is per contract, so a bulk approval is N requests
 *
 * `POST /pricing/{contract}/approvals` takes sequences for **one** contract. A queue spanning
 * contracts therefore groups the selection and issues one request per contract, **sequentially** — the
 * same reasoning the all-pages export uses: concurrent CTRM writes are exactly the load pattern
 * spike 1 warned about, and an approval is not the place to discover it.
 *
 * ⚠ **A partial failure is reported as a partial failure.** If the third of five contracts is refused,
 * the first two are approved and cannot be undone — so the screen names what succeeded rather than
 * showing one error and leaving the user to guess.
 *
 * ### ⚠ The queue's own truncation is surfaced
 *
 * CTRM caps this route at `Dim(2000)` with no paging and reports no truncation. The API returns the
 * ceiling; the screen says so when the count reaches it, rather than presenting a short queue as
 * complete — CR-4's class of silent short read on a different route.
 */
export declare class PricingApprovalsPageComponent {
  private readonly source;
  private readonly tradeUnit;
  private readonly permissions;
  /**
   * Whether this account may commit a pricing approval.
   *
   * ⚠ **OUR authority, not CTRM's.** CTRM runs a per-location approval check that no published
   * route exposes, so a `true` here does not promise CTRM would agree — and the commit is
   * simulated regardless while the origin OOMs on every request shape.
   */
  protected readonly canApprove: import("@angular/core").Signal<boolean>;
  /**
   * #411, C-15 — why every CTRM write is refused in this trade unit whatever the account holds, or
   * `null`. An approval is a CTRM write, so the granted controls are disabled with this as their
   * title (F4.3a) rather than hidden.
   */
  protected readonly writeRefusal: import("@angular/core").Signal<string | null>;
  protected readonly columns: readonly import("@cws/shared-ui").GridColumn<ApprovalRow>[];
  /** The Columns menu's choice, in the toolbar beside Export as on Home (JFrisbie, 2026-10-23). */
  protected readonly columnChoice: import("@cws/shared-ui").GridColumnChoice<ApprovalRow>;
  protected readonly sorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  protected readonly search: import("@angular/core").WritableSignal<string>;
  /**
   * What the container says when it has nothing to show.
   *
   * 🔴 Two different absences: no scope means *nothing was asked for*, no rows means *the answer
   * was empty*. One message for both would tell a user the approval queue is clear when the screen
   * has not issued a request.
   */
  protected readonly emptyMessage: import("@angular/core").Signal<string>;
  private readonly reload;
  /** The approver's own pricing queue (#1168). Optional: a host without it gets the trade unit's queue. */
  private readonly queueSource;
  /**
   * Set once the queue route has answered `notDeployed`, so Refresh re-reads the trade unit rather
   * than asking a server without the route again and flickering between the two scopes.
   */
  private queueRouteAbsent;
  /**
   * The approver's queue read. `settled` is the last answer, `null` until the first; a Refresh does
   * not clear it, so the scope on screen cannot flip back to pending while the queue re-reads.
   *
   * ⚠ **Pending issues no trade-unit request**: reading the unit first and the approver's queue second
   * would show one queue and then replace it with another under the approver's cursor.
   */
  private readonly queueState;
  /** One read per Refresh or approval run; `refresh` is sent only when the counter has moved. */
  private queueReads;
  /**
   * Which queue is on screen: `pending` (the route has not answered), `approver` (it answered, with a
   * queue or a failure the container shows), `refused`, or `tradeUnit` (the route is not on this
   * server, or no seam is provided).
   */
  protected readonly mode: import("@angular/core").Signal<"tradeUnit" | "refused" | "approver" | "pending">;
  /** Who the route resolved the user to, when it answered a queue. */
  protected readonly approver: import("@angular/core").Signal<import("@cws/domain-contracts").ApprovalQueueApprover | null>;
  /**
   * The refusal, as a failure that stays until dismissed and carries the server's reference.
   * ⚠ Dismissing hides the message, not the refusal: the queue stays empty and the container repeats
   * the title.
   */
  private readonly refusalDismissed;
  protected readonly refusal: import("@angular/core").Signal<MutationOutcome | null>;
  /** The refusal's detail, repeated in the scope notice so it survives the message being dismissed. */
  protected readonly refusalDetail: import("@angular/core").Signal<string>;
  protected dismissRefusal(): void;
  /** The scope notice's one-line summary, counted by the notices panel. */
  private readonly scopeSummary;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  /**
   * A run's two outcomes (#803), and a run can have both: the contracts approved before a failure
   * stay approved, so the success names them while the failure, with its reference, names the rest.
   */
  protected readonly message: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly failure: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /**
   * The trade-unit query, used ONLY when the approver's queue route is not on the server (#1170).
   *
   * ⚠ **The location comes from the shell's trade unit**, which is also what makes the queue callable
   * at all: the API refuses a call with neither a trader nor a location, because CTRM does. With no
   * trade unit chosen there is nothing to ask for, and the screen says so rather than issuing a
   * request that must fail.
   *
   * 🔴 **The trade unit is now the ONLY scope**, since the Trader box came off the toolbar. It used
   * to be the second half of an `or`, so a user with no trade unit could still load a queue by typing
   * their initials. That path is gone; the empty state says "choose a trade unit" and nothing else,
   * because nothing else will work.
   */
  protected readonly query: import("@angular/core").Signal<{
    location: string | undefined;
  }>;
  /**
   * Whether the screen has something to ask for: always once the approver's queue answers (the server
   * decides the scope), and a trade unit otherwise.
   */
  protected readonly hasScope: import("@angular/core").Signal<boolean>;
  /** The trade unit's queue, read ONLY when the approver's queue route is not on the server (#1170). */
  private readonly loaded;
  /**
   * What the async container renders.
   *
   * 🔴 While the precondition is unmet the state is forced to `loaded` with an empty result, so the
   * container shows the empty state rather than a spinner that will never resolve. An indefinite
   * skeleton is how "you must choose something" gets mistaken for a hang -- and the screen issues no
   * request without a scope, so the read never completes to clear it.
   *
   * The workspace has done this since it was built; these screens rendered their own card instead,
   * which is what this replaces.
   */
  protected readonly state: import("@angular/core").Signal<RemoteData<UnapprovedPrices>>;
  protected readonly mayBeTruncated: import("@angular/core").Signal<boolean>;
  protected readonly truncationCeiling: import("@angular/core").Signal<number>;
  /**
   * One line per standing notice, and — because the panel counts these — the number it reports.
   *
   * ⚠ The decision outcomes above are **not** here and must not be added: the panel holds standing
   * conditions, never the result of something the user just did.
   */
  protected readonly noticeSummaries: import("@angular/core").Signal<string[]>;
  /** #1223: the environment and system caveats are the Entra Admin role's only. */
  protected readonly showSystemNotices: import("@angular/core").Signal<boolean>;
  /**
   * The whole matched queue — filtered and sorted in the browser, **not** paged.
   *
   * ⚠ **The search runs over every column the grid renders**, matching the workspace. Filtering here
   * rather than server-side is not a choice: the route takes trader, location and approver type and
   * nothing else.
   *
   * ⚠ Named `queue` rather than `rows` since paging landed (JFrisbie, 2026-09-17), and the
   * distinction is load-bearing: the count below the grid, the export's "all" scope and the
   * truncation check are all claims about the **queue**, while selection and the grid are about the
   * **page**. Collapsing the two is how "Select these 50" quietly became "approve 2,000".
   */
  protected readonly queue: import("@angular/core").Signal<readonly ApprovalRow[]>;
  protected readonly pageSize = 50;
  /** The requested page, before clamping. Reset to 1 by anything that narrows the queue. */
  private readonly page;
  protected readonly totalPages: import("@angular/core").Signal<number>;
  /**
   * The page, clamped to what exists.
   *
   * Narrowing the search can leave the requested page past the end of the queue, and an
   * out-of-range page renders an empty grid that reads as "nothing to approve" when the matches are
   * on page 1.
   */
  protected readonly currentPage: import("@angular/core").Signal<number>;
  /**
   * The rows on screen.
   *
   * 🔴 **This screen rendered every matched row until 2026-09-17**, which is what made one spec take
   * 13 seconds against a 2,000-row fixture — CTRM's `Dim(2000)` ceiling is the realistic upper bound
   * here, not a pathological case. Paging is the same `DEFAULT_PAGE_SIZE` slice the other three grids
   * take, so the four screens now behave alike.
   *
   * ⚠ **Selection is deliberately NOT cleared when the page turns.** A selection spanning pages is
   * the point of the count on the Approve button; clearing it would silently discard rows the user
   * had already chosen, which on an action with no inverse is the worse of the two surprises.
   */
  protected readonly rows: import("@angular/core").Signal<readonly ApprovalRow[]>;
  protected onPage(page: number): void;
  /**
   * Set when an export could not complete, so the failure is on screen rather than silent.
   *
   * ⚠ Beside the grid, **not** in the notices panel: that panel holds standing conditions of the
   * screen, and this is the outcome of something the user just did.
   */
  protected readonly exportError: import("@angular/core").WritableSignal<string | null>;
  /**
   * Names an export file — `pricing-approvals-0210-page-1.csv`.
   *
   * ⚠ An arrow property rather than a method, because it is passed to `cms-grid-export` as an input:
   * a plain method would arrive unbound and throw on the first export.
   */
  protected readonly exportFilename: (scope: "page" | "all") => string;
  /**
   * Every row the current search and filter match.
   *
   * ✅ No request, and here that is not even a caching accident: the route has **no paging at all**
   * (CTRM caps it at `Dim(2000)`), so the whole queue arrives in one response and the export reads
   * what is already held.
   */
  protected readonly exportAllRows: () => Promise<readonly ApprovalRow[] | null>;
  /** The filter rules, evaluated over every column this grid renders. Client-side, like the search. */
  protected readonly filter: import("@angular/core").WritableSignal<FilterGroup>;
  /** Its own scope - this is a different grid from the trader approval queue. */
  protected readonly savedFilterScope: "pricing-approvals";
  protected onRulesChange(group: FilterGroup): void;
  /** Narrowing the queue invalidates the page number, for the same reason a rule change does. */
  protected onSearch(term: string): void;
  /**
   * A saved view: its rules, and its sorting where it has any.
   *
   * 🔴 **EVERY view clears the sort, the baseline included** (JFrisbie, 2026-09-16). `sort` is always
   * a chain and an empty one means "clear it", so what you see after selecting a view is what that
   * view is — it cannot depend on which view preceded it.
   */
  protected onViewChange(view: AppliedView): void;
  /** `contract|sequence`, because a sequence number is unique only within its contract. */
  protected readonly selected: import("@angular/core").WritableSignal<ReadonlySet<string>>;
  protected keyOf(row: ApprovalRow): string;
  protected isSelected(row: ApprovalRow): boolean;
  protected toggle(row: ApprovalRow): void;
  protected clearSelection(): void;
  /**
   * Selects everything currently VISIBLE, which is not the same as everything in the queue.
   *
   * ⚠ Named "select these N" rather than "select all" for that reason: with a filter applied, "all"
   * would be read as the whole queue, and approving something you cannot see is the one mistake this
   * screen cannot undo.
   */
  protected selectVisible(): void;
  /**
   * Space on a focused grid row (#884). Ignored mid-run, as the checkboxes are disabled then.
   */
  protected onRowToggle(row: ApprovalRow): void;
  /**
   * `Ctrl+A` on a focused grid row (#884): the rows on screen, the same set "Select these N" takes.
   *
   * 🔴 Never the whole queue. A row on another page or behind the search is hidden, and approving
   * something you cannot see is the one mistake this screen cannot undo.
   */
  protected onSelectAll(): void;
  /**
   * Both keys in the `?` cheat-sheet, on this screen only (#884). Legend-only: the grid handles the
   * keys on its focused row, so the registry must never fire them, or `Ctrl+A` would leave a text
   * field. Listed only where the grid takes them, which is for an account that may approve.
   */
  constructor();
  protected readonly selectedCount: import("@angular/core").Signal<number>;
  /** The selection grouped the way the API takes it: one request per contract. */
  private selectionByContract;
  protected approveOne(row: ApprovalRow): void;
  /**
   * Approves the selection, one contract at a time.
   *
   * 🔴 Sequential and failure-aware. Approval has no inverse, so a run that fails part-way has already
   * committed everything before the failure — and the user has to be told which, or they will retry
   * the whole selection and be refused on the ones that went through.
   */
  protected approveSelected(): Promise<void>;
  protected refresh(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<PricingApprovalsPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PricingApprovalsPageComponent, "cms-pricing-approvals-page", never, {}, {}, never, never, true, never>;
}
/**
 * The pricing approval queue's columns — docs/02 §5.3.
 *
 * 🔴 **Contract leads, and it is not decoration.** The queue spans contracts and approval is issued
 * per contract, so the contract is what a reviewer groups by and what the screen groups by when it
 * submits. A queue that showed only sequence numbers would be ambiguous — a sequence number is unique
 * only *within* a contract.
 *
 * ⚠ **Approver initials and timestamp are present although every row here is unapproved**, because
 * §5.3 specifies they display *after* approval and the queue re-reads in place: a row approved and
 * still on screen before the refresh lands should show who did it rather than going blank.
 */
export declare const APPROVAL_QUEUE_COLUMNS: readonly GridColumn<ApprovalRow>[];
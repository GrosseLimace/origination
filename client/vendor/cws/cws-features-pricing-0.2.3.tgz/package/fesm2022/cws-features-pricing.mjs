import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, HostListener, Injectable, computed, effect, inject, input, signal, untracked } from "@angular/core";
import { toObservable, toSignal } from "@angular/core/rxjs-interop";
import { ActivatedRoute } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { CONTRACT_DETAIL_SOURCE, CONTRACT_LIST_SOURCE, CONTRACT_WRITE_SOURCE, DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, PRICING_APPROVAL_QUEUE_SOURCE, PRICING_SOURCE, RECORD_JOURNEY_STATE, RECORD_ORIGIN_PARAM, RecordJourneyStore, RecordStepperComponent, SaveAnnouncementStore, flatPrice, flatPriceAgrees, formatContractDate, formatQuantity, formatShipPeriod, formatShortDate, fromRouteParams, injectRecordJourney, injectTradeUnitLabel, listCompletenessNotice, listEveryPage, recordJourneyState, recordOrigin, recordOriginKey, returnParamsAt, startRecordJourney, toRouteParams, toSortParam, unpricedOpenOutcomeOf } from "@cws/domain-contracts";
import { AsyncContainerComponent, BreadcrumbComponent, ClearSortButtonComponent, DataGridComponent, DateInputComponent, EMPTY_FILTER, FilterBuilderComponent, FilterSelectComponent, GridColumnMenuComponent, GridExportComponent, GridToolbarComponent, NoticesPanelComponent, PageHeaderComponent, PagerComponent, RefreshButtonComponent, SAVED_FILTER_SCOPES, SearchShortcutDirective, StatusMessageComponent, compareBySorts, gridColumnChoice, injectConfirm, matchesGroup, matchesSearch, mutationFailed, mutationSucceeded, registerShortcuts, remoteError, remoteLoaded, remoteLoading } from "@cws/shared-ui";
import { catchError, filter, firstValueFrom, map, of, scan, startWith, switchMap, tap } from "rxjs";
import * as i1 from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { DecimalPipe, NgTemplateOutlet } from "@angular/common";
function pricedQuantity(row) {
	if (row.quantity === null || row.unpricedQuantity === null) return null;
	return row.quantity - row.unpricedQuantity;
}
function needsPricing(row) {
	return (row.unpricedQuantity ?? 0) > 0;
}
const quantityColumn = (key, header, value, tooltip) => ({
	key,
	header,
	align: "end",
	sortable: true,
	width: 135,
	format: (row) => formatQuantity(value(row)),
	sortValue: (row) => value(row) ?? Number.NEGATIVE_INFINITY,
	...tooltip === void 0 ? {} : { tooltip: () => tooltip }
});
const PRICING_GRID_COLUMNS = [
	{
		key: "contractNumber",
		header: "Contract",
		sortable: true,
		width: 130,
		format: (row) => row.contractNumber
	},
	{
		key: "contractDate",
		header: "Date",
		sortable: true,
		width: 90,
		format: (row) => formatShortDate(row.contractDate),
		sortValue: (row) => row.contractDate ?? "",
		tooltip: (row) => formatContractDate(row.contractDate)
	},
	{
		key: "customerId",
		header: "Customer",
		sortable: true,
		width: 180,
		format: (row) => row.customerId ?? ""
	},
	{
		key: "commodity",
		header: "Commodity",
		sortable: true,
		width: 120,
		format: (row) => row.commodity ?? ""
	},
	{
		key: "priceTypeCode",
		header: "Type",
		sortable: true,
		width: 80,
		format: (row) => row.priceTypeCode ?? ""
	},
	quantityColumn("quantity", "Contract Qty", (row) => row.quantity, "The contract quantity CTRM holds, in the contract’s own unit."),
	quantityColumn("pricedQuantity", "Priced", pricedQuantity, "Contract quantity minus unpriced quantity. Derived here — CTRM does not return it on this route."),
	quantityColumn("unpricedQuantity", "Unpriced", (row) => row.unpricedQuantity, "What still needs a price. This is the figure the queue is built on."),
	quantityColumn("appliedQuantity", "Applied", (row) => row.appliedQuantity, "Quantity applied against shipments."),
	quantityColumn("openQuantity", "Open", (row) => row.openQuantity, "Quantity still open."),
	{
		key: "shipPeriodBegin",
		header: "Ship Period",
		sortable: true,
		width: 180,
		format: formatShipPeriod,
		sortValue: (row) => row.shipPeriodBegin ?? ""
	},
	{
		key: "marketZone",
		header: "Zone",
		sortable: true,
		width: 90,
		format: (row) => row.marketZone ?? ""
	},
	{
		key: "trader",
		header: "Trader",
		sortable: true,
		width: 140,
		format: (row) => row.trader ?? row.traderInitials ?? ""
	}
];
const DEFAULT_SORTS = [{
	key: "unpricedQuantity",
	direction: "desc"
}];
var PricingPageComponent = class PricingPageComponent {
	source = inject(CONTRACT_LIST_SOURCE);
	arrivedAfterSave = signal(inject(SaveAnnouncementStore).takeForOrigin("pricing"), ...ngDevMode ? [{ debugName: "arrivedAfterSave" }] : /* istanbul ignore next */ []);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	approvalsIntent = {
		kind: "module",
		module: "pricing-approvals"
	};
	approvalsHref = computed(() => this.hostContext.hrefFor(this.approvalsIntent), ...ngDevMode ? [{ debugName: "approvalsHref" }] : /* istanbul ignore next */ []);
	followApprovals(event) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(this.approvalsIntent);
	}
	columns = PRICING_GRID_COLUMNS;
	columnChoice = gridColumnChoice(PRICING_GRID_COLUMNS, "pricing.contracts", ["contractNumber"]);
	initial = fromRouteParams(this.route.snapshot.queryParamMap);
	sorts = signal(this.route.snapshot.queryParamMap.get("sort") === null ? DEFAULT_SORTS : this.initial.sorts, ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	defaultSorts = DEFAULT_SORTS;
	searchTerm = signal(this.initial.query.search ?? "", ...ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []);
	focusKey = signal(this.initial.focus, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	query = computed(() => {
		return {
			status: "Open",
			...this.tradeUnit.code() === null ? {} : { tradeUnit: this.tradeUnit.code() },
			sort: toSortParam(this.sorts()),
			page: 1,
			pageSize: MAX_PAGE_SIZE
		};
	}, ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	data = toSignal(toObservable(computed(() => ({
		query: this.query(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ query }) => listEveryPage(this.source, query))), { initialValue: remoteLoading() });
	containerState = computed(() => this.hasTradeUnit() ? this.data() : {
		status: "loaded",
		value: emptyPage(this.query())
	}, ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	result = computed(() => {
		const state = this.data();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "result" }] : /* istanbul ignore next */ []);
	fetched = computed(() => this.result()?.rows ?? [], ...ngDevMode ? [{ debugName: "fetched" }] : /* istanbul ignore next */ []);
	queue = computed(() => {
		const term = this.searchTerm();
		const filtered = this.fetched().filter((row) => needsPricing(row) && matchesGroup(row, this.columns, this.filter()) && matchesSearch(row, this.columns, term));
		const sorts = this.sorts();
		return sorts.length === 0 ? filtered : [...filtered].sort((left, right) => compareBySorts(this.columns, sorts, left, right));
	}, ...ngDevMode ? [{ debugName: "queue" }] : /* istanbul ignore next */ []);
	page = signal(this.initial.query.page, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	pageSize = DEFAULT_PAGE_SIZE;
	totalPages = computed(() => Math.max(1, Math.ceil(this.queue().length / this.pageSize)), ...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const start = (this.currentPage() - 1) * this.pageSize;
		return this.queue().slice(start, start + this.pageSize);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	currentPage = computed(() => Math.min(Math.max(this.page(), 1), this.totalPages()), ...ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []);
	rangeLabel = computed(() => {
		const total = this.queue().length;
		if (total === 0) return "";
		return `${(this.currentPage() - 1) * this.pageSize + 1}–${Math.min(this.currentPage() * this.pageSize, total)} of ${total}`;
	}, ...ngDevMode ? [{ debugName: "rangeLabel" }] : /* istanbul ignore next */ []);
	onPage(page) {
		this.page.set(page);
	}
	onPageStep(step) {
		this.page.set(Math.min(Math.max(this.currentPage() + step, 1), this.totalPages()));
	}
	isRefreshing = computed(() => this.data().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => this.result()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.result()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => ["Where pricing and approvals are done", ...this.showSystemNotices() ? [
		...this.isSimulated() ? ["Simulated rows, not read from CTRM"] : [],
		...this.rowCapMessage() ? ["CTRM may have sent fewer rows than exist"] : [],
		...this.warnings()
	] : []], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	showSystemNotices = computed(() => this.permissions.canSeeSystemNotices?.() ?? false, ...ngDevMode ? [{ debugName: "showSystemNotices" }] : /* istanbul ignore next */ []);
	rowCapMessage = computed(() => {
		const page = this.result();
		if (!page) return null;
		const verdict = listCompletenessNotice(page);
		if (verdict !== null || !this.shortRead()) return verdict;
		return `Only ${page.rows.length.toLocaleString("en-US")} of ${page.totalCount.toLocaleString("en-US")} open contracts were read; there may be more to price than is listed here.`;
	}, ...ngDevMode ? [{ debugName: "rowCapMessage" }] : /* istanbul ignore next */ []);
	shortRead = computed(() => {
		const page = this.result();
		return page !== null && page.rows.length < page.totalCount;
	}, ...ngDevMode ? [{ debugName: "shortRead" }] : /* istanbul ignore next */ []);
	hasTradeUnit = computed(() => {
		const code = this.tradeUnit.code();
		return code !== null && code !== "";
	}, ...ngDevMode ? [{ debugName: "hasTradeUnit" }] : /* istanbul ignore next */ []);
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportFilename = (scope) => {
		return `unpriced-${this.tradeUnit.code() ?? "all"}-${scope === "page" ? `page-${this.currentPage()}` : "all"}`;
	};
	exportAllRows = () => Promise.resolve(this.queue());
	emptyMessage = computed(() => this.hasTradeUnit() ? "Every open contract in this trade unit is fully priced." : "Choose a trade unit in the top bar to load unpriced contracts.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	moreThanOnePage = this.shortRead;
	totalOpen = computed(() => this.result()?.totalCount ?? 0, ...ngDevMode ? [{ debugName: "totalOpen" }] : /* istanbul ignore next */ []);
	trackByContract = (row) => row.contractNumber;
	onSortChange(sorts) {
		this.sorts.set(sorts);
	}
	filter = signal(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	savedFilterScope = SAVED_FILTER_SCOPES.pricing;
	onRulesChange(group) {
		this.filter.set(group);
		this.page.set(1);
	}
	onViewChange(view) {
		this.filter.set(view.group);
		this.columnChoice.applyView(view.columns);
		this.sorts.set(view.sort);
		this.page.set(1);
	}
	onSearch(term) {
		this.searchTerm.set(term);
		this.page.set(1);
	}
	refresh() {
		this.attempt.update((value) => value + 1);
	}
	retry() {
		this.refresh();
	}
	onRowActivate(row) {
		const params = toRouteParams(this.query(), this.sorts(), row.contractNumber);
		const search = this.searchTerm().trim();
		const returnTo = new URLSearchParams({
			...params,
			...search === "" ? {} : { search },
			...this.currentPage() > 1 ? { page: String(this.currentPage()) } : {}
		}).toString();
		const keys = this.queue().map((each) => each.contractNumber);
		const journey = this.journeys.begin(startRecordJourney({
			origin: "pricing",
			kind: "pricing",
			label: "Pricing",
			keys,
			index: Math.max(0, keys.indexOf(row.contractNumber))
		}));
		this.hostContext.navigate({
			kind: "review",
			origin: "pricing",
			contractNumber: row.contractNumber,
			params: {
				returnTo,
				[RECORD_ORIGIN_PARAM]: "pricing"
			},
			state: recordJourneyState(journey)
		});
	}
	journeys = inject(RecordJourneyStore);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PricingPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PricingPageComponent,
		isStandalone: true,
		selector: "cms-pricing-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Pricing\"\n    description=\"Open contracts with quantity still to price, most outstanding first.\"\n  >\n    <!--\n      🔴 A LINK in the header actions, not a fifth module in the shell nav.\n      Approving price sequences is something you do having read this queue, not a separate place in\n      the application — and the nav is the four modules of docs/02 §1.1, which this is not one of.\n    -->\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /pricing/approvals escapes. -->\n    <a\n      cmsPageHeaderActions\n      [attr.href]=\"approvalsHref()\"\n      (click)=\"followApprovals($event)\"\n      class=\"scoular-btn scoular-btn-secondary\"\n    >\n      Pricing approvals\n    </a>\n  </cms-page-header>\n\n  <!-- #888: the save a Save-and-close from a record opened here came back with, said once. -->\n  <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\n\n  <!--\n    ⚠ **This block used to say price entry was impossible from this application**, citing two\n    blockers: that `prices` is not writable on `upsertContract`, and that the API published no pricing\n    route. The first is still true and is why a contract cannot be created *with* its prices. The\n    second stopped being true when `PricingEndpoints` shipped, and nothing re-pointed the sentence —\n    so this queue told users to go to the green screen while the editor it links to was live.\n\n    The rule that missed it is the one this repository keeps re-learning: a statement on screen is not\n    re-checked by the change that falsifies it unless something asserts it. There is a test for this\n    wording now.\n  -->\n  <!--\n    Standing notices, in the shared collapsible panel — the same one the workspace and the approval\n    queue use (JFrisbie, 2026-09-14). This screen opened with a capability warning, a simulated-data\n    banner and one row per server warning, ahead of the queue itself.\n  -->\n  <cms-notices-panel [summaries]=\"noticeSummaries()\" [systemNotices]=\"showSystemNotices()\">\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n      <div class=\"scoular-alert-title\">Where pricing is done</div>\n      <div class=\"scoular-alert-description\">\n        Opening a row shows that contract's price sequences, where they can be added, changed and\n        removed. Approving them is on Pricing approvals, linked above. A contract cannot be created\n        with its prices already on it — CTRM does not accept them on a contract write — so prices are\n        always entered after the contract exists.\n      </div>\n    </div>\n\n    <!-- #1223: the system caveats below are the Admin role's only. -->\n    @if (showSystemNotices()) {\n      @if (isSimulated()) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">Simulated data</div>\n          <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\n        </div>\n      }\n\n      @if (rowCapMessage(); as message) {\n        <!-- #662: CTRM truncates the list silently; shown only on the server's explicit true. -->\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">This list may be incomplete</div>\n          <div class=\"scoular-alert-description\">{{ message }}</div>\n        </div>\n      }\n\n      @for (warning of warnings(); track warning) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-description\">{{ warning }}</div>\n        </div>\n      }\n    }\n  </cms-notices-panel>\n\n  <!--\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto` — the same\n    order and the same split as the workspace grid and the approvals queue, so the controls do not\n    move between screens (JFrisbie, 2026-09-10).\n  -->\n  <!--\n    🔴 **The width goes on the LABEL, never on the field.** `.scoular-form-input` is `@apply w-full`\n    and the design system compiles unlayered, so a `w-32` on the input silently loses to it and the\n    field fills its wrapper — every filter here measured **193px** regardless of its class, which is\n    what pushed the refresh/pager block onto a second line at 1280px. Seventh instance of this trap;\n    the remedy is to put the declaration on the wrapper, which has no design-system class to fight.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <cms-grid-toolbar>\n    <!--\n      One search box, replacing four per-field boxes plus a server-side search (JFrisbie,\n      2026-09-10).\n\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so\n      Customer, Commodity, Trader and Price type are all still reachable, along with the four\n      columns the old boxes could not narrow on.\n\n      ⚠ **Applied CLIENT-SIDE and no longer sent as a request parameter.** The server matches\n      three fields where this box matches all eight, so sending it too would narrow the fetched\n      set by a different rule than the one on screen. It costs nothing: the API fetches the whole\n      status set for the trade unit either way — `ContractListProjector` filters in process —\n      which is also why this screen already asks for the largest page it can.\n\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\n      move as a user goes between the two screens.\n    -->\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        autocomplete=\"off\"\n        placeholder=\"Search every column\"\n        [value]=\"searchTerm()\"\n        (input)=\"onSearch($any($event.target).value)\"\n      />\n    </label>\n\n    <!--\n      Saved views and the rule builder, the same pair the workspace and the approvals queue carry.\n      Its OWN scope: a view from another grid would carry rules against columns this one does not\n      render and match nothing, which here reads as \"nothing to price\".\n\n      The width is on the wrapper, never the control - .scoular-form-input is @apply w-full and the\n      design system compiles unlayered, so a w-* on the control itself would lose.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [columnLayout]=\"columnChoice.layout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\n      (click)=\"builder.beginAdd()\"\n    >\n      + Add filter\n    </button>\n\n    <!--\n      Clear sort, hidden until the queue is sorted some other way -- see the approval queue's own\n      note. This screen arrives largest-outstanding-first, so that ordering is the screen's doing\n      rather than the user's, and returning to it is what \"clear\" has to mean here.\n    -->\n    <cms-clear-sort-button\n      [sorts]=\"sorts()\"\n      [defaultSorts]=\"defaultSorts\"\n      (clear)=\"onSortChange($event)\"\n    />\n\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\n      <!-- Columns, beside the export it shapes, where Home has it (JFrisbie, 2026-10-23). -->\n      <cms-grid-column-menu\n        [fields]=\"columnChoice.fields()\"\n        [lockedKeys]=\"columnChoice.locked()\"\n        [keptIn]=\"columnChoice.keptIn()\"\n        [failure]=\"columnChoice.failure()\"\n        resetLabel=\"Show every column\"\n        (fieldsChange)=\"columnChoice.change($event)\"\n        (reset)=\"columnChoice.reset()\"\n      />\n      <!--\n        Export, the same shared control the workspace and the approval queue carry. Both scopes are\n        cheap here - this screen fetches one large page and narrows in the browser - and the choice\n        is still offered, because \"what I am looking at\" and \"everything the filter matched\" are\n        different files on a paged grid. See `cms-grid-export`.\n      -->\n      <cms-grid-export\n        [columns]=\"columns\"\n        [visibleKeys]=\"columnChoice.shownKeys()\"\n        [pageRows]=\"rows()\"\n        [totalCount]=\"queue().length\"\n        [allRows]=\"exportAllRows\"\n        [filename]=\"exportFilename\"\n        [disabled]=\"!hasTradeUnit() || queue().length === 0\"\n        (failed)=\"exportError.set($event)\"\n      />\n\n      <cms-refresh-button\n        label=\"Refresh the unpriced queue\"\n        [busy]=\"isRefreshing()\"\n        [disabled]=\"!hasTradeUnit()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <cms-pager\n        [page]=\"currentPage()\"\n        [totalPages]=\"totalPages()\"\n        position=\"top\"\n        (goTo)=\"onPage($event)\"\n      />\n    </div>\n  </cms-grid-toolbar>\n\n  <!--\n    Chips and the rule editor. Renders nothing when there are no rules and the editor is closed, so\n    it leaves no empty band above the queue. Its own add button is suppressed because the toolbar\n    carries one - one owner for the editor state.\n  -->\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onRulesChange($event)\"\n  />\n\n  <!--\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\n    failed export is the outcome of something the user just did.\n  -->\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\n\n    This screen used to render a `scoular-card` above the container and hide the container behind\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\n    read as a notice about the data rather than as the absence of any.\n\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\n    unit the request is certain to 422, which is why the screen never issues one.\n  -->\n  <cms-async-container\n    [data]=\"containerState()\"\n    [empty]=\"!hasTradeUnit() || queue().length === 0\"\n    [emptyMessage]=\"emptyMessage()\"\n      loadingLabel=\"Loading unpriced contracts\"\n      (retry)=\"retry()\"\n    >\n      <!--\n        ⚠ **`striped` is safe here because this queue declares no `rowTone`** — the same condition the\n        approvals queue records. A stripe and a semantic tint are both a background on the `<tr>`, and\n        together the tint stops meaning anything. The grid enforces the precedence rather than\n        trusting this binding, but adding a tone to this queue later would make the stripe the wrong\n        call rather than merely a redundant one.\n      -->\n      <cms-data-grid\n        [rows]=\"rows()\"\n        [columns]=\"columnChoice.shown()\"\n        label=\"Contracts with quantity to price\"\n        [columnMenu]=\"false\"\n        [striped]=\"true\"\n        [sorts]=\"sorts()\"\n        [trackBy]=\"trackByContract\"\n        [focusKey]=\"focusKey()\"\n        (sortChange)=\"onSortChange($event)\"\n        activateLabel=\"Open\"\n        (rowActivate)=\"onRowActivate($event)\"\n        (pageStep)=\"onPageStep($event)\"\n      />\n\n      <!--\n        The footer, matching the workspace grid: record count left, pager right.\n\n        🔴 The count is over the QUEUE, not over what the server sent — `1–50 of 87` means 87\n        contracts need pricing, which is what the screen is about. The second line keeps the\n        client-side filter honest: it names how many open contracts were read to find them, and warns\n        when the server had more pages than it sent, because the filter cannot see past those.\n      -->\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          <p>{{ rangeLabel() }}</p>\n          <p class=\"cws:mt-0.5 cws:text-xs\">\n            Found in {{ fetched().length }} open contracts read.\n            @if (moreThanOnePage()) {\n              <span class=\"cws:text-amber-700 cws:dark:text-amber-400\">\n                This trade unit has {{ totalOpen() }} open contracts and not every page could be\n                read — there may be more to price than is listed here.\n              </span>\n            }\n          </p>\n        </div>\n\n        <cms-pager\n          [page]=\"currentPage()\"\n          [totalPages]=\"totalPages()\"\n          position=\"bottom\"\n          (goTo)=\"onPage($event)\"\n        />\n      </footer>\n  </cms-async-container>\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel",
					"columnLayout"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"columnMenu",
					"columnsKey",
					"lockedColumns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"rowLabel",
					"activateLabel",
					"selectable",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep",
					"rowToggle",
					"selectAll"
				]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridColumnMenuComponent,
				selector: "cms-grid-column-menu",
				inputs: [
					"fields",
					"lockedKeys",
					"keptIn",
					"failure",
					"disabled",
					"resetLabel"
				],
				outputs: ["fieldsChange", "reset"]
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"visibleKeys",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"systemNotices",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PricingPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pricing-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FilterBuilderComponent,
				FilterSelectComponent,
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				SearchShortcutDirective,
				GridColumnMenuComponent,
				GridExportComponent,
				GridToolbarComponent,
				NoticesPanelComponent,
				StatusMessageComponent,
				PagerComponent,
				RefreshButtonComponent,
				PageHeaderComponent
			],
			template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Pricing\"\n    description=\"Open contracts with quantity still to price, most outstanding first.\"\n  >\n    <!--\n      🔴 A LINK in the header actions, not a fifth module in the shell nav.\n      Approving price sequences is something you do having read this queue, not a separate place in\n      the application — and the nav is the four modules of docs/02 §1.1, which this is not one of.\n    -->\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /pricing/approvals escapes. -->\n    <a\n      cmsPageHeaderActions\n      [attr.href]=\"approvalsHref()\"\n      (click)=\"followApprovals($event)\"\n      class=\"scoular-btn scoular-btn-secondary\"\n    >\n      Pricing approvals\n    </a>\n  </cms-page-header>\n\n  <!-- #888: the save a Save-and-close from a record opened here came back with, said once. -->\n  <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\n\n  <!--\n    ⚠ **This block used to say price entry was impossible from this application**, citing two\n    blockers: that `prices` is not writable on `upsertContract`, and that the API published no pricing\n    route. The first is still true and is why a contract cannot be created *with* its prices. The\n    second stopped being true when `PricingEndpoints` shipped, and nothing re-pointed the sentence —\n    so this queue told users to go to the green screen while the editor it links to was live.\n\n    The rule that missed it is the one this repository keeps re-learning: a statement on screen is not\n    re-checked by the change that falsifies it unless something asserts it. There is a test for this\n    wording now.\n  -->\n  <!--\n    Standing notices, in the shared collapsible panel — the same one the workspace and the approval\n    queue use (JFrisbie, 2026-09-14). This screen opened with a capability warning, a simulated-data\n    banner and one row per server warning, ahead of the queue itself.\n  -->\n  <cms-notices-panel [summaries]=\"noticeSummaries()\" [systemNotices]=\"showSystemNotices()\">\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n      <div class=\"scoular-alert-title\">Where pricing is done</div>\n      <div class=\"scoular-alert-description\">\n        Opening a row shows that contract's price sequences, where they can be added, changed and\n        removed. Approving them is on Pricing approvals, linked above. A contract cannot be created\n        with its prices already on it — CTRM does not accept them on a contract write — so prices are\n        always entered after the contract exists.\n      </div>\n    </div>\n\n    <!-- #1223: the system caveats below are the Admin role's only. -->\n    @if (showSystemNotices()) {\n      @if (isSimulated()) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">Simulated data</div>\n          <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\n        </div>\n      }\n\n      @if (rowCapMessage(); as message) {\n        <!-- #662: CTRM truncates the list silently; shown only on the server's explicit true. -->\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">This list may be incomplete</div>\n          <div class=\"scoular-alert-description\">{{ message }}</div>\n        </div>\n      }\n\n      @for (warning of warnings(); track warning) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-description\">{{ warning }}</div>\n        </div>\n      }\n    }\n  </cms-notices-panel>\n\n  <!--\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto` — the same\n    order and the same split as the workspace grid and the approvals queue, so the controls do not\n    move between screens (JFrisbie, 2026-09-10).\n  -->\n  <!--\n    🔴 **The width goes on the LABEL, never on the field.** `.scoular-form-input` is `@apply w-full`\n    and the design system compiles unlayered, so a `w-32` on the input silently loses to it and the\n    field fills its wrapper — every filter here measured **193px** regardless of its class, which is\n    what pushed the refresh/pager block onto a second line at 1280px. Seventh instance of this trap;\n    the remedy is to put the declaration on the wrapper, which has no design-system class to fight.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <cms-grid-toolbar>\n    <!--\n      One search box, replacing four per-field boxes plus a server-side search (JFrisbie,\n      2026-09-10).\n\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so\n      Customer, Commodity, Trader and Price type are all still reachable, along with the four\n      columns the old boxes could not narrow on.\n\n      ⚠ **Applied CLIENT-SIDE and no longer sent as a request parameter.** The server matches\n      three fields where this box matches all eight, so sending it too would narrow the fetched\n      set by a different rule than the one on screen. It costs nothing: the API fetches the whole\n      status set for the trade unit either way — `ContractListProjector` filters in process —\n      which is also why this screen already asks for the largest page it can.\n\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\n      move as a user goes between the two screens.\n    -->\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        autocomplete=\"off\"\n        placeholder=\"Search every column\"\n        [value]=\"searchTerm()\"\n        (input)=\"onSearch($any($event.target).value)\"\n      />\n    </label>\n\n    <!--\n      Saved views and the rule builder, the same pair the workspace and the approvals queue carry.\n      Its OWN scope: a view from another grid would carry rules against columns this one does not\n      render and match nothing, which here reads as \"nothing to price\".\n\n      The width is on the wrapper, never the control - .scoular-form-input is @apply w-full and the\n      design system compiles unlayered, so a w-* on the control itself would lose.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [columnLayout]=\"columnChoice.layout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\n      (click)=\"builder.beginAdd()\"\n    >\n      + Add filter\n    </button>\n\n    <!--\n      Clear sort, hidden until the queue is sorted some other way -- see the approval queue's own\n      note. This screen arrives largest-outstanding-first, so that ordering is the screen's doing\n      rather than the user's, and returning to it is what \"clear\" has to mean here.\n    -->\n    <cms-clear-sort-button\n      [sorts]=\"sorts()\"\n      [defaultSorts]=\"defaultSorts\"\n      (clear)=\"onSortChange($event)\"\n    />\n\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\n      <!-- Columns, beside the export it shapes, where Home has it (JFrisbie, 2026-10-23). -->\n      <cms-grid-column-menu\n        [fields]=\"columnChoice.fields()\"\n        [lockedKeys]=\"columnChoice.locked()\"\n        [keptIn]=\"columnChoice.keptIn()\"\n        [failure]=\"columnChoice.failure()\"\n        resetLabel=\"Show every column\"\n        (fieldsChange)=\"columnChoice.change($event)\"\n        (reset)=\"columnChoice.reset()\"\n      />\n      <!--\n        Export, the same shared control the workspace and the approval queue carry. Both scopes are\n        cheap here - this screen fetches one large page and narrows in the browser - and the choice\n        is still offered, because \"what I am looking at\" and \"everything the filter matched\" are\n        different files on a paged grid. See `cms-grid-export`.\n      -->\n      <cms-grid-export\n        [columns]=\"columns\"\n        [visibleKeys]=\"columnChoice.shownKeys()\"\n        [pageRows]=\"rows()\"\n        [totalCount]=\"queue().length\"\n        [allRows]=\"exportAllRows\"\n        [filename]=\"exportFilename\"\n        [disabled]=\"!hasTradeUnit() || queue().length === 0\"\n        (failed)=\"exportError.set($event)\"\n      />\n\n      <cms-refresh-button\n        label=\"Refresh the unpriced queue\"\n        [busy]=\"isRefreshing()\"\n        [disabled]=\"!hasTradeUnit()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <cms-pager\n        [page]=\"currentPage()\"\n        [totalPages]=\"totalPages()\"\n        position=\"top\"\n        (goTo)=\"onPage($event)\"\n      />\n    </div>\n  </cms-grid-toolbar>\n\n  <!--\n    Chips and the rule editor. Renders nothing when there are no rules and the editor is closed, so\n    it leaves no empty band above the queue. Its own add button is suppressed because the toolbar\n    carries one - one owner for the editor state.\n  -->\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onRulesChange($event)\"\n  />\n\n  <!--\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\n    failed export is the outcome of something the user just did.\n  -->\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\n\n    This screen used to render a `scoular-card` above the container and hide the container behind\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\n    read as a notice about the data rather than as the absence of any.\n\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\n    unit the request is certain to 422, which is why the screen never issues one.\n  -->\n  <cms-async-container\n    [data]=\"containerState()\"\n    [empty]=\"!hasTradeUnit() || queue().length === 0\"\n    [emptyMessage]=\"emptyMessage()\"\n      loadingLabel=\"Loading unpriced contracts\"\n      (retry)=\"retry()\"\n    >\n      <!--\n        ⚠ **`striped` is safe here because this queue declares no `rowTone`** — the same condition the\n        approvals queue records. A stripe and a semantic tint are both a background on the `<tr>`, and\n        together the tint stops meaning anything. The grid enforces the precedence rather than\n        trusting this binding, but adding a tone to this queue later would make the stripe the wrong\n        call rather than merely a redundant one.\n      -->\n      <cms-data-grid\n        [rows]=\"rows()\"\n        [columns]=\"columnChoice.shown()\"\n        label=\"Contracts with quantity to price\"\n        [columnMenu]=\"false\"\n        [striped]=\"true\"\n        [sorts]=\"sorts()\"\n        [trackBy]=\"trackByContract\"\n        [focusKey]=\"focusKey()\"\n        (sortChange)=\"onSortChange($event)\"\n        activateLabel=\"Open\"\n        (rowActivate)=\"onRowActivate($event)\"\n        (pageStep)=\"onPageStep($event)\"\n      />\n\n      <!--\n        The footer, matching the workspace grid: record count left, pager right.\n\n        🔴 The count is over the QUEUE, not over what the server sent — `1–50 of 87` means 87\n        contracts need pricing, which is what the screen is about. The second line keeps the\n        client-side filter honest: it names how many open contracts were read to find them, and warns\n        when the server had more pages than it sent, because the filter cannot see past those.\n      -->\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          <p>{{ rangeLabel() }}</p>\n          <p class=\"cws:mt-0.5 cws:text-xs\">\n            Found in {{ fetched().length }} open contracts read.\n            @if (moreThanOnePage()) {\n              <span class=\"cws:text-amber-700 cws:dark:text-amber-400\">\n                This trade unit has {{ totalOpen() }} open contracts and not every page could be\n                read — there may be more to price than is listed here.\n              </span>\n            }\n          </p>\n        </div>\n\n        <cms-pager\n          [page]=\"currentPage()\"\n          [totalPages]=\"totalPages()\"\n          position=\"bottom\"\n          (goTo)=\"onPage($event)\"\n        />\n      </footer>\n  </cms-async-container>\n</section>\n"
		}]
	}]
});
function emptyPage(query) {
	return {
		rows: [],
		totalCount: 0,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: 1,
		dataOrigin: "Simulated",
		filteredInProcess: false,
		rowCapReached: null,
		rowCap: null,
		warnings: []
	};
}
function formatPrice$1(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", {
		minimumFractionDigits: 4,
		maximumFractionDigits: 5
	});
}
function formatAmount$1(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
}
const PRICE_SEQUENCE_COLUMNS = [
	{
		key: "priceSequence",
		header: "Seq",
		format: (row) => String(row.priceSequence),
		sortValue: (row) => row.priceSequence
	},
	{
		key: "pricedQuantity",
		header: "Priced qty",
		format: (row) => formatAmount$1(row.pricedQuantity),
		sortValue: (row) => row.pricedQuantity
	},
	{
		key: "openQuantity",
		header: "Open qty",
		format: (row) => formatAmount$1(row.openQuantity),
		sortValue: (row) => row.openQuantity
	},
	{
		key: "appliedQuantity",
		header: "Applied qty",
		format: (row) => formatAmount$1(row.appliedQuantity),
		sortValue: (row) => row.appliedQuantity
	},
	{
		key: "unsettledQuantity",
		header: "Unsettled qty",
		format: (row) => formatAmount$1(row.unsettledQuantity),
		sortValue: (row) => row.unsettledQuantity
	},
	{
		key: "settledQuantity",
		header: "Settled qty",
		format: (row) => formatAmount$1(row.settledQuantity),
		sortValue: (row) => row.settledQuantity
	},
	{
		key: "pricedLoads",
		header: "Priced loads",
		format: (row) => String(row.pricedLoads),
		sortValue: (row) => row.pricedLoads
	},
	{
		key: "appliedLoads",
		header: "Applied loads",
		format: (row) => String(row.appliedLoads),
		sortValue: (row) => row.appliedLoads
	},
	{
		key: "settledLoads",
		header: "Settled loads",
		format: (row) => String(row.settledLoads),
		sortValue: (row) => row.settledLoads
	},
	{
		key: "price",
		header: "Flat price",
		format: (row) => formatPrice$1(row.price),
		sortValue: (row) => row.price
	},
	{
		key: "basisPrice",
		header: "Basis",
		format: (row) => formatPrice$1(row.basisPrice),
		sortValue: (row) => row.basisPrice
	},
	{
		key: "hedgePrice",
		header: "Futures",
		format: (row) => formatPrice$1(row.hedgePrice),
		sortValue: (row) => row.hedgePrice
	},
	{
		key: "hedgeMarketCode",
		header: "Market",
		format: (row) => row.hedgeMarketCode ? row.hedgeMarketCodeDescription ? `${row.hedgeMarketCode} — ${row.hedgeMarketCodeDescription}` : row.hedgeMarketCode : ""
	},
	{
		key: "hedgeMarketMonth",
		header: "Month",
		format: (row) => row.hedgeMarketMonth ?? ""
	},
	{
		key: "priceDate",
		header: "Price date",
		format: (row) => formatShortDate(row.priceDate),
		sortValue: (row) => row.priceDate ?? ""
	},
	{
		key: "traderInitials",
		header: "Trader",
		format: (row) => row.traderInitials ?? ""
	},
	{
		key: "approval",
		header: "Approval",
		format: (row) => row.isApproved ? row.approverInitials ? `Approved — ${row.approverInitials}` : "Approved" : "Pending",
		sortValue: (row) => row.isApproved ? 1 : 0
	},
	{
		key: "remark",
		header: "Remark",
		format: (row) => row.remark ?? ""
	}
];
var PricingArrivals = class PricingArrivals {
	pending = null;
	leave(contractNumber, priceSequence, arrival) {
		this.pending = {
			key: keyOf(contractNumber, priceSequence),
			arrival
		};
	}
	take(contractNumber, priceSequence) {
		const pending = this.pending;
		if (pending === null || pending.key !== keyOf(contractNumber, priceSequence)) return null;
		this.pending = null;
		return pending.arrival;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PricingArrivals,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PricingArrivals,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PricingArrivals,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const keyOf = (contractNumber, priceSequence) => `${contractNumber.trim()}#${priceSequence ?? "-"}`;
const PRICING_PARENT_JOURNEY = "cwsPricingParentJourney";
function withParentJourney(state, parent) {
	if (parent === void 0 || parent === null) return state;
	return {
		...state ?? {},
		[PRICING_PARENT_JOURNEY]: parent
	};
}
function parentJourneyState(parent) {
	return parent === void 0 || parent === null ? void 0 : { [RECORD_JOURNEY_STATE]: parent };
}
var PricingDetailPageComponent = class PricingDetailPageComponent {
	source = inject(PRICING_SOURCE);
	contractDetail = inject(CONTRACT_DETAIL_SOURCE);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	returnTo = this.route.snapshot.queryParamMap.get("returnTo");
	returnParams = computed(() => returnParamsAt(this.returnTo, this.contractNumber(), this.journey.position()), ...ngDevMode ? [{ debugName: "returnParams" }] : /* istanbul ignore next */ []);
	origin = computed(() => recordOrigin(this.originKey(), "pricing"), ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	originKey = computed(() => recordOriginKey(this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM), "pricing"), ...ngDevMode ? [{ debugName: "originKey" }] : /* istanbul ignore next */ []);
	originIntent = computed(() => ({
		kind: "origin",
		origin: this.originKey(),
		params: this.returnParams()
	}), ...ngDevMode ? [{ debugName: "originIntent" }] : /* istanbul ignore next */ []);
	recordIntent = computed(() => ({
		kind: "contract",
		contractNumber: this.contractNumber(),
		params: this.recordLinkParams()
	}), ...ngDevMode ? [{ debugName: "recordIntent" }] : /* istanbul ignore next */ []);
	recordHref = computed(() => this.hostContext.hrefFor(this.recordIntent()), ...ngDevMode ? [{ debugName: "recordHref" }] : /* istanbul ignore next */ []);
	follow(event, intent) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(intent);
	}
	followRecord(event) {
		this.follow(event, this.recordIntent());
	}
	crumbs = computed(() => {
		const intent = this.originIntent();
		return [{
			label: this.origin().label,
			path: this.origin().path,
			link: {
				href: this.hostContext.hrefFor(intent),
				follow: (event) => this.follow(event, intent)
			}
		}];
	}, ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	tradeUnitLabel = injectTradeUnitLabel();
	recordLinkParams = computed(() => ({
		[RECORD_ORIGIN_PARAM]: "pricing",
		...this.returnTo === null ? {} : { returnTo: this.returnTo }
	}), ...ngDevMode ? [{ debugName: "recordLinkParams" }] : /* istanbul ignore next */ []);
	onEscape(event) {
		if (event.defaultPrevented) return;
		this.hostContext.navigate(this.originIntent());
	}
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	columns = PRICE_SEQUENCE_COLUMNS;
	sorts = signal([], ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	reload = signal(0, ...ngDevMode ? [{ debugName: "reload" }] : /* istanbul ignore next */ []);
	loaded = toSignal(toObservable(computed(() => ({
		contract: this.contractNumber(),
		nonce: this.reload()
	}))).pipe(switchMap(({ contract }) => this.source.contractPrices(contract))), { initialValue: remoteLoading() });
	state = computed(() => this.loaded(), ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	openCheck = toSignal(toObservable(computed(() => ({
		contract: this.contractNumber(),
		nonce: this.reload()
	}))).pipe(switchMap(({ contract }) => this.contractDetail.get(contract))), { initialValue: remoteLoading() });
	openOutcome = computed(() => unpricedOpenOutcomeOf(this.openCheck()), ...ngDevMode ? [{ debugName: "openOutcome" }] : /* istanbul ignore next */ []);
	addHeld = computed(() => this.openOutcome()?.holdsAdd ?? null, ...ngDevMode ? [{ debugName: "addHeld" }] : /* istanbul ignore next */ []);
	afterWrite = signal(null, ...ngDevMode ? [{ debugName: "afterWrite" }] : /* istanbul ignore next */ []);
	unverified = signal(null, ...ngDevMode ? [{ debugName: "unverified" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	writeFormErrors = signal([], ...ngDevMode ? [{ debugName: "writeFormErrors" }] : /* istanbul ignore next */ []);
	deleteNotApplied = signal(null, ...ngDevMode ? [{ debugName: "deleteNotApplied" }] : /* istanbul ignore next */ []);
	lastAcknowledgement = signal(null, ...ngDevMode ? [{ debugName: "lastAcknowledgement" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	canEditPricing = computed(() => this.permissions.canEditPricing(), ...ngDevMode ? [{ debugName: "canEditPricing" }] : /* istanbul ignore next */ []);
	writeRefusal = computed(() => this.permissions.writeRefusal?.()?.message ?? null, ...ngDevMode ? [{ debugName: "writeRefusal" }] : /* istanbul ignore next */ []);
	sequenceLabel = (row) => `sequence ${row.priceSequence}`;
	rowActions = computed(() => {
		if (!this.canEditPricing()) return [];
		return [{
			label: "Edit",
			tone: "outline",
			run: (row) => this.openSequence(row, "edit"),
			disabled: () => this.writeRefusal() ?? (this.busy() ? "A pricing write is in flight" : false)
		}, {
			label: "Delete",
			tone: "secondary",
			run: (row) => this.askDelete(row),
			disabled: () => this.writeRefusal() ?? (this.busy() ? "A pricing write is in flight" : false)
		}];
	}, ...ngDevMode ? [{ debugName: "rowActions" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const written = this.afterWrite();
		if (written !== null) return this.sortRows(written);
		const state = this.state();
		return state.status === "loaded" ? this.sortRows(state.value.prices) : [];
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	sortRows(rows) {
		const chain = this.sorts();
		return chain.length === 0 ? rows : [...rows].sort((left, right) => compareBySorts(this.columns, chain, left, right));
	}
	journey = injectRecordJourney({
		kind: "pricing",
		key: () => this.contractNumber(),
		held: () => this.busy(),
		open: (contractNumber, state) => this.hostContext.navigate({
			kind: "review",
			origin: "pricing",
			contractNumber,
			params: this.passedParams(),
			state
		})
	});
	fromParam = this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM);
	passedParams = computed(() => ({
		...this.fromParam === null ? {} : { [RECORD_ORIGIN_PARAM]: this.fromParam },
		...this.returnTo === null ? {} : { returnTo: this.returnTo }
	}), ...ngDevMode ? [{ debugName: "passedParams" }] : /* istanbul ignore next */ []);
	lastContract = null;
	arrivals = inject(PricingArrivals);
	resetForContract = effect(() => {
		const contractNumber = this.contractNumber();
		untracked(() => {
			if (this.lastContract !== null && this.lastContract !== contractNumber) {
				this.afterWrite.set(null);
				this.unverified.set(null);
				this.outcome.set(null);
				this.writeFormErrors.set([]);
				this.deleteNotApplied.set(null);
				this.lastAcknowledgement.set(null);
			}
			this.lastContract = contractNumber;
			const arrival = this.arrivals.take(contractNumber, null);
			if (arrival !== null) {
				if (arrival.prices !== null) this.afterWrite.set(arrival.prices);
				this.outcome.set(arrival.outcome);
				this.unverified.set(arrival.unverified);
				this.lastAcknowledgement.set(arrival.acknowledgement);
			}
		});
	}, ...ngDevMode ? [{ debugName: "resetForContract" }] : /* istanbul ignore next */ []);
	onRowActivate(row) {
		const keys = this.rows().map((each) => String(each.priceSequence));
		const journey = startRecordJourney({
			origin: "pricing",
			kind: "price-sequence",
			label: "Price sequences",
			keys,
			index: Math.max(0, keys.indexOf(String(row.priceSequence)))
		});
		this.openSequence(row, "view", recordJourneyState(journey));
	}
	openSequence(row, mode, state) {
		const carried = withParentJourney(state, this.journey.state()?.[RECORD_JOURNEY_STATE]);
		this.hostContext.navigate({
			kind: "price-sequence",
			contractNumber: this.contractNumber(),
			priceSequence: row === null ? null : row.priceSequence,
			mode,
			params: this.passedParams(),
			...carried === void 0 ? {} : { state: carried }
		});
	}
	addSequence() {
		if (this.addHeld() !== null || this.busy()) return;
		this.openSequence(null, "edit");
	}
	confirm = injectConfirm();
	askDelete(row) {
		if (this.busy()) return;
		this.clearMessages();
		this.confirm({
			title: `Remove price sequence ${row.priceSequence}?`,
			message: "This removes the sequence from CTRM. The list will be re-read afterwards, because a pricing delete cannot report its own outcome.",
			confirmLabel: "Remove sequence",
			cancelLabel: "Keep it",
			destructive: true
		}).subscribe((confirmed) => {
			if (confirmed) this.removeSequence(row);
		});
	}
	removeSequence(row) {
		if (this.busy()) return;
		const removed = row.priceSequence;
		this.run(this.source.remove(this.contractNumber(), removed), `Price sequence ${removed} removed.`, () => void 0, (written) => written.verified && written.prices.some((price) => price.priceSequence === removed) ? `CTRM accepted the request, but price sequence ${removed} is still listed when the prices are read back, so it was not removed. Refresh to check, then try again.` : null);
	}
	run(write, success, onAccepted, notApplied = () => null) {
		this.busy.set(true);
		this.clearMessages();
		write.subscribe((result) => {
			if (result.status === "loading") return;
			this.busy.set(false);
			if (result.status !== "loaded") {
				this.outcome.set(mutationFailed(result.status === "error" ? {
					message: `That change was not saved. ${result.error.message}`,
					correlationId: result.error.correlationId
				} : { message: "That change was not saved. It did not complete." }));
				this.writeFormErrors.set(result.status === "error" ? result.error.formErrors ?? [] : []);
				return;
			}
			onAccepted();
			this.afterWrite.set(result.value.prices);
			const reason = notApplied(result.value);
			if (reason !== null) {
				this.deleteNotApplied.set(reason);
				return;
			}
			if (result.value.verified) {
				this.outcome.set(mutationSucceeded(`${success} CTRM said: ${result.value.acknowledgement}`));
				return;
			}
			this.lastAcknowledgement.set(result.value.acknowledgement);
			this.unverified.set("CTRM accepted the change but we could not read the prices back, so the list below may be out of date. Refresh to confirm.");
		});
	}
	refresh() {
		this.clearMessages();
		this.afterWrite.set(null);
		this.reload.update((value) => value + 1);
	}
	clearMessages() {
		this.outcome.set(null);
		this.writeFormErrors.set([]);
		this.unverified.set(null);
		this.deleteNotApplied.set(null);
		this.lastAcknowledgement.set(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PricingDetailPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PricingDetailPageComponent,
		isStandalone: true,
		selector: "cms-pricing-detail-page",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: { "document:keydown.escape": "onEscape($event)" } },
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    [title]=\"'Price sequences — ' + contractNumber()\"\n    description=\"Flat price is basis plus adjustments plus futures. CTRM computes the stored price itself.\"\n  >\n    <!--\n      🔴 The shared trail, replacing a lookalike that was not a breadcrumb.\n\n      This was an anchor, a `<span>/</span>` and a second `<span>` — visually a trail, and to a screen\n      reader three unrelated pieces of text: no list, no `aria-current`, and a `/` separator where the\n      other two detail screens use `&rsaquo;`. So the one control a user meets on every detail screen\n      changed shape depending which screen they were on.\n\n      `returnParams()` carries the queue's packed state, so the crumb returns the user to the row they\n      opened rather than to a reset queue — the same journey the approvals review screen keeps.\n    -->\n    <cms-breadcrumb\n      cmsPageHeaderBreadcrumb\n      [crumbs]=\"crumbs()\"\n      [current]=\"contractNumber()\"\n      [context]=\"tradeUnitLabel()\"\n      [queryParams]=\"returnParams()\"\n    />\n\n    <!-- The shared control, replacing a hand-rolled text button. See the pricing approvals note.\n      First, as on the record and approval screens, so every details screen opens its actions the same way. -->\n    <cms-refresh-button\n      cmsPageHeaderActions\n      label=\"Refresh price sequences\"\n      [busy]=\"busy()\"\n      (refresh)=\"refresh()\"\n    />\n\n    <!--\n      The contract behind these sequences. Carries `from=pricing` so the record's own breadcrumb comes\n      back through this screen rather than dropping the user on the workspace.\n    -->\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\n    <a\n      cmsPageHeaderActions\n      [attr.href]=\"recordHref()\"\n      (click)=\"followRecord($event)\"\n      class=\"scoular-btn scoular-btn-secondary\"\n    >\n      View full record\n    </a>\n\n    @if (canEditPricing()) {\n      <button\n        cmsPageHeaderActions\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n        [disabled]=\"busy() || writeRefusal() !== null || addHeld() !== null\"\n        [attr.title]=\"writeRefusal() ?? addHeld()\"\n        [attr.aria-describedby]=\"addHeld() !== null ? 'pricing-add-held' : null\"\n        (click)=\"addSequence()\"\n      >\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\n        Add price sequence\n      </button>\n    }\n    <!--\n      The reason beside the held button, not only in a tooltip a touch user cannot reach (#743). Its\n      own block with ONE root: a second root inside the button's block stops both projecting (NG8011).\n    -->\n    @if (canEditPricing() ? addHeld() : null; as reason) {\n      <span\n        cmsPageHeaderActions\n        id=\"pricing-add-held\"\n        class=\"cws:self-center cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\"\n      >\n        {{ reason }}\n      </span>\n    }\n    <!-- ‹ Record 3 of 150 ›, last of the record actions on every details screen (JFrisbie, 2026-10-26). -->\n    <cms-record-stepper cmsPageHeaderActions [journey]=\"journey\" />\n  </cms-page-header>\n\n  <!--\n    BR-053's re-check (F5.1, #743): what a fresh read of the contract says CTRM would do with an Add.\n\n    `role=\"status\"`, not `alert`: it is a standing fact about the contract found on arrival, not the\n    outcome of something the user pressed. Success renders nothing. The three refusals are CTRM's own\n    price-add checks (`CNTPRCADDE`); \"could not re-check\" is a read failure, which proves nothing about\n    the contract and so holds nothing.\n  -->\n  @if (openOutcome(); as outcome) {\n    @if (outcome.kind !== 'success') {\n      <div\n        class=\"scoular-alert\"\n        [class.scoular-alert-warning]=\"outcome.kind !== 'unchecked'\"\n        [class.scoular-alert-info]=\"outcome.kind === 'unchecked'\"\n        role=\"status\"\n        [attr.data-outcome]=\"outcome.kind\"\n      >\n        <div class=\"scoular-alert-title\">{{ outcome.title }}</div>\n        <div class=\"scoular-alert-description\">{{ outcome.message }}</div>\n      </div>\n    }\n  }\n\n  <!--\n    🔴 The one sentence standing in for three absent controls (F4.3a, extending #155).\n\n    Add, Edit and Remove are hidden rather than disabled: this screen shows a handful of\n    sequences, so disabling would put two dead buttons on every row plus one in the header, each\n    promising an action the account cannot take. One statement is more useful than five refusals.\n\n    ⚠ This screen has no `cms-notices-panel` and deliberately does not gain one for this. A panel\n    is a disclosure over several standing conditions; introducing one to hold a single line would\n    hide that line behind a collapsed summary, which is the opposite of what it is for.\n  -->\n  @if (!canEditPricing()) {\n    <p role=\"status\" class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n      This account can view price sequences but not change them. Pricing needs the\n      <strong>Admin</strong> role on this application.\n    </p>\n  } @else if (writeRefusal(); as refusal) {\n    <!-- #411: the controls stay, disabled; this is their reason, said once. -->\n    <p role=\"status\" class=\"cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n      {{ refusal }}\n    </p>\n  }\n\n  <!--\n    🔴 `role=\"alert\"`, and deliberately NOT the notices panel (F2.4, #373).\n\n    This is an EVENT — the user pressed something and it was refused — not a standing statement about\n    the record. The notices panel is for the latter, and putting an outcome there would make it\n    indistinguishable from a condition that was already true before they acted.\n\n    `formErrors` are rendered as a LIST inside the same alert rather than as a second banner: they are\n    reasons for the failure the title already names, and a second box would read as a second failure.\n  -->\n  <!-- #803: the last write's outcome. A refusal carries its reasons and the server's reference. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\n    @if (writeFormErrors().length > 0) {\n      <ul class=\"cws:mt-2 cws:list-disc cws:space-y-1 cws:pl-5\">\n        @for (reason of writeFormErrors(); track reason) {\n          <li>{{ reason }}</li>\n        }\n      </ul>\n    }\n  </cms-status-message>\n\n  @if (unverified(); as message) {\n    <!--\n      🔴 Accepted, state unknown — deliberately NOT an error. By this point the write has happened, and\n      telling a user their save failed when it did not is how the same price gets entered twice.\n    -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n      <div class=\"scoular-alert-title\">Saved, but not confirmed</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (deleteNotApplied(); as message) {\n    <!--\n      🔴 #156: a delete answered 202 and the re-read still lists the row. Its own title, because it is\n      neither the success CTRM's acknowledgement claims nor a refusal: the request was accepted and\n      the row is still there. `role=\"alert\"` because it is the outcome of what the user just pressed.\n    -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\n      <div class=\"scoular-alert-title\">The delete did not take effect</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (lastAcknowledgement(); as message) {\n    <!-- Only beside \"Saved, but not confirmed\": a confirmed write says this in its success. -->\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n      <div class=\"scoular-alert-description\">CTRM said: {{ message }}</div>\n    </div>\n  }\n\n  <!--\n    #1149: the inline editor that stood here is gone. A sequence opens as its own screen, view first and\n    then Edit, as the contract record does: double-click or Enter on a row, the row menu's Edit, or Add.\n  -->\n\n  <!--\n    The delete confirmation used to be rendered here, inline, as a `scoular-alert` carrying\n    `role=\"alertdialog\"`. It moved to the shared `cms-confirm-dialog` on 2026-09-16 — see\n    `askDelete()` — because it was a dialog in name only: the page behind it stayed operable, so the\n    one irreversible action on this screen could be scrolled past. The shared one traps focus, makes\n    the background inert and answers Escape.\n  -->\n\n  <!--\n    🔴 `(retry)` is bound, and it was not. The container renders its Retry button whenever the\n    load failed, so an unbound handler is a button that does nothing -- on the one screen where\n    the user has just been told the read failed. It calls the same reload the header Refresh\n    does, so retrying means exactly what refreshing means.\n\n    ⚠ The empty state goes through `[empty]`/`emptyMessage` rather than an `@if` INSIDE the\n    container. Hand-rolling it there bypassed the `[cmsEmptyAction]` slot and gave this screen\n    its own spacing, so two screens showing \"nothing here\" did not look alike.\n  -->\n  <cms-async-container\n    [data]=\"state()\"\n    [empty]=\"rows().length === 0\"\n    emptyMessage=\"This contract has no price sequences yet.\"\n    loadingLabel=\"Loading price sequences\"\n    (retry)=\"refresh()\"\n  >\n    @if (rows().length > 0) {\n      <!--\n        Striped for consistency with the two pricing queues, and tone-free like them. ⚠ This grid is\n        usually a handful of rows, where zebra earns less than it does on a long queue — it is here so\n        that the three pricing screens do not disagree about what a row looks like.\n      -->\n      <!--\n        🔴 Edit and Remove are grid row actions, not a second list beneath the grid.\n\n        This screen rendered every sequence TWICE -- once in the grid and again as a list item\n        carrying the two buttons -- so thirty sequences were sixty visual rows for thirty records,\n        and the second copy had to repeat the sequence number to say which row it belonged to. The\n        approval queue already had the right shape; this screen predates it.\n\n        The list also carried an \"approved\" marker, which the grid already has as a column -- so\n        removing the list loses nothing, and the state stays in the row it describes.\n      -->\n      <cms-data-grid\n        [rows]=\"rows()\"\n        [columns]=\"columns\"\n        label=\"Price sequences\"\n        columnsKey=\"pricing.sequences\"\n        [striped]=\"true\"\n        [sorts]=\"sorts()\"\n        [actions]=\"rowActions()\"\n        [rowLabel]=\"sequenceLabel\"\n        (sortChange)=\"sorts.set($event)\"\n        (rowActivate)=\"onRowActivate($event)\"\n      />\n\n    }\n  </cms-async-container>\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: BreadcrumbComponent,
				selector: "cms-breadcrumb",
				inputs: [
					"crumbs",
					"current",
					"context",
					"queryParams"
				]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"columnMenu",
					"columnsKey",
					"lockedColumns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"rowLabel",
					"activateLabel",
					"selectable",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep",
					"rowToggle",
					"selectAll"
				]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RecordStepperComponent,
				selector: "cms-record-stepper",
				inputs: ["journey"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PricingDetailPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pricing-detail-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				BreadcrumbComponent,
				DataGridComponent,
				PageHeaderComponent,
				RecordStepperComponent,
				RefreshButtonComponent,
				StatusMessageComponent
			],
			template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    [title]=\"'Price sequences — ' + contractNumber()\"\n    description=\"Flat price is basis plus adjustments plus futures. CTRM computes the stored price itself.\"\n  >\n    <!--\n      🔴 The shared trail, replacing a lookalike that was not a breadcrumb.\n\n      This was an anchor, a `<span>/</span>` and a second `<span>` — visually a trail, and to a screen\n      reader three unrelated pieces of text: no list, no `aria-current`, and a `/` separator where the\n      other two detail screens use `&rsaquo;`. So the one control a user meets on every detail screen\n      changed shape depending which screen they were on.\n\n      `returnParams()` carries the queue's packed state, so the crumb returns the user to the row they\n      opened rather than to a reset queue — the same journey the approvals review screen keeps.\n    -->\n    <cms-breadcrumb\n      cmsPageHeaderBreadcrumb\n      [crumbs]=\"crumbs()\"\n      [current]=\"contractNumber()\"\n      [context]=\"tradeUnitLabel()\"\n      [queryParams]=\"returnParams()\"\n    />\n\n    <!-- The shared control, replacing a hand-rolled text button. See the pricing approvals note.\n      First, as on the record and approval screens, so every details screen opens its actions the same way. -->\n    <cms-refresh-button\n      cmsPageHeaderActions\n      label=\"Refresh price sequences\"\n      [busy]=\"busy()\"\n      (refresh)=\"refresh()\"\n    />\n\n    <!--\n      The contract behind these sequences. Carries `from=pricing` so the record's own breadcrumb comes\n      back through this screen rather than dropping the user on the workspace.\n    -->\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\n    <a\n      cmsPageHeaderActions\n      [attr.href]=\"recordHref()\"\n      (click)=\"followRecord($event)\"\n      class=\"scoular-btn scoular-btn-secondary\"\n    >\n      View full record\n    </a>\n\n    @if (canEditPricing()) {\n      <button\n        cmsPageHeaderActions\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n        [disabled]=\"busy() || writeRefusal() !== null || addHeld() !== null\"\n        [attr.title]=\"writeRefusal() ?? addHeld()\"\n        [attr.aria-describedby]=\"addHeld() !== null ? 'pricing-add-held' : null\"\n        (click)=\"addSequence()\"\n      >\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\n        Add price sequence\n      </button>\n    }\n    <!--\n      The reason beside the held button, not only in a tooltip a touch user cannot reach (#743). Its\n      own block with ONE root: a second root inside the button's block stops both projecting (NG8011).\n    -->\n    @if (canEditPricing() ? addHeld() : null; as reason) {\n      <span\n        cmsPageHeaderActions\n        id=\"pricing-add-held\"\n        class=\"cws:self-center cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\"\n      >\n        {{ reason }}\n      </span>\n    }\n    <!-- ‹ Record 3 of 150 ›, last of the record actions on every details screen (JFrisbie, 2026-10-26). -->\n    <cms-record-stepper cmsPageHeaderActions [journey]=\"journey\" />\n  </cms-page-header>\n\n  <!--\n    BR-053's re-check (F5.1, #743): what a fresh read of the contract says CTRM would do with an Add.\n\n    `role=\"status\"`, not `alert`: it is a standing fact about the contract found on arrival, not the\n    outcome of something the user pressed. Success renders nothing. The three refusals are CTRM's own\n    price-add checks (`CNTPRCADDE`); \"could not re-check\" is a read failure, which proves nothing about\n    the contract and so holds nothing.\n  -->\n  @if (openOutcome(); as outcome) {\n    @if (outcome.kind !== 'success') {\n      <div\n        class=\"scoular-alert\"\n        [class.scoular-alert-warning]=\"outcome.kind !== 'unchecked'\"\n        [class.scoular-alert-info]=\"outcome.kind === 'unchecked'\"\n        role=\"status\"\n        [attr.data-outcome]=\"outcome.kind\"\n      >\n        <div class=\"scoular-alert-title\">{{ outcome.title }}</div>\n        <div class=\"scoular-alert-description\">{{ outcome.message }}</div>\n      </div>\n    }\n  }\n\n  <!--\n    🔴 The one sentence standing in for three absent controls (F4.3a, extending #155).\n\n    Add, Edit and Remove are hidden rather than disabled: this screen shows a handful of\n    sequences, so disabling would put two dead buttons on every row plus one in the header, each\n    promising an action the account cannot take. One statement is more useful than five refusals.\n\n    ⚠ This screen has no `cms-notices-panel` and deliberately does not gain one for this. A panel\n    is a disclosure over several standing conditions; introducing one to hold a single line would\n    hide that line behind a collapsed summary, which is the opposite of what it is for.\n  -->\n  @if (!canEditPricing()) {\n    <p role=\"status\" class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n      This account can view price sequences but not change them. Pricing needs the\n      <strong>Admin</strong> role on this application.\n    </p>\n  } @else if (writeRefusal(); as refusal) {\n    <!-- #411: the controls stay, disabled; this is their reason, said once. -->\n    <p role=\"status\" class=\"cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n      {{ refusal }}\n    </p>\n  }\n\n  <!--\n    🔴 `role=\"alert\"`, and deliberately NOT the notices panel (F2.4, #373).\n\n    This is an EVENT — the user pressed something and it was refused — not a standing statement about\n    the record. The notices panel is for the latter, and putting an outcome there would make it\n    indistinguishable from a condition that was already true before they acted.\n\n    `formErrors` are rendered as a LIST inside the same alert rather than as a second banner: they are\n    reasons for the failure the title already names, and a second box would read as a second failure.\n  -->\n  <!-- #803: the last write's outcome. A refusal carries its reasons and the server's reference. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\n    @if (writeFormErrors().length > 0) {\n      <ul class=\"cws:mt-2 cws:list-disc cws:space-y-1 cws:pl-5\">\n        @for (reason of writeFormErrors(); track reason) {\n          <li>{{ reason }}</li>\n        }\n      </ul>\n    }\n  </cms-status-message>\n\n  @if (unverified(); as message) {\n    <!--\n      🔴 Accepted, state unknown — deliberately NOT an error. By this point the write has happened, and\n      telling a user their save failed when it did not is how the same price gets entered twice.\n    -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n      <div class=\"scoular-alert-title\">Saved, but not confirmed</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (deleteNotApplied(); as message) {\n    <!--\n      🔴 #156: a delete answered 202 and the re-read still lists the row. Its own title, because it is\n      neither the success CTRM's acknowledgement claims nor a refusal: the request was accepted and\n      the row is still there. `role=\"alert\"` because it is the outcome of what the user just pressed.\n    -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\n      <div class=\"scoular-alert-title\">The delete did not take effect</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (lastAcknowledgement(); as message) {\n    <!-- Only beside \"Saved, but not confirmed\": a confirmed write says this in its success. -->\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n      <div class=\"scoular-alert-description\">CTRM said: {{ message }}</div>\n    </div>\n  }\n\n  <!--\n    #1149: the inline editor that stood here is gone. A sequence opens as its own screen, view first and\n    then Edit, as the contract record does: double-click or Enter on a row, the row menu's Edit, or Add.\n  -->\n\n  <!--\n    The delete confirmation used to be rendered here, inline, as a `scoular-alert` carrying\n    `role=\"alertdialog\"`. It moved to the shared `cms-confirm-dialog` on 2026-09-16 — see\n    `askDelete()` — because it was a dialog in name only: the page behind it stayed operable, so the\n    one irreversible action on this screen could be scrolled past. The shared one traps focus, makes\n    the background inert and answers Escape.\n  -->\n\n  <!--\n    🔴 `(retry)` is bound, and it was not. The container renders its Retry button whenever the\n    load failed, so an unbound handler is a button that does nothing -- on the one screen where\n    the user has just been told the read failed. It calls the same reload the header Refresh\n    does, so retrying means exactly what refreshing means.\n\n    ⚠ The empty state goes through `[empty]`/`emptyMessage` rather than an `@if` INSIDE the\n    container. Hand-rolling it there bypassed the `[cmsEmptyAction]` slot and gave this screen\n    its own spacing, so two screens showing \"nothing here\" did not look alike.\n  -->\n  <cms-async-container\n    [data]=\"state()\"\n    [empty]=\"rows().length === 0\"\n    emptyMessage=\"This contract has no price sequences yet.\"\n    loadingLabel=\"Loading price sequences\"\n    (retry)=\"refresh()\"\n  >\n    @if (rows().length > 0) {\n      <!--\n        Striped for consistency with the two pricing queues, and tone-free like them. ⚠ This grid is\n        usually a handful of rows, where zebra earns less than it does on a long queue — it is here so\n        that the three pricing screens do not disagree about what a row looks like.\n      -->\n      <!--\n        🔴 Edit and Remove are grid row actions, not a second list beneath the grid.\n\n        This screen rendered every sequence TWICE -- once in the grid and again as a list item\n        carrying the two buttons -- so thirty sequences were sixty visual rows for thirty records,\n        and the second copy had to repeat the sequence number to say which row it belonged to. The\n        approval queue already had the right shape; this screen predates it.\n\n        The list also carried an \"approved\" marker, which the grid already has as a column -- so\n        removing the list loses nothing, and the state stays in the row it describes.\n      -->\n      <cms-data-grid\n        [rows]=\"rows()\"\n        [columns]=\"columns\"\n        label=\"Price sequences\"\n        columnsKey=\"pricing.sequences\"\n        [striped]=\"true\"\n        [sorts]=\"sorts()\"\n        [actions]=\"rowActions()\"\n        [rowLabel]=\"sequenceLabel\"\n        (sortChange)=\"sorts.set($event)\"\n        (rowActivate)=\"onRowActivate($event)\"\n      />\n\n    }\n  </cms-async-container>\n</section>\n"
		}]
	}],
	propDecorators: {
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}],
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}]
	}
});
const NEW_DRAFT = {
	priceSequence: 0,
	isNew: true,
	pricedQuantity: "",
	pricedLoads: "",
	hedgePrice: "",
	basisPrice: "",
	adjustments: 0,
	hedgeMarketCode: "",
	hedgeMarketMonthCode: "",
	priceDate: "",
	description: "",
	remark: "",
	printFlag: true
};
var PriceSequenceDetailPageComponent = class PriceSequenceDetailPageComponent {
	source = inject(PRICING_SOURCE);
	contractDetail = inject(CONTRACT_DETAIL_SOURCE);
	contractFields = inject(CONTRACT_WRITE_SOURCE, { optional: true });
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	arrivals = inject(PricingArrivals);
	confirm = injectConfirm();
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	seq = input(...ngDevMode ? [void 0, { debugName: "seq" }] : /* istanbul ignore next */ []);
	mode = input(...ngDevMode ? [void 0, { debugName: "mode" }] : /* istanbul ignore next */ []);
	screenMode = computed(() => this.mode() ?? "view", ...ngDevMode ? [{ debugName: "screenMode" }] : /* istanbul ignore next */ []);
	isNew = computed(() => this.screenMode() === "new", ...ngDevMode ? [{ debugName: "isNew" }] : /* istanbul ignore next */ []);
	sequenceNumber = computed(() => {
		if (this.isNew()) return null;
		const parsed = Number(this.seq() ?? "");
		return Number.isInteger(parsed) ? parsed : null;
	}, ...ngDevMode ? [{ debugName: "sequenceNumber" }] : /* istanbul ignore next */ []);
	fromParam = this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM);
	returnTo = this.route.snapshot.queryParamMap.get("returnTo");
	passedParams = computed(() => ({
		...this.fromParam === null ? {} : { [RECORD_ORIGIN_PARAM]: this.fromParam },
		...this.returnTo === null ? {} : { returnTo: this.returnTo }
	}), ...ngDevMode ? [{ debugName: "passedParams" }] : /* istanbul ignore next */ []);
	originKey = computed(() => recordOriginKey(this.fromParam, "pricing"), ...ngDevMode ? [{ debugName: "originKey" }] : /* istanbul ignore next */ []);
	origin = computed(() => recordOrigin(this.originKey(), "pricing"), ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	parentJourney = computed(() => this.hostContext.navigationState?.()?.[PRICING_PARENT_JOURNEY], ...ngDevMode ? [{ debugName: "parentJourney" }] : /* istanbul ignore next */ []);
	originIntent = computed(() => ({
		kind: "origin",
		origin: this.originKey(),
		params: Object.fromEntries(new URLSearchParams(this.returnTo ?? ""))
	}), ...ngDevMode ? [{ debugName: "originIntent" }] : /* istanbul ignore next */ []);
	pricingIntent = computed(() => {
		const state = parentJourneyState(this.parentJourney());
		return {
			kind: "review",
			origin: "pricing",
			contractNumber: this.contractNumber(),
			params: this.passedParams(),
			...state === void 0 ? {} : { state }
		};
	}, ...ngDevMode ? [{ debugName: "pricingIntent" }] : /* istanbul ignore next */ []);
	recordIntent = computed(() => ({
		kind: "contract",
		contractNumber: this.contractNumber(),
		params: {
			[RECORD_ORIGIN_PARAM]: "pricing",
			...this.returnTo === null ? {} : { returnTo: this.returnTo }
		}
	}), ...ngDevMode ? [{ debugName: "recordIntent" }] : /* istanbul ignore next */ []);
	recordHref = computed(() => this.hostContext.hrefFor(this.recordIntent()), ...ngDevMode ? [{ debugName: "recordHref" }] : /* istanbul ignore next */ []);
	crumbs = computed(() => {
		const queue = this.originIntent();
		const pricing = this.pricingIntent();
		return [{
			label: this.origin().label,
			path: this.origin().path,
			link: {
				href: this.hostContext.hrefFor(queue),
				follow: (event) => this.follow(event, queue)
			}
		}, {
			label: this.contractNumber(),
			path: this.origin().review?.path(this.contractNumber()) ?? `/pricing/${this.contractNumber()}`,
			link: {
				href: this.hostContext.hrefFor(pricing),
				follow: (event) => this.follow(event, pricing)
			}
		}];
	}, ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	currentCrumb = computed(() => this.isNew() ? "New sequence" : `Sequence ${this.seq() ?? ""}`, ...ngDevMode ? [{ debugName: "currentCrumb" }] : /* istanbul ignore next */ []);
	title = computed(() => this.isNew() ? `New price sequence — ${this.contractNumber()}` : `Price sequence ${this.seq() ?? ""} — ${this.contractNumber()}`, ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	tradeUnitLabel = injectTradeUnitLabel();
	follow(event, intent) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(intent);
	}
	followRecord(event) {
		this.follow(event, this.recordIntent());
	}
	journey = injectRecordJourney({
		kind: "price-sequence",
		key: () => this.seq() ?? "",
		held: () => this.busy(),
		open: (key, state) => this.hostContext.navigate(this.sequenceIntent(Number(key), this.screenMode() === "edit" ? "edit" : "view", state))
	});
	sequenceIntent(priceSequence, mode, state = this.journey.state()) {
		const carried = withParentJourney(state, this.parentJourney());
		return {
			kind: "price-sequence",
			contractNumber: this.contractNumber(),
			priceSequence,
			mode,
			params: this.passedParams(),
			...carried === void 0 ? {} : { state: carried }
		};
	}
	reload = signal(0, ...ngDevMode ? [{ debugName: "reload" }] : /* istanbul ignore next */ []);
	loaded = toSignal(toObservable(computed(() => ({
		contract: this.contractNumber(),
		nonce: this.reload()
	}))).pipe(switchMap(({ contract }) => this.source.contractPrices(contract))), { initialValue: remoteLoading() });
	afterWrite = signal(null, ...ngDevMode ? [{ debugName: "afterWrite" }] : /* istanbul ignore next */ []);
	state = computed(() => {
		const written = this.afterWrite();
		return written === null ? this.loaded() : remoteLoaded({
			contract: this.contractNumber(),
			prices: written
		});
	}, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	prices = computed(() => {
		const state = this.state();
		return state.status === "loaded" ? state.value.prices : [];
	}, ...ngDevMode ? [{ debugName: "prices" }] : /* istanbul ignore next */ []);
	row = computed(() => {
		const wanted = this.sequenceNumber();
		return wanted === null ? null : this.prices().find((each) => each.priceSequence === wanted) ?? null;
	}, ...ngDevMode ? [{ debugName: "row" }] : /* istanbul ignore next */ []);
	missing = computed(() => !this.isNew() && this.state().status === "loaded" && this.row() === null, ...ngDevMode ? [{ debugName: "missing" }] : /* istanbul ignore next */ []);
	freshContract = toSignal(toObservable(computed(() => ({
		contract: this.contractNumber(),
		isNew: this.isNew(),
		nonce: this.reload()
	}))).pipe(switchMap(({ contract, isNew }) => isNew ? this.contractDetail.get(contract) : of(null))), { initialValue: null });
	openOutcome = computed(() => {
		const read = this.freshContract();
		return read === null ? null : unpricedOpenOutcomeOf(read);
	}, ...ngDevMode ? [{ debugName: "openOutcome" }] : /* istanbul ignore next */ []);
	contractMarket = toSignal(toObservable(computed(() => ({
		contract: this.contractNumber(),
		isNew: this.isNew()
	}))).pipe(switchMap(({ contract, isNew }) => !isNew || this.contractFields === null ? of(null) : this.contractFields.fields(contract).pipe(map((read) => read.fields), catchError(() => of(null))))), { initialValue: null });
	contractDefaults = computed(() => {
		const defaults = {};
		const market = this.contractMarket();
		const read = this.freshContract();
		const code = textOf(market?.["price_market_code"]);
		const month = textOf(market?.["price_market_month"]);
		const basis = read?.status === "loaded" ? read.value.contract.header.basisPrice : null;
		if (code !== "") defaults.hedgeMarketCode = code;
		if (month !== "") defaults.hedgeMarketMonthCode = month;
		if (basis !== null && basis !== void 0) defaults.basisPrice = String(basis);
		return defaults;
	}, ...ngDevMode ? [{ debugName: "contractDefaults" }] : /* istanbul ignore next */ []);
	addHeld = computed(() => this.isNew() ? this.openOutcome()?.holdsAdd ?? null : null, ...ngDevMode ? [{ debugName: "addHeld" }] : /* istanbul ignore next */ []);
	canEditPricing = computed(() => this.permissions.canEditPricing(), ...ngDevMode ? [{ debugName: "canEditPricing" }] : /* istanbul ignore next */ []);
	writeRefusal = computed(() => this.permissions.writeRefusal?.()?.message ?? null, ...ngDevMode ? [{ debugName: "writeRefusal" }] : /* istanbul ignore next */ []);
	editing = computed(() => this.screenMode() !== "view" && this.canEditPricing(), ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	writeFormErrors = signal([], ...ngDevMode ? [{ debugName: "writeFormErrors" }] : /* istanbul ignore next */ []);
	unverified = signal(null, ...ngDevMode ? [{ debugName: "unverified" }] : /* istanbul ignore next */ []);
	lastAcknowledgement = signal(null, ...ngDevMode ? [{ debugName: "lastAcknowledgement" }] : /* istanbul ignore next */ []);
	deleteNotApplied = signal(null, ...ngDevMode ? [{ debugName: "deleteNotApplied" }] : /* istanbul ignore next */ []);
	draft = signal(null, ...ngDevMode ? [{ debugName: "draft" }] : /* istanbul ignore next */ []);
	pristine = signal(null, ...ngDevMode ? [{ debugName: "pristine" }] : /* istanbul ignore next */ []);
	leaving = false;
	dirty = computed(() => {
		const draft = this.draft();
		const pristine = this.pristine();
		return draft !== null && pristine !== null && JSON.stringify(draft) !== JSON.stringify(pristine);
	}, ...ngDevMode ? [{ debugName: "dirty" }] : /* istanbul ignore next */ []);
	seedDraft = effect(() => {
		if (!this.editing() || untracked(() => this.draft()) !== null) return;
		const seed = this.isNew() ? NEW_DRAFT : this.row() === null ? null : draftOf(this.row());
		if (seed !== null) untracked(() => {
			this.draft.set({ ...seed });
			this.pristine.set({ ...seed });
		});
	}, ...ngDevMode ? [{ debugName: "seedDraft" }] : /* istanbul ignore next */ []);
	seeded = computed(() => this.draft() !== null, ...ngDevMode ? [{ debugName: "seeded" }] : /* istanbul ignore next */ []);
	prefillFromContract = effect(() => {
		const defaults = this.contractDefaults();
		if (!this.isNew() || !this.seeded()) return;
		untracked(() => {
			const draft = this.draft();
			const pristine = this.pristine();
			if (draft === null || pristine === null) return;
			const fill = {};
			for (const key of [
				"hedgeMarketCode",
				"hedgeMarketMonthCode",
				"basisPrice"
			]) {
				const value = defaults[key];
				if (value !== void 0 && pristine[key] === "" && draft[key] === "") fill[key] = value;
			}
			if (Object.keys(fill).length > 0) {
				this.draft.set({
					...draft,
					...fill
				});
				this.pristine.set({
					...pristine,
					...fill
				});
			}
		});
	}, ...ngDevMode ? [{ debugName: "prefillFromContract" }] : /* istanbul ignore next */ []);
	lastKey = null;
	onArrival = effect(() => {
		const contractNumber = this.contractNumber();
		const key = `${contractNumber}#${this.seq() ?? ""}`;
		const priceSequence = this.sequenceNumber();
		untracked(() => {
			if (this.lastKey !== null && this.lastKey !== key) {
				this.draft.set(null);
				this.pristine.set(null);
				this.leaving = false;
				this.clearMessages();
			}
			this.lastKey = key;
			const arrival = priceSequence === null ? null : this.arrivals.take(contractNumber, priceSequence);
			if (arrival !== null) this.takeArrival(arrival);
		});
	}, ...ngDevMode ? [{ debugName: "onArrival" }] : /* istanbul ignore next */ []);
	takeArrival(arrival) {
		if (arrival.prices !== null) this.afterWrite.set(arrival.prices);
		this.outcome.set(arrival.outcome);
		this.unverified.set(arrival.unverified);
		this.lastAcknowledgement.set(arrival.acknowledgement);
	}
	draftFlatPrice = computed(() => {
		const draft = this.draft();
		return draft === null ? 0 : flatPrice({
			basisPrice: numberOrNull(draft.basisPrice),
			adjustments: draft.adjustments,
			hedgePrice: numberOrNull(draft.hedgePrice)
		});
	}, ...ngDevMode ? [{ debugName: "draftFlatPrice" }] : /* istanbul ignore next */ []);
	viewFlatPrice = computed(() => {
		const row = this.row();
		return row === null ? 0 : flatPrice({
			basisPrice: row.basisPrice,
			adjustments: row.adjustments,
			hedgePrice: row.hedgePrice
		});
	}, ...ngDevMode ? [{ debugName: "viewFlatPrice" }] : /* istanbul ignore next */ []);
	storedPriceDisagrees = computed(() => {
		const row = this.row();
		if (row === null) return false;
		return !flatPriceAgrees(this.editing() ? this.draftFlatPrice() : this.viewFlatPrice(), row.price);
	}, ...ngDevMode ? [{ debugName: "storedPriceDisagrees" }] : /* istanbul ignore next */ []);
	viewFields = computed(() => {
		const row = this.row();
		if (row === null) return [];
		return [
			{
				label: "Priced quantity",
				value: amount(row.pricedQuantity)
			},
			{
				label: "Loads",
				value: String(row.pricedLoads)
			},
			{
				label: "Futures price",
				value: price(row.hedgePrice)
			},
			{
				label: "Basis",
				value: price(row.basisPrice)
			},
			{
				label: "Market code",
				value: row.hedgeMarketCode ?? ""
			},
			{
				label: "Market month",
				value: row.hedgeMarketMonth ?? ""
			},
			{
				label: "Price date",
				value: formatShortDate(row.priceDate)
			},
			{
				label: "Description",
				value: row.priceDescription ?? ""
			},
			{
				label: "Remark",
				value: row.remark ?? "",
				wide: true
			},
			{
				label: "Print on confirmation",
				value: (row.printFlag ?? "Y").toUpperCase() !== "N" ? "Yes" : "No"
			}
		];
	}, ...ngDevMode ? [{ debugName: "viewFields" }] : /* istanbul ignore next */ []);
	patch(key, value) {
		const draft = this.draft();
		if (draft !== null) this.draft.set({
			...draft,
			[key]: value
		});
	}
	patchText(key, raw) {
		this.patch(key, raw);
	}
	canSave = computed(() => {
		const draft = this.draft();
		const quantity = draft === null ? null : numberOrNull(draft.pricedQuantity);
		return quantity !== null && quantity > 0 && this.addHeld() === null;
	}, ...ngDevMode ? [{ debugName: "canSave" }] : /* istanbul ignore next */ []);
	edit() {
		const priceSequence = this.sequenceNumber();
		if (priceSequence !== null && !this.busy()) this.hostContext.navigate(this.sequenceIntent(priceSequence, "edit"));
	}
	cancel() {
		const priceSequence = this.sequenceNumber();
		this.hostContext.navigate(priceSequence === null ? this.pricingIntent() : this.sequenceIntent(priceSequence, "view"));
	}
	save() {
		const draft = this.draft();
		if (draft === null || !this.canSave() || this.busy() || this.writeRefusal() !== null) return;
		const edit = {
			priceSequence: draft.isNew ? 0 : draft.priceSequence,
			pricedQuantity: numberOrNull(draft.pricedQuantity),
			pricedLoads: numberOrNull(draft.pricedLoads),
			hedgePrice: numberOrNull(draft.hedgePrice),
			basisPrice: numberOrNull(draft.basisPrice),
			hedgeMarketCode: draft.hedgeMarketCode || null,
			hedgeMarketMonthCode: draft.hedgeMarketMonthCode || null,
			priceDate: draft.priceDate || null,
			description: draft.description || null,
			remark: draft.remark || null,
			printFlag: draft.printFlag ? "Y" : "N"
		};
		const before = new Set(this.prices().map((each) => each.priceSequence));
		this.write(this.source.save(this.contractNumber(), [edit]), (written) => {
			const arrived = draft.isNew ? numberedByCtrm(before, written.prices) : draft.priceSequence;
			const success = draft.isNew ? arrived === null ? "Price sequence added." : `Price sequence ${arrived} added.` : `Price sequence ${draft.priceSequence} saved.`;
			const journey = draft.isNew ? void 0 : this.journey.state();
			this.leaving = true;
			this.arrivals.leave(this.contractNumber(), arrived, arrivalOf(written, success));
			this.hostContext.navigate(arrived === null ? this.pricingIntent() : this.sequenceIntent(arrived, "view", journey));
		});
	}
	askDelete() {
		const priceSequence = this.sequenceNumber();
		if (priceSequence === null || this.busy()) return;
		this.clearMessages();
		this.confirm({
			title: `Remove price sequence ${priceSequence}?`,
			message: "This removes the sequence from CTRM. The list will be re-read afterwards, because a pricing delete cannot report its own outcome.",
			confirmLabel: "Remove sequence",
			cancelLabel: "Keep it",
			destructive: true
		}).subscribe((confirmed) => {
			if (confirmed) this.remove(priceSequence);
		});
	}
	remove(priceSequence) {
		this.write(this.source.remove(this.contractNumber(), priceSequence), (written) => {
			if (written.verified && written.prices.some((each) => each.priceSequence === priceSequence)) {
				this.afterWrite.set(written.prices);
				this.deleteNotApplied.set(`CTRM accepted the request, but price sequence ${priceSequence} is still listed when the prices are read back, so it was not removed. Refresh to check, then try again.`);
				return;
			}
			this.arrivals.leave(this.contractNumber(), null, arrivalOf(written, `Price sequence ${priceSequence} removed.`));
			this.hostContext.navigate(this.pricingIntent());
		});
	}
	write(request, accepted) {
		this.busy.set(true);
		this.clearMessages();
		request.subscribe((result) => {
			if (result.status === "loading") return;
			this.busy.set(false);
			if (result.status !== "loaded") {
				this.outcome.set(mutationFailed(result.status === "error" ? {
					message: `That change was not saved. ${result.error.message}`,
					correlationId: result.error.correlationId
				} : { message: "That change was not saved. It did not complete." }));
				this.writeFormErrors.set(result.status === "error" ? result.error.formErrors ?? [] : []);
				return;
			}
			accepted(result.value);
		});
	}
	refresh() {
		this.clearMessages();
		this.afterWrite.set(null);
		this.reload.update((value) => value + 1);
	}
	clearMessages() {
		this.outcome.set(null);
		this.writeFormErrors.set([]);
		this.unverified.set(null);
		this.deleteNotApplied.set(null);
		this.lastAcknowledgement.set(null);
	}
	confirmNavigation() {
		if (this.leaving || !this.dirty()) return true;
		return this.confirm({
			title: "Leave without saving?",
			message: "This price sequence has changes that have not been sent to CTRM. Leaving now discards them.",
			confirmLabel: "Discard changes",
			cancelLabel: "Keep editing",
			destructive: true
		});
	}
	onBeforeUnload(event) {
		if (this.dirty() && !this.leaving) event.preventDefault();
	}
	onEscape(event) {
		if (event.defaultPrevented) return;
		if (this.editing()) {
			this.cancel();
			return;
		}
		this.hostContext.navigate(this.pricingIntent());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PriceSequenceDetailPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PriceSequenceDetailPageComponent,
		isStandalone: true,
		selector: "cms-price-sequence-detail-page",
		inputs: {
			contractNumber: {
				classPropertyName: "contractNumber",
				publicName: "contractNumber",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			seq: {
				classPropertyName: "seq",
				publicName: "seq",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { listeners: {
			"window:beforeunload": "onBeforeUnload($event)",
			"document:keydown.escape": "onEscape($event)"
		} },
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    [title]=\"title()\"\n    description=\"Flat price is basis plus adjustments plus futures. CTRM computes the stored price itself.\"\n  >\n    <!-- Pricing › <contract> › Sequence <n>. -->\n    <cms-breadcrumb\n      cmsPageHeaderBreadcrumb\n      [crumbs]=\"crumbs()\"\n      [current]=\"currentCrumb()\"\n      [context]=\"tradeUnitLabel()\"\n    />\n\n    <!-- One root per block: a second root stops both projecting into the slot (NG8011). -->\n    @if (!editing() && canEditPricing() && row() !== null) {\n      <button\n        cmsPageHeaderActions\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n        [disabled]=\"busy() || writeRefusal() !== null\"\n        [attr.title]=\"writeRefusal()\"\n        (click)=\"edit()\"\n      >\n        Edit\n      </button>\n    }\n    @if (!editing() && canEditPricing() && row() !== null) {\n      <button\n        cmsPageHeaderActions\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-secondary\"\n        [disabled]=\"busy() || writeRefusal() !== null\"\n        [attr.title]=\"writeRefusal()\"\n        (click)=\"askDelete()\"\n      >\n        Delete\n      </button>\n    }\n\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\n    <a\n      cmsPageHeaderActions\n      [attr.href]=\"recordHref()\"\n      (click)=\"followRecord($event)\"\n      class=\"scoular-btn scoular-btn-secondary\"\n    >\n      View full record\n    </a>\n    <!-- ‹ Record 2 of 5 ›, last of the record actions on every details screen (JFrisbie, 2026-10-26). One root per block (NG8011). -->\n    @if (!isNew()) {\n      <cms-record-stepper cmsPageHeaderActions [journey]=\"journey\" />\n    }\n  </cms-page-header>\n\n  <!-- BR-053's re-check before an Add (#743), on a new sequence only: a standing fact, so `status`. -->\n  @if (openOutcome(); as found) {\n    @if (found.kind !== 'success') {\n      <div\n        class=\"scoular-alert\"\n        [class.scoular-alert-warning]=\"found.kind !== 'unchecked'\"\n        [class.scoular-alert-info]=\"found.kind === 'unchecked'\"\n        role=\"status\"\n        [attr.data-outcome]=\"found.kind\"\n      >\n        <div class=\"scoular-alert-title\">{{ found.title }}</div>\n        <div class=\"scoular-alert-description\">{{ found.message }}</div>\n      </div>\n    }\n  }\n\n  @if (!canEditPricing()) {\n    <p role=\"status\" class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n      This account can view price sequences but not change them. Pricing needs the\n      <strong>Admin</strong> role on this application.\n    </p>\n  } @else if (writeRefusal(); as refusal) {\n    <p role=\"status\" class=\"cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n      {{ refusal }}\n    </p>\n  }\n\n  <!-- The last write's outcome (#803); a refusal carries its reasons and the server's reference. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\n    @if (writeFormErrors().length > 0) {\n      <ul class=\"cws:mt-2 cws:list-disc cws:space-y-1 cws:pl-5\">\n        @for (reason of writeFormErrors(); track reason) {\n          <li>{{ reason }}</li>\n        }\n      </ul>\n    }\n  </cms-status-message>\n\n  @if (unverified(); as message) {\n    <!-- Accepted, state unknown: deliberately NOT an error, or the same price gets entered twice. -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n      <div class=\"scoular-alert-title\">Saved, but not confirmed</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (deleteNotApplied(); as message) {\n    <!-- #156: the delete answered 202 and the re-read still lists the sequence. -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\n      <div class=\"scoular-alert-title\">The delete did not take effect</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (lastAcknowledgement(); as message) {\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n      <div class=\"scoular-alert-description\">CTRM said: {{ message }}</div>\n    </div>\n  }\n\n  @if (isNew() && editing()) {\n    <ng-container *ngTemplateOutlet=\"editor\" />\n  } @else {\n    <cms-async-container\n      [data]=\"state()\"\n      [empty]=\"missing()\"\n      [emptyMessage]=\"'Price sequence ' + (seq() ?? '') + ' is not on this contract. It may have been removed.'\"\n      loadingLabel=\"Loading the price sequence\"\n      (retry)=\"refresh()\"\n    >\n      @if (row(); as current) {\n        @if (editing()) {\n          <ng-container *ngTemplateOutlet=\"editor\" />\n        } @else {\n          <!-- The view: every field the editor shows, read-only and in the editor's layout. -->\n          <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\">\n            <dl class=\"cws:grid cws:grid-cols-1 cws:gap-4 cws:sm:grid-cols-2 cws:2xl:grid-cols-4\">\n              @for (field of viewFields(); track field.label) {\n                <div class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\" [class.cws:sm:col-span-2]=\"field.wide\">\n                  <dt class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">{{ field.label }}</dt>\n                  <dd class=\"cws:min-h-5 cws:text-slate-900 cws:dark:text-white\">{{ field.value }}</dd>\n                </div>\n              }\n            </dl>\n\n            <div\n              class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:border-t cws:border-slate-200 cws:pt-3 cws:dark:border-slate-700\"\n            >\n              <p class=\"cws:text-sm\">\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">Flat price (basis + adjustments + futures):</span>\n                <strong class=\"cws:ml-2 cws:text-slate-900 cws:dark:text-white\">{{ viewFlatPrice() | number: '1.4-5' }}</strong>\n                @if (current.adjustments) {\n                  <span class=\"cws:ml-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                    includes adjustments {{ current.adjustments | number: '1.4-5' }}\n                  </span>\n                }\n              </p>\n              @if (storedPriceDisagrees()) {\n                <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-scoular-yellow\">\n                  This differs from the price CTRM has stored for this sequence.\n                </p>\n              }\n            </div>\n          </div>\n        }\n      }\n    </cms-async-container>\n  }\n\n  <ng-template #editor>\n    @if (draft(); as editing) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\">\n        @if (editing.isNew) {\n          <!-- No number is shown: an add sends 0 and CTRM assigns the number on save (CQ00132, #581). -->\n          <p class=\"cws:mb-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            CTRM assigns the sequence number on save.\n          </p>\n        }\n\n        <div class=\"cws:grid cws:grid-cols-1 cws:gap-4 cws:sm:grid-cols-2 cws:2xl:grid-cols-4\">\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Priced quantity *</span>\n            <input\n              type=\"text\"\n              inputmode=\"decimal\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.pricedQuantity\"\n              (input)=\"patchText('pricedQuantity', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Loads</span>\n            <input\n              type=\"text\"\n              inputmode=\"numeric\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.pricedLoads\"\n              (input)=\"patchText('pricedLoads', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Futures price</span>\n            <input\n              type=\"text\"\n              inputmode=\"decimal\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.hedgePrice\"\n              (input)=\"patchText('hedgePrice', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Basis</span>\n            <input\n              type=\"text\"\n              inputmode=\"decimal\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.basisPrice\"\n              (input)=\"patchText('basisPrice', $any($event.target).value)\"\n            />\n            @if (isNew()) {\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                Defaults to the contract’s basis. You can change it.\n              </span>\n            }\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market code</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.hedgeMarketCode\"\n              (input)=\"patch('hedgeMarketCode', $any($event.target).value)\"\n            />\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              @if (isNew()) {\n                The market code and month default to the contract’s. You can change them; left blank,\n                CTRM uses the contract’s.\n              } @else {\n                The hedge market and month for this sequence, typed as CTRM stores them.\n              }\n            </span>\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market month</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.hedgeMarketMonthCode\"\n              (input)=\"patch('hedgeMarketMonthCode', $any($event.target).value)\"\n            />\n          </label>\n\n          <!-- The shared C3 date control (BR-020's typed shapes), patched field by field. -->\n          <cms-date-input\n            label=\"Price date\"\n            controlId=\"price-sequence-price-date\"\n            [ngModel]=\"editing.priceDate\"\n            (ngModelChange)=\"patch('priceDate', $event)\"\n          />\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Description</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.description\"\n              (input)=\"patch('description', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm cws:sm:col-span-2\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Remark</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.remark\"\n              (input)=\"patch('remark', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm\">\n            <input\n              type=\"checkbox\"\n              [checked]=\"editing.printFlag\"\n              (change)=\"patch('printFlag', $any($event.target).checked)\"\n            />\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Print on confirmation</span>\n          </label>\n        </div>\n\n        <!-- BR-050, live. `role=\"status\"` so a screen reader hears the total change. -->\n        <div\n          class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:border-t cws:border-slate-200 cws:pt-3 cws:dark:border-slate-700\"\n        >\n          <p class=\"cws:text-sm\" role=\"status\">\n            <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">Flat price (basis + adjustments + futures):</span>\n            <strong class=\"cws:ml-2 cws:text-slate-900 cws:dark:text-white\">{{ draftFlatPrice() | number: '1.4-5' }}</strong>\n            @if (editing.adjustments) {\n              <span class=\"cws:ml-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                includes adjustments {{ editing.adjustments | number: '1.4-5' }}\n              </span>\n            }\n          </p>\n\n          @if (storedPriceDisagrees()) {\n            <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-scoular-yellow\">\n              This differs from the price CTRM has stored for this sequence.\n            </p>\n          }\n        </div>\n\n        <div class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n            [disabled]=\"!canSave() || busy() || writeRefusal() !== null\"\n            [attr.title]=\"writeRefusal() ?? addHeld()\"\n            (click)=\"save()\"\n          >\n            {{ busy() ? 'Saving…' : 'Save sequence' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"cancel()\">\n            Cancel\n          </button>\n\n          @if (addHeld(); as reason) {\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ reason }}</span>\n          } @else if (!canSave()) {\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              A priced quantity greater than zero is required.\n            </span>\n          }\n        </div>\n      </div>\n    }\n  </ng-template>\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: BreadcrumbComponent,
				selector: "cms-breadcrumb",
				inputs: [
					"crumbs",
					"current",
					"context",
					"queryParams"
				]
			},
			{
				kind: "component",
				type: DateInputComponent,
				selector: "cms-date-input",
				inputs: [
					"label",
					"controlId",
					"required",
					"requiredMarker",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RecordStepperComponent,
				selector: "cms-record-stepper",
				inputs: ["journey"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "pipe",
				type: DecimalPipe,
				name: "number"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PriceSequenceDetailPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-price-sequence-detail-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				BreadcrumbComponent,
				DateInputComponent,
				DecimalPipe,
				FormsModule,
				NgTemplateOutlet,
				PageHeaderComponent,
				RecordStepperComponent,
				StatusMessageComponent
			],
			template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    [title]=\"title()\"\n    description=\"Flat price is basis plus adjustments plus futures. CTRM computes the stored price itself.\"\n  >\n    <!-- Pricing › <contract> › Sequence <n>. -->\n    <cms-breadcrumb\n      cmsPageHeaderBreadcrumb\n      [crumbs]=\"crumbs()\"\n      [current]=\"currentCrumb()\"\n      [context]=\"tradeUnitLabel()\"\n    />\n\n    <!-- One root per block: a second root stops both projecting into the slot (NG8011). -->\n    @if (!editing() && canEditPricing() && row() !== null) {\n      <button\n        cmsPageHeaderActions\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n        [disabled]=\"busy() || writeRefusal() !== null\"\n        [attr.title]=\"writeRefusal()\"\n        (click)=\"edit()\"\n      >\n        Edit\n      </button>\n    }\n    @if (!editing() && canEditPricing() && row() !== null) {\n      <button\n        cmsPageHeaderActions\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-secondary\"\n        [disabled]=\"busy() || writeRefusal() !== null\"\n        [attr.title]=\"writeRefusal()\"\n        (click)=\"askDelete()\"\n      >\n        Delete\n      </button>\n    }\n\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\n    <a\n      cmsPageHeaderActions\n      [attr.href]=\"recordHref()\"\n      (click)=\"followRecord($event)\"\n      class=\"scoular-btn scoular-btn-secondary\"\n    >\n      View full record\n    </a>\n    <!-- ‹ Record 2 of 5 ›, last of the record actions on every details screen (JFrisbie, 2026-10-26). One root per block (NG8011). -->\n    @if (!isNew()) {\n      <cms-record-stepper cmsPageHeaderActions [journey]=\"journey\" />\n    }\n  </cms-page-header>\n\n  <!-- BR-053's re-check before an Add (#743), on a new sequence only: a standing fact, so `status`. -->\n  @if (openOutcome(); as found) {\n    @if (found.kind !== 'success') {\n      <div\n        class=\"scoular-alert\"\n        [class.scoular-alert-warning]=\"found.kind !== 'unchecked'\"\n        [class.scoular-alert-info]=\"found.kind === 'unchecked'\"\n        role=\"status\"\n        [attr.data-outcome]=\"found.kind\"\n      >\n        <div class=\"scoular-alert-title\">{{ found.title }}</div>\n        <div class=\"scoular-alert-description\">{{ found.message }}</div>\n      </div>\n    }\n  }\n\n  @if (!canEditPricing()) {\n    <p role=\"status\" class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n      This account can view price sequences but not change them. Pricing needs the\n      <strong>Admin</strong> role on this application.\n    </p>\n  } @else if (writeRefusal(); as refusal) {\n    <p role=\"status\" class=\"cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n      {{ refusal }}\n    </p>\n  }\n\n  <!-- The last write's outcome (#803); a refusal carries its reasons and the server's reference. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\n    @if (writeFormErrors().length > 0) {\n      <ul class=\"cws:mt-2 cws:list-disc cws:space-y-1 cws:pl-5\">\n        @for (reason of writeFormErrors(); track reason) {\n          <li>{{ reason }}</li>\n        }\n      </ul>\n    }\n  </cms-status-message>\n\n  @if (unverified(); as message) {\n    <!-- Accepted, state unknown: deliberately NOT an error, or the same price gets entered twice. -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n      <div class=\"scoular-alert-title\">Saved, but not confirmed</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (deleteNotApplied(); as message) {\n    <!-- #156: the delete answered 202 and the re-read still lists the sequence. -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\n      <div class=\"scoular-alert-title\">The delete did not take effect</div>\n      <div class=\"scoular-alert-description\">{{ message }}</div>\n    </div>\n  }\n\n  @if (lastAcknowledgement(); as message) {\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n      <div class=\"scoular-alert-description\">CTRM said: {{ message }}</div>\n    </div>\n  }\n\n  @if (isNew() && editing()) {\n    <ng-container *ngTemplateOutlet=\"editor\" />\n  } @else {\n    <cms-async-container\n      [data]=\"state()\"\n      [empty]=\"missing()\"\n      [emptyMessage]=\"'Price sequence ' + (seq() ?? '') + ' is not on this contract. It may have been removed.'\"\n      loadingLabel=\"Loading the price sequence\"\n      (retry)=\"refresh()\"\n    >\n      @if (row(); as current) {\n        @if (editing()) {\n          <ng-container *ngTemplateOutlet=\"editor\" />\n        } @else {\n          <!-- The view: every field the editor shows, read-only and in the editor's layout. -->\n          <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\">\n            <dl class=\"cws:grid cws:grid-cols-1 cws:gap-4 cws:sm:grid-cols-2 cws:2xl:grid-cols-4\">\n              @for (field of viewFields(); track field.label) {\n                <div class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\" [class.cws:sm:col-span-2]=\"field.wide\">\n                  <dt class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">{{ field.label }}</dt>\n                  <dd class=\"cws:min-h-5 cws:text-slate-900 cws:dark:text-white\">{{ field.value }}</dd>\n                </div>\n              }\n            </dl>\n\n            <div\n              class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:border-t cws:border-slate-200 cws:pt-3 cws:dark:border-slate-700\"\n            >\n              <p class=\"cws:text-sm\">\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">Flat price (basis + adjustments + futures):</span>\n                <strong class=\"cws:ml-2 cws:text-slate-900 cws:dark:text-white\">{{ viewFlatPrice() | number: '1.4-5' }}</strong>\n                @if (current.adjustments) {\n                  <span class=\"cws:ml-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                    includes adjustments {{ current.adjustments | number: '1.4-5' }}\n                  </span>\n                }\n              </p>\n              @if (storedPriceDisagrees()) {\n                <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-scoular-yellow\">\n                  This differs from the price CTRM has stored for this sequence.\n                </p>\n              }\n            </div>\n          </div>\n        }\n      }\n    </cms-async-container>\n  }\n\n  <ng-template #editor>\n    @if (draft(); as editing) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\">\n        @if (editing.isNew) {\n          <!-- No number is shown: an add sends 0 and CTRM assigns the number on save (CQ00132, #581). -->\n          <p class=\"cws:mb-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            CTRM assigns the sequence number on save.\n          </p>\n        }\n\n        <div class=\"cws:grid cws:grid-cols-1 cws:gap-4 cws:sm:grid-cols-2 cws:2xl:grid-cols-4\">\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Priced quantity *</span>\n            <input\n              type=\"text\"\n              inputmode=\"decimal\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.pricedQuantity\"\n              (input)=\"patchText('pricedQuantity', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Loads</span>\n            <input\n              type=\"text\"\n              inputmode=\"numeric\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.pricedLoads\"\n              (input)=\"patchText('pricedLoads', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Futures price</span>\n            <input\n              type=\"text\"\n              inputmode=\"decimal\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.hedgePrice\"\n              (input)=\"patchText('hedgePrice', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Basis</span>\n            <input\n              type=\"text\"\n              inputmode=\"decimal\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.basisPrice\"\n              (input)=\"patchText('basisPrice', $any($event.target).value)\"\n            />\n            @if (isNew()) {\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                Defaults to the contract’s basis. You can change it.\n              </span>\n            }\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market code</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.hedgeMarketCode\"\n              (input)=\"patch('hedgeMarketCode', $any($event.target).value)\"\n            />\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              @if (isNew()) {\n                The market code and month default to the contract’s. You can change them; left blank,\n                CTRM uses the contract’s.\n              } @else {\n                The hedge market and month for this sequence, typed as CTRM stores them.\n              }\n            </span>\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market month</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.hedgeMarketMonthCode\"\n              (input)=\"patch('hedgeMarketMonthCode', $any($event.target).value)\"\n            />\n          </label>\n\n          <!-- The shared C3 date control (BR-020's typed shapes), patched field by field. -->\n          <cms-date-input\n            label=\"Price date\"\n            controlId=\"price-sequence-price-date\"\n            [ngModel]=\"editing.priceDate\"\n            (ngModelChange)=\"patch('priceDate', $event)\"\n          />\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Description</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.description\"\n              (input)=\"patch('description', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:flex-col cws:gap-2 cws:text-sm cws:sm:col-span-2\">\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Remark</span>\n            <input\n              type=\"text\"\n              class=\"scoular-form-input\"\n              [value]=\"editing.remark\"\n              (input)=\"patch('remark', $any($event.target).value)\"\n            />\n          </label>\n\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm\">\n            <input\n              type=\"checkbox\"\n              [checked]=\"editing.printFlag\"\n              (change)=\"patch('printFlag', $any($event.target).checked)\"\n            />\n            <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Print on confirmation</span>\n          </label>\n        </div>\n\n        <!-- BR-050, live. `role=\"status\"` so a screen reader hears the total change. -->\n        <div\n          class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:border-t cws:border-slate-200 cws:pt-3 cws:dark:border-slate-700\"\n        >\n          <p class=\"cws:text-sm\" role=\"status\">\n            <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">Flat price (basis + adjustments + futures):</span>\n            <strong class=\"cws:ml-2 cws:text-slate-900 cws:dark:text-white\">{{ draftFlatPrice() | number: '1.4-5' }}</strong>\n            @if (editing.adjustments) {\n              <span class=\"cws:ml-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                includes adjustments {{ editing.adjustments | number: '1.4-5' }}\n              </span>\n            }\n          </p>\n\n          @if (storedPriceDisagrees()) {\n            <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-scoular-yellow\">\n              This differs from the price CTRM has stored for this sequence.\n            </p>\n          }\n        </div>\n\n        <div class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n            [disabled]=\"!canSave() || busy() || writeRefusal() !== null\"\n            [attr.title]=\"writeRefusal() ?? addHeld()\"\n            (click)=\"save()\"\n          >\n            {{ busy() ? 'Saving…' : 'Save sequence' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"cancel()\">\n            Cancel\n          </button>\n\n          @if (addHeld(); as reason) {\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ reason }}</span>\n          } @else if (!canSave()) {\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              A priced quantity greater than zero is required.\n            </span>\n          }\n        </div>\n      </div>\n    }\n  </ng-template>\n</section>\n"
		}]
	}],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}],
		seq: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "seq",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		onBeforeUnload: [{
			type: HostListener,
			args: ["window:beforeunload", ["$event"]]
		}],
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	}
});
function draftOf(row) {
	return {
		priceSequence: row.priceSequence,
		isNew: false,
		pricedQuantity: String(row.pricedQuantity),
		pricedLoads: String(row.pricedLoads),
		hedgePrice: String(row.hedgePrice),
		basisPrice: String(row.basisPrice),
		adjustments: row.adjustments,
		hedgeMarketCode: row.hedgeMarketCode ?? "",
		hedgeMarketMonthCode: row.hedgeMarketMonth ?? "",
		priceDate: row.priceDate ?? "",
		description: row.priceDescription ?? "",
		remark: row.remark ?? "",
		printFlag: (row.printFlag ?? "Y").toUpperCase() !== "N"
	};
}
function numberedByCtrm(before, after) {
	const added = after.filter((each) => !before.has(each.priceSequence));
	return added.length === 1 ? added[0].priceSequence : null;
}
function arrivalOf(written, success) {
	return written.verified ? {
		prices: written.prices,
		outcome: mutationSucceeded(`${success} CTRM said: ${written.acknowledgement}`),
		unverified: null,
		acknowledgement: null
	} : {
		prices: null,
		outcome: null,
		unverified: "CTRM accepted the change but we could not read the prices back, so what is shown may be out of date. Refresh to confirm.",
		acknowledgement: written.acknowledgement
	};
}
function amount(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
}
function price(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", {
		minimumFractionDigits: 4,
		maximumFractionDigits: 5
	});
}
function textOf(value) {
	return typeof value === "string" ? value.trim() : "";
}
function numberOrNull(raw) {
	const trimmed = raw.trim();
	if (trimmed === "") return null;
	const parsed = Number(trimmed);
	return Number.isFinite(parsed) ? parsed : null;
}
function formatPrice(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", {
		minimumFractionDigits: 4,
		maximumFractionDigits: 5
	});
}
function formatAmount(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
}
const APPROVAL_QUEUE_COLUMNS = [
	{
		key: "contract",
		header: "Contract",
		format: (row) => row.contract
	},
	{
		key: "priceSequence",
		header: "Seq",
		format: (row) => String(row.priceSequence),
		sortValue: (row) => row.priceSequence
	},
	{
		key: "pricedQuantity",
		header: "Priced qty",
		format: (row) => formatAmount(row.pricedQuantity),
		sortValue: (row) => row.pricedQuantity
	},
	{
		key: "pricedLoads",
		header: "Loads",
		format: (row) => String(row.pricedLoads),
		sortValue: (row) => row.pricedLoads
	},
	{
		key: "price",
		header: "Flat price",
		format: (row) => formatPrice(row.price),
		sortValue: (row) => row.price
	},
	{
		key: "hedgePrice",
		header: "Futures",
		format: (row) => formatPrice(row.hedgePrice),
		sortValue: (row) => row.hedgePrice
	},
	{
		key: "hedgeMarketCode",
		header: "Market",
		format: (row) => row.hedgeMarketCode ?? ""
	},
	{
		key: "hedgeMarketMonth",
		header: "Month",
		format: (row) => row.hedgeMarketMonth ?? ""
	},
	{
		key: "priceDate",
		header: "Price date",
		format: (row) => formatShortDate(row.priceDate),
		sortValue: (row) => row.priceDate ?? ""
	},
	{
		key: "traderInitials",
		header: "Trader",
		format: (row) => row.traderInitials ?? ""
	},
	{
		key: "approverInitials",
		header: "Approver",
		format: (row) => row.approverInitials ?? ""
	},
	{
		key: "approvalTimestamp",
		header: "Approved",
		format: (row) => formatShortDate(row.approvalTimestamp),
		sortValue: (row) => row.approvalTimestamp ?? ""
	}
];
const NOT_DEPLOYED = { kind: "notDeployed" };
var PricingApprovalsPageComponent = class PricingApprovalsPageComponent {
	source = inject(PRICING_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	canApprove = computed(() => this.permissions.canApproveContracts(), ...ngDevMode ? [{ debugName: "canApprove" }] : /* istanbul ignore next */ []);
	writeRefusal = computed(() => this.permissions.writeRefusal?.()?.message ?? null, ...ngDevMode ? [{ debugName: "writeRefusal" }] : /* istanbul ignore next */ []);
	columns = APPROVAL_QUEUE_COLUMNS;
	columnChoice = gridColumnChoice(APPROVAL_QUEUE_COLUMNS, "pricing.approvals", ["contract"]);
	sorts = signal([], ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	search = signal("", ...ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []);
	emptyMessage = computed(() => {
		const settled = this.queueState().settled;
		if (settled?.kind === "refused") return settled.title;
		if (this.mode() === "approver") return this.approver()?.traderInitials === null ? "Your CTRM user has no trader initials, so no pricing record names you." : "Nothing is awaiting your pricing approval.";
		return this.hasScope() ? "Nothing is awaiting pricing approval in this trade unit." : "Choose a trade unit in the top bar to load the approval queue.";
	}, ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	reload = signal(0, ...ngDevMode ? [{ debugName: "reload" }] : /* istanbul ignore next */ []);
	queueSource = inject(PRICING_APPROVAL_QUEUE_SOURCE, { optional: true });
	queueRouteAbsent = this.queueSource === null;
	queueState = toSignal((this.queueSource === null ? of(NOT_DEPLOYED) : this.queueReads(this.queueSource)).pipe(scan((state, next) => next === "loading" ? {
		...state,
		loading: true
	} : {
		settled: next,
		loading: false
	}, {
		settled: null,
		loading: true
	}), startWith({
		settled: null,
		loading: true
	})), { requireSync: true });
	queueReads(source) {
		return toObservable(this.reload).pipe(scan((previous, attempt) => ({
			attempt,
			refresh: attempt !== previous.attempt
		}), {
			attempt: 0,
			refresh: false
		}), switchMap(({ refresh }) => this.queueRouteAbsent ? of(NOT_DEPLOYED) : source.read({ refresh }).pipe(tap((read) => {
			if (read.kind === "notDeployed") this.queueRouteAbsent = true;
		}), startWith("loading"))));
	}
	mode = computed(() => {
		switch (this.queueState().settled?.kind) {
			case void 0: return "pending";
			case "notDeployed": return "tradeUnit";
			case "refused": return "refused";
			default: return "approver";
		}
	}, ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	approver = computed(() => {
		const settled = this.queueState().settled;
		return settled?.kind === "loaded" ? settled.approver : null;
	}, ...ngDevMode ? [{ debugName: "approver" }] : /* istanbul ignore next */ []);
	refusalDismissed = signal(false, ...ngDevMode ? [{ debugName: "refusalDismissed" }] : /* istanbul ignore next */ []);
	refusal = computed(() => {
		const settled = this.queueState().settled;
		return settled?.kind === "refused" && !this.refusalDismissed() ? {
			kind: "failure",
			message: `${settled.title}\n${settled.detail}`,
			sent: true,
			correlationId: settled.correlationId
		} : null;
	}, ...ngDevMode ? [{ debugName: "refusal" }] : /* istanbul ignore next */ []);
	refusalDetail = computed(() => {
		const settled = this.queueState().settled;
		return settled?.kind === "refused" ? settled.detail : "";
	}, ...ngDevMode ? [{ debugName: "refusalDetail" }] : /* istanbul ignore next */ []);
	dismissRefusal() {
		this.refusalDismissed.set(true);
	}
	scopeSummary = computed(() => {
		switch (this.mode()) {
			case "approver": return "Your CTRM pricing approval queue";
			case "refused": return "Your pricing approval queue could not be shown";
			case "tradeUnit": return "Scoped to one trade unit";
			default: return null;
		}
	}, ...ngDevMode ? [{ debugName: "scopeSummary" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	message = signal(null, ...ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []);
	failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	query = computed(() => ({ location: this.tradeUnit.code() ?? void 0 }), ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	hasScope = computed(() => this.mode() === "tradeUnit" ? this.query().location !== void 0 : this.mode() !== "pending", ...ngDevMode ? [{ debugName: "hasScope" }] : /* istanbul ignore next */ []);
	loaded = toSignal(toObservable(computed(() => ({
		query: this.query(),
		byTradeUnit: this.mode() === "tradeUnit",
		nonce: this.reload()
	}))).pipe(switchMap(({ query, byTradeUnit }) => !byTradeUnit || query.location === void 0 ? of(remoteLoading()) : this.source.unapproved(query))), { initialValue: remoteLoading() });
	state = computed(() => {
		const settled = this.queueState().settled;
		switch (this.mode()) {
			case "pending": return remoteLoading();
			case "refused": return {
				status: "loaded",
				value: emptyPrices()
			};
			case "approver":
				if (settled?.kind === "loaded") return {
					status: "loaded",
					value: settled.prices
				};
				return settled?.kind === "failed" ? remoteError({
					message: settled.message,
					correlationId: settled.correlationId ?? void 0
				}) : remoteLoading();
			default: return this.hasScope() ? this.loaded() : {
				status: "loaded",
				value: emptyPrices()
			};
		}
	}, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	mayBeTruncated = computed(() => {
		const state = this.state();
		return state.status === "loaded" && state.value.mayBeTruncated;
	}, ...ngDevMode ? [{ debugName: "mayBeTruncated" }] : /* istanbul ignore next */ []);
	truncationCeiling = computed(() => {
		const state = this.state();
		return state.status === "loaded" ? state.value.truncationCeiling : 0;
	}, ...ngDevMode ? [{ debugName: "truncationCeiling" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [
		...this.scopeSummary() === null ? [] : [this.scopeSummary()],
		...this.showSystemNotices() && this.mayBeTruncated() ? ["CTRM may have sent fewer rows than exist"] : [],
		...this.canApprove() ? [] : ["This account cannot approve pricing"]
	], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	showSystemNotices = computed(() => this.permissions.canSeeSystemNotices?.() ?? false, ...ngDevMode ? [{ debugName: "showSystemNotices" }] : /* istanbul ignore next */ []);
	queue = computed(() => {
		const state = this.state();
		if (state.status !== "loaded") return [];
		const all = state.value.prices;
		const term = this.search().trim();
		const group = this.filter();
		const kept = all.filter((row) => matchesGroup(row, this.columns, group) && (term === "" || matchesSearch(row, this.columns, term)));
		const chain = this.sorts();
		return chain.length === 0 ? kept : [...kept].sort((left, right) => compareBySorts(this.columns, chain, left, right));
	}, ...ngDevMode ? [{ debugName: "queue" }] : /* istanbul ignore next */ []);
	pageSize = DEFAULT_PAGE_SIZE;
	page = signal(1, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	totalPages = computed(() => Math.max(1, Math.ceil(this.queue().length / this.pageSize)), ...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	currentPage = computed(() => Math.min(Math.max(this.page(), 1), this.totalPages()), ...ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const start = (this.currentPage() - 1) * this.pageSize;
		return this.queue().slice(start, start + this.pageSize);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	onPage(page) {
		this.page.set(page);
	}
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportFilename = (scope) => {
		return `pricing-approvals-${this.mode() === "approver" ? "mine" : this.tradeUnit.code() ?? "all"}-${scope === "page" ? `page-${this.currentPage()}` : "all"}`;
	};
	exportAllRows = () => Promise.resolve(this.queue());
	filter = signal(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	savedFilterScope = SAVED_FILTER_SCOPES.pricingApprovals;
	onRulesChange(group) {
		this.filter.set(group);
		this.page.set(1);
	}
	onSearch(term) {
		this.search.set(term);
		this.page.set(1);
	}
	onViewChange(view) {
		this.filter.set(view.group);
		this.columnChoice.applyView(view.columns);
		this.sorts.set(view.sort);
		this.page.set(1);
	}
	selected = signal(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	keyOf(row) {
		return `${row.contract}|${row.priceSequence}`;
	}
	isSelected(row) {
		return this.selected().has(this.keyOf(row));
	}
	toggle(row) {
		const key = this.keyOf(row);
		const next = new Set(this.selected());
		if (!next.delete(key)) next.add(key);
		this.selected.set(next);
	}
	clearSelection() {
		this.selected.set(/* @__PURE__ */ new Set());
	}
	selectVisible() {
		this.selected.set(new Set(this.rows().map((row) => this.keyOf(row))));
	}
	onRowToggle(row) {
		if (!this.busy()) this.toggle(row);
	}
	onSelectAll() {
		if (!this.busy()) this.selectVisible();
	}
	constructor() {
		registerShortcuts([{
			keys: "space",
			scope: "feature",
			label: "Select or clear the focused row",
			group: "Grids",
			available: () => this.canApprove()
		}, {
			keys: "ctrl+a",
			scope: "feature",
			label: "Select every row shown",
			group: "Grids",
			available: () => this.canApprove()
		}]);
	}
	selectedCount = computed(() => {
		const keys = this.selected();
		return this.rows().filter((row) => keys.has(this.keyOf(row))).length;
	}, ...ngDevMode ? [{ debugName: "selectedCount" }] : /* istanbul ignore next */ []);
	selectionByContract() {
		const keys = this.selected();
		const grouped = /* @__PURE__ */ new Map();
		for (const row of this.rows()) {
			if (!keys.has(this.keyOf(row))) continue;
			const existing = grouped.get(row.contract);
			if (existing) existing.push(row.priceSequence);
			else grouped.set(row.contract, [row.priceSequence]);
		}
		return grouped;
	}
	approveOne(row) {
		this.selected.set(/* @__PURE__ */ new Set([this.keyOf(row)]));
		this.approveSelected();
	}
	async approveSelected() {
		if (this.busy() || this.selectedCount() === 0) return;
		this.busy.set(true);
		this.message.set(null);
		this.failure.set(null);
		const grouped = this.selectionByContract();
		const approved = [];
		let failedContract = null;
		let failureReason = "";
		let failureReference;
		for (const [contract, sequences] of grouped) {
			const result = await firstLoadedValue(this.source.approve(contract, sequences));
			if (result.status !== "loaded") {
				failedContract = contract;
				failureReason = result.status === "error" ? result.error.message : "The approval did not complete.";
				failureReference = result.status === "error" ? result.error.correlationId : void 0;
				break;
			}
			approved.push(`${contract} (${sequences.length})`);
		}
		this.busy.set(false);
		this.clearSelection();
		this.reload.update((value) => value + 1);
		if (approved.length > 0) this.message.set(mutationSucceeded(`Approved: ${approved.join(", ")}.`));
		if (failedContract !== null) this.failure.set(mutationFailed({
			message: `The approval run stopped part-way. ${contractCount(approved.length)} before ${failedContract} failed: ${failureReason} Approvals already made cannot be undone — re-check the queue before retrying.`,
			correlationId: failureReference
		}));
	}
	refresh() {
		this.message.set(null);
		this.failure.set(null);
		this.clearSelection();
		this.reload.update((value) => value + 1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PricingApprovalsPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PricingApprovalsPageComponent,
		isStandalone: true,
		selector: "cms-pricing-approvals-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Pricing approvals\"\n    description=\"Price sequences awaiting approval. Approval cannot be undone.\"\n  >\n    <!--\n      ⚠ **Refresh MOVED to the grid toolbar** (JFrisbie, 2026-09-17). It was the shared control\n      already, but it was the only one of the four grids putting it in the page header, and the\n      toolbar is now one standard set on every grid. Nothing is left in the header actions slot\n      here, so the slot itself is gone rather than left rendering an empty box.\n    -->\n  </cms-page-header>\n\n  <cms-grid-toolbar>\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-md\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        placeholder=\"Search every column\"\n        [value]=\"search()\"\n        (input)=\"onSearch($any($event.target).value)\"\n      />\n    </label>\n\n    <!-- Saved views and the rule builder, under this grid own scope. Width on the wrapper, never\n         the control: .scoular-form-input is @apply w-full and the design system compiles unlayered. -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [columnLayout]=\"columnChoice.layout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <button type=\"button\" class=\"scoular-btn scoular-btn-outline cws:shrink-0\" (click)=\"builder.beginAdd()\">\n      + Add filter\n    </button>\n\n    <!--\n      🔴 **The Trader box and the Approver type dropdown stood here and are GONE** (JFrisbie,\n      2026-09-17). The toolbar is now one standard set on every grid — search, view, add filter,\n      clear sort, export, refresh, pager — and nothing else.\n\n      ⚠ **The Trader box was an entry path, not a narrowing.** It was the only way to load this queue\n      with no trade unit selected, because the route needs a trader OR a location. It now needs a\n      trade unit; the empty state says so. Both this and the approver type remain request parameters\n      the source still accepts, so either control is a template change away from returning.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"sorts.set($event)\" />\n\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\n      <!-- Columns, beside the export it shapes, where Home has it (JFrisbie, 2026-10-23). -->\n      <cms-grid-column-menu\n        [fields]=\"columnChoice.fields()\"\n        [lockedKeys]=\"columnChoice.locked()\"\n        [keptIn]=\"columnChoice.keptIn()\"\n        [failure]=\"columnChoice.failure()\"\n        resetLabel=\"Show every column\"\n        (fieldsChange)=\"columnChoice.change($event)\"\n        (reset)=\"columnChoice.reset()\"\n      />\n      <!--\n        Export, the same shared control as the other three grids. Both scopes are cheap here — the\n        route has no paging at all, so the whole queue is in memory — and the choice is still offered,\n        because \"this page\" and \"everything matched\" are different files now that the grid pages.\n      -->\n      <cms-grid-export\n        [columns]=\"columns\"\n        [visibleKeys]=\"columnChoice.shownKeys()\"\n        [pageRows]=\"rows()\"\n        [totalCount]=\"queue().length\"\n        [allRows]=\"exportAllRows\"\n        [filename]=\"exportFilename\"\n        [disabled]=\"!hasScope() || queue().length === 0\"\n        (failed)=\"exportError.set($event)\"\n      />\n\n      <cms-refresh-button\n        label=\"Refresh pricing approvals\"\n        [busy]=\"busy()\"\n        [disabled]=\"!hasScope()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <cms-pager\n        [page]=\"currentPage()\"\n        [totalPages]=\"totalPages()\"\n        position=\"top\"\n        (goTo)=\"onPage($event)\"\n      />\n    </div>\n  </cms-grid-toolbar>\n\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onRulesChange($event)\"\n  />\n\n  <!--\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\n    failed export is the outcome of something the user just did.\n  -->\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    🔴 ONE presentation of the precondition, through the container, matching every other screen.\n\n    This was a tinted `scoular-alert-info` with a title, which read as a NOTICE about the data\n    rather than as the absence of any. CTRM refuses this route with neither a trader nor a location,\n    so the screen still issues no request -- only the way it says so has changed.\n  -->\n    <!-- #803: what was approved, said once the run ends. -->\n    <cms-status-message [outcome]=\"message()\" (dismissed)=\"message.set(null)\" />\n\n    <!--\n      🔴 A partial failure, reported as one. Approval has no inverse, so a run that stopped part-way\n      has already committed everything before the failure — naming what succeeded is what stops the\n      user retrying the whole selection and being refused on the half that went through. #803: with\n      the server's reference.\n    -->\n    <cms-status-message [outcome]=\"failure()\" (dismissed)=\"failure.set(null)\" />\n\n    <!-- #1170: the server could not tell who the user is in CTRM; its title, detail and reference. -->\n    <cms-status-message [outcome]=\"refusal()\" (dismissed)=\"dismissRefusal()\" />\n\n    <!--\n      The standing notice, in the shared collapsible panel.\n\n      ⚠ **The success and failure messages above are deliberately NOT in it.** The panel is for\n      standing conditions — environment, data origin, capability gaps — and never for the outcome of\n      something the user just did. An approval run that stopped part-way has already committed half\n      its selection; behind a collapsed panel that is a message nobody reads.\n    -->\n    <cms-notices-panel [summaries]=\"noticeSummaries()\" [systemNotices]=\"showSystemNotices()\">\n      <!--\n        🔴 The scope statement (#1170), and it always says which scope is on screen. The approver's\n        pricing queue is the sequences whose pricing record names them as the trader, in every trade\n        unit (#1168). When the route is not on the server, what is on screen is a whole trade unit,\n        every approver's sequences in it, and the sentence says so.\n      -->\n      @switch (mode()) {\n        @case ('approver') {\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n            <div class=\"scoular-alert-title\">Showing your CTRM pricing approval queue</div>\n            <div class=\"scoular-alert-description\">\n              @if (approver()?.traderInitials; as initials) {\n                CTRM lists the price sequences whose pricing record names you ({{ initials }}) as the\n                trader, in every trade unit. The trade unit selected above does not narrow it.\n              } @else if (approver()) {\n                Your CTRM user has no trader initials, so no pricing record names you and CTRM lists no\n                price sequences for you to approve.\n              } @else {\n                CTRM lists the price sequences whose pricing record names you as the trader, in every\n                trade unit. The trade unit selected above does not narrow it.\n              }\n              @if (approver()?.approverType === 'PRIMARY') {\n                Sequences you cover as a backup approver for another trader are not included.\n              } @else if (approver()?.approverType === 'BOTH') {\n                It also includes the sequences you cover as a backup approver.\n              }\n            </div>\n          </div>\n        }\n        @case ('refused') {\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n            <div class=\"scoular-alert-title\">Your pricing approval queue could not be shown</div>\n            <div class=\"scoular-alert-description\">\n              Your pricing approval queue is the price sequences whose pricing record names you as the\n              trader, and we could not match you to exactly one CTRM user. {{ refusalDetail() }}\n            </div>\n          </div>\n        }\n        @case ('tradeUnit') {\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n            <div class=\"scoular-alert-title\">Showing one trade unit, not your pricing approval queue</div>\n            <div class=\"scoular-alert-description\">\n              Your pricing approval queue is the price sequences whose pricing record names you as the\n              trader, in every trade unit. That queue is not available here yet, so this screen shows\n              every unapproved sequence in the trade unit selected above, whoever approves it:\n              <strong>sequences awaiting you in other trade units are not listed here</strong>.\n            </div>\n          </div>\n        }\n      }\n      <!-- #1223: a system caveat, the Admin role's only. -->\n      @if (showSystemNotices() && mayBeTruncated()) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">This queue may be incomplete</div>\n          <div class=\"scoular-alert-description\">\n            <!--\n              ⚠ The advice used to read \"narrow by trader\", and that box came off the toolbar on\n              2026-09-17 — so the sentence named a control the screen no longer has. A filter rule on\n              Trader narrows what is DISPLAYED and cannot make CTRM send more, which is the honest\n              thing to say rather than pointing at a workaround that no longer exists.\n            -->\n            CTRM returns at most {{ truncationCeiling() }} rows for this queue and does not say when\n            it has more, so rows may be missing before any filter is applied.\n          </div>\n        </div>\n      }\n      <!--\n        ⚠ Projected content AND a summary line, always both. `cms-notices-panel` gates the whole\n        panel on the summary count, so content added here without a matching summary is not\n        merely uncounted — it is not rendered at all.\n      -->\n      @if (!canApprove()) {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n          <div class=\"scoular-alert-title\">Read-only for this account</div>\n          <div class=\"scoular-alert-description\">\n            You can see the unapproved queue but not commit an approval. Approving needs the\n            <strong>Admin</strong> role on this application.\n          </div>\n        </div>\n      }\n    </cms-notices-panel>\n\n    <!--\n      🔴 The whole decision toolbar, gated as one (F4.3a).\n\n      Selecting rows is only ever a prelude to approving them, so leaving the selection controls\n      behind a hidden Approve would be a gesture that collects rows and then has nowhere to send\n      them. The notices panel above carries the reason.\n    -->\n    @if (canApprove()) {\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n          [disabled]=\"selectedCount() === 0 || busy() || writeRefusal() !== null\"\n          [attr.title]=\"writeRefusal()\"\n          (click)=\"approveSelected()\"\n        >\n          {{ busy() ? 'Approving…' : 'Approve ' + selectedCount() + ' selected' }}\n        </button>\n\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          [disabled]=\"rows().length === 0 || busy()\"\n          (click)=\"selectVisible()\"\n        >\n          <!--\n            ⚠ \"these N\", never \"all\". With a filter applied, \"all\" reads as the whole queue — and\n            approving something you cannot see is the one mistake this screen cannot undo.\n          -->\n          Select these {{ rows().length }}\n        </button>\n\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          [disabled]=\"selectedCount() === 0 || busy()\"\n          (click)=\"clearSelection()\"\n        >\n          Clear selection\n        </button>\n\n        <!--\n          #884: the count, announced when Space or Ctrl+A changes it on a grid row, where the ticked\n          box may be off screen. Not cms-status-message: that is for the outcome of a mutation, and\n          selecting rows commits nothing. Hidden, as the Approve button already shows the number.\n        -->\n        <p class=\"cws:sr-only\" aria-live=\"polite\">{{ selectedCount() }} of {{ rows().length }} selected</p>\n\n        @if (writeRefusal(); as refusal) {\n          <!-- #411: the approvals stay, disabled; this is their reason, said once beside them. -->\n          <p role=\"status\" class=\"cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\n            {{ refusal }}\n          </p>\n        }\n      </div>\n    }\n\n    <!-- `(retry)` bound and the empty state routed through the container. See the pricing detail\n         screen for why both matter. -->\n    <cms-async-container\n      [data]=\"state()\"\n      [empty]=\"!hasScope() || rows().length === 0\"\n      [emptyMessage]=\"emptyMessage()\"\n      loadingLabel=\"Loading pricing approvals\"\n      (retry)=\"refresh()\"\n    >\n      @if (rows().length > 0) {\n        <!-- Tone-free, so the stripe cannot compete with a semantic tint — see the pricing queue. -->\n        <cms-data-grid\n          [rows]=\"rows()\"\n          [columns]=\"columnChoice.shown()\"\n          label=\"Price sequences awaiting approval\"\n          [columnMenu]=\"false\"\n          [striped]=\"true\"\n          [sorts]=\"sorts()\"\n          [selectable]=\"canApprove()\"\n          (sortChange)=\"sorts.set($event)\"\n          (rowToggle)=\"onRowToggle($event)\"\n          (selectAll)=\"onSelectAll()\"\n        />\n\n        <!--\n          Selection lives beside the grid rather than inside it: the shared grid renders columns from\n          data and has no concept of a row action, and giving it one for this screen would put a\n          checkbox column into every grid in the application.\n        -->\n        <ul class=\"cws:mt-3 cws:flex cws:flex-col cws:gap-1\">\n          @for (row of rows(); track row.contract + '|' + row.priceSequence) {\n            <li class=\"cws:flex cws:items-center cws:gap-3 cws:text-sm\">\n              <label class=\"cws:flex cws:items-center cws:gap-2\">\n                <input\n                  type=\"checkbox\"\n                  [checked]=\"isSelected(row)\"\n                  [disabled]=\"busy()\"\n                  (change)=\"toggle(row)\"\n                />\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">\n                  {{ row.contract }} · seq {{ row.priceSequence }}\n                </span>\n              </label>\n\n              @if (canApprove()) {\n                <button\n                  type=\"button\"\n                  class=\"cws:min-h-6 cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:dark:text-sky-400\"\n                  [disabled]=\"busy() || writeRefusal() !== null\"\n                  [attr.title]=\"writeRefusal()\"\n                  (click)=\"approveOne(row)\"\n                >\n                  Approve this one\n                </button>\n              }\n            </li>\n          }\n        </ul>\n\n        <!--\n          The footer pager and the range, matching the other three grids.\n\n          🔴 **Both numbers are about the QUEUE, not the page** — a user deciding whether they have\n          seen everything is asking about the queue, and \"1-50 of 50\" on a 2,000-row queue is the\n          claim that would mislead them. The grid above renders the page; this says how much of the\n          queue that is.\n        -->\n        <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-2\">\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            Showing {{ rows().length }} of {{ queue().length }} awaiting approval\n          </p>\n\n          <cms-pager\n            [page]=\"currentPage()\"\n            [totalPages]=\"totalPages()\"\n            position=\"bottom\"\n            (goTo)=\"onPage($event)\"\n          />\n        </div>\n      }\n    </cms-async-container>\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel",
					"columnLayout"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"columnMenu",
					"columnsKey",
					"lockedColumns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"rowLabel",
					"activateLabel",
					"selectable",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep",
					"rowToggle",
					"selectAll"
				]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridColumnMenuComponent,
				selector: "cms-grid-column-menu",
				inputs: [
					"fields",
					"lockedKeys",
					"keptIn",
					"failure",
					"disabled",
					"resetLabel"
				],
				outputs: ["fieldsChange", "reset"]
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"visibleKeys",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"systemNotices",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PricingApprovalsPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pricing-approvals-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FilterBuilderComponent,
				FilterSelectComponent,
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				SearchShortcutDirective,
				GridColumnMenuComponent,
				GridExportComponent,
				GridToolbarComponent,
				NoticesPanelComponent,
				PageHeaderComponent,
				PagerComponent,
				RefreshButtonComponent,
				StatusMessageComponent
			],
			template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Pricing approvals\"\n    description=\"Price sequences awaiting approval. Approval cannot be undone.\"\n  >\n    <!--\n      ⚠ **Refresh MOVED to the grid toolbar** (JFrisbie, 2026-09-17). It was the shared control\n      already, but it was the only one of the four grids putting it in the page header, and the\n      toolbar is now one standard set on every grid. Nothing is left in the header actions slot\n      here, so the slot itself is gone rather than left rendering an empty box.\n    -->\n  </cms-page-header>\n\n  <cms-grid-toolbar>\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-md\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        placeholder=\"Search every column\"\n        [value]=\"search()\"\n        (input)=\"onSearch($any($event.target).value)\"\n      />\n    </label>\n\n    <!-- Saved views and the rule builder, under this grid own scope. Width on the wrapper, never\n         the control: .scoular-form-input is @apply w-full and the design system compiles unlayered. -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [columnLayout]=\"columnChoice.layout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <button type=\"button\" class=\"scoular-btn scoular-btn-outline cws:shrink-0\" (click)=\"builder.beginAdd()\">\n      + Add filter\n    </button>\n\n    <!--\n      🔴 **The Trader box and the Approver type dropdown stood here and are GONE** (JFrisbie,\n      2026-09-17). The toolbar is now one standard set on every grid — search, view, add filter,\n      clear sort, export, refresh, pager — and nothing else.\n\n      ⚠ **The Trader box was an entry path, not a narrowing.** It was the only way to load this queue\n      with no trade unit selected, because the route needs a trader OR a location. It now needs a\n      trade unit; the empty state says so. Both this and the approver type remain request parameters\n      the source still accepts, so either control is a template change away from returning.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"sorts.set($event)\" />\n\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\n      <!-- Columns, beside the export it shapes, where Home has it (JFrisbie, 2026-10-23). -->\n      <cms-grid-column-menu\n        [fields]=\"columnChoice.fields()\"\n        [lockedKeys]=\"columnChoice.locked()\"\n        [keptIn]=\"columnChoice.keptIn()\"\n        [failure]=\"columnChoice.failure()\"\n        resetLabel=\"Show every column\"\n        (fieldsChange)=\"columnChoice.change($event)\"\n        (reset)=\"columnChoice.reset()\"\n      />\n      <!--\n        Export, the same shared control as the other three grids. Both scopes are cheap here — the\n        route has no paging at all, so the whole queue is in memory — and the choice is still offered,\n        because \"this page\" and \"everything matched\" are different files now that the grid pages.\n      -->\n      <cms-grid-export\n        [columns]=\"columns\"\n        [visibleKeys]=\"columnChoice.shownKeys()\"\n        [pageRows]=\"rows()\"\n        [totalCount]=\"queue().length\"\n        [allRows]=\"exportAllRows\"\n        [filename]=\"exportFilename\"\n        [disabled]=\"!hasScope() || queue().length === 0\"\n        (failed)=\"exportError.set($event)\"\n      />\n\n      <cms-refresh-button\n        label=\"Refresh pricing approvals\"\n        [busy]=\"busy()\"\n        [disabled]=\"!hasScope()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <cms-pager\n        [page]=\"currentPage()\"\n        [totalPages]=\"totalPages()\"\n        position=\"top\"\n        (goTo)=\"onPage($event)\"\n      />\n    </div>\n  </cms-grid-toolbar>\n\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onRulesChange($event)\"\n  />\n\n  <!--\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\n    failed export is the outcome of something the user just did.\n  -->\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    🔴 ONE presentation of the precondition, through the container, matching every other screen.\n\n    This was a tinted `scoular-alert-info` with a title, which read as a NOTICE about the data\n    rather than as the absence of any. CTRM refuses this route with neither a trader nor a location,\n    so the screen still issues no request -- only the way it says so has changed.\n  -->\n    <!-- #803: what was approved, said once the run ends. -->\n    <cms-status-message [outcome]=\"message()\" (dismissed)=\"message.set(null)\" />\n\n    <!--\n      🔴 A partial failure, reported as one. Approval has no inverse, so a run that stopped part-way\n      has already committed everything before the failure — naming what succeeded is what stops the\n      user retrying the whole selection and being refused on the half that went through. #803: with\n      the server's reference.\n    -->\n    <cms-status-message [outcome]=\"failure()\" (dismissed)=\"failure.set(null)\" />\n\n    <!-- #1170: the server could not tell who the user is in CTRM; its title, detail and reference. -->\n    <cms-status-message [outcome]=\"refusal()\" (dismissed)=\"dismissRefusal()\" />\n\n    <!--\n      The standing notice, in the shared collapsible panel.\n\n      ⚠ **The success and failure messages above are deliberately NOT in it.** The panel is for\n      standing conditions — environment, data origin, capability gaps — and never for the outcome of\n      something the user just did. An approval run that stopped part-way has already committed half\n      its selection; behind a collapsed panel that is a message nobody reads.\n    -->\n    <cms-notices-panel [summaries]=\"noticeSummaries()\" [systemNotices]=\"showSystemNotices()\">\n      <!--\n        🔴 The scope statement (#1170), and it always says which scope is on screen. The approver's\n        pricing queue is the sequences whose pricing record names them as the trader, in every trade\n        unit (#1168). When the route is not on the server, what is on screen is a whole trade unit,\n        every approver's sequences in it, and the sentence says so.\n      -->\n      @switch (mode()) {\n        @case ('approver') {\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n            <div class=\"scoular-alert-title\">Showing your CTRM pricing approval queue</div>\n            <div class=\"scoular-alert-description\">\n              @if (approver()?.traderInitials; as initials) {\n                CTRM lists the price sequences whose pricing record names you ({{ initials }}) as the\n                trader, in every trade unit. The trade unit selected above does not narrow it.\n              } @else if (approver()) {\n                Your CTRM user has no trader initials, so no pricing record names you and CTRM lists no\n                price sequences for you to approve.\n              } @else {\n                CTRM lists the price sequences whose pricing record names you as the trader, in every\n                trade unit. The trade unit selected above does not narrow it.\n              }\n              @if (approver()?.approverType === 'PRIMARY') {\n                Sequences you cover as a backup approver for another trader are not included.\n              } @else if (approver()?.approverType === 'BOTH') {\n                It also includes the sequences you cover as a backup approver.\n              }\n            </div>\n          </div>\n        }\n        @case ('refused') {\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n            <div class=\"scoular-alert-title\">Your pricing approval queue could not be shown</div>\n            <div class=\"scoular-alert-description\">\n              Your pricing approval queue is the price sequences whose pricing record names you as the\n              trader, and we could not match you to exactly one CTRM user. {{ refusalDetail() }}\n            </div>\n          </div>\n        }\n        @case ('tradeUnit') {\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n            <div class=\"scoular-alert-title\">Showing one trade unit, not your pricing approval queue</div>\n            <div class=\"scoular-alert-description\">\n              Your pricing approval queue is the price sequences whose pricing record names you as the\n              trader, in every trade unit. That queue is not available here yet, so this screen shows\n              every unapproved sequence in the trade unit selected above, whoever approves it:\n              <strong>sequences awaiting you in other trade units are not listed here</strong>.\n            </div>\n          </div>\n        }\n      }\n      <!-- #1223: a system caveat, the Admin role's only. -->\n      @if (showSystemNotices() && mayBeTruncated()) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">This queue may be incomplete</div>\n          <div class=\"scoular-alert-description\">\n            <!--\n              ⚠ The advice used to read \"narrow by trader\", and that box came off the toolbar on\n              2026-09-17 — so the sentence named a control the screen no longer has. A filter rule on\n              Trader narrows what is DISPLAYED and cannot make CTRM send more, which is the honest\n              thing to say rather than pointing at a workaround that no longer exists.\n            -->\n            CTRM returns at most {{ truncationCeiling() }} rows for this queue and does not say when\n            it has more, so rows may be missing before any filter is applied.\n          </div>\n        </div>\n      }\n      <!--\n        ⚠ Projected content AND a summary line, always both. `cms-notices-panel` gates the whole\n        panel on the summary count, so content added here without a matching summary is not\n        merely uncounted — it is not rendered at all.\n      -->\n      @if (!canApprove()) {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\n          <div class=\"scoular-alert-title\">Read-only for this account</div>\n          <div class=\"scoular-alert-description\">\n            You can see the unapproved queue but not commit an approval. Approving needs the\n            <strong>Admin</strong> role on this application.\n          </div>\n        </div>\n      }\n    </cms-notices-panel>\n\n    <!--\n      🔴 The whole decision toolbar, gated as one (F4.3a).\n\n      Selecting rows is only ever a prelude to approving them, so leaving the selection controls\n      behind a hidden Approve would be a gesture that collects rows and then has nowhere to send\n      them. The notices panel above carries the reason.\n    -->\n    @if (canApprove()) {\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n          [disabled]=\"selectedCount() === 0 || busy() || writeRefusal() !== null\"\n          [attr.title]=\"writeRefusal()\"\n          (click)=\"approveSelected()\"\n        >\n          {{ busy() ? 'Approving…' : 'Approve ' + selectedCount() + ' selected' }}\n        </button>\n\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          [disabled]=\"rows().length === 0 || busy()\"\n          (click)=\"selectVisible()\"\n        >\n          <!--\n            ⚠ \"these N\", never \"all\". With a filter applied, \"all\" reads as the whole queue — and\n            approving something you cannot see is the one mistake this screen cannot undo.\n          -->\n          Select these {{ rows().length }}\n        </button>\n\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          [disabled]=\"selectedCount() === 0 || busy()\"\n          (click)=\"clearSelection()\"\n        >\n          Clear selection\n        </button>\n\n        <!--\n          #884: the count, announced when Space or Ctrl+A changes it on a grid row, where the ticked\n          box may be off screen. Not cms-status-message: that is for the outcome of a mutation, and\n          selecting rows commits nothing. Hidden, as the Approve button already shows the number.\n        -->\n        <p class=\"cws:sr-only\" aria-live=\"polite\">{{ selectedCount() }} of {{ rows().length }} selected</p>\n\n        @if (writeRefusal(); as refusal) {\n          <!-- #411: the approvals stay, disabled; this is their reason, said once beside them. -->\n          <p role=\"status\" class=\"cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\n            {{ refusal }}\n          </p>\n        }\n      </div>\n    }\n\n    <!-- `(retry)` bound and the empty state routed through the container. See the pricing detail\n         screen for why both matter. -->\n    <cms-async-container\n      [data]=\"state()\"\n      [empty]=\"!hasScope() || rows().length === 0\"\n      [emptyMessage]=\"emptyMessage()\"\n      loadingLabel=\"Loading pricing approvals\"\n      (retry)=\"refresh()\"\n    >\n      @if (rows().length > 0) {\n        <!-- Tone-free, so the stripe cannot compete with a semantic tint — see the pricing queue. -->\n        <cms-data-grid\n          [rows]=\"rows()\"\n          [columns]=\"columnChoice.shown()\"\n          label=\"Price sequences awaiting approval\"\n          [columnMenu]=\"false\"\n          [striped]=\"true\"\n          [sorts]=\"sorts()\"\n          [selectable]=\"canApprove()\"\n          (sortChange)=\"sorts.set($event)\"\n          (rowToggle)=\"onRowToggle($event)\"\n          (selectAll)=\"onSelectAll()\"\n        />\n\n        <!--\n          Selection lives beside the grid rather than inside it: the shared grid renders columns from\n          data and has no concept of a row action, and giving it one for this screen would put a\n          checkbox column into every grid in the application.\n        -->\n        <ul class=\"cws:mt-3 cws:flex cws:flex-col cws:gap-1\">\n          @for (row of rows(); track row.contract + '|' + row.priceSequence) {\n            <li class=\"cws:flex cws:items-center cws:gap-3 cws:text-sm\">\n              <label class=\"cws:flex cws:items-center cws:gap-2\">\n                <input\n                  type=\"checkbox\"\n                  [checked]=\"isSelected(row)\"\n                  [disabled]=\"busy()\"\n                  (change)=\"toggle(row)\"\n                />\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">\n                  {{ row.contract }} · seq {{ row.priceSequence }}\n                </span>\n              </label>\n\n              @if (canApprove()) {\n                <button\n                  type=\"button\"\n                  class=\"cws:min-h-6 cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:dark:text-sky-400\"\n                  [disabled]=\"busy() || writeRefusal() !== null\"\n                  [attr.title]=\"writeRefusal()\"\n                  (click)=\"approveOne(row)\"\n                >\n                  Approve this one\n                </button>\n              }\n            </li>\n          }\n        </ul>\n\n        <!--\n          The footer pager and the range, matching the other three grids.\n\n          🔴 **Both numbers are about the QUEUE, not the page** — a user deciding whether they have\n          seen everything is asking about the queue, and \"1-50 of 50\" on a 2,000-row queue is the\n          claim that would mislead them. The grid above renders the page; this says how much of the\n          queue that is.\n        -->\n        <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-2\">\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            Showing {{ rows().length }} of {{ queue().length }} awaiting approval\n          </p>\n\n          <cms-pager\n            [page]=\"currentPage()\"\n            [totalPages]=\"totalPages()\"\n            position=\"bottom\"\n            (goTo)=\"onPage($event)\"\n          />\n        </div>\n      }\n    </cms-async-container>\n</section>\n"
		}]
	}],
	ctorParameters: () => []
});
function contractCount(count) {
	if (count === 0) return "Nothing was approved";
	return count === 1 ? "1 contract was approved" : `${count} contracts were approved`;
}
async function firstLoadedValue(source) {
	return firstValueFrom(source.pipe(filter((value) => value.status !== "loading")));
}
function emptyPrices() {
	return {
		prices: [],
		count: 0,
		truncationCeiling: 0,
		mayBeTruncated: false
	};
}
export { APPROVAL_QUEUE_COLUMNS, PRICE_SEQUENCE_COLUMNS, PRICING_GRID_COLUMNS, PriceSequenceDetailPageComponent, PricingApprovalsPageComponent, PricingDetailPageComponent, PricingPageComponent, needsPricing, pricedQuantity };

//# sourceMappingURL=cws-features-pricing.mjs.map
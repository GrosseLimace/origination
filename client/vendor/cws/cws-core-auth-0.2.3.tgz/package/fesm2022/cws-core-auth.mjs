import * as i0 from "@angular/core";
import { Injectable, InjectionToken, computed, effect, inject, makeEnvironmentProviders, provideAppInitializer, signal, untracked } from "@angular/core";
import { BrowserCacheLocation, LogLevel, PublicClientApplication } from "@azure/msal-browser";
import { HttpErrorResponse } from "@angular/common/http";
import { EMPTY, from, switchMap, throwError } from "rxjs";
function rolesFromAccessToken(token) {
	const roles = payloadOf(token)?.["roles"];
	return Array.isArray(roles) ? roles.filter((role) => typeof role === "string") : [];
}
function payloadOf(token) {
	const segments = token?.split(".");
	if (!segments || segments.length !== 3 || !segments[1]) return null;
	try {
		const base64 = segments[1].replace(/-/g, "+").replace(/_/g, "/");
		const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, "=");
		const bytes = Uint8Array.from(atob(padded), (character) => character.charCodeAt(0));
		const payload = JSON.parse(new TextDecoder().decode(bytes));
		return typeof payload === "object" && payload !== null ? payload : null;
	} catch {
		return null;
	}
}
function initialsOf(name, fallback) {
	const trimmed = name?.trim();
	if (!trimmed) return fallback?.[0]?.toUpperCase() ?? "?";
	const words = trimmed.split(/\s+/).filter(Boolean);
	return ((words[0]?.[0] ?? "") + (words.length > 1 ? words[words.length - 1][0] ?? "" : "")).toUpperCase() || "?";
}
var CmsAuthService = class CmsAuthService {
	msal = inject(CWS_MSAL_INSTANCE);
	config = inject(CMS_AUTH_CONFIG);
	msalAccount = signal(this.msal.getActiveAccount(), ...ngDevMode ? [{ debugName: "msalAccount" }] : /* istanbul ignore next */ []);
	started = null;
	signingIn = null;
	blocked = signal(false, ...ngDevMode ? [{ debugName: "blocked" }] : /* istanbul ignore next */ []);
	signInBlocked = this.blocked.asReadonly();
	accessRoles = signal([], ...ngDevMode ? [{ debugName: "accessRoles" }] : /* istanbul ignore next */ []);
	photo = signal(null, ...ngDevMode ? [{ debugName: "photo" }] : /* istanbul ignore next */ []);
	isSignedIn = computed(() => this.msalAccount() !== null, ...ngDevMode ? [{ debugName: "isSignedIn" }] : /* istanbul ignore next */ []);
	account = computed(() => {
		const account = this.msalAccount();
		return account ? {
			oid: account.localAccountId,
			username: account.username,
			name: account.name ?? null
		} : null;
	}, ...ngDevMode ? [{ debugName: "account" }] : /* istanbul ignore next */ []);
	username = computed(() => this.msalAccount()?.username ?? null, ...ngDevMode ? [{ debugName: "username" }] : /* istanbul ignore next */ []);
	userId = computed(() => this.msalAccount()?.localAccountId ?? null, ...ngDevMode ? [{ debugName: "userId" }] : /* istanbul ignore next */ []);
	displayName = computed(() => {
		const account = this.msalAccount();
		return account ? account.name ?? account.username : null;
	}, ...ngDevMode ? [{ debugName: "displayName" }] : /* istanbul ignore next */ []);
	photoUrl = computed(() => this.photo(), ...ngDevMode ? [{ debugName: "photoUrl" }] : /* istanbul ignore next */ []);
	initials = computed(() => initialsOf(this.msalAccount()?.name, this.username()), ...ngDevMode ? [{ debugName: "initials" }] : /* istanbul ignore next */ []);
	roles = computed(() => this.accessRoles(), ...ngDevMode ? [{ debugName: "roles" }] : /* istanbul ignore next */ []);
	canReadContracts = computed(() => this.roles().some((role) => role === "Admin" || role === "User"), ...ngDevMode ? [{ debugName: "canReadContracts" }] : /* istanbul ignore next */ []);
	ready() {
		this.started ??= this.start();
		return this.started;
	}
	async start() {
		await this.msal.initialize();
		if (this.config.interaction === "redirect") await this.consumeRedirect();
		const own = this.msal.getAllAccounts().find((candidate) => candidate.idTokenClaims);
		if (own && !this.msal.getActiveAccount()) this.msal.setActiveAccount(own);
		await this.refresh();
	}
	async consumeRedirect() {
		try {
			await this.msal.handleRedirectPromise();
		} catch (error) {
			warn("handleRedirectPromise failed", error);
		}
	}
	ensureSignedIn() {
		this.signingIn ??= this.attemptSignIn().finally(() => {
			this.signingIn = null;
		});
		return this.signingIn;
	}
	async attemptSignIn() {
		await this.ready();
		const active = this.msal.getActiveAccount();
		if (active) {
			this.blocked.set(false);
			if (this.msalAccount() !== active) await this.refresh();
			return true;
		}
		if (this.config.silentSignIn && await this.trySilentSignIn()) return true;
		try {
			if (this.config.interaction === "redirect") {
				await this.msal.loginRedirect(this.interactiveRequest());
				return false;
			}
			const result = await this.msal.loginPopup(this.interactiveRequest());
			await this.adopt(result.account);
			return true;
		} catch (error) {
			if (isBlockedSignIn(error)) {
				this.blocked.set(true);
				return false;
			}
			throw error;
		}
	}
	async trySilentSignIn() {
		const cached = this.msal.getAllAccounts()[0];
		const hint = cached ? null : this.config.loginHint?.() ?? null;
		try {
			const result = await this.msal.ssoSilent(this.silentRequest({
				scopes: [...this.config.apiScopes],
				...cached ? { account: cached } : {},
				...hint ? { loginHint: hint } : {}
			}));
			await this.adopt(result.account);
			return true;
		} catch {
			return false;
		}
	}
	signIn() {
		(this.config.interaction === "redirect" ? this.msal.loginRedirect(this.interactiveRequest()) : this.msal.loginPopup(this.interactiveRequest()).then((result) => this.adopt(result.account))).catch((error) => {
			if (isBlockedSignIn(error)) this.blocked.set(true);
			else warn("sign-in failed", error);
		});
	}
	silentRequest(request) {
		const redirectUri = this.config.silentRedirectUri;
		return redirectUri ? {
			...request,
			redirectUri
		} : request;
	}
	interactiveRequest() {
		const account = this.msal.getActiveAccount();
		return {
			scopes: [...this.config.apiScopes],
			...account ? { account } : {}
		};
	}
	async adopt(account) {
		this.msal.setActiveAccount(account);
		this.blocked.set(false);
		await this.refresh();
	}
	signOut() {
		(this.config.interaction === "redirect" ? this.msal.logoutRedirect() : this.msal.logoutPopup()).catch((error) => warn("sign-out failed", error));
	}
	async refresh() {
		this.msalAccount.set(this.msal.getActiveAccount());
		this.accessRoles.set(await this.readRoles());
		this.loadPhoto();
	}
	async accessToken(scopes) {
		await this.ready();
		return this.silentToken(scopes);
	}
	async silentToken(scopes) {
		const account = this.msalAccount();
		const wanted = scopes && scopes.length > 0 ? scopes : this.config.apiScopes;
		if (!account || wanted.length === 0) return null;
		try {
			return (await this.msal.acquireTokenSilent(this.silentRequest({
				scopes: [...wanted],
				account
			}))).accessToken;
		} catch {
			this.blocked.set(true);
			return null;
		}
	}
	async readRoles() {
		const token = await this.silentToken();
		return token === null ? [] : rolesFromAccessToken(token);
	}
	async loadPhoto() {
		const account = this.msalAccount();
		if (!account) {
			this.photo.set(null);
			return;
		}
		try {
			const result = await this.msal.acquireTokenSilent(this.silentRequest({
				scopes: [GRAPH_PHOTO_SCOPE],
				account
			}));
			const response = await fetch(GRAPH_PHOTO_URL, { headers: { Authorization: `Bearer ${result.accessToken}` } });
			if (!response.ok) {
				this.photo.set(null);
				return;
			}
			const blob = await response.blob();
			this.photo.set(blob.size > 0 ? await readAsDataUrl(blob) : null);
		} catch {
			this.photo.set(null);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CmsAuthService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CmsAuthService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CmsAuthService,
	decorators: [{ type: Injectable }]
});
function readAsDataUrl(blob) {
	return new Promise((resolve) => {
		const reader = new FileReader();
		reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : null);
		reader.onerror = () => resolve(null);
		reader.readAsDataURL(blob);
	});
}
const GRAPH_PHOTO_SCOPE = "https://graph.microsoft.com/User.Read";
const GRAPH_PHOTO_URL = "https://graph.microsoft.com/v1.0/me/photo/$value";
const BLOCKED_SIGN_IN_CODES = /* @__PURE__ */ new Set([
	"interaction_in_progress",
	"popup_window_error",
	"user_cancelled"
]);
function isBlockedSignIn(error) {
	const code = error?.errorCode;
	return typeof code === "string" && BLOCKED_SIGN_IN_CODES.has(code);
}
function warn(what, error) {
	console.warn(`[cws-auth] ${what}`, error);
}
const CWS_TOKEN_PROVIDER = new InjectionToken("CWS_TOKEN_PROVIDER");
const CWS_TOKEN_TARGET = new InjectionToken("CWS_TOKEN_TARGET");
var HostTokenAuthService = class HostTokenAuthService {
	provider = inject(CWS_TOKEN_PROVIDER);
	target = inject(CWS_TOKEN_TARGET);
	accessRoles = signal([], ...ngDevMode ? [{ debugName: "accessRoles" }] : /* istanbul ignore next */ []);
	account = this.provider.account;
	signInBlocked = this.provider.signInBlocked;
	isSignedIn = computed(() => this.account() !== null, ...ngDevMode ? [{ debugName: "isSignedIn" }] : /* istanbul ignore next */ []);
	username = computed(() => this.account()?.username ?? null, ...ngDevMode ? [{ debugName: "username" }] : /* istanbul ignore next */ []);
	userId = computed(() => this.account()?.oid ?? null, ...ngDevMode ? [{ debugName: "userId" }] : /* istanbul ignore next */ []);
	displayName = computed(() => {
		const account = this.account();
		return account ? account.name ?? account.username : null;
	}, ...ngDevMode ? [{ debugName: "displayName" }] : /* istanbul ignore next */ []);
	initials = computed(() => initialsOf(this.account()?.name, this.username()), ...ngDevMode ? [{ debugName: "initials" }] : /* istanbul ignore next */ []);
	photoUrl = computed(() => null, ...ngDevMode ? [{ debugName: "photoUrl" }] : /* istanbul ignore next */ []);
	roles = computed(() => this.accessRoles(), ...ngDevMode ? [{ debugName: "roles" }] : /* istanbul ignore next */ []);
	canReadContracts = computed(() => this.roles().some((role) => role === "Admin" || role === "User"), ...ngDevMode ? [{ debugName: "canReadContracts" }] : /* istanbul ignore next */ []);
	ready() {
		return this.provider.ready();
	}
	async ensureSignedIn() {
		const signedIn = await this.provider.ensureSignedIn();
		if (signedIn) await this.refresh();
		return signedIn;
	}
	accessToken(scopes) {
		return this.provider.accessToken(scopes ?? this.target.apiScopes);
	}
	signIn() {
		this.provider.signIn();
	}
	signOut() {
		this.provider.signOut();
	}
	constructor() {
		effect(() => {
			this.account();
			untracked(() => void this.refresh());
		});
	}
	reads = 0;
	latest = Promise.resolve();
	refresh() {
		const read = ++this.reads;
		const run = (async () => {
			const roles = rolesFromAccessToken(await this.accessToken());
			if (read === this.reads) this.accessRoles.set(roles);
			else await this.latest;
		})();
		this.latest = run;
		return run;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HostTokenAuthService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HostTokenAuthService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HostTokenAuthService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
const CMS_AUTH_CONFIG = new InjectionToken("CMS_AUTH_CONFIG");
const CWS_MSAL_INSTANCE = new InjectionToken("CWS_MSAL_INSTANCE");
function provideCmsAuth(config) {
	return makeEnvironmentProviders([
		{
			provide: CMS_AUTH_CONFIG,
			useValue: config
		},
		{
			provide: CWS_TOKEN_TARGET,
			useValue: {
				apiUrl: config.apiUrl,
				apiScopes: config.apiScopes,
				onSilentFailure: config.interaction === "redirect" ? "redirect" : "fail"
			}
		},
		{
			provide: CWS_MSAL_INSTANCE,
			useFactory: () => instanceFor(config)
		},
		CmsAuthService,
		{
			provide: CWS_TOKEN_PROVIDER,
			useExisting: CmsAuthService
		},
		provideAppInitializer(() => inject(CmsAuthService).ready())
	]);
}
function provideCwsHostTokenAuth(options) {
	return makeEnvironmentProviders([
		{
			provide: CWS_TOKEN_TARGET,
			useValue: {
				apiUrl: options.apiUrl,
				apiScopes: options.apiScopes,
				onSilentFailure: "fail"
			}
		},
		{
			provide: CWS_TOKEN_PROVIDER,
			useValue: options.tokenProvider
		},
		{
			provide: CmsAuthService,
			useClass: HostTokenAuthService
		}
	]);
}
function instanceFor(config) {
	return new PublicClientApplication({
		auth: {
			clientId: config.clientId,
			authority: config.authority,
			redirectUri: config.redirectUri,
			postLogoutRedirectUri: config.postLogoutRedirectUri
		},
		cache: { cacheLocation: BrowserCacheLocation.SessionStorage },
		system: { loggerOptions: {
			logLevel: LogLevel.Warning,
			piiLoggingEnabled: false,
			loggerCallback: (_level, message, containsPii) => {
				if (!containsPii) console.warn("[msal]", message);
			}
		} }
	});
}
const cwsAuthGuard = () => inject(CWS_TOKEN_PROVIDER).ensureSignedIn();
function isApiRequest(url, apiUrl) {
	const base = apiUrl.replace(/\/+$/, "");
	return url === base || url.startsWith(`${base}/`) || url.startsWith(`${base}?`);
}
const cwsTokenInterceptor = (req, next) => {
	const target = inject(CWS_TOKEN_TARGET);
	const provider = inject(CWS_TOKEN_PROVIDER);
	if (!isApiRequest(req.url, target.apiUrl)) return next(req);
	return from(provider.accessToken(target.apiScopes)).pipe(switchMap((token) => {
		if (token !== null) return next(req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }));
		if (target.onSilentFailure === "redirect") {
			provider.signIn();
			return EMPTY;
		}
		return throwError(() => new HttpErrorResponse({
			status: 401,
			statusText: "cws-sign-in-required",
			url: req.url
		}));
	}));
};
const FAKE_ACCOUNT = {
	homeAccountId: "oid-1.1521f999-f722-4a4f-9747-166f93e9b0d1",
	environment: "login.microsoftonline.com",
	tenantId: "1521f999-f722-4a4f-9747-166f93e9b0d1",
	username: "u@scoular.com",
	localAccountId: "oid-1",
	name: "U",
	idTokenClaims: {}
};
function fakePublicClientApplication(options = {}) {
	const accounts = options.account ? [options.account] : [];
	let active = null;
	const eventCallbacks = /* @__PURE__ */ new Map();
	let nextCallbackId = 0;
	const calls = {
		initialize: 0,
		handleRedirectPromise: 0,
		setActiveAccount: 0,
		acquireTokenSilent: 0,
		ssoSilent: 0,
		loginRedirect: 0,
		loginPopup: 0,
		logoutRedirect: 0,
		logoutPopup: 0
	};
	const signedIn = (account) => {
		if (!accounts.includes(account)) accounts.push(account);
		return {
			account,
			accessToken: options.accessToken ?? "fake-access-token"
		};
	};
	const fake = {
		calls,
		lastSsoSilent: null,
		lastAcquireTokenSilent: null,
		addAccount(account) {
			accounts.push(account);
		},
		async initialize() {
			calls.initialize += 1;
		},
		async handleRedirectPromise() {
			calls.handleRedirectPromise += 1;
			return null;
		},
		getAllAccounts: () => [...accounts],
		getActiveAccount: () => active,
		setActiveAccount(account) {
			calls.setActiveAccount += 1;
			active = account;
		},
		async acquireTokenSilent(request) {
			calls.acquireTokenSilent += 1;
			fake.lastAcquireTokenSilent = request;
			if (options.acquireTokenSilentError) throw { errorCode: options.acquireTokenSilentError };
			const account = request.account ?? active;
			if (!account) throw { errorCode: "no_account_error" };
			return {
				account,
				accessToken: options.accessToken ?? "fake-access-token"
			};
		},
		async ssoSilent(request) {
			calls.ssoSilent += 1;
			fake.lastSsoSilent = request;
			if (options.ssoSilent !== "succeeds") throw { errorCode: "login_required" };
			return signedIn(request.account ?? FAKE_ACCOUNT);
		},
		async loginRedirect(_request) {
			calls.loginRedirect += 1;
		},
		async loginPopup(_request) {
			calls.loginPopup += 1;
			if (options.loginPopupError) throw { errorCode: options.loginPopupError };
			return signedIn(FAKE_ACCOUNT);
		},
		async logoutRedirect() {
			calls.logoutRedirect += 1;
		},
		async logoutPopup() {
			calls.logoutPopup += 1;
		},
		addEventCallback(callback) {
			const id = `fake-callback-${nextCallbackId += 1}`;
			eventCallbacks.set(id, callback);
			return id;
		},
		removeEventCallback(id) {
			eventCallbacks.delete(id);
		},
		emit(message) {
			for (const callback of eventCallbacks.values()) callback(message);
		},
		get eventCallbackCount() {
			return eventCallbacks.size;
		}
	};
	return fake;
}
export { CMS_AUTH_CONFIG, CWS_MSAL_INSTANCE, CWS_TOKEN_PROVIDER, CWS_TOKEN_TARGET, CmsAuthService, FAKE_ACCOUNT, HostTokenAuthService, cwsAuthGuard, cwsTokenInterceptor, fakePublicClientApplication, initialsOf, isApiRequest, provideCmsAuth, provideCwsHostTokenAuth, rolesFromAccessToken };

//# sourceMappingURL=cws-core-auth.mjs.map
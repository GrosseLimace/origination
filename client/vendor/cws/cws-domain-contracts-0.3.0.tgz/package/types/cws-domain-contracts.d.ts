import { AllowedValue, CollectionBehaviour, CollectionConstraint, ConstraintSnapshot, ContractFacts, ContractFieldControl, ContractForm, ControlPattern, EffectiveFieldState, FieldPresentation, FieldVerdict, FieldWidth, FormConfigProvenance, FormFieldConfig, RemarkTypeBehaviour, ResolvedFormConfig, SavedCodeDescription, ShipPeriodRow, TradeUnitAttributes } from "@cws/shared-form-engine";
import * as i0 from "@angular/core";
import { InjectionToken, OnInit, Provider, Signal } from "@angular/core";
import { Observable } from "rxjs";
import { CmsNavigationIntent } from "@cws/core-host-context";
import { CodeOption, CodeSearchSource, FieldHelp, FilterGroup, GridBadge, GridCellComponent, GridColumn, GridRowTone, GridSort, HelpTipEntry, MutationOutcome, RemoteData } from "@cws/shared-ui";
import { ConnectedPosition } from "@angular/cdk/overlay";
import { HttpParams } from "@angular/common/http";
/**
 * **The contract's field layout, as data — read by the detail screen AND the add/edit screen.**
 *
 * Two jobs in one file, because they are the same table.
 *
 * ### ⚠ `note`, `emptyNote` and `gap` are TRADER-FACING copy, so they carry no issue numbers
 *
 * Every string in this file reaches the screen. Issue numbers, `BR-` references and section symbols
 * were stripped from them on 2026-09-17 and the provenance moved into comments, because a trader
 * reading *"needs the parameterised reference route (#83)"* has no way to act on the parenthetical
 * and no way to look it up — it reads as an internal note left in by accident, which is what it was.
 * A guard spec enforces this; see `user-facing-copy.spec.ts` in the shell.
 *
 * The references those notes used to carry, kept here so the gaps stay traceable:
 *
 * - **The "no callable reference route" notes** (language, price market, hedge market, freight
 *   payment) and the **"code list needs the parameterised reference route"** notes were issues 44 and
 *   83. ✅ **Retired 2026-10-05 (#219):** `getCodes` is served per prefix, so the coded fields are
 *   combos; the two market codes are assigned by CTRM and shown by the cascade (#201); and language and
 *   freight payment have no code table at all (CTRM derives the language from the text code, and
 *   checks freight payment against a fixed C/I/P set). Each note now says which. Origin code and
 *   Destination code kept the old note until #1049: their list is served, but not picked from here.
 * - **The customer-name field** was issue 47 — no CTRM route returns a customer name, and none does
 *   now — but the customer directory answers instead: the detail read fills it where the directory
 *   resolved the name, and the record screen confirms a typed id on blur (F4.3b). Its `emptyNote`
 *   says where the name comes from; the gap it used to state is closed.
 * - **The Additional fields grouping** is issue 100 — this lane's choice, awaiting a business ruling.
 *
 * ### 1. The layout
 *
 * 🔴 **One table, two screens, and that is the point rather than a convenience.** This used to be the
 * entry screen's layout, with the detail screen keeping its own in `contract-detail.fields.ts`. The two
 * were written to match and then drifted: this file's own docstring still claimed *"the same six
 * sections … as the detail screen"* while it had grown to **eleven**; the two disagreed on whether
 * Incoterms came before or after the ship-period description; and **70 of the 104 editable fields had
 * no place on the detail screen at all**, so a field could be changed on one screen and be
 * unfindable on the other. Two hand-maintained copies of one decision is the failure this repository
 * keeps recording, and matching them once would only have reset the clock.
 *
 * Now neither screen can move a field without moving it for the other.
 *
 * docs/02 §3 makes sections and fields configurable per trade unit (BR-001a), so a screen that
 * hard-codes them in a template cannot satisfy that without a rewrite. This is a constant today, and
 * `HttpFormConfigSource` turns it into the `ResolvedFormConfig` that F2.1's endpoint will eventually
 * serve instead — so swapping the source is a provider change, not a re-layout.
 *
 * ### Read-only fields are rows here too
 *
 * A handful of fields — `version`, `trader`, `customer_name`, the `*_description` values CTRM derives —
 * are readable and **refused on a write**. They are listed with {@link ContractLayoutField.readOnly},
 * so the detail screen renders them normally and the entry screen renders them **disabled**. That is
 * what keeps the two field lists identical in both directions: a row never disappears when you move
 * from viewing to editing, it only stops accepting input.
 *
 * ⚠ **A `readOnly` row must never reach the write payload.** `upsertContract` refuses those 38 fields
 * outright rather than ignoring them, so including one turns a good save into a rejected one.
 * {@link CONTRACT_WRITABLE_FIELDS} is the set the save path iterates, and it excludes them by
 * construction rather than by the caller remembering.
 *
 * ### 2. The mapping nobody had written down
 *
 * `field-validators.ts` states the gap exactly: *"`FormFieldConfig.componentName` is a catalog
 * component name and the dictionary is keyed by CTRM field name. Nothing in the repository maps one to
 * the other yet."* {@link ContractLayoutField.ctrmField} is that mapping. It is what lets the real
 * `GET /meta/constraints` document reach this form — so a width enforced here and a width enforced by
 * FluentValidation on the server come from **one document** rather than from two hand-written copies.
 * That is ADR-7's actual guarantee, and until now it did not hold for any screen.
 *
 * ### ⚠ Every `ctrmField` below was verified against the document, not inferred from the label
 *
 * Known Issue 18: a wrong CTRM field name fails **silently** — it deserialises to `undefined` and
 * renders as an empty control, with no error anywhere. Each name here was checked to exist in
 * `src/Scoular.Contracts.Application/Validation/constraints.json` (v2, 146 fields) and to be writable.
 * Two consequences worth reading before adding a row:
 *
 * - **The read-only descriptions are deliberately absent.** `commodity_description`,
 *   `market_zone_description`, `price_type_description`, `inco_terms_description`, `origin_name`,
 *   `destination_name`, `named_place`, `trader` and `version` are all `access: readOnly` — CTRM
 *   *returns* them and **refuses them on a write**. The detail screen shows them because it is reading;
 *   a create form must send the **code**, which is why this file pairs `commodity_code` with the label
 *   "Commodity" rather than offering both.
 * - **`GradeAdjustment` has no row here, and the Power App source says why.** BR-003 and BR-004 both
 *   name it as a price component, and there is no grade-adjustment field anywhere in the 146 — CTRM has
 *   `grade_code` and `grades_to_govern_code`, neither of which is an adjustment. **✅ Resolved
 *   2026-09-01 from the legacy Power App export**: it has `Grade Adj` and `Grade Adj UM` components and
 *   stores them (`sc_gradeadj`, `sc_gradeadjumcode`), and its `upsertContract` body sends **no
 *   `grade_adj` scalar** — what it sends is a collection, `adj_calculator_lines`
 *   (`adjustment_sequence`, `adjustment_type`, `adjustment_amount`, `adjustment_uom`,
 *   `adjustment_currency_code`), backed by `sc_cms_contracts_AdjustmentCalculatorLines`.
 *
 *   So grade adjustment is an **adjustment line with a type discriminator, not a base_data scalar** —
 *   which is exactly why a sweep of the 146 could not find it. ⚠ Note the asymmetry: `freight_adj`
 *   *is* a scalar and is sent as one, so the two adjustments are not modelled alike. A row here would
 *   still be wrong; the correct home is the adjustments collection, with the other ten. `adjustment_type`
 *   carrying "grade" is inferred from the member names — the collection's existence is not.
 */
export interface ContractLayoutField {
  /**
   * Catalog identity — what the form engine keys the control on, and what the rules name.
   *
   * Where a rule names a component (BR-003…BR-007), this **must** be the `ContractComponent` constant,
   * or the rule silently stops firing for that field.
   */
  readonly componentName: string;
  /**
   * The CTRM field name: the key into `GET /meta/constraints`, and the key this value would carry in
   * an `upsertContract` payload.
   *
   * Verified present and writable in `constraints.json` v2.
   */
  readonly ctrmField: string;
  /**
   * Where the value is written. A layout row is always a CTRM field (D4).
   *
   * 🔴 **Typed as `'ctrm'` only, and that is the point.** A field stored by CWS is a
   * `CwsContractField` and lives outside this layout, so a row here cannot be re-homed to `cws` to
   * get past the constraints drift guard: it would not compile. Omitted on every row, since the only
   * value it can take is the default.
   */
  readonly destination?: 'ctrm';
  /** Forbidden on a layout row: a CTRM field has no CWS storage name. */
  readonly cwsField?: never;
  readonly label: string;
  readonly controlPattern: ControlPattern;
  /** Which reference set fills the dropdown, where one both exists and is callable today. */
  readonly referenceSet?: ContractReferenceSet;
  /**
   * The dropdown's codes are `constraints.json`'s `allowedValues` for {@link ctrmField} (#1007, ADR-7).
   *
   * For a closed domain CTRM's write rule states and no code table states correctly. The codes are
   * never restated here; only their labels are, in {@link CONSTRAINT_VALUE_LABELS}. Without a document
   * that lists them, the combo degrades to a typed code rather than a list of guesses.
   */
  readonly valuesFromConstraints?: true;
  /**
   * The server search a C2 field's combo uses, a key into `CODE_SEARCH_SOURCES` (#1064). For a code
   * list too large to send whole, searched by what the user types instead.
   *
   * ⚠ Never in the seed: like `controlPattern`, it is how the field is drawn, not configuration.
   */
  readonly searchSet?: string;
  /**
   * The CTRM description that belongs to this code, for a code — description pair (#595).
   *
   * 🔴 **Not a row, and never written.** CTRM fills a description from its code only when the
   * description is blank and keeps typed text (`wnr051e:3254-3273`), so a typeable description box
   * let a user print anything beside a code. The ruling (GEstevez, 2026-10-01) is one combo per pair:
   * the combo already shows `code — description` from the code table, so the description has no
   * control of its own. This name is kept only so view mode can show a legacy contract's saved text
   * (see {@link savedCodeDescriptions}); the server derives what is written (#594).
   *
   * Verified present and `readWrite` in `constraints.json` by `contract-layout.spec.ts`.
   */
  readonly descriptionField?: string;
  /** Spans the section's two columns, for values that need the room. */
  readonly wide?: boolean;
  /**
   * Takes **half** a column, sharing one cell with the next half field.
   *
   * For a value a full column overstates — both key prefixes are `maxLength: 1`. ⚠ A half field's
   * {@link note} renders in an **"i" tooltip** instead of under the control, because help text does
   * not fit at half width; the tooltip carries the note and the CTRM field name.
   *
   * ⚠ **Half fields pair with the NEXT half field in display order**, so a lone one takes half a cell
   * and leaves the other half empty. Mark them in adjacent pairs.
   */
  readonly half?: boolean;
  /**
   * Renders the visible label as screen-reader-only, keeping the accessible name.
   *
   * For a field that is part of a GROUP under one heading -- the three parts of the contract key sit
   * under a single "Contract number" label, because they are one identifier and three headings read
   * as three unrelated fields.
   *
   * ⚠ **Hidden, never removed.** Dropping the label would leave the input with no accessible name at
   * all, so a screen reader would announce an unlabelled text box. The label stays in the DOM as
   * `sr-only`; only the sighted heading goes.
   */
  readonly labelHidden?: boolean;
  /**
   * A visible heading rendered ABOVE this field, covering it and the grouped fields that follow.
   *
   * 🔴 **This exists because a group heading and an accessible name are different things, and
   * conflating them is what #196 reported.** The key group used to take its heading from the first
   * field's own `label`, so `ContractPrefixType` had to be called "Contract number" to make the
   * heading read correctly — which left **two controls with the accessible name "Contract number"**
   * (it and `ContractNumber`), the exact ambiguity the issue was opened about, relocated rather than
   * removed. It is also what made ~25 spec queries switch to exact-string matching during #194: the
   * defect showed up in the tests before anyone read it on screen.
   *
   * With the heading declared separately, every field can carry a `label` that names **itself** —
   * `sr-only` via {@link labelHidden} — while the group still reads as one identifier.
   *
   * ⚠ The heading is `aria-hidden`: each control already has its own accessible name, so announcing
   * the heading as well would repeat it on every field in the group.
   */
  readonly groupHeading?: string;
  /**
   * Rendered as help text under the control.
   *
   * Used where a field would otherwise mislead — a value CTRM issues rather than accepts, or a
   * dropdown whose reference set is not callable yet.
   */
  readonly note?: string;
  /**
   * Locks the control regardless of what configuration says.
   *
   * ⚠ **No field uses this today, and the one that did was a defect.** It was set on the contract
   * number, on 03 §2.6's *"issued by CTRM when reserved"* model — but `constraints.json`, generated
   * from CTRM's copybooks, declares `contract_number` **`readWrite`**, so the form was locking a field
   * CTRM accepts. That blocked QA entirely on 2026-09-08 (F-23): with no prefill endpoint and no way to
   * type, no contract could be created at all.
   *
   * Kept as a mechanism because it is the honest way to render a field that exists but cannot be set
   * *here*. 🔴 **Before using it, check `constraints.json` first** — if CTRM says `readWrite`, a lock
   * needs a reason beyond "CTRM usually supplies this", and `readOnly` is the property for a field
   * `upsertContract` actually refuses.
   */
  readonly locked?: boolean;
  /**
   * CTRM returns this field and **refuses it on a write**.
   *
   * Distinct from {@link locked}, which is a writable field the user may not set *here*. A `readOnly`
   * field is one `upsertContract` rejects outright — the 38 read-only members of `base_data`, plus the
   * `*_description` values CTRM derives from their codes and discards what you send.
   *
   * The row still exists so both screens show the same fields in the same places; the entry screen
   * renders it disabled, and {@link CONTRACT_WRITABLE_FIELDS} leaves it out of the payload.
   */
  readonly readOnly?: boolean;
  /**
   * How the detail screen formats the value.
   *
   * Only the detail screen reads this — the entry screen gets its input type from
   * {@link controlPattern}. Both live on the same row so a field cannot be a date in one place and a
   * string in the other.
   */
  readonly kind?: ContractFieldKind;
  /**
   * Why this field is blank when it always will be, shown by the detail screen in place of a value.
   *
   * Distinct from {@link note}, which is guidance for someone filling the field in. This one answers
   * "is this empty, or did something fail?" — the distinction #47 exists for.
   */
  readonly emptyNote?: string;
}
/** How the detail screen renders one value. */
export type ContractFieldKind = 'text' | 'number' | 'price' | 'quantity' | 'date' | 'status';
/**
 * The reference sets this screen can actually fill a dropdown from **today**.
 *
 * Deliberately not the full nine. `#44` established that `codes`, `market-codes`, `market-months`,
 * `origin-destination-codes` and `location-types` are **parameterised** — `getCodes` needs
 * `{prefix, languageCode}`, `getMarketMonths` needs four — while `ReferenceSet` models all nine as
 * unparameterised GETs (#83). Calling those returns empty, and **an empty combo is worse than a text
 * box**: it presents a closed list of nothing and blocks entry entirely. So the fields those sets would
 * serve are plain inputs with a note, until #83 lands.
 *
 * The three below are verified working against live CTRM: commodities (3,251 rows), market zones and
 * the location list.
 *
 * ## ✅ #83 landed, so the code table is reachable too (#219)
 *
 * The paragraph above is the state before 2026-09-09. `GET /api/v1/reference/Codes?prefix=…` is built
 * and live-verified, so the sets that were "parameterised, therefore unusable" are now usable — and the
 * note those fields carried, blaming CTRM for having no callable route, was wrong in both halves.
 *
 * One CTRM route serves **27 field vocabularies**, discriminated by prefix, so a code set is modelled
 * as `Codes:<PREFIX>` rather than as 20 more union members with 20 more fetch functions.
 */
export type ContractReferenceSet = 'Commodities' | 'CommodityGroups' | 'MarketZones' | 'Locations' | `Codes:${ContractCodePrefix}`;
/**
 * 🔴 **The CAK groups the commodity list carries, one option per group** (#920, ruled 2026-10-19).
 *
 * Not fetched: derived from `Commodities`, whose rows carry their CAK group (`group`, C-16, #189). The
 * ruled source is the CAK group, never `getCodes` prefix `CM`. Measured on apiuat 2026-10-20: 3,256
 * commodities, every one carrying a group, 20 distinct groups; `CM` lists 29, the 20 plus 9 that no
 * commodity uses. So the two disagree only by `CM` offering groups no commodity has, and a contract
 * keyed on one of those would describe no commodity at all.
 *
 * Each option's description names the group's commodities, the first two and a count, so a user can
 * tell `C` from `B` without knowing CTRM's codes. Groups in code order, so the list does not move when
 * a commodity is renamed. `null` in, `null` out: the commodity list is still in flight.
 */
export declare function commodityGroupsFrom(commodities: readonly AllowedValue[] | null | undefined): readonly AllowedValue[] | null | undefined;
/**
 * The `getCodes` prefixes this screen populates a control from.
 *
 * 🔑 **Taken from §5 of `docs/CTRM-CONTRACT-WRITE-RULES-2026-09-08.md`, which enumerates them from
 * CTRM's own source**, rather than curated here — that is F-21's actual ask. All eleven spot-checked
 * live on 2026-09-09 returned the table §5 assigns them.
 *
 * ⚠ **Five vocabularies are deliberately absent, and each for a different reason:**
 *
 * - **`TR` (trader initials)** — 1,099 rows / 87 KB, and the write rules record a second rule on that
 *   field that is not about the value: *"Trader does not have approval authority for this location"*.
 *   So the correct list is **location-scoped** and far shorter, and `getCodes` has **no location
 *   parameter**. A decision rather than a build (#219).
 * - **`CP` / `CM` (the key prefixes)** — `CM` is not read at all: the commodity prefix is a dropdown
 *   of the CAK groups the commodity list carries (`CommodityGroups`, #920), the ruled source. `CP` is
 *   held out because it disagrees with CTRM's own write rule: on apiuat it lists `C` and `S`, while
 *   `WNR051E` accepts only `P` and `S` (#920, measured 2026-10-20).
 * - **`language_code` / `freight_payment_code`** — absent from §5 entirely, so there is no prefix to
 *   populate from. They stay text, and their notes name that gap rather than blaming CTRM.
 *
 * ⚠ **`price_market_code` and `hedge_market_code` are not here on purpose either**: §1 of the write
 * rules says **CTRM assigns the market code and refuses a wrong month**, so they are derived, not
 * picked. They belong to [#201](https://scoular.ghe.com/IT/contract-management-system/issues/201).
 */
export type ContractCodePrefix = 'BI' | 'CT' | 'CU' | 'DE' | 'FA' | 'GG' | 'GR' | 'GT' | 'PD' | 'PS' | 'PT' | 'PZ' | 'RC' | 'ST' | 'TC' | 'UM' | 'WG';
/**
 * What each prefix's vocabulary is called, for anything a **user** reads.
 *
 * 🔴 The record screen names the lists that came back empty, so a trader can tell a reduced screen
 * from a broken one. `Codes:GT` is not a thing a trader has ever heard of — it is CTRM's internal
 * discriminator — so the banner would have been technically accurate and useless. Same reasoning as
 * showing a trade unit as `CODE — Name` rather than four digits.
 */
export declare const CONTRACT_CODE_PREFIX_LABELS: Readonly<Record<ContractCodePrefix, string>>;
/** Every code prefix the layout references, so the config source can fetch exactly these. */
export declare const CONTRACT_CODE_PREFIXES: readonly ContractCodePrefix[];
/**
 * **The record screen's tabs, taken from the Power App traders use today.**
 *
 * 🔴 Not our invention, and that is the point. The 111 fields used to render as eleven section cards
 * stacked down one page, with the child grids after all of them — which JFrisbie's own summary was
 * *"the layout is a little confusing and there are so many fields prior to the child grids that it's
 * just too much"* (2026-09-01).
 *
 * The legacy Power App solves the same problem with **four tabs**, and its source states them
 * outright (`App.pa.yaml`, `fxTabOptions`): `Contract Info`, `Shipping Info`, `Remarks`, `Log`, plus
 * `Currency Rates`, `Truck Logistics` and `Hidden Factors` shipped invisible and `BIO`/`FOG` shown only
 * for locations `4090` and `4092`. So the grouping below is the business's, recovered from the
 * application they actually use, rather than a fourth opinion from this lane. That closes the half of
 * [#100](https://scoular.ghe.com/IT/contract-management-system/issues/100) that asked whether our
 * section grouping was right: it was ours, and this is theirs.
 *
 * ### What differs from the Power App, and why
 *
 * - **`additional` is ours.** The Power App surfaces 80 components; this layout carries 102 CTRM
 *   fields (111 when this was written), so roughly 20 have no tab in the original. They go in one clearly-named tab rather than
 *   being distributed into a business tab, so a field the business has never seen on a contract screen
 *   is visibly not one of the fields it knows. Hiding that difference is the failure mode.
 * - **No `Log` tab.** The Power App's Log is an audit timeline over a Dataverse table
 *   (`sc_cms_contracts_Log`: action, details, timestamp, user). CMS has `AuditEntry` and no rows and no
 *   endpoint (F3.7), so a Log tab today would be an empty promise. Add it with F3.7.
 * - **No per-location tabs.** `BIO` and `FOG` are conditional on hard-coded location codes in the
 *   Power App. Configuration-driven tab visibility is real work and belongs with F2.1; recorded here
 *   so it is a known gap rather than a surprise.
 *
 * ⚠ **Tab membership is declared on the SECTION, not the field.** Eleven declarations rather than 102,
 * and it keeps the sections as visible sub-structure inside a tab — the cards are what stop a 63-field
 * tab reading as a wall. A field therefore cannot be moved between tabs without moving its section,
 * which is a constraint rather than an oversight: the section is the unit the business names.
 */
export interface ContractTab {
  readonly id: ContractTabId;
  readonly label: string;
}
export type ContractTabId = 'contract' | 'pricing' | 'shipping' | 'remarks' | 'additional' | 'addendum' | 'documents' | 'log';
/**
 * The tabs in display order.
 *
 * `contract` is first and is the default, so the record opens on the fields somebody came to read.
 *
 * ### ⚠ `pricing` was split out of `contract` on 2026-09-17, and the reason is the original one
 *
 * The tabs exist because the screen put every control in front of a user before the first table. That
 * was fixed and then half-unfixed by the grouping itself: **Contract Info carried 62 of the 110
 * fields**, in six sections, so 56% of the form landed on the tab everybody arrives at and the tab bar
 * was doing a fraction of the work it was added for.
 *
 * Pricing (17) and Quantity (12) move out together rather than separately, because they are read
 * together — a price is meaningless without the quantity it applies to, and BR-003/BR-004's
 * auto-calculation spans both. That gives **33 · 29 · 38 · 0 · 10**, which is the most even split
 * available without inventing a grouping the business has not seen.
 *
 * ⚠ **Shipping Info is now the largest tab, at 38.** Worth knowing before anyone reads the split as
 * finished: *Shipping and logistics* alone is 27 fields, and it is the next candidate if the balance
 * is pushed further. It is left whole here because no obvious seam runs through it — unlike Pricing
 * and Quantity, which were already two sections.
 *
 * ⚠ **These numbers are recorded, not enforced.** `contract-layout.spec.ts` asserts the PROPERTY — no
 * tab over 40% — precisely so this paragraph going stale cannot break a build, and so moving a section
 * does not require editing a count in two places.
 *
 * ⚠ **This is layout data, so it propagates**; field ORDER lives in the stored configuration row and
 * does not. A section's tab assignment is not a stored value, so no configuration repair is needed —
 * unlike the 2026-09-09 reorder, which was invisible on screen until the row itself was updated.
 */
export declare const CONTRACT_TABS: readonly ContractTab[];
/**
 * The Log tab (F3.7) — the audit timeline, Add Note and Notify Trader.
 *
 * 🔴 **Deliberately NOT a member of {@link CONTRACT_TABS}, and the reason is a decision rather than a
 * workaround.** `CONTRACT_TABS` is the *form* layout: it seeds the stored configuration document, and
 * an administrator resolves tabs and sections per trade unit from that document (ADR-17 D7). Putting
 * the Log tab in it would make the audit history **configurable per trade unit** — i.e. hideable —
 * which is not a power anybody asked for and is the wrong default for a compliance surface (BR-070).
 *
 * It also carries no fields, so every field-balance and section-coverage invariant in the layout spec
 * would need an exception for it, and the generated seed the API ships would change. A history is not
 * part of the record being edited; it is a view of what happened to it.
 *
 * So the record screen appends this tab itself, after the configured ones.
 */
export declare const LOG_TAB: ContractTab;
/**
 * The Documents tab (F10.2) — the contract's CTRM document set and an inline viewer.
 *
 * Not a member of {@link CONTRACT_TABS} for the reasons {@link LOG_TAB} gives: it carries no fields,
 * and a trade unit has no business hiding a contract's documents. The record screen appends it, only
 * for an existing contract and only where the host provides a documents source.
 */
export declare const DOCUMENTS_TAB: ContractTab;
/**
 * The Addendum tab (#923, ruled 2026-10-19) — the in-house addendum section (F10.3b).
 *
 * Not a member of {@link CONTRACT_TABS} either: it carries no CTRM fields, and whether it is there is
 * decided by the contract's special type rather than by the trade unit's configuration. The record
 * screen appends it, after the configured tabs, only while the server lists an addendum type for the
 * special type (`addendumTypeFor`, #1043).
 */
export declare const ADDENDUM_TAB: ContractTab;
/** Narrows an untrusted string — a query parameter — to a tab, defaulting to the first. */
export declare function toContractTabId(value: string | null | undefined): ContractTabId;
/** A titled group of fields, and the tab it appears on. */
export interface ContractLayoutSection {
  readonly id: string;
  readonly title: string;
  /**
   * Which tab this section's fields appear on.
   *
   * Assigned from the Power App's own tab membership where it has an equivalent — its Contract Info
   * carries price, basis, grade and broker, and its Shipping Info carries payment terms and billing,
   * which is why those sit where they do below rather than where an alphabetical instinct would put
   * them.
   */
  readonly tab: ContractTabId;
  readonly description?: string;
  /** Shown as a caution inside the section — for what the section deliberately does not carry. */
  readonly gap?: string;
  readonly fields: readonly ContractLayoutField[];
}
/**
 * The sections, in display order — the detail screen's order, for the same reason: identity, then
 * commercial terms, then logistics, then the administrative tail.
 */
export declare const CONTRACT_LAYOUT_SECTIONS: readonly ContractLayoutSection[];
/** Every field across every section, in display order — read-only rows included. */
export declare const CONTRACT_LAYOUT_FIELDS: readonly ContractLayoutField[];
/**
 * The fields a save may send — every row CTRM accepts on a write.
 *
 * 🔴 **The save path must iterate THIS, not {@link CONTRACT_LAYOUT_FIELDS}.** Read-only rows exist in
 * the layout so both screens show the same fields in the same places, and `upsertContract` **refuses**
 * those 38 fields rather than ignoring them — so one of them reaching the payload turns a good save
 * into a rejection the user cannot act on. Deriving the set here rather than filtering at the call
 * site means adding a read-only row cannot quietly widen the payload.
 */
export declare const CONTRACT_WRITABLE_FIELDS: readonly ContractLayoutField[];
/** The read-only rows, which the entry screen renders disabled. */
export declare const CONTRACT_READ_ONLY_FIELDS: Readonly<Record<string, boolean>>;
/** Why a field is permanently blank, by component name — the detail screen shows these. */
export declare const CONTRACT_LAYOUT_EMPTY_NOTES: Readonly<Record<string, string>>;
/** Help text by field component name. */
export declare const CONTRACT_LAYOUT_FIELD_NOTES: Readonly<Record<string, string>>;
/** What a section deliberately does not carry, by section id. */
export declare const CONTRACT_LAYOUT_SECTION_NOTES: Readonly<Record<string, string>>;
/** Fields spanning both columns of their section. */
export declare const CONTRACT_LAYOUT_WIDE_FIELDS: Readonly<Record<string, boolean>>;
/**
 * Fields that take **half** a column, paired with the next half field into one cell.
 *
 * For values a full column overstates. `contract_prefix_type` and `contract_prefix_commodity` are
 * both `maxLength: 1` in `constraints.json` — a whole column for a one-character box reads as though
 * more were expected, and it pushes the field it composes a key with off to the side.
 *
 * ⚠ **A half field's `note` moves into an "i" tooltip rather than rendering under the control**, since
 * there is no room for help text at half width. The tooltip carries the note *and* the CTRM field
 * name, which is the pair a user needs when a label is ambiguous — and two of these labels are
 * (F-06/#196).
 */
export declare const CONTRACT_LAYOUT_HALF_FIELDS: Readonly<Record<string, boolean>>;
/**
 * The visible group heading a field introduces, by component name.
 *
 * Separate from the field LABEL on purpose (#196): the heading covers several controls, while each
 * control keeps a label that names itself. See {@link ContractLayoutField.groupHeading}.
 */
export declare const CONTRACT_LAYOUT_GROUP_HEADINGS: Readonly<Record<string, string>>;
/** Fields whose visible heading is suppressed because they sit under a group label. */
export declare const CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS: Readonly<Record<string, boolean>>;
/**
 * The CTRM field name per componentName, for the tooltip.
 *
 * The resolved configuration carries `componentName` and never `ctrmField` — the mapping lives only
 * here — so a screen that wants to *show* a user which CTRM field they are editing has to be handed it.
 */
export declare const CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT: Readonly<Record<string, string>>;
/**
 * Every CTRM field name this screen writes to, in display order.
 *
 * Not consumed by the form — it is the **write payload's key set**, and it exists so that when the
 * upsert client is built the mapping is already stated and testable rather than re-derived. Pair it
 * with `writableFields()` from the form engine, which strips anything CTRM refuses.
 */
export declare const CONTRACT_LAYOUT_CTRM_FIELDS: readonly string[];
/**
 * The words for the codes of a {@link ContractLayoutField.valuesFromConstraints} dropdown, by component
 * name, then by code (#1007).
 *
 * 🔴 **Labels only, never the list.** The codes are `constraints.json`'s `allowedValues`, the single
 * source (ADR-7), and this map neither adds nor removes one: a code CTRM's rule gains appears in the
 * dropdown under its bare code until a label is added here. Neither CTRM's document nor a code table
 * names P (the `CP` table has no P), so the words are ours.
 */
export declare const CONSTRAINT_VALUE_LABELS: Readonly<Record<string, Readonly<Record<string, string>>>>;
/**
 * The code — description pairs as a contract was saved, keyed by the code's component name (#595).
 *
 * Fed to `withSavedCodeDescriptions` (`@cws/shared-form-engine`) with the record's raw CTRM values,
 * so view mode shows a legacy, hand-typed description exactly as it was saved, and edit mode marks a
 * field only when the user CHANGES its code, against the new code's text (the server keeps a
 * description beside an unchanged code, #613). Wired into the record screen's `bundle` (#595).
 *
 * ⚠ **A pair with a blank code or a blank description is left out**, because there is nothing to
 * preserve: CTRM fills a blank description from the code, so the code table's text is what prints.
 */
export declare function savedCodeDescriptions(values: Readonly<Record<string, unknown>>): ReadonlyMap<string, SavedCodeDescription>;
/**
 * **The fields whose change makes CTRM re-open confirmation** (`ConfirmChg`, BR-066, #143).
 *
 * `$ChkCfmChg` in `wnr051e.sqlrpgle` (source read 2026-10-05, `qrpglesrc`) diffs the session record
 * against the live contract. When anything below differs, `WNR051U` bumps the confirmation version and
 * reissues the confirmation (`if confirmchg`, brief 04). On an already-confirmed contract that is a new
 * confirmation round, which is what BR-066 calls material.
 *
 * The CTRM names come from `conups.sqlrpgle`'s `dsWNP007.wpa* = dsCon.<field>` assignments, so the
 * key is the API's own field name, never a hand-typed guess. `confirm-chg.spec.ts` fails if any of
 * them is not a layout field (a wrong CTRM name fails silently otherwise, Known Issue 18).
 *
 * ⚠ **Grain only.** The BCO and IFI business units add their own lists (`When BCO` / `When IFI`), and
 * Proteins skip the check; this application's trade units take the "all others" branch, which adds the
 * basis market and month when the price type is `U` (see {@link CONFIRM_CHG_WHEN_UNPRICED}).
 *
 * ⚠ **Not listed, because they are not fields on this form:** the remarks and notes collections, the
 * additional and shipping documents, and the climate-smart data, all of which CTRM also diffs. And
 * five `WPA*` fields in the diff (`IASrvCh`, `IAAssmt`, `IAMSvCh`, `IADelLc`, `Prot`) have no API
 * source in `conups`, so nothing here can change them.
 */
export declare const CONFIRM_CHG_CTRM_FIELDS: readonly string[];
/** "All others - edit basis market and basis MM": compared only when the price type is `U`. */
export declare const CONFIRM_CHG_WHEN_UNPRICED: readonly string[];
/**
 * The layout fields (by component name) whose change re-opens confirmation.
 *
 * 🔑 A code whose DESCRIPTION is on the list counts too. The description is no longer a row (the
 * combo is the pair, #595), and the server re-derives it whenever its code changes (#613), so
 * changing the code changes a `ConfirmChg` field. That is why billing instructions is NOT here: its
 * description is the one pair outside the diff.
 */
export declare function confirmChgComponents(priceTypeCode: string | null): ReadonlySet<string>;
/**
 * **Where a field's value is written: CTRM, or CWS's own store** (addendum architecture D4).
 *
 * The contract layout could only say "this is a CTRM field". A field that is writable but stored
 * somewhere other than CTRM had no representation, and every Family B addendum field is exactly that:
 * Min Price Call, Min/Max and Premium Advance are keyed by a person and persisted by CWS (D3), because
 * they never went through Cara and CTRM holds nothing for them.
 *
 * ### 🔴 The discriminator is a CLASSIFICATION, not an escape hatch
 *
 * The obvious failure is someone meeting the constraints drift guard on a mistyped CTRM field and
 * making it pass by flipping the row to `cws`. The value would then persist to the wrong system and
 * the screen would say saved: the silent loss the guard exists to prevent. So the guard below checks
 * both directions, and a layout row cannot say `cws` at all without a compile error, because
 * {@link ContractLayoutField.destination} only admits `'ctrm'`.
 */
export type ContractFieldDestination = 'ctrm' | 'cws';
/**
 * A field written to CWS's own store rather than to CTRM.
 *
 * Shares the layout row's presentation properties so the form engine renders it the same way.
 * `readOnly`, `locked` and `emptyNote` are left out deliberately: all three describe CTRM's handling
 * of a CTRM field, and none of them has a meaning for a value CWS owns.
 */
export interface CwsContractField extends Omit<ContractLayoutField, 'ctrmField' | 'destination' | 'cwsField' | 'readOnly' | 'locked' | 'emptyNote'> {
  readonly destination: 'cws';
  /** The name the value is stored under by CWS. Never a `constraints.json` name. */
  readonly cwsField: string;
  /** Forbidden: a CWS field with a CTRM key is the ambiguity this type exists to remove. */
  readonly ctrmField?: never;
}
/** Either kind of field, for code that routes by destination. */
export type ContractFieldDefinition = ContractLayoutField | CwsContractField;
/** The destination of any field. A layout row with no `destination` is a CTRM field. */
export declare function destinationOf(field: ContractFieldDefinition): ContractFieldDestination;
/** Which Family B addendum a field set belongs to. */
export type AddendumFieldSetId = 'min-price-call' | 'min-max' | 'premium-advance';
/**
 * The fields one addendum product carries, selected by the contract's special type.
 *
 * ⚠ **Kept OUT of the 112-row contract layout on purpose** (D4 §3, JFrisbie 2026-09-28). These vary by
 * product, so there is no fixed row set the layout could declare, and the addendum's field set is
 * mandatory by construction: it is not a configuration row, so no trade-unit configuration can hide or
 * relax it. That is also why the form-configuration seed, which is generated from the layout, does not
 * change when these do.
 */
export interface AddendumFieldSet {
  readonly id: AddendumFieldSetId;
  readonly title: string;
  /**
   * The CTRM special-type codes that select this addendum. These are the `SPADD` control list
   * (`GNP521 P1PREFIX = 'SPADD'`), CTRM's own record of the types that require an addendum document.
   *
   * ⚠ Keyed on the CODE from CTRM's control list, never on a code-table description. `GNP004`'s
   * descriptions have already sent two readers to a dead code once (`AMM`, docs/08).
   */
  readonly specialTypes: readonly string[];
  readonly fields: readonly CwsContractField[];
}
/**
 * The three in-house (Family B) addendums. Provisional field lists: see the note above.
 *
 * 🔴 **No longer the record screen's source (#1043).** Whether a record carries an Addendum section
 * is the server's addendum types (`addendumTypeFor`), and the fields it offers are the chosen
 * template's `addendum_*` mappings (`addendumEntryFieldsOf`). These sets remain the admin picker's
 * offer list (#1038), the labels in `ADDENDUM_FIELD_PRESENTATION`, and the sample templates' source.
 * `addendumFieldSetFor`, which selected one by special type, is retired: it hid KA and SA and offered
 * PREM the wrong fields once Legal's templates were loaded.
 */
export declare const FAMILY_B_ADDENDUM_FIELD_SETS: readonly AddendumFieldSet[];
/** Every CWS-destined field, across every set. */
export declare const CWS_CONTRACT_FIELDS: readonly CwsContractField[];
/** What the guard compares against. */
export interface DestinationGuardInput {
  readonly layout: readonly ContractFieldDefinition[];
  readonly cwsFields: readonly ContractFieldDefinition[];
  /** Every field name `constraints.json` declares, which is every name CTRM knows. */
  readonly ctrmFieldNames: ReadonlySet<string>;
}
/**
 * Every way a field's destination can be wrong, as readable sentences. Empty means consistent.
 *
 * 🔴 **Both directions, and each has its own failure.**
 *
 * - *A CTRM field re-homed to CWS.* A CWS field stored under a name CTRM knows, or under a layout
 *   row's `ctrmField`, is almost certainly a CTRM field someone flipped to get past the constraints
 *   guard. Its value would persist to CWS and CTRM would never hear about it. The layout comparison
 *   is not redundant with the constraints one: `customer_name` is a layout row and absent from
 *   `constraints.json` (#47), so only the layout catches it.
 * - *A CWS field reaching the CTRM payload.* The save path builds `upsertContract` by walking
 *   `CONTRACT_WRITABLE_FIELDS` and reading each control **by component name**. A CWS field sharing a
 *   layout component name shares its control, and its value goes to CTRM under the CTRM key.
 *
 * A pure function over its inputs, so each direction can be shown to fire against a fixture built to
 * break it. A guard only ever run against the real data would pass whether or not it works.
 */
export declare function fieldDestinationViolations(input: DestinationGuardInput): string[];
/** `A` is the StoneX products, `B` the in-house trio (Min Price Call, Min/Max, Premium Advance). */
export type AddendumFamily = 'A' | 'B';
/** The server's language when a template names none (`AddendumRules.DefaultLanguage`). */
export declare const DEFAULT_ADDENDUM_LANGUAGE = "ENUS";
/** The only content format the server accepts today (`AddendumRules.DefaultContentFormat`). */
export declare const DEFAULT_ADDENDUM_CONTENT_FORMAT = "text/plain";
/** One template placeholder and the field that fills it: a CTRM field, or a CWS `addendum_*` field. */
export interface AddendumFieldMapping {
  readonly placeholder: string;
  readonly field: string;
}
/**
 * An addendum template as `GET /api/v1/addendum-templates` serves it (#624, ADR-19; the server's
 * `AddendumTemplateRecord`, camel-cased).
 *
 * - `specialTypes`: the CTRM special types it serves, at least one. Replaced `family`, which now
 *   lives on the addendum type.
 * - `tradeUnits` empty means every trade unit.
 * - `version` moves only when what renders changes (content, format or fields).
 * - `rowVersion` moves on ANY change, and goes back on `If-Match` with every `PUT` and `DELETE`.
 */
export interface AddendumTemplate {
  readonly id: number;
  readonly name: string;
  readonly specialTypes: readonly string[];
  readonly language: string;
  readonly tradeUnits: readonly string[];
  readonly templateContent: string;
  readonly contentFormat: string;
  readonly fields: readonly AddendumFieldMapping[];
  readonly active: boolean;
  readonly version: number;
  readonly rowVersion: string;
  readonly modifiedByUpn?: string;
  readonly modifiedAtUtc?: string;
  /**
   * True when Legal's text has no initials line (#1027, #1037): the server then waives the initials
   * anchor, and only that one. Omitted means false, so a server that predates the flag, and every
   * template saved before it, still requires the anchor.
   */
  readonly initialsAnchorOptional?: boolean;
}
/** What a create or an update sends: the server's `AddendumTemplateSubmission`. */
export type AddendumTemplateDraft = Pick<AddendumTemplate, 'name' | 'specialTypes' | 'language' | 'tradeUnits' | 'templateContent' | 'contentFormat' | 'fields' | 'active' | 'initialsAnchorOptional'>;
/**
 * An addendum type as `GET /api/v1/addendum-types` serves it (the server's `AddendumTypeRecord`): one
 * CTRM special type, its family, and whether Legal has approved it. A template is offered on a
 * record only when its type is `available`.
 */
export interface AddendumType {
  readonly specialType: string;
  readonly displayName: string;
  readonly family: AddendumFamily;
  readonly available: boolean;
  readonly rowVersion: string;
  readonly modifiedByUpn?: string;
  readonly modifiedAtUtc?: string;
}
/** What a type create or update sends: the server's `AddendumTypeSubmission`. */
export type AddendumTypeDraft = Pick<AddendumType, 'specialType' | 'displayName' | 'family' | 'available'>;
/** What `POST /api/v1/contracts/{n}/addendums` sends. `fields` is keyed by the CWS storage name. */
export interface AddendumGenerationRequest {
  readonly templateId: number;
  readonly fields: Readonly<Record<string, string>>;
}
/** What it answers. */
export interface GeneratedAddendum {
  readonly id: number;
  readonly status: string;
  readonly documentId: string | null;
  /**
   * #828: the route regenerates through a save. `Stored` (with `201`) issued a new document;
   * `Unchanged` (with `200`) found the text unchanged and sent nothing. Absent before #829.
   */
  readonly action?: 'Stored' | 'Unchanged';
}
/**
 * How any addendum call comes back, and the screens treat the three differently on purpose.
 *
 * - `done`: the server answered.
 * - `unavailable`: the route is not there yet (`404`) or the server cannot be reached (`0`). Both
 *   routes were wired before the backend published them, so this is a normal state, rendered as
 *   *not available yet*, and never a crash.
 * - `failed`: the server understood and refused, or broke. Its message is shown as an error, and a
 *   `400`'s `errors.<field>` arrive in `fieldErrors`, keyed as the server keys them, for the screen
 *   to put beside the field.
 * - `conflict`: a `409`. The row changed since it was read (a stale `If-Match`), or the server
 *   refuses for a reason it names (a duplicate code, a type still in use). Either way the screen says
 *   so and offers a reload; it never retries, which would overwrite the change it just detected.
 */
export type AddendumCall<T> = {
  readonly kind: 'done';
  readonly value: T;
} | {
  readonly kind: 'unavailable';
  readonly reason: string;
} | {
  readonly kind: 'failed';
  readonly message: string;
  readonly correlationId?: string;
  readonly fieldErrors?: Readonly<Record<string, readonly string[]>>;
} | {
  readonly kind: 'conflict';
  readonly message: string;
  readonly correlationId?: string;
};
/**
 * The sentence for a stale `If-Match`, the same from the HTTP and sample sources. The server's own
 * `detail` is preferred when it sends one, because a 409 also covers a refusal it names.
 */
export declare const ADDENDUM_CONFLICT_MESSAGE = "This changed since you opened it. Reload to see the current version, then make your change again.";
/** Reads and writes addendum templates. Every `PUT` and `DELETE` sends `If-Match: <rowVersion>`. */
export interface AddendumTemplateSource {
  list(): Observable<AddendumCall<readonly AddendumTemplate[]>>;
  create(draft: AddendumTemplateDraft): Observable<AddendumCall<AddendumTemplate>>;
  update(id: number, rowVersion: string, draft: AddendumTemplateDraft): Observable<AddendumCall<AddendumTemplate>>;
  /**
   * A `PUT` of the whole template with `active: false`, on the template's own `rowVersion`.
   *
   * ⚠ Its own method rather than the caller building the `PUT`, so there is one place that decides
   * deactivation is an update and not a delete. A deactivated template keeps its history; a deleted
   * one does not.
   */
  deactivate(template: AddendumTemplate): Observable<AddendumCall<AddendumTemplate>>;
  remove(template: AddendumTemplate): Observable<AddendumCall<void>>;
}
/** Reads and writes addendum types (`/api/v1/addendum-types`). `PUT`/`DELETE` send `If-Match`. */
export interface AddendumTypeSource {
  list(): Observable<AddendumCall<readonly AddendumType[]>>;
  create(draft: AddendumTypeDraft): Observable<AddendumCall<AddendumType>>;
  update(type: AddendumType, draft: AddendumTypeDraft): Observable<AddendumCall<AddendumType>>;
  remove(type: AddendumType): Observable<AddendumCall<void>>;
}
/** Generates an addendum document for a contract from a template and its CWS field values. */
export interface AddendumGenerationSource {
  generate(contractNumber: string, request: AddendumGenerationRequest): Observable<AddendumCall<GeneratedAddendum>>;
}
/**
 * The template seam. The shell provides the HTTP one; the playground and the tests provide the
 * sample one. Every consumer injects it **optionally**, so a host that embeds the record screen
 * without it gets a screen without the Addendum section's template picker, and the embedding host's
 * provider list does not grow.
 */
export declare const ADDENDUM_TEMPLATE_SOURCE: InjectionToken<AddendumTemplateSource>;
/** The generation seam. Injected optionally, for the same reason. */
export declare const ADDENDUM_GENERATION_SOURCE: InjectionToken<AddendumGenerationSource>;
/**
 * The type seam. Injected optionally: without it the record screen cannot tell which types Legal has
 * approved, so it offers no template and says why, rather than offering an unapproved one.
 */
export declare const ADDENDUM_TYPE_SOURCE: InjectionToken<AddendumTypeSource>;
/**
 * A template draft copied from a template, for an update.
 *
 * 🔴 `initialsAnchorOptional` is carried whenever the template has it (#1038). Dropping it would send
 * the flag as omitted, which the server reads as false, so deactivating a template with no initials
 * line would be refused for the anchor it was allowed to leave out.
 */
export declare function draftOf(template: AddendumTemplate): AddendumTemplateDraft;
/** A type draft copied from a type, for an update. */
export declare function typeDraftOf(type: AddendumType): AddendumTypeDraft;
/**
 * The templates a record offers (#676): active, serving the contract's special type, for a type
 * Legal has made available, and limited to the contract's trade unit when limited at all.
 *
 * Replaces `addendumFieldSetOf`, which read the old `fieldMapJson` and silently matched nothing once
 * the server stopped sending it. ⚠ Codes are trimmed, because CTRM pads them, and never case-folded,
 * because CTRM's codes are upper case. A type the list does not know is not available.
 */
export declare function addendumTemplatesFor(templates: readonly AddendumTemplate[], types: readonly AddendumType[], specialType: string | null | undefined, tradeUnit: string | null | undefined): readonly AddendumTemplate[];
/**
 * The prefix of a value the originator enters (D4), the server's `AddendumRules.CwsFieldPrefix`.
 *
 * 🔴 **Only these get a control.** A template's other mappings are filled without the originator: a
 * CTRM field from the contract, `customer.*` from the customer master (#1027) and
 * `generated.addendumDate` stamped by the server. The server refuses an entered key that is not
 * `addendum_*`, and one the template does not use (`AddendumComposer.EnteredProblems`).
 */
export declare const ADDENDUM_ENTRY_FIELD_PREFIX = "addendum_";
/** How an entered field is labelled and which control pattern it renders with. */
export interface AddendumFieldPresentation {
  readonly label: string;
  readonly controlPattern: ControlPattern;
  readonly kind?: CwsContractField['kind'];
}
/**
 * **Labels and control patterns, keyed by field name: presentation only (#1043).**
 *
 * 🔴 **This map never decides WHICH fields are offered.** The chosen template does. A field missing
 * from here still gets a control, labelled from its own name ({@link addendumFieldLabelFallback}), so a
 * template Legal adds or revises is fillable with no frontend release. Adding a row here only makes
 * its label read better.
 *
 * The provisional Family B sets supply the rest of the labels; they remain the admin picker's offer
 * list (#1038) and the sample templates' source, and are no longer the record screen's source.
 */
export declare const ADDENDUM_FIELD_PRESENTATION: Readonly<Record<string, AddendumFieldPresentation>>;
/**
 * A label made from the field's own name: `addendum_knockout_price` reads `Knockout price`. The name is
 * the only thing known about a field this frontend has never heard of, so it is used, never hidden.
 */
export declare function addendumFieldLabelFallback(field: string): string;
/** Whether the originator enters this field (the server's `IsCwsField`): an `addendum_*` name. */
export declare function isAddendumEntryField(field: string): boolean;
/**
 * **The fields the originator fills in for a template: exactly its `addendum_*` mappings (#1043).**
 *
 * - One control per field, however many placeholders print it.
 * - In the order the template prints them (the first `{{placeholder}}` in the content), so the form
 *   reads like the document. The server sorts mappings by placeholder, which is not an order a person
 *   would fill in. A mapping whose placeholder is not in the content keeps its list position, after.
 * - Every other mapping (CTRM, `customer.*`, `generated.addendumDate`) gets no control.
 *
 * `[]` for no template.
 */
export declare function addendumEntryFieldsOf(template: AddendumTemplate | null | undefined): readonly CwsContractField[];
/** One entered field as the section renders it: presented from the map, or from its own name. */
export declare function entryFieldFor(field: string): CwsContractField;
/**
 * The addendum type the server lists for a special type, or `null` (#1043).
 *
 * 🔴 **This is what decides whether the record carries an Addendum section**, and it mirrors the
 * server's rule (`AddendumTemplateResolver`): a save needs an addendum iff the special type has an
 * `AddendumTypes` row, available or not. An unavailable one still shows, so the screen can say why no
 * template is offered rather than leave the server's refusal unexplained. Trimmed, because CTRM pads
 * codes; never case-folded, because CTRM's codes are upper case.
 */
export declare function addendumTypeFor(types: readonly AddendumType[], specialType: string | null | undefined): AddendumType | null;
/**
 * **The e-signature anchors every addendum template must carry** (F10.3b, Legal's constraint).
 *
 * Legal ruled at the 2026-09-09 workshop that a template is used **as approved**, with a separate
 * signature anchor AND a separate initials anchor. The signing platform finds the places to sign by
 * matching this exact text in the rendered PDF, so a template missing one produces a document that
 * cannot be signed where Legal requires it, and nothing fails until a counterparty opens it.
 *
 * ### 🔴 `sig10__es_` is refused BY NAME, not merely "not accepted"
 *
 * The form with a size suffix looks like a harmless variant of the signature anchor, and the matcher
 * refuses it (recorded on #309). A template carrying it next to a correct anchor would pass a check
 * that only looked for the required text, so the check names it and refuses it on its own.
 *
 * ⚠ **Case-sensitive on purpose.** The initials anchor is `Int_es_` with a capital I; a
 * case-insensitive match would accept `int_es_`, which the matcher does not recognise.
 */
export declare const ADDENDUM_SIGNATURE_ANCHOR = "{{sig__es_:signer1:signature}}";
export declare const ADDENDUM_DATE_ANCHOR = "{{dte__es_:signer1:date}}";
export declare const ADDENDUM_INITIALS_ANCHOR = "{{Int_es_:signer1:initials}}";
/**
 * The refused size-suffixed signature form, matched case-insensitively. Any occurrence at all is a
 * refusal. Exported so `addendum-anchors.drift.spec.ts` can hold it to the server's
 * `addendum-anchors.json` (#672).
 */
export declare const ADDENDUM_REFUSED_SIGNATURE_FORM = "sig10__es_";
/**
 * Why a template's content would be refused, as sentences an administrator can act on. Empty means
 * the anchors are right.
 *
 * Pure, and one reason per problem rather than a single "anchors are wrong": an administrator
 * pasting in Legal's approved text needs to know WHICH anchor to add, and a template missing two of
 * them gets two reasons.
 *
 * `initialsOptional` is the template's `initialsAnchorOptional` (#1027, #1037): when true the initials
 * anchor is not required, as `AddendumAnchors.ProblemsWith` waives it. Only that anchor; the signature
 * and date anchors stay required and the refused form stays refused.
 */
export declare function addendumAnchorProblems(templateContent: string | null | undefined, initialsOptional?: boolean): string[];
/**
 * What a document is to the contract: CTRM's closed set, plus `unknown` for anything outside it.
 *
 * ⚠ `unknown` is kept rather than guessed, so the screen can list the document without mislabelling
 * it. The Documents tab puts it in an **Other** group so nothing CTRM sends is ever dropped.
 */
export type ContractDocumentRole = 'draft' | 'approved' | 'confirmed' | 'additional' | 'attachment' | 'unknown';
/**
 * Where a document came from. A separate axis from the role on purpose: several provenances share
 * one role, and the Addendums group is keyed on this (`rjoAddendum`), whatever the role.
 *
 * `null` means CTRM sent none; `unknown` means it sent one this screen does not recognise.
 */
export type ContractDocumentProvenance = 'generated' | 'otmCopy' | 'termsAndConditions' | 'rjoAddendum' | 'userImported' | 'userAttachment' | 'contractUpload' | 'unknown';
/**
 * Whether a document can be opened.
 *
 * 🔴 **Only `available` is openable.** `unknown` is never read as available (correction C-7): an
 * unrecognised status is not a healthy one. `notStored` is normal and common: CTRM still lists the
 * document but no longer holds its file.
 */
export type ContractDocumentStatus = 'available' | 'pending' | 'expired' | 'notStored' | 'unknown';
/**
 * One document, as `GET /api/v1/contracts/{n}/documents` lists it (F10.1, the LANDED route).
 *
 * ⚠ **This is the route as built, and it supersedes the shape F10.2's issue text describes**
 * (`{ id, kind, name, createdUtc, status: 'ready' | 'generating' }`). The identity is `documentEntry`,
 * CTRM's DSR entry number, and the name the screen shows is `description`, falling back to `fileName`.
 *
 * `createdStamp` is CTRM's timestamp verbatim: the backend does not parse it because its format has
 * not been observed on the wire, so it is shown as text, never reformatted here.
 */
export interface ContractDocument {
  readonly documentEntry: string;
  readonly role: ContractDocumentRole;
  readonly provenance: ContractDocumentProvenance | null;
  readonly documentType: string | null;
  readonly description: string | null;
  readonly fileName: string | null;
  readonly appearanceSequence: number | null;
  readonly status: ContractDocumentStatus;
  readonly createdStamp: string | null;
}
/** The whole list response. `dataOrigin` is `Simulated` while the CTRM documents API is unpublished. */
export interface ContractDocumentsResponse {
  readonly contract: string;
  readonly documents: readonly ContractDocument[];
  readonly dataOrigin: string;
  readonly warnings: readonly string[];
}
/**
 * How a list read comes back, and the tab treats the three differently on purpose.
 *
 * - `loaded`: the server answered. An empty `documents` is a real "no documents yet".
 * - `refused`: an answer Retry cannot change, shown with a title and detail and no Retry. Any `403`;
 *   for `ctrm-user-ambiguous`, `ctrm-user-not-found` and `ctrm-document-access-denied` the `detail`
 *   says what to do about it (ask the Help Desk), and the tab shows it verbatim. Also a `404` of type
 *   `contract-not-found` (#880), because CTRM has no such contract.
 * - `failed`: anything else, **including any other `404`, or a `0`**. Unlike the addendum routes, this
 *   route has landed, so its absence is a failure and not "not available yet".
 *
 * 🔴 **`failed` must never render as an empty tab** (F10.2 criterion 4): "no documents" is a claim
 * about the contract, and a failed read cannot make it.
 */
export type ContractDocumentsRead = {
  readonly kind: 'loaded';
  readonly response: ContractDocumentsResponse;
} | {
  readonly kind: 'refused';
  readonly title: string;
  readonly detail: string;
} | {
  readonly kind: 'failed';
  readonly message: string;
  readonly correlationId?: string;
};
/**
 * How a content read comes back.
 *
 * - `done`: the file, with the media type the server sent: a PDF or an image inline, anything else
 *   `application/octet-stream`. The tab shows only a PDF or an image, and offers the rest as a
 *   download (#495).
 * - `unavailable`: the server cannot be reached (`0`). Rendered as *this document can't be opened
 *   here yet*, never as a crash.
 * - `refused`: an answer Try again cannot change (#1004), shown with its title, detail and reference
 *   and no Try again. Any `401` or `403`, and the content route's `404` and `410`.
 * - `failed`: anything else, with the server's title and detail when it sent them, its reference, and
 *   Try again: a `502` (CTRM could not deliver the file, or it did not arrive intact), a `409` (still
 *   generating), a `500`.
 */
export type ContractDocumentContent = {
  readonly kind: 'done';
  readonly blob: Blob;
} | {
  readonly kind: 'unavailable';
  readonly reason: string;
} | {
  readonly kind: 'refused';
  readonly title: string;
  readonly detail: string;
  readonly correlationId?: string;
} | {
  readonly kind: 'failed';
  readonly title?: string;
  readonly message: string;
  readonly correlationId?: string;
};
/** Reads a contract's document list, and one document's content. */
export interface ContractDocumentsSource {
  list(contractNumber: string): Observable<ContractDocumentsRead>;
  content(contractNumber: string, documentEntry: string): Observable<ContractDocumentContent>;
}
/**
 * The documents seam (F10.2).
 *
 * ⚠ **Provided at the ROUTE level in the shell, not in `app.config.ts`**, so the HTTP source lands in
 * the record screen's lazy chunk rather than the initial bundle, which sits just under its error
 * budget. The record screen injects it **optionally**: a host that embeds the screen without it gets
 * no Documents tab, and the embedding host's provider list does not grow.
 */
export declare const CONTRACT_DOCUMENTS_SOURCE: InjectionToken<ContractDocumentsSource>;
/** The name a document is shown under: its description, then its file name, then its entry. */
export declare function contractDocumentName(document: ContractDocument): string;
/** The Documents tab's groups, in display order (docs/02a §6.4a, plus Other). */
export type ContractDocumentGroupId = 'contract' | 'additional' | 'attachments' | 'addendums' | 'other';
export interface ContractDocumentGroup {
  readonly id: ContractDocumentGroupId;
  readonly title: string;
  readonly documents: readonly ContractDocument[];
}
export interface ContractDocumentGrouping {
  /** Only the groups with something in them, in display order. */
  readonly groups: readonly ContractDocumentGroup[];
  /**
   * Contract documents held back because the contract has not had its first approval. The tab says
   * so rather than leaving the Contract group silently missing.
   */
  readonly heldBack: number;
  /** Whether the list shows the contract has been approved at least once. */
  readonly approved: boolean;
}
/**
 * Whether the contract has had its **first** approval, read from the document list itself.
 *
 * An `approved` row is the approved contract document (`WDOCE`) and a `confirmed` row the
 * countersigned one (`WDOCEF`); CTRM only produces either once the contract has been approved. So the
 * presence of either says the first approval has happened.
 *
 * ⚠ **Deliberately not the contract's CURRENT approval status.** A material change sends an approved
 * contract back for re-approval (BR-066), and its approval status then reads unapproved, but its
 * first approval still happened and its approved document still exists. The rule is about the first
 * approval, and the document set is the one place that still records it.
 */
export declare function hasFirstApproval(documents: readonly ContractDocument[]): boolean;
/**
 * Groups a contract's documents for the Documents tab (docs/02a §6.4a).
 *
 * - **Addendums**: provenance `rjoAddendum`, **whatever its role**. Taken first, so an RJO addendum
 *   CTRM files as an additional document is not listed twice.
 * - **Contract**: `draft`, `approved`, `confirmed`, in that order, each badged with its role.
 * - **Additional documents**: `additional`, in `appearanceSequence` order (the merge order).
 * - **Attachments**: `attachment`, as CTRM lists them.
 * - **Other**: role `unknown`, so nothing CTRM sends is ever dropped.
 *
 * ### 🔴 The first-approval rule (ruled 2026-09-29, the route's own description)
 *
 * *"Before the first approval the contract document is not shown; after it, it is."* So until
 * {@link hasFirstApproval} is true the Contract group's rows are held back and counted in `heldBack`,
 * and once it is, every contract row is shown, the draft included. That is what makes §6.4a's
 * Draft/Approved/Confirmed badges meaningful side by side: they only ever appear together after an
 * approval.
 *
 * ⚠ A pending draft on an unapproved contract is therefore held back too, generating state and all.
 * That follows the ruling as written; the backend simulator's own comment expects a pending draft to
 * be where the generating state is seen, and the two are flagged for the backend lane rather than
 * reconciled here.
 */
export declare function groupContractDocuments(documents: readonly ContractDocument[]): ContractDocumentGrouping;
/**
 * Which of `upsertContract`'s two paths CTRM took, read from its own response.
 *
 * `Unchanged` is the API's, not CTRM's: nothing differed, so nothing was sent (#835). Reachable only
 * through a save that carries an addendum (#830), so this screen does not produce it yet.
 */
export type ContractWriteAction = 'Created' | 'Updated' | 'Unknown' | 'Unchanged';
/**
 * What became of Save & Notify's request that CTRM email the contract's trader (BR-064, #831).
 *
 * - `NotRequested`: a plain Save.
 * - `Requested`: CTRM was asked. 🔴 **Never "the email was sent"**: CTRM emails only when the contract
 *   needs approval, and some of its notification failures (a trader with no email) come back as plain
 *   success by CTRM's design.
 * - `NotSent`: nothing had changed, so nothing went to CTRM and no email went.
 * - `Failed`: saved, but CTRM could not notify the trader.
 */
export type ContractWriteNotification = 'NotRequested' | 'Requested' | 'NotSent' | 'Failed';
/** What a completed save did. */
export interface ContractWriteResult {
  readonly contractNumber: string;
  readonly action: ContractWriteAction;
  readonly detail: string;
  readonly warnings: readonly string[];
  /** Absent from an API older than #835, and from a host's own source; read as `NotRequested`. */
  readonly notification?: ContractWriteNotification;
  /**
   * True when CTRM's answer was lost and the save was confirmed by reading the contract back. With
   * `Requested` it means whether CTRM notified is unknown.
   */
  readonly confirmedByReadBack?: boolean;
  /** What the save did with the contract's CWS addendum (#830). Absent from an API older than #829. */
  readonly addendum?: ContractWriteAddendumOutcome;
  /**
   * What the save did with the contract's CWS attachments (#499, F10.6). Present on an attachment
   * write's answer and on a create that carried files; absent elsewhere.
   */
  readonly attachments?: {
    readonly changes: readonly ContractWriteAttachmentChange[];
  };
}
/** One change a save made to the contract's attachments. See `ContractAttachmentChange`. */
export interface ContractWriteAttachmentChange {
  readonly action: 'Stored' | 'Resent' | 'Removed' | 'AlreadyRemoved' | 'Unknown';
  readonly documentId: string | null;
  readonly supersededDocumentId: string | null;
}
/**
 * A file a new contract carries (#499, F10.6): it rides the create as a multipart part, with its
 * document type in the `contract` part's `attachments` manifest.
 */
export interface ContractCreateAttachment {
  readonly file: File;
  readonly documentType: string;
}
/**
 * What a save did with the contract's CWS addendum (#828, #830).
 *
 * - `Stored`: a new addendum document went to CTRM, so the contract goes back for approval and
 *   signature (BR-066).
 * - `Reused`: the printed text did not change, so nothing new was issued.
 * - `Withdrawn`: the special type no longer takes an addendum.
 * - `None`: the contract has no addendum.
 */
export interface ContractWriteAddendumOutcome {
  readonly action: 'None' | 'Stored' | 'Reused' | 'Withdrawn';
  readonly addendumId?: number | null;
  readonly documentId?: string | null;
  readonly supersededDocumentId?: string | null;
}
/**
 * The addendum a save carries (#830): the template and the entered `addendum_*` values.
 *
 * 🔴 **Omitted, the server keeps the stored template and values (BR-096).** So a screen sends it
 * only when the user changed the addendum, or when the special type changed to another addendum
 * type, where the server needs the new template (#828's final review, F3). `fields` takes CWS
 * `addendum_*` names only; a CTRM field name is refused.
 */
export interface ContractWriteAddendum {
  readonly templateId: number | null;
  readonly fields: Readonly<Record<string, string>>;
}
/** A contract's writable values, keyed by CTRM field name. */
export interface ContractWriteFields {
  readonly contractNumber: string;
  readonly fields: Readonly<Record<string, unknown>>;
}
/**
 * Reads and writes a contract's field values.
 * </summary>
 *
 * **Keyed by CTRM field name throughout, not by component name**, because that is the only vocabulary
 * both sides share: `constraints.json` is keyed that way, `GET /meta/constraints` serves it that way,
 * the API's request body takes it that way, and `@cws/domain-contracts` maps each control to its
 * `ctrmField`. Translating in the middle would put a third spelling of every field in the codebase,
 * which is precisely the drift Known Issue 18 makes invisible.
 */
export interface ContractWriteSource {
  /** The contract's writable values, for prefilling the edit form. */
  fields(contractNumber: string): Observable<ContractWriteFields>;
  /**
   * Creates a contract.
   *
   * ⚠ Pass `options.idempotencyKey` (#557), and pass the SAME key on a retry of the same create. It
   * is optional only so an existing host implementation still compiles.
   */
  create(fields: Readonly<Record<string, unknown>>, collections?: ContractWriteCollections, options?: ContractWriteOptions): Observable<ContractWriteResult>;
  /**
   * Updates a contract.
   *
   * ⚠ **Send only the fields that changed.** The API merges onto a fresh read of the contract, so an
   * unchanged field is carried through from CTRM's own value — which is both how untouched data
   * survives a full-replace upsert and how Known Issue 17's lossy numerics are left alone.
   */
  update(contractNumber: string, fields: Readonly<Record<string, unknown>>, collections?: ContractWriteCollections, options?: ContractUpdateOptions): Observable<ContractWriteResult>;
}
/**
 * A contract's child collections, keyed by CTRM's collection name (F2.3b, #372).
 *
 * ### 🔴 OMITTING a collection preserves it. SUPPLYING IT EMPTY CLEARS IT.
 *
 * `upsertContract` replaces a supplied collection's contents **entirely** — an omitted row is a
 * deleted row — and answers `202` either way (correction C-4), so the destructive request and the
 * harmless one are indistinguishable from the response. The API's own `ContractWriteBody.Collections`
 * says so in the same words.
 *
 * ⚠ **Therefore this type is optional at every call site, and a caller must pass it only when the
 * collection actually changed.** `undefined` is not "no periods"; it is "leave the periods alone".
 * A screen that always supplied its current rows would put a full replace on the save path of every
 * contract edit, and a grid that had failed to load would clear the contract's periods and report
 * success.
 */
export interface ContractWriteCollections {
  /**
   * `ship_periods` rows, in CTRM's own member names.
   *
   * ⚠ **No description member, deliberately.** `ship_period_description` is a `base_data` scalar
   * describing the periods *as a whole* — Known Issue 18 — so BR-023's generated text is a field on
   * the contract, not a column here. `constraints.json` caps this at 12 rows.
   */
  readonly ship_periods?: readonly ContractWriteShipPeriod[];
  /**
   * `notes` rows, in CTRM's own member names. `constraints.json` caps this at 50 rows.
   *
   * 🔴 **FULL REPLACE, and this collection has a trap the others do not: the base you would merge
   * onto can be silently EMPTY.** `getContract` answers `200` with `notes: []` whenever reassembling
   * them overflows `LISTAGG`'s `VARCHAR(4000)` — one note over 4,000 bytes voids the whole cursor —
   * and reports it only in a response header, surfaced to us as a warning on the aggregate.
   *
   * So "read the notes, append one, send them all back" **deletes every note on the contract** when
   * that overflow happened, and CTRM answers `202`. The API refuses the *silent* case, where a caller
   * relies on the merge base; it deliberately does **not** refuse a caller that supplies `notes`
   * itself, because that is the only route by which an unreadable note could ever be repaired.
   *
   * ⚠ **That makes it the caller's job here.** A screen appending a note must first establish that
   * the notes it read are complete, and refuse otherwise — see the record screen's Log tab.
   *
   * ⚠ **#907: what CTRM does with the rows was measured on apiuat 2026-10-21 (the API's
   * `LmsFlagWrite`), and it is a merge by code, not a replace:** a stored note left out is KEPT, and a
   * row sent with its code and BLANK text DELETES it. The record screen's contract text still sends
   * every stored note back (`contractTextNotesPayload`), so it is safe under either reading, and deletes
   * an override the one way that works.
   */
  readonly notes?: readonly ContractWriteNote[];
  /**
   * `remarks` rows, in CTRM's own member names (#789). `constraints.json` caps this at 11.
   *
   * 🔴 **Full replace, like the others: send it only when a remark changed, and send all of them.**
   * And **packed**: `conups` stops reading at the first blank `remark_type`, so no blank row may come
   * before a real one. {@link remarksPayload} builds it that way.
   */
  readonly remarks?: readonly ContractWriteRemark[];
}
/**
 * One `remarks` row, exactly as `constraints.json` declares it (#789, C-19).
 *
 * `remark_type` is one of CTRM's 11 codes: `P`, `1` to `9`, `A`. `remark_note` is at most 72 characters.
 */
export interface ContractWriteRemark {
  readonly remark_type: string;
  readonly remark_note: string;
}
/** One `notes` row, exactly as `constraints.json` declares it. */
export interface ContractWriteNote {
  readonly note_prefix: string | null;
  readonly note_code: string | null;
  readonly note: string | null;
}
/**
 * One `ship_periods` row: all five members `constraints.json` declares, all writable (#1018).
 *
 * 🔴 **Every member is required, because the row is written whole.** The collection is a full
 * replace, so a member left off is written EMPTY and CTRM answers `202`. Before #1018 this type had
 * only the first three, and every ship-period save blanked each period's late pickup and early
 * delivery dates. Build rows with `shipPeriodWriteRow`; `ship-period-write.drift.spec.ts` holds its
 * members to `constraints.json`'s.
 */
export interface ContractWriteShipPeriod {
  readonly begin_ship_date: string | null;
  readonly end_ship_date: string | null;
  readonly ship_quantity: number | null;
  readonly late_pickup_date: string | null;
  readonly early_delivery_date: string | null;
}
/**
 * Per-request options on a contract create (#557).
 *
 * `idempotencyKey` is sent as the `Idempotency-Key` header. **One key per new contract**: minted when
 * the create form opens, reused on every retry of that create, and replaced only for a different
 * contract. The server (#558) stores the outcome per key and answers a repeat with the original
 * answer instead of calling CTRM again, which is what stops a lost answer from becoming a second
 * contract. A key reused with a different body answers `422`.
 *
 * ⚠ Until #558 lands the API ignores the header, so sending it early is harmless.
 */
export interface ContractWriteOptions extends ContractUpdateOptions {
  readonly idempotencyKey?: string;
  /**
   * Files picked before the first Save (#499, F10.6). Non-empty, the create is sent as
   * `multipart/form-data`; absent or empty, it is the JSON create it always was.
   *
   * ⚠ A multipart create needs a reserved contract number in `fields` (422
   * `errors["attachment.contract"]` otherwise), because the files are stored under it before CTRM
   * answers. Never on an update: the server refuses a manifest on `PUT /contracts/{n}`.
   */
  readonly attachments?: readonly ContractCreateAttachment[];
}
/**
 * Per-request options on any contract save.
 *
 * `sendNotification` is Save & Notify (BR-064, #831): CTRM emails the contract's trader, and only when
 * the contract needs approval. 🔴 **Opt-in only**: absent or false is a plain Save, the ruled default,
 * and the body then carries no `sendNotification` member at all.
 */
export interface ContractUpdateOptions {
  readonly sendNotification?: boolean;
  /** The addendum this save carries (#830). Absent keeps the stored one; see {@link ContractWriteAddendum}. */
  readonly addendum?: ContractWriteAddendum;
  /**
   * Sets (`true`) or clears (`false`) the contract's LMS flag (#973, the server half #985).
   *
   * 🔴 **Absent means unchanged, so pass it only when the user changed the box.** The API refuses
   * clearing an automatic flag, and any change while the flag is `unknown`, with a `422` on
   * `errors["lmsFlag"]`.
   */
  readonly lmsFlag?: boolean;
}
/**
 * Mints an idempotency key. Injected so a spec can tell "the same key" from "a new key" by which
 * call minted it, rather than by two random strings happening to differ.
 */
export declare const CONTRACT_IDEMPOTENCY_KEY: InjectionToken<() => string>;
/** The seam, so a screen can be tested without HTTP and embedded hosts can supply their own. */
export declare const CONTRACT_WRITE_SOURCE: InjectionToken<ContractWriteSource>;
/**
 * **What happened inside an embedded CWS screen, typed for the host** (F9.5, ADR-13).
 *
 * A host mounting the contract record has no other way to learn that a contract was opened, saved,
 * left, or failed. Events notify; they do not replace a Contracts API read, so every payload carries
 * a stable identifier and nothing a host should treat as the record itself.
 *
 * ### Why this lives in the domain library
 *
 * A host importing the contract set must not drag a feature barrel in with it (#252). The domain
 * library is what every host already installs for the data seams, so the union rides with it.
 *
 * ### 🔴 No DOM assumption
 *
 * Nothing here is a `CustomEvent`, and the emitter is an `Observable`. An Angular host subscribes
 * directly; an Elements bridge for a host below the Angular floor can forward each event to
 * `dispatchEvent` without the type changing.
 */
export type CwsContractEvent =
/** A contract record loaded and is on screen. */
{
  readonly type: 'contract-opened';
  readonly contractNumber: string;
  readonly mode: 'view' | 'edit';
} |
/**
 * A save was accepted and the contract re-read.
 *
 * ⚠ `action` is CTRM's own answer. `Unknown` is a real value: every CTRM write answers `202`
 * regardless of outcome (C-4), so a host must not read "saved" as more than "accepted and re-read".
 */
{
  readonly type: 'contract-saved';
  readonly contractNumber: string;
  readonly action: ContractWriteAction;
  readonly warnings: readonly string[];
} |
/**
 * The screen wants to go somewhere. The host decides what that means.
 *
 * The event half of F9.1's `navigate()` seam: the intent is exactly what `CmsHostContext.navigate`
 * received, so a host that routes through its own outlet can also observe where the user went.
 */
{
  readonly type: 'navigation-requested';
  readonly intent: CmsNavigationIntent;
} |
/**
 * Something the user was told failed.
 *
 * `message` is the plain-language sentence the screen showed, never a stack trace or wire body.
 * `correlationId` is present when the failure reached the API, for quoting to support.
 */
{
  readonly type: 'error';
  readonly operation: 'load' | 'save';
  readonly contractNumber: string | null;
  readonly message: string;
  readonly correlationId?: string;
};
/** The discriminator values, for a host that wants to check exhaustiveness. */
export type CwsContractEventType = CwsContractEvent['type'];
/**
 * The union's version, semver'd as part of the host contract.
 *
 * 🔴 **The rule.** A new variant or a new OPTIONAL field is a **minor** bump, so a host must keep a
 * default branch in any switch over `type`. Removing a variant, removing or renaming a field, or
 * changing a field's type is a **major** bump. A wording change inside `message` is neither: it is
 * display text, and a host must never branch on it.
 */
export declare const CWS_CONTRACT_EVENTS_VERSION = "1.0.0";
/**
 * Where embedded screens publish {@link CwsContractEvent}s, and where a host subscribes.
 *
 * Provided in root, so a host and every CWS screen it mounts share one stream through the host's own
 * root injector. A host needs no provider for it.
 */
export declare class CwsContractEvents {
  private readonly subject;
  /** Every event, in the order the screens emitted them. Hot: a late subscriber sees only later ones. */
  readonly events$: Observable<CwsContractEvent>;
  /** For CWS screens. A host has no reason to call this. */
  emit(event: CwsContractEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<CwsContractEvents, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Where one of CTRM's `invalid_params[].name` values can actually be shown (F2.4).
 *
 * ### 🔴 Why three outcomes rather than two
 *
 * The obvious split is "addresses a control" / "does not". It is not enough, because the two
 * not-a-control cases need opposite wording and the screen was conflating them:
 *
 * - **A field this layout does not render.** `commodity_description` is a real CTRM field; if the
 *   layout drops it, the refusal still names something the user could recognise. Naming it is
 *   useful.
 * - **A name that is not a field at all.** CTRM answers with procedure names and composites
 *   (docs/04 §8.2) — `ContractProcedure`, `getContract`. Rendering one of those under a "Field"
 *   heading invents a field that does not exist and sends the user looking for it.
 *
 * So the third outcome exists to stop the screen asserting something false.
 */
export type InvalidParamTarget =
/** A control on this screen. Mark it, badge its tab, focus it. */
{
  readonly kind: 'control';
  readonly ctrmField: string;
  readonly componentName: string;
} |
/** A real CTRM field this layout does not render. Name it, but do not pretend to focus it. */
{
  readonly kind: 'unrenderedField';
  readonly ctrmField: string;
} |
/** Not a field. Goes to the form-level banner as a reason, never as a field name. */
{
  readonly kind: 'form';
  readonly name: string;
};
/**
 * CTRM names that address a control under a different key.
 *
 * 🔴 **Empty, and that is a finding rather than an omission.** The write endpoints pass an
 * **identity** mapping server-side (`ContractEndpoints.CtrmFieldIsTheFormKey`) precisely because
 * "the form is already keyed by CTRM field name" — so on the save path there is nothing to
 * translate, and inventing entries here would be a second spelling of a vocabulary ADR-7 exists to
 * keep singular.
 *
 * It is declared anyway because the *read* endpoints keep the default mapper and CTRM names
 * composites there, so the first real alias has somewhere to go that is not a conditional buried in
 * a component. **Add a row only with the CTRM name observed on the wire**, never a guessed synonym:
 * a wrong alias silently marks the wrong control, which is worse than not marking one at all.
 */
export declare const INVALID_PARAM_ALIASES: Readonly<Record<string, string>>;
/**
 * Whether a name is shaped like a CTRM `base_data` field.
 *
 * **Measured, not guessed: all 110 `ctrmField` values in the layout match `^[a-z][a-z0-9_]*$`.**
 * CTRM's own field vocabulary is lowercase snake_case throughout, so anything carrying an uppercase
 * letter, a colon or a bracket is a procedure name, a composite, or the `*` operation sentinel.
 *
 * ⚠ **This deliberately duplicates part of the API's `CtrmFieldError.IsFieldName`, and is stricter.**
 * That one is documented as *"a weak heuristic on purpose … not to be authoritative"* — it rejects
 * only `*`, names containing `:` and names starting with `sp`. `getContract` and `ContractProcedure`
 * both pass it and arrive in `errors` looking like fields. This is the second line, on the screen
 * that would otherwise render them.
 *
 * 🔑 **It fails toward the banner, which is the safe direction.** A real field wrongly judged a
 * non-field still reaches the user, worded as a reason; a non-field wrongly judged a field becomes a
 * control that does not exist.
 */
export declare function looksLikeCtrmFieldName(name: string): boolean;
/**
 * Decides where a single `invalid_params[].name` can be shown.
 *
 * The documented fallback F2.4 asks for: **an unmapped name is surfaced, never dropped.** Every
 * input returns one of the three targets, so there is no path on which a refusal disappears — which
 * is the failure that leaves a user with a save that failed for no stated reason.
 */
export declare function classifyInvalidParam(name: string): InvalidParamTarget;
/**
 * Splits a whole `errors` map into the three targets, preserving every reason.
 *
 * ⚠ **Returns form-level reasons as TEXT, with the name folded in.** The banner renders reasons, not
 * name/value pairs, so a caller that kept the name separately would have to invent a presentation
 * for it — and the two screens would invent different ones.
 */
export declare function classifyInvalidParams(errors: Readonly<Record<string, readonly string[]>>): {
  readonly controls: readonly {
    ctrmField: string;
    componentName: string;
    reasons: readonly string[];
  }[];
  readonly unrenderedFields: readonly {
    ctrmField: string;
    reasons: readonly string[];
  }[];
  readonly formReasons: readonly string[];
};
/**
 * Which of BR-002a's tests said yes.
 *
 * Branch 2 — "the customer id appears as `GNP003.LCUST`" — is **deliberately absent**. It is
 * withdrawn, and the standing rule is *do not ship branch 2 alone; it fails silently*: measured over
 * live rows it covers **59.4%** of intercompany customers against branch 1's **99.6%**, so a build
 * carrying only branch 2 would classify two customers in five as ordinary and nothing would report
 * it. Numbering the branches after CTRM's own order keeps that absence visible rather than tidy.
 */
export type IntercompanyBranch = 1 | 3;
/**
 * Whether this customer is intercompany, and how confident that is.
 *
 * 🔴 **`noMatch` and `cannotClassify` are both "not intercompany" and they are not the same thing.**
 * The first is an answer; the second is the absence of one. They are separated because the screen
 * must fail **open** on the second — see {@link classifyIntercompany} — and because a future branch 1
 * changes how many customers land in `cannotClassify` without changing the verdict for anyone else.
 */
export type IntercompanyVerdict = {
  readonly intercompany: true;
  readonly branch: IntercompanyBranch;
} | {
  readonly intercompany: false;
  readonly reason: 'noMatch' | 'cannotClassify';
};
/** What BR-002a needs to decide. */
export interface IntercompanyFacts {
  /** The contract's `customer_id` — `maxLength: 7` in `constraints.json`. */
  readonly customerId: string | null;
  /**
   * **BR-002a branch 1** — `GNP005.RINDFD`, the customer-industry field, carrying `IC`, `IC/IB`,
   * `IC/SW`.
   *
   * 🔴 **The seam, and it is `undefined` everywhere today.** No endpoint exposes it and there is no
   * customer route at all (#47); CTRM brief 07 is what changes that. Declared now so the branch has
   * somewhere to arrive that is not a new parameter on every caller — and so the omission is visible
   * in the type rather than implied by its absence.
   *
   * ⚠ `undefined` means *"nobody asked"*; `null` means *"asked, and CTRM had none"*. Only the second
   * is evidence, and neither is evidence of **not** intercompany.
   */
  readonly customerIndustryCode?: string | null;
  /** Every `GNP003.LOCCOD` we hold — `scm/locations`' `code`, already fetched and cached. */
  readonly locationCodes: Iterable<string>;
}
/**
 * **BR-002a — is this customer intercompany?**
 *
 * Implements **branch 3** and leaves **branch 1** wired but unsupplied. The two are ORed, exactly as
 * CTRM ORs them (`conups.sqlrpgle:3272-3299`), so adding branch 1 later can only turn a `false` into
 * a `true` — it can never reclassify someone this already answered for.
 *
 * ### 🔴 It fails OPEN, and that direction is a deliberate choice rather than a free one
 *
 * BR-002a feeds **BR-002**, which makes the whole form read-only for an intercompany *purchase*. So a
 * false positive **blocks legitimate work**: it locks a contract a trader is entitled to edit, with
 * no way round it from the screen. Uncertainty therefore resolves to **not** intercompany.
 *
 * ⚠ The comfortable argument for the other direction — *"a wrong answer fails safe because CTRM
 * blocks the write anyway"* — is **struck in docs/01 §7.1 as partly false**. The real block
 * (`wnr051e:4436-4448`) fires on `WNR051E`'s own narrower flag and *"does not fire for exactly the
 * population this paragraph is about"*, and BR-024 does not fail safe either. Failing open is chosen
 * knowing that, because an over-lock is immediate and total while an under-lock is a divergence CTRM
 * may still catch.
 */
export declare function classifyIntercompany(facts: IntercompanyFacts): IntercompanyVerdict;
/**
 * **BR-002** — whether the whole form must be read-only because this is an intercompany *purchase*.
 *
 * ⚠ **Both halves, and the prefix half is what keeps it narrow.** CTRM short-circuits intercompany to
 * false for any prefix type other than `S` (`conups.sqlrpgle:3274`), while BR-002 specifies the
 * read-only form for a `P`. That discrepancy is an open research question in docs/06 B10 and is
 * **not** resolved here: this implements BR-002 as written, and a ruling that changes it changes this
 * one function.
 */
export declare function isIntercompanyPurchase(verdict: IntercompanyVerdict, contractPrefixType: string | null): boolean;
/**
 * The API base URL, e.g. `https://localhost:7041/api/v1`.
 *
 * Injected rather than imported from `environments/environment.ts` because this is a library: the
 * shell is only one of its two consumers, the Module Federation remote is the other (ADR-11), and a
 * library that reaches into an application's environment file cannot be reused by a host that has no
 * such file.
 */
export declare const CONTRACTS_API_URL: InjectionToken<string>;
/**
 * The route segments for `GET /api/v1/reference/{referenceSet}`.
 *
 * ## 🔴 These are the CWS API's enum NAMES, and CTRM's own segments are different
 *
 * This is the one place in the application where the two disagree, and the disagreement is silent.
 *
 * | | Segment | Where it is declared |
 * |---|---|---|
 * | **CWS** — what this client sends | `MarketCodes` | `ReferenceSet.cs`, an enum member |
 * | **CTRM** — what the API sends onward | `market-codes` | `ReferenceSets.RouteFor` |
 *
 * ASP.NET binds `{referenceSet}` to the enum **by member name**, so a kebab-case segment matches no
 * member and the request is refused by model binding **before the handler runs** — a bare `400` with
 * no title and nothing naming the set. The frontend's `catchError` then settles that as an empty
 * list, which renders as a dropdown with no options rather than as an error.
 *
 * ⚠ **Every other source names the kebab-case form**: docs/04, the RPG, `RouteFor`, and every note
 * anyone has written about these routes. So the wrong spelling is the one within easy reach, and it
 * is the one that was reached — #481, where the market cascade sent kebab-case for both of its calls
 * and had very likely never loaded in any environment.
 *
 * 🔑 **One object rather than six string literals, because a second hand-typed spelling is exactly
 * how #481 happened.** This mirrors `ReferenceSets.RouteFor`'s own remark on the backend side — that
 * it is the only place the segments live.
 *
 * ⚠ **`Locations` is deliberately absent and is not an omission.** The CTRM location list is its own
 * route, `GET /api/v1/locations` (`ReferenceEndpoints.cs`), and there is no `Locations` member on the
 * enum. A field declaring `referenceSet: 'Locations'` is served from that route, never from this one;
 * adding it here would invite exactly the `400` this module exists to prevent.
 */
export declare const REFERENCE_ROUTES: {
  /** The 27 field vocabularies, discriminated by a `prefix` query parameter (#83, #219). */
  readonly codes: "Codes";
  readonly commodities: "Commodities";
  /** Parameterised: `location`, `commodityCode`. Fetched reactively, not bundled. */
  readonly marketCodes: "MarketCodes";
  /** Parameterised: `location`, `commodityCode`, `marketCode`, `languageCode`. */
  readonly marketMonths: "MarketMonths";
  readonly marketZones: "MarketZones";
  /**
   * Searched, never bundled (#1064): it refuses a call with none of `code`, `name`, `city`, `state`.
   * `code` is exact, `name` contains, and the parameters AND together.
   */
  readonly originDestinationCodes: "OriginDestinationCodes";
};
/** A segment this client is allowed to put after `/reference/`. */
export type ReferenceRoute = (typeof REFERENCE_ROUTES)[keyof typeof REFERENCE_ROUTES];
/**
 * Whether CTRM is accepting work, as the API reports it (F1.4, corrections C-6 and C-7).
 *
 * The five are an exact set of tokens. Anything else — a state added server-side after this client
 * shipped, a body shaped differently, a failed read — is `Unknown`, and `Unknown` is inside the hard
 * gate.
 */
export declare const AVAILABILITY_STATES: readonly ["Available", "Closed", "NightRun", "Unreachable", "Unknown"];
export type AvailabilityState = (typeof AVAILABILITY_STATES)[number];
/** What the shell says about a state, and whether writes are available under it. */
export interface AvailabilityNotice {
  readonly title: string;
  readonly detail: string;
  readonly blocksWrites: boolean;
}
/**
 * Whether the hard gate is closed for this state.
 *
 * 🔴 `Unknown` returns `true`. Not knowing whether CTRM is accepting work is not the same as it
 * being fine, and a write attempted in that state is the case the gate exists for.
 */
export declare function writesBlockedBy(state: AvailabilityState): boolean;
/**
 * Narrows whatever the wire carried to a state.
 *
 * 🔴 **Everything unrecognised becomes `Unknown`, never `Available`.** The tempting default is the
 * optimistic one — a missing field on an older server would then leave the application working — and
 * it disables the gate at exactly the moment it is needed. An exact, case-sensitive match against the
 * declared set is what makes the fallback meaningful.
 */
export declare function toAvailabilityState(value: unknown): AvailabilityState;
export declare function availabilityNotice(state: AvailabilityState): AvailabilityNotice;
/**
 * The `GET /api/v1/contracts` response, mirrored field for field.
 *
 * **Sourced, not invented.** Every member below is copied from the API: the rows from
 * `ContractSummary` (`src/Scoular.Contracts.Application/Contracts/ContractSummary.cs`), the envelope
 * from the projection in `ContractEndpoints.GetContractsAsync`. Names are camelCase because the API
 * configures no `JsonSerializerOptions`, so System.Text.Json's default applies.
 *
 * This matters because a wrong field name fails *silently* — it deserialises to `undefined` and
 * renders as an empty cell, with no error anywhere. That is Known Issue 18 on the backend and it
 * behaves identically here. Verify against the C# record, never against a doc.
 */
/** One grid row. 24 fields, matching `ContractSummary` exactly. */
export interface ContractSummary {
  /** Composed by CTRM, e.g. `SC1240000`, with an `-A` suffix on amended contracts. */
  readonly contractNumber: string;
  /** The CTRM location code. Trade unit *is* the location (B12, C-15). */
  readonly tradeUnit: string | null;
  /** ISO `yyyy-MM-dd` — a .NET `DateOnly`, so no time component and no timezone. */
  readonly contractDate: string | null;
  readonly customerId: string | null;
  /**
   * The customer's name — **populated on `?status=unapproved` and null on every other status.**
   *
   * ⚠ **Corrected 2026-09-10; this said "null on the list route, always".** That was true when
   * written and #107 falsified it: `?status=unapproved` is a *different backend procedure*
   * (`getUnapprovedContracts` returning `dsCon`, not `OpenDS`) and it does carry
   * `customer_name char(30)`. `ContractSummary.CustomerName`'s own remarks on the API say so.
   *
   * So the approvals queue can show a name where the home grid structurally cannot (#47) — and any
   * column shared between the two must go through a formatter that falls back to the id, never
   * render this directly.
   *
   * ⚠ **On `open` and `closed` the field is ABSENT from the wire record, not blank on it.** `OpenDS`
   * declares no `customer_name` member, so there is nothing to map and no request shape that would
   * produce one. Worth stating because "always null" invites someone to go looking for the value.
   *
   * 🔑 **Deliberately not being fixed CTRM-side** (JFrisbie, 2026-09-15). The read layer is moving to
   * GraphQL (#240, ADR-15) and its `contracts` query returns `customerName` **inline** — measured
   * live, and it is what retired the batched-lookup design planned instead — with a dedicated
   * `customers` query behind it waiting only on a role grant. The name arrives with the transport
   * switch, so asking CTRM to widen `OpenDS` would be building something the migration discards.
   * CR-10 was withdrawn on the same reasoning.
   */
  readonly customerName: string | null;
  readonly customerContract: string | null;
  readonly commodity: string | null;
  readonly quantity: number | null;
  readonly quantityUom: string | null;
  /** Contract quantity not yet priced. **The unpriced queue's whole filter** (docs/02 §5.1). */
  readonly unpricedQuantity: number | null;
  /** Quantity applied against shipments. Part of BR-054's settlement dimension. */
  readonly appliedQuantity: number | null;
  /** Quantity still open. Part of BR-054's settlement dimension. */
  readonly openQuantity: number | null;
  readonly price: number | null;
  readonly basisPrice: number | null;
  readonly priceTypeCode: string | null;
  readonly paymentTerms: string | null;
  readonly marketZone: string | null;
  /**
   * ⚠ **Null on `open` and `closed`; populated on `unapproved`** — same correction as
   * {@link ContractSummary.customerName}, same cause. It is also the filter CTRM accepts by name on
   * that status and refuses on the others (#109).
   */
  readonly traderInitials: string | null;
  readonly trader: string | null;
  readonly originName: string | null;
  readonly destinationName: string | null;
  readonly shipPeriodBegin: string | null;
  readonly shipPeriodEnd: string | null;
  readonly traderApprovalStatus: string | null;
  readonly customerConfirmStatus: string | null;
  /**
   * ⚠ **Null on `open`/`closed`, populated on `unapproved` — and it FAILS OPEN, so do not read it
   * as evidence a broker confirmed anything (#124).**
   *
   * It is derived CTRM-side, not stored: `coalesce(s2.status, 'Confirmed')` over a CTE whose join is
   * pinned to the contract version. Any upsert update bumps the version while `conups` never writes
   * `BRKCONFRM`, so the row is orphaned and the contract reads **broker-confirmed with no broker
   * involved** — and a contract with no broker at all reads Confirmed from creation onward.
   *
   * Safe only as *"nothing outstanding"*. The confirmation indicator (docs/02 §4.4) therefore lights
   * this segment from the field being **populated**, and the screen says the value is CTRM-derived
   * rather than asserting a broker signed.
   */
  readonly brokerConfirmStatus: string | null;
  /**
   * Whether the contract is closed (F4.3a, docs/02 §2.2).
   *
   * Supplied by the list route rather than derived here from the status filter: the filter selects
   * which CTRM procedure served the page, and "closed" as a fact about the contract is the server's
   * to state. Deriving it would be a different rule wearing the same name.
   *
   * ⚠ Until the backend carries it, {@link HttpContractListSource} normalises an absent value to
   * `false`, so the grid behaves exactly as it did before the field existed.
   */
  readonly isClosed: boolean;
  /**
   * Whether the customer is intercompany per BR-002a, or `null` when the list route cannot say.
   *
   * 🔴 **`null` must leave every gated action ENABLED.** A wrong lock blocks a trader from a contract
   * they are entitled to edit with no way round it from the screen, so uncertainty fails open — the
   * same rule F2.3c applies to the form. CTRM enforces the real intercompany-purchase write block
   * server-side; this flag only decides what the row offers.
   *
   * ⚠ Until the backend carries it, {@link HttpContractListSource} normalises an absent value to
   * `null`, which is the fail-open state by construction.
   */
  readonly isIntercompany: boolean | null;
}
/** The paged envelope. */
export interface ContractListPage {
  readonly rows: readonly ContractSummary[];
  readonly totalCount: number;
  readonly page: number;
  readonly pageSize: number;
  readonly totalPages: number;
  /**
   * `'Live'` or `'Simulated'`. A string rather than a number because the endpoint projects it with
   * an explicit `.ToString()`; the same value also arrives on the `X-CMS-Data-Origin` header.
   * F4.1a owes a banner when this is `Simulated` — a demo that silently shows generated data is how
   * generated data gets mistaken for a production readout.
   */
  readonly dataOrigin: CtrmDataOrigin;
  /**
   * True when the BFF applied filters CTRM would not. Currently **always true**, because CR-4 (#31)
   * is unimplemented: the API fetches the whole status set for the trade unit and filters in
   * process. Spike 1 measured that at p50 3.9 s / 780 KB for 880 rows to serve a page of 50, so
   * this flag is the user-visible edge of a real performance problem, not a curiosity.
   */
  readonly filteredInProcess: boolean;
  /**
   * The sort chain the API applied across the **whole** result set, echoed back in the same
   * `key:direction,…` form the request used — or `null` when it applied its own newest-first order.
   *
   * **Optional because the API does not send it yet**, and that absence is load-bearing rather than
   * untidy: an unknown query parameter is ignored silently, so without an echo the grid could not tell
   * a server that sorted 880 rows from one that ignored the request and handed back page 1. `undefined`
   * therefore means "pre-change server" and keeps the page-local caveat on screen. See
   * {@link isServerSorted}.
   *
   * Make it required once the API ships it; the type is optional only for as long as both servers
   * exist.
   */
  readonly appliedSort?: string | null;
  /**
   * Whether the *Customer* column can be trusted — the verdict from #240's customer directory.
   *
   * 🔴 **This is the signal, not {@link ContractSummary.customerName}.** Do not infer redaction from
   * a null name: sparse master data produces nulls too, and the backend distinguishes the two
   * deliberately (`CustomerNameAvailability`, and the `UniformlyNamelessThreshold` behind it). A
   * `Redacted` row's name is null, exactly like a row whose customer genuinely has no name in MDM.
   *
   * ⚠ **Optional because it is absent from an older server**, and that absence is load-bearing in the
   * same way `appliedSort`'s is: `undefined` means "this server does not report a verdict", which
   * must render as *nothing said* rather than as a healthy answer. `Resolved` is a claim; `undefined`
   * is silence. Collapsing them would be correction C-7's trap — unrecognised wording read as
   * healthy — and it would fire the moment a stale SPA met a new API or the reverse.
   *
   * Make it required when no server without it is deployed.
   */
  readonly customerNames?: CustomerNameAvailability;
  /**
   * Whether CTRM returned its row cap for the status (#450, #662), or `null` when the server does
   * not say.
   *
   * CTRM truncates silently at a fixed array size, so a full array may not be every contract. The
   * server computes this on what CTRM **returned**, before any filter, so a search that narrows
   * 1,000 rows to one still searched a truncated set.
   *
   * 🔴 **`null` is unknown, never complete.** {@link HttpContractListSource} turns an absent field
   * into `null`, so a server without the field renders no notice and the screen claims nothing.
   * `false` is a claim; `null` is silence. See {@link rowCapNotice}.
   */
  readonly rowCapReached: boolean | null;
  /**
   * The cap that applied: 1,000 for open and closed, 2,000 for unapproved (#450). `null` when the
   * server does not say. The client keeps no copy of CTRM's array sizes.
   */
  readonly rowCap: number | null;
  /** CTRM warnings, surfaced rather than dropped (correction C-2). Rare on a read. */
  readonly warnings: readonly string[];
}
/**
 * The sentence the grids and the export show when CTRM returned its row cap (#662), or `null` when
 * there is nothing to say.
 *
 * Only `true` produces a sentence. `false` and `null` both return `null`, so a grid says nothing
 * about completeness either way. The export is the one place that says "complete", and only on an
 * explicit `false`.
 *
 * ⚠ "May", because a trade unit can hold exactly the cap. And no advice to narrow by customer: since
 * #687 no screen sends a customer to the server, so a Customer rule cannot bring back what CTRM
 * dropped (JFrisbie, 2026-10-07).
 */
export declare function rowCapNotice(rowCapReached: boolean | null, rowCap: number | null): string | null;
/**
 * The customer-name availability verdict, mirroring the API's `CustomerNameAvailability` enum.
 *
 * A **string** rather than a number because `ContractEndpoints` projects it with an explicit
 * `.ToString()` — the same arrangement as {@link CtrmDataOrigin}.
 *
 * | Value | What it means for the screen |
 * |---|---|
 * | `Resolved` | The column is the truth as the customer master knows it. Say nothing. |
 * | `Unavailable` | The lookup did not complete. **Transient** — a blip, a timeout, the client off. Names fall back to ids and that is the designed degradation. |
 * | `Redacted` | 🔴 The GraphQL field policy is refusing us. **Not transient, will not clear on retry**, and it needs a person. |
 *
 * 🔴 **`Unavailable` and `Redacted` must not be collapsed into one notice.** #328 criterion 5: the
 * backend separates them precisely so ordinary sparse data and a transient fault do not raise an
 * alarm that then gets ignored. A notice that fires on a blip is a notice nobody reads by the time
 * the one that needs a person arrives.
 */
export type CustomerNameAvailability = 'Resolved' | 'Unavailable' | 'Redacted';
export type CtrmDataOrigin = 'Live' | 'Simulated';
/** The status filter. Matches the `ContractListStatus` enum, which binds by name in a query string. */
export type ContractListStatus = 'Open' | 'Unapproved' | 'Closed';
/**
 * The query, mirroring `ContractListQuery`'s nine bound parameters.
 *
 * **`tradeUnit` or `customerId` is mandatory.** CTRM's `contract/list` refuses an unscoped call, so
 * the API returns **422** with the reason in `formErrors` rather than an empty page (#40 finding 2,
 * C-15). The type cannot express "one of two" usefully, so `hasScope` below is the guard, and the
 * page never issues a request without it.
 */
export interface ContractListQuery {
  readonly status: ContractListStatus;
  readonly tradeUnit?: string;
  readonly customerId?: string;
  readonly commodity?: string;
  readonly traderInitials?: string;
  /**
   * Primary or secondary approver. **`unapproved` only** — CTRM declares it on that status and
   * answers `400` naming it on the others, so sending it with `open` is a hard failure rather than a
   * silently ignored parameter (#109, and see `ContractListQuery.CtrmApproverType`).
   */
  readonly approverType?: string;
  readonly marketZone?: string;
  readonly search?: string;
  /**
   * The sort chain, `key:direction` comma-separated in priority order — `price:desc,contractDate:asc`.
   *
   * Absent asks for the server's own ordering, which `ContractListProjector` defines as newest-first.
   * Built by {@link toSortParam} from the grid's active chain, so the keys are `GridColumn.key` values
   * and the column list stays the only definition of what is sortable.
   */
  readonly sort?: string;
  readonly page: number;
  readonly pageSize: number;
}
/** `ContractListQuery.DefaultPageSize`. */
export declare const DEFAULT_PAGE_SIZE = 50;
/** `ContractListQuery.MaxPageSize`. */
export declare const MAX_PAGE_SIZE = 200;
/**
 * Whether the query carries a CTRM scope.
 *
 * The mirror of `ContractListQuery.HasCtrmScope`. Checked client-side so the grid renders its
 * "pick a trade unit" empty state instead of firing a request that is certain to 422 — but the
 * server check is the authority, and this one is a courtesy.
 */
export declare const hasScope: (query: ContractListQuery) => boolean;
/** The initial query. Status Open matches the API's own default. */
export declare const initialQuery: () => ContractListQuery;
/**
 * Where a stage of the confirmation progression has got to.
 *
 * 🔴 **Three states, not two.** `unknown` is what an unrecognised value resolves to, and it exists
 * so that a status nobody taught this client about never renders as done — the umbrella issue's
 * criterion 7, and the same rule the grid's status pills follow.
 */
export type ConfirmationStageState = 'complete' | 'outstanding' | 'unknown';
export interface ConfirmationStage {
  readonly key: 'approval' | 'customer' | 'broker';
  /** What the stage reads as on screen, given where it has got to. */
  readonly label: string;
  /** CTRM's own word, so the neutral state hides nothing. `null` when the field is blank. */
  readonly value: string | null;
  readonly state: ConfirmationStageState;
  /** Why a populated value here cannot be taken at face value. Only the broker stage has one. */
  readonly caution: string | null;
}
/**
 * 🔴 Why the broker stage cannot be read as a broker having confirmed anything (#124).
 *
 * CTRM derives it as `coalesce(status, 'Confirmed')` over a CTE whose join is pinned to the contract
 * version. Any upsert update bumps that version while `conups` never writes the confirmation row, so
 * the row is orphaned and the contract reads broker-confirmed with no broker involved — and a
 * contract with **no broker at all** reads Confirmed from creation onward, which is probably the
 * larger population.
 *
 * Exported so the screens and their tests share one string and cannot drift.
 */
export declare const BROKER_STAGE_CAUTION: string;
/**
 * The approved → customer → broker progression for a contract (BR-065, docs/02 §4.4).
 *
 * 🔴 **Derived from populated contract fields, never from a separate workflow state.** That
 * distinction is the whole design: modelling it as a status enum would invent a state machine CTRM
 * does not have, and the three fields are independent rather than sequential — a contract can carry
 * a customer confirmation with no trader approval.
 *
 * ⚠ The ORDER here is presentational. It is the order a reader expects to see work happen in, and it
 * is not a claim that a later stage implies an earlier one.
 */
export declare function confirmationProgress(header: ContractSummary): readonly ConfirmationStage[];
/**
 * The approved → customer → broker progression (F6.5, BR-065, docs/02 §4.4).
 *
 * 🔴 **One component rendered by BOTH the approval view and the record screen**, rather than the
 * same markup twice. The broker stage carries a caution that is easy to lose in a copy, and losing
 * it on the approval screen — the one where somebody commits — would be the worst place for it to go
 * missing.
 *
 * ⚠ It renders CTRM's own word beside each stage where there is one, so the neutral state hides
 * nothing: a reader sees both that we do not recognise the value and what the value was.
 */
export declare class ConfirmationProgressComponent {
  readonly header: import("@angular/core").InputSignal<ContractSummary>;
  protected readonly stages: import("@angular/core").Signal<readonly import("@cws/domain-contracts").ConfirmationStage[]>;
  /** The broker caution, shown whenever the stage is rendered at all. */
  protected readonly brokerCaution: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationProgressComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationProgressComponent, "cms-confirmation-progress", never, {
    "header": {
      "alias": "header";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** What `GET /api/v1/availability` answers (F1.4, the agreed backend contract). */
export interface Availability {
  readonly state: AvailabilityState;
  /** CTRM's own sentence where it gave one, for the banner's detail line. Never parsed. */
  readonly message: string | null;
}
export interface AvailabilitySource {
  /** The current state. Emits `Unknown` first, so nothing renders as available before it is known. */
  get(): Observable<Availability>;
}
/**
 * The availability seam.
 *
 * Injected **optionally**: a host that mounts a screen without an availability backend gets a screen
 * with no banner rather than an injection failure. ⚠ It does **not** get an open gate — a screen that
 * cannot ask treats the answer as `Unknown` and blocks writes, which is the same direction every
 * other unknown takes here.
 */
export declare const AVAILABILITY_SOURCE: InjectionToken<AvailabilitySource>;
/**
 * The real one: `GET /api/v1/availability`.
 *
 * 🔴 **A failed read resolves to `Unknown`, which is inside the hard gate.** That is the whole
 * behaviour: the natural `catchError` here would be to carry on as before, and "carry on" means
 * "keep writing" — so a gateway outage would silently remove the gate at the moment CTRM is least
 * likely to be reachable.
 *
 * ⚠ **Wired before the `state` field lands.** An older server answering without it parses to
 * `Unknown` by the same rule, so the gate is closed until the field exists rather than open. That is
 * deliberately the inconvenient direction, and it is the safe one.
 */
export declare class HttpAvailabilitySource implements AvailabilitySource {
  private readonly http;
  private readonly baseUrl;
  private readonly answer;
  get(): Observable<Availability>;
  private fetch;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpAvailabilitySource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The gate the workspace chrome and the write screens both read.
 *
 * 🔴 **Provided once by `provideCwsWorkspace` (and by a host composing a write screen), never from
 * root** (2026-09-30, E9 PR 3, D-16) — so there is still exactly one instance per mount and the
 * banner and the buttons cannot disagree. Two independent subscriptions could render "CTRM is
 * closed" beside an enabled Save, which is worse than either failure on its own.
 *
 * ⚠ It used to be root-provided so no test bed could forget it. That convenience had a price: from a
 * host's root injector this class found no `AVAILABILITY_SOURCE` and reported OPEN, with nothing
 * saying so. A bed (or a host) that forgets it now fails `NG0201`, loudly, which is the point. The
 * no-source-means-open ruling below is unchanged.
 *
 * 🔴 **With NO source, the gate is OPEN — and that is a correction, not the obvious choice.**
 *
 * The first version blocked writes when no source was provided, reasoning that a host which cannot
 * ask has not established that CTRM is accepting work. That reasoning conflates two different facts:
 *
 * | | Means | Gate |
 * |---|---|---|
 * | Source present, answers `Unknown` | *I asked and could not tell* | **closed** — this is C-7 |
 * | No source at all | *this host does not offer the capability* | open |
 *
 * C-7 is about not reading an unrecognised **answer** as healthy. It says nothing about a host that
 * never had the conversation. Treating absence as `Unknown` made the gate's own absence
 * indistinguishable from CTRM being down — it turned every test bed, and any embedded host that had
 * not wired it, into a silently read-only application. **55 tests across 10 files went red, and they
 * were right to.**
 *
 * ⚠ **The production safety property is unaffected, because it does not live here.** The shell always
 * provides a source, and {@link HttpAvailabilitySource} resolves a failed read, a missing field and an
 * unrecognised token to `Unknown` — so the gate closes on every path that actually happens in the
 * deployed application. What guards the "shell forgot to wire it" case is a shell test asserting the
 * provider exists, which fails loudly, rather than an app-wide read-only mode that fails quietly.
 */
export declare class AvailabilityGate {
  private readonly source;
  /** `Available` when nothing offers the capability; see the class remarks for why, at length. */
  private readonly current;
  /** Whether this host offers an availability backend at all. */
  readonly isOffered: boolean;
  /** The state as last reported. `Unknown` until something says otherwise. */
  readonly state: import("@angular/core").Signal<"Unknown" | "Available" | "Closed" | "NightRun" | "Unreachable">;
  /** CTRM's own sentence, where it gave one. */
  readonly message: import("@angular/core").Signal<string | null>;
  /** What the shell banner renders. */
  readonly notice: import("@angular/core").Signal<AvailabilityNotice>;
  /** Whether the hard gate is closed. Read by every screen that can write. */
  readonly writesBlocked: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AvailabilityGate, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A stand-in for the playground and the tests.
 *
 * ⚠ Configured by assigning {@link answer} rather than through the constructor: an `@Injectable`
 * cannot take an untokened constructor parameter, and adding a token for a stand-in's fixture would
 * put test scaffolding into the injection graph.
 */
export declare class SampleAvailabilitySource implements AvailabilitySource {
  answer: Availability;
  get(): Observable<Availability>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleAvailabilitySource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * One of the caller's trade units, as `GET /api/v1/me` reports it (C-15 c and d).
 *
 * ⚠ **`onboarded: false` is a trade unit the user HAS and the application cannot yet configure.**
 * It is rendered and marked, never filtered out: hiding it would make a trade unit the user knows
 * they have simply absent, which reads as a permissions fault rather than as work not yet done.
 */
export interface MeTradeUnit {
  readonly code: string;
  readonly isDefault: boolean;
  readonly onboarded: boolean;
  /**
   * What the caller may do in this trade unit, by key (`contracts:update`, `prices:update`, ...).
   *
   * ⚠ The keys are #411's provisional table and may rename pending #138.
   */
  readonly permissions: readonly string[];
}
/**
 * What `GET /api/v1/me` answers (`MeEndpoints.cs`, #411), as the frontend reads it.
 *
 * 🔴 **Read at the wire shape since E9 PR 3 (#552).** The model used to read `oid`, `upn`, `roles`
 * and `tradeUnits[].name`, none of which the server sends; it worked only because `code`,
 * `isDefault` and `onboarded` happen to match. There is no `name` on a trade unit: the picker names
 * locations from `LOCATION_SOURCE`.
 */
export interface Me {
  /** The Entra object id, `user.objectId` on the wire. The key (C-13). */
  readonly oid: string;
  /** `user.userName` on the wire; display only. `null` when the token carried none. */
  readonly upn: string | null;
  /** The Entra `Admin` app role: every permission in every trade unit (ruled 2026-09-24). */
  readonly isAdmin: boolean;
  /** The caller's default trade unit code, or `null`. */
  readonly defaultTradeUnit: string | null;
  /**
   * `'Unavailable'` when the config database could not be read: then nothing is granted and nothing
   * is onboarded, and a non-admin sees everything read-only. Anything unrecognised reads as this.
   */
  readonly status: 'Available' | 'Unavailable';
  /** Only the trade units the caller holds a role in. */
  readonly tradeUnits: readonly MeTradeUnit[];
  /**
   * **Every** onboarded trade unit, not just the caller's (#411, C-15). A CTRM write needs its trade
   * unit in this list as well as a grant. Absent on the wire reads as none.
   */
  readonly onboardedTradeUnits: readonly string[];
  /**
   * Whether the server refuses a write to a trade unit that is not onboarded (`Enforce`) or allows it
   * and only logs it (`Report`, Dev and QA today). Anything unrecognised reads as `Enforce`.
   */
  readonly onboardingGate: 'Enforce' | 'Report';
}
export interface MeSource {
  get(): Observable<RemoteData<Me>>;
}
/** The identity seam. Optional, so a host may mount a screen without one. */
export declare const ME_SOURCE: InjectionToken<MeSource>;
/**
 * The caller's default trade unit, or `null`.
 *
 * 🔴 **Exactly one `isDefault` is the contract (C-15 c), and this does NOT trust it.** It takes the
 * first, so two defaults resolve deterministically rather than by iteration order — and `null` when
 * there are none, which the picker renders as "choose one" rather than silently selecting the first
 * trade unit in the list. Picking arbitrarily would put a user on a trade unit nobody chose, and on
 * this application the trade unit decides which contracts are visible and writable.
 */
export declare function defaultTradeUnitOf(me: Me | null): MeTradeUnit | null;
/**
 * The real one: `GET /api/v1/me`.
 *
 * ⚠ **Wired before the route lands.** A failure reports as an error rather than an empty trade-unit
 * list, because "you have no trade units" is a claim a 404 cannot support — and it is the claim that
 * would send a user to ask for access they already have.
 */
export declare class HttpMeSource implements MeSource {
  private readonly http;
  private readonly baseUrl;
  private readonly answer;
  get(): Observable<RemoteData<Me>>;
  private fetch;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpMeSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A stand-in for the playground and the tests.
 *
 * ⚠ Configured by assigning {@link answer} rather than through the constructor, for the same reason
 * the availability stand-in is: an `@Injectable` cannot take an untokened constructor parameter.
 */
export declare class SampleMeSource implements MeSource {
  answer: RemoteData<Me>;
  get(): Observable<RemoteData<Me>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleMeSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The sample identity.
 *
 * ⚠ One trade unit is deliberately **not onboarded**, so the indicator has something to show. A
 * sample where everything is onboarded would let an implementation that never renders the marker
 * pass every local check.
 */
export declare const SAMPLE_ME: Me;
/**
 * **The permission keys, in ONE place on this side of the wire (#401).**
 *
 * The C# source is `Scoular.Contracts.Domain.Security.PermissionKeys`, and
 * `permission-catalog.source.spec.ts` reads that file and pins this set to it, so a key renamed on
 * either side fails a test rather than drifting. Every frontend reader of a key — the permission
 * context that asks for a grant, the simulated catalogue below — takes it from here.
 *
 * ⚠ **Provisional pending #138.** The seven may be renamed or regrouped by that ruling; when it lands
 * the change is the C# list and this one, and the spec says which.
 */
export declare const PermissionKeys: {
  readonly ContractsUpdate: "contracts:update";
  readonly BrokerConfirmationsUpdate: "broker-confirmations:update";
  readonly ContractsApprove: "contracts:approve";
  readonly PricesUpdate: "prices:update";
  readonly PricesApprove: "prices:approve";
  readonly TemplatesManage: "templates:manage";
  readonly SettingsManage: "settings:manage";
};
export type PermissionKey = (typeof PermissionKeys)[keyof typeof PermissionKeys];
/** One permission a role can be granted, as the roles screen renders it. */
export interface PermissionCatalogEntry {
  readonly key: string;
  readonly name: string;
  readonly description: string;
}
/**
 * The catalogue, and where it came from.
 *
 * `origin` is `Api` when `GET /api/v1/admin/permissions` answered and `Simulated` when the built-in
 * copy is shown instead, so the screen can say which it is rather than present a copy as the
 * server's answer.
 */
export interface PermissionCatalog {
  readonly entries: readonly PermissionCatalogEntry[];
  readonly origin: 'Api' | 'Simulated';
  /** The server says the set is provisional (#138). The built-in copy always is. */
  readonly provisional: boolean;
}
export interface PermissionCatalogSource {
  get(): Observable<RemoteData<PermissionCatalog>>;
}
/**
 * The seam. Optional for a screen: a host that provides none gets {@link SIMULATED_PERMISSION_CATALOG}.
 * `provideCwsWorkspace` binds the HTTP source.
 */
export declare const PERMISSION_CATALOG_SOURCE: InjectionToken<PermissionCatalogSource>;
/** The built-in catalogue, keyed from {@link PermissionKeys}. Descriptions follow 01 §5. */
export declare const SIMULATED_PERMISSION_CATALOG: PermissionCatalog;
/** The built-in catalogue, for the playground, the tests and a host without the route. */
export declare class SamplePermissionCatalogSource implements PermissionCatalogSource {
  get(): Observable<RemoteData<PermissionCatalog>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SamplePermissionCatalogSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The real one: `GET /api/v1/admin/permissions` (Admin only).
 *
 * ⚠ **Fails soft to the built-in copy**, marked `Simulated`: a catalogue the screen cannot fetch is
 * still the provisional seven, and showing them labelled as a copy beats an error panel on a screen
 * whose purpose is to describe them. An empty answer is treated the same way, because a catalogue
 * with no permissions is never true.
 */
export declare class HttpPermissionCatalogSource implements PermissionCatalogSource {
  private readonly http;
  private readonly baseUrl;
  private readonly answer;
  get(): Observable<RemoteData<PermissionCatalog>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpPermissionCatalogSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **The role admin API (F8.4, #429): roles, their permissions, and who holds them per trade unit.**
 *
 * Nine routes under `/api/v1/admin`, Entra `Admin` only, reads included. The permission↔role
 * mapping lives in the server's rows (`Role.permissionKeys`), never in a screen, so #138's ruling
 * on the provisional permission set changes data rather than code.
 *
 * ⚠ **Provisional pending #138.** Whatever is configured through this is a draft until that rules.
 */
/** Where the server keeps these rows. `InMemory` is lost on restart, and the screen says so. */
export type RoleStoreOrigin = 'Sql' | 'InMemory' | string;
/** One role, as `GET /admin/roles` and the role writes answer it. */
export interface Role {
  readonly id: string;
  /** A PascalCase identifier that never changes after create. */
  readonly name: string;
  /** The label. Unique, case-insensitively, like `name`. */
  readonly displayName: string;
  readonly description: string;
  /** The built-in `Admin` role. The server refuses to change or delete it (`409`). */
  readonly isSystem: boolean;
  readonly parentRoleId: string | null;
  /** The directly granted keys. REPLACED on update, never merged. */
  readonly permissionKeys: readonly string[];
  readonly createdAtUtc: string;
  readonly updatedAtUtc: string;
  /** The concurrency token. Goes back as `If-Match` on `PUT` and `DELETE`. */
  readonly version: string;
}
/** A role create. `name` is fixed from here on. */
export interface RoleCreateDraft {
  readonly name: string;
  readonly displayName: string;
  readonly description: string;
  readonly parentRoleId: string | null;
  readonly permissionKeys: readonly string[];
}
/** A role update. The whole permission set is sent: the server replaces it. */
export interface RoleUpdateDraft {
  readonly displayName: string;
  readonly description: string;
  readonly parentRoleId: string | null;
  readonly permissionKeys: readonly string[];
}
/** One user holding one role in one trade unit. */
export interface RoleAssignment {
  /** The Entra object id (a GUID), never the UPN (C-13). */
  readonly userObjectId: string;
  /** For display only. */
  readonly userUpn: string;
  readonly roleId: string;
  readonly roleName: string;
  readonly roleDisplayName: string;
  readonly tradeUnit: string;
  /** Exactly one per user. Moves when another row is made default or the default is revoked. */
  readonly isDefault: boolean;
  readonly expiresAtUtc: string | null;
  readonly isExpired: boolean;
  readonly assignedByUpn: string;
  readonly assignedAtUtc: string;
}
/** An assignment create. */
export interface RoleAssignmentDraft {
  readonly userObjectId: string;
  readonly userUpn: string;
  readonly roleId: string;
  readonly tradeUnit: string;
  readonly expiresAtUtc: string | null;
  readonly isDefault: boolean;
}
/** A list read: the rows, and where the server keeps them. */
export interface RoleAdminList<T> {
  readonly storeOrigin: RoleStoreOrigin;
  readonly rows: readonly T[];
}
/** Which assignments to read. Either filter may be omitted. */
export interface RoleAssignmentFilter {
  readonly tradeUnit?: string;
  readonly userObjectId?: string;
}
/**
 * How a call ended. The server's `detail` is shown as-is (`409`, `503`, `404`), and a `400`'s
 * `errors.<field>` arrive keyed as the server keys them.
 *
 * - `refused` is a `409`: a stale `If-Match`, the built-in role, or a role somebody holds or
 *   inherits from. Its sentence says which.
 * - `unavailable` is a route the server does not offer, or no network.
 */
export type RoleAdminCall<T> = {
  readonly kind: 'done';
  readonly value: T;
} | {
  readonly kind: 'unavailable';
  readonly reason: string;
} | {
  readonly kind: 'refused';
  readonly message: string;
  readonly correlationId?: string;
} | {
  readonly kind: 'failed';
  readonly message: string;
  readonly correlationId?: string;
  readonly fieldErrors?: Readonly<Record<string, readonly string[]>>;
};
/**
 * Reads and writes roles and assignments (#429).
 *
 * Every assignment write answers **all of that user's rows**, so a screen re-renders from them
 * rather than predicting where the default went.
 */
export interface RoleAdminSource {
  listRoles(): Observable<RoleAdminCall<RoleAdminList<Role>>>;
  createRole(draft: RoleCreateDraft): Observable<RoleAdminCall<Role>>;
  /** Sends `role.version` as `If-Match`. */
  updateRole(role: Role, draft: RoleUpdateDraft): Observable<RoleAdminCall<Role>>;
  /** Sends `role.version` as `If-Match`. */
  deleteRole(role: Role): Observable<RoleAdminCall<void>>;
  listAssignments(filter: RoleAssignmentFilter): Observable<RoleAdminCall<RoleAdminList<RoleAssignment>>>;
  assign(draft: RoleAssignmentDraft): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  setDefault(userObjectId: string, tradeUnit: string): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  revoke(assignment: RoleAssignment): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
}
/**
 * The seam. Optional for a screen: a host that provides none gets a roles screen that says role
 * administration is not offered. `provideCwsWorkspace` binds the HTTP source.
 */
export declare const ROLE_ADMIN_SOURCE: InjectionToken<RoleAdminSource>;
/**
 * Whether a value is an Entra object id: a GUID, hyphenated, any case.
 *
 * 🔴 **A UPN is refused here, before any request** (C-13). Keying an assignment on a UPN orphans
 * it the day the UPN changes, and the server answers `400` anyway.
 */
export declare function isEntraObjectId(value: string): boolean;
/** The sentence for an object id that is not a GUID, from the form and the HTTP source alike. */
export declare const OBJECT_ID_REFUSAL: string;
/**
 * The real source: the nine `/api/v1/admin` routes in #429.
 *
 * ⚠ Kept in a file with no injection token, so the workspace can load it lazily (#678).
 *
 * 🔴 **A non-GUID object id never leaves the browser.** `assign`, `setDefault` and `revoke` answer a
 * `failed` with `errors.userObjectId` instead of sending, because a UPN where the object id belongs
 * would key the row on something that changes (C-13).
 */
export declare class HttpRoleAdminSource implements RoleAdminSource {
  private readonly http;
  private readonly baseUrl;
  private get rolesUrl();
  private get userRolesUrl();
  listRoles(): Observable<RoleAdminCall<RoleAdminList<Role>>>;
  createRole(draft: RoleCreateDraft): Observable<RoleAdminCall<Role>>;
  updateRole(role: Role, draft: RoleUpdateDraft): Observable<RoleAdminCall<Role>>;
  deleteRole(role: Role): Observable<RoleAdminCall<void>>;
  listAssignments(filter: RoleAssignmentFilter): Observable<RoleAdminCall<RoleAdminList<RoleAssignment>>>;
  assign(draft: RoleAssignmentDraft): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  setDefault(userObjectId: string, tradeUnit: string): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  revoke(assignment: RoleAssignment): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpRoleAdminSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * An in-memory stand-in for the role admin API (#429), for the playground and the tests.
 *
 * 🔴 Sample data. The seeded `Admin` row matches what the server seeds; the other role is a
 * playground placeholder, **not a proposed role** (01 §5 leaves the catalogue to a workshop).
 *
 * It keeps the server's rules so a screen built over it behaves as it will live:
 * - a stale `version` on `If-Match` is refused (`409`);
 * - the built-in `Admin` role cannot be changed or deleted;
 * - a role somebody holds, or another role inherits from, cannot be deleted;
 * - a user's first assignment becomes their default, `isDefault` on a later one moves it, and
 *   revoking the default promotes another role in the same trade unit first, otherwise the
 *   earliest-assigned remaining row (ruled 2026-09-24);
 * - every assignment write answers all of that user's rows.
 */
export declare class SampleRoleAdminSource implements RoleAdminSource {
  private clock;
  private roles;
  private assignments;
  constructor();
  listRoles(): Observable<RoleAdminCall<RoleAdminList<Role>>>;
  createRole(draft: RoleCreateDraft): Observable<RoleAdminCall<Role>>;
  updateRole(role: Role, draft: RoleUpdateDraft): Observable<RoleAdminCall<Role>>;
  deleteRole(role: Role): Observable<RoleAdminCall<void>>;
  listAssignments(filter: RoleAssignmentFilter): Observable<RoleAdminCall<RoleAdminList<RoleAssignment>>>;
  assign(draft: RoleAssignmentDraft): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  setDefault(userObjectId: string, tradeUnit: string): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  revoke(assignment: RoleAssignment): Observable<RoleAdminCall<readonly RoleAssignment[]>>;
  private rowsOf;
  private tick;
  private role;
  private assignment;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleRoleAdminSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Talks to `POST/PUT /api/v1/contracts`.
 *
 * Provided by `provideCwsWorkspace` (and by any host composing this screen); never root — see
 * `no-root-provision.spec.ts`.
 */
export declare class HttpContractWriteSource implements ContractWriteSource {
  private readonly http;
  private readonly baseUrl;
  /**
   * The contract collection, built once rather than at each call site.
   *
   * ⚠ `CONTRACTS_API_URL` is the API ROOT — `…/api/v1` — despite the name; every consumer adds its
   * own resource segment (`HttpContractDetailSource` builds `${baseUrl}/contracts/${number}`). All
   * three methods here originally omitted `/contracts` and so addressed `/api/v1/{number}/fields`,
   * `POST /api/v1` and `PUT /api/v1/{number}`. Every one 404s, and the prefill's `catchError`
   * degrades that to an empty form — so an edit screen loaded blank and a save failed with no
   * request the server would ever log under the contracts route.
   */
  private get contractsUrl();
  fields(contractNumber: string): Observable<ContractWriteFields>;
  create(fields: Readonly<Record<string, unknown>>, collections?: ContractWriteCollections, options?: ContractWriteOptions): Observable<ContractWriteResult>;
  update(contractNumber: string, fields: Readonly<Record<string, unknown>>, collections?: ContractWriteCollections, options?: ContractUpdateOptions): Observable<ContractWriteResult>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractWriteSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * An unsaved record form, kept so a crash or an accidental reload does not cost the typing — F3.2f.
 *
 * ### 🔴 Session storage, not local storage, and the reason is the same one `TradeUnitStore` gives
 *
 * A draft belongs to the tab it was typed in. `localStorage` is shared across every tab on the
 * origin, so two contracts open side by side would overwrite each other's drafts — and a draft
 * surviving a browser restart is a contract someone abandoned weeks ago offering itself back.
 *
 * ### ⚠ It stores the DIRTY values only
 *
 * Not the whole form. A restore patches these back and marks them dirty, which is true — they were
 * user edits — and it is what keeps the restored form's save payload identical to the one the user
 * would have sent. Storing every control would make a restored *edit* send CTRM its own values back
 * as if they had been typed, which under a full-replace upsert is a rewrite wearing an edit's
 * clothes.
 */
export interface RecordDraft {
  /** Component name to value, exactly as `dirtyValues` produces it. */
  readonly values: Readonly<Record<string, unknown>>;
  /** When it was captured, for the restore prompt. ISO 8601. */
  readonly savedAt: string;
  /**
   * A create's idempotency key (#557), so a reload that restores the draft retries the SAME create
   * rather than starting a second one. Absent on an edit, and on any draft written before #557.
   */
  readonly idempotencyKey?: string;
}
/**
 * What a draft is keyed on.
 *
 * 🔴 **All three parts are load-bearing, and the contract number is the one that bites.** A draft
 * restored onto a different contract silently writes one contract's values over another's — with a
 * full-replace upsert behind it, that is the worst outcome this screen can produce. The trade unit is
 * here for the same reason one step out: configuration is resolved per trade unit, so the same
 * contract number under a different unit is a different set of fields.
 *
 * ⚠ **Create mode has no contract number**, so its key is the mode and the trade unit — which is
 * right: there is one create-in-progress per unit, and a second one legitimately replaces it.
 */
export interface RecordDraftKey {
  readonly mode: string;
  readonly contractNumber: string;
  readonly tradeUnit: string;
}
export interface RecordDraftStore {
  read(key: RecordDraftKey): RecordDraft | null;
  write(key: RecordDraftKey, values: Readonly<Record<string, unknown>>, idempotencyKey?: string): void;
  clear(key: RecordDraftKey): void;
}
export declare const RECORD_DRAFT_STORE: InjectionToken<RecordDraftStore>;
/**
 * The storage a draft store writes to.
 *
 * Injected rather than reached for, so a spec can supply a fake without touching a global — and so
 * the store can be exercised with a storage that throws, which is a real state (private browsing,
 * and a full quota).
 */
export declare const DRAFT_STORAGE: InjectionToken<Storage>;
/** The clock, so the restore prompt's time is assertable. */
export declare const DRAFT_CLOCK: InjectionToken<() => Date>;
/** Composes the storage key. Exported for the spec, which asserts two contracts cannot collide. */
export declare function draftStorageKey(key: RecordDraftKey): string;
export declare class SessionRecordDraftStore implements RecordDraftStore {
  private readonly storage;
  private readonly now;
  read(key: RecordDraftKey): RecordDraft | null;
  write(key: RecordDraftKey, values: Readonly<Record<string, unknown>>, idempotencyKey?: string): void;
  clear(key: RecordDraftKey): void;
  private readRaw;
}
/**
 * What CTRM handed back for a newly issued contract number.
 *
 * 🔴 **`numberComponent` is the value the `contract_number` field takes — never `contractNumber`.**
 * The API returns all three forms, named, precisely so a client cannot pick the wrong one: CTRM's key
 * is positional (type + commodity + a 7-character number + optional suffix), and `contract_number` is
 * declared `maxLength: 7` because it holds only the middle component. Binding the composed key to that
 * control is the defect QA found as F-04 — it rendered `SCW2276` for `SCW227618`, and under a
 * positional scheme a truncated component names a **different contract**.
 */
export interface IssuedContractNumber {
  /** The 7-character number component. **This is what `contract_number` takes.** */
  readonly numberComponent: string;
  /**
   * The composed key as a user reads it, for display only.
   *
   * `null` when the number was issued WITHOUT prefixes (#631, backend #632): the create and copy
   * screens issue on entry, before any prefix is chosen, so there is nothing to compose yet. Present
   * and `null` rather than omitted, so absence can never be read as a value.
   */
  readonly contractNumber: string | null;
  /** The positional key CTRM addresses the contract by, for display only; `null` as above. */
  readonly ctrmKey: string | null;
  readonly dataOrigin: string;
  readonly warnings: readonly string[];
}
/** Whether a contract number is free, for validating one the user typed themselves. */
export interface ContractNumberAvailability {
  readonly contractNumber: string;
  readonly isAvailable: boolean;
  /** CTRM's own word for what it collided with, when it is not available. */
  readonly conflict: string;
  readonly dataOrigin: string;
  readonly warnings: readonly string[];
}
/** Both prefixes, for a caller that already has them; a suffix only ever with both. */
export interface PrefixedIssueContractNumberRequest {
  readonly prefixType: string;
  readonly prefixCommodity: string;
  readonly suffix?: string;
}
/**
 * **Both prefixes or neither** (#631; the API since #632). Neither prefixes is `{}`, the create and copy
 * case: CTRM's `getNextContract` takes no input and checks uniqueness on the 7-character number alone,
 * so the prefixes never affected which number is issued. One prefix alone, or a suffix without both,
 * is refused with a `400`, and the type rules both out. Never defaulted: on this estate an omitted
 * field means "choose for me".
 */
export type IssueContractNumberRequest = Readonly<Record<string, never>> | PrefixedIssueContractNumberRequest;
/**
 * Issues and checks contract numbers.
 *
 * 🔴 **Issuing SPENDS a finite resource that cannot be handed back.** `getNextContract` increments
 * `GNP291.ctlctrl` before anything can fail and CTRM's counter never revisits a value, so every call
 * consumes a number permanently — there is no release, and a reservation would not return it to the
 * sequence either. The API models issuance as a **POST** for exactly this reason: a GET is replayable
 * by a browser prefetch, a proxy, a double-click or a client retry, and every replay is a spent number.
 *
 * ⚠ **So a caller must issue at most once per journey.** Nothing in this seam enforces that, because
 * the seam cannot know what a journey is; see the record page, which holds the issued number outside
 * the form so a rebuild re-applies it rather than re-requesting it.
 */
export interface ContractNumberSource {
  /** Issues the next number. ⚠ Spends one, permanently. */
  issue(request: IssueContractNumberRequest): Observable<IssuedContractNumber>;
  /** Reports whether a number is free. A pure read — safe to repeat. */
  check(contractNumber: string): Observable<ContractNumberAvailability>;
}
/** The seam, so a screen can be tested without HTTP and an embedded host can supply its own. */
export declare const CONTRACT_NUMBER_SOURCE: InjectionToken<ContractNumberSource>;
/**
 * Talks to `POST /api/v1/contract-numbers` and `GET /api/v1/contract-numbers/{key}`.
 *
 * ⚠ **Errors are deliberately NOT mapped here, and the caller must tell three cases apart.** A thin
 * seam is right because the three failures need three different sentences on screen, and only the
 * screen knows which field to attach them to:
 *
 * | Status | Means | What the user can do |
 * |---|---|---|
 * | **403** | The caller lacks the write policy — issuance is gated on `CwsContractWriter`, not the read gate, so a `User`-role account cannot spend a number | Nothing; type a number, or ask for the role |
 * | **503** | The environment writes contracts Live but simulates issuance, so the API refuses to hand back a fabricated number | Type a number; the configuration needs fixing |
 * | anything else | A CTRM fault | Retry, or type a number |
 *
 * Collapsing those into one "could not get a number" would tell a user with no entitlement to try
 * again forever.
 *
 * Provided by `provideCwsWorkspace` (and by any host composing this screen); never root — see
 * `no-root-provision.spec.ts`.
 */
export declare class HttpContractNumberSource implements ContractNumberSource {
  private readonly http;
  private readonly baseUrl;
  /**
   * Its own collection rather than a segment under `/contracts`.
   *
   * ⚠ `CONTRACTS_API_URL` is the API **root** (`…/api/v1`) despite the name, and every consumer adds
   * its own resource segment. Omitting one is not a compile error and not a visible one either — it
   * addresses `/api/v1/…`, 404s, and degrades to an empty field.
   */
  private get numbersUrl();
  issue(request: IssueContractNumberRequest): Observable<IssuedContractNumber>;
  check(contractNumber: string): Observable<ContractNumberAvailability>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractNumberSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Coerces one CTRM value into what its control expects.
 *
 * Exported for its own tests: the failure this guards is silent — a wrong type renders as a blank or
 * an unformatted control, never as an error — so it is worth asserting directly rather than only
 * through a screen.
 *
 * @param value The raw value, as CTRM sent it.
 * @param controlPattern The control that will receive it.
 * @returns A value the control's `writeValue` accepts, or `null` where CTRM holds nothing.
 */
export declare function coerceForControl(value: unknown, controlPattern: ControlPattern): unknown;
/**
 * Turns one control value back into what CTRM stores: the inverse of {@link coerceForControl}.
 *
 * 🔴 **#944: a `ToggleFlag` holds a boolean, and CTRM's flag is `Char(1)`.** Sent as it stands, the
 * value reaches IWS as the text `false` and the whole write is refused: on a create every toggle is
 * sent, so every create from the screen failed. So a flag goes out as `"Y"` or `"N"`. A string already
 * in the control (a template seeds CTRM's raw `"Y"`) is read with the same rule the read side uses, so
 * the two directions cannot disagree. Every other control's value passes through unchanged.
 *
 * @param value The control's current value.
 * @param controlPattern The control it came from.
 * @returns The value to put in the save body.
 */
export declare function toCtrmValue(value: unknown, controlPattern: ControlPattern): unknown;
/**
 * Every control value a contract's CTRM values can fill, keyed by **component name**.
 *
 * Fields CTRM holds nothing for are left out rather than set to `null`, so the form's own initial
 * state stands and a control is not marked as carrying an explicit empty. That distinction matters
 * under a full-replace upsert: seeding an explicit blank and seeding nothing look identical on screen
 * and are different intentions.
 *
 * @param values CTRM's values, keyed by CTRM field name — the shape `/contracts/{n}/fields` returns.
 * @returns Control values keyed by component name, ready for `ContractFormComponent.initialValues`.
 */
export declare function seedFromCtrmValues(values: Readonly<Record<string, unknown>>): Readonly<Record<string, unknown>>;
/**
 * The `GET /api/v1/contracts/{number}` response, mirrored field for field.
 *
 * **Sourced, not invented.** Every member below is copied from
 * `src/Scoular.Contracts.Application/Contracts/ContractDetail.cs` and from the projection in
 * `ContractEndpoints.GetContractAsync`. Names are camelCase because the API configures no
 * `JsonSerializerOptions`, so System.Text.Json's default applies.
 *
 * This matters because a wrong field name fails *silently* — it deserialises to `undefined` and renders
 * as an empty cell, with no error anywhere. That is Known Issue 18 on the backend and it behaves
 * identically here. **Verify against the C# record, never against a doc.**
 *
 * `ContractSummary` is imported from this same library rather than re-declared here. It used to come
 * from `@cws/features-home`, which was a layering smell taken deliberately: two hand-maintained
 * mirrors of one C# record is a *drift* risk, and drift is the failure mode this codebase has
 * actually been bitten by (Known Issues 18, 23, 34 are all "two things that looked like the same
 * record and were not"). The structural fix the paragraph asked for has since landed - the contract
 * wire types live in `@cws/domain-contracts`, and so does this model.
 */
/** CTRM's computed quantity breakdown (docs/04 §6). Mirrors `ContractQuantities`. */
export interface ContractQuantities {
  readonly unpriced: number | null;
  readonly priced: number | null;
  readonly unshipped: number | null;
  readonly applied: number | null;
  readonly settled: number | null;
  readonly open: number | null;
}
/**
 * One remark line (BR-030).
 *
 * `order` is **CMS's number, not CTRM's** — `RmkDS` has no sequence subfield, so it is array position
 * and nothing else. Do not present it as a CTRM identifier.
 */
export interface ContractRemark {
  readonly order: number;
  readonly type: string | null;
  readonly text: string | null;
}
/** One ship period (BR-020…BR-023). `order` is CMS's number, as above. */
export interface ContractShipPeriod {
  readonly order: number;
  readonly begin: string | null;
  readonly end: string | null;
  readonly latePickup: string | null;
  readonly earlyDelivery: string | null;
  readonly quantity: number | null;
}
/**
 * One price sequence as read from the contract aggregate.
 *
 * ⚠ **Not the same record as the pricing API's price** (Known Issue 34). This one has 10 members and
 * calls things `flatPrice`/`quantity`; the pricing API's `dsPrc` has 36 and calls them
 * `price`/`pricedQuantity`. **Do not merge them or reuse a component across both** without checking
 * which record it is holding.
 *
 * `sequence` is CTRM's own `price_sequence` — the one collection number here that is real.
 */
export interface ContractPrice {
  readonly sequence: number | null;
  readonly quantity: number | null;
  readonly flatPrice: number | null;
  readonly basisPrice: number | null;
  readonly hedgePrice: number | null;
  readonly freightAdjustment: number | null;
  readonly marketMonth: string | null;
  readonly marketMonthDescription: string | null;
  readonly priceDate: string | null;
  readonly remark: string | null;
}
/** One note. `order` is CMS's number, as above. Text runs to 32 000 characters. */
export interface ContractNote {
  readonly order: number;
  readonly prefix: string | null;
  readonly code: string | null;
  readonly text: string | null;
}
/**
 * The contract's LMS flag (#973; the server half is #972, merged in #985). Mirrors `ContractLmsFlag`.
 *
 * In CTRM the flag is contract note `LMSFLAG`, so it is NOT a `base_data` field and never appears on
 * `/fields`. Written with `lmsFlag: true | false` on a save, never through `notes`.
 *
 * | `state` | Means | `editable` |
 * |---|---|---|
 * | `none` | no flag | `true` |
 * | `automatic` | CTRM set it for an LMS special type (`ROOT`) | `false` |
 * | `manual` | set by a person or the bot | `true` |
 * | `unknown` | CTRM could not read the contract's notes | `false` |
 */
export interface ContractLmsFlag {
  readonly state: 'none' | 'automatic' | 'manual' | 'unknown';
  readonly editable: boolean;
}
/** The contract aggregate. Mirrors `ContractDetail`. */
export interface ContractDetail {
  /** The header fields, flattened from CTRM's `base_data`. */
  readonly header: ContractSummary;
  readonly version: string | null;
  readonly currency: string | null;
  readonly descriptiveQuantity: string | null;
  readonly basisLocation: string | null;
  /**
   * CTRM's description of the shipment periods **as a whole**.
   *
   * A `base_data` field, *not* a column of the ship-period collection — the source read settled this
   * (Known Issue 18). An individual ship period has no description of its own, so do not render this
   * inside the periods table.
   */
  readonly shipPeriodDescription: string | null;
  readonly incoTermsDescription: string | null;
  readonly namedPlace: string | null;
  readonly originCode: string | null;
  readonly destinationCode: string | null;
  readonly brokerId: string | null;
  readonly brokerContract: string | null;
  readonly customerMerchant: string | null;
  readonly freightAdjustment: number | null;
  readonly hedgePrice: number | null;
  readonly quantities: ContractQuantities;
  readonly remarks: readonly ContractRemark[];
  readonly shipPeriods: readonly ContractShipPeriod[];
  readonly prices: readonly ContractPrice[];
  readonly notes: readonly ContractNote[];
  /**
   * The LMS flag (#973). Optional because a host's own source, or an API older than #985, does not
   * send it; the record screen then says the flag cannot be shown, as it does for `unknown`.
   */
  readonly lmsFlag?: ContractLmsFlag;
  /**
   * ⚠ **A NUMBER, not `'Live' | 'Simulated'` — and use {@link ContractDetailResponse.dataOrigin}
   * instead.**
   *
   * `ContractDetail.Origin` is a C# `enum` (`CtrmDataOrigin`, `Live = 0`) and the API registers no
   * `JsonStringEnumConverter`, so System.Text.Json writes it as its numeric value. The *envelope's*
   * `dataOrigin` is the same information explicitly stringified by the endpoint
   * (`payload.Origin.ToString()`), which is why that is the one to read.
   *
   * Typed honestly rather than as the string union it looks like it should be. Declaring it a string
   * would compile, never fail, and quietly make `origin === 'Simulated'` permanently false — which is
   * the "simulated data shown as production" failure the banner exists to prevent. Derived from the
   * serializer configuration rather than measured; a backend test asserting this route's JSON shape
   * would pin it.
   */
  readonly origin: number;
}
/**
 * The response envelope.
 *
 * `unmodelledCollections` is the interesting member and it must be **shown, not swallowed**. The API
 * names the child collections CTRM returns that CMS does not read yet, precisely so a reader can tell
 * *"this contract has no quality factors"* from *"CMS does not read quality factors"*. A screen that
 * silently omitted them would answer the first when the truth is the second.
 */
export interface ContractDetailResponse {
  readonly contract: ContractDetail;
  readonly dataOrigin: CtrmDataOrigin;
  readonly unmodelledCollections: readonly string[];
  /**
   * The child collections CTRM failed to read (#788, merged in #819), by the aggregate's names
   * (`remarks`, `notes`, `ship_periods`, …). A name here means that collection's emptiness proves
   * nothing, and a full replace from it would delete what CTRM still holds. Always present on an API
   * since #819, `[]` on a clean read; absent on an older one, which reads as "nothing known unread".
   */
  readonly incompleteCollections?: readonly string[];
  readonly warnings: readonly string[];
}
/** One of CTRM's remark types, as the record screen labels it. */
export interface RemarkType {
  readonly code: string;
  readonly label: string;
}
/**
 * **CTRM's 11 remark types, in the order the Power App shows them** (C-19, #789).
 *
 * BR-030 named 12; CTRM holds 11. `remark_type` is `Char(1)` in both `RmkDS` copybooks, so there is
 * no "Remarks 10" to build. Read: `contapi.sqlrpgle:913-917`; write: `conups.sqlrpgle:1835-1863`.
 */
export declare const REMARK_TYPES: readonly RemarkType[];
/**
 * The key one remark type goes by, as `remarks.<code>` (#1006): the record screen's id for its input
 * and validation summary entry, and the key #1022's save enforcement is proposed to refuse a missing
 * required remark on (`422`), so a server refusal lands on the same entry.
 */
export declare function remarkKey(code: string): string;
/** A remark note's length, from `constraints.json` (`remarks.remark_note`). */
export declare const REMARK_NOTE_MAX_LENGTH = 72;
/** The remarks as the editor holds them: one note per type code, `''` for none. */
export type RemarkValues = Readonly<Record<string, string>>;
/**
 * The editor's starting values from what CTRM holds: each type's note, `''` for a type with none.
 * A type CTRM returns that is not one of the 11 is ignored, and a repeated type keeps its first note.
 */
export declare function remarkValuesOf(remarks: readonly ContractRemark[]): RemarkValues;
/** Whether any note differs from what CTRM holds. Compared exactly, as a change to spaces is one. */
export declare function remarksChanged(original: RemarkValues, current: RemarkValues): boolean;
/**
 * The whole `remarks` collection to send: every type with a note, in the 11's order, **packed**, so no
 * blank row comes before a real one (`conups` stops at the first blank `remark_type`). A type whose
 * note is blank is left out, which is how a remark is removed under a full replace.
 */
export declare function remarksPayload(values: RemarkValues): ContractWriteRemark[];
/**
 * What a copy of a contract may carry, and what it must never carry.
 *
 * **BR-041 is the authority**: *"Copy and Save-As-Template apply per-field exclusion flags
 * server-side (authoritative implementation was the `DuplicateContractRecord` flow, not the
 * form)."* So a copy is agreed scope with an agreed mechanism — the `excludeFromCopy` flag that
 * `FieldBehaviour` has carried since the Power App's `sc_locationcontractconfig` set was mapped onto
 * it — and this module's job is to honour that flag rather than to invent an exclusion policy of its
 * own.
 *
 * 🔴 **Two layers of exclusion, and only one of them is configurable. That distinction is the whole
 * safety argument for this feature.**
 *
 * 1. {@link CONTRACT_COPY_IDENTITY_FIELDS} — **structural, and deliberately unreachable from
 *    configuration.** These identify the individual record. Carrying one turns a create into an
 *    overwrite of the contract being copied; see the constant's own remarks, because that failure is
 *    silent and unrecoverable.
 * 2. `behaviour.excludeFromCopy` — **policy, per field, per trade unit**, resolved server-side and
 *    transmitted in the resolved configuration.
 *
 * ⚠ **Layer 2 is inert today and that is worth knowing before trusting it.** `FormConfigSeed` sets
 * `ExcludeFromCopy: false` for every field, and no stored configuration row overrides it, so nothing
 * is currently excluded by policy. Layer 1 is therefore the only exclusion actually operating — which
 * is exactly why the identity fields are not expressed as configuration. A field that must never be
 * copied cannot depend on a flag nobody has set.
 *
 * ⚠ **And a caution inherited from 2026-09-09: a stored configuration row freezes what it was written
 * with.** When someone does configure `excludeFromCopy`, it will freeze into rows the same way field
 * *order* did, and a later seed change will not propagate. That is
 * [#221](https://scoular.ghe.com/IT/contract-management-system/issues/221)'s re-sync-from-layout ask,
 * not this module's problem — but it is why layer 1 does not live there.
 */
/**
 * The fields a copy must never carry, whatever any configuration says.
 *
 * 🔴 **`contract_number` is the dangerous one, and the danger is total.** `upsertContract` creates
 * when the key does not match and **updates when it does** — docs/04e calls that its single most
 * important line. All four key components are `readWrite` in `constraints.json`, so a copy that
 * seeded the source contract's number would send it: the create would match the source's key,
 * CTRM would **full-replace the contract being copied**, and the response would report success.
 * Worse, the number-issuance guard declines to issue when `ContractNumber` already holds a value, so
 * no fresh number would ever be requested and nothing on the screen would look wrong.
 *
 * The only signal would be `ContractWriteAction.Updated` coming back from a create — which the record
 * screen does surface, and which is a detective control catching a mistake this constant makes
 * impossible in the first place.
 *
 * **`contract_suffix` is excluded for a weaker but sufficient reason.** It is character 10 of the key
 * and usually empty. A new number makes the composed key unique regardless, so carrying it would not
 * collide — but a suffix distinguishes one record from its siblings rather than classifying it, so it
 * is record identity and belongs here.
 *
 * ⚠ **The two prefixes are deliberately NOT excluded.** `contract_prefix_type` (sale or purchase) and
 * `contract_prefix_commodity` (the commodity's CAK group) *classify* the contract, so a copy of a
 * corn sale should be a corn sale. They are also the two drivers number issuance waits on, so
 * excluding them would leave the copy unable to obtain a number at all.
 */
export declare const CONTRACT_COPY_IDENTITY_FIELDS: readonly string[];
/**
 * The component names the resolved configuration excludes from a copy (BR-041, layer 2).
 *
 * Reads the flag off the configuration the server sent rather than deciding anything locally, which
 * is what keeps this consistent with BR-041's "server-side" ruling: the *decision* is made where the
 * configuration is resolved, per trade unit, and this only applies it.
 *
 * ⚠ Hidden sections are walked too. A field's `excludeFromCopy` is about copying, not about
 * rendering, and skipping invisible sections would mean a field hidden for a trade unit quietly
 * became copyable there.
 */
export declare function copyExclusions(config: ResolvedFormConfig | null): ReadonlySet<string>;
/**
 * The values a new contract should start with when copied from an existing one.
 *
 * Keyed by **component name** and coerced for the controls, so the result drops straight into the
 * record screen's `defaultValues` — which marks what it applies *dirty*, and that is required rather
 * than incidental: the save path sends only dirty controls, on a create as much as an edit, so a
 * pristine copied value would be silently omitted from the payload.
 *
 * 🔴 **Iterates `CONTRACT_WRITABLE_FIELDS`, never `CONTRACT_LAYOUT_FIELDS`.** The layout carries
 * read-only rows so every mode shows the same fields in the same places, and `upsertContract`
 * *refuses* those rather than ignoring them. The save path already filters to the writable set, so a
 * read-only value here could not reach CTRM — but it would still be marked dirty on a control the
 * user cannot edit, and seeding a derived `*_description` from the source would show a value that
 * CTRM will recompute from its code. Filtering here keeps the screen honest as well as the payload.
 *
 * @param sourceValues The source contract's writable values, keyed by CTRM field name — the body of
 *   `GET /contracts/{number}/fields`, exactly as the edit screen's prefill consumes it.
 * @param excluded Component names to leave out, from {@link copyExclusions}.
 */
export declare function copyableValues(sourceValues: Readonly<Record<string, unknown>>, excluded?: ReadonlySet<string>): Readonly<Record<string, unknown>>;
/**
 * What became of one CTRM collection on a copy (#960).
 *
 * - `carried`: on the new contract, as new rows.
 * - `empty`: the source holds none.
 * - `excluded`: the trade unit's resolved configuration sets `excludeFromCopy` on it (#959).
 * - `pricing`: `prices`, which only copy-with-pricing's own step carries (#459), never the create.
 * - `notYet`: `notes`, the contract text, carried once #907's screen exists.
 * - `unread`: CWS cannot read it from the source, or the read of it failed.
 * - `neverCopied`: CTRM refuses it on a contract write (`writable: false`), so no copy can carry it.
 */
export type CollectionCopyStatus = 'carried' | 'empty' | 'excluded' | 'pricing' | 'notYet' | 'unread' | 'neverCopied';
export interface CollectionCopyOutcome {
  /** The CTRM collection name, from `constraints.json`. */
  readonly name: string;
  readonly status: CollectionCopyStatus;
  /** The rows carried: fewer than {@link total} only when the source holds more than `maxItems`. */
  readonly rows?: number;
  /** The rows the source holds, where CWS could read them. */
  readonly total?: number;
  /** The collection's cap, from `constraints.json`. */
  readonly maxItems?: number;
}
/** What a copy carries in the way of collections, and why it leaves out the rest. */
export interface CollectionCopyPlan {
  /**
   * False when CTRM's collection list (`constraints.json`, served as `GET /meta/constraints`) could
   * not be read. Then nothing is carried: a collection whose cap and writability are unknown is never
   * sent, because "unknown" is not "unconstrained" (Known Issue 16).
   */
  readonly catalogKnown: boolean;
  /** One per collection in `constraints.json`, in its order. */
  readonly outcomes: readonly CollectionCopyOutcome[];
  /** The source's ship periods to carry, capped at `maxItems`; empty when none are carried. */
  readonly shipPeriods: readonly ContractShipPeriod[];
  /** The source's remarks to carry, capped at `maxItems`; empty when none are carried. */
  readonly remarks: readonly ContractRemark[];
  /** True when the trade unit excludes `prices`, so copy-with-pricing must post none. */
  readonly pricesExcluded: boolean;
}
/** What {@link planCollectionCopy} works from. */
export interface CollectionCopyInput {
  /** The source contract's aggregate (`GET /contracts/{n}`), or `null` when it could not be read. */
  readonly source: ContractDetailResponse | null;
  /** `constraints.json`'s collections, by CTRM name, or `null`/`undefined` when unread. */
  readonly catalog: Readonly<Record<string, CollectionConstraint>> | null | undefined;
  /** The resolved configuration's per-collection flags (#959). Absent from a server without #991. */
  readonly behaviour?: Readonly<Record<string, CollectionBehaviour>>;
}
/**
 * What a copy carries of the source contract's collections (#960, ruled 2026-10-20).
 *
 * 🔴 **The ruling: a copy carries everything on the source unless the trade unit excludes it.** So
 * every collection is walked from `constraints.json` (ADR-7, never a typed list), and each is carried
 * unless one of these holds, checked in this order:
 *
 * 1. CTRM refuses it on a write (`writable: false`). `prices` is the exception: copy-with-pricing
 *    carries it (#459), so it is `pricing`, or `excluded` when the trade unit excludes it.
 * 2. The resolved configuration sets `excludeFromCopy` on it (#959). Absent flags exclude nothing.
 * 3. It is `notes`, which waits for #907.
 * 4. CWS cannot read it: the aggregate does not model it, the source read failed, or the source
 *    listed it in `incompleteCollections` (#788), where an empty list proves nothing.
 *
 * A carried collection keeps at most `maxItems` rows, the first ones, and its outcome says how many
 * of how many. A source over the cap is not expected (CTRM enforces the same cap), so this is a guard
 * on the create rather than a case the screen is built around.
 */
export declare function planCollectionCopy(input: CollectionCopyInput): CollectionCopyPlan;
/** A collection's name for reading: CTRM's own, with spaces for underscores, so it stays greppable. */
export declare function collectionLabel(name: string): string;
/**
 * The copy banner's sentences about collections (#960): what was copied, and only what was actually
 * left out, each with its reason.
 *
 * ⚠ An `excluded` collection the source holds none of is not named: nothing was left out. One whose
 * rows CWS cannot read is named, because it may hold some.
 *
 * @param withPricing The copy is a copy-with-pricing (#459), whose prices follow the create.
 */
export declare function describeCollectionCopy(plan: CollectionCopyPlan, withPricing: boolean): readonly string[];
/** `a`, `a and b`, `a, b and c`, over collection names. */
export declare function listCollections(names: readonly string[]): string;
/**
 * A period read from CTRM as an editable row (#1018), keeping every member the write needs.
 *
 * 🔴 **The late pickup and early delivery dates ride along although the screen does not edit them.**
 * The collection is written whole, so a row that dropped them would write them empty on the next
 * save. The record screen's seed and a copy's (#960) both build rows here, so neither can drop one.
 */
export declare function shipPeriodRowOf(period: ContractShipPeriod): ShipPeriodRow;
/**
 * One `ship_periods` row to send, in CTRM's member names (#1018).
 *
 * ⚠ **Every member of {@link ContractWriteShipPeriod}, always.** The literal is typed as the write
 * row, so a member the type gains and this leaves out fails to compile, and the drift spec holds the
 * keys this returns to `constraints.json`'s. A row added on screen has no late pickup or early
 * delivery date, and sends `null` for both.
 */
export declare function shipPeriodWriteRow(row: ShipPeriodRow): ContractWriteShipPeriod;
/**
 * Where a contract record was opened from, so the breadcrumb can go back there.
 *
 * 🔴 **The record screen's first crumb used to be a hard-coded "Contracts" pointing at `/`.** That
 * was correct while the workspace grid was the only way in; the approvals and pricing queues made it
 * wrong in the way that is worst — it *worked*, so an approver who double-clicked a row, looked at
 * the contract and pressed the crumb was silently moved to a different screen, losing the queue's
 * filters, its sort and their place in it. Nothing looked broken; the queue was simply gone.
 *
 * ⚠ **The origin travels in the URL, not in a service.** A record screen reached by a pasted link or
 * a reload has to render the same breadcrumb as one reached by a click, and shell state would not
 * survive either. It also keeps the record screen ignorant of the queues: it renders a label and a
 * path from this table rather than importing three feature libraries to ask them who they are.
 */
/** The screens a contract record can be opened from. */
export type RecordOrigin = 'contracts' | 'approvals' | 'pricing';
/** The query parameter carrying it. Paired with `returnTo`, which carries the grid's own state. */
export declare const RECORD_ORIGIN_PARAM = "from";
export interface RecordOriginDescriptor {
  /** The breadcrumb's wording — the name of the screen you came from, as its nav entry reads. */
  readonly label: string;
  /** Where the crumb navigates. */
  readonly path: string;
  /**
   * The per-contract screen sitting BETWEEN the queue and the record, where the journey passes
   * through one.
   *
   * 🔴 **Both queues have one now, and the pricing entry is here because the journey changed rather
   * than because the table was tidied.** This used to say pricing had none — true while the pricing
   * queue navigated straight to the record, which it no longer does (#201). It opens
   * `/pricing/{n}`, and that screen links on to the record, so `from=pricing` means two screens are
   * behind you exactly as `from=approvals` does.
   *
   * ⚠ **Keep this keyed to who *sets* the parameter.** The rule the old note gave was the right one
   * and it is what made this edit safe: an entry here is correct only while the screen that sets
   * `from` is genuinely reached through the middle screen. Add one for a queue that still navigates
   * direct and the crumb points at a screen the user never saw.
   */
  readonly review?: RecordOriginReview;
}
/** The per-contract screen between a queue and the record. */
export interface RecordOriginReview {
  /** Short, and the queue's own word for it — the approvals grid's row button reads "Review". */
  readonly label: string;
  /** Built from the contract number, because the screen is per contract. */
  readonly path: (contractNumber: string) => string;
}
/** One link in the breadcrumb trail. */
export interface RecordCrumb {
  readonly label: string;
  readonly path: string;
}
/**
 * The origin a `from` parameter names, defaulting to the workspace.
 *
 * ⚠ **An unrecognised value falls back rather than throwing**, and that is deliberate: a URL can say
 * anything, and a stale or hand-edited link should land on a working breadcrumb rather than break
 * the record screen. The fallback is the workspace because that is where the crumb pointed before
 * this existed, so an old link keeps behaving exactly as it used to.
 *
 * ⚠ **`fallback` exists for screens whose own default is not the workspace**, and the approval review
 * screen is the case: it is reached from the approvals queue, so an absent `from` means *approvals*
 * there and *contracts* here. Defaulting it to `contracts` would send an approver who arrived by a
 * pasted link back to the workspace — the silent wrong-screen move this whole file exists to stop,
 * reintroduced one screen along.
 */
export declare function recordOrigin(value: string | null | undefined, fallback?: RecordOrigin): RecordOriginDescriptor;
/**
 * The origin a `from` parameter names, as its logical name, with the same fallback as
 * {@link recordOrigin}.
 *
 * For a screen that hands the origin to the host as a navigation intent (E9 PR 4, F9.10): the intent
 * carries a name, not a path, and a screen whose own default is not the workspace must send the name
 * it resolved, or the host's table falls back to the workspace instead. One narrowing for both.
 */
export declare function recordOriginKey(value: string | null | undefined, fallback?: RecordOrigin): RecordOrigin;
/**
 * The full trail back from a contract record — every screen between the workspace and here.
 *
 * 🔴 **A single crumb was wrong for the approvals journey, and wrong in the way that is hardest to
 * see: it worked.** From the review screen, "View full record" left a trail reading
 * `Approvals › SS1242898`, so the only way back was past the screen the user had actually come from.
 * They had read the contract in order to decide on it, and the trail offered them the queue instead —
 * losing the decision they were in the middle of, with nothing looking broken.
 *
 * ⚠ **The review crumb is DERIVED, not passed.** `from=approvals` is set in exactly one place — the
 * review screen's own "View full record" link — so its presence already means the review screen is
 * behind you, and the screen is `/approvals/{contractNumber}` for the contract being shown. A second
 * parameter carrying the same fact is a second copy that can disagree with the first.
 *
 * ⚠ **No contract number, no middle crumb.** Create mode has no contract, so the review path would be
 * `/approvals/` — a link to the queue wearing the review crumb's label.
 */
export declare function recordTrail(origin: RecordOriginDescriptor, contractNumber: string): readonly RecordCrumb[];
/**
 * **A contract save's success, carried across the navigation that follows it** (#803).
 *
 * A save that CTRM accepts navigates to the contract's view, and that is a NEW record screen: the
 * success the edit screen set is torn down with it, so a save was announced by nothing but the screen
 * changing. The edit screen leaves its sentence here before it navigates, and the view screen for that
 * contract takes it once, on arrival.
 *
 * - **Keyed by contract number**, so a different contract's screen never shows it.
 * - **Or by origin** (#888): Save-and-close returns to the grid the record was opened from, so its
 *   outcome is left for that grid. A contract and an origin never match each other.
 * - **Taken once**: a reload of the view does not announce the save again.
 * - **Root-provided**, so it survives the route change under any host, and holds at most one sentence:
 *   a second save replaces the first, which is what the user last did.
 * - **The whole outcome, not only its sentence** (#812), so a success that stays (saved, but CTRM
 *   could not notify the trader) still stays on the screen that shows it.
 */
export declare class SaveAnnouncementStore {
  private pending;
  announce(contractNumber: string, outcome: MutationOutcome): void;
  /** The outcome left for this contract, once; `null` when there is none or it was for another. */
  take(contractNumber: string): MutationOutcome | null;
  /** Leaves the outcome for the grid a Save-and-close returns to (#888). */
  announceForOrigin(origin: RecordOrigin, outcome: MutationOutcome): void;
  /** The outcome left for this origin's grid, once; `null` when there is none or it was for another. */
  takeForOrigin(origin: RecordOrigin): MutationOutcome | null;
  private takeKey;
  static ɵfac: i0.ɵɵFactoryDeclaration<SaveAnnouncementStore, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Whole days between an ISO date and a reference day.
 *
 * 🔑 **One copy, shared.** This was private to the approval queue's metrics; the contract workspace's
 * portfolio cards need exactly the same arithmetic, and a second copy of a date rule is how two
 * screens end up disagreeing about which contracts ship this month.
 *
 * ⚠ Parsed as **UTC midnight** rather than through the local-time `Date` constructor, which reads a
 * bare `yyyy-MM-dd` as UTC but a `yyyy/MM/dd` as local — so a mixed feed would shift some rows by a
 * day and move them across a threshold. Returning `null` for anything that does not parse keeps a
 * malformed date out of the count rather than letting `NaN` compare false in silence.
 *
 * Positive is in the PAST, negative is in the FUTURE — it answers "how long since", so a ship period
 * opening next week is `-7`.
 *
 * @param iso An ISO date, or `null`.
 * @param today The day to measure against. Taken as an argument so callers stay pure and testable.
 * @returns Whole days, or `null` when the date is absent or unparseable.
 */
export declare function wholeDaysBetween(iso: string | null, today: Date): number | null;
/**
 * What identifies the configuration to resolve (ADR-17 D1): contract type class → location/trade
 * unit → commodity, most matches winning.
 *
 * Either give the contract number and let the server derive all three from a fresh read — the only
 * correct route in view and edit mode, because `text_description` is CTRM-derived and read-only —
 * or give the dimensions explicitly, which is create mode and the grid.
 *
 * ⚠ **The grid resolves LOCATION-ONLY, deliberately.** A grid crosses many contract types and
 * commodities, so pinning either would resolve one row's configuration and apply it to all of them.
 */
export interface FormConfigResolutionKey {
  /** The contract to derive dimensions from. Wins over the explicit dimensions when present. */
  readonly contractNumber?: string;
  /** Normalized `text_description` — a text-set name such as `BCO - English`, not a bare token. */
  readonly contractTypeClass?: string;
  readonly locationCode?: string;
  readonly commodityCode?: string;
}
/** What the form needs to render: the resolved configuration plus the trade unit's own attributes. */
export interface FormConfigBundle {
  readonly config: ResolvedFormConfig;
  readonly tradeUnit: TradeUnitAttributes;
  /**
   * Which configuration row answered, and why (implementation brief §6).
   *
   * Absent only on the client-side fallback below, where no server resolution happened at all.
   */
  readonly provenance?: FormConfigProvenance;
  /**
   * True when this bundle was assembled client-side because the resolve endpoint could not be
   * reached.
   *
   * **Reported rather than hidden**, and the screen says so. The layout and CTRM's constraint
   * document are enough to render a correct, safe form — but nothing in it reflects any
   * per-trade-unit configuration an admin has saved, so a required field could be missing and a
   * hidden field could be showing. A user who is told that can act on it; one who is not will
   * report the save refusal as a bug in the form.
   */
  readonly defaultsOnly?: boolean;
  /**
   * Reference sets that came back empty, so their dropdowns have no values.
   *
   * Reported rather than hidden. Three of the nine sets are empty on UAT and two refuse an
   * unparameterised call (#44, #83), so a blank list is routine — and a combo rendering nothing looks
   * like a defect in this screen when it is a known gap in the reference route. The screen names
   * them; it does not silently show an empty list.
   */
  readonly unavailableLists?: readonly string[];
  /**
   * The constraint document the controls are validated against (#732): width, precision and scale
   * by CTRM field name. Absent when none should be applied, which is when the live document could
   * not be read and the server's own fold of it already sits on each field.
   */
  readonly constraints?: ConstraintSnapshot;
  /**
   * Why the screen should mention the field limits, if it should (#732):
   * - `bundled`: the limits are the copy built into this app, because the live document could not be
   *   read and the configuration could not be resolved either;
   * - `unavailable`: the live document could not be read. The configuration resolved, so widths and
   *   decimal places still come from the server, but digits before the decimal point are not checked
   *   on this screen. CTRM still checks them on save.
   */
  readonly constraintsNotice?: 'bundled' | 'unavailable';
}
export interface FormConfigSource {
  load(key: FormConfigResolutionKey): Observable<RemoteData<FormConfigBundle>>;
}
/**
 * The seam between the record screen and wherever its configuration comes from.
 *
 * ✅ **F2.1 exists now.** `GET /api/v1/form-configurations/resolve` serves the resolved
 * configuration with provenance (ADR-17), and `HttpFormConfigSource` calls it — the client-side
 * assembly from the layout plus `/meta/constraints` survives as its *fallback* rather than as the
 * primary path.
 *
 * Keeping it behind a token is what made that swap a change to one class rather than to every
 * feature component, which is the whole reason the token was introduced before the endpoint existed.
 */
export declare const FORM_CONFIG_SOURCE: InjectionToken<FormConfigSource>;
/**
 * **The section→tab cascade (F8.3, ruled by JFrisbie 2026-09-24).**
 *
 * A tab whose every section has been hidden is dropped, rather than rendered empty.
 *
 * ### Why this is one function and not three predicates
 *
 * Three surfaces have to agree about it: the **record screen** (which renders the tabs), the admin
 * **preview tool** (whose whole purpose is to show what the record screen will do), and the
 * **editor**, which warns the administrator at the moment they hide the last section. A preview that
 * disagreed with the record screen would be worse than no preview at all — it would be a
 * confidently wrong answer — and three copies of a predicate is the second-copy drift ADR-7 exists
 * to prevent.
 *
 * So the rule lives here, structurally typed over the *minimum* each caller can supply, and each of
 * the three shapes (`ConfigTab`/`ConfigSection`, `FormTabConfig`/`FormSectionConfig`, and the
 * preview's own) satisfies it without conversion.
 *
 * ### 🔴 The Remarks guard, which is the half that is easy to get wrong
 *
 * **A tab the layout never gave sections to is NOT emptied by this rule.** Remarks carries no
 * sections at all and renders two collections perfectly well, so a naive *"drop any tab with no
 * visible section"* would delete a working tab from every trade unit at once. The predicate is
 * therefore *"had sections, and now none of them are visible"* — an emptied tab, not an empty one.
 *
 * ⚠ The distinction is invisible in the common case: for every tab that does own sections the two
 * readings agree. It only diverges on Remarks, which is exactly why it needs a named control rather
 * than an assertion that the tabs came out right.
 *
 * ### Framework-free on purpose
 *
 * No Angular, no I/O, no signals — the same contract `market-cascade.ts` keeps, so it can be unit
 * tested as a table and consumed from a component, a computed, or neither.
 */
/** The minimum a tab must expose for the cascade. */
export interface CascadeTab {
  readonly id: string;
  readonly visible: boolean;
}
/** The minimum a section must expose. `tab` matches a {@link CascadeTab.id}. */
export interface CascadeSection {
  readonly tab: string;
  readonly visible: boolean;
}
/**
 * The tabs that were **emptied** — visible themselves, owning at least one section, and with none
 * of those sections left visible.
 *
 * This is the primitive: {@link tabsAfterCascade} is defined in terms of it, so the warning the
 * editor shows and the tabs the record screen drops cannot disagree about which tabs are affected.
 */
export declare function emptiedTabs<T extends CascadeTab>(tabs: readonly T[], sections: readonly CascadeSection[]): readonly T[];
/**
 * The tabs a surface should render: visible, minus the emptied ones.
 *
 * ⚠ **Order and identity are preserved from the input** — this narrows the caller's own array
 * rather than rebuilding it, so a caller that has already sorted or mapped its tabs keeps that
 * work, and anything it carries beyond `id`/`visible` survives.
 */
export declare function tabsAfterCascade<T extends CascadeTab>(tabs: readonly T[], sections: readonly CascadeSection[]): readonly T[];
/** One configuration row as the admin list shows it. */
export interface FormConfigRow {
  readonly id: number;
  readonly contractTypeClass: string | null;
  readonly locationCode: string | null;
  readonly commodityCode: string | null;
  readonly dimensionKey: string;
  readonly effectiveFrom: string;
  readonly version: number;
  readonly isActive: boolean;
  readonly modifiedByUpn: string;
  readonly modifiedAtUtc: string;
  /** Opaque concurrency token — travels back on `If-Match` and is never interpreted here. */
  readonly rowVersion: string;
}
export interface FormConfigListResponse {
  readonly rows: readonly FormConfigRow[];
  /** `Database` or `InMemory`. The screen says which, because one of them is not durable. */
  readonly storeOrigin: string;
}
/** What the preview tool asked for and what came back. */
export interface FormConfigPreview {
  readonly config: {
    readonly tradeUnit: string;
    readonly version: string;
    readonly tabs: readonly {
      id: string;
      label: string;
      order: number;
      visible: boolean;
    }[];
    readonly sections: readonly {
      readonly componentName: string;
      readonly label: string;
      readonly tab: string;
      readonly visible: boolean;
      readonly fields: readonly {
        readonly componentName: string;
        readonly label: string;
        readonly behaviour: {
          readonly visible: boolean;
          readonly required: boolean;
          readonly readOnly: boolean;
        };
      }[];
    }[];
    /** Every registry collection's copy flags (#959); absent from a server without it. */
    readonly collections?: Readonly<Record<string, ConfigCollectionBehaviour>>;
    /** Every remark type's Visible and Required (#1022); absent from a server without it. */
    readonly remarkTypes?: Readonly<Record<string, ConfigRemarkTypeBehaviour>>;
  };
  readonly tradeUnitAttributes: {
    readonly autoCalculationMode: string;
    readonly pendingContractsEnabled: boolean;
    /** The home grid's columns (#748); absent means every column. Stored by #747. */
    readonly homeGridColumns?: readonly string[];
  };
  readonly provenance: {
    readonly configId: number | null;
    readonly rank: number;
    readonly matchedDimensions: readonly string[];
    readonly effectiveFrom: string | null;
    readonly version: number | null;
    readonly source: string;
  };
}
/** The dimensions a preview resolves for. Every one optional — absent means *any*. */
export interface PreviewDimensions {
  readonly contractTypeClass?: string;
  readonly locationCode?: string;
  readonly commodityCode?: string;
  readonly contractNumber?: string;
}
/**
 * The field registry — what a contract field IS (implementation brief §5.4).
 *
 * Served rather than stored: it is the merged view of `constraints.json` and the shared Angular
 * layout, which already state all of this. The editor needs it to know **which fields exist at
 * all**, and which of them an administrator may not touch.
 */
export interface FormConfigRegistry {
  readonly schemaVersion: number;
  readonly tabs: readonly ConfigTab[];
  readonly sections: readonly ConfigSection[];
  readonly fields: Readonly<Record<string, RegistryField>>;
  /**
   * CTRM's child collections, keyed by their CTRM name (`ship_periods`), served by #959 (PR #991).
   *
   * ⚠ **Optional, because a server without #959 does not send it.** Absent means the server offers no
   * collection copy settings, and the editor shows no block for them rather than an error.
   */
  readonly collections?: Readonly<Record<string, RegistryCollection>>;
  /**
   * CTRM's remark types, in the order the record screen shows them, served by #1022 (#1006).
   *
   * An ARRAY rather than a map keyed by code, because the codes are `P`, `1`…`9`, `A`: a JSON object
   * read into JavaScript iterates integer-like keys first, so a map would come back as `1`…`9`, `P`,
   * `A`, and the block would not read in the record screen's order.
   *
   * ⚠ **Optional, because a server without #1022 does not send it.** Absent means the server offers no
   * remark settings, and the editor shows no block for them rather than an error.
   */
  readonly remarkTypes?: readonly RegistryRemarkType[];
}
/** One CTRM remark type in the registry (#1006): its `remark_type` code and the label it shows. */
export interface RegistryRemarkType {
  readonly code: string;
  readonly label: string;
}
/**
 * One remark type's Visible and Required (#1006). One declaration with the resolved configuration's,
 * so the editor and the record screen read the same type. A missing entry means shown and optional.
 */
export type ConfigRemarkTypeBehaviour = RemarkTypeBehaviour;
/** One CTRM child collection in the registry (#959). Generated server-side from `constraints.json`. */
export interface RegistryCollection {
  /** `upsertContract` accepts the collection. */
  readonly writable: boolean;
  /**
   * A copy can carry it at all. `false` means the server refuses a set copy flag on it (`400` on
   * `config.collections.<name>`), so the editor shows its box disabled with the reason.
   */
  readonly copyable: boolean;
  /** The element cap from `ContractDS`, or `null` where the catalogue states none. */
  readonly maxItems: number | null;
}
/**
 * One collection's copy flags (#959). The editor sends `excludeFromTemplateCopy` unchanged, because
 * templates do not carry collections yet.
 *
 * One declaration with the resolved configuration's, so the editor and Copy (#960) read the same type.
 */
export type ConfigCollectionBehaviour = CollectionBehaviour;
export interface RegistryField {
  readonly ctrmField: string;
  readonly label: string;
  readonly section: string;
  readonly order: number;
  /** CTRM refuses this field on a write, or issues its value itself. Never requirable. */
  readonly readOnly: boolean;
  /** `false` for the drivers and the contract number — no row may hide or relax them (D9). */
  readonly configurable: boolean;
  /** The three resolution drivers, always required on create. */
  readonly systemRequired: boolean;
  readonly constraints: {
    readonly maxLength?: number;
    readonly decimalPlaces?: number;
  } | null;
}
export interface ConfigTab {
  readonly id: string;
  readonly label: string;
  readonly order: number;
  readonly visible: boolean;
}
export interface ConfigSection {
  readonly id: string;
  readonly label: string;
  readonly tab: string;
  readonly order: number;
  readonly visible: boolean;
}
/** The six per-field behaviour flags, plus where the field sits. */
export interface ConfigFieldBehaviour {
  readonly visible: boolean;
  readonly required: boolean;
  readonly readOnly: boolean;
  readonly borderWarning: boolean;
  readonly excludeFromCopy: boolean;
  readonly excludeFromTemplateCopy: boolean;
  readonly section: string;
  readonly order: number;
  /**
   * #221's presentation, beside the six flags rather than among them. Optional, and absent means
   * the layout's value: the editor writes it only when a value was set, so saving a row does not
   * freeze the layout into it.
   */
  readonly presentation?: FieldPresentation;
}
/** The configuration document — what a row stores. */
export interface ConfigDocument {
  readonly schemaVersion: number;
  readonly tabs: readonly ConfigTab[];
  readonly sections: readonly ConfigSection[];
  readonly fields: Readonly<Record<string, ConfigFieldBehaviour>>;
  readonly attributes: {
    readonly autoCalculationMode: string;
    readonly pendingContractsEnabled: boolean;
    /** The home grid's columns (#748); absent means every column. Stored by #747. */
    readonly homeGridColumns?: readonly string[];
  };
  /**
   * The collection copy flags (#959), keyed by CTRM collection name.
   *
   * ⚠ **Absent on a row saved before #959, and the editor SENDS IT SPARSE**: only the collections an
   * administrator changed. The server keeps the current value for any it leaves out, so a save that
   * touched no collection carries no `collections` member at all.
   */
  readonly collections?: Readonly<Record<string, ConfigCollectionBehaviour>>;
  /**
   * Each remark type's Visible and Required (#1006, #1022), keyed by CTRM's `remark_type` code.
   *
   * ⚠ **Absent on a row saved before #1022, and the editor SENDS IT SPARSE**, as it does
   * `collections`: only the types an administrator changed. A save that touched no remark type carries
   * no `remarkTypes` member at all.
   */
  readonly remarkTypes?: Readonly<Record<string, ConfigRemarkTypeBehaviour>>;
}
/** One row with its full document, for the editor to load. */
export interface FormConfigDetail extends FormConfigRow {
  readonly config: ConfigDocument;
  readonly createdByUpn: string;
  readonly createdAtUtc: string;
}
/** What the editor submits. Dimensions are omitted rather than blank when they mean *any*. */
export interface FormConfigSubmission {
  readonly contractTypeClass?: string;
  readonly locationCode?: string;
  readonly commodityCode?: string;
  readonly effectiveFrom: string;
  readonly config: ConfigDocument;
}
/**
 * One entry in a row's audit trail (F8.6).
 *
 * ⚠ **`configJsonSnapshot` is the document AFTER the change, and there is no `before`.** The before
 * of entry *n* is entry *n−1*'s snapshot, which is why the trail's ORDER is part of its contract —
 * see `diffConfigDocuments`.
 */
export interface FormConfigAuditEntry {
  readonly auditId: number;
  readonly changeType: 'Created' | 'Updated' | 'Deactivated';
  readonly configJsonSnapshot: string;
  readonly dimensionKey: string;
  readonly effectiveFrom: string;
  readonly version: number;
  readonly actorUpn: string;
  readonly timestampUtc: string;
  readonly correlationId: string;
}
export interface FormConfigAuditTrail {
  readonly entries: readonly FormConfigAuditEntry[];
  /**
   * True when the server left out entries made while the row was in a trade unit this account does
   * not manage (#700). The first entry shown then has a "before" that is not on screen.
   */
  readonly partial?: boolean;
}
export interface FormConfigAdminSource {
  list(): Observable<RemoteData<FormConfigListResponse>>;
  /** One row's audit trail, oldest first (F8.6). */
  auditTrail(id: number): Observable<RemoteData<FormConfigAuditTrail>>;
  registry(): Observable<RemoteData<FormConfigRegistry>>;
  get(id: number): Observable<RemoteData<FormConfigDetail>>;
  preview(dimensions: PreviewDimensions): Observable<RemoteData<FormConfigPreview>>;
  create(submission: FormConfigSubmission): Observable<RemoteData<FormConfigDetail>>;
  update(id: number, rowVersion: string, submission: FormConfigSubmission): Observable<RemoteData<FormConfigDetail>>;
  deactivate(id: number, rowVersion: string): Observable<RemoteData<FormConfigRow>>;
}
/**
 * The seam, so the screen can be rendered against a stub in tests and against HTTP in the app —
 * the same arrangement as every other feature's data source in this repository.
 */
export declare const FORM_CONFIG_ADMIN_SOURCE: InjectionToken<FormConfigAdminSource>;
/**
 * **The form-configuration audit diff (F8.6).**
 *
 * `FormConfigurationAudit` stores the full document **after** each change and nothing else. There
 * is no `before` column, and this module is why none is needed: the *before* of entry *n* is the
 * snapshot of entry *n−1*, so a diff is derivable from what is already stored with **no new
 * storage, no new column and no second write**.
 *
 * ### 🔴 A `Created` entry has no predecessor, and must not render as 111 changes
 *
 * The first entry in a trail is an addition, not a modification. Diffing it against an empty
 * document would produce a line for every field in the configuration, which is both useless and
 * actively misleading — it reads as though someone changed 111 things. {@link diffConfigDocuments}
 * takes `null` for *before* and returns **no changes** in that case; the screen says "created"
 * instead.
 *
 * ### Why a flat list rather than a tree
 *
 * The requirement is *one line per change*. A nested result would push the flattening into the
 * template, where it cannot be unit-tested as a table — and the interesting property of this
 * function is exactly the table: which pairs of documents produce which lines.
 *
 * ### Framework-free on purpose
 *
 * No Angular, no I/O — the contract `market-cascade.ts` and `tab-cascade.ts` keep.
 */
/** What kind of thing changed. Drives grouping and the icon, not the wording. */
export type ConfigChangeScope = 'field' | 'section' | 'tab' | 'attribute' | 'collection' | 'remark';
/** One rendered line. */
export interface ConfigChange {
  readonly scope: ConfigChangeScope;
  /** The thing: a component name, a section id, a tab id, or the attribute name. */
  readonly subject: string;
  /** Which property of it, or `'(added)'` / `'(removed)'` for whole-subject changes. */
  readonly property: string;
  /** Rendered previous value; empty string when the subject did not exist. */
  readonly before: string;
  /** Rendered new value; empty string when the subject was removed. */
  readonly after: string;
}
/**
 * Every difference between two stored documents, one entry per changed property.
 *
 * @param before The previous snapshot, or `null` for the first entry in a trail (a `Created`).
 * @param after The snapshot this audit entry recorded.
 */
export declare function diffConfigDocuments(before: ConfigDocument | null, after: ConfigDocument): readonly ConfigChange[];
/**
 * **Trade-unit narrowing of a coded list (F8.2 allowed values, F8.5 market months).**
 *
 * Both features are the same operation: CTRM offers a list, the trade unit's configuration may
 * reduce it, and **it may never extend it**.
 *
 * ### 🔴 No configuration means NO NARROWING, never "allow nothing"
 *
 * This is the rule the whole module exists to hold, and getting it backwards is catastrophic and
 * silent: read as deny-by-default, every unconfigured trade unit would get a combo with no options
 * in it — the closed list of nothing that #219 criterion 7 forbids — on every coded field at once,
 * and it would look like a broken screen rather than a configuration.
 *
 * ### 🔴 Narrowing only, in the strict sense
 *
 * A configured value that CTRM did **not** offer is **not added**. For market months that is not a
 * nicety: CTRM refuses a month that does not belong to the contract's market
 * (`wnr051e:5881-5891`), so offering one would convert an administrator's typo into a write
 * refusal the trader cannot diagnose. The configuration is read *after* CTRM's list and intersected
 * with it.
 *
 * ### The two kinds of row, and why both exist
 *
 * `docs/03` §5 gives `ValueConfigurations` an `Include` flag rather than making the table a bare
 * allow-list, so a row can say *"considered and excluded"* as distinct from *"nobody has said"*:
 *
 * | Configured rows | Result |
 * |---|---|
 * | none | CTRM's list, unchanged |
 * | at least one `include: true` | the offered codes that are included, minus any excluded |
 * | only `include: false` rows | CTRM's list minus those, i.e. exclusions alone |
 *
 * ⚠ The third row is the one worth stating: a component configured **only** with exclusions is not
 * an empty allow-list. Treating it as one would hide every value the administrator did not think to
 * list.
 *
 * ### Framework-free on purpose
 *
 * The same contract `market-cascade.ts` and `tab-cascade.ts` keep.
 */
/** The minimum a configured row must expose. `value` is compared after {@link normaliseCode}. */
export interface ConfiguredValue {
  readonly value: string;
  readonly include: boolean;
}
/** The minimum an offered option must expose. */
export interface OfferedValue {
  readonly code: string;
}
/**
 * TRIM + UPPER — the same normalisation the server keys on.
 *
 * ⚠ **Both sides must use this one function.** CTRM's codes arrive padded and inconsistently cased,
 * so a configured `" yc "` compared literally against a returned `"YC"` matches nothing and the
 * configuration silently narrows nothing at all — which reads as the feature not being wired up.
 */
export declare function normaliseCode(value: string): string;
/**
 * CTRM's list, narrowed by the trade unit's configuration.
 *
 * @param offered What CTRM returned. Returned unchanged when nothing is configured.
 * @param configured The rows for this component (or commodity). Empty means no opinion.
 */
export declare function narrowToConfigured<T extends OfferedValue>(offered: readonly T[], configured: readonly ConfiguredValue[]): readonly T[];
/**
 * The trade-unit narrowing tables (F8.2 allowed values, F8.5 market months).
 *
 * 🔴 **Every read here can legitimately return nothing, and nothing means NO NARROWING.** A failed
 * call settles as an **empty list** for the same reason: a configuration that cannot be fetched
 * must leave CTRM's list alone, never replace it with an empty one. Degrading to "unnarrowed" shows
 * the user more than they should see; degrading to "empty" shows them a form they cannot fill in.
 */
export interface ValueConfigurationRow {
  readonly id: number;
  readonly tradeUnit: string;
  readonly componentName: string;
  readonly value: string;
  readonly include: boolean;
  readonly modifiedByUpn: string;
  readonly modifiedAtUtc: string;
}
export interface MarketMonthConfigRow {
  readonly id: number;
  readonly tradeUnit: string;
  readonly commodity: string;
  readonly marketMonth: string;
  readonly modifiedByUpn: string;
  readonly modifiedAtUtc: string;
}
export interface TradeUnitValuesSource {
  /** Every configured value for a trade unit. Empty means no narrowing. */
  values(tradeUnit: string): Observable<readonly ValueConfigurationRow[]>;
  /** Every configured market month for a trade unit. Empty means no narrowing. */
  marketMonths(tradeUnit: string): Observable<readonly MarketMonthConfigRow[]>;
}
/**
 * The seam.
 *
 * 🔴 **No root default any more (2026-09-30, E9 PR 3, D-16).** A root factory instantiated the HTTP
 * source in whichever injector asked first — inside a host that provides `CONTRACTS_API_URL` for a
 * single screen, that is the host's `HttpClient` with no CWS bearer. `provideCwsWorkspace` binds it
 * explicitly, and its golden-list test is what now makes the narrowing impossible to forget:
 * narrowing is not opt-in, because a screen without it renders CTRM's list unnarrowed, a *wrong*
 * form rather than a broken one. A screen composed without it now fails `NG0201`, loudly.
 */
export declare const TRADE_UNIT_VALUES_SOURCE: InjectionToken<TradeUnitValuesSource>;
/**
 * The live implementation.
 *
 * Provided by `provideCwsWorkspace` (and by any host composing this screen); never root — see
 * `no-root-provision.spec.ts`.
 */
export declare class HttpTradeUnitValuesSource implements TradeUnitValuesSource {
  private readonly http;
  private readonly baseUrl;
  /**
   * One replayed stream per trade unit, for the session.
   *
   * Configuration changes rarely and is read on every form load, so a per-session cache is the
   * right trade — and it is keyed by trade unit because a shared key would hand one trade unit's
   * narrowing to another, which is a wrong form rather than a slow one.
   */
  private readonly cache;
  values(tradeUnit: string): Observable<readonly ValueConfigurationRow[]>;
  marketMonths(tradeUnit: string): Observable<readonly MarketMonthConfigRow[]>;
  private fetch;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpTradeUnitValuesSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **The contract's trader, as an email address — Notify Trader's default recipient (#458).**
 *
 * Ruled on #513 (GEstevez, 2026-09-30): the recipient list opens with the contract's trader. The
 * contract carries only `trader_initials`, and **no route CWS has maps initials to a user** (#513
 * leaves where CTRM, GraphQL or Entra holds it as research). So this is a seam with no HTTP source
 * on purpose (JFrisbie, 2026-10-05): one is added when the route is designed, not invented ahead of
 * it. Until then the screen starts the list empty and names the trader's initials.
 *
 * Optional: a screen with no source behaves exactly as an unresolvable trader.
 */
export interface TraderEmailSource {
  /** The trader's address for these initials, or `null` when it is not known. */
  emailFor(traderInitials: string): Observable<string | null>;
}
export declare const TRADER_EMAIL_SOURCE: InjectionToken<TraderEmailSource>;
/**
 * A SIMULATED resolver for the playground and the tests: every trader is the repository's existing
 * placeholder address. ⚠ Deliberately not derived from the initials, so it can never be read as a
 * real directory answer, and no new address enters the repository (#282's pre-commit guard).
 */
export declare const SAMPLE_TRADER_EMAIL = "someone@scoular.com";
export declare class SampleTraderEmailSource implements TraderEmailSource {
  emailFor(traderInitials: string): Observable<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleTraderEmailSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** One cell of a section's layout: a single field, or a compound group drawn as one field. */
type LayoutItem = {
  readonly kind: 'field';
  readonly key: string;
  readonly field: FormFieldConfig;
} | {
  readonly kind: 'group';
  readonly key: string;
  readonly groupKey: string;
  readonly heading: string;
  readonly fields: FormFieldConfig[];
  help: HelpTipEntry[];
};
export declare class ContractFormComponent implements OnInit {
  private readonly formBuilder;
  readonly config: import("@angular/core").InputSignal<ResolvedFormConfig>;
  readonly tradeUnit: import("@angular/core").InputSignal<TradeUnitAttributes>;
  /**
   * Contract-level facts the rules need but the form does not hold — closed, intercompany, editable.
   * Defaults to a new, editable, non-intercompany contract, which is what a create screen is.
   */
  readonly facts: import("@angular/core").InputSignal<ContractFacts>;
  /**
   * Renders every field inactive — the record screen's view mode.
   *
   * Applied as a *state* override rather than by disabling controls, so the values stay readable,
   * selectable and copyable and the tab sequence is intact. See the class remarks.
   *
   * ⚠ It is presentation, not protection. Nothing here decides what may be written: the save path
   * builds its payload from `CONTRACT_WRITABLE_FIELDS` and only from controls marked dirty, and a
   * view-mode form marks nothing dirty because {@link defaultValues} is skipped while this is true.
   */
  readonly readOnly: import("@angular/core").InputSignal<boolean>;
  /** Distinguishes two instances of this form on one host page (03 §3.4). */
  readonly instanceId: import("@angular/core").InputSignal<string>;
  /**
   * Which section ids to render. `null` — the default — renders them all.
   *
   * 🔴 **`null` and `[]` mean different things, and conflating them was a real defect.** This was
   * `input<readonly string[]>([])` with an `shown.length === 0` escape in {@link sections}, so an
   * empty array meant *"the caller is not filtering"*. The Remarks tab legitimately resolves to no
   * sections — the tab totals reconcile to the whole field set without it (when this was found:
   * Contract Info 63 + Shipping Info 38 + Additional fields 10 = 111; the layout is 102 fields since
   * #143) — so it passed `[]` and got **every** section,
   * which is the one tab where showing everything is most obviously wrong.
   *
   * An untabbed caller omits the input entirely and gets `null`, so it keeps the previous behaviour.
   * The general shape is worth remembering: an absent filter and a filter that matches nothing are
   * different questions, and a single empty value cannot answer both.
   *
   * 🔴 **This is a display filter, and it must never become a filter on what the form CONTAINS.** The
   * record screen is tabbed, and the obvious implementation — wrap the form in `@if (tab === …)` and
   * render one tab at a time — destroys and rebuilds this component on every tab change. The form is
   * seeded once in `ngOnInit`, so that would discard every value the user had typed, silently, on a
   * click that looks like navigation. It would also reset `dirty`, which is what the save path reads —
   * so a change made on the Contract Info tab would simply not be sent after visiting Shipping Info.
   *
   * So the group is always built from the **whole** configuration and only the rendering narrows.
   * Consequences worth knowing: validation covers fields you cannot currently see, `form.dirty` spans
   * tabs, and the save payload is unaffected by which tab is open. All three are correct, and none of
   * them would be true of the `@if` version.
   */
  readonly visibleSections: import("@angular/core").InputSignal<readonly string[] | null>;
  /**
   * View mode only: leave out fields that hold no value (2026-10-13), and any section left with none.
   *
   * 🔴 **A display filter, exactly like {@link visibleSections}, and never a filter on the form.** The
   * controls are all still built and seeded; this narrows only what the sheet draws. Ignored while
   * editing or creating, because there an empty field is the one you are about to fill in.
   *
   * Empty means empty, not falsy: a zero is a value, and a toggle that is off says "No".
   */
  readonly hideEmptyFields: import("@angular/core").InputSignal<boolean>;
  /**
   * A description per field component name, offered behind an "i" beside the label.
   *
   * Passed in as data rather than read from a catalogue here, so this component stays what it is —
   * something that renders any `ResolvedFormConfig` — instead of learning about one screen's
   * particular notes. F2.1's payload will carry the equivalent, at which point the caller supplies it
   * from there and nothing changes in this file.
   *
   * 🔴 **On request, not on screen** (2026-10-13). These printed under every control, which gave rows
   * of unequal height and buried the values in grey text. A note the user must read before acting
   * belongs in {@link pinnedNotes} instead.
   */
  readonly fieldNotes: import("@angular/core").InputSignal<Readonly<Record<string, string>>>;
  /**
   * Text per field that STAYS on screen under the control, because the user needs it without asking:
   * a precondition on the value, or the outcome of something they just did.
   *
   * Separate from {@link fieldNotes} for the same reason {@link emptyNotes} is: once merged, nothing
   * downstream can tell which notes may be tucked away.
   */
  readonly pinnedNotes: import("@angular/core").InputSignal<Readonly<Record<string, string>>>;
  /**
   * Help text that applies **only while the field is empty** — why this one is permanently blank.
   *
   * 🔴 **Separate from {@link fieldNotes} because merging the two made the screen state something
   * false.** An `emptyNote` answers a question a blank field cannot ("CTRM has not versioned this
   * contract", "no CTRM route returns a customer name yet"). Folded in with ordinary help text it
   * rendered regardless of the value, so a contract at version `009` carried a note saying it had no
   * version — the screen contradicting the value next to it (#195, QA finding F-03).
   *
   * ⚠ **The two cannot be one record.** Once merged, nothing downstream can tell an always-true note
   * from a conditionally-true one, so the condition has to be applied by whoever still knows the
   * difference. That is here.
   */
  readonly emptyNotes: import("@angular/core").InputSignal<Readonly<Record<string, string>>>;
  /** The same, per section — used for what a section deliberately does not carry. */
  readonly sectionNotes: import("@angular/core").InputSignal<Readonly<Record<string, string>>>;
  /** Component names that need more room than a standard field: a `large` width (`fieldWidthFor`). */
  readonly wideFields: import("@angular/core").InputSignal<Readonly<Record<string, boolean>>>;
  /**
   * Component names a standard width overstates, such as a `maxLength: 1` prefix box: a `small` width.
   *
   * These used to pair two-to-a-cell, and a lone one left half a cell empty. The unit grid makes the
   * pairing unnecessary: a small field takes a small share of the row, and whatever follows flows in
   * beside it.
   */
  readonly halfFields: import("@angular/core").InputSignal<Readonly<Record<string, boolean>>>;
  /**
   * The CTRM field name per component name, shown in the "i" above the description.
   *
   * The resolved configuration carries `componentName` and never `ctrmField`, so a screen that wants
   * to tell a user which CTRM field they are editing has to hand it in. Worth showing precisely
   * because two labels on this form are ambiguous to a person (F-06/#196): "Contract type" and
   * "Contract type code" are different fields, and `contract_prefix_type` says which is which.
   */
  readonly fieldCtrmNames: import("@angular/core").InputSignal<Readonly<Record<string, string>>>;
  /**
   * The constraint document the controls are validated against (#732), or `null` for none. Read once,
   * at build, like the configuration: the form builder attaches each field's write width, precision
   * and scale from it by CTRM field name.
   */
  readonly constraints: import("@angular/core").InputSignal<ConstraintSnapshot | null>;
  /**
   * Component names whose visible heading is suppressed because they sit under a GROUP label.
   *
   * The three parts of the contract key share one "Contract number" heading -- they are one
   * identifier, and three headings read as three unrelated fields. ⚠ The label is hidden, never
   * removed, so the control keeps its accessible name.
   */
  readonly hiddenLabelFields: import("@angular/core").InputSignal<Readonly<Record<string, boolean>>>;
  /**
   * Visible headings that introduce a GROUP of fields, keyed on the field that starts the group.
   *
   * 🔴 Separate from the field label because they are different things, and conflating them is what
   * #196 reported. The key group used to take its heading from the first field's own `label`, which
   * forced `ContractPrefixType` to be called "Contract number" — leaving it and `ContractNumber` with
   * the **same accessible name**, the ambiguity that issue was opened about.
   *
   * ⚠ Rendered `aria-hidden`: every control in the group already has its own `sr-only` label, so
   * announcing the heading too would repeat it on each field.
   */
  readonly groupHeadings: import("@angular/core").InputSignal<Readonly<Record<string, string>>>;
  /**
   * Component names CTRM returns but refuses on a write, rendered inactive in every mode.
   *
   * They are on this form so reading a contract and editing it show the same fields in the same
   * places — a row that vanished when you pressed Edit is the findability problem this layout was
   * unified to fix. Inactive rather than hidden, because "CTRM owns this value" is information.
   *
   * 🔴 **Applied as `readOnly`, not `disable()`, and that changed on 2026-09-01.** Disabling worked
   * while these rows only ever appeared on a form, but it removes the value from the tab sequence and
   * from `Ctrl+C` — which on the record screen's view mode is the *primary* way the field is used. The
   * payload is unaffected either way: it is built from `CONTRACT_WRITABLE_FIELDS`, which excludes these
   * by construction rather than by relying on a control's disabled flag.
   */
  readonly readOnlyFields: import("@angular/core").InputSignal<Readonly<Record<string, boolean>>>;
  /**
   * Component names the user may not change on THIS screen, though CTRM accepts them: an existing
   * contract's key (#920). Inactive like {@link readOnlyFields}, without its "Set by CTRM" word, which
   * would be false for a key the user chose when creating the contract.
   */
  readonly lockedFields: import("@angular/core").InputSignal<Readonly<Record<string, boolean>>>;
  /**
   * The screen's verdicts on field values, by component name (#962): the typed contract number checked
   * free, taken or in flight. Drawn as the field's outline, with the sentence under the field, or under
   * the whole group for a group member, where a 7-character box has no room for one.
   */
  readonly fieldVerdicts: import("@angular/core").InputSignal<Readonly<Record<string, FieldVerdict>>>;
  /** A group's members that carry a verdict, for the sentences under its row (#962). */
  protected verdictsOf(fields: readonly FormFieldConfig[]): readonly {
    readonly componentName: string;
    readonly verdict: FieldVerdict;
  }[];
  /**
   * Values to seed the controls with, keyed by component name.
   *
   * Applied once, after the group is built, because the builder needs the configuration to know what
   * controls exist. Patched rather than passed into `build` so an unknown key is ignored instead of
   * creating a control the configuration did not ask for — a form that grew a field from its data
   * would render something no rule governs and no server accepts.
   *
   * **Marked pristine**, which is what makes "send only what changed" possible on an edit: a control
   * carrying CTRM's own value is not dirty, so it stays out of the payload and survives the merge.
   */
  readonly initialValues: import("@angular/core").InputSignal<Readonly<Record<string, unknown>>>;
  /**
   * Values the screen is asserting on the user's behalf, keyed by component name.
   *
   * 🔴 **Marked DIRTY, and that is the entire difference from {@link initialValues}.** A create has no
   * merge base, so a field that stays out of the payload is simply not written — and the save path
   * sends only dirty controls. The trade unit is the case that matters: the shell knows it, the route
   * locks its switcher precisely because you are creating *under* it, and a contract created without
   * one is accepted, reports a number, and is then **absent from the grid you created it from**,
   * because the list is scoped by trade unit and the projector re-applies that narrowing.
   *
   * Seeded visibly rather than injected at save time, so the value being written is the value on
   * screen. A screen that silently added a field to the payload would be writing something the user
   * never saw.
   *
   * ⚠ **Skipped entirely while {@link readOnly}.** These are the only values this component marks
   * dirty, so skipping them is what makes "a view of a record cannot produce a payload" structural
   * rather than a promise made by the page above.
   */
  readonly defaultValues: import("@angular/core").InputSignal<Readonly<Record<string, unknown>>>;
  /**
   * Emits the built form once, so the host page can read values and validity to save.
   *
   * The form stays owned here — the page gets a handle, not a second source of truth. Two components
   * building their own groups from one configuration is how a screen ends up saving values the user
   * never saw (03 §3.4.8 keeps instances separate for the same reason).
   */
  readonly ready: import("@angular/core").OutputEmitterRef<ContractForm>;
  /**
   * Fires with a field's component name when the field loses focus (F4.3b).
   *
   * The host page decides which fields it cares about — the record screen confirms a Customer id on
   * blur — so this form does not learn what a customer is. One output, every field, the name only.
   */
  readonly fieldBlur: import("@angular/core").OutputEmitterRef<string>;
  protected onFieldFocusOut(componentName: string): void;
  /**
   * The built form.
   *
   * A signal rather than a plain field so {@link fieldStates} can depend on it. A `computed` over a
   * mutable property would evaluate once — before `ngOnInit` assigns it — and never again, so every
   * field would render with no state and every section would come up empty.
   */
  protected readonly form: import("@angular/core").WritableSignal<ContractForm | null>;
  /**
   * Sections in configured order, carrying **only the fields that are actually shown**.
   *
   * Narrowed by {@link visibleSections} last, so the ordering and pruning rules are identical whether
   * or not a caller filters — a tabbed screen and an untabbed one show the same sections in the same
   * order.
   *
   * 🔴 **Hidden fields are dropped HERE rather than skipped in the template** (JFrisbie, 2026-09-08).
   * `<cms-dynamic-field>` already renders nothing for an invisible field, but the template still
   * emitted the grid cell around it — so a field turned off in configuration left **an empty column
   * that held its space**, and the field's help text rendered under it with no field to describe. The
   * reported symptom was a gap where `version` used to be, with "CTRM has not versioned this contract"
   * floating in it.
   *
   * Removing the field from this list means the CSS grid never sees a cell for it, so the fields after
   * it reflow up into the space. Doing it in one computation rather than with a second `@if` in the
   * template is what makes the empty-section prune below fall out of the same rule instead of being a
   * separate condition that can disagree with it.
   *
   * ⚠ **This does NOT drop the FormControl.** `FormBuilderService.build` walks `config()`, not this
   * list, and its own remarks are explicit that every configured field gets a control "including one a
   * rule has hidden. Visibility is transient; dropping the control would lose the value when the field
   * reappears." So a rule that turns a field back on finds its value intact.
   */
  protected readonly sections: import("@angular/core").Signal<{
    fields: FormFieldConfig[];
    componentName: string;
    label: string;
    tab: string;
    order: number;
    visible: boolean;
    mandatedFlags: import("@cws/shared-form-engine").MandatedFlags;
  }[]>;
  /**
   * Which compound GROUP each field belongs to, if any (2026-10-13).
   *
   * A group is what the layout already declares: a field carrying a `groupHeading` and the fields
   * straight after it in configured order whose own labels are hidden (`hiddenLabelFields`). The
   * contract number is the one today (two prefixes and the number, under "Contract number"), and any
   * other run marked the same way becomes one too; nothing here names a field.
   *
   * 🔴 **Read from the whole configuration, in configured order, not from what is shown.** So hiding a
   * member, or the heading field, only removes that member from its group; it never makes a neighbour
   * join a group it was not configured into. And a reorder that separates the members simply splits
   * the group, because only CONSECUTIVE shown members are drawn together (see {@link layouts}).
   */
  private readonly groupOf;
  /**
   * Each shown section's fields as LAYOUT ITEMS: a single field, or a compound group of consecutive
   * group members drawn as one field (2026-10-13). One configured field is not always one cell.
   *
   * Every member is still its own control with its own state, validation and payload key; the group
   * is presentation only. Its one "i" carries each member's description, headed by the member's label.
   */
  protected readonly layouts: import("@angular/core").Signal<{
    section: {
      fields: FormFieldConfig[];
      componentName: string;
      label: string;
      tab: string;
      order: number;
      visible: boolean;
      mandatedFlags: import("@cws/shared-form-engine").MandatedFlags;
    };
    items: LayoutItem[];
  }[]>;
  /**
   * True while the sheet is hiding empty fields AND that left nothing to show on this tab, so the
   * template can say so rather than render a blank tab. A tab with no sections to begin with (Remarks)
   * is not this case, which is why the count is taken without the empty filter.
   */
  protected readonly hidingEmpty: import("@angular/core").Signal<boolean>;
  /** {@link hideEmptyFields}, honoured only in view mode: a form always shows what it can take. */
  private readonly hidingEmptyFields;
  /** The control for a component name, so the shared cell template needs no alias in scope. */
  protected controlFor(componentName: string): ContractFieldControl | undefined;
  /**
   * Each field's semantic width, by component name (2026-10-13). See `fieldWidthFor` for the rules
   * and the template for the grid they map onto.
   *
   * Over the whole configuration rather than the shown sections, because a width depends only on the
   * field, so a field keeps its width when a neighbour is hidden, reordered or brought back.
   */
  protected readonly widths: import("@angular/core").Signal<Readonly<Record<string, FieldWidth>>>;
  /**
   * Each field's description for its "i", with the CTRM field name it is stored in.
   *
   * A map rather than a method so each field gets the same object on every change-detection pass. A
   * fresh object per pass would read as a new input to `cms-dynamic-field` every time.
   */
  protected readonly helps: import("@angular/core").Signal<Readonly<Record<string, FieldHelp>>>;
  /**
   * "Set by CTRM" on a field CTRM refuses on a write or derives itself, in every mode.
   *
   * While editing it sits on the label row and answers the question a value with no box raises: why
   * can I not change this? On the view sheet it sits in small type under the value, which is what
   * tells a derived figure from one somebody keyed, without a badge or a box.
   *
   * Only for {@link readOnlyFields}. A field a rule has made read-only is drawn as a value too, but
   * carries no word: "Set by CTRM" would be false for it, and a second word is clutter.
   */
  protected readonly markers: import("@angular/core").Signal<Readonly<Record<string, string>>>;
  /**
   * The box width for a group member whose value has a short fixed width, or `null` to share the row.
   *
   * 🔴 #920 (GEstevez, 2026-10-20): the key is one row of sized boxes, and the 7-character number was
   * stretched across it. A text member whose `maxLength` is short gets a box for that many characters,
   * read from the constraint document the form engine folds into each field (ADR-7). Never a guessed
   * width: a member with no known width keeps sharing the row (Known Issue 16). `2.5rem` is the input's
   * own horizontal padding and border; `ch` follows the font, so the box holds exactly the value.
   */
  protected memberWidth(member: FormFieldConfig): string | null;
  /** Whether a single field takes one normal cell of the grid: a normal field, and a compact one. */
  protected isNormalCell(componentName: string): boolean;
  /**
   * The note to keep on screen under a field right now, or `undefined` for none.
   *
   * A {@link pinnedNotes} entry wins. An {@link emptyNotes} entry is shown **only while the control is
   * empty** — that is the whole point of the split, and #195 is what happens without it. The field's
   * ordinary description is never here; it is in the "i" ({@link helps}).
   *
   * ⚠ **Empty means empty, not falsy.** `0` is a legitimate value for every numeric field on this
   * form — a zero quantity, a zero basis — so a truthiness test would put "CTRM holds nothing here"
   * beside a deliberate zero, which is the same false statement in a new place.
   */
  protected visibleNoteFor(componentName: string): string | undefined;
  /**
   * Whether a field renders — the engine's answer, falling back to configuration's.
   *
   * ⚠ **The fallback is load-bearing, not defensive.** `fieldStates()` is empty until `ngOnInit` builds
   * the form, and {@link sections} is read during the first render — so keying visibility on the engine
   * alone would make every section momentarily fieldless, and the prune above would then render *no
   * sections at all*. That is the same failure that once produced an empty record screen in 61 tests
   * from a filter reading the wrong side of a not-yet-populated map.
   *
   * Configuration is the right fallback rather than `true`: it is what the engine starts from, so the
   * first paint matches what the rules will confirm a tick later, and a field configured invisible never
   * flashes into view.
   */
  private isFieldShown;
  /**
   * Each field's state, with this screen's read-only overrides folded in.
   *
   * The engine's own state stays authoritative about everything else — visibility, requiredness, the
   * calculated-value formula, which rule spoke — so this narrows exactly one flag and copies the rest
   * through. Overriding here rather than in `FormBuilderService` keeps view-versus-edit out of the
   * rules, which are mirrored 1:1 server-side and know nothing about screens.
   */
  protected readonly fieldStates: import("@angular/core").Signal<ReadonlyMap<string, EffectiveFieldState>>;
  protected readonly idPrefix: import("@angular/core").Signal<string>;
  ngOnInit(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractFormComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractFormComponent, "cms-contract-form", never, {
    "config": {
      "alias": "config";
      "required": true;
      "isSignal": true;
    };
    "tradeUnit": {
      "alias": "tradeUnit";
      "required": true;
      "isSignal": true;
    };
    "facts": {
      "alias": "facts";
      "required": false;
      "isSignal": true;
    };
    "readOnly": {
      "alias": "readOnly";
      "required": false;
      "isSignal": true;
    };
    "instanceId": {
      "alias": "instanceId";
      "required": false;
      "isSignal": true;
    };
    "visibleSections": {
      "alias": "visibleSections";
      "required": false;
      "isSignal": true;
    };
    "hideEmptyFields": {
      "alias": "hideEmptyFields";
      "required": false;
      "isSignal": true;
    };
    "fieldNotes": {
      "alias": "fieldNotes";
      "required": false;
      "isSignal": true;
    };
    "pinnedNotes": {
      "alias": "pinnedNotes";
      "required": false;
      "isSignal": true;
    };
    "emptyNotes": {
      "alias": "emptyNotes";
      "required": false;
      "isSignal": true;
    };
    "sectionNotes": {
      "alias": "sectionNotes";
      "required": false;
      "isSignal": true;
    };
    "wideFields": {
      "alias": "wideFields";
      "required": false;
      "isSignal": true;
    };
    "halfFields": {
      "alias": "halfFields";
      "required": false;
      "isSignal": true;
    };
    "fieldCtrmNames": {
      "alias": "fieldCtrmNames";
      "required": false;
      "isSignal": true;
    };
    "constraints": {
      "alias": "constraints";
      "required": false;
      "isSignal": true;
    };
    "hiddenLabelFields": {
      "alias": "hiddenLabelFields";
      "required": false;
      "isSignal": true;
    };
    "groupHeadings": {
      "alias": "groupHeadings";
      "required": false;
      "isSignal": true;
    };
    "readOnlyFields": {
      "alias": "readOnlyFields";
      "required": false;
      "isSignal": true;
    };
    "lockedFields": {
      "alias": "lockedFields";
      "required": false;
      "isSignal": true;
    };
    "fieldVerdicts": {
      "alias": "fieldVerdicts";
      "required": false;
      "isSignal": true;
    };
    "initialValues": {
      "alias": "initialValues";
      "required": false;
      "isSignal": true;
    };
    "defaultValues": {
      "alias": "defaultValues";
      "required": false;
      "isSignal": true;
    };
  }, {
    "ready": "ready";
    "fieldBlur": "fieldBlur";
  }, never, never, true, never>;
}
/**
 * Per-request options that are **deliberately not part of {@link ContractListQuery}**.
 *
 * ### 🔴 Why this is a second parameter rather than a tenth query member
 *
 * `ContractListQuery` is the workspace's **addressable state** — `toRouteParams` serialises it into
 * the query string the screen writes to `history`, so every member of it is bookmarkable and travels
 * in a shared link. A cache bypass must never be either: a bookmarked `?refresh=true` would make
 * every reload of that link re-read CTRM forever, returning the grid to the ~1 s / 780 KB per
 * navigation that #71's cache was built to remove — **with nothing failing and nothing on screen to
 * say so** (#294, and GEstevez's note on it).
 *
 * Keeping it out of the query type makes that **structurally impossible** rather than a rule someone
 * has to remember. `toRouteParams` cannot serialise a field the type does not have.
 */
export interface ContractListRequestOptions {
  /**
   * Ask the server to bypass its 60-second list cache for this one request.
   *
   * 🔴 **Set it only on a deliberate user action** — the toolbar's Refresh, or Retry from a failed
   * state. Navigation, paging, sorting and filtering are exactly the traffic the cache exists to
   * serve, and sending it on those would disable the cache while appearing to work.
   *
   * Omitted means "serve me from cache if you have it", which is the right default and the only one
   * a caller gets by saying nothing.
   */
  readonly refresh?: boolean;
}
export interface ContractListSource {
  list(query: ContractListQuery, options?: ContractListRequestOptions): Observable<RemoteData<ContractListPage>>;
}
/**
 * The seam between the home grid and where its rows come from.
 *
 * `GET /api/v1/contracts` exists and works — this is not a missing endpoint. What is missing is a
 * **token**: every CTRM-backed route requires `Admin` or `User` in the `roles` claim (#36), MSAL is
 * unwired (F1.2), and the app role is not yet assigned to the developer account, so a real request
 * returns 401 today. The seam lets the grid be built and reviewed against the true response shape
 * meanwhile, exactly as `FORM_CONFIG_SOURCE` does for the contract form.
 *
 * Swapping the sample source for {@link HttpContractListSource} is one provider line in
 * `app.config.ts`; no component changes.
 */
export declare const CONTRACT_LIST_SOURCE: InjectionToken<ContractListSource>;
/**
 * The wire format for the grid's sort chain: `key:direction`, comma-separated, priority first.
 *
 * **Why a string and not an array.** `GET /api/v1/contracts` binds each parameter individually so the
 * OpenAPI document describes it (see `ContractEndpoints.GetContractsAsync`), and a repeated or indexed
 * query parameter describes badly. One ordered string keeps the priority explicit — `price:desc,
 * contractDate:asc` says which key wins — where `?sort=price&sort=contractDate` relies on parameter
 * order surviving every proxy between here and the API.
 *
 * **The keys are {@link GridColumn.key} values**, which that type already documents as "also the sort
 * key sent to the server". So the column list stays the single definition of what is sortable, and a
 * column added to the grid needs no second registration here.
 */
/**
 * Serialises a sort chain for the query string, or `undefined` when nothing is sorted.
 *
 * `undefined` rather than `''` because the two are different requests: an omitted parameter asks for
 * the server's own ordering, which `ContractListProjector` defines as newest-first. Sending an empty
 * string would ask the server to parse a sort chain with no members.
 */
export declare function toSortParam(sorts: readonly GridSort[]): string | undefined;
/**
 * Parses a sort chain back out of the wire format.
 *
 * **The application only *built* this string until 2026-08-27**, which is why this function did not
 * exist — a parser with no caller is code you cannot trust. The caller now is URL restoration: the grid
 * keeps its sort in the query string so the contract-detail breadcrumb can return the user to exactly
 * the ordering they left, so the string has to survive a round trip.
 *
 * Deliberately forgiving, because the input is a **URL** and therefore user-editable. A malformed entry
 * yields a sort on a key no column matches, and `compareBySorts` already skips unknown keys rather than
 * throwing — so a hand-mangled link degrades to "not sorted by that" instead of a broken screen.
 * Anything that is not exactly `desc` reads as ascending for the same reason.
 */
export declare function parseSortParam(sort: string | null | undefined): readonly GridSort[];
/**
 * Whether the server sorted the **whole result set** the way this screen asked it to.
 *
 * This is the honest-reporting seam, and it exists because the alternative is a silent lie. Until the
 * API gains the `sort` parameter (**issue #99**, `BACKEND`), it ignores it the way any server ignores
 * an unknown query parameter — no error, no header, nothing to notice. The grid would then send a sort,
 * receive page 1 of the server's newest-first ordering, sort those 50 rows locally, and look exactly
 * like a full-result-set sort. That is the failure mode this repo keeps rediscovering (Known Issue 18):
 * a request whose parameter goes nowhere and a response that cannot be distinguished from success.
 *
 * So the API echoes what it actually applied, and this compares it against what was asked for. An
 * absent `appliedSort` is the pre-change server and means "no, I only sorted your page"; a mismatched
 * one means the server applied a *different* chain, which must also read as no.
 *
 * @param requested What {@link toSortParam} produced for the active chain.
 * @param applied The `appliedSort` the API echoed back, if any.
 * @returns True only when a sort was asked for and the server confirms that exact chain.
 */
export declare function isServerSorted(requested: string | undefined, applied: string | null | undefined): boolean;
/**
 * **How a customer is written on screen, in one place.**
 *
 * Five render sites showed a customer before this existed — the workspace grid, the approvals grid,
 * the contract detail field list, and two on the approval detail screen — and each had written
 * `customerName ?? customerId` for itself. #328 names three of them; there are five, which is the
 * issue's own point that *"the three grids do not all take the same path today, so check each render
 * site rather than assuming one fix covers them"* turning out to be an undercount rather than a
 * caution.
 *
 * ### 🔴 What this guards, and the honest scope of it
 *
 * The Scoular GraphQL API has a **per-consumer field policy**. When a consumer is not on the
 * allow-list it does not null the field — it substitutes the **string** `[REDACTED]`, which would
 * render in a *Customer* column as though it were a company's name.
 *
 * ⚠ **That cannot reach these sites today, and this is defence in depth rather than a live defect.**
 * `GraphQlCustomerDirectory` compares each name against its own `RedactionLiteral` and returns the
 * `Redacted` verdict instead of the value, so `customerName` arrives null on a redacted row —
 * measured in the source, not assumed. The guard is here because **that check is on the far side of
 * the wire**: it belongs to one directory implementation, the read layer is migrating to GraphQL
 * (ADR-15, #240), and a future path that reads `customers` more directly would carry the literal
 * straight through. A client-side guard costs one comparison and removes the whole class.
 *
 * 🔑 **It is deliberately NOT the redaction detector.** A single `[REDACTED]` string is not evidence
 * of the policy being on — the verdict on {@link ContractListPage.customerNames} is, and it is
 * derived from a threshold precisely so one nameless customer does not cry wolf. This function only
 * refuses to *print* the literal; whether to tell the user anything is the page's decision.
 */
/**
 * Whether a value is the field policy's placeholder rather than a name.
 *
 * @param value The candidate name.
 * @returns True when it must not be printed.
 */
export declare function isRedactedName(value: string | null | undefined): boolean;
/**
 * What to show in a *Customer* cell.
 *
 * @param name The resolved customer name, or null.
 * @param id The customer id, which is always available and is the designed fallback.
 * @param absent What to render when neither is usable. Defaults to the empty string because the
 *   grids render a blank cell; the approval detail passes an em dash, which is its own convention
 *   for "no value" and is why this is a parameter rather than a constant.
 * @returns The display value.
 *
 * @remarks
 * ⚠ **Falling back to the id is correct and is not a workaround.** It is what the screen did before
 * the directory existed, and `CustomerNameAvailability.Unavailable` documents it as the designed
 * degradation: a name lookup must never be able to take the contract list down. What #328 adds is
 * that a `Redacted` verdict must not be *silent* — that is the page's notice, not this function's
 * job, and the two are deliberately separate so a page cannot satisfy the notice by mangling the
 * cell.
 */
export declare function customerDisplayName(name: string | null | undefined, id: string | null | undefined, absent?: string): string;
/**
 * The one sample id that answers `Redacted`, so the notice has something to show in the playground.
 * No sample contract carries it; it is typed into the record screen's Customer id to see the notice.
 */
export declare const SAMPLE_REDACTED_CUSTOMER_ID = "1009999";
/**
 * A stand-in for the customer lookup, for the playground and the tests: the sample's own six
 * customers resolve, one id is set aside as redacted, and everything else is `Unknown`.
 */
export declare class SampleCustomerSource implements CustomerSource {
  private readonly names;
  lookup(customerId: string): Observable<RemoteData<CustomerLookup>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleCustomerSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * What `GET /api/v1/customers/{id}` answers (F4.3b, the agreed backend contract).
 *
 * `404` never: an id the customer master does not know is `name: null` with `Unknown`. `Redacted`
 * is the GraphQL field policy refusing this application — it needs a person and does not clear on
 * retry — and the screen renders it as a notice, never as a blank, for the reason recorded on the
 * grid's customer-names verdict: a blank is indistinguishable from the gap the screen had before the
 * directory existed.
 */
export interface CustomerLookup {
  readonly customerId: string;
  readonly name: string | null;
  readonly availability: 'Resolved' | 'Redacted' | 'Unknown';
}
export interface CustomerSource {
  lookup(customerId: string): Observable<RemoteData<CustomerLookup>>;
}
/**
 * The customer lookup. The shell provides the HTTP one; the playground and the tests provide the
 * sample one. Consumers inject it **optionally** where a host may reasonably not offer a lookup.
 */
export declare const CUSTOMER_SOURCE: InjectionToken<CustomerSource>;
/**
 * The real lookup: `GET /api/v1/customers/{id}`.
 *
 * ⚠ **Wired in the shell before the route lands, deliberately.** The contract says `404` never, so
 * a `404` is the route not having been published — and it is reported as *the lookup is not
 * available*, the same as the network or the server being down, never as "no such customer". The
 * day the backend publishes the route this class starts answering with no change here.
 *
 * Answers are shared per id for the life of the source, so opening the same customer's popover
 * twice, or blurring the same id twice, asks the server once. A failure is not kept: the next
 * caller asks again.
 */
export declare class HttpCustomerSource implements CustomerSource {
  private readonly http;
  private readonly baseUrl;
  private readonly answers;
  lookup(customerId: string): Observable<RemoteData<CustomerLookup>>;
  private fetch;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpCustomerSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The workspace grid's Customer ID cell: the id, never the name (#768), plus a lookup popover that
 * carries the name (F4.3b — docs/02 §2.3's *"Customer lookup popup"*).
 *
 * **A confirmation, not a picker.** The customer master has 123,155 rows; this answers "who is
 * account 1004421" for the row under the pointer and nothing else. The directory is asked only when
 * the popover opens, once per row, so a grid of fifty rows costs zero lookups until someone asks.
 *
 * 🔴 **Redacted renders as a notice, never as a blank** — the same rule as the grid's customer-names
 * verdict, because a blank is indistinguishable from the gap the screen had before the directory
 * existed. The `[REDACTED]` literal is guarded on the client too, as defence in depth.
 *
 * ⚠ **A CDK connected overlay, not an in-cell panel.** Every grid cell is `truncate`, which is
 * `overflow: hidden`, so a panel positioned inside the cell would be clipped to one line. The
 * overlay renders in the CDK container at the end of `<body>` and is positioned against the trigger.
 *
 * ⚠ **The trigger stops the grid's own gestures.** A `<td>` selects on mousedown and a row activates
 * on double-click; a press on this button must do neither, or the popover would open over a newly
 * selected cell and a double press would navigate away mid-lookup. Enter and Space are stopped for
 * the same reason the action buttons stop them — the row treats Enter as "open".
 *
 * **Teams click-to-call is stated, not built.** No contract carries a phone number, and this row
 * says so rather than inventing a field for one.
 */
export declare class CustomerCellComponent implements GridCellComponent<ContractSummary> {
  readonly row: import("@angular/core").InputSignal<ContractSummary>;
  /**
   * The lookup, or `null` where the host provides none.
   *
   * 🔴 Optional, and the trigger is not offered without it. This cell is painted by every grid that
   * uses the shared column list — the workspace, its specs, the playground, a future embedding
   * host — and a required token here would make each of them fail to render rows until they
   * provided a lookup they may not have. No source means the cell is the text it always was.
   */
  private readonly source;
  private readonly overlay;
  /** Whether a lookup is possible at all: a source is provided and the row carries an id. */
  protected readonly canLookUp: import("@angular/core").Signal<boolean>;
  private readonly destroyRef;
  private subscription;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  /** `null` until the popover has been opened once; the directory is not asked before then. */
  protected readonly lookup: import("@angular/core").WritableSignal<RemoteData<CustomerLookup> | null>;
  /**
   * The id, always (#768, ruled 2026-10-12). The name is in this cell's hover card, and painting it
   * here would bring back a cell that changes from an id to a name between loads.
   */
  protected readonly display: import("@angular/core").Signal<string>;
  /** Repositions on scroll rather than closing, so a long grid does not shut the popover under you. */
  protected readonly scroll: import("@angular/cdk/overlay").RepositionScrollStrategy;
  /** Below the trigger, left-aligned; above it when there is no room below. */
  protected readonly positions: ConnectedPosition[];
  /** The resolved name to show, or `null` when it must not be shown as one. */
  protected nameOf(value: CustomerLookup): string | null;
  protected toggle(event: Event): void;
  protected show(): void;
  protected close(): void;
  protected stop(event: Event): void;
  protected onTriggerKeydown(event: KeyboardEvent): void;
  protected onOverlayKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<CustomerCellComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CustomerCellComponent, "cms-customer-cell", never, {
    "row": {
      "alias": "row";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * What happened to a contract, as the audit table records it.
 *
 * Mirrors the API's `AuditAction`, plus `Unknown` for anything this client does not recognise — a
 * value the server adds later must render as "not known here" rather than as a raw token.
 */
export type ContractAuditAction = 'Create' | 'Update' | 'Approve' | 'Reject' | 'StatusChange' | 'PriceCreate' | 'PriceUpdate' | 'PriceDelete' | 'PriceApprove' | 'Note' | 'EmailUpdate' | 'ConfigChange' | 'TemplateChange' | 'ReservationSwept' | 'AddendumCreate' | 'RoleChange' | 'RoleAssignmentChange' | 'AddendumTemplateChange' | 'AddendumTypeChange' | 'AddendumRemove' | 'AddendumRestore' | 'AttachmentAdd' | 'AttachmentReplace' | 'AttachmentRemove' | 'AttachmentRestore' | 'Unknown';
/**
 * Normalises whatever the wire carried into an action.
 *
 * 🔴 **`action` arrives as a NUMBER.** `AuditAction` is a C# enum and the API registers no
 * `JsonStringEnumConverter`, so `System.Text.Json` writes its numeric value. This is the same trap
 * already recorded against `ContractDetail.Origin`: declaring the field as the string union it looks
 * like it should be compiles, never throws, and quietly labels every row `Unknown`.
 *
 * ⚠ **`0` is `Create`, so this cannot be written as a falsy check.** Contract creation is the most
 * common row on any timeline and the one a reader is most often looking for; `value || 'Unknown'`
 * would hide exactly that one.
 *
 * The string form is accepted too, so registering the converter server-side later is not a breaking
 * change in this direction.
 */
export declare function auditActionOf(value: unknown): ContractAuditAction;
/**
 * The prefix the API puts on the warning that says a contract's notes could not be read.
 *
 * 🔴 **This is the only signal that a `200` with `notes: []` means "unreadable" rather than "none".**
 * The API projects a warning's `Reason` and drops the scope it was raised against, so the prefix is
 * what identifies it. Matching a prefix is a weak join and it is the strongest one available; the
 * alternative — treating an empty array as an empty history — is the data-loss path itself.
 */
export declare const NOTES_WARNING = "NotesErrorSQLCode";
/**
 * A plain-language label for an action.
 *
 * ⚠ `Unknown` reads as *"Change recorded"* rather than "Unknown": the row is real and something did
 * happen, so saying the system does not recognise its own audit code tells the user nothing they can
 * use and reads as a fault. What matters on the timeline is that a change occurred, by whom, when.
 */
export declare function describeAuditAction(action: ContractAuditAction): string;
/** One row of the contract's audit trail. Mirrors the API's `AuditEntry`. */
export interface ContractAuditEntry {
  readonly id: number;
  readonly contractNumber: string | null;
  readonly tradeUnit: string;
  readonly action: ContractAuditAction;
  readonly actorUpn: string;
  readonly timestampUtc: string;
  /** The before/after payload, as stored. Rendered only where it is present and parseable. */
  readonly detailsJson: string | null;
  readonly correlationId: string;
}
/** One field a contract write changed, keyed by CTRM field name. `null` is an empty value. */
export interface AuditFieldChange {
  readonly field: string;
  readonly from: string | null;
  readonly to: string | null;
}
/** What a contract write's audit entry says it changed (#567). */
export interface AuditChangeSummary {
  readonly changes: readonly AuditFieldChange[];
  /** Child collections the write replaced whole, by CTRM name (`ship_periods`, `notes`). */
  readonly collectionsReplaced: readonly string[];
}
/**
 * Reads the field changes out of an entry's `detailsJson` (#567).
 *
 * The shape is the API's own: `ContractEndpoints.RecordWriteAsync` writes
 * `{ changes: [{ field, from, to }], collectionsReplaced: [...], ctrmReported, ctrmDetail,
 * confirmedByReadBack }`, serialized with the web (camelCase) defaults by `ContractAuditRecorder`.
 * Price entries carry a different payload with no `changes`.
 *
 * ⚠ **Total, and `null` means "render the entry as it always was".** Absent, unparseable, not an
 * object, or carrying no usable change: all `null`. A change row with no field name is dropped. A
 * number or boolean value is shown as its text; an object or array value reads as empty rather than
 * as `[object Object]`.
 */
export declare function auditChangesOf(detailsJson: string | null): AuditChangeSummary | null;
/**
 * One note someone left on the contract's CWS log (F3.7, #912). Mirrors the API's
 * `ContractLogNoteRecord`.
 *
 * 🔴 **CWS's own record, never CTRM's.** CTRM's `notes` collection is contract text that prints with
 * the contract (#907, ruled 2026-10-17), and is not what the Log tab reads or writes.
 */
export interface ContractLogNote {
  readonly id: number;
  readonly contractNumber: string;
  readonly tradeUnit: string;
  /** As stored: the server keeps line breaks and stores CRLF as LF. */
  readonly note: string;
  readonly actorUpn: string;
  readonly createdAtUtc: string;
}
/**
 * The stored note's id an audit `Note` entry refers to, or `null`.
 *
 * The API writes a note's audit row as `{ noteId, byteCount }` and never the text, so the words come
 * only from the notes list and the timeline joins the two by this id (#912).
 */
export declare function auditNoteIdOf(detailsJson: string | null): number | null;
/** The Log tab's backend: the audit trail, the CWS log notes, and the one message it can send. */
export interface ContractLogSource {
  /** `GET /api/v1/contracts/{n}/audit`, newest first. */
  audit(contractNumber: string): Observable<RemoteData<readonly ContractAuditEntry[]>>;
  /**
   * `GET /api/v1/contracts/{n}/notes`, newest first (#912). A failed read is an error, never an
   * empty list: "nobody has left a note" is a claim a failed read cannot support.
   *
   * Optional so a host written before #912 still compiles; without it the timeline shows the audit's
   * "Note added" rows and no words.
   */
  notes?(contractNumber: string): Observable<RemoteData<readonly ContractLogNote[]>>;
  /**
   * `POST /api/v1/contracts/{n}/notes` with `{ note, clientNoteId }`, answering `201` with the stored
   * note (#912). Nothing is written to CTRM.
   *
   * `clientNoteId` is a GUID the screen makes once per note and re-sends on a retry, so a repeat
   * answers the note already stored rather than adding a second (ruled 2026-10-18). ⚠ **Sent before
   * the server reads it (#909)**: until then the server ignores the member and a repeat adds a second
   * note, so the screen re-reads the list rather than trusting a retry. Errors are re-thrown for the
   * screen to describe.
   *
   * Optional for the same reason as {@link notes}; without it the screen offers no Add Note.
   */
  addNote?(contractNumber: string, note: string, clientNoteId: string): Observable<ContractLogNote>;
  /**
   * `POST /api/v1/contracts/{n}/notify-trader`, answering `202`.
   *
   * 🔴 **`202` is acceptance, not delivery**, and the screen must say so. Every write on this estate
   * answers `202` regardless of outcome (correction C-4), so "the trader has been notified" is a
   * claim this client is in no position to make.
   *
   * `recipients` are email addresses, at least one, all on our domain (ruled on #513, 2026-09-30):
   * the contract's trader by default, plus anyone the user adds. The server refuses anything else.
   */
  notifyTrader(contractNumber: string, message: string, recipients: readonly string[]): Observable<NotifyTraderAnswer>;
}
/**
 * What the notify-trader `202` says (#847, #865).
 *
 * - `delivered: true`: the mail service took the email. Not proof that it arrived.
 * - `delivered: false`: the message was recorded and NOT sent. Every environment records only, until
 *   a mail service is switched on (#752).
 * - `null`: an API older than #847, which sent no body; nothing is known either way.
 */
export interface NotifyTraderAnswer {
  readonly delivered: boolean | null;
  readonly provider: string | null;
}
/** The one domain Notify Trader may send to (ruled on #513, GEstevez, 2026-09-30). */
export declare const SCOULAR_EMAIL_DOMAIN = "scoular.com";
/**
 * Whether an address is on our domain, checked at the control before the server refuses it.
 *
 * Case-insensitive and trimmed. ⚠ The domain must be the WHOLE host after the `@`: a suffix test would
 * pass a host that merely ends in our domain's letters, and a contains test a host that only starts
 * with it.
 */
export declare function isScoularAddress(address: string): boolean;
/**
 * The Log tab's seam.
 *
 * Injected **optionally**: a host that mounts the record screen without a log backend gets a screen
 * with no Log tab rather than an injection failure.
 */
export declare const CONTRACT_LOG_SOURCE: InjectionToken<ContractLogSource>;
/**
 * The real one, over `GET /api/v1/contracts/{n}/audit` (#559), `GET` and `POST …/notes` (#908, for
 * #912) and `POST …/notify-trader` (#847).
 *
 * ⚠ A failed read reports as "the history could not be loaded", which is emphatically not the same
 * as an empty trail.
 */
export declare class HttpContractLogSource implements ContractLogSource {
  private readonly http;
  private readonly baseUrl;
  audit(contractNumber: string): Observable<RemoteData<readonly ContractAuditEntry[]>>;
  /**
   * #912: CWS's own log notes, never CTRM's notes collection (which is contract text, #907).
   *
   * ⚠ A failed read, a bare `404` included (a deployment the route has not reached yet), is an error
   * rather than an empty list, so the screen can say the notes are missing instead of implying there
   * are none.
   */
  notes(contractNumber: string): Observable<RemoteData<readonly ContractLogNote[]>>;
  /**
   * #912: `{ note, clientNoteId }`. ⚠ The server ignores `clientNoteId` until #909 lands, silently, as
   * it does any member it does not know; the member is sent now so nothing changes here on the day it
   * does. The `201` body is the stored note. Failures are re-thrown, already parsed by the interceptor.
   */
  addNote(contractNumber: string, note: string, clientNoteId: string): Observable<ContractLogNote>;
  notifyTrader(contractNumber: string, message: string, recipients: readonly string[]): Observable<NotifyTraderAnswer>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractLogSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The sentence the close confirmation must carry, verbatim (F3.5).
 *
 * 🔴 **This is a finding, not a caution written for effect** (2026-08-28). Closing rewrites the
 * pricing-approval provenance on the contract, and re-opening does **not** put it back — so the pair
 * is not symmetric and a dialog that implied it was would be wrong about the one fact that makes this
 * irreversible. Exported as a constant so the screen and its test cannot drift apart: a test that
 * retyped the sentence would keep passing while the screen said something else.
 */
export declare const CLOSE_PROVENANCE_WARNING = "closing rewrites pricing-approval provenance and cannot be undone";
/**
 * Closes and re-opens a contract.
 *
 * 🔴 **Both answer the RE-READ contract, and that is the point of the seam.** Every CTRM write
 * answers `202` regardless of outcome (correction C-4), so completion proves nothing; the only
 * evidence a close happened is reading the contract back. The route does that server-side and returns
 * the result, so the screen renders the server's truth rather than flipping a local flag.
 */
export interface ContractStateSource {
  close(contractNumber: string): Observable<ContractDetailResponse>;
  reopen(contractNumber: string): Observable<ContractDetailResponse>;
}
/**
 * The close/re-open seam.
 *
 * Injected **optionally** by the record screen: a host that mounts the screen without a state source
 * gets a screen with no close action, rather than an injection failure. That is the same call the
 * customer lookup made, and for the same reason — an embedded host is not obliged to offer every
 * action the shell does.
 */
export declare const CONTRACT_STATE_SOURCE: InjectionToken<ContractStateSource>;
/**
 * The real one: `POST /api/v1/contracts/{n}/close` and `/reopen` (#848). Each answers `200` with
 * the contract as `GET /contracts/{n}` reads it, once the change is read back from CTRM.
 *
 * ⚠ **No body.** The contract is the number in the path; a body would be a second place to disagree
 * with it, and on this estate a field the server did not expect is not reliably inert.
 */
export declare class HttpContractStateSource implements ContractStateSource {
  private readonly http;
  private readonly baseUrl;
  close(contractNumber: string): Observable<ContractDetailResponse>;
  reopen(contractNumber: string): Observable<ContractDetailResponse>;
  /**
   * ⚠ **The number is encoded.** CTRM keys are positional and can carry a suffix; an unencoded
   * separator would address a different route and 404 rather than fail in a way anyone could read.
   */
  private post;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractStateSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A saved set of contract values, scoped to a trade unit (F3.3, BR-041).
 *
 * 🔴 **`payloadJson` arrives with the `ExcludeFromCopy` fields already removed, server-side.** This
 * client does not re-strip them and must not start: BR-041's exclusion list is CTRM-side knowledge,
 * and a second copy of it here would be a second place for it to drift — which is the failure ADR-7
 * exists to prevent. The payload is treated as opaque data to apply, not as a structure to rebuild.
 */
export interface ContractTemplate {
  readonly id: number;
  readonly tradeUnit: string;
  readonly name: string;
  readonly payloadJson: string;
  readonly createdBy: string;
  readonly createdUtc: string;
}
/**
 * The values a template carries, or an empty set when the payload cannot be read.
 *
 * 🔴 **A corrupt payload answers empty rather than throwing.** A template that applies nothing is
 * recoverable — the user picks another, or fills the form in — whereas an exception on selection takes
 * the create screen down and strands whatever they had already typed.
 */
export declare function templateValuesOf(template: ContractTemplate): Readonly<Record<string, unknown>>;
/** Reads and writes a trade unit's templates. */
export interface ContractTemplateSource {
  list(tradeUnit: string): Observable<RemoteData<readonly ContractTemplate[]>>;
  /**
   * Saves a new template.
   *
   * 🔴 **`values` must be the FULL RESOLVED field set, not the fields somebody typed.** A template
   * built from typed fields alone drops every value the form defaulted — the defect recorded on the
   * create screen, where a fix for one field turned out to generalise to forty. The caller resolves;
   * this seam just sends what it is given.
   */
  save(tradeUnit: string, name: string, values: Readonly<Record<string, unknown>>): Observable<ContractTemplate>;
  rename(id: number, tradeUnit: string, name: string, values: Readonly<Record<string, unknown>>): Observable<ContractTemplate>;
  remove(id: number): Observable<void>;
}
/** The seam. Injected optionally, so a host without templates gets a screen without the action. */
export declare const CONTRACT_TEMPLATE_SOURCE: InjectionToken<ContractTemplateSource>;
/**
 * The real one: `/api/v1/templates`.
 *
 * ⚠ **Wired before the routes land.** A failed list reports as an error rather than an empty list,
 * because "this trade unit has no templates" is a claim a 404 cannot support.
 */
export declare class HttpContractTemplateSource implements ContractTemplateSource {
  private readonly http;
  private readonly baseUrl;
  private get templatesUrl();
  list(tradeUnit: string): Observable<RemoteData<readonly ContractTemplate[]>>;
  save(tradeUnit: string, name: string, values: Readonly<Record<string, unknown>>): Observable<ContractTemplate>;
  rename(id: number, tradeUnit: string, name: string, values: Readonly<Record<string, unknown>>): Observable<ContractTemplate>;
  remove(id: number): Observable<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractTemplateSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The size limit on a contract note, and why it is a limit at all (F3.7).
 *
 * 🔴 **CTRM stores a note of any length. It is the READ that breaks, and it breaks for EVERY note on
 * the contract, not only the oversized one.**
 *
 * The write path chunks a note into 120-byte rows with no cap anywhere — a structural ceiling around
 * 12 MB. `getContract` reassembles them with `LISTAGG`, whose result type on Db2 for i is
 * `VARCHAR(4000)`: 4,000 bytes returns, 4,001 raises an overflow. That overflow aborts the multi-row
 * fetch, and the notes array is cleared *before* the SQL code is tested and never repopulated — so the
 * contract comes back with **zero** notes. The failure is reported in an HTTP response header rather
 * than the body, so the route answers `200` with a structurally valid contract that is quietly missing
 * its entire note history.
 *
 * That asymmetry is the whole reason this guard is client-side and refuses *before* sending. A save
 * that succeeded and silently emptied the note history would be discovered much later, by someone
 * looking for a note that is still in CTRM and no longer readable.
 *
 * 🔴 **The limit is in BYTES.** A `length` check passes a 4,000-character note that is 5,000 bytes on
 * the wire — em dashes pasted out of email are three bytes each — and the read then breaks for a note
 * the screen said was fine.
 */
export declare const NOTE_MAX_BYTES = 4000;
/**
 * UTF-8 byte length.
 *
 * `TextEncoder` rather than arithmetic over code points: it is the same encoding the request body
 * uses, so this measures what will actually be sent rather than a model of it.
 */
export declare function noteByteLength(note: string): number;
/**
 * How much of the budget is left, negative when the note is over.
 *
 * ⚠ **Deliberately not clamped at zero.** The screen says *by how much* a note is over, and a user
 * who has pasted three pages needs to know whether to trim a sentence or half of it. Clamping would
 * turn every overflow into the same unhelpful "0 remaining".
 */
export declare function remainingNoteBytes(note: string): number;
/**
 * Why this note cannot be saved, or `null` when it can.
 *
 * ⚠ **The copy names the consequence, not the mechanism.** A trader cannot act on `LISTAGG` or a
 * `VARCHAR(4000)` result type, but they can act on "this would hide every note on the contract" — and
 * that sentence is what stops the obvious workaround of splitting the overflow into a second note,
 * which would leave the contract just as unreadable.
 */
export declare function noteSizeRefusal(note: string): string | null;
/**
 * #912: the same limit for a CWS log note, which the notes route refuses over 4,000 UTF-8 bytes
 * (ruled 2026-10-18), worded without CTRM's consequence.
 *
 * ⚠ A log note is CWS's own row and never reaches CTRM's notes collection, so the "hides every note"
 * warning above is not true of it. That one stays for CTRM's notes, which are contract text (#907).
 */
export declare function logNoteSizeRefusal(note: string): string | null;
/**
 * One contract-text code for the contract's archetype (#907), as the PROPOSED
 * `GET /api/v1/contracts/{n}/contract-text` serves it.
 *
 * ⚠ **Proposed, not landed.** The names below are the frontend's half of the contract posted on #907
 * for GEstevez to agree. Today's API has no such route, and {@link HttpContractTextSource} reads its
 * bare `404` as "not available", so the section is simply absent.
 *
 * - `code`: the GNP527 text code, e.g. `PAYMENT`. The contract's note is stored under the answer's
 *   `prefix` (`CNTTX`) and this code.
 * - `description`: what the screen labels the field. `null` falls back to the code.
 * - `order`: GNP527's order (later the configuration's, per BR-001a).
 * - `editable`: whether CWS lets the user change it. GNP527's active flag until configuration owns it.
 * - `templateText`: the GNP528 template text, which CTRM prints when the contract carries no row.
 * - `contractText`: the contract's own GNP279 row for the code, or `null` when it has none.
 */
export interface ContractTextCode {
  readonly code: string;
  readonly description: string | null;
  readonly order: number;
  readonly editable: boolean;
  readonly templateText: string;
  readonly contractText: string | null;
}
/**
 * A contract's contract text (#907): its archetype's codes, in order, each with the template and the
 * contract's override.
 *
 * - `archetype`: `GNP271.PCLOCTYP` (BCO, FI, NAP, SG, BIO, FOG; C-18).
 * - `side`: `P` or `S`, the GNP527 key's side.
 * - `prefix`: the note prefix the codes are stored under. `CNTTX` today; carried rather than assumed.
 * - `reconfirmsOnChange`: 🔴 CTRM's own rule, `wnr051e` `$ChkCfmChg`: on BCO and FI any change to
 *   contract text re-confirms the contract (PDF reprinted, new confirmation version). The server says
 *   so, so the screen never decides it from a hard-coded archetype list.
 * - `notesReadable`: `false` when CTRM could not read the contract's notes (#331), so an override may
 *   exist that the answer cannot show. The screen then refuses editing.
 */
export interface ContractTextAnswer {
  readonly contractNumber: string;
  readonly archetype: string;
  readonly side: string;
  readonly prefix: string;
  readonly reconfirmsOnChange: boolean;
  readonly notesReadable: boolean;
  readonly codes: readonly ContractTextCode[];
}
/**
 * What a contract-text read came to.
 *
 * - `loaded`: the answer.
 * - `unavailable`: the server does not offer the route (a bare `404`, or no answer at all). 🔴 **Not an
 *   error.** Against today's API this is every read, and the record screen shows no section and no
 *   banner, exactly as before #907.
 * - `failed`: the route answered and could not complete. The section says so in place; the rest of the
 *   screen is untouched.
 */
export type ContractTextCall = {
  readonly kind: 'loaded';
  readonly value: ContractTextAnswer;
} | {
  readonly kind: 'unavailable';
} | {
  readonly kind: 'failed';
  readonly message: string;
};
/**
 * Reads a contract's contract text (#907). Optional where injected: with none, the record screen shows
 * no Contract Text section. Writing goes through the contract save's `notes` collection, not here.
 */
export interface ContractTextSource {
  load(contractNumber: string): Observable<ContractTextCall>;
}
export declare const CONTRACT_TEXT_SOURCE: InjectionToken<ContractTextSource>;
/** Said in the section when the route answered and could not complete. */
export declare const CONTRACT_TEXT_FAILED_MESSAGE = "The contract text could not be read, so it cannot be shown or changed here. The text CTRM holds is unchanged.";
/**
 * The PROPOSED `GET /api/v1/contracts/{n}/contract-text` (#907), wired now so nothing changes on the
 * screen's side when the backend half lands.
 *
 * 🔴 **It fails soft, and against today's API it always does.** The route is not mapped, and the API's
 * `/api` catch-all answers an unmatched `GET` with a bare `404` (`Program.cs`), so every read is
 * `unavailable` and the record screen shows no Contract Text section and no banner. Likewise for no
 * answer at all (`0`), a `405` or a `501`, and for a `200` whose body is not the proposed shape, which
 * is what a mis-routed request answered by something else would look like.
 *
 * A `404` that SAYS something (a problem `title` or `detail`) is the server answering about the
 * contract, so it is `failed`, not `unavailable`.
 */
export declare class HttpContractTextSource implements ContractTextSource {
  private readonly http;
  private readonly baseUrl;
  load(contractNumber: string): Observable<ContractTextCall>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractTextSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A SAMPLE archetype's contract-text codes (#907), invented for the playground: the codes are the ones
 * #907's TESTING sample carried on BCO contracts, and every template text is made up here.
 */
export declare const SAMPLE_CONTRACT_TEXT_TEMPLATES: readonly Omit<ContractTextCode, 'contractText'>[];
/**
 * The simulated half of the proposed `GET /contracts/{n}/contract-text` (#907): the sample templates
 * as a BCO contract's, each overridden by the contract's own `CNTTX` note where it has one.
 *
 * `notesOf` is how a host hands it the contract's notes, so a playground save that changes them shows
 * on the next read. With none, every code shows its template. Not injectable: provide it with
 * `useValue` or `useFactory`.
 */
export declare class SampleContractTextSource implements ContractTextSource {
  private readonly notesOf;
  constructor(notesOf?: (contractNumber: string) => readonly ContractNote[]);
  load(contractNumber: string): Observable<ContractTextCall>;
}
/**
 * Contract text as the editor holds it (#907): one text per code, keyed by the code as the answer
 * spells it.
 */
export type ContractTextValues = Readonly<Record<string, string>>;
/** The `notes` collection's row cap, from `constraints.json` (`collections.notes.maxItems`). */
export declare const CONTRACT_NOTES_MAX_ROWS = 50;
/**
 * Whether two texts are the same text. Line endings and trailing blanks are not a difference: CTRM
 * pads and a textarea answers `\n`, so an exact compare would store a row for a text the user never
 * changed, and on BCO and FI that re-confirms the contract.
 */
export declare function sameContractText(a: string | null | undefined, b: string | null | undefined): boolean;
/**
 * What each code shows before the user edits it: the contract's own text where it has a row, the
 * template's otherwise. This is what CTRM prints (`wnr051p2p`/`p2s`, `p1`).
 */
export declare function contractTextBaseline(answer: ContractTextAnswer): ContractTextValues;
/** The codes whose text differs from what the contract shows today. Only editable codes count. */
export declare function changedContractTextCodes(answer: ContractTextAnswer, baseline: ContractTextValues, values: ContractTextValues): string[];
/**
 * The `notes` collection a save sends for the user's contract-text edits, or `undefined` when nothing
 * changed (so the save sends no `notes` key and the notes are left exactly as they are).
 *
 * 🔴 **Every stored note goes back, in its order and as CTRM returned it.** Rows CWS does not manage
 * (`P/CONALTLOC`, `CUSTEMAIL`, `LMSFLAG`, an unknown code, a `CNTTX` code not in the archetype's list)
 * are never dropped, whatever upsert does with an omitted row. The API's `LmsFlagWrite` builds its rows
 * the same way.
 *
 * For each edited code, as the WNR051 screens store it:
 * - **text that differs from the template** replaces the contract's row, or adds one under
 *   `prefix` + code;
 * - **text equal to the template, or blank,** stores nothing: the contract's row, if it has one, is
 *   DELETED the only way upsert deletes a note, its code with blank text (measured on apiuat 2026-10-21,
 *   `LmsFlagWrite`). Those rows go after every other row, as the API sends its own.
 */
export declare function contractTextNotesPayload(stored: readonly ContractNote[], answer: ContractTextAnswer, baseline: ContractTextValues, values: ContractTextValues): ContractWriteNote[] | undefined;
/**
 * Why the contract text cannot be saved as it stands, or `null`. Each text is held to the 4,000-byte
 * note limit (#331: one note over it empties every note on the next read), and the collection to the
 * 50 rows `constraints.json` allows.
 */
export declare function contractTextRefusal(stored: readonly ContractNote[], answer: ContractTextAnswer, baseline: ContractTextValues, values: ContractTextValues): string | null;
/** A code's label: its description, or the code itself. */
export declare function labelOf(answer: ContractTextAnswer, code: string): string;
/**
 * The three members of a row the Edit gate reads (F4.3a, docs/02 §2.2).
 *
 * A `Pick` rather than the whole row so the rule can be exercised without composing a 27-member
 * fixture, and so a caller with only these facts — a record header, say — can ask the same question.
 */
export type EditGateFacts = Pick<ContractSummary, 'contractNumber' | 'isClosed' | 'isIntercompany'>;
/**
 * The reason a closed contract cannot be edited, as the user reads it on the button.
 *
 * ⚠ User-facing copy: no rule numbers, no issue numbers, no field names.
 */
export declare const CLOSED_REFUSAL = "This contract is closed";
/** The reason an intercompany purchase cannot be edited, as the user reads it on the button. */
export declare const INTERCOMPANY_PURCHASE_REFUSAL = "Intercompany purchase contracts are read-only";
/**
 * Whether a contract number names a purchase.
 *
 * **Position 1 of a CTRM contract number is its prefix type** — `S` sale, `P` purchase — and that is
 * CTRM's own composition (`ContractNumber.PrefixType`, `cpreft`), not a naming convention read off
 * the customer. BR-002a forbids a customer-id prefix test; this is not one.
 */
export declare function isPurchaseContract(contractNumber: string): boolean;
/**
 * Why Edit is refused for a row, or `false` when it is available.
 *
 * docs/02 §2.2: Edit is *"disabled when Closed or intercompany XM purchase"*. Returned as the string
 * `GridRowAction.disabled` expects, so the grid disables the button and shows the reason as its
 * title — the opposite call from the capability gating on the same grid, which *hides* an action.
 * Unavailable to this account is hidden; unavailable to everyone earns a reason.
 *
 * 🔴 **`isIntercompany === null` leaves Edit available.** The list route is allowed to answer "cannot
 * say", and a wrong lock blocks a trader from a contract they are entitled to edit with no way round
 * it from the screen. CTRM enforces the real intercompany-purchase write block server-side; this only
 * decides what the row offers, so it fails open. The sale/purchase half comes from the number itself.
 *
 * Closure is named first when both hold: it is the broader fact and the one the user can act on by
 * choosing a different contract rather than a different counterparty.
 */
export declare function editRefusalFor(row: EditGateFacts): string | false;
/**
 * Why Approve is refused for a row, or `false` when it is available (#841).
 *
 * docs/02 §2.2 gates Approve on *"ContractApproval + contract awaiting approval"*, and CTRM's own
 * approval queue never holds a closed contract: `getUnapprovedContracts` selects
 * `A.cgclsdt = '0001-01-01'` (`aprvapi.sqlrpgle:542`). So a closed row cannot be awaiting approval.
 *
 * ⚠ Only the closed half of "awaiting approval" is applied. Whether an open row awaits approval is
 * `traderApprovalStatus`, which is not known to be populated on the open list, so it is still not
 * gated (see `openApproval` on the workspace grid).
 */
export declare function approveRefusalFor(row: Pick<ContractSummary, 'isClosed'>): string | false;
/**
 * Why CTRM will not accept a contract number the user TYPED (F3.1d, #204): the five verdicts of
 * `checkContractNumber`, as the API classifies them.
 *
 * ⚠ **Issuance has none of these** (#666). `getNextContract` takes no input and loops until the
 * number is in neither `GNP007` nor `TMP007` (`conproc.sqlrpgle:121-162`), and the backend does not
 * send a `condition` on issuance (#623 re-scoped). An issuance failure therefore gets
 * {@link NUMBER_ISSUE_GENERIC_MESSAGE}, and a mapping for it is not kept here.
 *
 * 🔴 **`'unknown'` is not a sixth diagnosis, it is the absence of one.** It means the backend saw a
 * verdict it could not classify, and anything the screen says beyond the generic sentence is
 * invented. This is correction C-7's rule: unrecognised wording must never be read as a specific
 * outcome.
 */
export type NumberIssueCondition = 'blank' | 'inUse' | 'purged' | 'pendingHold' | 'suffixCollision' | 'unknown';
/**
 * The sentence for a failed number issuance, other than a 403 or a 503 (#666).
 *
 * CTRM's issuance has one failure, *"Unable to retreive next contract number"*
 * (`pndconapi.sqlrpgle:956`), and no classified cause, so this is the whole answer rather than a
 * fallback.
 */
export declare const NUMBER_ISSUE_GENERIC_MESSAGE = "CTRM could not issue a contract number. Type one, or try again.";
/**
 * The check's verdict, mapped onto the five conditions (#455's vocabulary).
 *
 * The API answers `conflict` with the names of `ContractNumberConflict`
 * (`ContractNumberAvailability.cs`), which classify CTRM's five `checkContractNumber` sentinels. A
 * name this client does not know, including `None` arriving with `isAvailable: false`, is `'unknown'`
 * and gets the generic sentence: an unrecognised verdict is never described as a specific cause (C-7).
 */
export declare function conditionOfConflict(conflict: string): NumberIssueCondition;
/**
 * The sentence for a typed number CTRM could not confirm free, with no classified cause.
 * ⚠ `'unknown'` resolves to exactly this string, asserted by equality.
 */
export declare const TYPED_NUMBER_GENERIC_MESSAGE = "That contract number cannot be used. Type a different number, or try again.";
/**
 * When the check itself failed, so a taken number could not be ruled out. Distinct from the generic
 * verdict: nothing was said about the number, and the save did not happen because of that.
 */
export declare const NUMBER_CHECK_FAILED_MESSAGE = "CWS could not confirm that contract number is free, so the contract was not saved. Try again.";
/**
 * #962: the same failure, said beside the field while the user is still typing. The save-time sentence
 * above would be false here ("the contract was not saved": nothing was saved or refused yet), so this
 * one says what is true and what happens next. Typing is never blocked by it.
 */
export declare const NUMBER_CHECK_UNCONFIRMED_MESSAGE = "CWS could not confirm that contract number is free. It is checked again when you save.";
/** #962: a typed number's check is in flight. */
export declare const TYPED_NUMBER_CHECKING_MESSAGE = "Checking whether that contract number is free…";
/** #962: a typed number checked free. The save-time check still runs, because a number can go in between. */
export declare const TYPED_NUMBER_AVAILABLE_MESSAGE = "That contract number is free.";
/** CTRM's contract-number width: positions 3 to 9 of the ten-position key. */
export declare const CONTRACT_NUMBER_WIDTH = 7;
/**
 * 🔴 **A typed number shorter than seven characters is refused before any request** (#770).
 *
 * CTRM holds a short number in two justifications as two different contracts, so a short number names
 * no single key, and the server refuses to create one (`CreateAddressing.RefuseShortNumber`). Refused
 * here so the user learns it at once, with the remedy, rather than from a check of one of the two.
 */
export declare const TYPED_NUMBER_SHORT_MESSAGE: string;
/** The sentence for a typed number's condition; `'unknown'` is exactly the generic one. */
export declare function messageForTypedNumberCondition(condition: NumberIssueCondition): string;
/**
 * The contract workspace's state as **query parameters**, both directions.
 *
 * ### Why the URL and not a service
 *
 * The contract-detail breadcrumb has to return the user to *exactly* the grid they left — same filters,
 * same sort, same page, same row focused (JFrisbie, 2026-08-27). A shared store would do that and
 * nothing else. Putting it in the URL also makes the workspace **linkable and refresh-proof**, which is
 * what docs/02 §1.3 already asks of every other route: `/contracts/new?tradeUnit=&customer=&template=`
 * and `/contracts/{number}?mode=edit` are both deep links, and the home screen was the one screen with
 * no addressable state.
 *
 * ⚠ **The trade unit is deliberately absent.** It belongs to the shell, not this screen (docs/02 §1.1),
 * and it survives navigation in its own store. Putting it here would create a second source of truth for
 * a value the shell owns — and the two could then disagree about which unit is active, which is exactly
 * what `TRADE_UNIT_CONTEXT` exists to prevent. The consequence to know: a workspace link pasted to
 * someone whose active trade unit differs shows *their* unit with *your* filters.
 *
 * ⚠ **`mode` must never be used here.** docs/02 §1.3 reserves it on the contract routes for
 * `edit`/`approval`, and reusing the name on the workspace would make one word mean two things.
 */
/** The `focus` parameter: which row to select and focus on arrival. */
export declare const FOCUS_PARAM = "focus";
/**
 * Serialises the workspace state for a query string.
 *
 * **Only non-default values are emitted**, which keeps the common URL clean — a trader who has filtered
 * nothing gets `/` rather than `/?status=Open&page=1`. It also means a link only pins what was
 * deliberately chosen, so a later change to a default is picked up rather than frozen into every old
 * link.
 */
export declare function toRouteParams(query: ContractListQuery, sorts: readonly GridSort[], focus?: string | null, filter?: FilterGroup): Record<string, string>;
export declare const FILTER_PARAM = "filter";
/**
 * Serialises a dynamic filter for the URL.
 *
 * **JSON in one parameter rather than a parameter per rule.** A rule set is variable-length and
 * ordered, and flattening it into `rule1col=…&rule1op=…` would be a second encoding of a shape the
 * model already defines — and one that could arrive half-parsed. One opaque value round-trips or it
 * does not.
 *
 * ⚠ Omitted entirely when nothing is filtering, so an unfiltered workspace keeps a clean URL and a
 * shared link does not carry an empty rule set that looks like a filter.
 */
export declare function filterToParam(group: FilterGroup): string | undefined;
/**
 * Reads a filter back, falling back to no filter on anything unexpected.
 *
 * 🔴 **Every field is validated, because this value is user-writable** — it is in the URL, so anyone
 * can edit it, and a shared link can be years old. A malformed value yields *no filter* rather than
 * a partial one: a filter that silently dropped half its rules would show more rows than asked for,
 * which is the direction that misleads.
 */
export declare function filterFromParam(raw: string | null): FilterGroup;
/**
 * Reads the workspace state back out of a query string.
 *
 * Every value is treated as **untrusted**, because a URL is user-editable and this is the one input to
 * the screen that a person can type. A bad status falls back to the default rather than being sent to
 * CTRM, which would answer `400` and present as a broken screen for what is really a bad link; a
 * non-numeric page becomes 1.
 *
 * `pageSize` is not read at all — it is fixed by the grid, and honouring it from the URL would let a
 * link ask for a page size the server clamps anyway (`ContractListQuery.MaxPageSize`), so the screen
 * and the response would disagree about how big a page is.
 */
export declare function fromRouteParams(params: {
  get(name: string): string | null;
}): {
  readonly query: ContractListQuery;
  readonly sorts: readonly GridSort[];
  readonly focus: string | null;
  readonly filter: FilterGroup;
};
/**
 * The real source: `GET /api/v1/contracts`.
 *
 * Written now rather than when F1.2 lands, because the response contract is already known and
 * because the query-string construction is the part with the sharp edges — an omitted parameter and
 * an empty one are different requests, and a blank `search=` is not the same as no search.
 *
 * **Only set parameters are sent.** `HttpParams` would happily serialise `commodity=` for an unset
 * filter, and `ContractListQuery.Normalized()` on the server treats whitespace as null anyway — so
 * sending the empty key is harmless but dishonest about what was asked for, and it defeats any
 * future response caching keyed on the URL.
 */
export declare class HttpContractListSource implements ContractListSource {
  private readonly http;
  private readonly baseUrl;
  list(query: ContractListQuery, options?: ContractListRequestOptions): Observable<RemoteData<ContractListPage>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractListSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The list envelope as the screens read it: the gating flags and the row-cap pair filled in below.
 * Exported for the approval queue's route (#101), which answers the same envelope.
 */
export declare function normalizeContractListPage(page: ContractListPage): ContractListPage;
/** Builds the query string, omitting anything unset. */
/**
 * The query string for `GET /contracts`, as the grid sends it.
 *
 * Exported because the export source (F4.3c) must send **the identical filter and sort** — the file
 * has to equal the screen, and two hand-written parameter builders are how a filter ends up applied
 * on one and not the other.
 */
export declare function toContractListParams(query: ContractListQuery, options?: ContractListRequestOptions): HttpParams;
/**
 * What the workspace asks the server to export (F4.3c, docs/02 §2.3 and §8).
 *
 * `query` is the grid's own query — the same object it sends to `GET /contracts`, sort included —
 * because the export must equal the screen. `fields` are the grid's column keys in the field
 * picker's order, which is what `fields=a,b,c` carries on the wire.
 */
export interface ContractExportRequest {
  readonly query: ContractListQuery;
  readonly fields: readonly string[];
}
/**
 * The three things an export can come back as, and the screen treats them differently on purpose.
 *
 * - `csv` — the stream, and the filename the server named or `null` when it named none. Also
 *   whether CTRM returned its row cap (#662), read from `X-CWS-Row-Cap-Reached` and
 *   `X-CWS-Row-Cap`. `null` means the server did not say, which is unknown, never complete.
 * - `unavailable` — the server cannot export right now: the route has not landed, the network is
 *   down, or the server is. **The in-screen export may stand in for this**, and the note says so.
 * - `refused` — the server understood the request and said no. **Nothing stands in for this**: a
 *   file built here would not be the file the server refused to produce, and falling back would
 *   paper over whatever was wrong with what the screen sent.
 */
export type ContractExportResult = {
  readonly kind: 'csv';
  readonly csv: Blob;
  readonly filename: string | null;
  readonly rowCapReached: boolean | null;
  readonly rowCap: number | null;
} | {
  readonly kind: 'unavailable';
  readonly reason: string;
} | {
  readonly kind: 'refused';
  readonly message: string;
  readonly correlationId?: string;
};
export interface ContractExportSource {
  export(request: ContractExportRequest): Observable<ContractExportResult>;
}
/**
 * The export source. The shell provides the HTTP one; the playground and the tests provide the
 * sample one. The workspace injects it **optionally**: with none provided, the export runs on the
 * screen exactly as it did before this seam existed.
 */
export declare const CONTRACT_EXPORT_SOURCE: InjectionToken<ContractExportSource>;
/**
 * The real export: `GET /api/v1/contracts/export`, a `text/csv` stream with
 * `Content-Disposition: attachment` (F4.3c, the agreed backend contract).
 *
 * 🔴 **The parameters are the list source's, built by the same function**, so a filter the grid
 * applied and the export did not cannot happen by drift. `page` and `pageSize` are removed: the
 * export is the whole result set, not a page of it. `fields` carries the grid's column keys in the
 * field picker's order.
 *
 * ⚠ **Wired in the shell before the route lands, deliberately.** A `404` is reported as
 * `unavailable`, which the screen answers by building the file itself and saying so — so the
 * export keeps working today, and the day the backend publishes the route this class starts
 * streaming without a change on this side. There is no stub to flip.
 *
 * ⚠ The filename is read from `Content-Disposition`. Cross-origin (local `ng serve` against the
 * API on another port) the browser hides that header unless the API exposes it, in which case this
 * reports `null` and the screen names the file itself. Same-origin, where the SPA is served from
 * the API's own wwwroot, it is always readable.
 */
export declare class HttpContractExportSource implements ContractExportSource {
  private readonly http;
  private readonly baseUrl;
  export(request: ContractExportRequest): Observable<ContractExportResult>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractExportSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * `X-CWS-Row-Cap-Reached` (#450, #662). The API always sends `true` or `false`.
 *
 * 🔴 **Anything else is `null`, which is unknown.** An absent header (an older server, or a browser
 * hiding an unexposed header cross-origin) must not read as `false`, because `false` is what lets
 * the screen call the file complete.
 */
export declare function rowCapReachedFrom(header: string | null): boolean | null;
/** `X-CWS-Row-Cap`: a positive whole number, or `null`. */
export declare function rowCapFrom(header: string | null): number | null;
/** The filename a `Content-Disposition` header names, or `null`. Reads the RFC 5987 form first. */
export declare function filenameFrom(disposition: string | null): string | null;
/**
 * A stand-in for `GET /api/v1/contracts/export` (F4.3c), for the playground and the tests.
 *
 * Built from **the same columns the grid renders and the same sort the grid sends**, so the file
 * equals the screen by construction — the property the real route is asked for. Every row the query
 * matches goes in, not the page the grid is on.
 *
 * ⚠ The sort is applied here explicitly because `project` does not apply `query.sort` — it orders
 * newest-first the way the projector did before the list route learned to sort — and an export that
 * ignored the sort is the 2026-08-26 defect this row must not reintroduce.
 *
 * Names no file: the screen names its exports, and a stand-in that invented a name would be one more
 * thing the real route could disagree with.
 */
export declare class SampleContractExportSource implements ContractExportSource {
  private readonly all;
  export(request: ContractExportRequest): Observable<ContractExportResult>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleContractExportSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * One CTRM location, mirroring `CtrmLocation`
 * (`src/Scoular.Contracts.Application/Reference/ReferenceItem.cs`).
 *
 * **Every CTRM location is a trade unit** — all 1044 of them, across 38 companies (correction C-15).
 * Onboarding is a configuration state that gates *writes*; it is not what makes a location a trade
 * unit, and an un-onboarded location still appears here and still shows its contracts, read-only.
 */
export interface CtrmLocation {
  readonly code: string;
  readonly name: string | null;
  readonly companyCode: string | null;
  readonly companyName: string | null;
  readonly divisionCode: string | null;
  readonly divisionName: string | null;
  /**
   * The intercompany discriminator (BR-002a). **Null against live CTRM** until CR-9 exposes
   * `GNP003.LCUST` — and absent is not the same as "not intercompany".
   */
  readonly customerId: string | null;
}
export interface LocationList {
  readonly locations: readonly CtrmLocation[];
  readonly dataOrigin: CtrmDataOrigin;
  readonly warnings: readonly string[];
}
export interface LocationSource {
  list(): Observable<RemoteData<LocationList>>;
}
export declare const LOCATION_SOURCE: InjectionToken<LocationSource>;
/**
 * `GET /api/v1/locations`.
 *
 * Loaded once and held for the session. The set is ~1044 rows and changes about as often as the
 * company structure does, so re-fetching it per screen would pay a CTRM round trip for nothing —
 * docs/03 §2.3 specifies a server-side reference cache for exactly this, which does not exist yet
 * (it is a separate, backend piece of work). Holding one copy client-side is not that cache and is
 * not a substitute for it; it just stops this screen asking twice.
 */
export declare class HttpLocationSource implements LocationSource {
  private readonly http;
  private readonly baseUrl;
  private cached;
  list(): Observable<RemoteData<LocationList>>;
  private fetch;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpLocationSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Groups locations by company for a picker.
 *
 * Keyed by **company code**, not company name, because names repeat: `22` and `42` are both
 * "SCOULAR CANADA, ULC", and several are currency variants such as `30 TSC CANADIAN DOLLARS`
 * (C-15). Grouping by name would silently merge two companies into one.
 */
export declare function groupByCompany(locations: readonly CtrmLocation[]): readonly {
  readonly code: string;
  readonly name: string;
  readonly locations: readonly CtrmLocation[];
}[];
/**
 * CTRM's origin and destination codes, searched rather than listed (#1064).
 *
 * `GET /api/v1/reference/OriginDestinationCodes` refuses a call with none of `code`, `name`, `city`
 * and `state`, and one state alone is 1,296 rows, so these codes cannot be a closed combo like the
 * `getCodes` fields. The record screen's Origin code and Destination code search it instead.
 *
 * The shell provides {@link HttpOriginDestinationSource}; the playground and the tests provide
 * {@link SampleOriginDestinationSource}, which answers with the same semantics and no more.
 */
export declare const ORIGIN_DESTINATION_SOURCE: InjectionToken<CodeSearchSource>;
/**
 * The `searchSet` a layout row names to be searched from this source. The route segment itself, so
 * the key and the route cannot be spelled two ways.
 */
export declare const ORIGIN_DESTINATION_SEARCH_SET: "OriginDestinationCodes";
/**
 * The form engine's search map, filled from {@link ORIGIN_DESTINATION_SOURCE}. A host provides both:
 * the token with its own source (HTTP in the shell, the sample in the playground), and this.
 */
export declare const CODE_SEARCH_SOURCES_PROVIDER: Provider;
/**
 * One answer from the two searches: exact-code hits first, then name hits in the server's order,
 * each code once, and at most {@link CODE_SEARCH_MAX_RESULTS}. Shared by the HTTP and sample sources
 * so the playground orders its matches the way the live screen does.
 */
export declare function mergeCodeSearchHits(byCode: readonly CodeOption[], byName: readonly CodeOption[]): readonly CodeOption[];
/**
 * The real search: `GET /api/v1/reference/OriginDestinationCodes`, twice (#1064).
 *
 * 🔴 **Two calls, because the route's parameters AND together.** Measured on apiuat through QA
 * (2026-10-22): `code` is an exact, case-insensitive match with no prefix matching, and `name` is a
 * case-insensitive "contains". One call carrying both would find only a row whose code IS the text
 * AND whose name contains it, which is almost never what was typed. So the text goes once as `code`
 * and once as `name`, and the answers are merged: the exact code first, then the name hits in the
 * server's order, without repeats, capped at {@link CODE_SEARCH_MAX_RESULTS}.
 *
 * **Fails soft.** One call failing still offers the other's rows; only both failing is an error, which
 * the combo shows as "Search unavailable" while still taking a typed code. Answers are shared per text
 * (case-insensitive) for the life of the source, and a failure is not kept, so the next search asks again.
 *
 * Provided by `provideCwsWorkspace`; never root (`no-root-provision.spec.ts`).
 */
export declare class HttpOriginDestinationSource implements CodeSearchSource {
  private readonly http;
  private readonly baseUrl;
  private readonly answers;
  search(text: string): Observable<RemoteData<readonly CodeOption[]>>;
  private fetch;
  /** One filtered call. Settles `null` on any failure, so the other call's rows can still be offered. */
  private call;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpOriginDestinationSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** Eight invented rows. No real origin or destination is named here. */
export declare const SAMPLE_ORIGIN_DESTINATION_CODES: readonly CodeOption[];
/**
 * A stand-in for the origin and destination search, for the playground and the tests (#1064).
 *
 * 🔴 **Exactly as capable as CTRM's route and no more** (Known Issue 23): a code matches only when
 * it IS the text (case-insensitive, no prefix), a name matches when it contains the text
 * (case-insensitive), and the two are merged the way {@link HttpOriginDestinationSource} merges them.
 * A sample that matched code prefixes would make the playground look better than the live screen.
 */
export declare class SampleOriginDestinationSource implements CodeSearchSource {
  search(text: string): Observable<RemoteData<readonly CodeOption[]>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleOriginDestinationSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The active trade unit as `CODE · Name`, or `null` when none is chosen.
 *
 * The same string the shell's picker shows on its trigger, so the breadcrumb and the switcher cannot
 * disagree about what you are operating on — which is the whole point of putting it in the
 * breadcrumb.
 *
 * Cheap to call from several screens at once: `HttpLocationSource` holds one copy of the ~1044
 * locations for the session, so this joins against a list that is already in memory rather than
 * issuing a request per screen.
 *
 * Falls back to the bare code when the list has not loaded or the code is not in it. The code alone
 * does not identify a location to a reader, but it is what CTRM and the contract itself show, and it
 * is better than a breadcrumb that flickers in from empty.
 */
export declare function injectTradeUnitLabel(): Signal<string | null>;
/**
 * Every CTRM location code we hold — `GNP003.LOCCOD` — for **BR-002a branch 3** (F2.3c, #423).
 *
 * Joins against the same in-memory copy {@link injectTradeUnitLabel} uses, so classifying a customer
 * costs no request: `HttpLocationSource` holds the ~1044 locations for the session.
 *
 * 🔴 **Empty while the list is loading, and the caller must not read that as "no match".** An
 * unloaded set is the absence of an answer, not a negative one — `classifyIntercompany` reports
 * `cannotClassify` for it, and BR-002's lock stays off. A screen that locked on an empty set would
 * lock every contract for as long as the fetch took.
 */
export declare function injectLocationCodes(): Signal<readonly string[]>;
/**
 * A stand-in for `GET /api/v1/contracts` until a token exists (F1.2, #36).
 *
 * **On how this differs from Known Issue 30.** The contract form's mock invented its own *content* —
 * sections, labels, orderings and dropdown lists that no document specifies, which is why that
 * screen must not be read as a field set. Nothing here is invented in that sense:
 *
 * - the **row shape** is `ContractSummary`, copied from the C# record;
 * - the **envelope** is the projection in `ContractEndpoints.GetContractsAsync`;
 * - the **value vocabulary** — commodities, locations, traders, customers, market zones, price
 *   types, payment terms, destinations, approval statuses, the `S` + commodity-initial contract
 *   number, the `-A` suffix every 11th row, 240 rows — is lifted from `CtrmSimulator`, which is what
 *   the API actually serves locally;
 * - the **filter, sort and paging semantics** mirror `ContractListProjector`, including that the
 *   status filter is *not* applied (the projector does not implement it either) and that
 *   `filteredInProcess` is always true.
 *
 * So what this shows is what the wired grid will show. What it does *not* prove is the HTTP call —
 * that needs the app role. The specific combination of values per row is generated rather than
 * captured, because the .NET `Random(20260819)` sequence cannot be reproduced in TypeScript; the
 * distribution matches, the exact rows do not.
 *
 * Exported from the public API because the shell has to name it in `app.config.ts` — the same
 * arrangement `MockFormConfigSource` has. Nothing selects it implicitly: a consumer that does not
 * provide it gets no source at all and fails at injection, which is the loud failure we want.
 */
export declare class SampleContractListSource implements ContractListSource {
  private readonly all;
  /**
   * @param query The scoped query.
   * @param _options Accepted and **deliberately ignored** — there is no cache in front of this
   *   source, so a bypass has nothing to bypass. Named with a leading underscore rather than
   *   omitted, because a narrower signature would let a caller pass `{ refresh: true }` here and be
   *   told nothing, and the point of #294 is that a bypass which silently does not happen is the
   *   defect. The parameter being visible is what says the answer is "not applicable", not "lost".
   */
  list(query: ContractListQuery, _options?: ContractListRequestOptions): Observable<RemoteData<ContractListPage>>;
  /** The loading state, for a caller that wants to see the skeleton. */
  loading(): Observable<RemoteData<ContractListPage>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleContractListSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** `ContractListProjector.Apply` — filter, then sort, then page. */
export declare function project(rows: readonly ContractSummary[], query: ContractListQuery): ContractListPage;
/**
 * `CtrmSimulator.BuildLocations()`.
 *
 * Kept whole rather than reduced to codes because it carries the two traps the trade-unit picker
 * has to survive (C-15): `divisionCode` `35` appears under three different companies, and companies
 * `22` and `42` share the name `SCOULAR CANADA, ULC`. The picker is F1.2's, but the data it will
 * group is already here.
 */
export declare const SAMPLE_LOCATIONS: readonly {
  readonly code: string;
  readonly name: string;
  readonly companyCode: string;
  readonly companyName: string;
  readonly divisionCode: string;
  readonly divisionName: string;
}[];
/**
 * The sample's customers, id and name. Exported for `SampleCustomerSource` (F4.3b), so the stand-in
 * lookup answers for exactly the customers the stand-in contracts carry.
 */
export declare const SAMPLE_CUSTOMERS: readonly (readonly [string, string])[];
/**
 * Builds the 240-row set, mirroring `CtrmSimulator.BuildContract`.
 *
 * `today` is a parameter rather than a call to the clock for the same reason the simulator takes one:
 * a data set that depends on the wall clock makes every assertion about it time-dependent.
 */
export declare function buildContracts(today?: Date): readonly ContractSummary[];
/**
 * `1,234` for a quantity, blank for null — **exported so the approvals and pricing grids share this
 * one decision** rather than each configuring its own `Intl.NumberFormat`.
 *
 * A second copy would drift on `maximumFractionDigits`, and the visible result would be the same
 * contract quantity rendered `1,875,000` on one screen and `1,875,000.00` on another, which reads as
 * two different numbers.
 *
 * ⚠ **Blank rather than `0`.** A null quantity is *unknown*, and CTRM stores real zeros; rendering
 * both as `0` makes an unquantified contract indistinguishable from an empty one.
 */
export declare function formatQuantity(value: number | null | undefined): string;
/**
 * `4.2350` for a price, blank for null. Exported for the same reason as {@link formatQuantity}.
 *
 * ⚠ **Blank rather than `0.0000`.** An unpriced BASIS contract has no price, and `0.0000` is a lie
 * about it — the home grid's own price column records this and the pricing queue is made entirely of
 * unpriced contracts, so it matters more there than anywhere.
 */
export declare function formatPrice(value: number | null | undefined): string;
/**
 * `21 Aug 2026`.
 *
 * Explicitly not a numeric date: `08/21/2026` and `21/08/2026` are indistinguishable for the first
 * twelve days of any month, and this grid is read by people in the US and Canada.
 *
 * Parsed by splitting the string rather than by `new Date(iso)`. An ISO `yyyy-MM-dd` from a .NET
 * `DateOnly` carries no timezone; `new Date` would read it as UTC midnight and then render it in
 * local time, moving the date a day earlier everywhere west of Greenwich — including every Scoular
 * office.
 */
export declare function formatContractDate(iso: string | null): string;
/**
 * `9/12/25` — short numeric date for the grid (JFrisbie, 2026-08-25).
 *
 * ⚠ **This reverses a documented decision and the objection has not gone away.** The long form above
 * exists because `08/21/2026` and `21/08/2026` are indistinguishable for the first twelve days of any
 * month, and this grid is read in both the US and Canada. A numeric date is genuinely ambiguous to
 * some of its readers.
 *
 * Two things keep that cost bounded rather than removing it: the column's `tooltip` carries the
 * unambiguous `21 Aug 2026` form, so the information is one hover away rather than gone; and
 * `formatContractDate` is retained and still exported, because the detail view (F4.1c) has room for
 * the unambiguous form and should use it. **The compact form is a grid-density decision, not a
 * project-wide date format** — do not propagate it to screens that are not width-constrained.
 *
 * Parsed by splitting the string for the same reason as the long form: `new Date(iso)` on a
 * timezone-less `yyyy-MM-dd` reads it as UTC midnight and renders it a day earlier everywhere west of
 * Greenwich, which is every Scoular office.
 */
export declare function formatShortDate(iso: string | null): string;
/** `1 Sep 2026 – 30 Sep 2026`, or one date, or blank. */
export declare function formatShipPeriod(row: ContractSummary): string;
/**
 * A CTRM contract status as a coloured pill — the one mapping every screen shares.
 *
 * **Extracted and exported 2026-08-27 for the contract detail view**, which shows all three statuses
 * (trader approval, customer confirmation and broker confirmation) and must not disagree with the grid
 * about what a rejection looks like. A duplicated colour table is how a status ends up green on one
 * screen and grey on another, and this is the second consumer — the point at which the standards say to
 * centralise.
 *
 * The union of both vocabularies maps cleanly, which is what makes one function correct rather than
 * merely convenient: `approved`/`confirmed` are the same answer, `unapproved`/`pending` are the same
 * answer, and no value means one thing on one field and something else on another.
 *
 * ⚠ **Anything unrecognised is `neutral`**, deliberately, and that rule is load-bearing. The simulator
 * emits `Approved`, `Unapproved`, `Rejected`, `Confirmed` and `Pending`; **live CTRM's full domain for
 * these fields has never been enumerated** (docs/04a lists the fields, not their values). So a value we
 * have not seen renders as a plain grey pill. Guessing green for an unknown status is the dangerous
 * direction — it would tell a trader a contract is approved on no evidence.
 *
 * Blank returns `null`, which callers render as *no pill* rather than an empty one. An empty pill reads
 * as a status; no pill reads as no status, which is the truth.
 */
export declare function contractStatusBadge(status: string | null | undefined): GridBadge | null;
/**
 * Tints a row that needs a trader's attention.
 *
 * Only two states earn a tint, and only where the row is genuinely actionable — a grid where most
 * rows are coloured communicates nothing. `Rejected` is the one that costs money to miss, so it gets
 * the stronger tone.
 *
 * The tint never carries meaning on its own: the Approval column shows the same status as a labelled
 * pill in the same row, so the information survives for a colour-blind reader (02a §4).
 */
export declare function contractRowTone(row: ContractSummary): GridRowTone | null;
/**
 * Widths are starting points, not settings.
 *
 * Every column is now drag-resizable and the table is `table-fixed`, so a column no longer sizes
 * itself to its content — these numbers are what a user sees before touching anything. Chosen from
 * the widest realistic value rather than the widest possible one: `advising_bank_description` is
 * `varchar(32000)` and sizing for that would leave every other column unreadable, so long text
 * truncates and its full form is in the cell's `title`.
 *
 * 🔴 **These headers and formatters are pinned by a CSV golden shared with the server export**
 * (#445): `docs/fixtures/contract-export/expected.csv`, asserted here by
 * `contract-grid.columns.golden.spec.ts` and on the server by `ContractCsvGoldenTests`. A change to
 * a header, a formatter or the column order means regenerating the golden by running
 * `toCsv(CONTRACT_GRID_COLUMNS, rows)` over `rows.json`, and the server's `ContractCsv` must follow
 * it in the same PR, or the "All pages" and "This page" exports stop agreeing.
 */
export declare const CONTRACT_GRID_COLUMNS: readonly GridColumn<ContractSummary>[];
/**
 * The `Confirmed` column, defined but not currently shown — see the note above.
 *
 * Exported so it is reachable when F1.3's column configuration arrives, and so the tests that cover
 * `confirmBadge` exercise a real column rather than a fixture.
 */
export declare const CONFIRMED_COLUMN: GridColumn<ContractSummary>;
/**
 * Customer name, as an EXPORT field only (#768, ruled 2026-10-12). Never a grid column: on the grid
 * the name is in the Customer cell's hover card and in the search, so the cell never changes from an
 * id to a name in front of the user. The file carries it beside the id, as the server's CSV does
 * (#767).
 */
export declare const CUSTOMER_NAME_EXPORT_COLUMN: GridColumn<ContractSummary>;
/**
 * What the export offers: the grid's columns with {@link CUSTOMER_NAME_EXPORT_COLUMN} directly after
 * Customer ID (#768), in the server CSV's order.
 *
 * 🔴 **Pinned by the shared CSV golden**, as {@link CONTRACT_GRID_COLUMNS} is: `toCsv` over this list
 * and `rows.json` must equal `docs/fixtures/contract-export/expected.csv`, which the server's
 * `ContractCsvGoldenTests` asserts too.
 */
export declare const CONTRACT_EXPORT_COLUMNS: readonly GridColumn<ContractSummary>[];
/**
 * One price sequence as `GET /api/v1/pricing/{contract}/prices` returns it.
 *
 * 🔴 **BR-054's settlement dimension is the reason this route exists rather than reading the contract
 * aggregate.** Priced, open, applied, unsettled and settled quantities — and the three load figures —
 * arrive only here, and docs/02 §5.2 and §5.3 both specify grids that show them.
 *
 * ⚠ **Every member is declared.** Three computed quantities were fetched by the API and absent from
 * the SPA's interface for a whole session, so they deserialised to `undefined` and rendered blank with
 * nothing looking wrong — the drop-on-our-side class, one layer out from the server. A field that is
 * on the wire and not in this interface is invisible rather than broken.
 */
export interface PriceSequence {
  readonly priceSequence: number;
  readonly price: number;
  readonly basisPrice: number;
  readonly adjustments: number;
  readonly priceCurrency: string | null;
  readonly priceCurrencyDescription: string | null;
  readonly priceUom: string | null;
  readonly priceUomDescription: string | null;
  readonly pricedQuantityUom: string | null;
  readonly pricedQuantityUomDescription: string | null;
  readonly pricedQuantity: number;
  readonly openQuantity: number;
  readonly appliedQuantity: number;
  readonly unsettledQuantity: number;
  readonly settledQuantity: number;
  readonly pricedLoads: number;
  readonly appliedLoads: number;
  readonly settledLoads: number;
  readonly priceDescription: string | null;
  readonly remark: string | null;
  readonly hedgePrice: number;
  readonly hedgePriceUom: string | null;
  readonly hedgePriceUomDescription: string | null;
  readonly hedgeMarketCode: string | null;
  readonly hedgeMarketCodeDescription: string | null;
  readonly hedgeMarketMonth: string | null;
  readonly hedgeMarketMonthDescription: string | null;
  readonly traderInitials: string | null;
  readonly trader: string | null;
  readonly customerMerchant: string | null;
  readonly priceDate: string | null;
  readonly approverInitials: string | null;
  readonly approver: string | null;
  readonly approvalTimestamp: string | null;
  readonly isApproved: boolean;
  readonly printFlag: string | null;
}
/** A sequence as the screen submits it — BR-051's field set. */
export interface PriceSequenceEdit {
  readonly priceSequence: number;
  readonly pricedQuantity?: number | null;
  readonly pricedLoads?: number | null;
  readonly hedgePrice?: number | null;
  readonly basisPrice?: number | null;
  readonly price?: number | null;
  readonly hedgeMarketCode?: string | null;
  readonly hedgeMarketMonthCode?: string | null;
  readonly priceDate?: string | null;
  readonly remark?: string | null;
  readonly description?: string | null;
  readonly printFlag?: string | null;
}
/**
 * What a pricing write returns.
 *
 * 🔴 **`prices` is the state CTRM holds afterwards, and `verified` says whether we could read it.**
 * Neither is inferred from the acknowledgement: every pricing write answers `202 Success` whatever it
 * did, and a delete that removed a row is byte-comparable with one that removed nothing. The screen
 * must render `prices` rather than mutating its own copy, which is the whole of #156.
 *
 * ⚠ `verified: false` means **the write was accepted and the read-back failed** — never that the write
 * failed. Telling a user their save failed when it did not invites them to repeat it.
 */
export interface PricingWriteResult {
  readonly contract: string;
  readonly acknowledgement: string | null;
  readonly verified: boolean;
  readonly prices: readonly PriceSequence[];
  readonly warnings?: readonly string[];
}
/** One contract's sequences. */
export interface ContractPrices {
  readonly contract: string;
  readonly prices: readonly PriceSequence[];
  readonly warnings?: readonly string[];
}
/**
 * The pricing approval queue — docs/02 §5.3.
 *
 * ⚠ `mayBeTruncated` is CTRM's `Dim(2000)` ceiling reported honestly rather than hidden. The route has
 * no server-side paging and reports no truncation, so a full queue is short without saying so — CR-4's
 * class of silent short read, on a different route.
 */
export interface UnapprovedPrices {
  readonly prices: readonly PriceSequence[];
  readonly count: number;
  readonly truncationCeiling: number;
  readonly mayBeTruncated: boolean;
  readonly warnings?: readonly string[];
}
/** Whose queue to read. At least one of trader or location is required. */
export interface UnapprovedPricesQuery {
  readonly traderInitials?: string;
  readonly location?: string;
  readonly approverType?: string;
}
/**
 * The seam between the pricing screens and CTRM's pricing API.
 *
 * ⚠ **Every write returns {@link PricingWriteResult}, not an acknowledgement, and that is the contract
 * rather than a convenience.** A pricing write cannot report its own outcome — `202 Success` on both a
 * success and a no-op, with a populated title on both — so the API re-reads and returns what CTRM now
 * holds. A source shape that returned `void` or a boolean would let a caller update its own copy from
 * what it *sent*, which is the defect #156 exists to prevent.
 */
export interface PricingSource {
  /** One contract's sequences, with BR-054's settlement dimension. */
  contractPrices(contract: string): Observable<RemoteData<ContractPrices>>;
  /** The cross-contract approval queue — docs/02 §5.3. */
  unapproved(query: UnapprovedPricesQuery): Observable<RemoteData<UnapprovedPrices>>;
  /** Creates or replaces sequences, and reports what CTRM holds afterwards. */
  save(contract: string, sequences: readonly PriceSequenceEdit[]): Observable<RemoteData<PricingWriteResult>>;
  /** Removes one sequence and reports the survivors. */
  remove(contract: string, priceSequence: number): Observable<RemoteData<PricingWriteResult>>;
  /** Approves sequences (BR-052). ⚠ Approval has no inverse. */
  approve(contract: string, priceSequences: readonly number[]): Observable<RemoteData<PricingWriteResult>>;
}
/**
 * Injected rather than constructed, so the screens can be rendered against a stub in tests and against
 * the real API everywhere else — the same arrangement `CONTRACT_LIST_SOURCE` uses.
 */
export declare const PRICING_SOURCE: InjectionToken<PricingSource>;
/**
 * The two **parameterised** reference lookups the market cascade needs — #201.
 *
 * ### Why this is not part of the form-config bundle
 *
 * `HttpFormConfigSource` fetches its reference sets once per form resolution, keyed on the trade unit.
 * These two cannot work that way: the market code depends on the **contract's** location and
 * commodity, and the month list depends on the market code the first lookup returns. They change as
 * the user types, so they are fetched reactively rather than bundled.
 *
 * ### ⚠ Why it lives in `@cws/domain-contracts` rather than in either feature
 *
 * Both pricing surfaces consume it — the contract record screen in `@cws/features-contract-summary`
 * and the editor in `@cws/features-pricing` — and a feature library importing another feature's barrel
 * is what put 264 kB of page components into `main` (#252). Anything two features share belongs down
 * here, which is the rule that issue left behind.
 *
 * ### 🔴 Three states, and `null` is the one that matters
 *
 * | | |
 * |---|---|
 * | `null` | the fetch is in flight |
 * | `[]` | settled, and the Grain Factors file has no row |
 * | rows | settled |
 *
 * Collapsing `null` to `[]` would run the whole cascade on data that has not arrived — deriving a
 * blank market code, mirroring that blank onto the hedge code and clearing the hedge month, on every
 * single form load. That is the same three-state distinction `referenceSet` draws for the code combos
 * (#219 criterion 7), and it is load-bearing here for a different reason: there it produced a wrong
 * *control*, and here it would produce a wrong *value*.
 */
export interface MarketReferenceSource {
  /**
   * The market codes for a location and commodity — `reference/MarketCodes`.
   *
   * ⚠ **Live returns exactly ONE row** (`location=2087&commodityCode=YC` → `C`, verified through the
   * endpoint 2026-09-09, PR #218). It is a lookup, not a pick-list: the cascade takes the first row as
   * the Grain Factors market, because that is what `FHMARK` is.
   */
  marketCodes(location: string, commodityCode: string): Observable<readonly AllowedValue[] | null>;
  /**
   * The months valid for that market — `reference/MarketMonths`.
   *
   * ⚠ **Four parameters, and `marketCode` is the one that does the work.** Omitting it returns zero
   * rows, which would render as a combo with no options — the closed list of nothing #219 forbids.
   */
  marketMonths(location: string, commodityCode: string, marketCode: string): Observable<readonly AllowedValue[] | null>;
}
export declare const MARKET_REFERENCE_SOURCE: InjectionToken<MarketReferenceSource>;
/**
 * The live implementation.
 *
 * ⚠ **Parameter names are transcribed from `ReferenceSet.cs`, not derived from the method names**, and
 * the casing is not consistent: `commodityCode`, `marketCode` and `languageCode` are camelCase while
 * `location` is one lower-case word. Known Issue 18 applies — CTRM ignores a name it does not
 * recognise rather than refusing it, so a wrong spelling returns an **unfiltered** list with a `200`
 * and nothing anywhere says so.
 *
 * Provided by `provideCwsWorkspace` (and by any host composing this screen); never root — see
 * `no-root-provision.spec.ts`.
 */
export declare class HttpMarketReferenceSource implements MarketReferenceSource {
  private readonly http;
  private readonly baseUrl;
  private readonly tradeUnitValues;
  /**
   * One replayed stream per distinct parameter set, for the session.
   *
   * Keyed on the whole query rather than on the set, because unlike the code tables these answers
   * differ per contract — a shared key would hand one commodity's months to another.
   */
  private readonly cache;
  marketCodes(location: string, commodityCode: string): Observable<readonly AllowedValue[] | null>;
  marketMonths(location: string, commodityCode: string, marketCode: string): Observable<readonly AllowedValue[] | null>;
  /**
   * The trade unit's configured months for this commodity, as narrowing rows.
   *
   * Always settles, and settles empty on any failure — see the rule above.
   */
  private configuredMonths;
  /**
   * ⚠ **`set` is a `ReferenceRoute`, not a `string`, and that is the fix for #481 rather than the
   * two corrected call sites above.** Typed as `string` this method accepted CTRM's kebab-case
   * segment, which the API refuses with a bare `400` that `catchError` below turns into an empty
   * list — so the wrong spelling produced an empty dropdown and no error anywhere.
   */
  private fetch;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpMarketReferenceSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The real source — `/api/v1/pricing/*`.
 *
 * 🔴 **A 404 from the delete is a legitimate answer, not a failure**, and it carries a body worth
 * keeping. The API pre-reads and returns `404` with the surviving sequences when the sequence is
 * already gone, which is the ordinary double-click case; treating it as an error would throw away the
 * survivors the screen needs to correct itself, and would show a fault banner for a state the user can
 * simply see. It is surfaced as a *loaded* result whose `verified` is true and whose `prices` are the
 * survivors, with the acknowledgement saying what happened.
 */
export declare class HttpPricingSource implements PricingSource {
  private readonly http;
  private readonly baseUrl;
  contractPrices(contract: string): Observable<RemoteData<ContractPrices>>;
  unapproved(query: UnapprovedPricesQuery): Observable<RemoteData<UnapprovedPrices>>;
  save(contract: string, sequences: readonly PriceSequenceEdit[]): Observable<RemoteData<PricingWriteResult>>;
  remove(contract: string, priceSequence: number): Observable<RemoteData<PricingWriteResult>>;
  approve(contract: string, priceSequences: readonly number[]): Observable<RemoteData<PricingWriteResult>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpPricingSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **BR-050 — Flat Price = Basis + Adjustments + Futures (hedge).**
 *
 * Pure and separate from the form so the arithmetic is testable without rendering anything, and so the
 * grid and the editor cannot disagree about what a flat price is.
 *
 * 🔴 **This is shown live while the user types, and it is NOT sent as the authority.** CTRM computes
 * the stored price itself, so what the screen displays is a preview of what CTRM will arrive at. If
 * the two ever disagree the discrepancy is CTRM's to settle — presenting our arithmetic as the answer
 * would be the `*_description` mistake in a new place, where a derived value we compute overwrites the
 * one the system of record derives.
 *
 * ⚠ **Adjustments are read-only and arrive on the sequence.** There is no adjustment control in
 * docs/02 §5.2's field list, and `grade_adj` — which BR-003/BR-004 reference — does not exist in CTRM
 * as a scalar at all; it is an `adj_calculator_lines` collection. So the term is carried through from
 * what CTRM returned rather than entered, and a create with no existing sequence has none.
 */
export interface FlatPriceTerms {
  readonly basisPrice?: number | null;
  readonly adjustments?: number | null;
  readonly hedgePrice?: number | null;
}
/**
 * Adds the three terms.
 *
 * ⚠ **A missing term is zero, and a missing term is not the same as a zero the user typed** — but for
 * this sum they behave identically, which is why this returns a number rather than null-propagating.
 * What it must never do is return `null` because one term is absent: BR-050 is a sum, and a basis with
 * no hedge yet is a legitimate half-filled state whose running total is still meaningful.
 */
export declare function flatPrice(terms: FlatPriceTerms): number;
/**
 * Whether the computed flat price differs from the one CTRM stored.
 *
 * 🔑 **Compared at a tolerance rather than exactly.** Prices are `Packed(11,5)` in CTRM and IEEE
 * doubles in the browser, so `4.1 + 0.2` is not `4.3` and an exact comparison would flag a
 * disagreement on almost every sequence. The tolerance is a hundredth of the smallest unit CTRM
 * stores, so a real divergence is still caught.
 */
export declare function flatPriceAgrees(computed: number, stored: number): boolean;
/**
 * What became of one copied price sequence (#459, F3.4; ruled 2026-10-07).
 *
 * 🔴 **Three outcomes, not two.** `unconfirmed` is the one this estate forces: the post was accepted
 * (or answered in a way that could not be used) and the read-back did not find a new UNAPPROVED
 * sequence. It is not a refusal, and reporting it as one would send the user to re-add a sequence
 * that may already exist, producing a duplicate. Every CTRM write answers `202` whatever it did
 * (C-4), and `upsertPrices` answers `202 Success` for a request it did not process (Known Issue 33),
 * so only the read-back says what happened.
 */
export type PriceCopyOutcome = 'copied' | 'not-copied' | 'unconfirmed';
export interface PriceCopyRow {
  /** The sequence on the contract it was copied from. */
  readonly source: PriceSequence;
  readonly outcome: PriceCopyOutcome | 'pending';
  /** The sequence number CTRM gave it on the new contract, when it was found. */
  readonly newSequence: number | null;
  /** Why it is not `copied`, in words a user can act on. */
  readonly reason: string | null;
  /**
   * The server's reference for a row that was `not-copied` (#803, docs/02 §9), for quoting to
   * support. Absent where nothing was sent, or the server returned none.
   */
  readonly correlationId?: string | null;
}
export interface PriceCopyRun {
  /** The new contract the prices were posted to. */
  readonly target: string;
  readonly rows: readonly PriceCopyRow[];
  readonly done: boolean;
}
/**
 * A source sequence as a NEW sequence on another contract: `priceSequence: 0`, so CTRM assigns the
 * number, and BR-051's field set only. Approval is never carried: a copied price is UNAPPROVED and
 * goes through approval like any other (the reason this row exists).
 */
export declare function editFromSequence(sequence: PriceSequence): PriceSequenceEdit;
/**
 * Posts each source sequence to `target`, **one at a time**, reading each back before the next.
 *
 * Emits the run as it goes: every row `pending` first, then each outcome as it is settled, ending
 * with `done: true`. It never errors; a failure is an outcome on its row.
 *
 * - **Sequential, not parallel.** CTRM numbers the sequences in the order they arrive, so concurrent
 *   posts would make the copy's order depend on scheduling.
 * - **No retry.** A row that is not copied is left for the user ("retry the ones not copied" is a
 *   second, explicit action); a retry after an unconfirmed post could duplicate a price.
 * - **Nothing is posted if the new contract's prices cannot be read first**, because the read-back
 *   compares against them: without a "before", an existing sequence would be counted as copied.
 */
export declare function copyPriceSequences(pricing: PricingSource, target: string, sources: readonly PriceSequence[]): Observable<PriceCopyRun>;
/**
 * What the approval screen needs to know about a contract.
 *
 * ⚠ **Deliberately the grid's own row type and nothing more.** The approver is deciding on terms
 * they can already see in the queue — customer, commodity, quantity, price — and the legacy Contract
 * Portal screen this replaces shows **no field grid at all**: the contract *is* the PDF. Rendering
 * all 111 fields here would be a second contract record screen to keep in step with the first, and
 * `/contracts/{number}` already is that screen.
 */
export interface ApprovalContract {
  readonly header: ContractSummary;
  /** `Simulated` means the rows were generated locally. Rendered, never swallowed. */
  readonly dataOrigin: 'Live' | 'Simulated';
  /** CTRM's own caveats about this read, surfaced rather than dropped. */
  readonly warnings: readonly string[];
}
/** Reads the one contract an approver is looking at. */
export interface ApprovalContractSource {
  get(contractNumber: string): Observable<RemoteData<ApprovalContract>>;
}
/**
 * The approval screen's contract read.
 *
 * ### Why this is a second token rather than `CONTRACT_DETAIL_SOURCE`
 *
 * It used to be packaging: that token and its model lived in `@cws/features-contract-summary`, and
 * importing one feature library from another is what puts a whole feature into the initial bundle
 * (#252). That reason is SPENT - both seams live here now, and `app.config` imports one barrel.
 *
 * What keeps them apart today is the MODEL. This projects the few fields the screen renders;
 * `ContractDetailResponse` carries the whole 111-field aggregate. Collapsing them makes the
 * approval screen pay for the full read, which is a decision about that screen rather than a
 * tidy-up - so it is deliberately still two tokens over one endpoint.
 */
export declare const APPROVAL_CONTRACT_SOURCE: InjectionToken<ApprovalContractSource>;
/**
 * The real source: `GET /api/v1/contracts/{number}`.
 *
 * The number goes in the **path**, so it is percent-encoded rather than concatenated — CR-11
 * established that CTRM keys with leading spaces exist, and a raw `/` or `#` in a path segment would
 * silently address a different route.
 */
export declare class HttpApprovalContractSource implements ApprovalContractSource {
  private readonly http;
  private readonly baseUrl;
  get(contractNumber: string): Observable<RemoteData<ApprovalContract>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpApprovalContractSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Approving and rejecting a contract.
 *
 * ### 🔴 Read this before wiring the live implementation, because the blocker is not in this file
 *
 * There is **no path from this application to CTRM's approval status today**, and both halves were
 * checked against the authorities rather than taken from a session log:
 *
 * 1. **The approval API cannot be called.** `approveContracts` has never succeeded through any
 *    transport — the origin answers `500` with a Java `OutOfMemoryError` in
 *    `ApproveContracts.processOutputParam4`, while building its *output* parameters, so no request
 *    shape gets past it ([#108](https://scoular.ghe.com/IT/contract-management-system/issues/108)).
 *    The BFF publishes no approval route either.
 * 2. **The contract upsert cannot set it.** The obvious workaround is to write
 *    `trader_approval_status` through `PUT /contracts/{n}`, which is a proven path — and
 *    `constraints.json`, generated from CTRM's copybooks, declares it
 *    `{ "access": "readOnly", "type": "string", "maxLength": 10 }`. CTRM **refuses** read-only
 *    fields on a write rather than ignoring them, so that route turns a good save into a rejection.
 *
 * So this token exists to make the frontend complete and the contract explicit: the screen, the
 * buttons, the rejection reason, the per-row state and the error handling are all real, and the day
 * an endpoint exists this is a one-line provider swap in `app.config.ts`.
 *
 * ### ⚠ Why the default is SIMULATED and not a stub that pretends
 *
 * {@link SimulatedApprovalActionSource} is the default, mirroring `Ctrm:Clients:ContractWrites`,
 * which has shipped defaulting to `Simulated` since the write path was built — the simulator runs
 * the real logic and only the HTTP call is absent.
 *
 * 🔴 **What it must never do is report a plain success.** Every result carries
 * {@link ApprovalActionResult.origin}, the screen renders `Simulated` prominently, and the queue
 * says so above the grid. An approval falsely reported as done is the worst outcome available on
 * this screen: the contract stays unapproved in CTRM while the person responsible for approving it
 * has been told it is finished, and nothing downstream would contradict them. That is this
 * project's own recurring lesson — CTRM answers `202` to writes it did not perform, and the rule
 * that came out of it is to verify by reading the data back, never to infer success.
 */
/** What an approver decided. */
export type ApprovalDecision = 'Approved' | 'Rejected';
/** Where an approval outcome came from — the same distinction the grid's rows carry. */
export type ApprovalOrigin = 'Live' | 'Simulated';
export interface ApprovalActionResult {
  readonly contractNumber: string;
  readonly decision: ApprovalDecision;
  /** `Simulated` means CTRM was never asked. Rendered, never swallowed. */
  readonly origin: ApprovalOrigin;
  /** The status the row should now show — CTRM's own wording where it answered. */
  readonly status: string;
  readonly detail: string;
}
/**
 * The ECM half of an approval (F6.2, docs/02 §4.2), in CTRM's own member names.
 *
 * 🔴 **#492 governs (GEstevez, 2026-09-28; shape agreed on #469, 2026-10-06): CWS never lets CTRM
 * choose the recipients or the e-sign decision.** An empty `distribution_entry` makes `APRVUPS`
 * load its own lists (ECM, the customer's `CUSTEMAIL` note, deal ticket, MA, QA, printers), and a
 * supplied one replaces them. So the payload is **required** on every approve and never empty.
 *
 * 🔴 **At most FOUR recipients**, refused at the control before sending. The production
 * `distribution_entry` carries four, and an approval is the write with the least tolerance for a
 * silent partial success on this estate. The BFF maps each address to TSCQA's `distribution` array.
 */
export interface ApprovalEcmRequest {
  /** One to four recipient addresses. Never empty, never omitted. */
  readonly distribution_entry: readonly string[];
  /** At least 1: CTRM rewrites 0 to 1, so 0 is never sent. */
  readonly copies: number;
  /** The email's body text (`Char(32000)`), not a flag. An empty string is allowed. */
  readonly email_message: string;
  /** From ECM's e-sign routing via {@link ApprovalActionSource.ecmRouting}. Never a user control. */
  readonly esign: boolean;
  /**
   * An `ESOVR` reason code, or `null` for no override.
   *
   * ⚠ **Any non-blank value skips e-sign** (`spOverrideEsign`) and is logged as *"E-Sign override:
   * <value>"*, so a placeholder such as the Power App's `"N"` overrides every approval. Always `null`
   * until #492's open questions on `CAPFLG3` and the `ESOVR` list are answered.
   */
  readonly esign_override: string | null;
}
/** The most recipients an approval carries. */
export declare const MAX_ECM_RECIPIENTS = 4;
/**
 * What ECM's routing says about this contract's customer (#492): whether it is set up for
 * e-signature, and who receives the approved contract.
 *
 * 🔴 **`esign: null` means UNKNOWN, and it refuses the approve.** ECM answers an unmatched trader
 * with a `200` and blank fields, which reads exactly like "not set up". Rule 2 of this repo: an
 * absence must never be read as a decision, least of all on the step that emails customers.
 */
export interface ApprovalEcmRouting {
  /** `true` e-sign, `false` not set up, `null` could not be established. */
  readonly esign: boolean | null;
  /** The routing's recipients: locked when `esign` is true, a starting list when it is false. */
  readonly recipients: readonly string[];
  readonly origin: ApprovalOrigin;
  /** Why `esign` is `null`, for the screen to say. */
  readonly reason?: string;
}
export interface ApprovalActionSource {
  /** ECM's e-sign status and routing for this contract. Fails soft to `esign: null`, never throws. */
  ecmRouting(contractNumber: string): Observable<ApprovalEcmRouting>;
  /**
   * @param ecm The distribution. **Required**: an approve without one would let CTRM choose who
   *   receives the contract (#492).
   */
  approve(contractNumber: string, ecm: ApprovalEcmRequest): Observable<ApprovalActionResult>;
  /**
   * @param reason Required by docs/02 §4.3 / BR-062 — the denial email quotes it, so an empty
   *   rejection would send the creator a mail with no cause. The screen refuses to submit without
   *   one and this signature makes that non-optional rather than a convention.
   */
  reject(contractNumber: string, reason: string): Observable<ApprovalActionResult>;
}
export declare const APPROVAL_ACTION_SOURCE: InjectionToken<ApprovalActionSource>;
/**
 * The live implementation, against a route the API **does not publish yet**.
 *
 * `POST /api/v1/contracts/{number}/approval` with `{ decision, reason }`. Named here so the backend
 * half has a concrete contract to implement rather than one to invent, and so swapping this in is a
 * single provider change.
 *
 * ⚠ **It will 404 until that endpoint exists**, which the screen reports as a failure and not as a
 * refusal — a 404 here means "not built", and the message says so rather than leaving an approver
 * to read it as a permissions problem.
 *
 * Provided by `provideCwsWorkspace` (and by any host composing this screen); never root — see
 * `no-root-provision.spec.ts`.
 */
export declare class HttpApprovalActionSource implements ApprovalActionSource {
  private readonly http;
  private readonly baseUrl;
  /**
   * `GET /api/v1/contracts/{number}/approval/ecm`, proposed on #469 and owed by the backend with
   * #217. Until it exists this answers `esign: null` with the reason, so the screen refuses the
   * approve instead of guessing.
   */
  ecmRouting(contractNumber: string): Observable<ApprovalEcmRouting>;
  approve(contractNumber: string, ecm: ApprovalEcmRequest): Observable<ApprovalActionResult>;
  reject(contractNumber: string, reason: string): Observable<ApprovalActionResult>;
  private post;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpApprovalActionSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The default. Runs the whole journey without asking CTRM, and **says so in every result**.
 *
 * The delay is deliberate: without it the per-row busy state never renders, so the screen's
 * in-flight handling would be untested by use and would first be exercised against the live API.
 *
 * Provided by `provideCwsWorkspace` (and by any host composing this screen); never root — see
 * `no-root-provision.spec.ts`.
 */
export declare class SimulatedApprovalActionSource implements ApprovalActionSource {
  /** Not set up for e-sign, with no default recipients: the approver must name them. */
  ecmRouting(_contractNumber: string): Observable<ApprovalEcmRouting>;
  approve(contractNumber: string, _ecm: ApprovalEcmRequest): Observable<ApprovalActionResult>;
  reject(contractNumber: string, reason: string): Observable<ApprovalActionResult>;
  private settle;
  static ɵfac: i0.ɵɵFactoryDeclaration<SimulatedApprovalActionSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * How CTRM was asked for the queue, echoed by the route (#1021).
 *
 * - `PRIMARY`: the contracts whose approval record names the caller as the trader, and nothing they
 *   cover as a backup. The backend sends this while CTRM's backup lookup is broken (#993).
 * - `BOTH`: those plus the contracts the caller covers as a backup approver.
 */
export type ApprovalQueueApproverType = 'PRIMARY' | 'BOTH';
/** Who the route resolved the signed-in user to, and how it asked CTRM. */
export interface ApprovalQueueApprover {
  /**
   * The caller's CTRM trader initials, or `null` when their CTRM user has none. A user without
   * initials is named on no approval record, so CTRM lists nothing for them: an empty queue, not a
   * refusal (GEstevez's 2026-10-20 ruling on #217).
   */
  readonly traderInitials: string | null;
  /** `null` when the server did not say, which the screen reads as "say nothing about backups". */
  readonly approverType: ApprovalQueueApproverType | null;
}
/**
 * One read of the signed-in approver's queue, `GET /api/v1/approvals/queue` (#101, #1021).
 *
 * - `loaded`: the route answered. An empty page is a real "nothing awaits you".
 * - `refused`: the route could not resolve the caller to exactly one CTRM user, or their initials are
 *   shared. Shown with its title and detail, which say what to ask the Help Desk for. Never an empty
 *   queue, which would read as "nothing to approve".
 * - `notDeployed`: a `404`, or no answer at all (`0`). The route is not on this server yet, so the
 *   screen keeps the one-trade-unit queue it showed before the route existed.
 * - `failed`: anything else. The route exists and broke, so the screen says so and offers Retry
 *   rather than quietly narrowing to one trade unit.
 */
export type ApprovalQueueRead = {
  readonly kind: 'loaded';
  readonly page: ContractListPage;
  readonly approver: ApprovalQueueApprover;
} | {
  readonly kind: 'refused';
  readonly title: string;
  readonly detail: string;
  readonly correlationId: string | null;
} | {
  readonly kind: 'notDeployed';
} | {
  readonly kind: 'failed';
  readonly message: string;
  readonly correlationId: string | null;
};
export interface ApprovalQueueSource {
  /** One answer per subscription. Never errors: a failure is `failed`, `refused` or `notDeployed`. */
  read(options?: ContractListRequestOptions): Observable<ApprovalQueueRead>;
}
/**
 * The approver's own queue (#101). Injected optionally: a host that provides none gets the
 * one-trade-unit queue, exactly as when the route answers `404`.
 */
export declare const APPROVAL_QUEUE_SOURCE: InjectionToken<ApprovalQueueSource>;
/** The answer for "this server has no such route", shared so every path that means it says it alike. */
export declare const APPROVAL_QUEUE_NOT_DEPLOYED: ApprovalQueueRead;
/**
 * The three refusals the route answers `403` with, each with the title and detail shown when the
 * server sends none. The wording follows GEstevez's 2026-10-20 ruling on #217, reference included.
 * The server's own title and detail win whenever it sends them.
 *
 * ⚠ Here rather than beside the token, which the initial bundle loads: this file is lazy (#678).
 */
export declare const APPROVAL_QUEUE_REFUSALS: Readonly<Record<string, {
  readonly title: string;
  readonly detail: string;
}>>;
/**
 * The real one: `GET /api/v1/approvals/queue`, proposed on #1021 and not built yet.
 *
 * 🔴 **A `404` or a `0` is `notDeployed`, and that is the only soft direction.** Until #1021 lands
 * every call 404s, and the queue must keep the one-trade-unit screen it shows today rather than an
 * error panel. The proposed route never answers `404` itself, so a `404` can only mean "no such route
 * on this server".
 *
 * Every other failure is `failed` or `refused`, never `notDeployed`: once the route exists, quietly
 * dropping to one trade unit would be a silently narrow work queue.
 */
export declare class HttpApprovalQueueSource implements ApprovalQueueSource {
  private readonly http;
  private readonly baseUrl;
  read(options?: ContractListRequestOptions): Observable<ApprovalQueueRead>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpApprovalQueueSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The sample approver: one of the sample list's own traders, so the queue spans the trade units
 * that trader's sample contracts sit in rather than one the playground picked.
 */
export declare const SAMPLE_APPROVER_INITIALS = "MKD";
/**
 * A stand-in for `GET /api/v1/approvals/queue` (#1021) for the playground: the sample contracts
 * whose trader is {@link SAMPLE_APPROVER_INITIALS}, in every trade unit, asked for as `PRIMARY`, which
 * is what the backend sends while CTRM's backup lookup is broken (#993).
 *
 * ⚠ It mirrors the route's rule (the contract's trader, across every location) and nothing more. The
 * envelope is the list route's, with the whole queue on one page, as the route proposes.
 */
export declare class SampleApprovalQueueSource implements ApprovalQueueSource {
  private readonly rows;
  /** `_options` is accepted and ignored: there is no cache in front of this source to bypass. */
  read(_options?: ContractListRequestOptions): Observable<ApprovalQueueRead>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleApprovalQueueSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **CTRM's transportation weight limit, checked while the user types (#965; the server half is #964).**
 *
 * The rule (`wnr051e:7061-7096`, docs/CTRM-CONTRACT-WRITE-RULES-2026-09-08.md § `transportation_type_code`):
 * when `buyers_equipment = 'Y'` and `transportation_type_code` is not `T`, the weight per unit of
 * equipment must sit inside `GNP084`'s limits for the type. That weight is the quantity in the
 * company's standard unit, ÷ `equipment_unit_size` when non-zero, ÷ `transportation_units` when
 * non-zero, tested against the `LB` row (or `EA`), blank commodity.
 *
 * 🔴 **The arithmetic is the SERVER's, deliberately (#964's recommendation).** The conversion to the
 * company's standard unit (commodity pounds per bushel included) must match CTRM exactly, and the limit
 * lookup must mirror CTRM's gaps exactly (no `KG` row, no commodity row, no `EA` row on TESTING). A
 * second copy of either in the browser would drift silently. So the screen sends the inputs and shows
 * the answer; it decides only WHEN to ask, which is the arming condition below.
 *
 * 🔴 **Never refuse on a limit CWS could not confirm.** Every way of not knowing (no route yet, a
 * failure, a body this screen cannot read, the server declining to check) is `notChecked`, which shows
 * nothing and holds nothing. CTRM still enforces the rule on Save.
 */
/**
 * What the screen sends: the inputs by their CTRM write names, as the save sends them.
 *
 * `contractNumber` is the stored contract on an edit, so the server can take what the form does not
 * carry (the company, and `equipment_unit_size`, which no CWS screen renders) from the contract as
 * CTRM holds it. `null` on a create or a copy.
 */
export interface WeightLimitCheckRequest {
  readonly contractNumber: string | null;
  readonly fields: {
    readonly location: string;
    readonly commodity_code: string | null;
    readonly quantity: number;
    readonly quantity_uom: string;
    readonly buyers_equipment: 'Y';
    readonly transportation_type_code: string;
    readonly transportation_units: number;
  };
}
/** The server's answer when it checked: the weight it computed and the limits it read. */
export interface WeightLimitMeasured {
  readonly status: 'within' | 'outside';
  /** The weight per unit of equipment, in {@link unit}. */
  readonly weight: number;
  /** The limit row's unit: `LB`, or `EA`. */
  readonly unit: string;
  readonly lowerLimit: number;
  readonly upperLimit: number;
  readonly transportationTypeCode: string;
  /** The type's description, or `null` when the server has none. */
  readonly transportationTypeDescription: string | null;
}
/** One check's verdict. `notChecked` covers every way of not knowing, and is never shown. */
export type WeightLimitVerdict = WeightLimitMeasured | {
  readonly status: 'notChecked';
};
/** The answer for "could not tell", shared so every path that means it says it the same way. */
export declare const WEIGHT_LIMIT_NOT_CHECKED: WeightLimitVerdict;
export interface WeightLimitCheckSource {
  /** One answer per subscription. Never errors: a failure is `notChecked`. */
  check(request: WeightLimitCheckRequest): Observable<WeightLimitVerdict>;
}
/**
 * The seam. Injected optionally: a host that provides none gets no pre-check, which is today's screen.
 * `provideCwsWorkspace` binds the HTTP source; the playground binds the simulated one.
 */
export declare const WEIGHT_LIMIT_CHECK_SOURCE: InjectionToken<WeightLimitCheckSource>;
/**
 * Whether CTRM's rule is armed: Buyers equipment `Y` and a transportation type that is not truck.
 *
 * ⚠ This is the one part of the rule the screen decides, because it is a literal in `wnr051e`, not
 * configuration. A blank type is not armed: there is nothing to look a limit up by.
 */
export declare function weightLimitRuleApplies(buyersEquipment: unknown, transportationTypeCode: unknown): boolean;
/** Shown on Transportation type while a check is in flight. */
export declare const WEIGHT_LIMIT_CHECKING_MESSAGE = "Checking the weight per unit of equipment against CTRM's limit…";
/** Shown under each input that drives an out-of-limit weight, so the user knows what to change. */
export declare const WEIGHT_LIMIT_DRIVER_MESSAGE = "Sets the weight per unit of equipment, which is outside CTRM's limit for this transportation type.";
/** The verdict's sentence, with the computed weight and the allowed range. */
export declare function weightLimitMessage(verdict: WeightLimitMeasured): string;
/**
 * The real one: `POST /api/v1/contracts/weight-limit-check`, which does not exist yet (#964).
 *
 * 🔴 **Fails soft to `notChecked`, and that is the only safe direction.** Until the route lands every
 * call 404s, and the screen must show nothing and hold nothing (CTRM still enforces the rule on Save).
 * A body whose outcome is unrecognised, or whose numbers are missing, is `notChecked` too: an
 * `Outside` with no limits would hold a save on a range nobody can see (correction C-7's rule, that
 * unrecognised wording never reads as a specific outcome).
 */
export declare class HttpWeightLimitCheckSource implements WeightLimitCheckSource {
  private readonly http;
  private readonly baseUrl;
  check(request: WeightLimitCheckRequest): Observable<WeightLimitVerdict>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpWeightLimitCheckSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A SIMULATED check for the playground and the tests (#965). **Sample data, not CTRM's arithmetic.**
 *
 * - One limit row: rail (`R`), 50,000–250,000 lb per unit of equipment, the range documented for
 *   TESTING's `GNP084` and used here only as a sample. Every other type has no row, so it is not
 *   checked, as CTRM does for a type with no row.
 * - Sample conversion factors to pounds: `LB` 1, `CWT` 100, and `BU` 56 (corn's pounds per bushel,
 *   for every commodity). The real conversion is the company's standard unit and the commodity's own
 *   factor, which is why the real check is the server's (#964).
 * - The equipment unit size is never divided by: no CWS screen carries it.
 */
export declare const SAMPLE_RAIL_WEIGHT_LIMITS: {
  readonly lowerLimit: 50000;
  readonly upperLimit: 250000;
};
export declare class SimulatedWeightLimitCheckSource implements WeightLimitCheckSource {
  check(request: WeightLimitCheckRequest): Observable<WeightLimitVerdict>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SimulatedWeightLimitCheckSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The user's own trade-unit visibility list (#103; storage is #711).
 *
 * 🔴 **A PREFERENCE, NOT A PERMISSION.** Hiding a trade unit shortens the picker and denies nothing:
 * reads are un-scoped by trade unit (C-14) and the picker is not restricted by assignment (C-15 a).
 * Nothing on either side of the wire may consult this list to refuse a read or a write, and a deep
 * link into a hidden unit must still open. If a real restriction is ever wanted, that is a spec
 * correction to C-14 and C-15 (a) plus server-side authorization, never a tightening of this list.
 *
 * `unavailable` covers a failed read (a 404 from an older server, or the 500 an environment answers
 * before its `AddUserPreferences` migration is applied, #711) and a malformed body. The picker then
 * shows every trade unit.
 */
export type TradeUnitVisibility = {
  readonly status: 'available';
  readonly hidden: readonly string[];
} | {
  readonly status: 'unavailable';
};
/**
 * A save that failed, with the server's reference (#803). A source may still answer the bare
 * `'failed'`, which reads as a failure with no reference, so an existing host implementation keeps
 * compiling: the result type only widened.
 */
export interface TradeUnitVisibilitySaveFailure {
  readonly kind: 'failed';
  readonly correlationId: string | null;
}
/**
 * Where a saved list was kept, as the source that saved it knows (#1051). The screen words the
 * success from this, so only a durable store is ever called "your account".
 *
 * - `account`: a durable server store (`X-CMS-Config-Store: Database`).
 * - `server-memory`: the server's `InMemory` store, lost when the server restarts.
 * - `session`: kept in this page only (the playground's sample), lost on reload.
 * - `unknown`: the source cannot tell, for instance a cross-origin host that cannot read the header.
 */
export type TradeUnitVisibilityKeptIn = 'account' | 'server-memory' | 'session' | 'unknown';
/** A save that worked, and where the list went (#1051). */
export interface TradeUnitVisibilitySaved {
  readonly kind: 'saved';
  readonly keptIn: TradeUnitVisibilityKeptIn;
}
/**
 * A bare `'saved'` is still accepted, so an existing host implementation keeps compiling, and reads
 * as `keptIn: 'unknown'`: it says no more than that the save worked.
 */
export type TradeUnitVisibilitySaveOutcome = 'saved' | TradeUnitVisibilitySaved | 'failed' | TradeUnitVisibilitySaveFailure;
export interface TradeUnitVisibilitySource {
  /** The saved list. Never errors: a failure is `unavailable`. */
  get(): Observable<TradeUnitVisibility>;
  /** Replaces the saved list. Never errors: answers whether it was saved, and why not. */
  save(hidden: readonly string[]): Observable<TradeUnitVisibilitySaveOutcome>;
}
/**
 * The seam. Injected optionally: a host that provides none gets the full picker and no curation.
 * `provideCwsWorkspace` binds the HTTP source.
 */
export declare const TRADE_UNIT_VISIBILITY_SOURCE: InjectionToken<TradeUnitVisibilitySource>;
/** The answer for "could not tell". */
export declare const TRADE_UNIT_VISIBILITY_UNAVAILABLE: TradeUnitVisibility;
/**
 * The real one: `GET|PUT /api/v1/me/trade-unit-visibility` (#711, on `main` since PR #954;
 * `TradeUnitVisibilityEndpoints.cs`). Both verbs carry `{ hidden: string[] }`: GET answers 200 with
 * an empty list for a person who has saved nothing (never 404), and PUT answers 200 echoing the
 * stored list, trimmed, de-duplicated and sorted. The echo is not read back: the store keeps the
 * person's own list for the session.
 *
 * A save reads the server's `X-CMS-Config-Store` header (#1051): `Database` is the account,
 * `InMemory` is lost when the server restarts, and anything else is `unknown`, never the account.
 * ⚠ The header is not in the API's CORS exposed headers, so a cross-origin host reads `unknown`.
 *
 * 🔴 **Fails soft in both directions.** A failed or malformed read is `unavailable`, so the picker
 * shows every trade unit: the safe direction for a preference, because the opposite failure would
 * hide units nobody chose to hide. A failed save answers `failed` and the caller keeps the user's
 * choice for the session and says it was not saved.
 */
export declare class HttpTradeUnitVisibilitySource implements TradeUnitVisibilitySource {
  private readonly http;
  private readonly url;
  get(): Observable<TradeUnitVisibility>;
  save(hidden: readonly string[]): Observable<TradeUnitVisibilitySaveOutcome>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpTradeUnitVisibilitySource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** The playground's starting list: two of the sample locations hidden. */
export declare const SAMPLE_HIDDEN_TRADE_UNITS: readonly string[];
/**
 * An in-memory list for the playground and the tests. Saves always succeed, and say they are kept
 * for this session only (#1051): the list is gone on reload, so it is never "your account".
 */
export declare class SampleTradeUnitVisibilitySource implements TradeUnitVisibilitySource {
  private hidden;
  get(): Observable<TradeUnitVisibility>;
  save(hidden: readonly string[]): Observable<TradeUnitVisibilitySaveOutcome>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleTradeUnitVisibilitySource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **The trade unit the user chose to start on** (JFrisbie, 2026-10-23: a default the user selects).
 *
 * `code` is a CTRM location code, or `null` for no choice of their own, in which case the default an
 * administrator assigned on the Roles page applies (`/me`'s `defaultTradeUnit`, C-15 c). `unavailable`
 * is a read that could not answer: never "no choice" on the user's behalf.
 *
 * 🔴 A PREFERENCE, NOT A PERMISSION (C-14). It only decides which unit a new session opens on.
 */
export type DefaultTradeUnitPreference = {
  readonly status: 'available';
  readonly code: string | null;
} | {
  readonly status: 'unavailable';
};
/** Where a save landed: on the account, or in this browser while the account route is missing. */
export type DefaultTradeUnitSaveOutcome = {
  readonly kind: 'saved';
  readonly keptIn: 'account' | 'browser';
} | {
  readonly kind: 'failed';
  readonly correlationId: string | null;
};
export interface DefaultTradeUnitSource {
  get(): Observable<DefaultTradeUnitPreference>;
  /** `null` clears the user's own choice, so the assigned default applies again. */
  save(code: string | null): Observable<DefaultTradeUnitSaveOutcome>;
}
/** What the trade-unit picker injects. Optional: absent, the picker offers no "make my default". */
export declare const DEFAULT_TRADE_UNIT_SOURCE: InjectionToken<DefaultTradeUnitSource>;
/**
 * **`GET|PUT /api/v1/me/default-trade-unit` when it answers, else this browser.** The account route is
 * proposed on the user-preferences store (#711's pattern), so until it lands every read falls back to
 * the browser and every save is kept there; the picker says which.
 *
 * ⚠ The two copies are not merged: once the server answers it is the only copy read, so a choice kept
 * in this browser before then is chosen again once. The browser copy is keyed on the `oid` (C-13), so
 * two people sharing a workstation profile do not share a default.
 */
export declare class LocalFirstDefaultTradeUnitSource implements DefaultTradeUnitSource {
  private readonly http;
  private readonly url;
  private readonly owner;
  get(): Observable<DefaultTradeUnitPreference>;
  save(code: string | null): Observable<DefaultTradeUnitSaveOutcome>;
  private key;
  private readLocal;
  private writeLocal;
  static ɵfac: i0.ɵɵFactoryDeclaration<LocalFirstDefaultTradeUnitSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * `/api/v1/form-configurations` — the admin CRUD and the resolve endpoint used as a preview.
 *
 * Every route here is `CmsAdmin`, so a `User`-role token gets 403 and the screen says so rather
 * than rendering an empty list that looks like "no configuration exists".
 */
export declare class HttpFormConfigAdminSource implements FormConfigAdminSource {
  private readonly http;
  private readonly baseUrl;
  list(): Observable<RemoteData<FormConfigListResponse>>;
  /** The field registry — served, not stored (brief §5.4). */
  registry(): Observable<RemoteData<FormConfigRegistry>>;
  /**
   * One row's audit trail, oldest first (F8.6).
   *
   * ⚠ **The order is load-bearing, not cosmetic.** Nothing stores a "before": the diff the screen
   * renders pairs each entry against its predecessor, so a trail served newest-first would invert
   * every line and nothing would report it.
   */
  auditTrail(id: number): Observable<RemoteData<FormConfigAuditTrail>>;
  /** One row with its full document, for editing. */
  get(id: number): Observable<RemoteData<FormConfigDetail>>;
  /**
   * Creates a row. A duplicate active (dimensions, EffectiveFrom) is a **409**, not a silent
   * second row — `describe` turns it into a sentence naming the fix.
   */
  create(submission: FormConfigSubmission): Observable<RemoteData<FormConfigDetail>>;
  /**
   * Updates a row under optimistic concurrency.
   *
   * The `rowVersion` came from the GET the editor loaded, and a mismatch is a 409 telling the
   * admin to reload — **never retried with a fresh token**, because that would deliberately
   * overwrite the change it just detected.
   */
  update(id: number, rowVersion: string, submission: FormConfigSubmission): Observable<RemoteData<FormConfigDetail>>;
  /**
   * Resolves for arbitrary dimensions — **the preview tool**.
   *
   * The same endpoint the record screen calls, deliberately: a preview built from a second
   * implementation of the ranking rules would be a second answer to "which configuration wins",
   * and the one place an admin looks to check their work is the last place that should disagree
   * with production.
   */
  preview(dimensions: PreviewDimensions): Observable<RemoteData<FormConfigPreview>>;
  /**
   * Soft-deletes a row, sending its `rowVersion` on `If-Match`.
   *
   * A 409 here means someone else saved it after this list was loaded — surfaced as a message
   * telling the admin to reload, never retried automatically, because a retry with a fresh token
   * would deliberately overwrite the change it just detected.
   */
  deactivate(id: number, rowVersion: string): Observable<RemoteData<FormConfigRow>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpFormConfigAdminSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** Reads one contract. */
export interface ContractDetailSource {
  /**
   * Loads a contract by its CTRM number.
   *
   * @param contractNumber The composed key, e.g. `SC1240000`.
   */
  get(contractNumber: string): Observable<RemoteData<ContractDetailResponse>>;
}
/**
 * The contract-detail source.
 *
 * A token rather than a concrete class for the same reason the list has one: the shell names the
 * implementation in `app.config.ts`, and a consumer that provides nothing fails at injection — which is
 * the loud failure we want over a silently empty screen.
 */
export declare const CONTRACT_DETAIL_SOURCE: InjectionToken<ContractDetailSource>;
/**
 * The real source: `GET /api/v1/contracts/{number}`.
 *
 * The contract number goes in the **path**, so it is percent-encoded rather than concatenated. Numbers
 * are `[A-Z0-9-]` today, but a key with a space in it is not hypothetical — CR-11 established that
 * CTRM keys with leading spaces exist and behave differently — and a raw `/` or `#` in a path segment
 * would silently address a different route.
 */
export declare class HttpContractDetailSource implements ContractDetailSource {
  private readonly http;
  private readonly baseUrl;
  get(contractNumber: string): Observable<RemoteData<ContractDetailResponse>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractDetailSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **BR-053: what opening an unpriced contract found when it re-checked CTRM** (F5.1, #743).
 *
 * BR-053 (docs/01 §7) names four outcomes. Each is bound here to the check CTRM itself makes when it
 * refuses a price ADD, read from `CNTPRCADDE` (`qrpglesrc/cntprcadde.sqlrpgle`), not to the
 * requirement's paraphrase:
 *
 * | Outcome | CTRM's check | What this reads |
 * |---|---|---|
 * | `not-found` | `ccmpcd = *BLANKS` (`spValidContract`) | CTRM's own refusal, `Contract not found.` (`contapi.sqlrpgle:514`) |
 * | `date-closed` | `cgclsdt <> *LOVAL` (`spValidCloseDate`) | `header.isClosed`, which the API sets from `closed_date` |
 * | `unpriced-zero` | `cprclb >= cqty` (`spValidQuantities`) | `quantities.unpriced` at or below zero |
 * | `success` | none of the above | |
 *
 * 🔑 **"Date closed" means the contract has a close date.** It is not a contract date outside an open
 * period: CTRM tests one field, the close date, and so does the API's `isClosed`. The record page reads
 * the same flag, so there is one definition of closed.
 *
 * ⚠ **A fifth state, `unchecked`, that BR-053 does not name.** Any read failure other than CTRM's
 * not-found sentence — a timeout, an outage, a missing route — proves nothing about the contract, so
 * it is neither "not found" nor "success" (ruled by JFrisbie on #743). A 404 is NOT not-found here:
 * CTRM reports an unknown contract as a 422 rejection, and a 404 means the route is missing.
 *
 * 🔴 **This is the pre-check BR-053 asks for, not a gate.** CTRM's refusal of the write stays the
 * authority, and this must read a FRESH contract, never the queue row: the row is a cached list
 * projection and can be up to the list's TTL stale.
 */
export type UnpricedOpenOutcomeKind = 'not-found' | 'date-closed' | 'unpriced-zero' | 'unchecked' | 'success';
/** One outcome, with the words the pricing screen shows for it. */
export interface UnpricedOpenOutcome {
  readonly kind: UnpricedOpenOutcomeKind;
  /** The banner's title, naming the outcome. Empty on success, which shows nothing. */
  readonly title: string;
  /** The banner's description. Empty on success. */
  readonly message: string;
  /** Why Add is held, or `null` when it is not. Rendered beside the disabled button. */
  readonly holdsAdd: string | null;
}
/** The facts the classifier reads. A `ContractDetailResponse` satisfies this structurally. */
export interface UnpricedOpenFacts {
  readonly contract: {
    readonly header: {
      readonly isClosed: boolean;
    };
    readonly quantities: {
      readonly unpriced: number | null;
    };
  };
}
/**
 * CTRM's sentence for an unknown contract, byte for byte as `contapi.sqlrpgle:514` sends it after the
 * `Error_Message:` prefix. Compared after trimming, never by substring: a reason that merely mentions
 * a contract not being found elsewhere must not read as this one.
 */
export declare const CTRM_CONTRACT_NOT_FOUND = "Contract not found.";
/**
 * Classifies a fresh contract read. `null` while the read is idle or loading: no outcome is claimed
 * before CTRM has answered.
 */
export declare function unpricedOpenOutcomeOf(read: RemoteData<UnpricedOpenFacts>): UnpricedOpenOutcome | null;
/**
 * **Which home-grid columns show, and in what order** (F4.1a, #748).
 *
 * docs/02 §2.1 makes the columns configurable per trade unit, with user-level show, hide and order on
 * top; 02a §6.1 says the visible set is the trade unit's configuration intersected with the user's
 * preferences. Three inputs, one rule each:
 *
 * | Input | Meaning | When absent (`null`) |
 * |---|---|---|
 * | `allKeys` | every column the grid defines, in its own order | never absent |
 * | `tradeUnitKeys` | the trade unit's `homeGridColumns` attribute, in its order | every column |
 * | `userKeys` | the columns this user shows, in their order | everything the trade unit allows |
 *
 * 🔴 **The trade unit wins.** A user who had shown a column the trade unit now omits does not see it.
 * The user narrows and orders within what the trade unit allows; they never widen it.
 *
 * ⚠ **An unknown key is dropped, the rest kept.** A stored preference or attribute that names a column
 * this build no longer has (renamed, removed) loses that one entry rather than being discarded whole:
 * the user's other choices still describe columns that exist.
 *
 * 🔑 **The contract number is always shown, first if nobody placed it.** It is the row's identity and
 * the grid's primary action opens it, so neither a trade unit nor a user can hide it.
 */
/** The column nobody can hide. */
export declare const PINNED_GRID_COLUMN = "contractNumber";
/** One column as the column menu lists it: its key, and whether it is currently shown. */
export interface GridColumnChoice {
  readonly key: string;
  readonly shown: boolean;
}
/**
 * The columns the trade unit allows, in its order: the attribute's known keys, else every column in
 * the grid's own order. Always includes the pinned column.
 */
export declare function tradeUnitGridColumnKeys(allKeys: readonly string[], tradeUnitKeys: readonly string[] | null): string[];
/**
 * The visible columns, in display order: the user's order where the user ordered, else the trade
 * unit's, else the grid's own.
 *
 * `condensedKeys` is docs/02a §7's priority set, passed when the layout is narrower than 1300 and
 * `null` otherwise (#759). 🔴 **A user's own choice wins over it**: someone who chose columns in the
 * Columns menu sees exactly those at every width. Without a choice, the trade unit's set is narrowed
 * to the priority columns, keeping the pinned column.
 */
export declare function visibleGridColumnKeys(allKeys: readonly string[], tradeUnitKeys: readonly string[] | null, userKeys: readonly string[] | null, condensedKeys?: readonly string[] | null): string[];
/**
 * What the column menu lists: every column the trade unit allows, shown ones first in display order,
 * then the hidden ones in the trade unit's order.
 */
export declare function gridColumnChoices(allKeys: readonly string[], tradeUnitKeys: readonly string[] | null, userKeys: readonly string[] | null, condensedKeys?: readonly string[] | null): GridColumnChoice[];
/** The preference a set of menu choices stores: the shown keys, in order. */
export declare function userGridColumnKeys(choices: readonly GridColumnChoice[]): string[];
/**
 * **What the admin screens may offer this account** (#696, after #695 and #700).
 *
 * The server authorizes the admin writes on `settings:manage` in the row's trade unit, or the Admin
 * role. This is the client's reading of `/me` for the same question, so a screen offers what the
 * server will accept instead of offering everything and answering `403`.
 *
 * `known: false` while `/me` has not answered, or could not be read: then a screen keeps showing what
 * it showed before #696, because hiding a panel on a guess would refuse what the server may allow.
 */
export interface SettingsScope {
  readonly known: boolean;
  /** The Entra Admin role: every trade unit, plus the routes that are Admin-only. */
  readonly isAdmin: boolean;
  /** Trade units where this account holds `settings:manage`, in `/me` order. Empty for an Admin. */
  readonly tradeUnits: readonly string[];
  /** Trade units that have a configuration, for the Admin picker's indicator. */
  readonly onboarded: readonly string[];
}
export declare const UNKNOWN_SETTINGS_SCOPE: SettingsScope;
export declare function settingsScopeOf(me: Me | null): SettingsScope;
/**
 * Whether `/me` says this account holds ANY permission in a trade unit, or the Admin role (#865).
 *
 * The server's rule for Notify Trader since #847 (ruled by GEstevez, 2026-10-15): a broker confirmer
 * may email the trader without being able to edit the contract. As on the server, only the keys the
 * catalogue defines count, and trade-unit codes are compared trimmed.
 *
 * `null` when it is not known: `/me` has not answered, could not be read, or there is no trade unit.
 * A screen then offers the action and the server decides, because refusing on a guess would refuse
 * what the server may allow.
 */
export declare function holdsAnyPermissionIn(me: Me | null, tradeUnit: string | null): boolean | null;
/**
 * A refusal from an admin route, as a holder or an Admin should read it.
 *
 * 🔴 **The server's own words, never a sentence written here about who may do what.** The screens
 * used to answer every `403` with "this account does not hold the Admin role", which became false the
 * day #695 let a `settings:manage` holder write: a holder refused for the wrong trade unit was told
 * they needed a role they do not need. The server's title and detail name the permission and the
 * trade unit, and say that nothing was written.
 */
export interface AdminRefusal {
  readonly status: number;
  /** One or two sentences for the banner. */
  readonly message: string;
  /** The `required` permission key on a `403`, else `null`. */
  readonly required: string | null;
  /** The `tradeUnit` on a `403`, else `null` (also `null` for an Admin-only refusal). */
  readonly tradeUnit: string | null;
  /** The server's `reason` (`Forbidden`, `AdminRequired`, `NotOnboarded` …), else `null`. */
  readonly reason: string | null;
  /** Field-scoped reasons from a `400`, keyed by the request's field name (`marketMonth` …). */
  readonly fieldErrors: Readonly<Record<string, readonly string[]>>;
  readonly correlationId: string | null;
}
export declare function adminRefusalOf(error: unknown): AdminRefusal;
/**
 * **The trade unit's home-grid column set** (docs/02 §2.1, F4.1a, #748).
 *
 * `null` means every column: the attribute is absent, the trade unit has no configuration, or the
 * read failed. A failed read must never narrow the grid, because a trader who cannot see a column
 * they rely on has lost information with nothing saying why.
 */
export interface HomeGridColumnsSource {
  forTradeUnit(tradeUnit: string): Observable<readonly string[] | null>;
}
export declare const HOME_GRID_COLUMNS_SOURCE: InjectionToken<HomeGridColumnsSource>;
/** A list of strings, else `null`: anything else is not a column set. */
export declare function columnKeysOf(value: unknown): readonly string[] | null;
/**
 * Sample data: one trade unit with a narrowed set, every other one unconfigured. The narrowed one is
 * not the playground's default trade unit, so the ordinary workspace shows every column and a
 * separate route shows the narrowed grid.
 */
export declare class SampleHomeGridColumnsSource implements HomeGridColumnsSource {
  /** One of `SAMPLE_LOCATIONS`, and not the playground's default `0210`. */
  static readonly narrowedTradeUnit = "0315";
  static readonly narrowedColumns: readonly string[];
  forTradeUnit(tradeUnit: string): Observable<readonly string[] | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleHomeGridColumnsSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **The user's own home-grid columns, per trade unit** (02a §6.1, F4.1a, #748).
 *
 * `columns` is the shown keys in the user's order, or `null` for no preference (show what the trade
 * unit allows). `unavailable` is a read that could not answer, which is never "no preference" on the
 * server's behalf: the caller decides what to fall back to.
 */
export type GridColumnPreference = {
  readonly status: 'available';
  readonly columns: readonly string[] | null;
} | {
  readonly status: 'unavailable';
};
/**
 * Where a save landed. `browser` is the client-side copy, used while the server route (#747) does not
 * exist, so the menu can say the choice is kept in this browser rather than on the account.
 */
export type GridColumnSaveOutcome = 'saved' | 'browser' | 'failed' | GridColumnSaveFailure;
/**
 * A save kept nowhere, with the server's reference when the server was asked (#803). A source may
 * still answer the bare `'failed'`, read as a failure with no reference: the type only widened, so
 * a host's own source keeps compiling.
 */
export interface GridColumnSaveFailure {
  readonly kind: 'failed';
  readonly correlationId: string | null;
}
export interface GridColumnPreferenceSource {
  get(tradeUnit: string): Observable<GridColumnPreference>;
  save(tradeUnit: string, columns: readonly string[] | null): Observable<GridColumnSaveOutcome>;
}
/** What the home screen injects. */
export declare const GRID_COLUMN_PREFERENCE_SOURCE: InjectionToken<GridColumnPreferenceSource>;
/** The server half alone (`GET|PUT /me/grid-columns`, #747). Optional: absent means browser only. */
export declare const GRID_COLUMN_SERVER_SOURCE: InjectionToken<GridColumnPreferenceSource>;
/**
 * The signed-in user's `oid`, or `null` before sign-in completes. The browser copy is keyed on it so
 * two people sharing a workstation profile do not share columns, and a changed sign-in name does not
 * orphan the row (C-13).
 */
export declare const GRID_COLUMN_OWNER: InjectionToken<() => string | null>;
export declare const GRID_COLUMNS_UNAVAILABLE: GridColumnPreference;
/**
 * Reads the attribute from `GET /form-configurations/resolve?locationCode=` (ruled by JFrisbie on
 * #748: no new route). Resolve with only a location answers the trade unit's own configuration, or
 * the global default when it has none.
 *
 * ⚠ **One read per trade unit per session.** Resolve carries the whole form configuration, and the
 * grid wants one attribute from it, so the answer is kept rather than re-fetched on every return to
 * the workspace. A change an admin makes shows on the next session.
 *
 * The attribute is #747's and is not served until it lands, so today every read answers `null`.
 */
export declare class HttpHomeGridColumnsSource implements HomeGridColumnsSource {
  private readonly http;
  private readonly url;
  private readonly cache;
  forTradeUnit(tradeUnit: string): Observable<readonly string[] | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpHomeGridColumnsSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * `GET|PUT /api/v1/me/grid-columns`, #747's route on #711's pattern. Until it lands every read 404s
 * and answers `unavailable`, and every save answers `failed`.
 */
export declare class HttpGridColumnPreferenceSource implements GridColumnPreferenceSource {
  private readonly http;
  private readonly url;
  get(tradeUnit: string): Observable<GridColumnPreference>;
  save(tradeUnit: string, columns: readonly string[] | null): Observable<GridColumnSaveOutcome>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpGridColumnPreferenceSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **The server when it answers, else this browser** — client-side first, with the server half wired
 * now so nothing flips when #747 lands except where the choice is kept.
 *
 * ⚠ **The two copies are not merged.** Once the server answers, it is the only copy read; a choice
 * kept in this browser before then is not carried across. That is one re-pick per trade unit, once,
 * and it avoids inventing which copy wins.
 */
export declare class LocalFirstGridColumnPreferenceSource implements GridColumnPreferenceSource {
  private readonly server;
  private readonly owner;
  get(tradeUnit: string): Observable<GridColumnPreference>;
  save(tradeUnit: string, columns: readonly string[] | null): Observable<GridColumnSaveOutcome>;
  private key;
  private readLocal;
  private writeLocal;
  static ɵfac: i0.ɵɵFactoryDeclaration<LocalFirstGridColumnPreferenceSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** A listed addendum's document, as `GET /api/v1/contracts/{n}/addendums` serves it (#858). */
export interface ListedAddendumDocument {
  readonly id: string;
  /** `Current`, `Superseded` or `Removed` on the wire; kept as a string so an unknown value is not dropped. */
  readonly status: string;
}
/** One addendum CWS stored for a contract. Only the members the record reads. */
export interface ListedAddendum {
  readonly id: number;
  readonly status: string;
  readonly documentId: string | null;
  readonly createdAtUtc: string;
  readonly document: ListedAddendumDocument | null;
}
/** The whole answer: newest first, and which one is current. */
export interface ContractAddendumList {
  readonly currentId: number | null;
  readonly addendums: readonly ListedAddendum[];
}
/**
 * Lists the addendums CWS stored for a contract (#858). A seam of its own, as the PDF source is, so a
 * screen that only lists depends on one verb. Optional where injected: with none, the record lists nothing.
 */
export interface AddendumListSource {
  list(contractNumber: string): Observable<AddendumCall<ContractAddendumList>>;
}
export declare const ADDENDUM_LIST_SOURCE: InjectionToken<AddendumListSource>;
/**
 * The template routes: `/api/v1/addendum-templates` (#624, ADR-19; live on Dev since #670).
 *
 * 🔴 **Every `PUT` and `DELETE` carries `If-Match: <rowVersion>`**, deactivate included, because the
 * server requires it: missing is a `400`, stale is a `409`. The `409` becomes `conflict`, which the
 * screen renders as *changed since you opened it, reload*; it is never retried.
 *
 * ⚠ A `404` with no problem body, or a `0`, is still `unavailable`: a host whose API predates the
 * routes. A `404` WITH a problem body is the server saying the row is gone, and is `failed` with its
 * sentence. Every other failure is `failed`, carrying a `400`'s `errors.<field>`.
 */
export declare class HttpAddendumTemplateSource implements AddendumTemplateSource {
  private readonly http;
  private readonly baseUrl;
  private get templatesUrl();
  list(): Observable<AddendumCall<readonly AddendumTemplate[]>>;
  create(draft: AddendumTemplateDraft): Observable<AddendumCall<AddendumTemplate>>;
  update(id: number, rowVersion: string, draft: AddendumTemplateDraft): Observable<AddendumCall<AddendumTemplate>>;
  deactivate(template: AddendumTemplate): Observable<AddendumCall<AddendumTemplate>>;
  remove(template: AddendumTemplate): Observable<AddendumCall<void>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpAddendumTemplateSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The type routes: `/api/v1/addendum-types`, keyed by the special-type code. The same rules as the
 * templates: `If-Match` on every `PUT` and `DELETE`, and a `409` is `conflict`.
 */
export declare class HttpAddendumTypeSource implements AddendumTypeSource {
  private readonly http;
  private readonly baseUrl;
  private get typesUrl();
  /** The code goes in the path, so it is encoded; CTRM pads codes, so it is trimmed first. */
  private typeUrl;
  list(): Observable<AddendumCall<readonly AddendumType[]>>;
  create(draft: AddendumTypeDraft): Observable<AddendumCall<AddendumType>>;
  update(type: AddendumType, draft: AddendumTypeDraft): Observable<AddendumCall<AddendumType>>;
  remove(type: AddendumType): Observable<AddendumCall<void>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpAddendumTypeSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The real generation route: `POST /api/v1/contracts/{n}/addendums`.
 *
 * ⚠ Same fail-soft rule as the templates: wired before the route lands, a `404` or `0` is
 * `unavailable`.
 */
export declare class HttpAddendumGenerationSource implements AddendumGenerationSource {
  private readonly http;
  private readonly baseUrl;
  generate(contractNumber: string, request: AddendumGenerationRequest): Observable<AddendumCall<GeneratedAddendum>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpAddendumGenerationSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The stored-addendum list: `GET /api/v1/contracts/{n}/addendums` (#858). Here, not in a file of its
 * own, so it reuses `settle` without exporting it. A bare `404` or `0` is `unavailable`, as above.
 */
export declare class HttpAddendumListSource implements AddendumListSource {
  private readonly http;
  private readonly baseUrl;
  list(contractNumber: string): Observable<AddendumCall<ContractAddendumList>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpAddendumListSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The line every simulated template opens with.
 *
 * 🔴 **Legal's approved wording is not in this repository** (JFrisbie ruling 2026-09-28), so the
 * sample templates carry text that says, in the document itself, that it is not that wording. A
 * sample that read like a real addendum is the version of this that reaches a counterparty.
 */
export declare const ADDENDUM_PLACEHOLDER_NOTICE = "PLACEHOLDER, not Legal's approved wording. An administrator replaces this text with the approved template.";
/**
 * One simulated Family B template for a field set: the placeholder notice, one merge line per CWS
 * field, and the three anchors, serving the set's special types. Built from the field set rather than
 * hand-written, so a field added to a provisional set appears in its sample template too.
 *
 * Every placeholder is mapped, as the server requires (`AddendumRules.FieldProblems`): the contract
 * number to its CTRM field, and each line to its CWS `addendum_*` field.
 */
export declare function sampleAddendumTemplate(set: AddendumFieldSet, id: number): AddendumTemplate;
/**
 * A stand-in for the template routes, for the playground and the tests: three Family B templates,
 * one per provisional field set, held in memory.
 *
 * ⚠ **It behaves as the server does where a screen can tell**, because a stand-in that accepted what
 * the real route refuses would let its caller look correct:
 * - a template with the wrong anchors, or an unmapped placeholder, is refused with `fieldErrors`
 *   keyed as the server keys them (`templateContent`, `fields`);
 * - an update or delete on a stale `rowVersion` is a `conflict`;
 * - `version` moves only when what renders changes; `rowVersion` moves on every change.
 */
export declare class SampleAddendumTemplateSource implements AddendumTemplateSource {
  private templates;
  private nextId;
  private changes;
  list(): Observable<AddendumCall<readonly AddendumTemplate[]>>;
  create(draft: AddendumTemplateDraft): Observable<AddendumCall<AddendumTemplate>>;
  update(id: number, rowVersion: string, draft: AddendumTemplateDraft): Observable<AddendumCall<AddendumTemplate>>;
  deactivate(template: AddendumTemplate): Observable<AddendumCall<AddendumTemplate>>;
  remove(template: AddendumTemplate): Observable<AddendumCall<void>>;
  private nextRowVersion;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleAddendumTemplateSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The sample addendum types: the Family B special types the field sets serve, all available, and one
 * Family A type that is not, so a screen shows both states. Display names are descriptive, not CTRM's.
 */
export declare const SAMPLE_ADDENDUM_TYPES: readonly AddendumType[];
/** A stand-in for the type routes, with the same stale-`rowVersion` and duplicate-code conflicts. */
export declare class SampleAddendumTypeSource implements AddendumTypeSource {
  private types;
  private changes;
  list(): Observable<AddendumCall<readonly AddendumType[]>>;
  create(draft: AddendumTypeDraft): Observable<AddendumCall<AddendumType>>;
  update(type: AddendumType, draft: AddendumTypeDraft): Observable<AddendumCall<AddendumType>>;
  remove(type: AddendumType): Observable<AddendumCall<void>>;
  private nextRowVersion;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleAddendumTypeSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The two StoneX special types whose Legal-approved templates were loaded on QA on 2026-10-22 (#1043),
 * as sample types: both available. Display names are descriptive, not CTRM's.
 */
export declare const SAMPLE_STONEX_ADDENDUM_TYPES: readonly AddendumType[];
/**
 * **Sample templates shaped like the ones loaded on QA for PREM, SA and KA (#1043).**
 *
 * The PREM one maps the field NAMES Legal's Premium Advance template uses (from the issue; configuration,
 * not data). KA and SA carry invented `addendum_*` names, several of which the frontend has no label
 * for, so the playground shows a field labelled from its own name. 🔴 The wording is the placeholder
 * notice, never Legal's text, and every mapping also shows the server-supplied kinds (a CTRM field, the
 * stamped date, the seller name) that get no control.
 */
export declare function sampleRecordAddendumTemplateDrafts(): readonly AddendumTemplateDraft[];
/**
 * The record screen's sample templates (#1043): the sample source, with its provisional PREM template
 * replaced by the PREM, KA and SA ones above. Through the source's own `remove` and `create`, so the
 * stand-in holds no second copy of its rules. The admin screen keeps the plain sample source.
 */
export declare class SampleRecordAddendumTemplateSource extends SampleAddendumTemplateSource {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleRecordAddendumTemplateSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** The record screen's sample types (#1043): the sample types, plus KA and SA. */
export declare class SampleRecordAddendumTypeSource extends SampleAddendumTypeSource {
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleRecordAddendumTypeSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** A stand-in for generation: it answers a generated addendum for any template it is given. */
export declare class SampleAddendumGenerationSource implements AddendumGenerationSource {
  private nextId;
  generate(contractNumber: string, request: AddendumGenerationRequest): Observable<AddendumCall<GeneratedAddendum>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleAddendumGenerationSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * What `POST /api/v1/addendum-previews` takes (#828, #830): what a save would carry, and the contract
 * it is for.
 *
 * - `contractNumber` is `null` for a new contract; the draft then prints `[contract number]`.
 * - `fields` is what the save would send: the changed CTRM fields on an update, the whole form on a
 *   create. The server merges them exactly as a save does.
 * - `collections` follows the save's rule: absent keeps the contract's rows.
 */
export interface AddendumPreviewRequest {
  readonly contractNumber: string | null;
  readonly fields: Readonly<Record<string, unknown>>;
  readonly collections?: ContractWriteCollections;
  readonly addendum: ContractWriteAddendum;
}
/**
 * Renders the addendum a save would store, as a draft watermarked `DRAFT - NOT SAVED` on every page,
 * and stores nothing (#830). The answer is the PDF.
 *
 * A refusal is `failed` with the server's reasons in `fieldErrors`, keyed as on a save: `addendum.*`,
 * or a CTRM field name when the merge refuses.
 */
export interface AddendumPreviewSource {
  preview(request: AddendumPreviewRequest): Observable<AddendumCall<Blob>>;
}
/** The preview seam. Injected optionally, as the other addendum seams are. */
export declare const ADDENDUM_PREVIEW_SOURCE: InjectionToken<AddendumPreviewSource>;
/**
 * The real preview route: `POST /api/v1/addendum-previews` (#828, merged in #829).
 *
 * It answers `200 application/pdf`, so the request asks for a blob. ⚠ **A blob request leaves the
 * error body as a Blob too**, and a `422` here is the user's to fix (a blank field, a template that
 * does not serve the type), so its reasons are read out of the Blob rather than dropped. A body that
 * is not JSON falls back to the generic sentence.
 *
 * ⚠ Same fail-soft rule as the other addendum routes: a bare `404` or a `0` is `unavailable`.
 */
export declare class HttpAddendumPreviewSource implements AddendumPreviewSource {
  private readonly http;
  private readonly baseUrl;
  preview(request: AddendumPreviewRequest): Observable<AddendumCall<Blob>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpAddendumPreviewSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The preview over sample data, for the playground and specs (#830).
 *
 * It answers a one-page PDF carrying the server's watermark, the contract number (or the server's
 * `[contract number]` stand-in for a new contract), the template id and each entered value, so a
 * screenshot shows what the request carried. A blank entered value is refused under
 * `addendum.fields`, as the server refuses a field that would print blank.
 */
export declare class SampleAddendumPreviewSource implements AddendumPreviewSource {
  preview(request: AddendumPreviewRequest): Observable<AddendumCall<Blob>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleAddendumPreviewSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Reads the PDF of an addendum CWS stored (#818): `GET /api/v1/contracts/{number}/addendums/{id}/pdf`.
 *
 * A seam of its own rather than a method on the template or generation sources, so a screen that only
 * opens a stored addendum depends on one verb. Optional where injected: with no source the screen
 * offers no Open button, rather than a button that cannot work.
 */
export interface AddendumPdfSource {
  pdf(contractNumber: string, addendumId: number): Observable<AddendumCall<Blob>>;
}
export declare const ADDENDUM_PDF_SOURCE: InjectionToken<AddendumPdfSource>;
/**
 * The real stored-addendum route: `GET /api/v1/contracts/{number}/addendums/{id}/pdf` (#818).
 *
 * It answers `200 application/pdf`, so the request asks for a blob, and a refusal's body is read out
 * of the Blob as the preview does.
 *
 * ⚠ **Unlike the other addendum sources, a `404` is NOT `unavailable`.** Those fail soft on a bare
 * `404` because their route may not have shipped; this route has, so a `404` means this addendum is
 * gone, and saying "the server does not offer it" would send the user looking for a missing feature.
 * It reads `failed`, with the server's detail and `traceId` when there are any. Only a status of `0`
 * (nothing answered) is `unavailable`.
 */
export declare class HttpAddendumPdfSource implements AddendumPdfSource {
  private readonly http;
  private readonly baseUrl;
  pdf(contractNumber: string, addendumId: number): Observable<AddendumCall<Blob>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpAddendumPdfSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The stored-addendum PDF over sample data, for the playground and specs (#818).
 *
 * It answers a one-page PDF naming the contract and the addendum id, so a screenshot shows what the
 * request carried.
 */
export declare class SampleAddendumPdfSource implements AddendumPdfSource {
  pdf(contractNumber: string, addendumId: number): Observable<AddendumCall<Blob>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleAddendumPdfSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The stored-addendum list over sample data, for the playground and specs (#818). Sample data, never
 * read from CTRM.
 *
 * The sample contract has a current addendum and one superseded; every other contract has none.
 */
export declare class SampleAddendumListSource implements AddendumListSource {
  list(contractNumber: string): Observable<AddendumCall<ContractAddendumList>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleAddendumListSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * An addendum CWS stored for a contract (#818), as the server's list of them says (#858): enough to
 * open its PDF (`ADDENDUM_PDF_SOURCE`) and to name the CTRM document it became, when there is one.
 */
export interface StoredAddendum {
  readonly contractNumber: string;
  readonly addendumId: number;
  readonly documentId: string | null;
}
/** What the record shows of a contract's stored addendums: the current one, and how many came before. */
export interface StoredAddendumSummary {
  readonly current: StoredAddendum | null;
  readonly earlier: number;
}
/**
 * Reads the server's list (#858) down to what the record shows.
 *
 * `current` is the entry whose id is `currentId`, and only that: with no `currentId`, or one no entry
 * has, it is `null`. It never falls back to the newest, because a withdrawn addendum is not current.
 * `earlier` counts every other entry, **`Removed` documents included**, so a withdrawn-then-regenerated
 * contract reads "2 earlier versions". A body whose `addendums` is not an array reads as empty, and so
 * does no body at all: a `2xx` with an empty body still settles `done`.
 *
 * `documentId` is the entry's own, which is CTRM's document reference and `null` until CTRM reports
 * one. The nested `document.id` is CWS's stored-document id, a different id space, so it is never used
 * in its place.
 */
export declare function summarizeAddendumList(contractNumber: string, list: ContractAddendumList | null | undefined): StoredAddendumSummary;
/**
 * The real documents routes (F10.2).
 *
 * - **The list**, `GET /api/v1/contracts/{n}/documents`, has LANDED (F10.1). Any failure of it,
 *   including a `404` or a `0`, is `failed`: the tab says the documents could not be loaded and
 *   offers Retry, and **never** renders an empty list for it.
 * - **The content**, `GET /api/v1/contracts/{n}/documents/{documentEntry}`, has LANDED too (F10.1's
 *   second half), keyed by the list's `documentEntry`. So a `404` is an answer about the document,
 *   not a missing route (#1004): only a `0` is `unavailable`. Its failures carry the server's detail
 *   and reference, read out of the Blob body by `problemDetailsInterceptor` (#925).
 */
export declare class HttpContractDocumentsSource implements ContractDocumentsSource {
  private readonly http;
  private readonly baseUrl;
  private documentsUrl;
  list(contractNumber: string): Observable<ContractDocumentsRead>;
  content(contractNumber: string, documentEntry: string): Observable<ContractDocumentContent>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractDocumentsSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A simulated document set for the playground and the specs (F10.2), in the landed route's shape.
 *
 * Every row is a state the backend simulator or TESTING has shown: an approved contract (so the
 * Contract group is visible under the first-approval rule) with its draft alongside, additional
 * documents in merge order, an RJO addendum, attachments, and one row each of the three states a
 * user cannot open: **pending** (still generating), **notStored** (listed, file gone, the commonest
 * state on TESTING) and **expired**. One attachment is not a PDF (#495), so the download-only path
 * can be seen: no such file has been observed on TESTING, but the content route already serves any
 * non-PDF, non-image type as `application/octet-stream`, and this answers it the same way.
 *
 * ⚠ **Sample data**: descriptions and file names are invented, and the content is a one-page PDF (or,
 * for the non-PDF row, a line of text) that says on its face that it is sample data, never a real
 * contract document.
 */
export declare const SAMPLE_CONTRACT_DOCUMENTS: readonly ContractDocument[];
/** The documents seam over {@link SAMPLE_CONTRACT_DOCUMENTS}. The same set for every contract. */
export declare class SampleContractDocumentsSource implements ContractDocumentsSource {
  private readonly documents;
  list(contractNumber: string): Observable<ContractDocumentsRead>;
  content(contractNumber: string, documentEntry: string): Observable<ContractDocumentContent>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleContractDocumentsSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A minimal, valid one-page PDF whose only content says it is sample data.
 *
 * Built rather than embedded so the cross-reference offsets are computed, not hand-counted: a PDF with
 * a wrong `xref` still opens in most viewers, which is exactly why a hand-counted one would go
 * unnoticed. ASCII only, so a character's index is its byte offset; anything else becomes `?`.
 */
export declare function samplePdf(title: string): Uint8Array<ArrayBuffer>;
/**
 * What `GET /api/v1/attachment-options` answers (#499, ADR-23): the formats, caps and document types an
 * upload accepts. **Configuration, never hard-coded here**: the formats may gain `docx` and the types
 * change without a client release, so the screen builds its `accept` attribute, its type picker and
 * its size hint from this alone.
 *
 * `maxSetBytes` and `maxDocumentsPerContract` are CTRM's caps on a contract's whole document set, the
 * addendum included, so the server can still refuse a set this screen let through (422
 * `errors["attachment.set"]`).
 */
export interface AttachmentOptions {
  /** Lower-case format names, such as `pdf`. */
  readonly acceptedFormats: readonly string[];
  /** The media types of the same formats, such as `application/pdf`. */
  readonly acceptedMediaTypes: readonly string[];
  readonly maxFileBytes: number;
  readonly maxSetBytes: number;
  readonly maxDocumentsPerContract: number;
  readonly documentTypes: readonly AttachmentDocumentType[];
}
/** One entry of the `document_type` controlled list. */
export interface AttachmentDocumentType {
  readonly code: string;
  readonly displayName: string;
}
/** Where a stored attachment stands. `Unknown` is anything else, and is never read as current. */
export type ContractAttachmentStatus = 'Current' | 'Superseded' | 'Removed' | 'Unknown';
/** One CWS attachment, as `GET /api/v1/contracts/{n}/attachments` lists it, newest first. */
export interface ContractAttachment {
  readonly documentId: string;
  readonly documentType: string;
  readonly fileName: string;
  readonly mediaType: string;
  readonly byteCount: number;
  readonly sha256: string;
  readonly status: ContractAttachmentStatus;
  readonly supersedesDocumentId: string | null;
  readonly createdByUpn: string;
  readonly createdAtUtc: string;
  readonly statusChangedAtUtc: string | null;
}
/**
 * One change an attachment write made, from the save's `attachments.changes`.
 *
 * - `Stored`: a new version is stored; `supersededDocumentId` names the one it replaced.
 * - `Resent`: the same bytes went to CTRM again, after the user confirmed.
 * - `Removed`: the document left the contract's current set.
 * - `AlreadyRemoved`: the removal went to CTRM again, after the user confirmed.
 */
export type ContractAttachmentChange = ContractWriteAttachmentChange;
/** A file the user picked, with the document type they chose for it. */
export interface AttachmentUpload {
  readonly file: File;
  readonly documentType: string;
}
/**
 * The optional flags of an attachment write. Each is sent only when `true`: absent is the server's
 * `false`, so a plain write is the request it always was.
 *
 * 🔴 `confirmResend` is sent **only after the user agreed** in the `409` dialog.
 */
export interface AttachmentWriteFlags {
  readonly confirmResend?: boolean;
  readonly sendNotification?: boolean;
}
/** How the options read came back. A failed read offers no upload, rather than a guessed one. */
export type AttachmentOptionsRead = {
  readonly kind: 'loaded';
  readonly options: AttachmentOptions;
} | {
  readonly kind: 'failed';
  readonly message: string;
  readonly correlationId: string | null;
};
/**
 * How a list read came back. 🔴 `failed` is never rendered as an empty list: "no attachments" is a
 * claim about the contract, and a failed read cannot make it.
 */
export type ContractAttachmentsRead = {
  readonly kind: 'loaded';
  readonly attachments: readonly ContractAttachment[];
} | {
  readonly kind: 'failed';
  readonly message: string;
  readonly correlationId: string | null;
};
/** How a content read came back. */
export type ContractAttachmentContent = {
  readonly kind: 'done';
  readonly blob: Blob;
} | {
  readonly kind: 'failed';
  readonly message: string;
  readonly correlationId: string | null;
};
/** The two `409` types, each meaning nothing was saved and the version did not move. */
export type AttachmentConflictType = 'attachment-already-attached' | 'attachment-already-removed';
/**
 * How an attachment write came back.
 *
 * - `saved`: the contract update ran; `result.attachments.changes` says what changed.
 * - `conflict`: a `409`. Nothing was saved. `detail` is the server's, shown verbatim; repeating the
 *   same request with `confirmResend` sends it again.
 * - `refused`: anything else, with every reason the server gave and its reference. `outcomeUnknown`
 *   is CTRM's lost answer (`502 ctrm-write-outcome-unknown`): the screen says to reload first.
 */
export type AttachmentWriteAnswer = {
  readonly kind: 'saved';
  readonly result: ContractWriteResult;
} | {
  readonly kind: 'conflict';
  readonly type: AttachmentConflictType;
  readonly detail: string;
  readonly correlationId: string | null;
} | {
  readonly kind: 'refused';
  readonly message: string;
  readonly fieldErrors: Readonly<Record<string, readonly string[]>>;
  readonly correlationId: string | null;
  readonly outcomeUnknown: boolean;
};
/**
 * A contract's CWS attachments (#499, F10.6): the options, the list, one file's content, and the three
 * writes, **each of which is its own contract update** (the version bumps and approval is required
 * again). CTRM's own document set is the Documents source, and is not this.
 */
export interface ContractAttachmentsSource {
  options(): Observable<AttachmentOptionsRead>;
  list(contractNumber: string): Observable<ContractAttachmentsRead>;
  content(contractNumber: string, documentId: string): Observable<ContractAttachmentContent>;
  add(contractNumber: string, upload: AttachmentUpload, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  replace(contractNumber: string, documentId: string, upload: AttachmentUpload, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  remove(contractNumber: string, documentId: string, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
}
/**
 * The attachments seam. ⚠ **Provided at the ROUTE level in the shell**, like the documents seam, so the
 * HTTP source lands in the record screen's lazy chunk. Injected optionally: a host without it gets no
 * attachments panel.
 */
export declare const CONTRACT_ATTACHMENTS_SOURCE: InjectionToken<ContractAttachmentsSource>;
/** The lower-case extension of a file name, or `''`. */
export declare function fileExtensionOf(name: string): string;
/**
 * The `accept` attribute for the file picker, from the options alone: each format as an extension,
 * then each media type.
 */
export declare function acceptAttributeOf(options: AttachmentOptions): string;
/** The accepted formats as the user reads them: `PDF`, `PDF or DOCX`. */
export declare function acceptedFormatsLabel(options: AttachmentOptions): string;
/** A byte count as the user reads it: `850 KB`, `10 MB`. */
export declare function readableBytes(bytes: number): string;
/**
 * Why a picked file cannot be sent, said before any request, or `null` when it may go.
 *
 * The server verifies the file by its CONTENT, so this is a courtesy that saves a round trip, never
 * the check: a renamed file passes here and is refused there. A Word file is refused **by name**, with
 * what to do about it, because that is the refusal a Phase 1 user will meet most (ruled 2026-10-18).
 */
export declare function pickedFileRefusal(file: File, options: AttachmentOptions): string | null;
/** A document type's display name, or its code when the options do not list it. */
export declare function documentTypeLabel(code: string, options: AttachmentOptions | null): string;
/**
 * The changes a write made, in plain words, for the outcome message: *"Stored as document 12,
 * replacing document 10."*. Empty when the answer carries none.
 */
export declare function attachmentChangesSentence(changes: readonly ContractAttachmentChange[]): string;
/**
 * The attachment routes (#499, F10.6; ADR-23), all landed on `main` with #917:
 * `GET /attachment-options`, `GET|POST /contracts/{n}/attachments`,
 * `GET /contracts/{n}/attachments/{id}/content`, `PUT|DELETE /contracts/{n}/attachments/{id}`.
 *
 * ### The refusal body, in either form
 *
 * The writes answer JSON, so their problem arrives as an object. The content read asks for a Blob, so
 * a refusal of it arrives as a Blob on `main` today, and as the parsed problem once the interceptor
 * reads binary error bodies (#925). {@link problemOf} reads both, so the refusal says its reason and
 * its reference either way.
 */
export declare class HttpContractAttachmentsSource implements ContractAttachmentsSource {
  private readonly http;
  private readonly baseUrl;
  private attachmentsUrl;
  options(): Observable<AttachmentOptionsRead>;
  list(contractNumber: string): Observable<ContractAttachmentsRead>;
  content(contractNumber: string, documentId: string): Observable<ContractAttachmentContent>;
  add(contractNumber: string, upload: AttachmentUpload, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  replace(contractNumber: string, documentId: string, upload: AttachmentUpload, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  remove(contractNumber: string, documentId: string, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  private write;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpContractAttachmentsSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The options the API ships with (`appsettings.json`, #499): PDF only in Phase 1, 10 MB a file, CTRM's
 * 25 MB and 50-document caps, and the two provisional document types.
 */
export declare const SAMPLE_ATTACHMENT_OPTIONS: AttachmentOptions;
/**
 * A simulated attachment set for the playground and the specs (#499, F10.6), newest first: one
 * **Current** version that replaced a **Superseded** one, and one **Removed** file.
 *
 * ⚠ **Sample data**: file names are invented and the content is a one-page PDF that says on its face
 * that it is sample data.
 */
export declare const SAMPLE_CONTRACT_ATTACHMENTS: readonly ContractAttachment[];
/**
 * The attachments seam over {@link SAMPLE_CONTRACT_ATTACHMENTS}, kept in memory per contract so an
 * upload, a replace and a removal show on the list. It answers the server's two `409`s the way the API
 * does: the same file (name, size and type here, the bytes there) under the same document type, and a
 * removal of a removed document, each until the request is repeated with `confirmResend`.
 */
export declare class SampleContractAttachmentsSource implements ContractAttachmentsSource {
  private readonly sets;
  private next;
  options(): Observable<AttachmentOptionsRead>;
  list(contractNumber: string): Observable<ContractAttachmentsRead>;
  content(_contractNumber: string, documentId: string): Observable<ContractAttachmentContent>;
  add(contractNumber: string, upload: AttachmentUpload, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  replace(contractNumber: string, documentId: string, upload: AttachmentUpload, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  remove(contractNumber: string, documentId: string, flags?: AttachmentWriteFlags): Observable<AttachmentWriteAnswer>;
  private setOf;
  private isSame;
  private store;
  private setStatus;
  private saved;
  private alreadyAttached;
  private refused;
  static ɵfac: i0.ɵɵFactoryDeclaration<SampleContractAttachmentsSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * What an entry says about the contract's attachments (#499, F10.6), one plain line each, or `[]`.
 *
 * Two shapes, both the API's own:
 * - an `AttachmentAdd` to `AttachmentRestore` row (21 to 24) carries
 *   `{ documentId, documentType, sha256, byteCount, mediaType, supersededDocumentId?, reason? }`;
 * - the contract's `Update` row carries `attachments: [{ action, documentId, supersededDocumentId }]`,
 *   and a `Resent` appears only there.
 *
 * 🔴 **Never a file name.** The audit stores none by design (D9), and this reads only ids and the
 * document type, so a file name cannot reach the timeline from here even if one were added later.
 */
export declare function auditAttachmentsOf(action: ContractAuditAction, detailsJson: string | null): readonly string[];
/**
 * **The workspace's links out to other systems** (docs/02 §2.3, §8; #756).
 *
 * Workspace configuration, not secrets: the standalone shell supplies them from its environment
 * files, a host supplies its own through `CwsWorkspaceConfig.links`. A link that is not configured
 * renders nothing, never a disabled stub, because a control that cannot work is noise on a toolbar.
 *
 * ⚠ **No URL here is invented.** On 2026-10-09 neither the Power BI report nor FileBound's
 * per-contract URL shape was known, so every environment ships both empty and the ask is in
 * `agents-docs/questions/2026-10-09-filebound-url-ask.md`.
 */
export interface CwsExternalLinks {
  /** The Power BI report, opened from the home screen's header. */
  readonly powerBi?: string;
  /**
   * FileBound's document archive for one contract, opened from the record screen's header.
   * `contractUrlTemplate` carries exactly one `{contract}`, which is replaced by the URL-encoded
   * contract number and nothing else.
   */
  readonly fileBound?: {
    readonly contractUrlTemplate: string;
  };
}
/** The one placeholder a FileBound template may carry. */
export declare const CONTRACT_PLACEHOLDER = "{contract}";
/**
 * The checked links. Defaults to none, so a screen mounted without `provideCwsWorkspace` (a test, a
 * playground route) renders no link rather than failing to inject.
 */
export declare const CWS_EXTERNAL_LINKS: InjectionToken<CwsExternalLinks>;
/**
 * Checks the configured links once, when the workspace is provided, and returns them with blanks
 * removed. Throws on anything it would otherwise have to guess about at click time.
 *
 * - A blank value is absent: the environment files carry `''` until someone supplies a URL.
 * - Every URL must be `https:`. That also refuses `javascript:` and `data:`, which Angular would
 *   sanitize to an `unsafe:` link rather than refuse.
 * - A FileBound template carries exactly one `{contract}`, and only in its path, query or fragment:
 *   the contract number must never be able to change which host the link goes to.
 *
 * ⚠ The messages are terse on purpose: this runs in the initial bundle (`provideCwsWorkspace`), whose
 * headroom under the 760 kB warning is about 1 kB (#678). They still name the setting and the rule.
 */
export declare function checkExternalLinks(links: CwsExternalLinks | undefined): CwsExternalLinks;
/**
 * FileBound's URL for one contract, or `null` when no template is configured or there is no number
 * (a create has none until CTRM issues it). The number is URL-encoded; nothing else is interpolated.
 *
 * ⚠ A file of its own so it lands in the record screen's lazy chunk. In `external-links.ts` it rode
 * into the initial bundle with `checkExternalLinks`, because the bundler splits by module (#756, #678).
 */
export declare function fileBoundUrlFor(links: CwsExternalLinks, contractNumber: string | null | undefined): string | null;
import { CODE_SEARCH_SOURCES, ConstraintCatalog, ControlPattern, DynamicFieldComponent, FormBuilderService, fieldWidthFor } from "@cws/shared-form-engine";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Injectable, InjectionToken, computed, inject, input, output, signal } from "@angular/core";
import { CODE_SEARCH_MAX_RESULTS, CODE_SEARCH_MIN_LENGTH, EMPTY_FILTER, HelpTipComponent, applyExportFields, compareBySorts, correlationIdOf, isRuleNode, remoteError, remoteLoaded, remoteLoading, toCsv } from "@cws/shared-ui";
import { Observable, Subject, catchError, combineLatest, delay, filter, firstValueFrom, forkJoin, from, map, of, shareReplay, startWith, switchMap, tap } from "rxjs";
import { HttpClient, HttpErrorResponse, HttpParams } from "@angular/common/http";
import { takeUntilDestroyed, toSignal } from "@angular/core/rxjs-interop";
import { NgTemplateOutlet } from "@angular/common";
import * as i1 from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { CdkConnectedOverlay, CdkOverlayOrigin, Overlay } from "@angular/cdk/overlay";
import { TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { ProblemKind, parseProblem, problemFrom } from "@cws/core-http";
const REFERENCE_ROUTES = {
	codes: "Codes",
	commodities: "Commodities",
	marketCodes: "MarketCodes",
	marketMonths: "MarketMonths",
	marketZones: "MarketZones",
	originDestinationCodes: "OriginDestinationCodes"
};
const ORIGIN_DESTINATION_SOURCE = new InjectionToken("ORIGIN_DESTINATION_SOURCE");
const ORIGIN_DESTINATION_SEARCH_SET = REFERENCE_ROUTES.originDestinationCodes;
const CODE_SEARCH_SOURCES_PROVIDER = {
	provide: CODE_SEARCH_SOURCES,
	useFactory: () => ({ [ORIGIN_DESTINATION_SEARCH_SET]: inject(ORIGIN_DESTINATION_SOURCE) })
};
function mergeCodeSearchHits(byCode, byName) {
	const seen = /* @__PURE__ */ new Set();
	const options = [];
	for (const option of [...byCode, ...byName]) {
		if (seen.has(option.code)) continue;
		seen.add(option.code);
		options.push(option);
	}
	return options.slice(0, CODE_SEARCH_MAX_RESULTS);
}
function commodityGroupsFrom(commodities) {
	if (commodities === null || commodities === void 0) return commodities;
	const members = /* @__PURE__ */ new Map();
	for (const commodity of commodities) {
		const group = commodity.group?.trim() ?? "";
		if (group !== "") members.set(group, [...members.get(group) ?? [], commodity.description]);
	}
	return [...members.entries()].sort(([left], [right]) => left.localeCompare(right)).map(([group, names]) => ({
		code: group,
		description: names.length <= 2 ? names.join(", ") : `${names.slice(0, 2).join(", ")} and ${names.length - 2} more`
	}));
}
const CONTRACT_CODE_PREFIX_LABELS = {
	BI: "Billing instructions",
	CT: "Contract type",
	CU: "Transportation unit type",
	DE: "Domestic/export",
	FA: "Special type",
	GG: "Grades to govern",
	GR: "Governing trade rule",
	GT: "Grade",
	PD: "Premium/discount scale",
	PS: "Price type",
	PT: "Payment terms",
	PZ: "Position zone",
	RC: "Routing",
	ST: "Ship period type",
	TC: "Transportation type",
	UM: "Unit of measure",
	WG: "Weights to govern"
};
const CONTRACT_CODE_PREFIXES = [
	"BI",
	"CT",
	"CU",
	"DE",
	"FA",
	"GG",
	"GR",
	"GT",
	"PD",
	"PS",
	"PT",
	"PZ",
	"RC",
	"ST",
	"TC",
	"UM",
	"WG"
];
const CONTRACT_TABS = [
	{
		id: "contract",
		label: "Contract Info"
	},
	{
		id: "pricing",
		label: "Pricing & Quantity"
	},
	{
		id: "shipping",
		label: "Shipping Info"
	},
	{
		id: "remarks",
		label: "Remarks"
	},
	{
		id: "additional",
		label: "Additional fields"
	}
];
const LOG_TAB = {
	id: "log",
	label: "Log"
};
const DOCUMENTS_TAB = {
	id: "documents",
	label: "Documents"
};
const ADDENDUM_TAB = {
	id: "addendum",
	label: "Addendum"
};
function toContractTabId(value) {
	if (value === LOG_TAB.id) return LOG_TAB.id;
	if (value === DOCUMENTS_TAB.id) return DOCUMENTS_TAB.id;
	if (value === ADDENDUM_TAB.id) return ADDENDUM_TAB.id;
	return CONTRACT_TABS.some((tab) => tab.id === value) ? value : "contract";
}
const CONTRACT_LAYOUT_SECTIONS = [
	{
		id: "identity",
		tab: "contract",
		title: "Contract",
		fields: [
			{
				componentName: "ContractPrefixType",
				ctrmField: "contract_prefix_type",
				groupHeading: "Contract number",
				label: "Contract number prefix — type",
				labelHidden: true,
				controlPattern: ControlPattern.SearchableCodeCombo,
				valuesFromConstraints: true,
				half: true,
				note: "Character 1 of the contract key — P for a purchase, S for a sale."
			},
			{
				componentName: "ContractPrefixCommodity",
				ctrmField: "contract_prefix_commodity",
				label: "Contract number prefix — commodity",
				labelHidden: true,
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "CommodityGroups",
				half: true,
				note: "Character 2 of the key — the commodity’s CAK group code (C for YELLOW CORN). Choosing a commodity selects its group; you can pick another listed group."
			},
			{
				componentName: "ContractNumber",
				ctrmField: "contract_number",
				label: "Contract number",
				labelHidden: true,
				controlPattern: ControlPattern.TextWithCounter,
				note: "The 7-character number only, not the whole key. Issued automatically when you start a new or copied contract, where the trade unit has that enabled — and always editable, so your own format can replace it. A number you type is checked before the contract is saved."
			},
			{
				componentName: "ContractSuffix",
				ctrmField: "contract_suffix",
				label: "Contract number suffix",
				labelHidden: true,
				half: true,
				controlPattern: ControlPattern.TextWithCounter,
				note: "Character 10 of the key, and usually empty."
			},
			{
				componentName: "ContractDate",
				ctrmField: "contract_date",
				label: "Contract date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			},
			{
				componentName: "Location",
				ctrmField: "location",
				label: "Trade unit",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Locations"
			},
			{
				componentName: "CommodityCode",
				ctrmField: "commodity_code",
				label: "Commodity",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Commodities"
			},
			{
				componentName: "TraderInitials",
				ctrmField: "trader_initials",
				label: "Trader",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives the trader’s name from these initials; the name itself is not sent on a write."
			},
			{
				componentName: "AlternateAddressLocation",
				ctrmField: "alternate_address_location",
				label: "Alternate address location",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TextCode",
				ctrmField: "text_code",
				label: "Text code",
				controlPattern: ControlPattern.QuantityDecimal
			},
			{
				componentName: "LanguageCode",
				ctrmField: "language_code",
				label: "Language code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM sets this from the contract’s text code, so what you type here is replaced when the contract is saved. There is no code list for it."
			},
			{
				componentName: "ContractCommodityDescription",
				ctrmField: "contract_commodity_description",
				label: "Contract commodity description",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives this from its paired code. What you type here may be discarded on save — send the code, not the words."
			},
			{
				componentName: "ContractTypeCode",
				ctrmField: "contract_type_code",
				label: "Contract type code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:CT"
			},
			{
				componentName: "SpecialType",
				ctrmField: "special_type",
				label: "Special type",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:FA"
			},
			{
				componentName: "DomesticExportCode",
				ctrmField: "domestic_export_code",
				label: "Domestic export code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:DE"
			},
			{
				componentName: "QuoteId",
				ctrmField: "quote_id",
				label: "Quote id",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "ContractStyle",
				ctrmField: "contract_style",
				label: "Contract style",
				controlPattern: ControlPattern.TextWithCounter
			}
		]
	},
	{
		id: "customer",
		tab: "contract",
		title: "Customer",
		fields: [
			{
				componentName: "CustomerId",
				ctrmField: "customer_id",
				label: "Customer id",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "CustomerName",
				ctrmField: "customer_name",
				label: "Customer name",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				emptyNote: "Filled in from the customer directory when a customer id is entered"
			},
			{
				componentName: "CustomerContract",
				ctrmField: "customer_contract",
				label: "Customer contract",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "CustomerMerchant",
				ctrmField: "customer_merchant",
				label: "Customer merchant",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PaymentTermsCode",
				ctrmField: "payment_terms_code",
				label: "Payment terms",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PT",
				descriptionField: "payment_terms_description",
				note: "Listed from CTRM’s payment terms table. Some locations check payment terms against a different table, so if the code you need is missing, ask before typing around it."
			},
			{
				componentName: "AdvisingBankNumber",
				ctrmField: "advising_bank_number",
				label: "Advising bank number",
				controlPattern: ControlPattern.QuantityDecimal
			}
		]
	},
	{
		id: "pricing",
		tab: "pricing",
		title: "Pricing",
		description: "Header prices. Individual price sequences are added after the contract exists.",
		fields: [
			{
				componentName: "PriceTypeCode",
				ctrmField: "price_type_code",
				label: "Price type",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PS"
			},
			{
				componentName: "Price",
				ctrmField: "price",
				label: "Price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "BasisPrice",
				ctrmField: "basis_price",
				label: "Basis price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "HedgePrice",
				ctrmField: "hedge_price",
				label: "Hedge price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "FreightAdjustment",
				ctrmField: "freight_adj",
				label: "Freight adjustment",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "BasisMarketMonth",
				ctrmField: "price_market_month",
				label: "Basis market month",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "HedgeMarketMonth",
				ctrmField: "hedge_market_month",
				label: "Hedge market month",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "ContractCurrency",
				ctrmField: "contract_currency",
				label: "Currency",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "MarketZone",
				ctrmField: "market_zone",
				label: "Market zone",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "MarketZones"
			},
			{
				componentName: "BasisLocation",
				ctrmField: "basis_location",
				label: "Basis location",
				controlPattern: ControlPattern.TextWithCounter,
				wide: true
			},
			{
				componentName: "PriceMarketCode",
				ctrmField: "price_market_code",
				label: "Price market code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM assigns this from the location and commodity. This screen shows the value it will store, so it is not chosen from a list."
			},
			{
				componentName: "HedgeMarketCode",
				ctrmField: "hedge_market_code",
				label: "Hedge market code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM assigns this from the location and commodity. This screen shows the value it will store, so it is not chosen from a list."
			},
			{
				componentName: "BrokerCurrency",
				ctrmField: "broker_currency",
				label: "Broker currency",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PremiumDiscountScaleCode",
				ctrmField: "premium_discount_scale_code",
				label: "Premium discount scale code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PD",
				descriptionField: "premium_discount_description"
			},
			{
				componentName: "IowaPriceLaterFlag",
				ctrmField: "iowa_price_later_flag",
				label: "Iowa price later flag",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			},
			{
				componentName: "IowaExerciseDate",
				ctrmField: "iowa_exercise_date",
				label: "Iowa exercise date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "quantity",
		tab: "pricing",
		title: "Quantity",
		fields: [
			{
				componentName: "Quantity",
				ctrmField: "quantity",
				label: "Quantity",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "quantity"
			},
			{
				componentName: "QuantityUnitOfMeasure",
				ctrmField: "quantity_uom",
				label: "Unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			},
			{
				componentName: "PriceUnitOfMeasure",
				ctrmField: "price_uom",
				label: "Price unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			},
			{
				componentName: "FreightAdjustmentUnitOfMeasure",
				ctrmField: "freight_adj_uom",
				label: "Freight adj. unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			},
			{
				componentName: "DescriptiveQuantity",
				ctrmField: "descriptive_quantity",
				label: "Descriptive quantity",
				controlPattern: ControlPattern.TextWithCounter,
				wide: true
			},
			{
				componentName: "NumberOfLoads",
				ctrmField: "number_of_loads",
				label: "Number of loads",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "WeightsToGovernCode",
				ctrmField: "weights_to_govern_code",
				label: "Weights to govern code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:WG",
				descriptionField: "weights_to_govern_description"
			},
			{
				componentName: "MaximumWeight",
				ctrmField: "maximum_weight",
				label: "Maximum weight",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "quantity"
			},
			{
				componentName: "MaximumWeightUom",
				ctrmField: "maximum_weight_uom",
				label: "Maximum weight unit of measure",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TolerenceMore",
				ctrmField: "tolerence_more",
				label: "Tolerance more",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "TolerenceLess",
				ctrmField: "tolerence_less",
				label: "Tolerance less",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			}
		]
	},
	{
		id: "logistics",
		tab: "shipping",
		title: "Shipping and logistics",
		description: "Shipment dates are set per ship period, in Ship periods on this tab: up to 12, each with its own begin, end, late pickup and early delivery.",
		fields: [
			{
				componentName: "OriginCode",
				ctrmField: "origin_code",
				label: "Origin code",
				controlPattern: ControlPattern.EntityTypeahead,
				searchSet: ORIGIN_DESTINATION_SEARCH_SET,
				note: "Search by name or enter the exact code. CTRM checks it when you save."
			},
			{
				componentName: "OriginName",
				ctrmField: "origin_name",
				label: "Origin",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				note: "Derived by CTRM from the origin code above, and not sent on a write."
			},
			{
				componentName: "DestinationCode",
				ctrmField: "destination_code",
				label: "Destination code",
				controlPattern: ControlPattern.EntityTypeahead,
				searchSet: ORIGIN_DESTINATION_SEARCH_SET,
				note: "Search by name or enter the exact code. CTRM checks it when you save."
			},
			{
				componentName: "DestinationName",
				ctrmField: "destination_name",
				label: "Destination",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				note: "Derived by CTRM from the destination code above, and not sent on a write."
			},
			{
				componentName: "LatestShipmentDate",
				ctrmField: "latest_shipment_date",
				label: "Latest shipment date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			},
			{
				componentName: "ShipPeriodTypeCode",
				ctrmField: "ship_period_type_code",
				label: "Ship period type",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:ST"
			},
			{
				componentName: "ShipPeriodDescription",
				ctrmField: "ship_period_description",
				label: "Ship period description",
				controlPattern: ControlPattern.MultilineNote,
				wide: true
			},
			{
				componentName: "IncoTermsCode",
				ctrmField: "inco_terms_code",
				label: "Incoterms",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "IncoTermsDescription",
				ctrmField: "inco_terms_description",
				label: "Incoterms description",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				wide: true,
				note: "Derived by CTRM from the Incoterms code above, and not sent on a write."
			},
			{
				componentName: "NamedPlaceCode",
				ctrmField: "named_place_code",
				label: "Named place code",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "NamedPlace",
				ctrmField: "named_place",
				label: "Named place",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				wide: true,
				note: "Derived by CTRM from the named place code above, and not sent on a write."
			},
			{
				componentName: "PositionZoneCode",
				ctrmField: "position_zone_code",
				label: "Position zone code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PZ"
			},
			{
				componentName: "TransportationTypeCode",
				ctrmField: "transportation_type_code",
				label: "Transportation type code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:TC"
			},
			{
				componentName: "TransportationUnits",
				ctrmField: "transportation_units",
				label: "Transportation units",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "TransportationUnitTypeCode",
				ctrmField: "transportation_unit_type_code",
				label: "Transportation unit type code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:CU"
			},
			{
				componentName: "RoutingCode",
				ctrmField: "routing_code",
				label: "Routing code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:RC",
				descriptionField: "routing_description"
			},
			{
				componentName: "PrintInco",
				ctrmField: "print_inco",
				label: "Print inco",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PartialShipmentAllowed",
				ctrmField: "partial_shipment_allowed",
				label: "Partial shipment allowed",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TransshipmentAllowed",
				ctrmField: "transshipment_allowed",
				label: "Transshipment allowed",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TransportationModeNumber",
				ctrmField: "transportation_mode_number",
				label: "Transportation mode number",
				controlPattern: ControlPattern.QuantityDecimal
			},
			{
				componentName: "EquipmentConstraint",
				ctrmField: "equipment_constraint",
				label: "Equipment constraint",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "FreeTime",
				ctrmField: "free_time",
				label: "Free time",
				controlPattern: ControlPattern.TextWithCounter,
				kind: "number"
			},
			{
				componentName: "OtmDomain",
				ctrmField: "otm_domain",
				label: "OTM domain",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "RampCode1",
				ctrmField: "ramp_code_1",
				label: "Ramp code 1",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "RampCode2",
				ctrmField: "ramp_code_2",
				label: "Ramp code 2",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "RampCode3",
				ctrmField: "ramp_code_3",
				label: "Ramp code 3",
				controlPattern: ControlPattern.TextWithCounter
			}
		]
	},
	{
		id: "broker",
		tab: "contract",
		title: "Broker",
		description: "All four or none — a half-filled broker block is a commission that cannot be settled.",
		fields: [
			{
				componentName: "BrokerId",
				ctrmField: "broker_id",
				label: "Broker id",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "BrokerContract",
				ctrmField: "broker_contract",
				label: "Broker contract",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "BrokerRate",
				ctrmField: "broker_rate",
				label: "Broker rate",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "BrokerUnitOfMeasure",
				ctrmField: "broker_uom",
				label: "Broker unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			}
		]
	},
	{
		id: "quality",
		tab: "contract",
		title: "Quality and grading",
		fields: [
			{
				componentName: "GradeCode",
				ctrmField: "grade_code",
				label: "Grade code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:GT"
			},
			{
				componentName: "GradesToGovernCode",
				ctrmField: "grades_to_govern_code",
				label: "Grades to govern code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:GG",
				descriptionField: "grades_to_govern_description"
			},
			{
				componentName: "FoodForHumanConsumption",
				ctrmField: "food_for_human_consumption",
				label: "Food for human consumption",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "GmoCertificateQty",
				ctrmField: "gmo_certificate_qty",
				label: "GMO certificate quantity",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "quantity"
			}
		]
	},
	{
		id: "settlement",
		tab: "shipping",
		title: "Payment and billing",
		fields: [
			{
				componentName: "BillingInstructionsCode",
				ctrmField: "billing_instructions_code",
				label: "Billing instructions code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:BI",
				descriptionField: "billing_instructions_description"
			},
			{
				componentName: "FreightPaymentCode",
				ctrmField: "freight_payment_code",
				label: "Freight payment code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM accepts C, I or P here, or blank."
			},
			{
				componentName: "FreightPaymentTerms",
				ctrmField: "freight_payment_terms",
				label: "Freight payment terms",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "LetterOfCreditOpen",
				ctrmField: "letter_of_credit_open",
				label: "Letter of credit open",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			},
			{
				componentName: "LetterOfCreditExpiration",
				ctrmField: "letter_of_credit_expiration",
				label: "Letter of credit expiration",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "packaging",
		tab: "shipping",
		title: "Packaging",
		fields: [
			{
				componentName: "PackageDescription",
				ctrmField: "package_description",
				label: "Package description",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives this from its paired code. What you type here may be discarded on save — send the code, not the words."
			},
			{
				componentName: "PackagingNumber",
				ctrmField: "packaging_number",
				label: "Packaging number",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "PackagingUom",
				ctrmField: "packaging_uom",
				label: "Packaging unit of measure",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PackagingDescription",
				ctrmField: "packaging_description",
				label: "Packaging description",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives this from its paired code. What you type here may be discarded on save — send the code, not the words."
			}
		]
	},
	{
		id: "terms",
		tab: "additional",
		title: "Trade terms and options",
		fields: [
			{
				componentName: "GoverningTradeRuleCode",
				ctrmField: "governing_trade_rule_code",
				label: "Governing trade rule code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:GR",
				descriptionField: "governing_trade_rule_description"
			},
			{
				componentName: "AutoRelease",
				ctrmField: "auto_release",
				label: "Auto release",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PurchasedForInventory",
				ctrmField: "purchased_for_inventory",
				label: "Purchased for inventory",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "ImexCertificate",
				ctrmField: "imex_certificate",
				label: "IMEX certificate",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "OfferToPurchaseExpireDate",
				ctrmField: "offer_to_purchase_expire_date",
				label: "Offer to purchase expire date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			},
			{
				componentName: "ProvisionalDate",
				ctrmField: "provisional_date",
				label: "Provisional date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "other",
		tab: "additional",
		title: "Additional CTRM fields",
		gap: "Fields the CTRM contract structure accepts that no business rule names. They are here because the write surface is 108 fields and a form that silently carried 90 of them would look complete; grouping them apart is the honest alternative to inventing a home for each. The grouping is not yet confirmed by the business.",
		fields: [
			{
				componentName: "BuyersEquipment",
				ctrmField: "buyers_equipment",
				label: "Buyers equipment",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			},
			{
				componentName: "AddFuel",
				ctrmField: "add_fuel",
				label: "Add fuel",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			},
			{
				componentName: "AddFreight",
				ctrmField: "add_freight",
				label: "Add freight",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			}
		]
	}
];
const CONTRACT_LAYOUT_FIELDS = CONTRACT_LAYOUT_SECTIONS.flatMap((section) => section.fields);
const CONTRACT_WRITABLE_FIELDS = CONTRACT_LAYOUT_FIELDS.filter((field) => field.readOnly !== true);
const CONTRACT_READ_ONLY_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.readOnly === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_EMPTY_NOTES = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.emptyNote !== void 0).map((field) => [field.componentName, field.emptyNote]));
const CONTRACT_LAYOUT_FIELD_NOTES = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.note !== void 0).map((field) => [field.componentName, field.note]));
const CONTRACT_LAYOUT_SECTION_NOTES = Object.fromEntries(CONTRACT_LAYOUT_SECTIONS.filter((section) => section.gap !== void 0 || section.description !== void 0).map((section) => [section.id, section.gap ?? section.description]));
const CONTRACT_LAYOUT_WIDE_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.wide === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_HALF_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.half === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_GROUP_HEADINGS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.groupHeading !== void 0).map((field) => [field.componentName, field.groupHeading]));
const CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.labelHidden === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.map((field) => [field.componentName, field.ctrmField]));
const CONTRACT_LAYOUT_CTRM_FIELDS = CONTRACT_LAYOUT_FIELDS.map((field) => field.ctrmField);
const CONSTRAINT_VALUE_LABELS = { ContractPrefixType: {
	P: "Purchase",
	S: "Sale"
} };
function savedCodeDescriptions(values) {
	const saved = /* @__PURE__ */ new Map();
	for (const field of CONTRACT_LAYOUT_FIELDS) {
		if (field.descriptionField === void 0) continue;
		const code = textOf$1(values[field.ctrmField]);
		const description = textOf$1(values[field.descriptionField]);
		if (code !== "" && description !== "") saved.set(field.componentName, {
			code,
			description
		});
	}
	return saved;
}
function textOf$1(value) {
	return typeof value === "string" ? value.trim() : "";
}
const CONFIRM_CHG_CTRM_FIELDS = [
	"contract_date",
	"customer_id",
	"commodity_code",
	"quantity",
	"quantity_uom",
	"number_of_loads",
	"price",
	"price_uom",
	"basis_location",
	"grade_code",
	"contract_currency",
	"premium_discount_description",
	"weights_to_govern_description",
	"grades_to_govern_description",
	"governing_trade_rule_description",
	"routing_description",
	"payment_terms_description",
	"iowa_price_later_flag",
	"iowa_exercise_date",
	"offer_to_purchase_expire_date",
	"ship_period_description"
];
const CONFIRM_CHG_WHEN_UNPRICED = ["price_market_code", "price_market_month"];
function confirmChgComponents(priceTypeCode) {
	const ctrmFields = /* @__PURE__ */ new Set([...CONFIRM_CHG_CTRM_FIELDS, ...(priceTypeCode ?? "").trim().toUpperCase() === "U" ? CONFIRM_CHG_WHEN_UNPRICED : []]);
	return new Set(CONTRACT_LAYOUT_FIELDS.filter((field) => ctrmFields.has(field.ctrmField) || field.descriptionField !== void 0 && ctrmFields.has(field.descriptionField)).map((field) => field.componentName));
}
function destinationOf(field) {
	return field.destination ?? "ctrm";
}
const FAMILY_B_ADDENDUM_FIELD_SETS = [
	{
		id: "min-price-call",
		title: "Minimum price with a call",
		specialTypes: ["MNC", "MNP"],
		fields: [
			{
				componentName: "AddendumCallExchange",
				cwsField: "addendum_call_exchange",
				destination: "cws",
				label: "Call exchange",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "AddendumCallMonth",
				cwsField: "addendum_call_month",
				destination: "cws",
				label: "Call month",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "AddendumCallStrike",
				cwsField: "addendum_call_strike",
				destination: "cws",
				label: "Call strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumCallPremium",
				cwsField: "addendum_call_premium",
				destination: "cws",
				label: "Call premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumOptionExpiration",
				cwsField: "addendum_option_expiration",
				destination: "cws",
				label: "Option expiration",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "min-max",
		title: "Min/Max",
		specialTypes: ["XPC"],
		fields: [
			{
				componentName: "AddendumPutStrike",
				cwsField: "addendum_put_strike",
				destination: "cws",
				label: "Put strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumPutPremium",
				cwsField: "addendum_put_premium",
				destination: "cws",
				label: "Put premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumMinMaxCallStrike",
				cwsField: "addendum_minmax_call_strike",
				destination: "cws",
				label: "Call strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumMinMaxCallPremium",
				cwsField: "addendum_minmax_call_premium",
				destination: "cws",
				label: "Call premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumNetPremium",
				cwsField: "addendum_net_premium",
				destination: "cws",
				label: "Net premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumMinMaxExpiration",
				cwsField: "addendum_minmax_expiration",
				destination: "cws",
				label: "Option expiration",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "premium-advance",
		title: "Premium advance",
		specialTypes: ["PREM"],
		fields: [
			{
				componentName: "AddendumPremiumCallMonth",
				cwsField: "addendum_premium_call_month",
				destination: "cws",
				label: "Call month",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "AddendumPremiumStrike",
				cwsField: "addendum_premium_strike",
				destination: "cws",
				label: "Strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumPremiumReceived",
				cwsField: "addendum_premium_received",
				destination: "cws",
				label: "Premium received",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			}
		]
	}
];
const CWS_CONTRACT_FIELDS = FAMILY_B_ADDENDUM_FIELD_SETS.flatMap((set) => set.fields);
function fieldDestinationViolations(input) {
	const violations = [];
	const layoutComponents = new Set(input.layout.map((field) => field.componentName));
	const layoutCtrmFields = new Set(input.layout.flatMap((field) => field.ctrmField === void 0 ? [] : [field.ctrmField]));
	for (const field of input.layout) if (destinationOf(field) !== "ctrm" || field.cwsField !== void 0) violations.push(`Layout row ${field.componentName} is declared as stored by CWS. The contract layout holds CTRM fields only; a CWS field belongs in its own field set.`);
	const seenCwsComponents = /* @__PURE__ */ new Set();
	for (const field of input.cwsFields) {
		const name = field.componentName;
		const stored = (field.cwsField ?? "").trim();
		if (destinationOf(field) !== "cws" || field.ctrmField !== void 0) violations.push(`CWS field ${name} carries a CTRM key or a CTRM destination.`);
		else if (stored === "") violations.push(`CWS field ${name} has no storage name.`);
		else if (input.ctrmFieldNames.has(stored)) violations.push(`CWS field ${name} is stored as "${stored}", which is a CTRM field in constraints.json. A CTRM field must not be re-homed to CWS; fix the CTRM name instead.`);
		else if (layoutCtrmFields.has(stored)) violations.push(`CWS field ${name} is stored as "${stored}", which a contract layout row maps to CTRM.`);
		if (layoutComponents.has(name)) violations.push(`CWS field ${name} shares a component name with a contract layout row, so its value would be read into the CTRM payload.`);
		else if (seenCwsComponents.has(name)) violations.push(`CWS field ${name} is declared twice.`);
		seenCwsComponents.add(name);
	}
	return violations;
}
const ADDENDUM_ENTRY_FIELD_PREFIX = "addendum_";
const LEGAL_TEMPLATE_FIELDS = {
	addendum_facility_address: {
		label: "Facility address",
		controlPattern: ControlPattern.TextWithCounter
	},
	addendum_facility_city_state_postal: {
		label: "Facility city, state and postal code",
		controlPattern: ControlPattern.TextWithCounter
	},
	addendum_facility_phone: {
		label: "Facility phone",
		controlPattern: ControlPattern.TextWithCounter
	},
	addendum_futures_reference: {
		label: "Futures reference",
		controlPattern: ControlPattern.TextWithCounter
	},
	addendum_premium_offer: {
		label: "Premium offer",
		controlPattern: ControlPattern.QuantityDecimal,
		kind: "price"
	},
	addendum_service_charge: {
		label: "Service charge",
		controlPattern: ControlPattern.QuantityDecimal,
		kind: "price"
	},
	addendum_target_date: {
		label: "Target date",
		controlPattern: ControlPattern.TextWithCounter
	},
	addendum_target_price: {
		label: "Target price",
		controlPattern: ControlPattern.QuantityDecimal,
		kind: "price"
	}
};
const ADDENDUM_FIELD_PRESENTATION = {
	...Object.fromEntries(FAMILY_B_ADDENDUM_FIELD_SETS.flatMap((set) => set.fields).map((field) => [field.cwsField, {
		label: field.label,
		controlPattern: field.controlPattern,
		...field.kind === void 0 ? {} : { kind: field.kind }
	}])),
	...LEGAL_TEMPLATE_FIELDS
};
function addendumFieldLabelFallback(field) {
	const spaced = (field.startsWith("addendum_") ? field.slice(9) : field).replace(/_+/g, " ").trim();
	return spaced === "" ? field : spaced.charAt(0).toUpperCase() + spaced.slice(1);
}
function isAddendumEntryField(field) {
	return field.startsWith("addendum_") && field.length > 9;
}
function addendumEntryFieldsOf(template) {
	if (template === null || template === void 0) return [];
	const content = template.templateContent ?? "";
	const positionOf = (placeholder) => {
		const match = new RegExp(`\\{\\{\\s*${escapeRegExp(placeholder.trim())}\\s*\\}\\}`).exec(content);
		return match === null ? Number.POSITIVE_INFINITY : match.index;
	};
	const first = /* @__PURE__ */ new Map();
	template.fields.forEach((mapping, index) => {
		const field = mapping.field.trim();
		if (!isAddendumEntryField(field)) return;
		const position = positionOf(mapping.placeholder);
		const seen = first.get(field);
		if (seen === void 0 || position < seen.position) first.set(field, {
			position,
			index: seen?.index ?? index
		});
	});
	return [...first.entries()].sort(([, a], [, b]) => a.position - b.position || a.index - b.index).map(([field]) => entryFieldFor(field));
}
function entryFieldFor(field) {
	const presentation = ADDENDUM_FIELD_PRESENTATION[field];
	return {
		componentName: field,
		cwsField: field,
		destination: "cws",
		label: presentation?.label ?? addendumFieldLabelFallback(field),
		controlPattern: presentation?.controlPattern ?? ControlPattern.TextWithCounter,
		...presentation?.kind === void 0 ? {} : { kind: presentation.kind }
	};
}
function addendumTypeFor(types, specialType) {
	const code = (specialType ?? "").trim();
	if (code === "") return null;
	return types.find((type) => type.specialType.trim() === code) ?? null;
}
function escapeRegExp(text) {
	return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
const ADDENDUM_SIGNATURE_ANCHOR = "{{sig__es_:signer1:signature}}";
const ADDENDUM_DATE_ANCHOR = "{{dte__es_:signer1:date}}";
const ADDENDUM_INITIALS_ANCHOR = "{{Int_es_:signer1:initials}}";
const ADDENDUM_REFUSED_SIGNATURE_FORM = "sig10__es_";
const REFUSED_SIGNATURE_FORM = new RegExp(ADDENDUM_REFUSED_SIGNATURE_FORM, "i");
function addendumAnchorProblems(templateContent, initialsOptional = false) {
	const content = templateContent ?? "";
	const problems = [];
	if (REFUSED_SIGNATURE_FORM.test(content)) problems.push(`The template uses the sig10__es_ signature form, which the signing service refuses. Replace it with ${ADDENDUM_SIGNATURE_ANCHOR}.`);
	if (!content.includes("{{sig__es_:signer1:signature}}")) problems.push(`The template has no signature anchor. Add ${ADDENDUM_SIGNATURE_ANCHOR}.`);
	if (!content.includes("{{dte__es_:signer1:date}}")) problems.push(`The template has no signature date anchor. Add ${ADDENDUM_DATE_ANCHOR}.`);
	if (!initialsOptional && !content.includes("{{Int_es_:signer1:initials}}")) problems.push(`The template has no initials anchor. Add ${ADDENDUM_INITIALS_ANCHOR}.`);
	return problems;
}
const GROUP_TITLES = {
	contract: "Contract",
	additional: "Additional documents",
	attachments: "Attachments",
	addendums: "Addendums",
	other: "Other"
};
const GROUP_ORDER = [
	"contract",
	"additional",
	"attachments",
	"addendums",
	"other"
];
const CONTRACT_ROLES = [
	"draft",
	"approved",
	"confirmed"
];
function hasFirstApproval(documents) {
	return documents.some((document) => document.role === "approved" || document.role === "confirmed");
}
function groupContractDocuments(documents) {
	const approved = hasFirstApproval(documents);
	const buckets = new Map(GROUP_ORDER.map((id) => [id, []]));
	let heldBack = 0;
	for (const document of documents) if (document.provenance === "rjoAddendum") buckets.get("addendums").push(document);
	else if (CONTRACT_ROLES.includes(document.role)) {
		if (approved) buckets.get("contract").push(document);
		else heldBack++;
	} else if (document.role === "additional") buckets.get("additional").push(document);
	else if (document.role === "attachment") buckets.get("attachments").push(document);
	else buckets.get("other").push(document);
	buckets.set("contract", [...buckets.get("contract")].sort(byContractRole));
	buckets.set("additional", [...buckets.get("additional")].sort(byAppearance));
	buckets.set("addendums", [...buckets.get("addendums")].sort(byAppearance));
	return {
		groups: GROUP_ORDER.filter((id) => buckets.get(id).length > 0).map((id) => ({
			id,
			title: GROUP_TITLES[id],
			documents: buckets.get(id)
		})),
		heldBack,
		approved
	};
}
function byContractRole(left, right) {
	return CONTRACT_ROLES.indexOf(left.role) - CONTRACT_ROLES.indexOf(right.role);
}
function byAppearance(left, right) {
	const a = left.appearanceSequence ?? Number.POSITIVE_INFINITY;
	const b = right.appearanceSequence ?? Number.POSITIVE_INFINITY;
	return a === b ? 0 : a < b ? -1 : 1;
}
const CWS_CONTRACT_EVENTS_VERSION = "1.0.0";
var CwsContractEvents = class CwsContractEvents {
	subject = new Subject();
	events$ = this.subject.asObservable();
	emit(event) {
		this.subject.next(event);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: CwsContractEvents,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: CwsContractEvents,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: CwsContractEvents,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const INVALID_PARAM_ALIASES = {};
const COMPONENT_BY_CTRM_FIELD = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.map((field) => [field.ctrmField, field.componentName]));
function looksLikeCtrmFieldName(name) {
	return /^[a-z][a-z0-9_]*$/.test(name);
}
function classifyInvalidParam(name) {
	const aliased = INVALID_PARAM_ALIASES[name] ?? name;
	const componentName = COMPONENT_BY_CTRM_FIELD[aliased];
	if (componentName !== void 0) return {
		kind: "control",
		ctrmField: aliased,
		componentName
	};
	return looksLikeCtrmFieldName(aliased) ? {
		kind: "unrenderedField",
		ctrmField: aliased
	} : {
		kind: "form",
		name
	};
}
function classifyInvalidParams(errors) {
	const controls = [];
	const unrenderedFields = [];
	const formReasons = [];
	for (const [name, reasons] of Object.entries(errors)) {
		const target = classifyInvalidParam(name);
		switch (target.kind) {
			case "control":
				controls.push({
					ctrmField: target.ctrmField,
					componentName: target.componentName,
					reasons
				});
				break;
			case "unrenderedField":
				unrenderedFields.push({
					ctrmField: target.ctrmField,
					reasons
				});
				break;
			case "form": formReasons.push(...reasons.map((reason) => `${target.name}: ${reason}`));
		}
	}
	return {
		controls,
		unrenderedFields,
		formReasons
	};
}
function positionalCode(customerId) {
	return customerId.slice(2, 7).trim();
}
function industryCodeSaysIntercompany(code) {
	return typeof code === "string" && code.toUpperCase().includes("IC");
}
function classifyIntercompany(facts) {
	if (industryCodeSaysIntercompany(facts.customerIndustryCode)) return {
		intercompany: true,
		branch: 1
	};
	const raw = facts.customerId ?? "";
	const code = raw.trim() === "" ? "" : positionalCode(raw);
	const codes = [...facts.locationCodes].map((value) => value.trim()).filter((value) => value !== "");
	if (code === "" || codes.length === 0) return {
		intercompany: false,
		reason: "cannotClassify"
	};
	return codes.includes(code) ? {
		intercompany: true,
		branch: 3
	} : {
		intercompany: false,
		reason: "noMatch"
	};
}
function isIntercompanyPurchase(verdict, contractPrefixType) {
	return verdict.intercompany && contractPrefixType?.trim().toUpperCase() === "P";
}
const CONTRACTS_API_URL = new InjectionToken("CONTRACTS_API_URL");
const AVAILABILITY_STATES = [
	"Available",
	"Closed",
	"NightRun",
	"Unreachable",
	"Unknown"
];
const WRITES_ALLOWED = ["Available"];
function writesBlockedBy(state) {
	return !WRITES_ALLOWED.includes(state);
}
function toAvailabilityState(value) {
	return typeof value === "string" && AVAILABILITY_STATES.includes(value) ? value : "Unknown";
}
const NOTICES = {
	Available: {
		title: "CTRM is available",
		detail: "Contracts can be read and saved as normal."
	},
	NightRun: {
		title: "CTRM is running its night job",
		detail: "Changes to contracts in CTRM are paused until the night run ends. Reading is unaffected, and templates and other Contract Workspace settings can still be saved."
	},
	Closed: {
		title: "CTRM is closed",
		detail: "CTRM is not accepting changes at the moment, so contracts cannot be saved. Reading is unaffected."
	},
	Unreachable: {
		title: "CTRM cannot be reached",
		detail: "Contracts cannot be saved while the connection is down. This is worth reporting if it persists."
	},
	Unknown: {
		title: "CTRM status is unknown",
		detail: "The status of CTRM could not be established, so saving is unavailable as a precaution. Reading is unaffected."
	}
};
function availabilityNotice(state) {
	const known = toAvailabilityState(state);
	return {
		...NOTICES[known],
		blocksWrites: writesBlockedBy(known)
	};
}
const BROKER_STAGE_CAUTION = "CTRM works this out rather than recording it, and defaults it to confirmed. A contract with no broker, or one edited since its last confirmation, shows as settled here — read it as nothing outstanding rather than as a broker having signed.";
const AFFIRMATIVE = [
	"approved",
	"confirmed",
	"complete",
	"completed",
	"yes"
];
function confirmationProgress(header) {
	const approval = stateOf(header.traderApprovalStatus);
	const customer = stateOf(header.customerConfirmStatus);
	const broker = stateOf(header.brokerConfirmStatus);
	return [
		{
			key: "approval",
			label: labelFor(approval, "Approved", "Not approved yet", "Approval status unclear"),
			value: trimmed(header.traderApprovalStatus),
			state: approval,
			caution: null
		},
		{
			key: "customer",
			label: labelFor(customer, "Customer confirmed", "Awaiting customer", "Customer status unclear"),
			value: trimmed(header.customerConfirmStatus),
			state: customer,
			caution: null
		},
		{
			key: "broker",
			label: labelFor(broker, "Broker: nothing outstanding", "Awaiting broker", "Broker status unclear"),
			value: trimmed(header.brokerConfirmStatus),
			state: broker,
			caution: BROKER_STAGE_CAUTION
		}
	];
}
function trimmed(value) {
	const text = (value ?? "").trim();
	return text === "" ? null : text;
}
function stateOf(value) {
	const text = trimmed(value);
	if (text === null) return "outstanding";
	return AFFIRMATIVE.includes(text.toLowerCase()) ? "complete" : "unknown";
}
function labelFor(state, complete, outstanding, unclear) {
	switch (state) {
		case "complete": return complete;
		case "outstanding": return outstanding;
		default: return unclear;
	}
}
var ConfirmationProgressComponent = class ConfirmationProgressComponent {
	header = input.required(...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	stages = computed(() => confirmationProgress(this.header()), ...ngDevMode ? [{ debugName: "stages" }] : /* istanbul ignore next */ []);
	brokerCaution = computed(() => this.stages().find((stage) => stage.key === "broker")?.caution ?? null, ...ngDevMode ? [{ debugName: "brokerCaution" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ConfirmationProgressComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ConfirmationProgressComponent,
		isStandalone: true,
		selector: "cms-confirmation-progress",
		inputs: { header: {
			classPropertyName: "header",
			publicName: "header",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0,
		template: `
    <ol class="cws:flex cws:flex-wrap cws:items-stretch cws:gap-2">
      @for (stage of stages(); track stage.key) {
        <li
          class="cws:flex cws:items-center cws:gap-2 cws:rounded cws:border cws:px-2.5 cws:py-1.5 cws:text-xs"
          [class.cws:border-emerald-300]="stage.state === 'complete'"
          [class.cws:bg-emerald-50]="stage.state === 'complete'"
          [class.cws:text-emerald-900]="stage.state === 'complete'"
          [class.cws:border-slate-300]="stage.state === 'outstanding'"
          [class.cws:bg-slate-50]="stage.state === 'outstanding'"
          [class.cws:text-slate-700]="stage.state === 'outstanding'"
          [class.cws:border-amber-300]="stage.state === 'unknown'"
          [class.cws:bg-amber-50]="stage.state === 'unknown'"
          [class.cws:text-amber-900]="stage.state === 'unknown'"
          [attr.title]="stage.caution"
        >
          <span aria-hidden="true">
            @switch (stage.state) {
              @case ('complete') { ✓ }
              @case ('outstanding') { · }
              @default { ? }
            }
          </span>
          <span class="cws:font-medium">{{ stage.label }}</span>
          @if (stage.value !== null && stage.state !== 'complete') {
            <!-- CTRM's own word, so a neutral stage says what it did not recognise. -->
            <span class="cws:font-mono cws:opacity-75">{{ stage.value }}</span>
          }
        </li>
      }
    </ol>

    @if (brokerCaution(); as caution) {
      <!--
        🔴 Rendered as TEXT, not only as a tooltip. A title attribute is invisible on a touch device
        and to anybody who does not hover, and this is the sentence that stops a lit broker segment
        being read as a broker having signed (#124).
      -->
      <p class="cws:mt-1.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ caution }}</p>
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ConfirmationProgressComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-confirmation-progress",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <ol class="cws:flex cws:flex-wrap cws:items-stretch cws:gap-2">
      @for (stage of stages(); track stage.key) {
        <li
          class="cws:flex cws:items-center cws:gap-2 cws:rounded cws:border cws:px-2.5 cws:py-1.5 cws:text-xs"
          [class.cws:border-emerald-300]="stage.state === 'complete'"
          [class.cws:bg-emerald-50]="stage.state === 'complete'"
          [class.cws:text-emerald-900]="stage.state === 'complete'"
          [class.cws:border-slate-300]="stage.state === 'outstanding'"
          [class.cws:bg-slate-50]="stage.state === 'outstanding'"
          [class.cws:text-slate-700]="stage.state === 'outstanding'"
          [class.cws:border-amber-300]="stage.state === 'unknown'"
          [class.cws:bg-amber-50]="stage.state === 'unknown'"
          [class.cws:text-amber-900]="stage.state === 'unknown'"
          [attr.title]="stage.caution"
        >
          <span aria-hidden="true">
            @switch (stage.state) {
              @case ('complete') { ✓ }
              @case ('outstanding') { · }
              @default { ? }
            }
          </span>
          <span class="cws:font-medium">{{ stage.label }}</span>
          @if (stage.value !== null && stage.state !== 'complete') {
            <!-- CTRM's own word, so a neutral stage says what it did not recognise. -->
            <span class="cws:font-mono cws:opacity-75">{{ stage.value }}</span>
          }
        </li>
      }
    </ol>

    @if (brokerCaution(); as caution) {
      <!--
        🔴 Rendered as TEXT, not only as a tooltip. A title attribute is invisible on a touch device
        and to anybody who does not hover, and this is the sentence that stops a lit broker segment
        being read as a broker having signed (#124).
      -->
      <p class="cws:mt-1.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ caution }}</p>
    }
  `
		}]
	}],
	propDecorators: { header: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "header",
			required: true
		}]
	}] }
});
const AVAILABILITY_SOURCE = new InjectionToken("AVAILABILITY_SOURCE");
var HttpAvailabilitySource = class HttpAvailabilitySource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answer = this.fetch();
	get() {
		return this.answer;
	}
	fetch() {
		return this.http.get(`${this.baseUrl}/availability`).pipe(map((body) => ({
			state: toAvailabilityState(body?.state),
			message: typeof body?.message === "string" ? body.message : null
		})), catchError(() => of({
			state: "Unknown",
			message: null
		})), startWith({
			state: "Unknown",
			message: null
		}), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAvailabilitySource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAvailabilitySource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpAvailabilitySource,
	decorators: [{ type: Injectable }]
});
var AvailabilityGate = class AvailabilityGate {
	source = inject(AVAILABILITY_SOURCE, { optional: true });
	current = toSignal(this.source?.get() ?? of(NOT_OFFERED), { initialValue: this.source === null ? NOT_OFFERED : UNKNOWN });
	isOffered = this.source !== null;
	state = computed(() => this.current().state, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	message = computed(() => this.current().message, ...ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []);
	notice = computed(() => availabilityNotice(this.state()), ...ngDevMode ? [{ debugName: "notice" }] : /* istanbul ignore next */ []);
	writesBlocked = computed(() => writesBlockedBy(this.state()), ...ngDevMode ? [{ debugName: "writesBlocked" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AvailabilityGate,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AvailabilityGate
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AvailabilityGate,
	decorators: [{ type: Injectable }]
});
const UNKNOWN = {
	state: "Unknown",
	message: null
};
const NOT_OFFERED = {
	state: "Available",
	message: null
};
var SampleAvailabilitySource = class SampleAvailabilitySource {
	answer = {
		state: "Available",
		message: null
	};
	get() {
		return of(this.answer);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAvailabilitySource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAvailabilitySource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleAvailabilitySource,
	decorators: [{ type: Injectable }]
});
const ME_SOURCE = new InjectionToken("ME_SOURCE");
function defaultTradeUnitOf(me) {
	if (me === null) return null;
	return (me.defaultTradeUnit === null ? void 0 : me.tradeUnits.find((unit) => unit.code === me.defaultTradeUnit)) ?? me.tradeUnits.find((unit) => unit.isDefault) ?? null;
}
var HttpMeSource = class HttpMeSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answer = this.fetch();
	get() {
		return this.answer;
	}
	fetch() {
		return this.http.get(`${this.baseUrl}/me`).pipe(map((me) => remoteLoaded({
			oid: me.user?.objectId ?? "",
			upn: me.user?.userName ?? null,
			isAdmin: me.isAdmin === true,
			defaultTradeUnit: me.defaultTradeUnit ?? null,
			status: me.status === "Available" ? "Available" : "Unavailable",
			tradeUnits: (me.tradeUnits ?? []).map((unit) => ({
				code: unit.code,
				isDefault: unit.isDefault === true,
				onboarded: unit.onboarded === true,
				permissions: unit.permissions ?? []
			})),
			onboardedTradeUnits: me.onboardedTradeUnits ?? [],
			onboardingGate: me.onboardingGate === "Report" ? "Report" : "Enforce"
		})), catchError(() => of(remoteError({ message: "Your trade units could not be loaded right now." }))), startWith(remoteLoading()), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpMeSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpMeSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpMeSource,
	decorators: [{ type: Injectable }]
});
var SampleMeSource = class SampleMeSource {
	answer = remoteLoaded(SAMPLE_ME);
	get() {
		return of(this.answer);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleMeSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleMeSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleMeSource,
	decorators: [{ type: Injectable }]
});
const SAMPLE_ME = {
	oid: "00000000-0000-0000-0000-000000000000",
	upn: "spec@scoular.com",
	isAdmin: false,
	defaultTradeUnit: "0210",
	status: "Available",
	onboardedTradeUnits: ["0210", "2087"],
	onboardingGate: "Enforce",
	tradeUnits: [
		{
			code: "0210",
			isDefault: true,
			onboarded: true,
			permissions: ["contracts:update"]
		},
		{
			code: "2087",
			isDefault: false,
			onboarded: true,
			permissions: []
		},
		{
			code: "4090",
			isDefault: false,
			onboarded: false,
			permissions: []
		}
	]
};
const PermissionKeys = {
	ContractsUpdate: "contracts:update",
	BrokerConfirmationsUpdate: "broker-confirmations:update",
	ContractsApprove: "contracts:approve",
	PricesUpdate: "prices:update",
	PricesApprove: "prices:approve",
	TemplatesManage: "templates:manage",
	SettingsManage: "settings:manage"
};
const PERMISSION_CATALOG_SOURCE = new InjectionToken("PERMISSION_CATALOG_SOURCE");
const SIMULATED_PERMISSION_CATALOG = {
	origin: "Simulated",
	provisional: true,
	entries: [
		{
			key: PermissionKeys.ContractsUpdate,
			name: "Create & edit contracts",
			description: "Create, edit and copy contracts; close and reopen; delete pending; save."
		},
		{
			key: PermissionKeys.BrokerConfirmationsUpdate,
			name: "Save broker confirmations",
			description: "The broker-confirmation save path."
		},
		{
			key: PermissionKeys.ContractsApprove,
			name: "Approve contracts",
			description: "Contract approval queue; approve and reject."
		},
		{
			key: PermissionKeys.PricesUpdate,
			name: "Edit prices",
			description: "Pricing screens; create, edit and delete price sequences."
		},
		{
			key: PermissionKeys.PricesApprove,
			name: "Approve prices",
			description: "Pricing approval queue; approve prices. CTRM's approver type still applies."
		},
		{
			key: PermissionKeys.TemplatesManage,
			name: "Manage templates",
			description: "Create and edit templates, and Save As Template."
		},
		{
			key: PermissionKeys.SettingsManage,
			name: "Administer the application",
			description: "Configure a trade unit: its form configuration (which onboards it), dropdown values and market months, and open the admin module. Held per trade unit."
		}
	]
};
var SamplePermissionCatalogSource = class SamplePermissionCatalogSource {
	get() {
		return of(remoteLoaded(SIMULATED_PERMISSION_CATALOG));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SamplePermissionCatalogSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SamplePermissionCatalogSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SamplePermissionCatalogSource,
	decorators: [{ type: Injectable }]
});
var HttpPermissionCatalogSource = class HttpPermissionCatalogSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answer = this.http.get(`${this.baseUrl}/admin/permissions`).pipe(map((wire) => {
		const rows = wire.rows ?? [];
		if (rows.length === 0) return SIMULATED_PERMISSION_CATALOG;
		return {
			origin: "Api",
			provisional: wire.provisional !== false,
			entries: rows.map((row) => ({
				key: row.key,
				name: row.displayName ?? row.key,
				description: row.description ?? ""
			}))
		};
	}), catchError(() => of(SIMULATED_PERMISSION_CATALOG)), map((catalog) => remoteLoaded(catalog)), startWith(remoteLoading()), shareReplay({
		bufferSize: 1,
		refCount: false
	}));
	get() {
		return this.answer;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpPermissionCatalogSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpPermissionCatalogSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpPermissionCatalogSource,
	decorators: [{ type: Injectable }]
});
const ROLE_ADMIN_SOURCE = new InjectionToken("ROLE_ADMIN_SOURCE");
function isEntraObjectId(value) {
	return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value.trim());
}
const OBJECT_ID_REFUSAL = "Enter the user's Entra object id: 32 hexadecimal digits in five hyphenated groups, not their email address.";
var HttpRoleAdminSource = class HttpRoleAdminSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get rolesUrl() {
		return `${this.baseUrl}/admin/roles`;
	}
	get userRolesUrl() {
		return `${this.baseUrl}/admin/user-roles`;
	}
	listRoles() {
		return settle$1(this.http.get(this.rolesUrl));
	}
	createRole(draft) {
		return settle$1(this.http.post(this.rolesUrl, draft));
	}
	updateRole(role, draft) {
		return settle$1(this.http.put(`${this.rolesUrl}/${encodeURIComponent(role.id)}`, draft, ifMatch$1(role.version)));
	}
	deleteRole(role) {
		return settle$1(this.http.delete(`${this.rolesUrl}/${encodeURIComponent(role.id)}`, ifMatch$1(role.version)).pipe(map(() => void 0)));
	}
	listAssignments(filter) {
		let params = new HttpParams();
		for (const [key, value] of [["tradeUnit", filter.tradeUnit], ["userObjectId", filter.userObjectId]]) {
			const trimmed = value?.trim();
			if (trimmed) params = params.set(key, trimmed);
		}
		return settle$1(this.http.get(this.userRolesUrl, { params }));
	}
	assign(draft) {
		if (!isEntraObjectId(draft.userObjectId)) return of(refusedObjectId());
		return settle$1(this.http.post(this.userRolesUrl, {
			...draft,
			userObjectId: draft.userObjectId.trim()
		}).pipe(map((body) => body.rows)));
	}
	setDefault(userObjectId, tradeUnit) {
		if (!isEntraObjectId(userObjectId)) return of(refusedObjectId());
		return settle$1(this.http.put(`${this.userRolesUrl}/${encodeURIComponent(userObjectId.trim())}/default`, { tradeUnit }).pipe(map((body) => body.rows)));
	}
	revoke(assignment) {
		if (!isEntraObjectId(assignment.userObjectId)) return of(refusedObjectId());
		const path = [
			assignment.userObjectId.trim(),
			assignment.roleId,
			assignment.tradeUnit.trim()
		].map(encodeURIComponent).join("/");
		return settle$1(this.http.delete(`${this.userRolesUrl}/${path}`).pipe(map((body) => body.rows)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpRoleAdminSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpRoleAdminSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpRoleAdminSource,
	decorators: [{ type: Injectable }]
});
function ifMatch$1(version) {
	return { headers: { "If-Match": `"${version}"` } };
}
function refusedObjectId() {
	return {
		kind: "failed",
		message: OBJECT_ID_REFUSAL,
		fieldErrors: { userObjectId: [OBJECT_ID_REFUSAL] }
	};
}
const UNAVAILABLE$3 = "Role administration is not available. The server does not offer it.";
const FAILED$4 = "The role service could not complete that. Please try again.";
function settle$1(request) {
	return request.pipe(map((value) => ({
		kind: "done",
		value
	})), catchError((error) => of(toCall$2(error))));
}
function toCall$2(error) {
	if (!(error instanceof HttpErrorResponse)) return {
		kind: "failed",
		message: FAILED$4
	};
	const problem = typeof error.error === "object" && error.error !== null ? error.error : null;
	if (error.status === 0 || error.status === 404 && !problem?.detail && !problem?.title) return {
		kind: "unavailable",
		reason: UNAVAILABLE$3
	};
	const reference = problem?.traceId ? { correlationId: problem.traceId } : {};
	if (error.status === 401 || error.status === 403) return {
		kind: "failed",
		message: "Role administration needs the Admin role. You are not signed in, or your account does not hold it.",
		...reference
	};
	if (error.status === 409) return {
		kind: "refused",
		message: problem?.detail ?? "The server refused that change. Reload to see the current state.",
		...reference
	};
	const fieldErrors = fieldErrorsOf$3(problem?.errors);
	const reasons = Object.values(fieldErrors).flat();
	return {
		kind: "failed",
		message: problem?.detail ?? (reasons.length > 0 ? reasons.join(" ") : null) ?? problem?.title ?? FAILED$4,
		...reference,
		...Object.keys(fieldErrors).length === 0 ? {} : { fieldErrors }
	};
}
function fieldErrorsOf$3(raw) {
	if (typeof raw !== "object" || raw === null) return {};
	const fields = {};
	for (const [key, value] of Object.entries(raw)) {
		const messages = Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
		if (messages.length > 0) fields[key] = messages;
	}
	return fields;
}
var SampleRoleAdminSource = class SampleRoleAdminSource {
	clock = Date.parse("2026-10-01T14:00:00Z");
	roles = [];
	assignments = [];
	constructor() {
		this.roles = [this.role({
			id: "00000000-0000-0000-0000-00000000a001",
			name: "Admin",
			displayName: "Administrator",
			description: "Built in. Every permission, in every trade unit.",
			isSystem: true,
			parentRoleId: null,
			permissionKeys: Object.values(PermissionKeys)
		}), this.role({
			id: "00000000-0000-0000-0000-00000000a002",
			name: "SampleContractWriter",
			displayName: "Sample contract writer",
			description: "Playground sample, not a proposed role.",
			isSystem: false,
			parentRoleId: null,
			permissionKeys: [PermissionKeys.ContractsUpdate, PermissionKeys.PricesUpdate]
		})];
		const user = "00000000-0000-0000-0000-0000000000b1";
		const writer = this.roles[1];
		this.assignments = [this.assignment(user, "sample.user@example.com", writer, "0210", true), this.assignment(user, "sample.user@example.com", writer, "0315", false)];
	}
	listRoles() {
		return done({
			storeOrigin: "InMemory",
			rows: [...this.roles]
		});
	}
	createRole(draft) {
		const clash = this.roles.find((role) => role.name.toLowerCase() === draft.name.trim().toLowerCase() || role.displayName.toLowerCase() === draft.displayName.trim().toLowerCase());
		if (clash) return of(invalid("name", `A role named "${clash.displayName}" already exists.`));
		const role = this.role({
			id: `00000000-0000-0000-0000-${(41216 + this.roles.length).toString(16).padStart(12, "0")}`,
			name: draft.name.trim(),
			displayName: draft.displayName.trim(),
			description: draft.description.trim(),
			isSystem: false,
			parentRoleId: draft.parentRoleId,
			permissionKeys: [...draft.permissionKeys].sort()
		});
		this.roles = [...this.roles, role];
		return done(role);
	}
	updateRole(role, draft) {
		const current = this.roles.find((candidate) => candidate.id === role.id);
		if (!current) return of(notFound());
		if (current.isSystem) return of(refused("The built-in Administrator role cannot be changed."));
		if (current.version !== role.version) return of(refused(STALE));
		const updated = this.role({
			...current,
			displayName: draft.displayName.trim(),
			description: draft.description.trim(),
			parentRoleId: draft.parentRoleId,
			permissionKeys: [...draft.permissionKeys].sort()
		});
		this.roles = this.roles.map((candidate) => candidate.id === role.id ? updated : candidate);
		return done(updated);
	}
	deleteRole(role) {
		const current = this.roles.find((candidate) => candidate.id === role.id);
		if (!current) return of(notFound());
		if (current.isSystem) return of(refused("The built-in Administrator role cannot be deleted."));
		if (current.version !== role.version) return of(refused(STALE));
		const holders = this.assignments.filter((assignment) => assignment.roleId === role.id).length;
		if (holders > 0) return of(refused(`"${current.displayName}" is held by ${holders} assignment(s). Revoke them first.`));
		const child = this.roles.find((candidate) => candidate.parentRoleId === role.id);
		if (child) return of(refused(`"${child.displayName}" inherits from "${current.displayName}". Change it first.`));
		this.roles = this.roles.filter((candidate) => candidate.id !== role.id);
		return done(void 0);
	}
	listAssignments(filter) {
		const tradeUnit = filter.tradeUnit?.trim();
		const user = filter.userObjectId?.trim().toLowerCase();
		return done({
			storeOrigin: "InMemory",
			rows: this.assignments.filter((row) => (!tradeUnit || row.tradeUnit === tradeUnit) && (!user || row.userObjectId.toLowerCase() === user))
		});
	}
	assign(draft) {
		if (!isEntraObjectId(draft.userObjectId)) return of(invalid("userObjectId", OBJECT_ID_REFUSAL));
		const role = this.roles.find((candidate) => candidate.id === draft.roleId);
		if (!role) return of(invalid("roleId", "Choose a role."));
		if (!/^\d{4}$/.test(draft.tradeUnit.trim())) return of(invalid("tradeUnit", "Enter a CTRM trade unit, such as 0210."));
		const user = draft.userObjectId.trim();
		if (this.rowsOf(user).some((row) => row.roleId === role.id && row.tradeUnit === draft.tradeUnit.trim())) return of(refused(`This user already holds "${role.displayName}" in ${draft.tradeUnit.trim()}.`));
		const first = this.rowsOf(user).length === 0;
		const row = this.assignment(user, draft.userUpn.trim(), role, draft.tradeUnit.trim(), first || draft.isDefault);
		this.assignments = [...this.assignments.map((existing) => existing.userObjectId === user && row.isDefault ? {
			...existing,
			isDefault: false
		} : existing), {
			...row,
			expiresAtUtc: draft.expiresAtUtc
		}];
		return done(this.rowsOf(user));
	}
	setDefault(userObjectId, tradeUnit) {
		const user = userObjectId.trim();
		const target = this.rowsOf(user).find((row) => row.tradeUnit === tradeUnit);
		if (!target) return of(notFound());
		this.assignments = this.assignments.map((row) => row.userObjectId !== user ? row : {
			...row,
			isDefault: row === target
		});
		return done(this.rowsOf(user));
	}
	revoke(assignment) {
		const user = assignment.userObjectId;
		const removed = this.assignments.find((row) => row.userObjectId === user && row.roleId === assignment.roleId && row.tradeUnit === assignment.tradeUnit);
		if (!removed) return of(notFound());
		this.assignments = this.assignments.filter((row) => row !== removed);
		if (removed.isDefault) {
			const remaining = this.rowsOf(user);
			const promoted = remaining.find((row) => row.tradeUnit === removed.tradeUnit) ?? [...remaining].sort((a, b) => a.assignedAtUtc.localeCompare(b.assignedAtUtc))[0];
			if (promoted) this.assignments = this.assignments.map((row) => row === promoted ? {
				...row,
				isDefault: true
			} : row);
		}
		return done(this.rowsOf(user));
	}
	rowsOf(user) {
		return this.assignments.filter((row) => row.userObjectId === user);
	}
	tick() {
		this.clock += 6e4;
		return new Date(this.clock).toISOString();
	}
	role(fields) {
		const now = this.tick();
		return {
			...fields,
			createdAtUtc: fields.createdAtUtc ?? now,
			updatedAtUtc: now,
			version: String(Date.parse(now))
		};
	}
	assignment(user, upn, role, tradeUnit, isDefault) {
		return {
			userObjectId: user,
			userUpn: upn,
			roleId: role.id,
			roleName: role.name,
			roleDisplayName: role.displayName,
			tradeUnit,
			isDefault,
			expiresAtUtc: null,
			isExpired: false,
			assignedByUpn: "sample.admin@example.com",
			assignedAtUtc: this.tick()
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleRoleAdminSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleRoleAdminSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleRoleAdminSource,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
const STALE = "This role changed since you opened it. Reload to see the current version, then make your change again.";
function done(value) {
	return of({
		kind: "done",
		value
	});
}
function refused(message) {
	return {
		kind: "refused",
		message
	};
}
function notFound() {
	return {
		kind: "failed",
		message: "That row no longer exists. Reload to see the current state."
	};
}
function invalid(field, message) {
	return {
		kind: "failed",
		message,
		fieldErrors: { [field]: [message] }
	};
}
const CONTRACT_IDEMPOTENCY_KEY = new InjectionToken("CONTRACT_IDEMPOTENCY_KEY", {
	providedIn: "root",
	factory: () => () => crypto.randomUUID()
});
const CONTRACT_WRITE_SOURCE = new InjectionToken("CONTRACT_WRITE_SOURCE");
var HttpContractWriteSource = class HttpContractWriteSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get contractsUrl() {
		return `${this.baseUrl}/contracts`;
	}
	fields(contractNumber) {
		return this.http.get(`${this.contractsUrl}/${encodeURIComponent(contractNumber)}/fields`).pipe(map((response) => ({
			...response,
			fields: response.fields ?? {}
		})));
	}
	create(fields, collections, options) {
		const key = options?.idempotencyKey;
		const attachments = options?.attachments ?? [];
		return this.http.post(this.contractsUrl, attachments.length === 0 ? bodyFor(fields, collections, options) : multipartCreate(bodyFor(fields, collections, options), attachments), key === void 0 ? {} : { headers: { "Idempotency-Key": key } });
	}
	update(contractNumber, fields, collections, options) {
		return this.http.put(`${this.contractsUrl}/${encodeURIComponent(contractNumber)}`, bodyFor(fields, collections, options));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractWriteSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractWriteSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractWriteSource,
	decorators: [{ type: Injectable }]
});
function multipartCreate(body, attachments) {
	const parts = attachments.map((attachment, index) => ({
		part: `file${index + 1}`,
		attachment
	}));
	const form = new FormData();
	form.append("contract", JSON.stringify({
		...body,
		attachments: parts.map(({ part, attachment }) => ({
			part,
			documentType: attachment.documentType
		}))
	}));
	for (const { part, attachment } of parts) form.append(part, attachment.file, attachment.file.name);
	return form;
}
function bodyFor(fields, collections, options) {
	return {
		fields,
		...collections === void 0 ? {} : { collections },
		...options?.sendNotification === true ? { sendNotification: true } : {},
		...options?.addendum === void 0 ? {} : { addendum: options.addendum },
		...options?.lmsFlag === void 0 ? {} : { lmsFlag: options.lmsFlag }
	};
}
const RECORD_DRAFT_STORE = new InjectionToken("RECORD_DRAFT_STORE", {
	providedIn: "root",
	factory: () => new SessionRecordDraftStore()
});
const DRAFT_STORAGE = new InjectionToken("DRAFT_STORAGE", {
	providedIn: "root",
	factory: () => sessionStorage
});
const DRAFT_CLOCK = new InjectionToken("DRAFT_CLOCK", {
	providedIn: "root",
	factory: () => () => /* @__PURE__ */ new Date()
});
const PREFIX = "cws.record-draft";
function draftStorageKey(key) {
	return `${PREFIX}:${key.mode}:${key.tradeUnit}:${key.contractNumber}`;
}
var SessionRecordDraftStore = class {
	storage = inject(DRAFT_STORAGE);
	now = inject(DRAFT_CLOCK);
	read(key) {
		const raw = this.readRaw(draftStorageKey(key));
		if (raw === null) return null;
		try {
			const parsed = JSON.parse(raw);
			if (!isDraft(parsed)) return null;
			const { idempotencyKey, ...rest } = parsed;
			return typeof idempotencyKey === "string" && idempotencyKey.trim() !== "" ? {
				...rest,
				idempotencyKey
			} : rest;
		} catch {
			return null;
		}
	}
	write(key, values, idempotencyKey) {
		if (Object.keys(values).length === 0) {
			this.clear(key);
			return;
		}
		const draft = idempotencyKey === void 0 ? {
			values,
			savedAt: this.now().toISOString()
		} : {
			values,
			savedAt: this.now().toISOString(),
			idempotencyKey
		};
		try {
			this.storage.setItem(draftStorageKey(key), JSON.stringify(draft));
		} catch {}
	}
	clear(key) {
		try {
			this.storage.removeItem(draftStorageKey(key));
		} catch {}
	}
	readRaw(storageKey) {
		try {
			return this.storage.getItem(storageKey);
		} catch {
			return null;
		}
	}
};
function isDraft(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return typeof candidate.savedAt === "string" && typeof candidate.values === "object" && candidate.values !== null && !Array.isArray(candidate.values);
}
const CONTRACT_NUMBER_SOURCE = new InjectionToken("CONTRACT_NUMBER_SOURCE");
var HttpContractNumberSource = class HttpContractNumberSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get numbersUrl() {
		return `${this.baseUrl}/contract-numbers`;
	}
	issue(request) {
		const body = "prefixType" in request && typeof request.prefixType === "string" ? {
			prefixType: request.prefixType,
			prefixCommodity: request.prefixCommodity,
			suffix: request.suffix ?? null
		} : {};
		return this.http.post(this.numbersUrl, body);
	}
	check(contractNumber) {
		return this.http.get(`${this.numbersUrl}/${encodeURIComponent(contractNumber)}`);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractNumberSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractNumberSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractNumberSource,
	decorators: [{ type: Injectable }]
});
const UNSET_DATE = "0001-01-01";
const TRUTHY_FLAGS = /* @__PURE__ */ new Set([
	"Y",
	"y",
	"T",
	"true"
]);
function coerceForControl(value, controlPattern) {
	if (value === null || value === void 0 || value === "") return null;
	switch (controlPattern) {
		case ControlPattern.QuantityDecimal: {
			const numeric = typeof value === "number" ? value : Number(String(value).replace(/,/g, ""));
			return Number.isFinite(numeric) ? numeric : null;
		}
		case ControlPattern.MaskedDate: {
			const iso = toIsoDate(value);
			return iso === UNSET_DATE ? null : iso;
		}
		case ControlPattern.ToggleFlag: return typeof value === "boolean" ? value : TRUTHY_FLAGS.has(String(value).trim());
		default: return typeof value === "string" ? value.trim() : String(value);
	}
}
function toCtrmValue(value, controlPattern) {
	if (controlPattern !== ControlPattern.ToggleFlag || value === null || value === void 0 || value === "") return value;
	return (typeof value === "boolean" ? value : TRUTHY_FLAGS.has(String(value).trim())) ? "Y" : "N";
}
function toIsoDate(value) {
	const text = String(value).trim();
	if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
	const packed = /^(\d{4})(\d{2})(\d{2})$/.exec(text);
	return packed === null ? text : `${packed[1]}-${packed[2]}-${packed[3]}`;
}
function seedFromCtrmValues(values) {
	const seeded = {};
	for (const field of CONTRACT_LAYOUT_FIELDS) {
		const coerced = coerceForControl(values[field.ctrmField], field.controlPattern);
		if (coerced !== null) seeded[field.componentName] = coerced;
	}
	return seeded;
}
const REMARK_TYPES = [
	{
		code: "P",
		label: "Final settlement"
	},
	...[
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9"
	].map((code) => ({
		code,
		label: `Remarks 0${code}`
	})),
	{
		code: "A",
		label: "Additional terms"
	}
];
function remarkKey(code) {
	return `remarks.${code}`;
}
const REMARK_NOTE_MAX_LENGTH = 72;
function remarkValuesOf(remarks) {
	const values = Object.fromEntries(REMARK_TYPES.map((type) => [type.code, ""]));
	for (const remark of remarks) {
		const code = (remark.type ?? "").trim().toUpperCase();
		if (code in values && values[code] === "") values[code] = remark.text ?? "";
	}
	return values;
}
function remarksChanged(original, current) {
	return REMARK_TYPES.some((type) => (original[type.code] ?? "") !== (current[type.code] ?? ""));
}
function remarksPayload(values) {
	return REMARK_TYPES.filter((type) => (values[type.code] ?? "").trim() !== "").map((type) => ({
		remark_type: type.code,
		remark_note: values[type.code]
	}));
}
const CONTRACT_COPY_IDENTITY_FIELDS = ["contract_number", "contract_suffix"];
const IDENTITY_FIELDS = new Set(CONTRACT_COPY_IDENTITY_FIELDS);
function copyExclusions(config) {
	const excluded = /* @__PURE__ */ new Set();
	for (const section of config?.sections ?? []) for (const field of section.fields) if (field.behaviour.excludeFromCopy) excluded.add(field.componentName);
	return excluded;
}
function copyableValues(sourceValues, excluded = /* @__PURE__ */ new Set()) {
	const copied = {};
	for (const field of CONTRACT_WRITABLE_FIELDS) {
		if (IDENTITY_FIELDS.has(field.ctrmField) || excluded.has(field.componentName)) continue;
		const coerced = coerceForControl(sourceValues[field.ctrmField], field.controlPattern);
		if (coerced !== null) copied[field.componentName] = coerced;
	}
	return copied;
}
const PRICED_COLLECTION = "prices";
const CONTRACT_TEXT_COLLECTION = "notes";
const READ_FROM_AGGREGATE = {
	ship_periods: (contract) => contract.shipPeriods,
	remarks: (contract) => contract.remarks
};
function planCollectionCopy(input) {
	const excluded = (name) => input.behaviour?.[name]?.excludeFromCopy === true;
	if (input.catalog === null || input.catalog === void 0) return {
		catalogKnown: false,
		outcomes: [],
		shipPeriods: [],
		remarks: [],
		pricesExcluded: excluded(PRICED_COLLECTION)
	};
	const source = input.source;
	const incomplete = new Set(source?.incompleteCollections ?? []);
	const carried = {};
	return {
		catalogKnown: true,
		outcomes: Object.entries(input.catalog).map(([name, collection]) => {
			if (name === PRICED_COLLECTION) return {
				name,
				status: excluded(name) ? "excluded" : "pricing"
			};
			if (!collection.writable) return {
				name,
				status: "neverCopied"
			};
			const read = READ_FROM_AGGREGATE[name];
			const rows = read !== void 0 && source !== null && !incomplete.has(name) ? read(source.contract) : null;
			if (excluded(name)) return {
				name,
				status: "excluded",
				...rows === null ? {} : { total: rows.length }
			};
			if (name === CONTRACT_TEXT_COLLECTION) return {
				name,
				status: "notYet"
			};
			if (rows === null) return {
				name,
				status: "unread"
			};
			if (rows.length === 0) return {
				name,
				status: "empty",
				total: 0
			};
			const kept = rows.slice(0, collection.maxItems);
			carried[name] = kept;
			return {
				name,
				status: "carried",
				rows: kept.length,
				total: rows.length,
				maxItems: collection.maxItems
			};
		}),
		shipPeriods: carried["ship_periods"] ?? [],
		remarks: carried["remarks"] ?? [],
		pricesExcluded: excluded(PRICED_COLLECTION)
	};
}
function collectionLabel(name) {
	return name.replace(/_/g, " ");
}
function describeCollectionCopy(plan, withPricing) {
	if (!plan.catalogKnown) return ["Ship periods, remarks and the other collections were not copied, because CTRM’s list of them could not be read. Enter them once this contract is saved."];
	const named = (status, keep = () => true) => plan.outcomes.filter((outcome) => outcome.status === status && keep(outcome)).map((outcome) => outcome.name);
	const sentences = [];
	const carried = plan.outcomes.filter((outcome) => outcome.status === "carried");
	if (carried.length > 0) sentences.push(`Its ${listCollections(carried.map((outcome) => outcome.name))} were copied as new rows.`);
	for (const outcome of carried) if (outcome.total !== void 0 && outcome.rows !== void 0 && outcome.total > outcome.rows) sentences.push(`Only the first ${outcome.rows} of its ${outcome.total} ${collectionLabel(outcome.name)} were copied: CTRM holds at most ${outcome.maxItems}.`);
	if (plan.pricesExcluded) sentences.push("Pricing was not copied: this trade unit excludes it from a copy.");
	else if (!withPricing) sentences.push("Pricing was not copied. Copy contract w/ pricing carries it.");
	const excluded = named("excluded", (outcome) => outcome.total !== 0).filter((name) => name !== PRICED_COLLECTION);
	if (excluded.length > 0) sentences.push(`Not copied, because this trade unit excludes them from a copy: ${listCollections(excluded)}.`);
	if (named("notYet").length > 0) sentences.push(`Not copied yet: ${listCollections(named("notYet"))} (the contract text).`);
	const unread = named("unread");
	if (unread.length > 0) sentences.push(`Not copied, because CWS could not read them from the source contract: ${listCollections(unread)}.`);
	const never = named("neverCopied");
	if (never.length > 0) sentences.push(`Never copied, because CTRM does not accept them on a contract write: ${listCollections(never)}.`);
	return sentences;
}
function listCollections(names) {
	const labels = names.map(collectionLabel);
	return labels.length <= 1 ? labels[0] ?? "" : `${labels.slice(0, -1).join(", ")} and ${labels[labels.length - 1]}`;
}
function shipPeriodRowOf(period) {
	return {
		beginDate: period.begin,
		endDate: period.end,
		quantity: period.quantity,
		latePickupDate: period.latePickup,
		earlyDeliveryDate: period.earlyDelivery
	};
}
function shipPeriodWriteRow(row) {
	return {
		begin_ship_date: row.beginDate,
		end_ship_date: row.endDate,
		ship_quantity: row.quantity,
		late_pickup_date: row.latePickupDate ?? null,
		early_delivery_date: row.earlyDeliveryDate ?? null
	};
}
const RECORD_ORIGIN_PARAM = "from";
const ORIGINS = {
	contracts: {
		label: "Contracts",
		path: "/"
	},
	approvals: {
		label: "Approvals",
		path: "/approvals",
		review: {
			label: "Review",
			path: (contractNumber) => `/approvals/${contractNumber}`
		}
	},
	pricing: {
		label: "Pricing",
		path: "/pricing",
		review: {
			label: "Prices",
			path: (contractNumber) => `/pricing/${contractNumber}`
		}
	}
};
function recordOrigin(value, fallback = "contracts") {
	return ORIGINS[recordOriginKey(value, fallback)];
}
function recordOriginKey(value, fallback = "contracts") {
	return isRecordOrigin(value) ? value : fallback;
}
function isRecordOrigin(value) {
	return value === "approvals" || value === "pricing" || value === "contracts";
}
function recordTrail(origin, contractNumber) {
	const queue = {
		label: origin.label,
		path: origin.path
	};
	if (origin.review === void 0 || contractNumber.trim() === "") return [queue];
	return [queue, {
		label: origin.review.label,
		path: origin.review.path(contractNumber)
	}];
}
var SaveAnnouncementStore = class SaveAnnouncementStore {
	pending = null;
	announce(contractNumber, outcome) {
		this.pending = {
			key: contractKey(contractNumber),
			outcome
		};
	}
	take(contractNumber) {
		return this.takeKey(contractKey(contractNumber));
	}
	announceForOrigin(origin, outcome) {
		this.pending = {
			key: originKey(origin),
			outcome
		};
	}
	takeForOrigin(origin) {
		return this.takeKey(originKey(origin));
	}
	takeKey(key) {
		const pending = this.pending;
		if (pending === null || pending.key !== key) return null;
		this.pending = null;
		return pending.outcome;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SaveAnnouncementStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SaveAnnouncementStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SaveAnnouncementStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const contractKey = (contractNumber) => `contract:${contractNumber.trim()}`;
const originKey = (origin) => `origin:${origin}`;
function wholeDaysBetween(iso, today) {
	if (iso === null || iso === "") return null;
	const parsed = Date.parse(`${iso.slice(0, 10)}T00:00:00Z`);
	if (Number.isNaN(parsed)) return null;
	const midnight = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
	return Math.round((midnight - parsed) / 864e5);
}
const FORM_CONFIG_SOURCE = new InjectionToken("FORM_CONFIG_SOURCE");
function emptiedTabs(tabs, sections) {
	const tabsWithAVisibleSection = new Set(sections.filter((section) => section.visible).map((section) => section.tab));
	return tabs.filter((tab) => tab.visible).filter((tab) => sections.some((section) => section.tab === tab.id)).filter((tab) => !tabsWithAVisibleSection.has(tab.id));
}
function tabsAfterCascade(tabs, sections) {
	const dropped = new Set(emptiedTabs(tabs, sections).map((tab) => tab.id));
	return tabs.filter((tab) => tab.visible && !dropped.has(tab.id));
}
const ADDED = "(added)";
const REMOVED = "(removed)";
const FIELD_PROPERTIES = [
	"visible",
	"required",
	"readOnly",
	"borderWarning",
	"excludeFromCopy",
	"excludeFromTemplateCopy",
	"section",
	"order"
];
const SECTION_PROPERTIES = [
	"label",
	"tab",
	"order",
	"visible"
];
const TAB_PROPERTIES = [
	"label",
	"order",
	"visible"
];
function diffConfigDocuments(before, after) {
	if (before === null) return [];
	return [
		...diffFields(before.fields ?? {}, after.fields ?? {}),
		...diffKeyed("section", before.sections ?? [], after.sections ?? [], SECTION_PROPERTIES),
		...diffKeyed("tab", before.tabs ?? [], after.tabs ?? [], TAB_PROPERTIES),
		...diffAttributes(before, after),
		...diffCollections(before.collections ?? {}, after.collections ?? {}),
		...diffRemarkTypes(before.remarkTypes ?? {}, after.remarkTypes ?? {})
	];
}
function diffFields(before, after) {
	const changes = [];
	for (const name of union(Object.keys(before), Object.keys(after))) {
		const was = before[name];
		const now = after[name];
		if (was === void 0 || now === void 0) {
			changes.push(whole("field", name, was, now));
			continue;
		}
		for (const property of FIELD_PROPERTIES) if (was[property] !== now[property]) changes.push({
			scope: "field",
			subject: name,
			property,
			before: render(was[property]),
			after: render(now[property])
		});
	}
	return changes;
}
function diffKeyed(scope, before, after, properties) {
	const changes = [];
	const byId = (items) => new Map(items.map((item) => [item.id, item]));
	const was = byId(before);
	const now = byId(after);
	for (const id of union([...was.keys()], [...now.keys()])) {
		const a = was.get(id);
		const b = now.get(id);
		if (a === void 0 || b === void 0) {
			changes.push(whole(scope, id, a, b));
			continue;
		}
		for (const property of properties) if (a[property] !== b[property]) changes.push({
			scope,
			subject: id,
			property: String(property),
			before: render(a[property]),
			after: render(b[property])
		});
	}
	return changes;
}
function diffAttributes(before, after) {
	const changes = [];
	const was = before.attributes;
	const now = after.attributes;
	if (was === void 0 || now === void 0) return changes;
	for (const property of ["autoCalculationMode", "pendingContractsEnabled"]) if (was[property] !== now[property]) changes.push({
		scope: "attribute",
		subject: property,
		property: "",
		before: render(was[property]),
		after: render(now[property])
	});
	const columns = (list) => list === void 0 ? "every column" : list.join(", ");
	if (columns(was.homeGridColumns) !== columns(now.homeGridColumns)) changes.push({
		scope: "attribute",
		subject: "homeGridColumns",
		property: "",
		before: columns(was.homeGridColumns),
		after: columns(now.homeGridColumns)
	});
	return changes;
}
const COLLECTION_PROPERTIES = ["excludeFromCopy", "excludeFromTemplateCopy"];
const COLLECTION_DEFAULT = {
	excludeFromCopy: false,
	excludeFromTemplateCopy: false
};
function diffCollections(before, after) {
	const changes = [];
	for (const name of union(Object.keys(before), Object.keys(after))) {
		const was = before[name] ?? COLLECTION_DEFAULT;
		const now = after[name] ?? COLLECTION_DEFAULT;
		for (const property of COLLECTION_PROPERTIES) if ((was[property] ?? false) !== (now[property] ?? false)) changes.push({
			scope: "collection",
			subject: name,
			property,
			before: render(was[property] ?? false),
			after: render(now[property] ?? false)
		});
	}
	return changes;
}
const REMARK_PROPERTIES = ["visible", "required"];
const REMARK_DEFAULT = {
	visible: true,
	required: false
};
function diffRemarkTypes(before, after) {
	const changes = [];
	for (const code of union(Object.keys(before), Object.keys(after))) {
		const was = {
			...REMARK_DEFAULT,
			...before[code]
		};
		const now = {
			...REMARK_DEFAULT,
			...after[code]
		};
		for (const property of REMARK_PROPERTIES) if (was[property] !== now[property]) changes.push({
			scope: "remark",
			subject: code,
			property,
			before: render(was[property]),
			after: render(now[property])
		});
	}
	return changes;
}
function whole(scope, subject, was, now) {
	return {
		scope,
		subject,
		property: was === void 0 ? ADDED : REMOVED,
		before: was === void 0 ? "" : "present",
		after: now === void 0 ? "" : "present"
	};
}
function union(first, second) {
	return [.../* @__PURE__ */ new Set([...first, ...second])];
}
function render(value) {
	if (value === null || value === void 0 || value === "") return "—";
	return String(value);
}
function normaliseCode(value) {
	return (value ?? "").trim().toUpperCase();
}
function narrowToConfigured(offered, configured) {
	if (configured.length === 0) return offered;
	const included = new Set(configured.filter((row) => row.include).map((row) => normaliseCode(row.value)));
	const excluded = new Set(configured.filter((row) => !row.include).map((row) => normaliseCode(row.value)));
	return offered.filter((option) => {
		const code = normaliseCode(option.code);
		if (excluded.has(code)) return false;
		return included.size === 0 || included.has(code);
	});
}
const TRADE_UNIT_VALUES_SOURCE = new InjectionToken("TRADE_UNIT_VALUES_SOURCE");
var HttpTradeUnitValuesSource = class HttpTradeUnitValuesSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	cache = /* @__PURE__ */ new Map();
	values(tradeUnit) {
		return this.fetch("values", tradeUnit);
	}
	marketMonths(tradeUnit) {
		return this.fetch("market-months", tradeUnit);
	}
	fetch(set, tradeUnit) {
		const key = `${set}:${tradeUnit}`;
		const cached = this.cache.get(key);
		if (cached !== void 0) return cached;
		const stream = this.http.get(`${this.baseUrl}/trade-unit-values/${set}`, { params: { tradeUnit } }).pipe(map((response) => response.rows ?? []), catchError(() => of([])), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
		this.cache.set(key, stream);
		return stream;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpTradeUnitValuesSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpTradeUnitValuesSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpTradeUnitValuesSource,
	decorators: [{ type: Injectable }]
});
const TRADER_EMAIL_SOURCE = new InjectionToken("TRADER_EMAIL_SOURCE");
const SAMPLE_TRADER_EMAIL = "someone@scoular.com";
var SampleTraderEmailSource = class SampleTraderEmailSource {
	emailFor(traderInitials) {
		return of(traderInitials.trim() === "" ? null : SAMPLE_TRADER_EMAIL);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleTraderEmailSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleTraderEmailSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleTraderEmailSource,
	decorators: [{ type: Injectable }]
});
const SIZED_MEMBER_MAX_LENGTH = 12;
var ContractFormComponent = class ContractFormComponent {
	formBuilder = inject(FormBuilderService);
	config = input.required(...ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []);
	tradeUnit = input.required(...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	facts = input({
		prefixType: "S",
		isClosed: false,
		isIntercompany: false,
		userCanEdit: true
	}, ...ngDevMode ? [{ debugName: "facts" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	instanceId = input("", ...ngDevMode ? [{ debugName: "instanceId" }] : /* istanbul ignore next */ []);
	visibleSections = input(null, ...ngDevMode ? [{ debugName: "visibleSections" }] : /* istanbul ignore next */ []);
	hideEmptyFields = input(false, ...ngDevMode ? [{ debugName: "hideEmptyFields" }] : /* istanbul ignore next */ []);
	fieldNotes = input({}, ...ngDevMode ? [{ debugName: "fieldNotes" }] : /* istanbul ignore next */ []);
	pinnedNotes = input({}, ...ngDevMode ? [{ debugName: "pinnedNotes" }] : /* istanbul ignore next */ []);
	emptyNotes = input({}, ...ngDevMode ? [{ debugName: "emptyNotes" }] : /* istanbul ignore next */ []);
	sectionNotes = input({}, ...ngDevMode ? [{ debugName: "sectionNotes" }] : /* istanbul ignore next */ []);
	wideFields = input({}, ...ngDevMode ? [{ debugName: "wideFields" }] : /* istanbul ignore next */ []);
	halfFields = input({}, ...ngDevMode ? [{ debugName: "halfFields" }] : /* istanbul ignore next */ []);
	fieldCtrmNames = input({}, ...ngDevMode ? [{ debugName: "fieldCtrmNames" }] : /* istanbul ignore next */ []);
	constraints = input(null, ...ngDevMode ? [{ debugName: "constraints" }] : /* istanbul ignore next */ []);
	hiddenLabelFields = input({}, ...ngDevMode ? [{ debugName: "hiddenLabelFields" }] : /* istanbul ignore next */ []);
	groupHeadings = input({}, ...ngDevMode ? [{ debugName: "groupHeadings" }] : /* istanbul ignore next */ []);
	readOnlyFields = input({}, ...ngDevMode ? [{ debugName: "readOnlyFields" }] : /* istanbul ignore next */ []);
	lockedFields = input({}, ...ngDevMode ? [{ debugName: "lockedFields" }] : /* istanbul ignore next */ []);
	fieldVerdicts = input({}, ...ngDevMode ? [{ debugName: "fieldVerdicts" }] : /* istanbul ignore next */ []);
	verdictsOf(fields) {
		const verdicts = this.fieldVerdicts();
		return fields.flatMap((field) => {
			const verdict = verdicts[field.componentName];
			return verdict === void 0 ? [] : [{
				componentName: field.componentName,
				verdict
			}];
		});
	}
	initialValues = input({}, ...ngDevMode ? [{ debugName: "initialValues" }] : /* istanbul ignore next */ []);
	defaultValues = input({}, ...ngDevMode ? [{ debugName: "defaultValues" }] : /* istanbul ignore next */ []);
	ready = output();
	fieldBlur = output();
	onFieldFocusOut(componentName) {
		this.fieldBlur.emit(componentName);
	}
	form = signal(null, ...ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []);
	sections = computed(() => {
		const shown = this.visibleSections();
		const hideEmpty = this.hidingEmptyFields();
		const values = hideEmpty ? this.form()?.value().fields ?? {} : {};
		return [...this.config().sections].filter((section) => section.visible).filter((section) => shown === null || shown.includes(section.componentName)).sort((a, b) => a.order - b.order).map((section) => ({
			...section,
			fields: [...section.fields].filter((field) => this.isFieldShown(field)).filter((field) => !hideEmpty || !isEmptyValue(values[field.componentName])).sort((a, b) => a.order - b.order)
		})).filter((section) => section.fields.length > 0);
	}, ...ngDevMode ? [{ debugName: "sections" }] : /* istanbul ignore next */ []);
	groupOf = computed(() => {
		const headings = this.groupHeadings();
		const hidden = this.hiddenLabelFields();
		const groups = /* @__PURE__ */ new Map();
		for (const section of this.config().sections) {
			let current = null;
			for (const field of [...section.fields].sort((a, b) => a.order - b.order)) {
				const heading = headings[field.componentName];
				if (heading !== void 0) current = {
					key: field.componentName,
					heading
				};
				else if (hidden[field.componentName] !== true) current = null;
				if (current !== null) groups.set(field.componentName, current);
			}
		}
		return groups;
	}, ...ngDevMode ? [{ debugName: "groupOf" }] : /* istanbul ignore next */ []);
	layouts = computed(() => {
		const groupOf = this.groupOf();
		const helps = this.helps();
		return this.sections().map((section) => {
			const items = [];
			for (const field of section.fields) {
				const group = groupOf.get(field.componentName);
				const previous = items.at(-1);
				if (group === void 0) items.push({
					kind: "field",
					key: field.componentName,
					field
				});
				else if (previous?.kind === "group" && previous.groupKey === group.key) previous.fields.push(field);
				else items.push({
					kind: "group",
					key: field.componentName,
					groupKey: group.key,
					heading: group.heading,
					fields: [field],
					help: []
				});
			}
			for (const item of items) if (item.kind === "group") item.help = item.fields.filter((member) => helps[member.componentName] !== void 0).map((member) => ({
				heading: member.label,
				source: helps[member.componentName].source ?? null,
				text: helps[member.componentName].text
			}));
			return {
				section,
				items
			};
		});
	}, ...ngDevMode ? [{ debugName: "layouts" }] : /* istanbul ignore next */ []);
	hidingEmpty = computed(() => {
		if (!this.hidingEmptyFields() || this.sections().length > 0) return false;
		const shown = this.visibleSections();
		return this.config().sections.some((section) => section.visible && (shown === null || shown.includes(section.componentName)) && section.fields.some((field) => this.isFieldShown(field)));
	}, ...ngDevMode ? [{ debugName: "hidingEmpty" }] : /* istanbul ignore next */ []);
	hidingEmptyFields = computed(() => this.readOnly() && this.hideEmptyFields(), ...ngDevMode ? [{ debugName: "hidingEmptyFields" }] : /* istanbul ignore next */ []);
	controlFor(componentName) {
		return this.form()?.control(componentName);
	}
	widths = computed(() => {
		const half = this.halfFields();
		const wide = this.wideFields();
		const widths = {};
		for (const section of this.config().sections) for (const field of section.fields) widths[field.componentName] = fieldWidthFor(field, {
			half: half[field.componentName] === true,
			wide: wide[field.componentName] === true
		});
		return widths;
	}, ...ngDevMode ? [{ debugName: "widths" }] : /* istanbul ignore next */ []);
	helps = computed(() => {
		const sources = this.fieldCtrmNames();
		return Object.fromEntries(Object.entries(this.fieldNotes()).map(([componentName, text]) => [componentName, {
			text,
			source: sources[componentName] ?? null
		}]));
	}, ...ngDevMode ? [{ debugName: "helps" }] : /* istanbul ignore next */ []);
	markers = computed(() => Object.fromEntries(Object.entries(this.readOnlyFields()).filter(([, refused]) => refused).map(([componentName]) => [componentName, "Set by CTRM"])), ...ngDevMode ? [{ debugName: "markers" }] : /* istanbul ignore next */ []);
	memberWidth(member) {
		const maxLength = member.constraints?.maxLength ?? null;
		if (this.widths()[member.componentName] === "small" || member.controlPattern !== ControlPattern.TextWithCounter || maxLength === null || maxLength > SIZED_MEMBER_MAX_LENGTH) return null;
		return `calc(${maxLength}ch + 2.5rem)`;
	}
	isNormalCell(componentName) {
		const width = this.widths()[componentName];
		return width === "medium" || width === "small";
	}
	visibleNoteFor(componentName) {
		const pinned = this.pinnedNotes()[componentName];
		if (pinned !== void 0) return pinned;
		const emptyNote = this.emptyNotes()[componentName];
		if (emptyNote === void 0) return;
		return isEmptyValue(this.controlFor(componentName)?.value) ? emptyNote : void 0;
	}
	isFieldShown(field) {
		return this.fieldStates().get(field.componentName)?.visible ?? field.behaviour.visible;
	}
	fieldStates = computed(() => {
		const built = this.form();
		if (built === null) return /* @__PURE__ */ new Map();
		const viewOnly = this.readOnly();
		const refused = this.readOnlyFields();
		const locked = this.lockedFields();
		const merged = /* @__PURE__ */ new Map();
		for (const [componentName, state] of built.states()) {
			const inactive = viewOnly || refused[componentName] === true || locked[componentName] === true;
			merged.set(componentName, inactive && !state.readOnly ? {
				...state,
				readOnly: true
			} : state);
		}
		return merged;
	}, ...ngDevMode ? [{ debugName: "fieldStates" }] : /* istanbul ignore next */ []);
	idPrefix = computed(() => this.instanceId() === "" ? "" : `${this.instanceId()}-`, ...ngDevMode ? [{ debugName: "idPrefix" }] : /* istanbul ignore next */ []);
	ngOnInit() {
		const snapshot = this.constraints();
		const built = this.formBuilder.build(this.config(), this.tradeUnit(), this.facts(), snapshot === null ? null : ConstraintCatalog.from(snapshot.document));
		const prefill = this.initialValues();
		built.seed(prefill);
		for (const componentName of Object.keys(prefill)) built.control(componentName)?.markAsPristine();
		if (!this.readOnly()) {
			const applicable = {};
			for (const [componentName, value] of Object.entries(this.defaultValues())) {
				const control = built.control(componentName);
				if (control === void 0 || control.value !== null && control.value !== "") continue;
				applicable[componentName] = value;
			}
			built.seed(applicable);
			for (const componentName of Object.keys(applicable)) built.control(componentName)?.markAsDirty();
		}
		this.form.set(built);
		this.ready.emit(built);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ContractFormComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ContractFormComponent,
		isStandalone: true,
		selector: "cms-contract-form",
		inputs: {
			config: {
				classPropertyName: "config",
				publicName: "config",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			tradeUnit: {
				classPropertyName: "tradeUnit",
				publicName: "tradeUnit",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			facts: {
				classPropertyName: "facts",
				publicName: "facts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			instanceId: {
				classPropertyName: "instanceId",
				publicName: "instanceId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			visibleSections: {
				classPropertyName: "visibleSections",
				publicName: "visibleSections",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideEmptyFields: {
				classPropertyName: "hideEmptyFields",
				publicName: "hideEmptyFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fieldNotes: {
				classPropertyName: "fieldNotes",
				publicName: "fieldNotes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pinnedNotes: {
				classPropertyName: "pinnedNotes",
				publicName: "pinnedNotes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyNotes: {
				classPropertyName: "emptyNotes",
				publicName: "emptyNotes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sectionNotes: {
				classPropertyName: "sectionNotes",
				publicName: "sectionNotes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wideFields: {
				classPropertyName: "wideFields",
				publicName: "wideFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			halfFields: {
				classPropertyName: "halfFields",
				publicName: "halfFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fieldCtrmNames: {
				classPropertyName: "fieldCtrmNames",
				publicName: "fieldCtrmNames",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			constraints: {
				classPropertyName: "constraints",
				publicName: "constraints",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hiddenLabelFields: {
				classPropertyName: "hiddenLabelFields",
				publicName: "hiddenLabelFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			groupHeadings: {
				classPropertyName: "groupHeadings",
				publicName: "groupHeadings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnlyFields: {
				classPropertyName: "readOnlyFields",
				publicName: "readOnlyFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lockedFields: {
				classPropertyName: "lockedFields",
				publicName: "lockedFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fieldVerdicts: {
				classPropertyName: "fieldVerdicts",
				publicName: "fieldVerdicts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initialValues: {
				classPropertyName: "initialValues",
				publicName: "initialValues",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			defaultValues: {
				classPropertyName: "defaultValues",
				publicName: "defaultValues",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			ready: "ready",
			fieldBlur: "fieldBlur"
		},
		host: { classAttribute: "cws:block" },
		providers: [FormBuilderService],
		ngImport: i0,
		template: "@if (form(); as contractForm) {\r\n  <!--\r\n    novalidate: validation is the form engine's, driven by constraints.json and the rules. The\r\n    browser's own bubbles would compete with the inline messages and say different things.\r\n  -->\r\n  <form [formGroup]=\"contractForm.group\" novalidate>\r\n    <!--\r\n      🔴 ONE STRUCTURED SCREEN IN THREE STATES (2026-10-13). The same sections, the same fields in the\r\n      same configured order, on the same layout, in view, edit and create. What changes is the field's\r\n      SURFACE: a value nobody can change here sits on a RECESSED read-only surface (a fill a step darker\r\n      than the panel, no visible border), and an editable value is the RAISED control. So moving between\r\n      modes changes how a field looks, never where it is.\r\n\r\n      🔴 **One panel per tab, its sections divided inside it.** A bordered panel per section stacked boxes\r\n      inside the record's own cards; one panel, matching the header card above it, with a hairline\r\n      between sections, gives the same grouping with one edge. The panel is not drawn at all when the\r\n      tab has no configured section (the Remarks tab), so it never shows an empty frame.\r\n\r\n      ⚠ Below 950 px docs/02a §7 is read-mostly in Phase 1: this form still works there for edit and\r\n      create, but it is not optimised for them, by the spec (#759).\r\n    -->\r\n    @if (layouts().length > 0) {\r\n    <div\r\n      class=\"cws:divide-y cws:divide-slate-200 cws:rounded-xl cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:divide-slate-700/70 cws:dark:border-slate-700 cws:dark:bg-slate-800/60 cws:dark:shadow-none\"\r\n    >\r\n      @for (layout of layouts(); track layout.section.componentName) {\r\n        <!--\r\n          ⚠ `data-section` is load-bearing rather than a test hook: `Ctrl+PgDn` / `Ctrl+PgUp`\r\n          (docs/02a §4.2) step between sections and need something addressable to scroll to and focus\r\n          into. Keyed on `componentName` because that is the identity the configuration orders by —\r\n          the visible label is a presentation string a trade unit may change.\r\n\r\n        -->\r\n        <div [attr.data-section]=\"layout.section.componentName\" class=\"cws:px-5 cws:pt-4 cws:pb-5\">\r\n          <!--\r\n            h3, matching the rest of the record screen: the shell owns the h1 and the page the h2. Small\r\n            capitals in a quiet tone, so it marks the group without competing with the values under it.\r\n          -->\r\n          <h3 class=\"cws:text-xs cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:dark:text-slate-400\">\r\n            {{ layout.section.label }}\r\n          </h3>\r\n\r\n          @if (sectionNotes()[layout.section.componentName]; as note) {\r\n            <!--\r\n              What the section deliberately does not carry — shipment dates living in a collection,\r\n              a customer name no route returns. Stated inside the section it applies to, because a\r\n              gap named at the top of the page is a gap nobody connects to the field in front of\r\n              them.\r\n            -->\r\n            <p class=\"cws:mt-1 cws:max-w-prose cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ note }}</p>\r\n          }\r\n\r\n          <!--\r\n            🔴 **A 12-column grid whose density steps with the screen** (2026-10-13). A NORMAL field is two\r\n            to a row from `md`, three from `xl`, four from `2xl`, so a wide window is used rather than left\r\n            empty and no field gets far more box than its value needs. A LONG field (the layout's \"spans\r\n            both columns\", or a description of 100+ characters) is two normal fields; a MULTILINE note is\r\n            the whole row. A compound group is one normal field. Below `md` it is one column.\r\n\r\n            ⚠ **A COMPACT field takes a normal CELL and a narrow BOX** (`max-w-56`). Giving it a narrower\r\n            span pushed every field after it off the column rhythm, so no two rows lined up; keeping the\r\n            cell keeps every row on the same columns, and the short box still says \"short value\". `widths()` says which, from what each field\r\n            already is (`fieldWidthFor`): nobody configures a row, a column or a pixel.\r\n\r\n            Fields are emitted in configured order and the grid flows in DOM order, so tab order follows\r\n            field order without any tabindex (02a §4.2). ⚠ No `dense` packing: it would reorder fields to\r\n            fill gaps, which is the one thing a form must not do. A field that does not fit the rest of a\r\n            row starts the next, and a multiline note therefore always starts its own row and ends it.\r\n\r\n            `items-start`: a tall cell (a field with a note or an error under it) does not stretch the\r\n            others in its row.\r\n          -->\r\n          <div class=\"cws:mt-4 cws:grid cws:grid-cols-12 cws:items-start cws:gap-x-6 cws:gap-y-4\">\r\n            @for (item of layout.items; track item.key) {\r\n              @if (item.kind === 'group') {\r\n                <!--\r\n                  🔴 **A COMPOUND FIELD**: several configured fields drawn as one, under one heading with\r\n                  one \"i\". The contract number is the case today: [S] [S] [1243150].\r\n\r\n                  Each member is its own control, with its own read-only state, validation and payload\r\n                  key; nothing is merged. Each keeps its own label as `sr-only` (the #196 ruling), and the\r\n                  heading is `aria-hidden` so it is not announced on every member.\r\n\r\n                  ⚠ The heading is drawn OVER the members' hidden label rows (`absolute`), which each keep\r\n                  their 20px (`cms-field`'s `min-h-5`). That is what lines the group's boxes up exactly\r\n                  with the single fields beside it in the same row.\r\n                -->\r\n                <div\r\n                  class=\"cws:relative cws:col-span-12 cws:md:col-span-6 cws:xl:col-span-4 cws:2xl:col-span-3\"\r\n                  data-field-width=\"group\"\r\n                  [attr.data-field-group]=\"item.groupKey\"\r\n                >\r\n                  <div class=\"cws:absolute cws:top-0 cws:left-0 cws:z-10 cws:flex cws:items-center cws:gap-1.5\">\r\n                    <span class=\"scoular-form-label\" aria-hidden=\"true\">{{ item.heading }}</span>\r\n                    @if (item.help.length > 0) {\r\n                      <cms-help-tip\r\n                        [label]=\"item.heading\"\r\n                        [tipId]=\"idPrefix() + item.groupKey + '-group-help'\"\r\n                        [entries]=\"item.help\"\r\n                      />\r\n                    }\r\n                  </div>\r\n\r\n                  <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n                    @for (member of item.fields; track member.componentName) {\r\n                      <!--\r\n                        A compact member keeps a narrow box. A short fixed-width member (the key's\r\n                        7-character number, #920) is sized for its width from the constraint document,\r\n                        never a hand-written one (ADR-7). Anything else shares what is left.\r\n                      -->\r\n                      <div\r\n                        [attr.data-group-member]=\"member.componentName\"\r\n                        [class.cws:w-16]=\"widths()[member.componentName] === 'small'\"\r\n                        [class.cws:shrink-0]=\"widths()[member.componentName] === 'small' || memberWidth(member) !== null\"\r\n                        [style.width]=\"memberWidth(member)\"\r\n                        [class.cws:min-w-0]=\"widths()[member.componentName] !== 'small' && memberWidth(member) === null\"\r\n                        [class.cws:flex-1]=\"widths()[member.componentName] !== 'small' && memberWidth(member) === null\"\r\n                      >\r\n                        <ng-container [ngTemplateOutlet]=\"cell\" [ngTemplateOutletContext]=\"{ field: member, inGroup: true }\" />\r\n                      </div>\r\n                    }\r\n                  </div>\r\n\r\n                  <!--\r\n                    #962: a member's verdict, under the whole row rather than under its narrow box. A live\r\n                    region that is always there, so a verdict arriving is announced, not just drawn.\r\n                  -->\r\n                  <div aria-live=\"polite\" data-group-verdicts>\r\n                    @for (entry of verdictsOf(item.fields); track entry.componentName) {\r\n                      <p\r\n                        [id]=\"idPrefix() + entry.componentName + '-verdict'\"\r\n                        class=\"cws:mt-1 cws:text-xs\"\r\n                        [class.cws:text-scoular-red-dark]=\"entry.verdict.tone === 'invalid'\"\r\n                        [class.cws:dark:text-scoular-red]=\"entry.verdict.tone === 'invalid'\"\r\n                        [class.cws:text-scoular-green-dark]=\"entry.verdict.tone === 'valid'\"\r\n                        [class.cws:dark:text-scoular-green]=\"entry.verdict.tone === 'valid'\"\r\n                        [class.cws:text-slate-500]=\"entry.verdict.tone === 'pending'\"\r\n                        [class.cws:dark:text-slate-400]=\"entry.verdict.tone === 'pending'\"\r\n                        [attr.data-field-verdict]=\"entry.verdict.tone\"\r\n                      >\r\n                        {{ entry.verdict.message }}\r\n                      </p>\r\n                    }\r\n                  </div>\r\n                </div>\r\n              } @else {\r\n                <!--\r\n                  ⚠ The width classes are spelled out here, not built from a string, so Tailwind's scanner\r\n                  sees every one of them. `data-field-width` names the width for the specs and for anyone\r\n                  reading the DOM.\r\n                -->\r\n                <div\r\n                  [attr.data-field-width]=\"widths()[item.field.componentName]\"\r\n                  class=\"cws:col-span-12\"\r\n                  [class.cws:md:col-span-6]=\"isNormalCell(item.field.componentName)\"\r\n                  [class.cws:xl:col-span-4]=\"isNormalCell(item.field.componentName)\"\r\n                  [class.cws:2xl:col-span-3]=\"isNormalCell(item.field.componentName)\"\r\n                  [class.cws:max-w-56]=\"widths()[item.field.componentName] === 'small'\"\r\n                  [class.cws:xl:col-span-8]=\"widths()[item.field.componentName] === 'large'\"\r\n                  [class.cws:2xl:col-span-6]=\"widths()[item.field.componentName] === 'large'\"\r\n                >\r\n                  <ng-container [ngTemplateOutlet]=\"cell\" [ngTemplateOutletContext]=\"{ field: item.field, inGroup: false }\" />\r\n                </div>\r\n              }\r\n            }\r\n          </div>\r\n        </div>\r\n      }\r\n    </div>\r\n    } @else if (hidingEmpty()) {\r\n      <!-- Every field on this tab is empty and the view is hiding them: say so, never a blank tab. -->\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-all-empty>\r\n        Every field here is empty. Turn off “Hide empty fields” to see them.\r\n      </p>\r\n    }\r\n  </form>\r\n}\r\n\r\n<!--\r\n  One field's cell.\r\n\r\n  `fieldStates()`, not `contractForm.states()`. The engine's state says what configuration and the\r\n  rules make of the field; this map is the same thing with the screen's read-only overrides folded in\r\n  — view mode, and the fields CTRM refuses on a write. Reading the engine's map directly here is what\r\n  would make view mode editable, so the indirection is load-bearing rather than a wrapper.\r\n-->\r\n<ng-template #cell let-field=\"field\" let-inGroup=\"inGroup\">\r\n  @if (controlFor(field.componentName); as control) {\r\n    @if (fieldStates().get(field.componentName); as state) {\r\n      <div (focusout)=\"onFieldFocusOut(field.componentName)\">\r\n        <!--\r\n          `skipTab`: a read-only field leaves the tab order while the form is editable, so Tab and\r\n          Enter go to what can be typed into (#314, JFrisbie 2026-10-06).\r\n\r\n          `display`: view mode draws every value on the quiet read-only surface.\r\n\r\n          `help`: the field's description, behind an \"i\" beside its label. A group member's is in the\r\n          group's one \"i\" instead.\r\n        -->\r\n        <cms-dynamic-field\r\n          [field]=\"field\"\r\n          [state]=\"state\"\r\n          [control]=\"control\"\r\n          [idPrefix]=\"idPrefix()\"\r\n          [hideLabel]=\"hiddenLabelFields()[field.componentName] === true\"\r\n          [skipTab]=\"state.readOnly && !readOnly()\"\r\n          [display]=\"readOnly()\"\r\n          [compact]=\"inGroup && widths()[field.componentName] === 'small'\"\r\n          [help]=\"inGroup ? null : (helps()[field.componentName] ?? null)\"\r\n          [marker]=\"markers()[field.componentName] ?? null\"\r\n          [verdict]=\"fieldVerdicts()[field.componentName] ?? null\"\r\n        />\r\n\r\n        <!-- #962: a single field's verdict. No empty live region per field: the box is described by it. -->\r\n        @if (!inGroup) {\r\n          @if (fieldVerdicts()[field.componentName]; as verdict) {\r\n            <p\r\n              [id]=\"idPrefix() + field.componentName + '-verdict'\"\r\n              class=\"cws:mt-1 cws:text-xs\"\r\n              [class.cws:text-scoular-red-dark]=\"verdict.tone === 'invalid'\"\r\n              [class.cws:dark:text-scoular-red]=\"verdict.tone === 'invalid'\"\r\n              [class.cws:text-scoular-green-dark]=\"verdict.tone === 'valid'\"\r\n              [class.cws:dark:text-scoular-green]=\"verdict.tone === 'valid'\"\r\n              [class.cws:text-slate-500]=\"verdict.tone === 'pending'\"\r\n              [class.cws:dark:text-slate-400]=\"verdict.tone === 'pending'\"\r\n              [attr.data-field-verdict]=\"verdict.tone\"\r\n            >\r\n              {{ verdict.message }}\r\n            </p>\r\n          }\r\n        }\r\n\r\n        @if (visibleNoteFor(field.componentName); as note) {\r\n          <!--\r\n            What the user needs to SEE, not look up: a precondition on the value (the Quantity\r\n            allocation), the outcome of something they just did (a Customer id confirmed), or why a\r\n            field is blank. Kept on screen deliberately; ordinary descriptions are in the \"i\".\r\n          -->\r\n          <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-field-note>\r\n            {{ note }}\r\n          </p>\r\n        }\r\n      </div>\r\n    }\r\n  }\r\n</ng-template>\r\n",
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.FormGroupDirective,
				selector: "[formGroup]",
				inputs: ["formGroup"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: DynamicFieldComponent,
				selector: "cms-dynamic-field",
				inputs: [
					"field",
					"state",
					"control",
					"idPrefix",
					"hideLabel",
					"skipTab",
					"help",
					"marker",
					"display",
					"compact",
					"verdict"
				]
			},
			{
				kind: "component",
				type: HelpTipComponent,
				selector: "cms-help-tip",
				inputs: [
					"label",
					"tipId",
					"entries"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ContractFormComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-contract-form",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				NgTemplateOutlet,
				ReactiveFormsModule,
				DynamicFieldComponent,
				HelpTipComponent
			],
			providers: [FormBuilderService],
			host: { class: "cws:block" },
			template: "@if (form(); as contractForm) {\r\n  <!--\r\n    novalidate: validation is the form engine's, driven by constraints.json and the rules. The\r\n    browser's own bubbles would compete with the inline messages and say different things.\r\n  -->\r\n  <form [formGroup]=\"contractForm.group\" novalidate>\r\n    <!--\r\n      🔴 ONE STRUCTURED SCREEN IN THREE STATES (2026-10-13). The same sections, the same fields in the\r\n      same configured order, on the same layout, in view, edit and create. What changes is the field's\r\n      SURFACE: a value nobody can change here sits on a RECESSED read-only surface (a fill a step darker\r\n      than the panel, no visible border), and an editable value is the RAISED control. So moving between\r\n      modes changes how a field looks, never where it is.\r\n\r\n      🔴 **One panel per tab, its sections divided inside it.** A bordered panel per section stacked boxes\r\n      inside the record's own cards; one panel, matching the header card above it, with a hairline\r\n      between sections, gives the same grouping with one edge. The panel is not drawn at all when the\r\n      tab has no configured section (the Remarks tab), so it never shows an empty frame.\r\n\r\n      ⚠ Below 950 px docs/02a §7 is read-mostly in Phase 1: this form still works there for edit and\r\n      create, but it is not optimised for them, by the spec (#759).\r\n    -->\r\n    @if (layouts().length > 0) {\r\n    <div\r\n      class=\"cws:divide-y cws:divide-slate-200 cws:rounded-xl cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:divide-slate-700/70 cws:dark:border-slate-700 cws:dark:bg-slate-800/60 cws:dark:shadow-none\"\r\n    >\r\n      @for (layout of layouts(); track layout.section.componentName) {\r\n        <!--\r\n          ⚠ `data-section` is load-bearing rather than a test hook: `Ctrl+PgDn` / `Ctrl+PgUp`\r\n          (docs/02a §4.2) step between sections and need something addressable to scroll to and focus\r\n          into. Keyed on `componentName` because that is the identity the configuration orders by —\r\n          the visible label is a presentation string a trade unit may change.\r\n\r\n        -->\r\n        <div [attr.data-section]=\"layout.section.componentName\" class=\"cws:px-5 cws:pt-4 cws:pb-5\">\r\n          <!--\r\n            h3, matching the rest of the record screen: the shell owns the h1 and the page the h2. Small\r\n            capitals in a quiet tone, so it marks the group without competing with the values under it.\r\n          -->\r\n          <h3 class=\"cws:text-xs cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:dark:text-slate-400\">\r\n            {{ layout.section.label }}\r\n          </h3>\r\n\r\n          @if (sectionNotes()[layout.section.componentName]; as note) {\r\n            <!--\r\n              What the section deliberately does not carry — shipment dates living in a collection,\r\n              a customer name no route returns. Stated inside the section it applies to, because a\r\n              gap named at the top of the page is a gap nobody connects to the field in front of\r\n              them.\r\n            -->\r\n            <p class=\"cws:mt-1 cws:max-w-prose cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ note }}</p>\r\n          }\r\n\r\n          <!--\r\n            🔴 **A 12-column grid whose density steps with the screen** (2026-10-13). A NORMAL field is two\r\n            to a row from `md`, three from `xl`, four from `2xl`, so a wide window is used rather than left\r\n            empty and no field gets far more box than its value needs. A LONG field (the layout's \"spans\r\n            both columns\", or a description of 100+ characters) is two normal fields; a MULTILINE note is\r\n            the whole row. A compound group is one normal field. Below `md` it is one column.\r\n\r\n            ⚠ **A COMPACT field takes a normal CELL and a narrow BOX** (`max-w-56`). Giving it a narrower\r\n            span pushed every field after it off the column rhythm, so no two rows lined up; keeping the\r\n            cell keeps every row on the same columns, and the short box still says \"short value\". `widths()` says which, from what each field\r\n            already is (`fieldWidthFor`): nobody configures a row, a column or a pixel.\r\n\r\n            Fields are emitted in configured order and the grid flows in DOM order, so tab order follows\r\n            field order without any tabindex (02a §4.2). ⚠ No `dense` packing: it would reorder fields to\r\n            fill gaps, which is the one thing a form must not do. A field that does not fit the rest of a\r\n            row starts the next, and a multiline note therefore always starts its own row and ends it.\r\n\r\n            `items-start`: a tall cell (a field with a note or an error under it) does not stretch the\r\n            others in its row.\r\n          -->\r\n          <div class=\"cws:mt-4 cws:grid cws:grid-cols-12 cws:items-start cws:gap-x-6 cws:gap-y-4\">\r\n            @for (item of layout.items; track item.key) {\r\n              @if (item.kind === 'group') {\r\n                <!--\r\n                  🔴 **A COMPOUND FIELD**: several configured fields drawn as one, under one heading with\r\n                  one \"i\". The contract number is the case today: [S] [S] [1243150].\r\n\r\n                  Each member is its own control, with its own read-only state, validation and payload\r\n                  key; nothing is merged. Each keeps its own label as `sr-only` (the #196 ruling), and the\r\n                  heading is `aria-hidden` so it is not announced on every member.\r\n\r\n                  ⚠ The heading is drawn OVER the members' hidden label rows (`absolute`), which each keep\r\n                  their 20px (`cms-field`'s `min-h-5`). That is what lines the group's boxes up exactly\r\n                  with the single fields beside it in the same row.\r\n                -->\r\n                <div\r\n                  class=\"cws:relative cws:col-span-12 cws:md:col-span-6 cws:xl:col-span-4 cws:2xl:col-span-3\"\r\n                  data-field-width=\"group\"\r\n                  [attr.data-field-group]=\"item.groupKey\"\r\n                >\r\n                  <div class=\"cws:absolute cws:top-0 cws:left-0 cws:z-10 cws:flex cws:items-center cws:gap-1.5\">\r\n                    <span class=\"scoular-form-label\" aria-hidden=\"true\">{{ item.heading }}</span>\r\n                    @if (item.help.length > 0) {\r\n                      <cms-help-tip\r\n                        [label]=\"item.heading\"\r\n                        [tipId]=\"idPrefix() + item.groupKey + '-group-help'\"\r\n                        [entries]=\"item.help\"\r\n                      />\r\n                    }\r\n                  </div>\r\n\r\n                  <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n                    @for (member of item.fields; track member.componentName) {\r\n                      <!--\r\n                        A compact member keeps a narrow box. A short fixed-width member (the key's\r\n                        7-character number, #920) is sized for its width from the constraint document,\r\n                        never a hand-written one (ADR-7). Anything else shares what is left.\r\n                      -->\r\n                      <div\r\n                        [attr.data-group-member]=\"member.componentName\"\r\n                        [class.cws:w-16]=\"widths()[member.componentName] === 'small'\"\r\n                        [class.cws:shrink-0]=\"widths()[member.componentName] === 'small' || memberWidth(member) !== null\"\r\n                        [style.width]=\"memberWidth(member)\"\r\n                        [class.cws:min-w-0]=\"widths()[member.componentName] !== 'small' && memberWidth(member) === null\"\r\n                        [class.cws:flex-1]=\"widths()[member.componentName] !== 'small' && memberWidth(member) === null\"\r\n                      >\r\n                        <ng-container [ngTemplateOutlet]=\"cell\" [ngTemplateOutletContext]=\"{ field: member, inGroup: true }\" />\r\n                      </div>\r\n                    }\r\n                  </div>\r\n\r\n                  <!--\r\n                    #962: a member's verdict, under the whole row rather than under its narrow box. A live\r\n                    region that is always there, so a verdict arriving is announced, not just drawn.\r\n                  -->\r\n                  <div aria-live=\"polite\" data-group-verdicts>\r\n                    @for (entry of verdictsOf(item.fields); track entry.componentName) {\r\n                      <p\r\n                        [id]=\"idPrefix() + entry.componentName + '-verdict'\"\r\n                        class=\"cws:mt-1 cws:text-xs\"\r\n                        [class.cws:text-scoular-red-dark]=\"entry.verdict.tone === 'invalid'\"\r\n                        [class.cws:dark:text-scoular-red]=\"entry.verdict.tone === 'invalid'\"\r\n                        [class.cws:text-scoular-green-dark]=\"entry.verdict.tone === 'valid'\"\r\n                        [class.cws:dark:text-scoular-green]=\"entry.verdict.tone === 'valid'\"\r\n                        [class.cws:text-slate-500]=\"entry.verdict.tone === 'pending'\"\r\n                        [class.cws:dark:text-slate-400]=\"entry.verdict.tone === 'pending'\"\r\n                        [attr.data-field-verdict]=\"entry.verdict.tone\"\r\n                      >\r\n                        {{ entry.verdict.message }}\r\n                      </p>\r\n                    }\r\n                  </div>\r\n                </div>\r\n              } @else {\r\n                <!--\r\n                  ⚠ The width classes are spelled out here, not built from a string, so Tailwind's scanner\r\n                  sees every one of them. `data-field-width` names the width for the specs and for anyone\r\n                  reading the DOM.\r\n                -->\r\n                <div\r\n                  [attr.data-field-width]=\"widths()[item.field.componentName]\"\r\n                  class=\"cws:col-span-12\"\r\n                  [class.cws:md:col-span-6]=\"isNormalCell(item.field.componentName)\"\r\n                  [class.cws:xl:col-span-4]=\"isNormalCell(item.field.componentName)\"\r\n                  [class.cws:2xl:col-span-3]=\"isNormalCell(item.field.componentName)\"\r\n                  [class.cws:max-w-56]=\"widths()[item.field.componentName] === 'small'\"\r\n                  [class.cws:xl:col-span-8]=\"widths()[item.field.componentName] === 'large'\"\r\n                  [class.cws:2xl:col-span-6]=\"widths()[item.field.componentName] === 'large'\"\r\n                >\r\n                  <ng-container [ngTemplateOutlet]=\"cell\" [ngTemplateOutletContext]=\"{ field: item.field, inGroup: false }\" />\r\n                </div>\r\n              }\r\n            }\r\n          </div>\r\n        </div>\r\n      }\r\n    </div>\r\n    } @else if (hidingEmpty()) {\r\n      <!-- Every field on this tab is empty and the view is hiding them: say so, never a blank tab. -->\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-all-empty>\r\n        Every field here is empty. Turn off “Hide empty fields” to see them.\r\n      </p>\r\n    }\r\n  </form>\r\n}\r\n\r\n<!--\r\n  One field's cell.\r\n\r\n  `fieldStates()`, not `contractForm.states()`. The engine's state says what configuration and the\r\n  rules make of the field; this map is the same thing with the screen's read-only overrides folded in\r\n  — view mode, and the fields CTRM refuses on a write. Reading the engine's map directly here is what\r\n  would make view mode editable, so the indirection is load-bearing rather than a wrapper.\r\n-->\r\n<ng-template #cell let-field=\"field\" let-inGroup=\"inGroup\">\r\n  @if (controlFor(field.componentName); as control) {\r\n    @if (fieldStates().get(field.componentName); as state) {\r\n      <div (focusout)=\"onFieldFocusOut(field.componentName)\">\r\n        <!--\r\n          `skipTab`: a read-only field leaves the tab order while the form is editable, so Tab and\r\n          Enter go to what can be typed into (#314, JFrisbie 2026-10-06).\r\n\r\n          `display`: view mode draws every value on the quiet read-only surface.\r\n\r\n          `help`: the field's description, behind an \"i\" beside its label. A group member's is in the\r\n          group's one \"i\" instead.\r\n        -->\r\n        <cms-dynamic-field\r\n          [field]=\"field\"\r\n          [state]=\"state\"\r\n          [control]=\"control\"\r\n          [idPrefix]=\"idPrefix()\"\r\n          [hideLabel]=\"hiddenLabelFields()[field.componentName] === true\"\r\n          [skipTab]=\"state.readOnly && !readOnly()\"\r\n          [display]=\"readOnly()\"\r\n          [compact]=\"inGroup && widths()[field.componentName] === 'small'\"\r\n          [help]=\"inGroup ? null : (helps()[field.componentName] ?? null)\"\r\n          [marker]=\"markers()[field.componentName] ?? null\"\r\n          [verdict]=\"fieldVerdicts()[field.componentName] ?? null\"\r\n        />\r\n\r\n        <!-- #962: a single field's verdict. No empty live region per field: the box is described by it. -->\r\n        @if (!inGroup) {\r\n          @if (fieldVerdicts()[field.componentName]; as verdict) {\r\n            <p\r\n              [id]=\"idPrefix() + field.componentName + '-verdict'\"\r\n              class=\"cws:mt-1 cws:text-xs\"\r\n              [class.cws:text-scoular-red-dark]=\"verdict.tone === 'invalid'\"\r\n              [class.cws:dark:text-scoular-red]=\"verdict.tone === 'invalid'\"\r\n              [class.cws:text-scoular-green-dark]=\"verdict.tone === 'valid'\"\r\n              [class.cws:dark:text-scoular-green]=\"verdict.tone === 'valid'\"\r\n              [class.cws:text-slate-500]=\"verdict.tone === 'pending'\"\r\n              [class.cws:dark:text-slate-400]=\"verdict.tone === 'pending'\"\r\n              [attr.data-field-verdict]=\"verdict.tone\"\r\n            >\r\n              {{ verdict.message }}\r\n            </p>\r\n          }\r\n        }\r\n\r\n        @if (visibleNoteFor(field.componentName); as note) {\r\n          <!--\r\n            What the user needs to SEE, not look up: a precondition on the value (the Quantity\r\n            allocation), the outcome of something they just did (a Customer id confirmed), or why a\r\n            field is blank. Kept on screen deliberately; ordinary descriptions are in the \"i\".\r\n          -->\r\n          <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-field-note>\r\n            {{ note }}\r\n          </p>\r\n        }\r\n      </div>\r\n    }\r\n  }\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		config: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "config",
				required: true
			}]
		}],
		tradeUnit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tradeUnit",
				required: true
			}]
		}],
		facts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "facts",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		instanceId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "instanceId",
				required: false
			}]
		}],
		visibleSections: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visibleSections",
				required: false
			}]
		}],
		hideEmptyFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideEmptyFields",
				required: false
			}]
		}],
		fieldNotes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldNotes",
				required: false
			}]
		}],
		pinnedNotes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pinnedNotes",
				required: false
			}]
		}],
		emptyNotes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyNotes",
				required: false
			}]
		}],
		sectionNotes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sectionNotes",
				required: false
			}]
		}],
		wideFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wideFields",
				required: false
			}]
		}],
		halfFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "halfFields",
				required: false
			}]
		}],
		fieldCtrmNames: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldCtrmNames",
				required: false
			}]
		}],
		constraints: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "constraints",
				required: false
			}]
		}],
		hiddenLabelFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hiddenLabelFields",
				required: false
			}]
		}],
		groupHeadings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groupHeadings",
				required: false
			}]
		}],
		readOnlyFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnlyFields",
				required: false
			}]
		}],
		lockedFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lockedFields",
				required: false
			}]
		}],
		fieldVerdicts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldVerdicts",
				required: false
			}]
		}],
		initialValues: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initialValues",
				required: false
			}]
		}],
		defaultValues: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "defaultValues",
				required: false
			}]
		}],
		ready: [{
			type: i0.Output,
			args: ["ready"]
		}],
		fieldBlur: [{
			type: i0.Output,
			args: ["fieldBlur"]
		}]
	}
});
function isEmptyValue(value) {
	return value === null || value === void 0 || typeof value === "string" && value.trim() === "";
}
function rowCapNotice(rowCapReached, rowCap) {
	if (rowCapReached !== true) return null;
	return `CTRM returned its ${rowCap === null ? "row maximum" : `${rowCap.toLocaleString("en-US")}-row maximum`}; this may not be every contract.`;
}
const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 200;
const hasScope = (query) => Boolean(query.tradeUnit?.trim() || query.customerId?.trim());
const initialQuery = () => ({
	status: "Open",
	page: 1,
	pageSize: 50
});
const CONTRACT_LIST_SOURCE = new InjectionToken("CONTRACT_LIST_SOURCE");
function toSortParam(sorts) {
	if (sorts.length === 0) return;
	return sorts.map((sort) => `${sort.key}:${sort.direction}`).join(",");
}
function parseSortParam(sort) {
	if (!sort) return [];
	return sort.split(",").map((entry) => entry.trim()).filter((entry) => entry !== "").map((entry) => {
		const [key, direction] = entry.split(":");
		return {
			key: key.trim(),
			direction: direction?.trim() === "desc" ? "desc" : "asc"
		};
	}).filter((sortEntry) => sortEntry.key !== "");
}
function isServerSorted(requested, applied) {
	return requested !== void 0 && applied === requested;
}
const REDACTION_LITERAL = "[REDACTED]";
function isRedactedName(value) {
	return value?.trim().toUpperCase() === REDACTION_LITERAL;
}
function customerDisplayName(name, id, absent = "") {
	return (isRedactedName(name) ? null : name?.trim()) || id?.trim() || absent;
}
var SampleContractListSource = class SampleContractListSource {
	all = buildContracts();
	list(query, _options) {
		if (!hasScope(query)) throw new Error("A trade unit or a customer is required. CTRM does not serve an unfiltered contract list.");
		return of(remoteLoaded(project(this.all, query)));
	}
	loading() {
		return of(remoteLoading());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractListSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractListSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleContractListSource,
	decorators: [{ type: Injectable }]
});
function project(rows, query) {
	const matched = rows.filter((row) => matches(row, query)).sort(compare);
	const skip = (query.page - 1) * query.pageSize;
	const rowCap = query.status === "Unapproved" ? 2e3 : 1e3;
	const scoped = rows.filter((row) => is(row.customerId, query.customerId) && is(row.tradeUnit, query.tradeUnit)).length;
	return {
		rows: matched.slice(skip, skip + query.pageSize),
		totalCount: matched.length,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: matched.length <= 0 ? 1 : Math.ceil(matched.length / query.pageSize),
		dataOrigin: "Simulated",
		filteredInProcess: true,
		rowCapReached: scoped >= rowCap,
		rowCap,
		warnings: []
	};
}
function matches(row, query) {
	return is(row.customerId, query.customerId) && is(row.tradeUnit, query.tradeUnit) && is(row.commodity, query.commodity) && is(row.traderInitials, query.traderInitials) && is(row.marketZone, query.marketZone) && matchesSearch(row, query.search);
}
const is = (value, filter) => !filter?.trim() || value?.toLowerCase() === filter.trim().toLowerCase();
function matchesSearch(row, search) {
	const term = search?.trim().toLowerCase();
	if (!term) return true;
	return [
		row.contractNumber,
		row.customerId,
		row.customerName,
		row.customerContract,
		row.commodity,
		row.traderInitials,
		row.trader
	].some((value) => value?.toLowerCase().includes(term));
}
function compare(left, right) {
	const byDate = (right.contractDate ?? "").localeCompare(left.contractDate ?? "");
	return byDate !== 0 ? byDate : left.contractNumber.localeCompare(right.contractNumber);
}
const COMMODITIES = [
	["CRN", "Corn"],
	["SBN", "Soybeans"],
	["WHT", "Wheat"],
	["SRG", "Grain Sorghum"],
	["SBM", "Soybean Meal"],
	["OAT", "Oats"]
];
const SAMPLE_LOCATIONS = [
	{
		code: "0210",
		name: "Omaha Terminal",
		companyCode: "20",
		companyName: "THE SCOULAR COMPANY",
		divisionCode: "10",
		divisionName: "MERCHANDISING"
	},
	{
		code: "0315",
		name: "Council Bluffs Elevator",
		companyCode: "20",
		companyName: "THE SCOULAR COMPANY",
		divisionCode: "35",
		divisionName: "OPERATIONS"
	},
	{
		code: "0428",
		name: "Salina Processing",
		companyCode: "20",
		companyName: "THE SCOULAR COMPANY",
		divisionCode: "50",
		divisionName: "COMMODITY MARKETING DIVISION"
	},
	{
		code: "0533",
		name: "Kansas City Rail",
		companyCode: "22",
		companyName: "SCOULAR CANADA, ULC",
		divisionCode: "35",
		divisionName: "SCOULAR CANADA LTD"
	},
	{
		code: "0641",
		name: "Sioux City Elevator",
		companyCode: "42",
		companyName: "SCOULAR CANADA, ULC",
		divisionCode: "10",
		divisionName: "MERCHANDISING"
	},
	{
		code: "0755",
		name: "Topeka Elevator",
		companyCode: "30",
		companyName: "TSC CANADIAN DOLLARS",
		divisionCode: "50",
		divisionName: "COMMODITY MARKETING DIVISION"
	}
];
const MARKET_ZONES = [
	"CIF",
	"PNW",
	"EMS",
	"WMS"
];
const PRICE_TYPES = [
	"FLAT",
	"BASIS",
	"HTA",
	"MIN"
];
const APPROVAL_STATUSES = [
	"Approved",
	"Approved",
	"Approved",
	"Unapproved",
	"Rejected"
];
const DESTINATIONS = [
	"Blair Processing",
	"NOLA Export",
	"Tacoma Export",
	"Hereford Feedlot",
	"Guadalajara Mill"
];
const TRADERS = [
	["JRB", "J. Brandt"],
	["MKD", "M. Delgado"],
	["TAO", "T. Osei"],
	["LNP", "L. Novak"],
	["SRW", "S. Whitfield"]
];
const SAMPLE_CUSTOMERS = [
	["1004421", "Prairie Feed Cooperative"],
	["1004612", "Midland Grain Partners"],
	["1005108", "Cornerstone Milling"],
	["1005733", "Great Plains Ethanol"],
	["1006204", "Rivergate Trading"],
	["1006990", "Northline Poultry"]
];
const PAYMENT_TERMS = [
	"Net 10 days",
	"Net 30 days",
	"Cash against documents"
];
const CONTRACT_COUNT = 240;
function mulberry32(seed) {
	let state = seed;
	return () => {
		state = state + 1831565813 | 0;
		let t = state;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function buildContracts(today = /* @__PURE__ */ new Date("2026-08-21T00:00:00Z")) {
	const random = mulberry32(20260819);
	const pick = (items) => items[Math.floor(random() * items.length)];
	const between = (min, max) => min + Math.floor(random() * (max - min));
	const rows = [];
	for (let index = 0; index < CONTRACT_COUNT; index += 1) {
		const [commodityCode, commodityName] = pick(COMMODITIES);
		const location = pick(SAMPLE_LOCATIONS);
		const [initials, traderName] = pick(TRADERS);
		const [customerId, customerName] = pick(SAMPLE_CUSTOMERS);
		const contractDate = addDays(today, -between(1, 540));
		const quantity = 500 * between(1, 60);
		const basisPrice = round(random() * 1.6 - .6, 4);
		const futuresPrice = round(4.1 + random() * 3.4, 4);
		const priceType = pick(PRICE_TYPES);
		const isPriced = priceType !== "BASIS";
		const priced = isPriced ? quantity : 500 * between(0, Math.max(quantity / 500, 1));
		const shipped = 500 * between(0, Math.max(priced / 500, 1));
		const number = 124e4 + index * 7;
		const shipBegin = addDays(contractDate, between(20, 120));
		const suffix = index % 11 === 0 ? "-A" : "";
		const prefixType = index % 5 === 2 ? "P" : "S";
		rows.push({
			contractNumber: prefixType + commodityCode[0] + number + suffix,
			tradeUnit: location.code,
			contractDate: isoDate(contractDate),
			customerId,
			customerName: index % 7 === 3 ? null : customerName,
			customerContract: "PO-" + between(1e4, 99999),
			commodity: commodityName,
			quantity,
			quantityUom: "BU",
			unpricedQuantity: quantity - priced,
			appliedQuantity: shipped,
			openQuantity: quantity - shipped,
			price: isPriced ? round(futuresPrice + basisPrice, 4) : null,
			basisPrice,
			priceTypeCode: priceType,
			paymentTerms: pick(PAYMENT_TERMS),
			marketZone: pick(MARKET_ZONES),
			traderInitials: initials,
			trader: traderName,
			originName: location.name,
			destinationName: pick(DESTINATIONS),
			shipPeriodBegin: isoDate(shipBegin),
			shipPeriodEnd: isoDate(addDays(shipBegin, between(20, 60))),
			traderApprovalStatus: pick(APPROVAL_STATUSES),
			customerConfirmStatus: between(0, 3) === 0 ? "Pending" : "Confirmed",
			brokerConfirmStatus: between(0, 4) === 0 ? "Pending" : null,
			isClosed: index % 9 === 4,
			isIntercompany: index % 13 === 7 ? null : customerId === INTERCOMPANY_CUSTOMER
		});
	}
	return rows;
}
const INTERCOMPANY_CUSTOMER = "1006204";
const addDays = (date, days) => new Date(date.getTime() + days * 24 * 60 * 60 * 1e3);
const isoDate = (date) => date.toISOString().slice(0, 10);
const round = (value, places) => {
	const factor = 10 ** places;
	return Math.round(value * factor) / factor;
};
const SAMPLE_REDACTED_CUSTOMER_ID = "1009999";
var SampleCustomerSource = class SampleCustomerSource {
	names = new Map(SAMPLE_CUSTOMERS);
	lookup(customerId) {
		const id = customerId.trim();
		if (id === "1009999") return of(remoteLoaded({
			customerId: id,
			name: null,
			availability: "Redacted"
		}));
		const name = this.names.get(id);
		return of(remoteLoaded({
			customerId: id,
			name: name ?? null,
			availability: name === void 0 ? "Unknown" : "Resolved"
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleCustomerSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleCustomerSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleCustomerSource,
	decorators: [{ type: Injectable }]
});
const CUSTOMER_SOURCE = new InjectionToken("CUSTOMER_SOURCE");
var HttpCustomerSource = class HttpCustomerSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answers = /* @__PURE__ */ new Map();
	lookup(customerId) {
		const id = customerId.trim();
		if (id === "") return of(remoteLoaded({
			customerId: "",
			name: null,
			availability: "Unknown"
		}));
		let answer = this.answers.get(id);
		if (answer === void 0) {
			answer = this.fetch(id);
			this.answers.set(id, answer);
		}
		return answer;
	}
	fetch(id) {
		return this.http.get(`${this.baseUrl}/customers/${encodeURIComponent(id)}`).pipe(map((lookup) => remoteLoaded(lookup)), catchError((error) => of(remoteError(toRemoteError$5(error)))), tap((state) => {
			if (state.status === "error") this.answers.delete(id);
		}), startWith(remoteLoading()), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpCustomerSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpCustomerSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpCustomerSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError$5(error) {
	if (error instanceof HttpErrorResponse && (error.status === 401 || error.status === 403)) return { message: "You are not signed in, or your account cannot look up customers." };
	return { message: "The customer lookup is not available right now." };
}
var CustomerCellComponent = class CustomerCellComponent {
	row = input.required(...ngDevMode ? [{ debugName: "row" }] : /* istanbul ignore next */ []);
	source = inject(CUSTOMER_SOURCE, { optional: true });
	overlay = inject(Overlay);
	canLookUp = computed(() => this.source !== null && Boolean(this.row().customerId?.trim()), ...ngDevMode ? [{ debugName: "canLookUp" }] : /* istanbul ignore next */ []);
	destroyRef = inject(DestroyRef);
	subscription = null;
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	lookup = signal(null, ...ngDevMode ? [{ debugName: "lookup" }] : /* istanbul ignore next */ []);
	display = computed(() => this.row().customerId?.trim() ?? "", ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	scroll = this.overlay.scrollStrategies.reposition();
	positions = [{
		originX: "start",
		originY: "bottom",
		overlayX: "start",
		overlayY: "top",
		offsetY: 4
	}, {
		originX: "start",
		originY: "top",
		overlayX: "start",
		overlayY: "bottom",
		offsetY: -4
	}];
	nameOf(value) {
		return isRedactedName(value.name) ? null : value.name?.trim() || null;
	}
	toggle(event) {
		event.stopPropagation();
		if (this.open()) this.close();
		else this.show();
	}
	show() {
		this.open.set(true);
		const id = this.row().customerId?.trim();
		const current = this.lookup();
		const source = this.source;
		if (id && source !== null && (current === null || current.status === "error")) {
			this.subscription?.unsubscribe();
			this.subscription = source.lookup(id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => this.lookup.set(state));
		}
	}
	close() {
		this.open.set(false);
	}
	stop(event) {
		event.stopPropagation();
	}
	onTriggerKeydown(event) {
		if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") event.stopPropagation();
	}
	onOverlayKeydown(event) {
		if (event.key === "Escape") {
			event.stopPropagation();
			this.close();
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: CustomerCellComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: CustomerCellComponent,
		isStandalone: true,
		selector: "cms-customer-cell",
		inputs: { row: {
			classPropertyName: "row",
			publicName: "row",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { classAttribute: "cws:block cws:min-w-0" },
		ngImport: i0,
		template: "<span class=\"cws:flex cws:min-w-0 cws:items-center cws:gap-1\">\r\n  <!-- The id, never the name (#768). `title` for the same reason every cell carries one. -->\r\n  <span class=\"truncate\" [attr.title]=\"display() || null\">{{ display() }}</span>\r\n\r\n  @if (canLookUp() && row().customerId; as id) {\r\n    <!--\r\n      The trigger, offered only where a lookup source is provided and the row carries an id. mousedown\r\n      and dblclick are stopped so the grid neither selects the cell nor opens the record; Enter and\r\n      Space are stopped so the row does not treat them as \"open\". `aria-haspopup=\"dialog\"` and\r\n      `aria-expanded` say what the button does before it is pressed.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:shrink-0 cws:rounded cws:px-1 cws:text-xs cws:leading-none cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue\"\r\n      cdkOverlayOrigin\r\n      #origin=\"cdkOverlayOrigin\"\r\n      [attr.aria-label]=\"'Look up customer ' + id\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      aria-haspopup=\"dialog\"\r\n      (mousedown)=\"stop($event)\"\r\n      (dblclick)=\"stop($event)\"\r\n      (click)=\"toggle($event)\"\r\n      (keydown)=\"onTriggerKeydown($event)\"\r\n    >\r\n      ⓘ\r\n    </button>\r\n\r\n    <!--\r\n      A CDK connected overlay rather than an in-cell panel: the cell is `truncate`, so anything inside\r\n      it is clipped to one line. Outside click and Escape both close it.\r\n    -->\r\n    <ng-template\r\n      cdkConnectedOverlay\r\n      [cdkConnectedOverlayOrigin]=\"origin\"\r\n      [cdkConnectedOverlayOpen]=\"open()\"\r\n      [cdkConnectedOverlayPositions]=\"positions\"\r\n      [cdkConnectedOverlayScrollStrategy]=\"scroll\"\r\n      (overlayOutsideClick)=\"close()\"\r\n      (overlayKeydown)=\"onOverlayKeydown($event)\"\r\n    >\r\n      <div\r\n        class=\"scoular-card cws:w-80 cws:p-3 cws:text-sm cws:shadow-lg\"\r\n        role=\"dialog\"\r\n        [attr.aria-label]=\"'Customer ' + id\"\r\n        (mousedown)=\"stop($event)\"\r\n        (dblclick)=\"stop($event)\"\r\n        (click)=\"stop($event)\"\r\n      >\r\n        @if (lookup(); as state) {\r\n          @if (state.status === 'loaded') {\r\n            @switch (state.value.availability) {\r\n              @case ('Resolved') {\r\n                @if (nameOf(state.value); as name) {\r\n                  <p class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ name }}</p>\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                } @else {\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                  <p>The customer directory returned no usable name for this account.</p>\r\n                }\r\n              }\r\n              @case ('Redacted') {\r\n                <!-- A notice, never a blank. It will not clear by retrying, so it says who to ask. -->\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <p class=\"cws:mt-1 cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-2 cws:py-1 cws:text-amber-900 cws:dark:border-amber-700 cws:dark:bg-amber-950 cws:dark:text-amber-200\">\r\n                  The customer's name is withheld for this application. The account number is\r\n                  correct; showing the name needs a person to enable it.\r\n                </p>\r\n              }\r\n              @case ('Unknown') {\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <!-- Not \"no record\": Unknown is also a customer MDM holds with no name (GEstevez, #438). -->\r\n                <p>No name on record for this id.</p>\r\n              }\r\n            }\r\n          } @else if (state.status === 'error') {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n            <p>{{ state.error.message }}</p>\r\n          } @else {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n          }\r\n        } @else {\r\n          <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n        }\r\n\r\n        <!-- Stated, not built: CWS holds no phone number for any customer, and none is invented here.\r\n             A phone belongs to the customer, not the contract (#766). -->\r\n        <p class=\"cws:mt-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400\">\r\n          Teams call: not available. No phone number is associated with this customer.\r\n        </p>\r\n      </div>\r\n    </ng-template>\r\n  }\r\n</span>\r\n",
		dependencies: [{
			kind: "directive",
			type: CdkConnectedOverlay,
			selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]",
			inputs: [
				"cdkConnectedOverlayOrigin",
				"cdkConnectedOverlayPositions",
				"cdkConnectedOverlayPositionStrategy",
				"cdkConnectedOverlayOffsetX",
				"cdkConnectedOverlayOffsetY",
				"cdkConnectedOverlayWidth",
				"cdkConnectedOverlayHeight",
				"cdkConnectedOverlayMinWidth",
				"cdkConnectedOverlayMinHeight",
				"cdkConnectedOverlayBackdropClass",
				"cdkConnectedOverlayPanelClass",
				"cdkConnectedOverlayViewportMargin",
				"cdkConnectedOverlayScrollStrategy",
				"cdkConnectedOverlayOpen",
				"cdkConnectedOverlayDisableClose",
				"cdkConnectedOverlayTransformOriginOn",
				"cdkConnectedOverlayHasBackdrop",
				"cdkConnectedOverlayLockPosition",
				"cdkConnectedOverlayFlexibleDimensions",
				"cdkConnectedOverlayGrowAfterOpen",
				"cdkConnectedOverlayPush",
				"cdkConnectedOverlayDisposeOnNavigation",
				"cdkConnectedOverlayUsePopover",
				"cdkConnectedOverlayMatchWidth",
				"cdkConnectedOverlay"
			],
			outputs: [
				"backdropClick",
				"positionChange",
				"attach",
				"detach",
				"overlayKeydown",
				"overlayOutsideClick"
			],
			exportAs: ["cdkConnectedOverlay"]
		}, {
			kind: "directive",
			type: CdkOverlayOrigin,
			selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]",
			exportAs: ["cdkOverlayOrigin"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: CustomerCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-customer-cell",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [CdkConnectedOverlay, CdkOverlayOrigin],
			host: { class: "cws:block cws:min-w-0" },
			template: "<span class=\"cws:flex cws:min-w-0 cws:items-center cws:gap-1\">\r\n  <!-- The id, never the name (#768). `title` for the same reason every cell carries one. -->\r\n  <span class=\"truncate\" [attr.title]=\"display() || null\">{{ display() }}</span>\r\n\r\n  @if (canLookUp() && row().customerId; as id) {\r\n    <!--\r\n      The trigger, offered only where a lookup source is provided and the row carries an id. mousedown\r\n      and dblclick are stopped so the grid neither selects the cell nor opens the record; Enter and\r\n      Space are stopped so the row does not treat them as \"open\". `aria-haspopup=\"dialog\"` and\r\n      `aria-expanded` say what the button does before it is pressed.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:shrink-0 cws:rounded cws:px-1 cws:text-xs cws:leading-none cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue\"\r\n      cdkOverlayOrigin\r\n      #origin=\"cdkOverlayOrigin\"\r\n      [attr.aria-label]=\"'Look up customer ' + id\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      aria-haspopup=\"dialog\"\r\n      (mousedown)=\"stop($event)\"\r\n      (dblclick)=\"stop($event)\"\r\n      (click)=\"toggle($event)\"\r\n      (keydown)=\"onTriggerKeydown($event)\"\r\n    >\r\n      ⓘ\r\n    </button>\r\n\r\n    <!--\r\n      A CDK connected overlay rather than an in-cell panel: the cell is `truncate`, so anything inside\r\n      it is clipped to one line. Outside click and Escape both close it.\r\n    -->\r\n    <ng-template\r\n      cdkConnectedOverlay\r\n      [cdkConnectedOverlayOrigin]=\"origin\"\r\n      [cdkConnectedOverlayOpen]=\"open()\"\r\n      [cdkConnectedOverlayPositions]=\"positions\"\r\n      [cdkConnectedOverlayScrollStrategy]=\"scroll\"\r\n      (overlayOutsideClick)=\"close()\"\r\n      (overlayKeydown)=\"onOverlayKeydown($event)\"\r\n    >\r\n      <div\r\n        class=\"scoular-card cws:w-80 cws:p-3 cws:text-sm cws:shadow-lg\"\r\n        role=\"dialog\"\r\n        [attr.aria-label]=\"'Customer ' + id\"\r\n        (mousedown)=\"stop($event)\"\r\n        (dblclick)=\"stop($event)\"\r\n        (click)=\"stop($event)\"\r\n      >\r\n        @if (lookup(); as state) {\r\n          @if (state.status === 'loaded') {\r\n            @switch (state.value.availability) {\r\n              @case ('Resolved') {\r\n                @if (nameOf(state.value); as name) {\r\n                  <p class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ name }}</p>\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                } @else {\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                  <p>The customer directory returned no usable name for this account.</p>\r\n                }\r\n              }\r\n              @case ('Redacted') {\r\n                <!-- A notice, never a blank. It will not clear by retrying, so it says who to ask. -->\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <p class=\"cws:mt-1 cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-2 cws:py-1 cws:text-amber-900 cws:dark:border-amber-700 cws:dark:bg-amber-950 cws:dark:text-amber-200\">\r\n                  The customer's name is withheld for this application. The account number is\r\n                  correct; showing the name needs a person to enable it.\r\n                </p>\r\n              }\r\n              @case ('Unknown') {\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <!-- Not \"no record\": Unknown is also a customer MDM holds with no name (GEstevez, #438). -->\r\n                <p>No name on record for this id.</p>\r\n              }\r\n            }\r\n          } @else if (state.status === 'error') {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n            <p>{{ state.error.message }}</p>\r\n          } @else {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n          }\r\n        } @else {\r\n          <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n        }\r\n\r\n        <!-- Stated, not built: CWS holds no phone number for any customer, and none is invented here.\r\n             A phone belongs to the customer, not the contract (#766). -->\r\n        <p class=\"cws:mt-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400\">\r\n          Teams call: not available. No phone number is associated with this customer.\r\n        </p>\r\n      </div>\r\n    </ng-template>\r\n  }\r\n</span>\r\n"
		}]
	}],
	propDecorators: { row: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "row",
			required: true
		}]
	}] }
});
const ACTIONS = [
	"Create",
	"Update",
	"Approve",
	"Reject",
	"StatusChange",
	"PriceCreate",
	"PriceUpdate",
	"PriceDelete",
	"PriceApprove",
	"Note",
	"EmailUpdate",
	"ConfigChange",
	"TemplateChange",
	"ReservationSwept",
	"AddendumCreate",
	"RoleChange",
	"RoleAssignmentChange",
	"AddendumTemplateChange",
	"AddendumTypeChange",
	"AddendumRemove",
	"AddendumRestore",
	"AttachmentAdd",
	"AttachmentReplace",
	"AttachmentRemove",
	"AttachmentRestore"
];
function auditActionOf(value) {
	if (typeof value === "number" && Number.isInteger(value)) return ACTIONS[value] ?? "Unknown";
	if (typeof value === "string") return ACTIONS.find((action) => action === value) ?? "Unknown";
	return "Unknown";
}
const NOTES_WARNING = "NotesErrorSQLCode";
const ACTION_LABELS = {
	Create: "Contract created",
	Update: "Contract updated",
	Approve: "Approved",
	Reject: "Rejected",
	StatusChange: "Status changed",
	PriceCreate: "Price added",
	PriceUpdate: "Price updated",
	PriceDelete: "Price removed",
	PriceApprove: "Price approved",
	Note: "Note added",
	EmailUpdate: "Email updated",
	ConfigChange: "Configuration changed",
	TemplateChange: "Template changed",
	ReservationSwept: "Reserved number released",
	AddendumCreate: "Addendum created",
	RoleChange: "Role changed",
	RoleAssignmentChange: "Role assignment changed",
	AddendumTemplateChange: "Addendum template changed",
	AddendumTypeChange: "Addendum type changed",
	AddendumRemove: "Addendum removed",
	AddendumRestore: "Addendum restored",
	AttachmentAdd: "Attachment added",
	AttachmentReplace: "Attachment replaced",
	AttachmentRemove: "Attachment removed",
	AttachmentRestore: "Attachment restored",
	Unknown: "Change recorded"
};
function describeAuditAction(action) {
	return ACTION_LABELS[action] ?? ACTION_LABELS.Unknown;
}
function auditChangesOf(detailsJson) {
	if (detailsJson === null || detailsJson.trim() === "") return null;
	let parsed;
	try {
		parsed = JSON.parse(detailsJson);
	} catch {
		return null;
	}
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return null;
	const record = parsed;
	const changes = Array.isArray(record.changes) ? record.changes.flatMap((row) => {
		const change = row ?? {};
		return typeof change.field === "string" && change.field.trim() !== "" ? [{
			field: change.field,
			from: valueText(change.from),
			to: valueText(change.to)
		}] : [];
	}) : [];
	const collectionsReplaced = Array.isArray(record.collectionsReplaced) ? record.collectionsReplaced.filter((name) => typeof name === "string" && name.trim() !== "") : [];
	return changes.length === 0 && collectionsReplaced.length === 0 ? null : {
		changes,
		collectionsReplaced
	};
}
function valueText(value) {
	if (value === null || value === void 0) return null;
	return typeof value === "string" || typeof value === "number" || typeof value === "boolean" ? String(value) : null;
}
function auditNoteIdOf(detailsJson) {
	if (detailsJson === null || detailsJson.trim() === "") return null;
	try {
		const parsed = JSON.parse(detailsJson);
		const id = parsed !== null && typeof parsed === "object" ? parsed.noteId : void 0;
		return typeof id === "number" && Number.isInteger(id) ? id : null;
	} catch {
		return null;
	}
}
const SCOULAR_EMAIL_DOMAIN = "scoular.com";
function isScoularAddress(address) {
	const match = /^[^\s@]+@([^\s@]+)$/.exec(address.trim());
	return match !== null && match[1].toLowerCase() === "scoular.com";
}
const CONTRACT_LOG_SOURCE = new InjectionToken("CONTRACT_LOG_SOURCE");
var HttpContractLogSource = class HttpContractLogSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	audit(contractNumber) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/audit`;
		return this.http.get(url).pipe(map((rows) => remoteLoaded(rows.map((row) => toEntry(row)))), catchError(() => of(remoteError({ message: "The history for this contract could not be loaded." }))), startWith(remoteLoading()));
	}
	notes(contractNumber) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/notes`;
		return this.http.get(url).pipe(map((rows) => remoteLoaded(rows.map((row) => toNote(row)))), catchError(() => of(remoteError({ message: "The notes for this contract could not be read." }))), startWith(remoteLoading()));
	}
	addNote(contractNumber, note, clientNoteId) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/notes`;
		return this.http.post(url, {
			note,
			clientNoteId
		}).pipe(map(toNote));
	}
	notifyTrader(contractNumber, message, recipients) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/notify-trader`;
		return this.http.post(url, {
			message,
			recipients
		}).pipe(map(notifyAnswerOf));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractLogSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractLogSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractLogSource,
	decorators: [{ type: Injectable }]
});
function notifyAnswerOf(body) {
	const record = typeof body === "object" && body !== null ? body : {};
	return {
		delivered: typeof record["delivered"] === "boolean" ? record["delivered"] : null,
		provider: typeof record["provider"] === "string" ? record["provider"] : null
	};
}
function toNote(row) {
	const record = typeof row === "object" && row !== null ? row : {};
	const text = (key) => typeof record[key] === "string" ? record[key] : "";
	return {
		id: typeof record["id"] === "number" ? record["id"] : 0,
		contractNumber: text("contractNumber"),
		tradeUnit: text("tradeUnit"),
		note: text("note"),
		actorUpn: text("actorUpn"),
		createdAtUtc: text("createdAtUtc")
	};
}
function toEntry(row) {
	const record = row ?? {};
	return {
		id: typeof record["id"] === "number" ? record["id"] : 0,
		contractNumber: typeof record["contractNumber"] === "string" ? record["contractNumber"] : null,
		tradeUnit: typeof record["tradeUnit"] === "string" ? record["tradeUnit"] : "",
		action: auditActionOf(record["action"]),
		actorUpn: typeof record["actorUpn"] === "string" ? record["actorUpn"] : "",
		timestampUtc: typeof record["timestampUtc"] === "string" ? record["timestampUtc"] : "",
		detailsJson: typeof record["detailsJson"] === "string" ? record["detailsJson"] : null,
		correlationId: typeof record["correlationId"] === "string" ? record["correlationId"] : ""
	};
}
const CLOSE_PROVENANCE_WARNING = "closing rewrites pricing-approval provenance and cannot be undone";
const CONTRACT_STATE_SOURCE = new InjectionToken("CONTRACT_STATE_SOURCE");
var HttpContractStateSource = class HttpContractStateSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	close(contractNumber) {
		return this.post(contractNumber, "close");
	}
	reopen(contractNumber) {
		return this.post(contractNumber, "reopen");
	}
	post(contractNumber, action) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/${action}`;
		return this.http.post(url, null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractStateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractStateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractStateSource,
	decorators: [{ type: Injectable }]
});
function templateValuesOf(template) {
	try {
		const parsed = JSON.parse(template.payloadJson);
		return typeof parsed === "object" && parsed !== null && !Array.isArray(parsed) ? parsed : {};
	} catch {
		return {};
	}
}
const CONTRACT_TEMPLATE_SOURCE = new InjectionToken("CONTRACT_TEMPLATE_SOURCE");
var HttpContractTemplateSource = class HttpContractTemplateSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get templatesUrl() {
		return `${this.baseUrl}/templates`;
	}
	list(tradeUnit) {
		return this.http.get(this.templatesUrl, { params: new HttpParams().set("tradeUnit", tradeUnit) }).pipe(map((templates) => remoteLoaded(templates)), catchError(() => of(remoteError({ message: "The templates for this trade unit could not be loaded." }))), startWith(remoteLoading()));
	}
	save(tradeUnit, name, values) {
		return this.http.post(this.templatesUrl, {
			tradeUnit,
			name,
			payloadJson: JSON.stringify(values)
		});
	}
	rename(id, tradeUnit, name, values) {
		return this.http.put(`${this.templatesUrl}/${id}`, {
			tradeUnit,
			name,
			payloadJson: JSON.stringify(values)
		});
	}
	remove(id) {
		return this.http.delete(`${this.templatesUrl}/${id}`);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractTemplateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractTemplateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractTemplateSource,
	decorators: [{ type: Injectable }]
});
const NOTE_MAX_BYTES = 4e3;
function noteByteLength(note) {
	return new TextEncoder().encode(note).length;
}
function remainingNoteBytes(note) {
	return NOTE_MAX_BYTES - noteByteLength(note);
}
function noteSizeRefusal(note) {
	const over = -remainingNoteBytes(note);
	if (over <= 0) return null;
	return `This note is ${over.toLocaleString("en-US")} characters over the ${NOTE_MAX_BYTES.toLocaleString("en-US")} allowed. Shorten it before saving — a note over the limit stops CTRM returning all of the notes on this contract, not just this one.`;
}
function logNoteSizeRefusal(note) {
	const over = -remainingNoteBytes(note);
	return over <= 0 ? null : `This note is ${over.toLocaleString("en-US")} characters over the ${NOTE_MAX_BYTES.toLocaleString("en-US")} allowed. Shorten it before adding it.`;
}
const CONTRACT_TEXT_SOURCE = new InjectionToken("CONTRACT_TEXT_SOURCE");
const CONTRACT_TEXT_FAILED_MESSAGE = "The contract text could not be read, so it cannot be shown or changed here. The text CTRM holds is unchanged.";
var HttpContractTextSource = class HttpContractTextSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	load(contractNumber) {
		return this.http.get(`${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/contract-text`).pipe(map((body) => {
			const answer = answerOf(body);
			return answer === null ? { kind: "unavailable" } : {
				kind: "loaded",
				value: answer
			};
		}), catchError((error) => of(callFor(error))));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractTextSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractTextSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractTextSource,
	decorators: [{ type: Injectable }]
});
function callFor(error) {
	if (!(error instanceof HttpErrorResponse)) return {
		kind: "failed",
		message: CONTRACT_TEXT_FAILED_MESSAGE
	};
	const problem = typeof error.error === "object" && error.error !== null ? error.error : null;
	const bareNotFound = error.status === 404 && !problem?.detail && !problem?.title;
	return error.status === 0 || bareNotFound || error.status === 405 || error.status === 501 ? { kind: "unavailable" } : {
		kind: "failed",
		message: CONTRACT_TEXT_FAILED_MESSAGE
	};
}
function answerOf(body) {
	if (typeof body !== "object" || body === null) return null;
	const raw = body;
	if (typeof raw["archetype"] !== "string" || typeof raw["prefix"] !== "string" || !Array.isArray(raw["codes"])) return null;
	const codes = raw["codes"].map(codeOf);
	if (codes.some((code) => code === null)) return null;
	return {
		contractNumber: typeof raw["contractNumber"] === "string" ? raw["contractNumber"] : "",
		archetype: raw["archetype"],
		side: typeof raw["side"] === "string" ? raw["side"] : "",
		prefix: raw["prefix"],
		reconfirmsOnChange: raw["reconfirmsOnChange"] !== false,
		notesReadable: raw["notesReadable"] === true,
		codes: codes.slice().sort((a, b) => a.order - b.order)
	};
}
function codeOf(value) {
	if (typeof value !== "object" || value === null) return null;
	const raw = value;
	if (typeof raw["code"] !== "string" || raw["code"].trim() === "") return null;
	return {
		code: raw["code"],
		description: typeof raw["description"] === "string" ? raw["description"] : null,
		order: typeof raw["order"] === "number" ? raw["order"] : Number.MAX_SAFE_INTEGER,
		editable: raw["editable"] === true,
		templateText: typeof raw["templateText"] === "string" ? raw["templateText"] : "",
		contractText: typeof raw["contractText"] === "string" ? raw["contractText"] : null
	};
}
const SAMPLE_CONTRACT_TEXT_TEMPLATES = [
	{
		code: "PAYMENT",
		description: "Payment terms",
		order: 1,
		editable: true,
		templateText: "Payment within 10 days of receipt of invoice and weight certificates."
	},
	{
		code: "TOLER",
		description: "Tolerance",
		order: 2,
		editable: true,
		templateText: "Five percent more or less at buyer’s option, at contract price."
	},
	{
		code: "ADDTERMS1",
		description: "Additional terms",
		order: 3,
		editable: true,
		templateText: ""
	},
	{
		code: "OTHERTERMS",
		description: "Other terms",
		order: 4,
		editable: false,
		templateText: "All other terms per NGFA trade rules."
	}
];
var SampleContractTextSource = class {
	notesOf;
	constructor(notesOf = () => []) {
		this.notesOf = notesOf;
	}
	load(contractNumber) {
		const notes = this.notesOf(contractNumber);
		const override = (code) => notes.find((note) => (note.prefix ?? "").trim().toUpperCase() === "CNTTX" && (note.code ?? "").trim().toUpperCase() === code)?.text ?? null;
		return of({
			kind: "loaded",
			value: {
				contractNumber,
				archetype: "BCO",
				side: contractNumber.trim().toUpperCase().startsWith("S") ? "S" : "P",
				prefix: "CNTTX",
				reconfirmsOnChange: true,
				notesReadable: true,
				codes: SAMPLE_CONTRACT_TEXT_TEMPLATES.map((code) => ({
					...code,
					contractText: override(code.code)
				}))
			}
		});
	}
};
const CONTRACT_NOTES_MAX_ROWS = 50;
function sameContractText(a, b) {
	return normalise(a) === normalise(b);
}
function normalise(text) {
	return (text ?? "").replace(/\r\n?/g, "\n").trimEnd();
}
function contractTextBaseline(answer) {
	return Object.fromEntries(answer.codes.map((code) => [code.code, code.contractText ?? code.templateText]));
}
function changedContractTextCodes(answer, baseline, values) {
	return answer.codes.filter((code) => code.editable && !sameContractText(values[code.code] ?? "", baseline[code.code] ?? "")).map((code) => code.code);
}
function contractTextNotesPayload(stored, answer, baseline, values) {
	const changed = changedContractTextCodes(answer, baseline, values);
	if (changed.length === 0) return;
	const rows = stored.map((note) => ({
		note_prefix: note.prefix,
		note_code: note.code,
		note: note.text
	}));
	const deletions = [];
	let touched = false;
	const prefix = answer.prefix.trim().toUpperCase();
	const isRowFor = (row, code) => (row.note_prefix ?? "").trim().toUpperCase() === prefix && (row.note_code ?? "").trim().toUpperCase() === code.trim().toUpperCase();
	for (const code of answer.codes.filter((entry) => changed.includes(entry.code))) {
		const text = values[code.code] ?? "";
		const index = rows.findIndex((row) => isRowFor(row, code.code));
		if (text.trim() === "" || sameContractText(text, code.templateText)) {
			if (index >= 0) {
				const [row] = rows.splice(index, 1);
				deletions.push({
					note_prefix: row.note_prefix,
					note_code: row.note_code,
					note: ""
				});
				touched = true;
			}
		} else if (index >= 0) {
			rows[index] = {
				...rows[index],
				note: text
			};
			touched = true;
		} else {
			rows.push({
				note_prefix: answer.prefix,
				note_code: code.code,
				note: text
			});
			touched = true;
		}
	}
	return touched ? [...rows, ...deletions] : void 0;
}
function contractTextRefusal(stored, answer, baseline, values) {
	for (const code of changedContractTextCodes(answer, baseline, values)) {
		const refusal = noteSizeRefusal(values[code] ?? "");
		if (refusal !== null) return `${labelOf(answer, code)}: ${refusal}`;
	}
	const rows = contractTextNotesPayload(stored, answer, baseline, values);
	return rows !== void 0 && rows.length > 50 ? `This contract would carry ${rows.length} notes, over the 50 CTRM allows. Return a text to its template to save.` : null;
}
function labelOf(answer, code) {
	return answer.codes.find((candidate) => candidate.code === code)?.description?.trim() || code;
}
const CLOSED_REFUSAL = "This contract is closed";
const INTERCOMPANY_PURCHASE_REFUSAL = "Intercompany purchase contracts are read-only";
function isPurchaseContract(contractNumber) {
	return contractNumber.trim().charAt(0).toUpperCase() === "P";
}
function editRefusalFor(row) {
	if (row.isClosed) return CLOSED_REFUSAL;
	if (row.isIntercompany === true && isPurchaseContract(row.contractNumber)) return INTERCOMPANY_PURCHASE_REFUSAL;
	return false;
}
function approveRefusalFor(row) {
	return row.isClosed ? CLOSED_REFUSAL : false;
}
const NUMBER_ISSUE_GENERIC_MESSAGE = "CTRM could not issue a contract number. Type one, or try again.";
function conditionOfConflict(conflict) {
	switch (conflict) {
		case "ExecutableContractExists": return "inUse";
		case "MarkedForPurge": return "purged";
		case "PendingContractExists": return "pendingHold";
		case "PendingNumberAndSuffixExist":
		case "ExecutableNumberAndSuffixExist": return "suffixCollision";
		default: return "unknown";
	}
}
const TYPED_NUMBER_GENERIC_MESSAGE = "That contract number cannot be used. Type a different number, or try again.";
const NUMBER_CHECK_FAILED_MESSAGE = "CWS could not confirm that contract number is free, so the contract was not saved. Try again.";
const NUMBER_CHECK_UNCONFIRMED_MESSAGE = "CWS could not confirm that contract number is free. It is checked again when you save.";
const TYPED_NUMBER_CHECKING_MESSAGE = "Checking whether that contract number is free…";
const TYPED_NUMBER_AVAILABLE_MESSAGE = "That contract number is free.";
const CONTRACT_NUMBER_WIDTH = 7;
const TYPED_NUMBER_SHORT_MESSAGE = "A new contract number must be 7 characters. CTRM holds a shorter number in two ways, as two different contracts, so a short one cannot be created. Type all 7 characters.";
const TYPED_MESSAGES = {
	blank: "Both contract prefixes are needed before that number can be checked. Fill them in.",
	inUse: "That contract number already belongs to another contract. Type a different number.",
	purged: "That contract number is marked for removal and cannot be used. Type a different number.",
	pendingHold: "That contract number is being held by an unfinished contract. Type a different number.",
	suffixCollision: "That number and suffix are already used under different prefixes. Choose a different suffix, or a different number.",
	unknown: TYPED_NUMBER_GENERIC_MESSAGE
};
function messageForTypedNumberCondition(condition) {
	return TYPED_MESSAGES[condition] ?? "That contract number cannot be used. Type a different number, or try again.";
}
const FOCUS_PARAM = "focus";
function toRouteParams(query, sorts, focus, filter) {
	const params = {};
	const defaults = initialQuery();
	const encoded = filter === void 0 ? void 0 : filterToParam(filter);
	if (encoded !== void 0) params[FILTER_PARAM] = encoded;
	if (query.status !== defaults.status) params["status"] = query.status;
	for (const key of [
		"search",
		"commodity",
		"customerId",
		"traderInitials",
		"marketZone",
		"approverType"
	]) {
		const value = query[key]?.trim();
		if (value) params[key] = value;
	}
	if (query.page > 1) params["page"] = String(query.page);
	const sort = toSortParam(sorts);
	if (sort !== void 0) params["sort"] = sort;
	if (focus) params[FOCUS_PARAM] = focus;
	return params;
}
const FILTER_PARAM = "filter";
function filterToParam(group) {
	const active = group.rules.filter(carries);
	return active.length === 0 ? void 0 : JSON.stringify({
		combinator: group.combinator,
		rules: active
	});
}
function filterFromParam(raw) {
	if (!raw) return EMPTY_FILTER;
	try {
		const parsed = JSON.parse(raw);
		if (typeof parsed !== "object" || parsed === null) return EMPTY_FILTER;
		return readGroup(parsed) ?? EMPTY_FILTER;
	} catch {
		return EMPTY_FILTER;
	}
}
function carries(node) {
	return isRuleNode(node) ? node.columnKey !== "" : node.rules.some(carries);
}
function readGroup(value) {
	if (typeof value !== "object" || value === null) return null;
	const candidate = value;
	if (!Array.isArray(candidate.rules)) return null;
	const rules = candidate.rules.map((child) => isRule(child) ? child : readGroup(child)).filter((child) => child !== null);
	return {
		combinator: candidate.combinator === "or" ? "or" : "and",
		rules
	};
}
function isRule(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return typeof candidate.id === "string" && typeof candidate.columnKey === "string" && typeof candidate.operator === "string" && typeof candidate.value === "string";
}
function fromRouteParams(params) {
	const status = params.get("status");
	const page = Number.parseInt(params.get("page") ?? "", 10);
	return {
		query: {
			...initialQuery(),
			status: isStatus(status) ? status : initialQuery().status,
			search: blank(params.get("search")),
			commodity: blank(params.get("commodity")),
			customerId: blank(params.get("customerId")),
			traderInitials: blank(params.get("traderInitials")),
			marketZone: blank(params.get("marketZone")),
			approverType: blank(params.get("approverType")),
			page: Number.isFinite(page) && page > 0 ? page : 1,
			pageSize: 50
		},
		sorts: parseSortParam(params.get("sort")),
		focus: blank(params.get("focus")) ?? null,
		filter: filterFromParam(params.get(FILTER_PARAM))
	};
}
const STATUSES$2 = [
	"Open",
	"Unapproved",
	"Closed"
];
function isStatus(value) {
	return value !== null && STATUSES$2.includes(value);
}
function blank(value) {
	const trimmed = value?.trim();
	return trimmed ? trimmed : void 0;
}
var HttpContractListSource = class HttpContractListSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	list(query, options) {
		return this.http.get(`${this.baseUrl}/contracts`, { params: toContractListParams(query, options) }).pipe(map((page) => remoteLoaded(normalizeContractListPage(page))), catchError((error) => of(remoteError(toRemoteError$4(error)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractListSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractListSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractListSource,
	decorators: [{ type: Injectable }]
});
function normalizeContractListPage(page) {
	return withRowCap(withGatingFlags(page));
}
function withGatingFlags(page) {
	return {
		...page,
		rows: page.rows.map((row) => ({
			...row,
			isClosed: row.isClosed ?? false,
			isIntercompany: row.isIntercompany === void 0 ? null : row.isIntercompany
		}))
	};
}
function withRowCap(page) {
	return {
		...page,
		rowCapReached: page.rowCapReached ?? null,
		rowCap: page.rowCap ?? null
	};
}
function toContractListParams(query, options) {
	let params = new HttpParams().set("status", query.status).set("page", query.page).set("pageSize", query.pageSize);
	if (options?.refresh) params = params.set("refresh", true);
	const optional = [
		["tradeUnit", query.tradeUnit],
		["customerId", query.customerId],
		["commodity", query.commodity],
		["traderInitials", query.traderInitials],
		["approverType", query.approverType],
		["marketZone", query.marketZone],
		["search", query.search],
		["sort", query.sort]
	];
	for (const [key, value] of optional) {
		const trimmed = value?.trim();
		if (trimmed) params = params.set(key, trimmed);
	}
	return params;
}
function toRemoteError$4(error) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 422) return {
			message: problem?.detail ?? problem?.title ?? "That request could not be completed.",
			correlationId: problem?.traceId
		};
		if (error.status === 401 || error.status === 403) return {
			message: "You are not signed in, or your account cannot view contracts.",
			correlationId: problem?.traceId
		};
		return {
			message: "We could not load contracts. Please try again.",
			correlationId: problem?.traceId
		};
	}
	return { message: "We could not load contracts. Please try again." };
}
const CONTRACT_EXPORT_SOURCE = new InjectionToken("CONTRACT_EXPORT_SOURCE");
var HttpContractExportSource = class HttpContractExportSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	export(request) {
		const params = toContractListParams(request.query).delete("page").delete("pageSize").set("fields", request.fields.join(","));
		return this.http.get(`${this.baseUrl}/contracts/export`, {
			params,
			responseType: "blob",
			observe: "response"
		}).pipe(map((response) => ({
			kind: "csv",
			csv: response.body ?? new Blob([], { type: "text/csv" }),
			filename: filenameFrom(response.headers.get("Content-Disposition")),
			rowCapReached: rowCapReachedFrom(response.headers.get("X-CWS-Row-Cap-Reached")),
			rowCap: rowCapFrom(response.headers.get("X-CWS-Row-Cap"))
		})), catchError((error) => toResult(error)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractExportSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractExportSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractExportSource,
	decorators: [{ type: Injectable }]
});
function rowCapReachedFrom(header) {
	const value = header?.trim().toLowerCase();
	return value === "true" ? true : value === "false" ? false : null;
}
function rowCapFrom(header) {
	const value = header?.trim() ?? "";
	return /^\d+$/.test(value) && Number(value) > 0 ? Number(value) : null;
}
function filenameFrom(disposition) {
	if (!disposition) return null;
	const encoded = /filename\*\s*=\s*utf-8''([^;]+)/i.exec(disposition);
	if (encoded) {
		const value = encoded[1].trim();
		try {
			return decodeURIComponent(value);
		} catch {
			return value;
		}
	}
	const plain = /filename\s*=\s*"?([^";]+)"?/i.exec(disposition);
	return plain ? plain[1].trim() : null;
}
function toResult(error) {
	if (!(error instanceof HttpErrorResponse)) return of({
		kind: "unavailable",
		reason: "The server export is not available right now."
	});
	if (error.status === 404) return of({
		kind: "unavailable",
		reason: "The server does not offer an export yet."
	});
	if (error.status === 0 || error.status >= 500) return of({
		kind: "unavailable",
		reason: "The server export is not available right now."
	});
	if (error.status === 401 || error.status === 403) return of({
		kind: "refused",
		message: "You are not signed in, or your account cannot export contracts."
	});
	return problemFrom$1(error.error).pipe(map((problem) => ({
		kind: "refused",
		message: problem?.detail ?? problem?.title ?? "The server refused the export.",
		...typeof problem?.traceId === "string" ? { correlationId: problem.traceId } : {}
	})));
}
function problemFrom$1(body) {
	if (body instanceof Blob) return from(body.text()).pipe(map(parseProblem$1), catchError(() => of(null)));
	if (typeof body === "string") return of(parseProblem$1(body));
	return of(isProblem(body) ? body : null);
}
function parseProblem$1(text) {
	try {
		const parsed = JSON.parse(text);
		return isProblem(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function isProblem(value) {
	return typeof value === "object" && value !== null;
}
const quantity = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const price = new Intl.NumberFormat("en-US", {
	minimumFractionDigits: 4,
	maximumFractionDigits: 4
});
function formatQuantity(value) {
	return value === null || value === void 0 ? "" : quantity.format(value);
}
function formatPrice(value) {
	return value === null || value === void 0 ? "" : price.format(value);
}
const MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function formatContractDate(iso) {
	if (!iso) return "";
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!match) return iso;
	const [, year, month, day] = match;
	const name = MONTHS[Number(month) - 1];
	return name ? `${Number(day)} ${name} ${year}` : iso;
}
function formatShortDate(iso) {
	if (!iso) return "";
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!match) return iso;
	const [, year, month, day] = match;
	return `${Number(month)}/${Number(day)}/${year.slice(2)}`;
}
function formatShipPeriod(row) {
	const begin = formatContractDate(row.shipPeriodBegin);
	const end = formatContractDate(row.shipPeriodEnd);
	if (begin && end) return begin === end ? begin : `${begin} – ${end}`;
	return begin || end;
}
function formatCustomerId(row) {
	return row.customerId?.trim() ?? "";
}
function formatCustomerName(row) {
	return isRedactedName(row.customerName) ? "" : row.customerName?.trim() ?? "";
}
function approvalBadge(row) {
	return contractStatusBadge(row.traderApprovalStatus);
}
function confirmBadge(row) {
	return contractStatusBadge(row.customerConfirmStatus);
}
function contractStatusBadge(status) {
	const trimmed = status?.trim();
	if (!trimmed) return null;
	switch (trimmed.toLowerCase()) {
		case "approved":
		case "confirmed": return {
			label: trimmed,
			tone: "positive"
		};
		case "unapproved":
		case "pending": return {
			label: trimmed,
			tone: "caution"
		};
		case "rejected": return {
			label: trimmed,
			tone: "negative"
		};
		default: return {
			label: trimmed,
			tone: "neutral"
		};
	}
}
function contractRowTone(row) {
	switch (row.traderApprovalStatus?.trim().toLowerCase()) {
		case "rejected": return "negative";
		case "unapproved":
		case "pending": return "caution";
		default: return null;
	}
}
const CONTRACT_GRID_COLUMNS = [
	{
		key: "contractNumber",
		header: "Contract",
		priority: 1,
		sortable: true,
		width: 130,
		format: (row) => row.contractNumber
	},
	{
		key: "contractDate",
		header: "Date",
		priority: 1,
		sortable: true,
		filterKind: "date",
		width: 90,
		format: (row) => formatShortDate(row.contractDate),
		sortValue: (row) => row.contractDate ?? "",
		tooltip: (row) => formatContractDate(row.contractDate)
	},
	{
		key: "customerId",
		header: "Customer ID",
		priority: 1,
		cell: CustomerCellComponent,
		sortable: true,
		width: 140,
		format: formatCustomerId,
		searchText: (row) => `${formatCustomerId(row)} ${formatCustomerName(row)}`.trim()
	},
	{
		key: "commodity",
		header: "Commodity",
		priority: 1,
		sortable: true,
		width: 120,
		format: (row) => row.commodity ?? ""
	},
	{
		key: "quantity",
		header: "Quantity",
		priority: 2,
		align: "end",
		sortable: true,
		filterKind: "number",
		width: 130,
		format: (row) => row.quantity === null ? "" : `${quantity.format(row.quantity)} ${row.quantityUom ?? ""}`.trim(),
		sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "price",
		header: "Price",
		priority: 2,
		align: "end",
		sortable: true,
		filterKind: "number",
		width: 110,
		format: (row) => row.price === null ? "" : price.format(row.price),
		sortValue: (row) => row.price ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "priceTypeCode",
		header: "Type",
		priority: 2,
		sortable: true,
		width: 90,
		format: (row) => row.priceTypeCode ?? ""
	},
	{
		key: "marketZone",
		header: "Zone",
		priority: 2,
		sortable: true,
		width: 90,
		format: (row) => row.marketZone ?? ""
	},
	{
		key: "trader",
		header: "Trader",
		priority: 2,
		sortable: true,
		width: 140,
		format: (row) => row.trader ?? row.traderInitials ?? ""
	},
	{
		key: "shipPeriod",
		header: "Ship period",
		priority: 2,
		sortable: true,
		width: 210,
		minWidth: 110,
		format: formatShipPeriod,
		sortValue: (row) => row.shipPeriodBegin ?? ""
	},
	{
		key: "traderApprovalStatus",
		header: "Approval",
		priority: 1,
		sortable: true,
		width: 130,
		format: (row) => row.traderApprovalStatus ?? "",
		badge: approvalBadge
	}
];
const CONFIRMED_COLUMN = {
	key: "customerConfirmStatus",
	header: "Confirmed",
	sortable: true,
	width: 130,
	format: (row) => row.customerConfirmStatus ?? "",
	badge: confirmBadge
};
const CUSTOMER_NAME_EXPORT_COLUMN = {
	key: "customerName",
	header: "Customer name",
	width: 180,
	format: formatCustomerName
};
const CONTRACT_EXPORT_COLUMNS = CONTRACT_GRID_COLUMNS.flatMap((column) => column.key === "customerId" ? [column, CUSTOMER_NAME_EXPORT_COLUMN] : [column]);
var SampleContractExportSource = class SampleContractExportSource {
	all = buildContracts();
	export(request) {
		const { query, fields } = request;
		if (!hasScope(query)) throw new Error("A trade unit or a customer is required. CTRM does not serve an unfiltered contract list.");
		const projected = project(this.all, {
			...query,
			page: 1,
			pageSize: Math.max(1, this.all.length)
		});
		const everything = projected.rows;
		const sorts = parseSortParam(query.sort);
		const ordered = sorts.length === 0 ? everything : [...everything].sort((left, right) => compareBySorts(CONTRACT_GRID_COLUMNS, sorts, left, right));
		const columns = applyExportFields(CONTRACT_EXPORT_COLUMNS, fields.map((key) => ({
			key,
			header: "",
			included: true
		})));
		return of({
			kind: "csv",
			csv: new Blob([toCsv(columns, ordered)], { type: "text/csv;charset=utf-8" }),
			filename: null,
			rowCapReached: projected.rowCapReached,
			rowCap: projected.rowCap
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractExportSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractExportSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleContractExportSource,
	decorators: [{ type: Injectable }]
});
const LOCATION_SOURCE = new InjectionToken("LOCATION_SOURCE");
var HttpLocationSource = class HttpLocationSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	cached = null;
	list() {
		this.cached ??= this.fetch();
		return this.cached;
	}
	fetch() {
		return this.http.get(`${this.baseUrl}/locations`).pipe(map((list) => remoteLoaded(list)), catchError((error) => of(remoteError(toRemoteError$3(error)))), tap((state) => {
			if (state.status === "error") this.cached = null;
		}), startWith(remoteLoading()), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpLocationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpLocationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpLocationSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError$3(error) {
	if (error instanceof HttpErrorResponse) {
		const correlationId = error.error?.traceId;
		if (error.status === 401) return {
			message: "Your session has expired. Please sign in again.",
			correlationId
		};
		if (error.status === 403) return {
			message: "Your account does not have a Contract Management System role. Request access, then sign in again.",
			correlationId
		};
		return {
			message: "We could not load the trade unit list. Please try again.",
			correlationId
		};
	}
	return { message: "We could not load the trade unit list. Please try again." };
}
function groupByCompany(locations) {
	const groups = /* @__PURE__ */ new Map();
	for (const location of locations) {
		const code = location.companyCode ?? "";
		const existing = groups.get(code);
		if (existing) existing.locations.push(location);
		else groups.set(code, {
			code,
			name: location.companyName ?? "Unknown company",
			locations: [location]
		});
	}
	return [...groups.values()].sort((left, right) => left.code.localeCompare(right.code));
}
var HttpOriginDestinationSource = class HttpOriginDestinationSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answers = /* @__PURE__ */ new Map();
	search(text) {
		const typed = text.trim();
		if (typed.length < CODE_SEARCH_MIN_LENGTH) return of(remoteLoaded([]));
		const key = typed.toLowerCase();
		let answer = this.answers.get(key);
		if (answer === void 0) {
			answer = this.fetch(typed, key);
			this.answers.set(key, answer);
		}
		return answer;
	}
	fetch(typed, key) {
		return forkJoin([this.call("code", typed), this.call("name", typed)]).pipe(map(([byCode, byName]) => byCode === null && byName === null ? remoteError({ message: "The origin and destination search is not available right now." }) : remoteLoaded(mergeCodeSearchHits(byCode ?? [], byName ?? []))), tap((state) => {
			if (state.status === "error") this.answers.delete(key);
		}), startWith(remoteLoading()), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	call(parameter, typed) {
		return this.http.get(`${this.baseUrl}/reference/${REFERENCE_ROUTES.originDestinationCodes}?${parameter}=${encodeURIComponent(typed)}`).pipe(map((response) => (response.items ?? []).filter((item) => item.code !== null && item.code.trim() !== "").map((item) => ({
			code: item.code,
			description: item.description ?? item.code
		}))), catchError(() => of(null)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpOriginDestinationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpOriginDestinationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpOriginDestinationSource,
	decorators: [{ type: Injectable }]
});
const SAMPLE_ORIGIN_DESTINATION_CODES = [
	{
		code: "EX-NE01",
		description: "Example Elevator North"
	},
	{
		code: "EX-NE02",
		description: "Example Elevator South"
	},
	{
		code: "EX-NE03",
		description: "Sample Grain Terminal"
	},
	{
		code: "EX-KS01",
		description: "Example Farms Rail Yard"
	},
	{
		code: "EX-KS02",
		description: "Sample River Terminal"
	},
	{
		code: "EX-IA01",
		description: "Example Feed Mill"
	},
	{
		code: "EX-IA02",
		description: "Sample Processing Plant"
	},
	{
		code: "EX-MN01",
		description: "Example Port Terminal"
	}
];
var SampleOriginDestinationSource = class SampleOriginDestinationSource {
	search(text) {
		const typed = text.trim().toLowerCase();
		if (typed.length < CODE_SEARCH_MIN_LENGTH) return of(remoteLoaded([]));
		const byCode = SAMPLE_ORIGIN_DESTINATION_CODES.filter((row) => row.code.toLowerCase() === typed);
		const byName = SAMPLE_ORIGIN_DESTINATION_CODES.filter((row) => row.description.toLowerCase().includes(typed));
		return of(remoteLoaded(mergeCodeSearchHits(byCode, byName)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleOriginDestinationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleOriginDestinationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleOriginDestinationSource,
	decorators: [{ type: Injectable }]
});
function injectTradeUnitLabel() {
	const context = inject(TRADE_UNIT_CONTEXT);
	const locations = toSignal(inject(LOCATION_SOURCE).list(), { initialValue: remoteLoading() });
	return computed(() => {
		const code = context.code();
		if (!code) return null;
		const state = locations();
		const match = state.status === "loaded" ? state.value.locations.find((location) => location.code === code) : void 0;
		return match?.name ? `${code} · ${match.name}` : code;
	});
}
function injectLocationCodes() {
	const locations = toSignal(inject(LOCATION_SOURCE).list(), { initialValue: remoteLoading() });
	return computed(() => {
		const state = locations();
		return state.status === "loaded" ? state.value.locations.map((location) => location.code) : [];
	});
}
const PRICING_SOURCE = new InjectionToken("PRICING_SOURCE");
const MARKET_REFERENCE_SOURCE = new InjectionToken("MARKET_REFERENCE_SOURCE");
var HttpMarketReferenceSource = class HttpMarketReferenceSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	tradeUnitValues = inject(TRADE_UNIT_VALUES_SOURCE);
	cache = /* @__PURE__ */ new Map();
	marketCodes(location, commodityCode) {
		return this.fetch(REFERENCE_ROUTES.marketCodes, {
			location,
			commodityCode
		});
	}
	marketMonths(location, commodityCode, marketCode) {
		const months = this.fetch(REFERENCE_ROUTES.marketMonths, {
			location,
			commodityCode,
			marketCode,
			languageCode: ""
		});
		return combineLatest([months, this.configuredMonths(location, commodityCode)]).pipe(map(([offered, configured]) => offered === null ? null : narrowToConfigured(offered, configured)));
	}
	configuredMonths(location, commodityCode) {
		const commodity = normaliseCode(commodityCode);
		return this.tradeUnitValues.marketMonths(location).pipe(map((rows) => rows.filter((row) => normaliseCode(row.commodity) === commodity).map((row) => ({
			value: row.marketMonth,
			include: true
		}))), catchError(() => of([])));
	}
	fetch(set, params) {
		const key = `${set}?${new URLSearchParams(params).toString()}`;
		const cached = this.cache.get(key);
		if (cached !== void 0) return cached;
		const stream = this.http.get(`${this.baseUrl}/reference/${set}`, { params }).pipe(map((response) => (response.items ?? []).filter((item) => item.code !== null && item.code.trim() !== "").map((item) => ({
			code: item.code,
			description: item.description ?? item.code
		}))), catchError(() => of([])), startWith(null), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
		this.cache.set(key, stream);
		return stream;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpMarketReferenceSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpMarketReferenceSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpMarketReferenceSource,
	decorators: [{ type: Injectable }]
});
var HttpPricingSource = class HttpPricingSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	contractPrices(contract) {
		return this.http.get(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/prices`).pipe(toRemote());
	}
	unapproved(query) {
		let params = new HttpParams();
		if (query.traderInitials) params = params.set("traderInitials", query.traderInitials);
		if (query.location) params = params.set("location", query.location);
		if (query.approverType) params = params.set("approverType", query.approverType);
		return this.http.get(`${this.baseUrl}/pricing/unapproved`, { params }).pipe(toRemote());
	}
	save(contract, sequences) {
		return this.http.post(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/prices`, { sequences }).pipe(toRemote());
	}
	remove(contract, priceSequence) {
		return this.http.delete(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/prices/${priceSequence}`).pipe(map((result) => remoteLoaded(result)), catchError((error) => {
			if (error instanceof HttpErrorResponse && error.status === 404 && error.error?.prices) return of(remoteLoaded({
				contract: error.error.contract ?? contract,
				acknowledgement: error.error.detail ?? "That price sequence had already been removed.",
				verified: true,
				prices: error.error.prices
			}));
			return of(remoteError(toRemoteError$2(error)));
		}), startWith(remoteLoading()));
	}
	approve(contract, priceSequences) {
		return this.http.post(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/approvals`, { priceSequences }).pipe(toRemote());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpPricingSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpPricingSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpPricingSource,
	decorators: [{ type: Injectable }]
});
function toRemote() {
	return (source) => source.pipe(map((value) => remoteLoaded(value)), catchError((error) => of(remoteError(toRemoteError$2(error)))), startWith(remoteLoading()));
}
function toRemoteError$2(error) {
	if (error instanceof HttpErrorResponse) {
		const problem = parseProblem(error);
		const formErrors = problem.formErrors.length > 0 ? problem.formErrors : void 0;
		const status = error.status;
		if (problem.detail !== null || problem.title !== null) return {
			message: problem.detail ?? problem.title ?? "",
			correlationId: problem.traceId ?? void 0,
			formErrors,
			status
		};
		if (problem.kind === ProblemKind.Forbidden) return {
			message: "You do not have permission to change pricing on this contract.",
			formErrors,
			status
		};
		if (error.status === 0) return {
			message: "We could not reach the server.",
			status
		};
		return {
			message: "We could not complete that pricing request.",
			formErrors,
			status
		};
	}
	return { message: "We could not complete that pricing request." };
}
function flatPrice(terms) {
	return (terms.basisPrice ?? 0) + (terms.adjustments ?? 0) + (terms.hedgePrice ?? 0);
}
function flatPriceAgrees(computed, stored) {
	return Math.abs(computed - stored) < 5e-6;
}
function editFromSequence(sequence) {
	return {
		priceSequence: 0,
		pricedQuantity: sequence.pricedQuantity,
		pricedLoads: sequence.pricedLoads,
		hedgePrice: sequence.hedgePrice,
		basisPrice: sequence.basisPrice,
		price: sequence.price,
		hedgeMarketCode: sequence.hedgeMarketCode,
		hedgeMarketMonthCode: sequence.hedgeMarketMonth,
		priceDate: sequence.priceDate,
		remark: sequence.remark,
		description: sequence.priceDescription,
		printFlag: sequence.printFlag
	};
}
function copyPriceSequences(pricing, target, sources) {
	return new Observable((subscriber) => {
		let stopped = false;
		const rows = sources.map((source) => ({
			source,
			outcome: "pending",
			newSequence: null,
			reason: null
		}));
		const emit = (done) => subscriber.next({
			target,
			rows: [...rows],
			done
		});
		const run = async () => {
			emit(false);
			const initial = await settled(pricing.contractPrices(target));
			if (initial.status !== "loaded") {
				rows.forEach((row, index) => {
					rows[index] = {
						...row,
						outcome: "not-copied",
						reason: "The new contract’s prices could not be read, so nothing was posted.",
						correlationId: initial.status === "error" ? initial.error.correlationId ?? null : null
					};
				});
				emit(true);
				return;
			}
			let held = initial.value.prices;
			for (let index = 0; index < rows.length && !stopped; index++) {
				const before = new Set(held.map((sequence) => sequence.priceSequence));
				const write = await settled(pricing.save(target, [editFromSequence(rows[index].source)]));
				if (write.status === "error" && isRefusal(write.error.status)) {
					rows[index] = {
						...rows[index],
						outcome: "not-copied",
						reason: write.error.message,
						correlationId: write.error.correlationId ?? null
					};
					emit(false);
					continue;
				}
				const after = await readBack(pricing, target, write);
				rows[index] = {
					...rows[index],
					...classify(write, before, after)
				};
				if (after !== null) held = after;
				emit(false);
			}
			emit(true);
		};
		run().then(() => subscriber.complete()).catch((error) => subscriber.error(error));
		return () => {
			stopped = true;
		};
	});
}
async function readBack(pricing, target, write) {
	if (write.status === "loaded" && write.value.verified) return write.value.prices;
	const read = await settled(pricing.contractPrices(target));
	return read.status === "loaded" ? read.value.prices : null;
}
function classify(write, before, after) {
	if (after === null) return {
		outcome: "unconfirmed",
		newSequence: null,
		reason: "Posted, but the new contract’s prices could not be read back to check it."
	};
	const added = after.find((sequence) => !before.has(sequence.priceSequence));
	if (added === void 0) return {
		outcome: "unconfirmed",
		newSequence: null,
		reason: write.status === "error" ? `CTRM’s answer could not be used (${write.error.message}), and no new sequence was found when read back.` : "CTRM accepted it, but no new sequence was found when read back."
	};
	if (added.isApproved) return {
		outcome: "unconfirmed",
		newSequence: added.priceSequence,
		reason: `Sequence ${added.priceSequence} read back as approved, so it is not reported as a copy.`
	};
	return {
		outcome: "copied",
		newSequence: added.priceSequence,
		reason: null
	};
}
function isRefusal(status) {
	return status !== void 0 && status >= 400 && status < 500;
}
function settled(source) {
	return firstValueFrom(source.pipe(filter((state) => state.status === "loaded" || state.status === "error")));
}
const APPROVAL_CONTRACT_SOURCE = new InjectionToken("APPROVAL_CONTRACT_SOURCE");
var HttpApprovalContractSource = class HttpApprovalContractSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get(contractNumber) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}`;
		return this.http.get(url).pipe(map((response) => {
			const header = response.contract?.header;
			if (!header) return remoteError({ message: `Contract ${contractNumber} came back without its header.` });
			return remoteLoaded({
				header,
				dataOrigin: response.dataOrigin ?? "Simulated",
				warnings: response.warnings ?? []
			});
		}), catchError((error) => of(remoteError(toRemoteError$1(error, contractNumber)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpApprovalContractSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpApprovalContractSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpApprovalContractSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError$1(error, contractNumber) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 422 && problem?.detail) return {
			message: problem.detail,
			correlationId: problem.correlationId
		};
		if (error.status === 403) return {
			message: "You do not have access to this contract.",
			correlationId: problem?.correlationId
		};
		return {
			message: `We could not load contract ${contractNumber}. Please try again.`,
			correlationId: problem?.correlationId
		};
	}
	return { message: `We could not load contract ${contractNumber}. Please try again.` };
}
const MAX_ECM_RECIPIENTS = 4;
const APPROVAL_ACTION_SOURCE = new InjectionToken("APPROVAL_ACTION_SOURCE");
var HttpApprovalActionSource = class HttpApprovalActionSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	ecmRouting(contractNumber) {
		return this.http.get(`${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/approval/ecm`).pipe(map((body) => toEcmRouting(body)), catchError(() => of({
			esign: null,
			recipients: [],
			origin: "Live",
			reason: "E-signature routing could not be read, so this contract cannot be approved here."
		})));
	}
	approve(contractNumber, ecm) {
		return this.post(contractNumber, {
			decision: "Approved",
			ecm
		});
	}
	reject(contractNumber, reason) {
		return this.post(contractNumber, {
			decision: "Rejected",
			reason
		});
	}
	post(contractNumber, body) {
		return this.http.post(`${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/approval`, body);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpApprovalActionSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpApprovalActionSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpApprovalActionSource,
	decorators: [{ type: Injectable }]
});
function toEcmRouting(body) {
	const value = body ?? {};
	const recipients = Array.isArray(value.recipients) ? value.recipients.filter((entry) => typeof entry === "string" && entry.trim() !== "") : [];
	return typeof value.esign === "boolean" ? {
		esign: value.esign,
		recipients,
		origin: "Live"
	} : {
		esign: null,
		recipients: [],
		origin: "Live",
		reason: "E-signature routing gave no clear answer, so this contract cannot be approved here."
	};
}
var SimulatedApprovalActionSource = class SimulatedApprovalActionSource {
	ecmRouting(_contractNumber) {
		return of({
			esign: false,
			recipients: [],
			origin: "Simulated"
		});
	}
	approve(contractNumber, _ecm) {
		return this.settle(contractNumber, "Approved", "Approved");
	}
	reject(contractNumber, reason) {
		return this.settle(contractNumber, "Rejected", "Rejected", reason);
	}
	settle(contractNumber, decision, status, reason) {
		return of({
			contractNumber,
			decision,
			origin: "Simulated",
			status,
			detail: `Simulated ${decision.toLowerCase()} — CTRM was not contacted.` + (reason === void 0 ? "" : ` Reason recorded locally: ${reason}`)
		}).pipe(delay(400));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SimulatedApprovalActionSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SimulatedApprovalActionSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SimulatedApprovalActionSource,
	decorators: [{ type: Injectable }]
});
const APPROVAL_QUEUE_SOURCE = new InjectionToken("APPROVAL_QUEUE_SOURCE");
const APPROVAL_QUEUE_NOT_DEPLOYED = { kind: "notDeployed" };
const FAILED$3 = "We could not load your approval queue. Please try again.";
const UNREADABLE = "We could not load your approval queue. The server's answer could not be read.";
const APPROVER_TYPES = /* @__PURE__ */ new Set(["PRIMARY", "BOTH"]);
const APPROVAL_QUEUE_REFUSALS = {
	"ctrm-user-not-found": {
		title: "We couldn't find your CTRM user.",
		detail: "Contact the Help Desk and ask them to check that your CTRM user record is active and has your email address. Reference: CWS-APPR-NO-USER."
	},
	"ctrm-user-ambiguous": {
		title: "Your email address is on more than one CTRM user record.",
		detail: "We can't tell which one is you. Contact the Help Desk and ask them to keep your email on one CTRM user only. Reference: CWS-APPR-EMAIL-SHARED."
	},
	"ctrm-trader-initials-shared": {
		title: "Your CTRM trader initials are also assigned to another CTRM user.",
		detail: "We can't safely show your approvals. Contact the Help Desk and ask them to give you unique trader initials. Reference: CWS-APPR-INITIALS-SHARED."
	}
};
var HttpApprovalQueueSource = class HttpApprovalQueueSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	read(options) {
		const params = options?.refresh ? new HttpParams().set("refresh", true) : new HttpParams();
		return this.http.get(`${this.baseUrl}/approvals/queue`, { params }).pipe(map((body) => readQueue(body)), catchError((error) => of(readFailure(error))));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpApprovalQueueSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpApprovalQueueSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpApprovalQueueSource,
	decorators: [{ type: Injectable }]
});
function readQueue(body) {
	const raw = body !== null && typeof body === "object" ? body : null;
	if (raw === null || !Array.isArray(raw["rows"])) return {
		kind: "failed",
		message: UNREADABLE,
		correlationId: null
	};
	return {
		kind: "loaded",
		page: normalizeContractListPage({
			...raw,
			warnings: Array.isArray(raw["warnings"]) ? raw["warnings"].filter((warning) => typeof warning === "string") : []
		}),
		approver: readApprover(raw["approver"])
	};
}
function readApprover(value) {
	const raw = value !== null && typeof value === "object" ? value : {};
	const initials = typeof raw["traderInitials"] === "string" ? raw["traderInitials"].trim() : "";
	const type = raw["approverType"];
	return {
		traderInitials: initials === "" ? null : initials,
		approverType: typeof type === "string" && APPROVER_TYPES.has(type) ? type : null
	};
}
function readFailure(error) {
	const problem = problemFrom(error);
	if (problem.status === 404 || problem.status === 0) return APPROVAL_QUEUE_NOT_DEPLOYED;
	const refusal = problem.status === 403 && problem.type !== null && Object.hasOwn(APPROVAL_QUEUE_REFUSALS, problem.type) ? APPROVAL_QUEUE_REFUSALS[problem.type] : void 0;
	if (refusal !== void 0) return {
		kind: "refused",
		title: problem.title ?? refusal.title,
		detail: problem.detail ?? refusal.detail,
		correlationId: problem.traceId
	};
	if (problem.status === 401 || problem.status === 403) return {
		kind: "failed",
		message: "You are not signed in, or your account cannot view the approval queue.",
		correlationId: problem.traceId
	};
	return {
		kind: "failed",
		message: problem.detail ?? FAILED$3,
		correlationId: problem.traceId
	};
}
const SAMPLE_APPROVER_INITIALS = "MKD";
var SampleApprovalQueueSource = class SampleApprovalQueueSource {
	rows = buildContracts().filter((row) => row.traderInitials === "MKD");
	read(_options) {
		return of({
			kind: "loaded",
			page: {
				rows: this.rows,
				totalCount: this.rows.length,
				page: 1,
				pageSize: Math.max(this.rows.length, 1),
				totalPages: 1,
				dataOrigin: "Simulated",
				filteredInProcess: false,
				appliedSort: null,
				rowCapReached: false,
				rowCap: 2e3,
				warnings: []
			},
			approver: {
				traderInitials: "MKD",
				approverType: "PRIMARY"
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleApprovalQueueSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleApprovalQueueSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleApprovalQueueSource,
	decorators: [{ type: Injectable }]
});
const WEIGHT_LIMIT_NOT_CHECKED = { status: "notChecked" };
const WEIGHT_LIMIT_CHECK_SOURCE = new InjectionToken("WEIGHT_LIMIT_CHECK_SOURCE");
function weightLimitRuleApplies(buyersEquipment, transportationTypeCode) {
	const equipment = buyersEquipment === true || typeof buyersEquipment === "string" && buyersEquipment.trim().toUpperCase() === "Y";
	const type = typeof transportationTypeCode === "string" ? transportationTypeCode.trim().toUpperCase() : "";
	return equipment && type !== "" && type !== "T";
}
const WEIGHT_LIMIT_CHECKING_MESSAGE = "Checking the weight per unit of equipment against CTRM's limit…";
const WEIGHT_LIMIT_DRIVER_MESSAGE = "Sets the weight per unit of equipment, which is outside CTRM's limit for this transportation type.";
function weightLimitMessage(verdict) {
	const unit = verdict.unit.toLowerCase();
	const weight = `${formatAmount(verdict.weight)} ${unit} per unit of equipment`;
	const range = `${formatAmount(verdict.lowerLimit)}–${formatAmount(verdict.upperLimit)} ${unit}`;
	const description = verdict.transportationTypeDescription?.trim();
	const type = description ? description : `transportation type ${verdict.transportationTypeCode}`;
	return verdict.status === "outside" ? `${weight} is outside the ${range} CTRM allows for ${type}. Change the quantity or the transportation units.` : `${weight}, within the ${range} CTRM allows for ${type}.`;
}
function formatAmount(value) {
	return value.toLocaleString("en-US", { maximumFractionDigits: 4 });
}
var HttpWeightLimitCheckSource = class HttpWeightLimitCheckSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	check(request) {
		return this.http.post(`${this.baseUrl}/contracts/weight-limit-check`, request).pipe(map(verdictOf), catchError(() => of(WEIGHT_LIMIT_NOT_CHECKED)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpWeightLimitCheckSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpWeightLimitCheckSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpWeightLimitCheckSource,
	decorators: [{ type: Injectable }]
});
function verdictOf(wire) {
	const status = wire?.outcome === "Within" ? "within" : wire?.outcome === "Outside" ? "outside" : null;
	const weight = finite(wire?.weight);
	const lowerLimit = finite(wire?.lowerLimit);
	const upperLimit = finite(wire?.upperLimit);
	const unit = text$1(wire?.limitUnit);
	const transportationTypeCode = text$1(wire?.transportationTypeCode);
	if (status === null || weight === null || lowerLimit === null || upperLimit === null || unit === null || transportationTypeCode === null) return WEIGHT_LIMIT_NOT_CHECKED;
	return {
		status,
		weight,
		unit,
		lowerLimit,
		upperLimit,
		transportationTypeCode,
		transportationTypeDescription: text$1(wire?.transportationTypeDescription)
	};
}
function finite(value) {
	return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function text$1(value) {
	return typeof value === "string" && value.trim() !== "" ? value.trim() : null;
}
const SAMPLE_RAIL_WEIGHT_LIMITS = {
	lowerLimit: 5e4,
	upperLimit: 25e4
};
const SAMPLE_POUNDS_PER_UNIT = {
	LB: 1,
	CWT: 100,
	BU: 56
};
var SimulatedWeightLimitCheckSource = class SimulatedWeightLimitCheckSource {
	check(request) {
		const { fields } = request;
		const type = fields.transportation_type_code.trim().toUpperCase();
		const factor = SAMPLE_POUNDS_PER_UNIT[fields.quantity_uom.trim().toUpperCase()];
		if (!weightLimitRuleApplies(fields.buyers_equipment, type) || type !== "R" || factor === void 0) return of(WEIGHT_LIMIT_NOT_CHECKED);
		const units = fields.transportation_units;
		const weight = fields.quantity * factor / (units !== 0 ? units : 1);
		const { lowerLimit, upperLimit } = SAMPLE_RAIL_WEIGHT_LIMITS;
		return of({
			status: weight < lowerLimit || weight > upperLimit ? "outside" : "within",
			weight,
			unit: "LB",
			lowerLimit,
			upperLimit,
			transportationTypeCode: type,
			transportationTypeDescription: "Rail"
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SimulatedWeightLimitCheckSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SimulatedWeightLimitCheckSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SimulatedWeightLimitCheckSource,
	decorators: [{ type: Injectable }]
});
const TRADE_UNIT_VISIBILITY_SOURCE = new InjectionToken("TRADE_UNIT_VISIBILITY_SOURCE");
const TRADE_UNIT_VISIBILITY_UNAVAILABLE = { status: "unavailable" };
const CONFIG_STORE_HEADER = "X-CMS-Config-Store";
function keptInFrom(store) {
	switch (store?.trim()) {
		case "Database": return "account";
		case "InMemory": return "server-memory";
		default: return "unknown";
	}
}
var HttpTradeUnitVisibilitySource = class HttpTradeUnitVisibilitySource {
	http = inject(HttpClient);
	url = `${inject(CONTRACTS_API_URL)}/me/trade-unit-visibility`;
	get() {
		return this.http.get(this.url).pipe(map((body) => {
			const hidden = body?.hidden;
			return Array.isArray(hidden) && hidden.every((code) => typeof code === "string") ? {
				status: "available",
				hidden
			} : TRADE_UNIT_VISIBILITY_UNAVAILABLE;
		}), catchError(() => of(TRADE_UNIT_VISIBILITY_UNAVAILABLE)));
	}
	save(hidden) {
		return this.http.put(this.url, { hidden }, { observe: "response" }).pipe(map((response) => ({
			kind: "saved",
			keptIn: keptInFrom(response.headers.get(CONFIG_STORE_HEADER))
		})), catchError((error) => of({
			kind: "failed",
			correlationId: correlationIdOf(error)
		})));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpTradeUnitVisibilitySource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpTradeUnitVisibilitySource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpTradeUnitVisibilitySource,
	decorators: [{ type: Injectable }]
});
const SAMPLE_HIDDEN_TRADE_UNITS = ["0428", "0641"];
var SampleTradeUnitVisibilitySource = class SampleTradeUnitVisibilitySource {
	hidden = SAMPLE_HIDDEN_TRADE_UNITS;
	get() {
		return of({
			status: "available",
			hidden: this.hidden
		});
	}
	save(hidden) {
		this.hidden = hidden;
		return of({
			kind: "saved",
			keptIn: "session"
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleTradeUnitVisibilitySource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleTradeUnitVisibilitySource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleTradeUnitVisibilitySource,
	decorators: [{ type: Injectable }]
});
const DEFAULT_TRADE_UNIT_SOURCE = new InjectionToken("DEFAULT_TRADE_UNIT_SOURCE");
const GRID_COLUMN_PREFERENCE_SOURCE = new InjectionToken("GRID_COLUMN_PREFERENCE_SOURCE");
const GRID_COLUMN_SERVER_SOURCE = new InjectionToken("GRID_COLUMN_SERVER_SOURCE");
const GRID_COLUMN_OWNER = new InjectionToken("GRID_COLUMN_OWNER");
const GRID_COLUMNS_UNAVAILABLE = { status: "unavailable" };
const LOCATION_CODE = /^\d{1,4}$/;
var LocalFirstDefaultTradeUnitSource = class LocalFirstDefaultTradeUnitSource {
	http = inject(HttpClient);
	url = `${inject(CONTRACTS_API_URL)}/me/default-trade-unit`;
	owner = inject(GRID_COLUMN_OWNER, { optional: true });
	get() {
		return this.http.get(this.url).pipe(map((body) => {
			const code = body?.tradeUnit;
			if (code === null) return {
				status: "available",
				code: null
			};
			return typeof code === "string" && LOCATION_CODE.test(code) ? {
				status: "available",
				code
			} : this.readLocal();
		}), catchError(() => of(this.readLocal())));
	}
	save(code) {
		return this.http.put(this.url, { tradeUnit: code }).pipe(map(() => ({
			kind: "saved",
			keptIn: "account"
		})), catchError((error) => of(this.writeLocal(code) ? {
			kind: "saved",
			keptIn: "browser"
		} : {
			kind: "failed",
			correlationId: correlationIdOf(error)
		})));
	}
	key() {
		const owner = this.owner?.() ?? null;
		return owner === null || owner === "" ? null : `cws.defaultTradeUnit.${owner}`;
	}
	readLocal() {
		const key = this.key();
		if (key === null) return { status: "unavailable" };
		try {
			const stored = localStorage.getItem(key);
			return {
				status: "available",
				code: stored !== null && LOCATION_CODE.test(stored) ? stored : null
			};
		} catch {
			return {
				status: "available",
				code: null
			};
		}
	}
	writeLocal(code) {
		const key = this.key();
		if (key === null) return false;
		try {
			if (code === null) localStorage.removeItem(key);
			else localStorage.setItem(key, code);
			return true;
		} catch {
			return false;
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: LocalFirstDefaultTradeUnitSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: LocalFirstDefaultTradeUnitSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: LocalFirstDefaultTradeUnitSource,
	decorators: [{ type: Injectable }]
});
const FORM_CONFIG_ADMIN_SOURCE = new InjectionToken("FORM_CONFIG_ADMIN_SOURCE");
const UNKNOWN_SETTINGS_SCOPE = {
	known: false,
	isAdmin: false,
	tradeUnits: [],
	onboarded: []
};
function settingsScopeOf(me) {
	if (me === null || me.status !== "Available") return UNKNOWN_SETTINGS_SCOPE;
	return {
		known: true,
		isAdmin: me.isAdmin,
		tradeUnits: me.isAdmin ? [] : me.tradeUnits.filter((unit) => unit.permissions.includes(PermissionKeys.SettingsManage)).map((unit) => unit.code),
		onboarded: me.onboardedTradeUnits
	};
}
function holdsAnyPermissionIn(me, tradeUnit) {
	const code = tradeUnit?.trim() ?? "";
	if (me === null || me.status !== "Available" || code === "") return null;
	if (me.isAdmin) return true;
	const known = new Set(Object.values(PermissionKeys));
	return me.tradeUnits.some((unit) => unit.code.trim() === code && unit.permissions.some((permission) => known.has(permission)));
}
function textOf(value) {
	return typeof value === "string" && value.trim() !== "" ? value : null;
}
function adminRefusalOf(error) {
	const problem = problemFrom(error);
	const body = error?.error;
	const raw = body !== null && typeof body === "object" ? body : {};
	const sentence = [problem.title, problem.detail].filter((part) => part !== null).join(". ").replace(/\.\./g, ".");
	const base = {
		status: problem.status,
		required: textOf(raw["required"]),
		tradeUnit: textOf(raw["tradeUnit"]),
		reason: textOf(raw["reason"]),
		fieldErrors: problem.errors,
		correlationId: problem.traceId
	};
	if (problem.status === 401) return {
		...base,
		message: "You are not signed in. Sign in again and retry."
	};
	if (problem.status === 403) return {
		...base,
		message: sentence !== "" ? sentence : "This account cannot make this change. Nothing was written."
	};
	if (problem.status === 400) return {
		...base,
		message: Object.keys(problem.errors).length > 0 ? "The change was refused. Nothing was saved." : sentence || "The change was refused."
	};
	if (problem.status === 503) return {
		...base,
		message: sentence !== "" ? sentence : "The service could not be checked, so nothing was saved. Try again shortly."
	};
	return {
		...base,
		message: "The configuration service could not be reached."
	};
}
var HttpFormConfigAdminSource = class HttpFormConfigAdminSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	list() {
		return this.http.get(`${this.baseUrl}/form-configurations`).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	registry() {
		return this.http.get(`${this.baseUrl}/form-configurations/registry`).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	auditTrail(id) {
		return this.http.get(`${this.baseUrl}/form-configurations/${id}/audit`).pipe(map((response) => remoteLoaded({
			entries: response.entries,
			partial: response.partial === true
		})), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	get(id) {
		return this.http.get(`${this.baseUrl}/form-configurations/${id}`).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	create(submission) {
		return this.http.post(`${this.baseUrl}/form-configurations`, submission).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	update(id, rowVersion, submission) {
		return this.http.put(`${this.baseUrl}/form-configurations/${id}`, submission, { headers: { "If-Match": rowVersion } }).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	preview(dimensions) {
		const params = Object.entries(dimensions).filter(([, value]) => value !== void 0 && value !== "").reduce((carry, [key, value]) => ({
			...carry,
			[key]: value
		}), {});
		return this.http.get(`${this.baseUrl}/form-configurations/resolve`, { params }).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	deactivate(id, rowVersion) {
		return this.http.delete(`${this.baseUrl}/form-configurations/${id}`, { headers: { "If-Match": rowVersion } }).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpFormConfigAdminSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpFormConfigAdminSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpFormConfigAdminSource,
	decorators: [{ type: Injectable }]
});
function describe(error) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 400 && problem?.errors !== void 0) return {
			message: `The configuration was refused:\n${Object.entries(problem.errors).map(([key, messages]) => `${key.replace("config.fields.", "").replace("config.collections.", "Collection ").replace("config.remarkTypes.", "Remark type ")}: ${messages.join(" ")}`).join("\n")}`,
			correlationId: problem.traceId
		};
		if (error.status === 401 || error.status === 403) return {
			message: adminRefusalOf(error).message,
			correlationId: problem?.traceId
		};
		if (error.status === 409) return {
			message: problem?.detail ?? "This configuration changed since the list was loaded. Reload before changing it again.",
			correlationId: problem?.traceId
		};
		return {
			message: problem?.detail ?? "The configuration service could not be reached.",
			correlationId: problem?.traceId
		};
	}
	return { message: "The configuration service could not be reached." };
}
const CONTRACT_DETAIL_SOURCE = new InjectionToken("CONTRACT_DETAIL_SOURCE");
var HttpContractDetailSource = class HttpContractDetailSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get(contractNumber) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}`;
		return this.http.get(url).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(toRemoteError(error, contractNumber)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractDetailSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractDetailSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractDetailSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError(error, contractNumber) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 422 || error.status === 400) {
			const formErrors = problemFrom(error).formErrors;
			return {
				message: problem?.detail ?? problem?.title ?? `Contract ${contractNumber} could not be loaded.`,
				correlationId: problem?.traceId,
				...formErrors.length > 0 ? { formErrors } : {}
			};
		}
		if (error.status === 404) return {
			message: "That contract route is not available. This is a configuration problem rather than a missing contract — CTRM reports an unknown contract as a rejection, not a 404.",
			correlationId: problem?.traceId
		};
		if (error.status === 401 || error.status === 403) return {
			message: "You are not signed in, or your account cannot view contracts.",
			correlationId: problem?.traceId
		};
		return {
			message: `We could not load contract ${contractNumber}. Please try again.`,
			correlationId: problem?.traceId
		};
	}
	return { message: `We could not load contract ${contractNumber}. Please try again.` };
}
const CTRM_CONTRACT_NOT_FOUND = "Contract not found.";
const OUTCOMES = {
	"not-found": {
		kind: "not-found",
		title: "Contract not found",
		message: "CTRM has no contract with this number, so no price sequence can be added to it.",
		holdsAdd: "CTRM has no contract with this number"
	},
	"date-closed": {
		kind: "date-closed",
		title: "Contract closed",
		message: "This contract has a close date in CTRM, and CTRM does not accept a new price sequence on a closed contract.",
		holdsAdd: "The contract is closed in CTRM"
	},
	"unpriced-zero": {
		kind: "unpriced-zero",
		title: "Nothing left to price",
		message: "CTRM shows no unpriced quantity on this contract, so a new price sequence would be refused. The queue may have listed it before the last price was saved.",
		holdsAdd: "CTRM shows no unpriced quantity left"
	},
	unchecked: {
		kind: "unchecked",
		title: "Could not re-check this contract",
		message: "The contract could not be read from CTRM, so whether it can still be priced is unknown. You can still add a price sequence; CTRM will refuse it if the contract cannot take one.",
		holdsAdd: null
	},
	success: {
		kind: "success",
		title: "",
		message: "",
		holdsAdd: null
	}
};
function unpricedOpenOutcomeOf(read) {
	switch (read.status) {
		case "idle":
		case "loading": return null;
		case "error": return (read.error.formErrors ?? []).some((reason) => reason.trim() === "Contract not found.") ? OUTCOMES["not-found"] : OUTCOMES.unchecked;
		case "loaded": {
			const { header, quantities } = read.value.contract;
			if (header.isClosed) return OUTCOMES["date-closed"];
			if (quantities.unpriced !== null && quantities.unpriced <= 0) return OUTCOMES["unpriced-zero"];
			return OUTCOMES.success;
		}
	}
}
const PINNED_GRID_COLUMN = "contractNumber";
function known(keys, allKeys) {
	const all = new Set(allKeys);
	const seen = /* @__PURE__ */ new Set();
	return keys.filter((key) => {
		if (!all.has(key) || seen.has(key)) return false;
		seen.add(key);
		return true;
	});
}
function withPinned(keys, allKeys) {
	if (!allKeys.includes("contractNumber") || keys.includes("contractNumber")) return [...keys];
	return [PINNED_GRID_COLUMN, ...keys];
}
function tradeUnitGridColumnKeys(allKeys, tradeUnitKeys) {
	if (tradeUnitKeys === null) return [...allKeys];
	const allowed = known(tradeUnitKeys, allKeys);
	return allowed.length === 0 ? [...allKeys] : withPinned(allowed, allKeys);
}
function visibleGridColumnKeys(allKeys, tradeUnitKeys, userKeys, condensedKeys = null) {
	const allowed = tradeUnitGridColumnKeys(allKeys, tradeUnitKeys);
	if (userKeys !== null) return withPinned(known(userKeys, allowed), allowed);
	if (condensedKeys === null) return allowed;
	const keep = new Set(condensedKeys);
	return withPinned(allowed.filter((key) => keep.has(key)), allowed);
}
function gridColumnChoices(allKeys, tradeUnitKeys, userKeys, condensedKeys = null) {
	const visible = visibleGridColumnKeys(allKeys, tradeUnitKeys, userKeys, condensedKeys);
	const shown = new Set(visible);
	const hidden = tradeUnitGridColumnKeys(allKeys, tradeUnitKeys).filter((key) => !shown.has(key));
	return [...visible.map((key) => ({
		key,
		shown: true
	})), ...hidden.map((key) => ({
		key,
		shown: false
	}))];
}
function userGridColumnKeys(choices) {
	return choices.filter((choice) => choice.shown).map((choice) => choice.key);
}
const HOME_GRID_COLUMNS_SOURCE = new InjectionToken("HOME_GRID_COLUMNS_SOURCE");
function columnKeysOf(value) {
	return Array.isArray(value) && value.every((key) => typeof key === "string") ? value : null;
}
var SampleHomeGridColumnsSource = class SampleHomeGridColumnsSource {
	static narrowedTradeUnit = "0315";
	static narrowedColumns = [
		"contractNumber",
		"customerId",
		"commodity",
		"quantity",
		"price",
		"traderApprovalStatus"
	];
	forTradeUnit(tradeUnit) {
		return of(tradeUnit === SampleHomeGridColumnsSource.narrowedTradeUnit ? SampleHomeGridColumnsSource.narrowedColumns : null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleHomeGridColumnsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleHomeGridColumnsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleHomeGridColumnsSource,
	decorators: [{ type: Injectable }]
});
var HttpHomeGridColumnsSource = class HttpHomeGridColumnsSource {
	http = inject(HttpClient);
	url = `${inject(CONTRACTS_API_URL)}/form-configurations/resolve`;
	cache = /* @__PURE__ */ new Map();
	forTradeUnit(tradeUnit) {
		const cached = this.cache.get(tradeUnit);
		if (cached !== void 0) return cached;
		const read = this.http.get(this.url, { params: new HttpParams().set("locationCode", tradeUnit) }).pipe(map((body) => columnKeysOf(body?.tradeUnitAttributes?.homeGridColumns)), catchError(() => of(null)), shareReplay(1));
		this.cache.set(tradeUnit, read);
		return read;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpHomeGridColumnsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpHomeGridColumnsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpHomeGridColumnsSource,
	decorators: [{ type: Injectable }]
});
var HttpGridColumnPreferenceSource = class HttpGridColumnPreferenceSource {
	http = inject(HttpClient);
	url = `${inject(CONTRACTS_API_URL)}/me/grid-columns`;
	get(tradeUnit) {
		return this.http.get(this.url, { params: new HttpParams().set("tradeUnit", tradeUnit) }).pipe(map((body) => {
			if (body?.columns === null) return {
				status: "available",
				columns: null
			};
			const columns = columnKeysOf(body?.columns);
			return columns === null ? GRID_COLUMNS_UNAVAILABLE : {
				status: "available",
				columns
			};
		}), catchError(() => of(GRID_COLUMNS_UNAVAILABLE)));
	}
	save(tradeUnit, columns) {
		return this.http.put(this.url, {
			tradeUnit,
			columns: columns ?? []
		}).pipe(map(() => "saved"), catchError((error) => of({
			kind: "failed",
			correlationId: correlationIdOf(error)
		})));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpGridColumnPreferenceSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpGridColumnPreferenceSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpGridColumnPreferenceSource,
	decorators: [{ type: Injectable }]
});
var LocalFirstGridColumnPreferenceSource = class LocalFirstGridColumnPreferenceSource {
	server = inject(GRID_COLUMN_SERVER_SOURCE, { optional: true });
	owner = inject(GRID_COLUMN_OWNER, { optional: true });
	get(tradeUnit) {
		if (this.server === null) return of(this.readLocal(tradeUnit));
		return this.server.get(tradeUnit).pipe(map((answer) => answer.status === "available" ? answer : this.readLocal(tradeUnit)));
	}
	save(tradeUnit, columns) {
		const local = () => of(this.writeLocal(tradeUnit, columns));
		if (this.server === null) return local();
		return this.server.save(tradeUnit, columns).pipe(switchMap((outcome) => {
			if (outcome === "saved") return of(outcome);
			const reference = typeof outcome === "object" ? outcome.correlationId : null;
			return local().pipe(map((kept) => kept === "failed" ? {
				kind: "failed",
				correlationId: reference
			} : kept));
		}));
	}
	key(tradeUnit) {
		const owner = this.owner?.() ?? null;
		return owner === null || owner === "" ? null : `cws.gridColumns.${owner}.${tradeUnit}`;
	}
	readLocal(tradeUnit) {
		const key = this.key(tradeUnit);
		if (key === null) return GRID_COLUMNS_UNAVAILABLE;
		try {
			const stored = localStorage.getItem(key);
			return {
				status: "available",
				columns: stored === null ? null : columnKeysOf(JSON.parse(stored))
			};
		} catch {
			return {
				status: "available",
				columns: null
			};
		}
	}
	writeLocal(tradeUnit, columns) {
		const key = this.key(tradeUnit);
		if (key === null) return "failed";
		try {
			if (columns === null) localStorage.removeItem(key);
			else localStorage.setItem(key, JSON.stringify(columns));
			return "browser";
		} catch {
			return "failed";
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: LocalFirstGridColumnPreferenceSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: LocalFirstGridColumnPreferenceSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: LocalFirstGridColumnPreferenceSource,
	decorators: [{ type: Injectable }]
});
const DEFAULT_ADDENDUM_LANGUAGE = "ENUS";
const DEFAULT_ADDENDUM_CONTENT_FORMAT = "text/plain";
const ADDENDUM_CONFLICT_MESSAGE = "This changed since you opened it. Reload to see the current version, then make your change again.";
const ADDENDUM_TEMPLATE_SOURCE = new InjectionToken("ADDENDUM_TEMPLATE_SOURCE");
const ADDENDUM_GENERATION_SOURCE = new InjectionToken("ADDENDUM_GENERATION_SOURCE");
const ADDENDUM_TYPE_SOURCE = new InjectionToken("ADDENDUM_TYPE_SOURCE");
function draftOf(template) {
	return {
		name: template.name,
		specialTypes: template.specialTypes,
		language: template.language,
		tradeUnits: template.tradeUnits,
		templateContent: template.templateContent,
		contentFormat: template.contentFormat,
		fields: template.fields,
		active: template.active,
		...template.initialsAnchorOptional === void 0 ? {} : { initialsAnchorOptional: template.initialsAnchorOptional }
	};
}
function typeDraftOf(type) {
	return {
		specialType: type.specialType,
		displayName: type.displayName,
		family: type.family,
		available: type.available
	};
}
function addendumTemplatesFor(templates, types, specialType, tradeUnit) {
	const code = (specialType ?? "").trim();
	const unit = (tradeUnit ?? "").trim();
	const type = types.find((candidate) => candidate.specialType.trim() === code);
	if (code === "" || type === void 0 || !type.available) return [];
	return templates.filter((template) => template.active && template.specialTypes.some((served) => served.trim() === code) && (template.tradeUnits.length === 0 || template.tradeUnits.includes(unit)));
}
function ifMatch(rowVersion) {
	return { headers: { "If-Match": `"${rowVersion}"` } };
}
var HttpAddendumTemplateSource = class HttpAddendumTemplateSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get templatesUrl() {
		return `${this.baseUrl}/addendum-templates`;
	}
	list() {
		return settle(this.http.get(this.templatesUrl), "templates");
	}
	create(draft) {
		return settle(this.http.post(this.templatesUrl, draft), "templates");
	}
	update(id, rowVersion, draft) {
		return settle(this.http.put(`${this.templatesUrl}/${id}`, draft, ifMatch(rowVersion)), "templates");
	}
	deactivate(template) {
		return this.update(template.id, template.rowVersion, {
			...draftOf(template),
			active: false
		});
	}
	remove(template) {
		return settle(this.http.delete(`${this.templatesUrl}/${template.id}`, ifMatch(template.rowVersion)).pipe(map(() => void 0)), "templates");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumTemplateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumTemplateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpAddendumTemplateSource,
	decorators: [{ type: Injectable }]
});
var HttpAddendumTypeSource = class HttpAddendumTypeSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get typesUrl() {
		return `${this.baseUrl}/addendum-types`;
	}
	typeUrl(specialType) {
		return `${this.typesUrl}/${encodeURIComponent(specialType.trim())}`;
	}
	list() {
		return settle(this.http.get(this.typesUrl), "types");
	}
	create(draft) {
		return settle(this.http.post(this.typesUrl, draft), "types");
	}
	update(type, draft) {
		return settle(this.http.put(this.typeUrl(type.specialType), draft, ifMatch(type.rowVersion)), "types");
	}
	remove(type) {
		return settle(this.http.delete(this.typeUrl(type.specialType), ifMatch(type.rowVersion)).pipe(map(() => void 0)), "types");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumTypeSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumTypeSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpAddendumTypeSource,
	decorators: [{ type: Injectable }]
});
var HttpAddendumGenerationSource = class HttpAddendumGenerationSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	generate(contractNumber, request) {
		return settle(this.http.post(`${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/addendums`, request), "generation");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumGenerationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumGenerationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpAddendumGenerationSource,
	decorators: [{ type: Injectable }]
});
var HttpAddendumListSource = class HttpAddendumListSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	list(contractNumber) {
		return settle(this.http.get(`${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/addendums`), "list");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumListSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumListSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpAddendumListSource,
	decorators: [{ type: Injectable }]
});
const UNAVAILABLE$2 = {
	templates: "Addendum templates are not available yet. The server does not offer them.",
	types: "Addendum types are not available yet. The server does not offer them.",
	generation: "Generating an addendum is not available yet. The server does not offer it.",
	list: "Listing stored addendums is not available. The server does not offer it."
};
const FAILED$2 = {
	templates: "The addendum template service could not complete that. Please try again.",
	types: "The addendum type service could not complete that. Please try again.",
	generation: "The addendum could not be generated. Please try again.",
	list: "The stored addendums could not be listed. Please try again."
};
function settle(request, subject) {
	return request.pipe(map((value) => ({
		kind: "done",
		value
	})), catchError((error) => of(toCall$1(error, subject))));
}
function toCall$1(error, subject) {
	if (!(error instanceof HttpErrorResponse)) return {
		kind: "failed",
		message: FAILED$2[subject]
	};
	const problem = typeof error.error === "object" && error.error !== null ? error.error : null;
	if (error.status === 0 || error.status === 404 && !problem?.detail && !problem?.title) return {
		kind: "unavailable",
		reason: UNAVAILABLE$2[subject]
	};
	const correlationId = problem?.traceId ?? void 0;
	const reference = correlationId === void 0 ? {} : { correlationId };
	if (error.status === 401 || error.status === 403) return {
		kind: "failed",
		message: "You are not signed in, or your account cannot do that.",
		...reference
	};
	if (error.status === 409) return {
		kind: "conflict",
		message: problem?.detail ?? "This changed since you opened it. Reload to see the current version, then make your change again.",
		...reference
	};
	const fieldErrors = fieldErrorsOf$2(problem?.errors);
	const reasons = Object.values(fieldErrors).flat();
	return {
		kind: "failed",
		message: problem?.detail ?? (reasons.length > 0 ? reasons.join(" ") : null) ?? problem?.title ?? FAILED$2[subject],
		...reference,
		...Object.keys(fieldErrors).length === 0 ? {} : { fieldErrors }
	};
}
function fieldErrorsOf$2(raw) {
	if (typeof raw !== "object" || raw === null) return {};
	const fields = {};
	for (const [key, value] of Object.entries(raw)) {
		const messages = Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
		if (messages.length > 0) fields[key] = messages;
	}
	return fields;
}
const ADDENDUM_PLACEHOLDER_NOTICE = "PLACEHOLDER, not Legal's approved wording. An administrator replaces this text with the approved template.";
const CONTRACT_NUMBER_FIELD = "contract_number";
function sampleAddendumTemplate(set, id) {
	const placeholderOf = (cwsField) => cwsField.replace(/^addendum_/, "");
	const lines = set.fields.map((field) => `${field.label}: {{${placeholderOf(field.cwsField)}}}`);
	return {
		id,
		name: `${set.title} (sample)`,
		specialTypes: set.specialTypes,
		language: DEFAULT_ADDENDUM_LANGUAGE,
		tradeUnits: [],
		templateContent: [
			ADDENDUM_PLACEHOLDER_NOTICE,
			"",
			`${set.title} addendum to contract {{contract_number}}`,
			...lines,
			"",
			`Signature: ${ADDENDUM_SIGNATURE_ANCHOR}`,
			`Date: ${ADDENDUM_DATE_ANCHOR}`,
			`Initials: ${ADDENDUM_INITIALS_ANCHOR}`
		].join("\n"),
		contentFormat: DEFAULT_ADDENDUM_CONTENT_FORMAT,
		fields: [{
			placeholder: "contract_number",
			field: CONTRACT_NUMBER_FIELD
		}, ...set.fields.map((field) => ({
			placeholder: placeholderOf(field.cwsField),
			field: field.cwsField
		}))],
		active: true,
		version: 1,
		rowVersion: `sample-${id}-1`
	};
}
var SampleAddendumTemplateSource = class SampleAddendumTemplateSource {
	templates = FAMILY_B_ADDENDUM_FIELD_SETS.map((set, index) => sampleAddendumTemplate(set, index + 1));
	nextId = this.templates.length + 1;
	changes = 0;
	list() {
		return of({
			kind: "done",
			value: [...this.templates]
		});
	}
	create(draft) {
		const refusal = refusalOf$1(draft);
		if (refusal !== null) return of(refusal);
		const id = this.nextId++;
		const template = {
			...draft,
			id,
			version: 1,
			rowVersion: this.nextRowVersion(id)
		};
		this.templates = [...this.templates, template];
		return of({
			kind: "done",
			value: template
		});
	}
	update(id, rowVersion, draft) {
		const existing = this.templates.find((template) => template.id === id);
		if (existing === void 0) return of({
			kind: "failed",
			message: "That template no longer exists."
		});
		if (existing.rowVersion !== rowVersion) return of({
			kind: "conflict",
			message: ADDENDUM_CONFLICT_MESSAGE
		});
		const refusal = refusalOf$1(draft);
		if (refusal !== null) return of(refusal);
		const rendersDifferently = draft.templateContent !== existing.templateContent || draft.contentFormat !== existing.contentFormat || JSON.stringify(draft.fields) !== JSON.stringify(existing.fields) || draft.initialsAnchorOptional === true !== (existing.initialsAnchorOptional === true);
		const template = {
			...draft,
			id,
			version: rendersDifferently ? existing.version + 1 : existing.version,
			rowVersion: this.nextRowVersion(id)
		};
		this.templates = this.templates.map((candidate) => candidate.id === id ? template : candidate);
		return of({
			kind: "done",
			value: template
		});
	}
	deactivate(template) {
		return this.update(template.id, template.rowVersion, {
			...draftOf(template),
			active: false
		});
	}
	remove(template) {
		const existing = this.templates.find((candidate) => candidate.id === template.id);
		if (existing !== void 0 && existing.rowVersion !== template.rowVersion) return of({
			kind: "conflict",
			message: ADDENDUM_CONFLICT_MESSAGE
		});
		this.templates = this.templates.filter((candidate) => candidate.id !== template.id);
		return of({
			kind: "done",
			value: void 0
		});
	}
	nextRowVersion(id) {
		this.changes += 1;
		return `sample-${id}-${this.changes + 1}`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumTemplateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumTemplateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleAddendumTemplateSource,
	decorators: [{ type: Injectable }]
});
const SAMPLE_ADDENDUM_TYPES = [
	{
		specialType: "MNC",
		displayName: "Minimum price with a call",
		family: "B",
		available: true,
		rowVersion: "sample-type-MNC-1"
	},
	{
		specialType: "MNP",
		displayName: "Minimum price with a put",
		family: "B",
		available: true,
		rowVersion: "sample-type-MNP-1"
	},
	{
		specialType: "XPC",
		displayName: "Min/Max",
		family: "B",
		available: true,
		rowVersion: "sample-type-XPC-1"
	},
	{
		specialType: "PREM",
		displayName: "Premium advance",
		family: "B",
		available: true,
		rowVersion: "sample-type-PREM-1"
	},
	{
		specialType: "AMX",
		displayName: "Accumulating Min/Max (StoneX)",
		family: "A",
		available: false,
		rowVersion: "sample-type-AMX-1"
	}
];
var SampleAddendumTypeSource = class SampleAddendumTypeSource {
	types = [...SAMPLE_ADDENDUM_TYPES];
	changes = 0;
	list() {
		return of({
			kind: "done",
			value: [...this.types]
		});
	}
	create(draft) {
		const code = draft.specialType.trim();
		if (this.types.some((type) => type.specialType === code)) return of({
			kind: "conflict",
			message: `A type '${code}' already exists.`
		});
		const type = {
			...draft,
			specialType: code,
			rowVersion: this.nextRowVersion(code)
		};
		this.types = [...this.types, type];
		return of({
			kind: "done",
			value: type
		});
	}
	update(type, draft) {
		const existing = this.types.find((candidate) => candidate.specialType === type.specialType);
		if (existing === void 0) return of({
			kind: "failed",
			message: "No addendum type has that code."
		});
		if (existing.rowVersion !== type.rowVersion) return of({
			kind: "conflict",
			message: ADDENDUM_CONFLICT_MESSAGE
		});
		const updated = {
			...draft,
			specialType: existing.specialType,
			rowVersion: this.nextRowVersion(existing.specialType)
		};
		this.types = this.types.map((candidate) => candidate.specialType === existing.specialType ? updated : candidate);
		return of({
			kind: "done",
			value: updated
		});
	}
	remove(type) {
		const existing = this.types.find((candidate) => candidate.specialType === type.specialType);
		if (existing !== void 0 && existing.rowVersion !== type.rowVersion) return of({
			kind: "conflict",
			message: ADDENDUM_CONFLICT_MESSAGE
		});
		this.types = this.types.filter((candidate) => candidate.specialType !== type.specialType);
		return of({
			kind: "done",
			value: void 0
		});
	}
	nextRowVersion(code) {
		this.changes += 1;
		return `sample-type-${code}-${this.changes + 1}`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumTypeSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumTypeSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleAddendumTypeSource,
	decorators: [{ type: Injectable }]
});
const SAMPLE_STONEX_ADDENDUM_TYPES = [{
	specialType: "KA",
	displayName: "Knockout accumulator",
	family: "A",
	available: true,
	rowVersion: "sample-type-KA-1"
}, {
	specialType: "SA",
	displayName: "Seasonal average",
	family: "A",
	available: true,
	rowVersion: "sample-type-SA-1"
}];
function sampleDraft(name, specialType, lines) {
	return {
		name,
		specialTypes: [specialType],
		language: DEFAULT_ADDENDUM_LANGUAGE,
		tradeUnits: [],
		templateContent: [
			ADDENDUM_PLACEHOLDER_NOTICE,
			"",
			`${name} to contract {{contract_number}}, dated {{addendum_date}}`,
			"Seller: {{seller_name}}",
			...lines.map(([label, placeholder]) => `${label}: {{${placeholder}}}`),
			"",
			`Signature: ${ADDENDUM_SIGNATURE_ANCHOR}`,
			`Date: ${ADDENDUM_DATE_ANCHOR}`,
			`Initials: ${ADDENDUM_INITIALS_ANCHOR}`
		].join("\n"),
		contentFormat: DEFAULT_ADDENDUM_CONTENT_FORMAT,
		fields: [
			{
				placeholder: "contract_number",
				field: CONTRACT_NUMBER_FIELD
			},
			{
				placeholder: "addendum_date",
				field: "generated.addendumDate"
			},
			{
				placeholder: "seller_name",
				field: "customer.merchandisingName"
			},
			...lines.map(([, placeholder, field]) => ({
				placeholder,
				field
			}))
		],
		active: true
	};
}
function sampleRecordAddendumTemplateDrafts() {
	return [
		sampleDraft("Premium Advance Addendum (sample)", "PREM", [
			[
				"Facility address",
				"facility_address",
				"addendum_facility_address"
			],
			[
				"Facility city, state, postal code",
				"facility_city_state_postal",
				"addendum_facility_city_state_postal"
			],
			[
				"Facility phone",
				"facility_phone",
				"addendum_facility_phone"
			],
			[
				"Futures",
				"futures_reference",
				"addendum_futures_reference"
			],
			[
				"Target price",
				"target_price",
				"addendum_target_price"
			],
			[
				"Target date",
				"target_date",
				"addendum_target_date"
			],
			[
				"Premium offer",
				"premium_offer",
				"addendum_premium_offer"
			],
			[
				"Service charge",
				"service_charge",
				"addendum_service_charge"
			]
		]),
		sampleDraft("Knockout Accumulator Addendum (sample)", "KA", [
			[
				"Accumulation sale price",
				"accumulation_sale_price",
				"addendum_accumulation_sale_price"
			],
			[
				"Knockout price",
				"knockout_price",
				"addendum_knockout_price"
			],
			[
				"Structure start",
				"structure_start",
				"addendum_structure_start"
			],
			[
				"Structure end",
				"structure_end",
				"addendum_structure_end"
			]
		]),
		sampleDraft("Seasonal Average Addendum (sample)", "SA", [
			[
				"Structure start",
				"structure_start",
				"addendum_structure_start"
			],
			[
				"Structure end",
				"structure_end",
				"addendum_structure_end"
			],
			[
				"Premium cost",
				"premium_cost",
				"addendum_premium_cost"
			]
		])
	];
}
var SampleRecordAddendumTemplateSource = class SampleRecordAddendumTemplateSource extends SampleAddendumTemplateSource {
	constructor() {
		super();
		this.list().subscribe((answer) => {
			if (answer.kind === "done") for (const template of answer.value.filter((candidate) => candidate.specialTypes.includes("PREM"))) this.remove(template).subscribe();
		});
		for (const draft of sampleRecordAddendumTemplateDrafts()) this.create(draft).subscribe();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleRecordAddendumTemplateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleRecordAddendumTemplateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleRecordAddendumTemplateSource,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
var SampleRecordAddendumTypeSource = class SampleRecordAddendumTypeSource extends SampleAddendumTypeSource {
	constructor() {
		super();
		for (const type of SAMPLE_STONEX_ADDENDUM_TYPES) this.create(type).subscribe();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleRecordAddendumTypeSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleRecordAddendumTypeSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleRecordAddendumTypeSource,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
var SampleAddendumGenerationSource = class SampleAddendumGenerationSource {
	nextId = 1;
	generate(contractNumber, request) {
		const id = this.nextId++;
		return of({
			kind: "done",
			value: {
				id,
				status: "Generated",
				documentId: `sample-${contractNumber}-${request.templateId}-${id}`
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumGenerationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumGenerationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleAddendumGenerationSource,
	decorators: [{ type: Injectable }]
});
const PLACEHOLDER = /\{\{\s*([A-Za-z0-9_]+)\s*\}\}/g;
function refusalOf$1(draft) {
	const fieldErrors = {};
	const anchorProblems = addendumAnchorProblems(draft.templateContent, draft.initialsAnchorOptional === true);
	if (anchorProblems.length > 0) fieldErrors["templateContent"] = anchorProblems;
	const mapped = new Set(draft.fields.map((entry) => entry.placeholder.trim()));
	const unmapped = [...new Set([...draft.templateContent.matchAll(PLACEHOLDER)].map((match) => match[1]))].filter((name) => !mapped.has(name)).sort();
	if (unmapped.length > 0) fieldErrors["fields"] = [`These placeholders are in the template but not mapped to a field, so they would print blank: ${unmapped.join(", ")}.`];
	return Object.keys(fieldErrors).length === 0 ? null : {
		kind: "failed",
		message: Object.values(fieldErrors).flat().join(" "),
		fieldErrors
	};
}
const ADDENDUM_PREVIEW_SOURCE = new InjectionToken("ADDENDUM_PREVIEW_SOURCE");
const UNAVAILABLE$1 = "Previewing an addendum is not available yet. The server does not offer it.";
const FAILED$1 = "The addendum preview could not be made. Please try again.";
const NOT_ALLOWED$1 = "You are not signed in, or your account cannot do that.";
async function problemOf(error) {
	const body = error instanceof HttpErrorResponse ? error.error : null;
	try {
		if (body instanceof Blob) {
			const parsed = JSON.parse(await body.text());
			return typeof parsed === "object" && parsed !== null ? parsed : null;
		}
	} catch {
		return null;
	}
	return typeof body === "object" && body !== null ? body : null;
}
function toCall(error, problem, options = {}) {
	const failed = options.failed ?? FAILED$1;
	if (!(error instanceof HttpErrorResponse)) return {
		kind: "failed",
		message: failed
	};
	const bareNotFound = error.status === 404 && !problem?.detail && !problem?.title;
	if (error.status === 0 || bareNotFound && options.bareNotFound !== "failed") return {
		kind: "unavailable",
		reason: options.unavailable ?? UNAVAILABLE$1
	};
	const reference = problem?.traceId ? { correlationId: problem.traceId } : {};
	if (error.status === 401 || error.status === 403) return {
		kind: "failed",
		message: NOT_ALLOWED$1,
		...reference
	};
	const fieldErrors = fieldErrorsOf$1(problem?.errors);
	const reasons = Object.values(fieldErrors).flat();
	return {
		kind: "failed",
		message: problem?.detail ?? (reasons.length > 0 ? reasons.join(" ") : null) ?? problem?.title ?? failed,
		...reference,
		...Object.keys(fieldErrors).length === 0 ? {} : { fieldErrors }
	};
}
function fieldErrorsOf$1(raw) {
	if (typeof raw !== "object" || raw === null) return {};
	return Object.fromEntries(Object.entries(raw).filter((entry) => Array.isArray(entry[1]) && entry[1].every((reason) => typeof reason === "string")));
}
var HttpAddendumPreviewSource = class HttpAddendumPreviewSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	preview(request) {
		const body = {
			contractNumber: request.contractNumber,
			fields: request.fields,
			...request.collections === void 0 ? {} : { collections: request.collections },
			addendum: request.addendum
		};
		return this.http.post(`${this.baseUrl}/addendum-previews`, body, { responseType: "blob" }).pipe(map((blob) => ({
			kind: "done",
			value: blob
		})), catchError((error) => from(problemOf(error)).pipe(switchMap((problem) => of(toCall(error, problem))))));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumPreviewSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumPreviewSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpAddendumPreviewSource,
	decorators: [{ type: Injectable }]
});
var SampleAddendumPreviewSource = class SampleAddendumPreviewSource {
	preview(request) {
		const blank = Object.entries(request.addendum.fields).filter(([, value]) => value.trim() === "");
		if (request.addendum.templateId === null) return of({
			kind: "failed",
			message: "Choose a template for this addendum.",
			fieldErrors: { "addendum.templateId": ["Choose a template for this addendum."] }
		});
		if (blank.length > 0) {
			const reason = `Fill in ${blank.map(([name]) => name).join(", ")}: nothing on an addendum may print blank.`;
			return of({
				kind: "failed",
				message: reason,
				fieldErrors: { "addendum.fields": [reason] }
			});
		}
		const lines = [
			"DRAFT - NOT SAVED",
			`Addendum (draft) for ${request.contractNumber ?? "[contract number]"}`,
			`Template ${request.addendum.templateId}`,
			...Object.entries(request.addendum.fields).map(([name, value]) => `${name}: ${value}`),
			"Sample data. Nothing here was read from CTRM."
		];
		return of({
			kind: "done",
			value: new Blob([previewPdf(lines)], { type: "application/pdf" })
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumPreviewSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumPreviewSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleAddendumPreviewSource,
	decorators: [{ type: Injectable }]
});
function previewPdf(lines) {
	const escape = (text) => text.replace(/[^\x20-\x7e]/g, "?").replace(/[\\()]/g, (c) => `\\${c}`);
	const stream = [
		"BT",
		"/F1 14 Tf",
		"72 720 Td",
		"18 TL",
		...lines.map((line) => `(${escape(line)}) '`),
		"ET"
	].join("\n");
	const objects = [
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
		`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
		"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
	];
	let pdf = "%PDF-1.4\n";
	const offsets = [];
	objects.forEach((body, index) => {
		offsets.push(pdf.length);
		pdf += `${index + 1} 0 obj\n${body}\nendobj\n`;
	});
	const xref = pdf.length;
	pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
	pdf += offsets.map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`).join("");
	pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
	return pdf;
}
const ADDENDUM_PDF_SOURCE = new InjectionToken("ADDENDUM_PDF_SOURCE");
const UNAVAILABLE = "Opening a stored addendum is not available. The server does not offer it.";
const FAILED = "The stored addendum could not be opened. Please try again.";
var HttpAddendumPdfSource = class HttpAddendumPdfSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	pdf(contractNumber, addendumId) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/addendums/${addendumId}/pdf`;
		return this.http.get(url, { responseType: "blob" }).pipe(map((blob) => ({
			kind: "done",
			value: blob
		})), catchError((error) => from(problemOf(error)).pipe(switchMap((problem) => of(toCall(error, problem, {
			bareNotFound: "failed",
			unavailable: UNAVAILABLE,
			failed: FAILED
		}))))));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumPdfSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpAddendumPdfSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpAddendumPdfSource,
	decorators: [{ type: Injectable }]
});
var SampleAddendumPdfSource = class SampleAddendumPdfSource {
	pdf(contractNumber, addendumId) {
		const lines = [`Addendum ${addendumId} for ${contractNumber}`, "Sample data. Nothing here was read from CTRM."];
		return of({
			kind: "done",
			value: new Blob([pdfOf(lines)], { type: "application/pdf" })
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumPdfSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumPdfSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleAddendumPdfSource,
	decorators: [{ type: Injectable }]
});
function pdfOf(lines) {
	const escape = (text) => text.replace(/[^\x20-\x7e]/g, "?").replace(/[\\()]/g, (c) => `\\${c}`);
	const stream = [
		"BT",
		"/F1 14 Tf",
		"72 720 Td",
		"18 TL",
		...lines.map((line) => `(${escape(line)}) '`),
		"ET"
	].join("\n");
	const objects = [
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
		`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
		"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
	];
	let pdf = "%PDF-1.4\n";
	const offsets = [];
	objects.forEach((body, index) => {
		offsets.push(pdf.length);
		pdf += `${index + 1} 0 obj\n${body}\nendobj\n`;
	});
	const xref = pdf.length;
	pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
	pdf += offsets.map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`).join("");
	pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
	return pdf;
}
const ADDENDUM_LIST_SOURCE = new InjectionToken("ADDENDUM_LIST_SOURCE");
const SAMPLE_CONTRACT = "SS1240007";
const SAMPLE_LIST = {
	currentId: 12,
	addendums: [{
		id: 12,
		status: "Locked",
		documentId: "sample-12",
		createdAtUtc: "2026-10-19T14:00:00Z",
		document: {
			id: "sample-12",
			status: "Current"
		}
	}, {
		id: 9,
		status: "Locked",
		documentId: "sample-9",
		createdAtUtc: "2026-10-18T14:00:00Z",
		document: {
			id: "sample-9",
			status: "Superseded"
		}
	}]
};
var SampleAddendumListSource = class SampleAddendumListSource {
	list(contractNumber) {
		const value = contractNumber.trim() === SAMPLE_CONTRACT ? SAMPLE_LIST : {
			currentId: null,
			addendums: []
		};
		return of({
			kind: "done",
			value
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumListSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleAddendumListSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleAddendumListSource,
	decorators: [{ type: Injectable }]
});
function summarizeAddendumList(contractNumber, list) {
	const entries = Array.isArray(list?.addendums) ? list.addendums : [];
	const currentId = list?.currentId ?? null;
	const entry = currentId === null ? void 0 : entries.find((item) => item.id === currentId);
	return {
		current: entry === void 0 ? null : {
			contractNumber: contractNumber.trim(),
			addendumId: entry.id,
			documentId: entry.documentId ?? null
		},
		earlier: entry === void 0 ? entries.length : entries.length - 1
	};
}
const CONTRACT_DOCUMENTS_SOURCE = new InjectionToken("CONTRACT_DOCUMENTS_SOURCE");
function contractDocumentName(document) {
	return document.description?.trim() || document.fileName?.trim() || `Document ${document.documentEntry}`;
}
const CTRM_USER_REFUSALS = /* @__PURE__ */ new Set(["ctrm-user-ambiguous", "ctrm-user-not-found"]);
const FINAL_ANSWERS = [{
	status: 403,
	type: "ctrm-document-access-denied",
	title: "CTRM does not let you see this contract's documents.",
	detail: "Please ask the Help Desk for access to this contract's documents."
}, {
	status: 404,
	type: "contract-not-found",
	title: "No such contract.",
	detail: "CTRM has no contract with this number."
}];
const ROLES = /* @__PURE__ */ new Set([
	"draft",
	"approved",
	"confirmed",
	"additional",
	"attachment"
]);
const PROVENANCES = /* @__PURE__ */ new Set([
	"generated",
	"otmCopy",
	"termsAndConditions",
	"rjoAddendum",
	"userImported",
	"userAttachment",
	"contractUpload"
]);
const STATUSES$1 = /* @__PURE__ */ new Set([
	"available",
	"pending",
	"expired",
	"notStored"
]);
const LIST_FAILED$1 = "The documents could not be loaded.";
const CONTENT_UNAVAILABLE = "This document can't be opened here yet.";
const CONTENT_FAILED$1 = "The document could not be opened. Please try again.";
const DOCUMENT_NOT_FOUND = {
	title: "No such document on this contract.",
	detail: "CTRM has no such document on this contract."
};
const DOCUMENT_NOT_STORED = {
	title: "The document's file is no longer stored.",
	detail: "CTRM still lists this document, but it no longer holds the file."
};
var HttpContractDocumentsSource = class HttpContractDocumentsSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	documentsUrl(contractNumber) {
		return `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/documents`;
	}
	list(contractNumber) {
		return this.http.get(this.documentsUrl(contractNumber)).pipe(map((body) => readList(body)), catchError((error) => of(listFailure(error))));
	}
	content(contractNumber, documentEntry) {
		return this.http.get(`${this.documentsUrl(contractNumber)}/${encodeURIComponent(documentEntry)}`, { responseType: "blob" }).pipe(map((blob) => ({
			kind: "done",
			blob
		})), catchError((error) => of(contentFailure(error))));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractDocumentsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractDocumentsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractDocumentsSource,
	decorators: [{ type: Injectable }]
});
function readList(body) {
	const raw = body !== null && typeof body === "object" ? body : null;
	if (raw === null || !Array.isArray(raw["documents"])) return {
		kind: "failed",
		message: `${LIST_FAILED$1} The server's answer could not be read.`
	};
	return {
		kind: "loaded",
		response: {
			contract: typeof raw["contract"] === "string" ? raw["contract"] : "",
			documents: raw["documents"].map(readDocument),
			dataOrigin: typeof raw["dataOrigin"] === "string" ? raw["dataOrigin"] : "",
			warnings: Array.isArray(raw["warnings"]) ? raw["warnings"].filter((warning) => typeof warning === "string") : []
		}
	};
}
function readDocument(value) {
	const row = value !== null && typeof value === "object" ? value : {};
	const text = (key) => typeof row[key] === "string" ? row[key] : null;
	const provenance = text("provenance");
	return {
		documentEntry: String(row["documentEntry"] ?? ""),
		role: oneOf(text("role"), ROLES),
		provenance: provenance === null ? null : oneOf(provenance, PROVENANCES),
		documentType: text("documentType"),
		description: text("description"),
		fileName: text("fileName"),
		appearanceSequence: typeof row["appearanceSequence"] === "number" ? row["appearanceSequence"] : null,
		status: oneOf(text("status"), STATUSES$1),
		createdStamp: text("createdStamp")
	};
}
function oneOf(value, known) {
	return value !== null && known.has(value) ? value : "unknown";
}
function refusalOf(problem) {
	if (problem.status === 403 && problem.type !== null && CTRM_USER_REFUSALS.has(problem.type)) return {
		title: problem.title ?? "Your account cannot read these documents.",
		detail: problem.detail ?? "Please ask the Help Desk to check your CTRM user."
	};
	const final = FINAL_ANSWERS.find((answer) => answer.status === problem.status && answer.type === problem.type);
	if (final !== void 0) return {
		title: problem.title ?? final.title,
		detail: problem.detail ?? final.detail
	};
	if (problem.status === 401 || problem.status === 403) return {
		title: "Your account cannot read these documents.",
		detail: problem.detail ?? "You are not signed in, or your account does not have access to this contract."
	};
	return null;
}
function listFailure(error) {
	const problem = problemFrom(error);
	const refusal = refusalOf(problem);
	if (refusal !== null) return {
		kind: "refused",
		...refusal
	};
	const correlation = problem.traceId === null ? {} : { correlationId: problem.traceId };
	return {
		kind: "failed",
		message: problem.detail ?? LIST_FAILED$1,
		...correlation
	};
}
function contentFailure(error) {
	const problem = problemFrom(error);
	if (problem.status === 0) return {
		kind: "unavailable",
		reason: CONTENT_UNAVAILABLE
	};
	const correlation = problem.traceId === null ? {} : { correlationId: problem.traceId };
	const refusal = refusalOf(problem) ?? contentRefusalOf(problem);
	if (refusal !== null) return {
		kind: "refused",
		...refusal,
		...correlation
	};
	return {
		kind: "failed",
		...problem.title === null ? {} : { title: problem.title },
		message: problem.detail ?? CONTENT_FAILED$1,
		...correlation
	};
}
function contentRefusalOf(problem) {
	const fallback = problem.status === 404 ? DOCUMENT_NOT_FOUND : problem.status === 410 ? DOCUMENT_NOT_STORED : null;
	return fallback === null ? null : {
		title: problem.title ?? fallback.title,
		detail: problem.detail ?? fallback.detail
	};
}
const CREATED = "2026-09-01-09.15.00.000000";
const SAMPLE_CONTRACT_DOCUMENTS = [
	sample("2200010", "approved", "generated", "Contract", "Contract.pdf", 0, "available"),
	sample("2200011", "draft", "generated", "Contract draft", "Contract draft.pdf", 0, "available"),
	sample("2200012", "additional", "termsAndConditions", "Terms and conditions", "Terms and conditions.pdf", 10, "available", "T&C PAGES"),
	sample("2200013", "additional", "userImported", "Scale ticket", "Scale ticket.pdf", 20, "pending"),
	sample("2200014", "additional", "rjoAddendum", "RJO Addendum", "RJO Addendum.pdf", 40, "available"),
	{
		...sample("2200015", "additional", "userImported", "Vendor confirmation", null, 50, "notStored"),
		createdStamp: null
	},
	sample("2200016", "attachment", "contractUpload", "Signed contract", "Signed contract.pdf", null, "available"),
	sample("2200017", "attachment", "userAttachment", "Chemical attestation", "Chemical attestation.pdf", null, "expired"),
	sample("2200018", "attachment", "userAttachment", "Moisture readings", "Moisture readings.xlsx", null, "available")
];
function sample(documentEntry, role, provenance, description, fileName, appearanceSequence, status, documentType = null) {
	return {
		documentEntry,
		role,
		provenance,
		documentType,
		description,
		fileName,
		appearanceSequence,
		status,
		createdStamp: CREATED
	};
}
var SampleContractDocumentsSource = class SampleContractDocumentsSource {
	documents = SAMPLE_CONTRACT_DOCUMENTS;
	list(contractNumber) {
		return of({
			kind: "loaded",
			response: {
				contract: contractNumber,
				documents: this.documents,
				dataOrigin: "Simulated",
				warnings: []
			}
		});
	}
	content(contractNumber, documentEntry) {
		const document = this.documents.find((candidate) => candidate.documentEntry === documentEntry);
		if (document === void 0 || document.status !== "available") return of({
			kind: "unavailable",
			reason: "This document can't be opened here yet."
		});
		if (!document.fileName?.toLowerCase().endsWith(".pdf")) return of({
			kind: "done",
			blob: new Blob([`SAMPLE - ${contractDocumentName(document)} - ${contractNumber}`], { type: "application/octet-stream" })
		});
		return of({
			kind: "done",
			blob: new Blob([samplePdf(`${contractDocumentName(document)} - ${contractNumber}`)], { type: "application/pdf" })
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractDocumentsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractDocumentsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleContractDocumentsSource,
	decorators: [{ type: Injectable }]
});
function samplePdf(title) {
	const escape = (value) => value.replace(/[^\x20-\x7e]/g, "?").replace(/([\\()])/g, "\\$1");
	const stream = [`BT /F1 18 Tf 72 720 Td (SAMPLE - ${escape(title)}) Tj ET`, "BT /F1 11 Tf 72 696 Td (Playground sample data. This is not a CTRM document.) Tj ET"].join("\n");
	const objects = [
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
		"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
		`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`
	];
	let pdf = "%PDF-1.4\n";
	const offsets = [];
	objects.forEach((body, index) => {
		offsets.push(pdf.length);
		pdf += `${index + 1} 0 obj\n${body}\nendobj\n`;
	});
	const xref = pdf.length;
	pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n` + offsets.map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`).join("") + `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
	return Uint8Array.from(pdf, (character) => character.charCodeAt(0));
}
const CONTRACT_ATTACHMENTS_SOURCE = new InjectionToken("CONTRACT_ATTACHMENTS_SOURCE");
const WORD_EXTENSIONS = /* @__PURE__ */ new Set([
	"doc",
	"docx",
	"docm",
	"dot",
	"dotx",
	"rtf"
]);
function fileExtensionOf(name) {
	const dot = name.lastIndexOf(".");
	return dot <= 0 || dot === name.length - 1 ? "" : name.slice(dot + 1).toLowerCase();
}
function acceptAttributeOf(options) {
	return [...options.acceptedFormats.map((format) => `.${format.toLowerCase()}`), ...options.acceptedMediaTypes].join(",");
}
function acceptedFormatsLabel(options) {
	const names = options.acceptedFormats.map((format) => format.toUpperCase());
	return names.length <= 1 ? names[0] ?? "no" : `${names.slice(0, -1).join(", ")} or ${names[names.length - 1]}`;
}
function readableBytes(bytes) {
	if (bytes >= 1048576) {
		const megabytes = bytes / 1048576;
		return `${Number.isInteger(megabytes) ? megabytes : megabytes.toFixed(1)} MB`;
	}
	return bytes >= 1024 ? `${Math.round(bytes / 1024)} KB` : `${bytes} bytes`;
}
function pickedFileRefusal(file, options) {
	const extension = fileExtensionOf(file.name);
	if (!(options.acceptedFormats.map((format) => format.toLowerCase()).includes(extension) || extension === "" && file.type !== "" && options.acceptedMediaTypes.includes(file.type))) {
		const only = acceptedFormatsLabel(options);
		return WORD_EXTENSIONS.has(extension) ? `${file.name} is a Word file, and only ${only} files are accepted. Save it as PDF, then attach the PDF.` : `${file.name} is not a ${only} file, and only ${only} files are accepted.`;
	}
	if (file.size > options.maxFileBytes) return `${file.name} is ${readableBytes(file.size)}, over the ${readableBytes(options.maxFileBytes)} limit for one file.`;
	if (file.size === 0) return `${file.name} is empty.`;
	return null;
}
function documentTypeLabel(code, options) {
	return options?.documentTypes.find((type) => type.code === code)?.displayName ?? code;
}
function attachmentChangesSentence(changes) {
	return changes.map((change) => {
		const id = change.documentId ?? "unknown";
		switch (change.action) {
			case "Stored": return change.supersededDocumentId === null ? `Stored as document ${id}.` : `Stored as document ${id}, replacing document ${change.supersededDocumentId}.`;
			case "Resent": return `Document ${id} sent to CTRM again.`;
			case "Removed": return `Document ${id} removed.`;
			case "AlreadyRemoved": return `The removal of document ${id} sent to CTRM again.`;
			default: return `Document ${id} changed.`;
		}
	}).join(" ");
}
const OPTIONS_FAILED = "What an attachment may be could not be loaded, so nothing can be attached here yet.";
const LIST_FAILED = "The contract's attachments could not be loaded.";
const CONTENT_FAILED = "The attachment could not be opened. Please try again.";
const WRITE_FAILED = "The attachment change could not be saved. Please try again.";
const NOT_ALLOWED = "You are not signed in, or your account cannot change this contract.";
const OUTCOME_UNKNOWN = "CTRM's answer was lost, so whether the change was saved is not known. Reload the contract before trying again.";
const STATUSES = /* @__PURE__ */ new Set([
	"Current",
	"Superseded",
	"Removed"
]);
const CONFLICTS = /* @__PURE__ */ new Set(["attachment-already-attached", "attachment-already-removed"]);
var HttpContractAttachmentsSource = class HttpContractAttachmentsSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	attachmentsUrl(contractNumber) {
		return `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/attachments`;
	}
	options() {
		return this.http.get(`${this.baseUrl}/attachment-options`).pipe(map((body) => {
			const options = readOptions(body);
			return options === null ? {
				kind: "failed",
				message: `${OPTIONS_FAILED} The server's answer could not be read.`,
				correlationId: null
			} : {
				kind: "loaded",
				options
			};
		}), catchError((error) => from(problemOf(error)).pipe(map((problem) => ({
			kind: "failed",
			message: OPTIONS_FAILED,
			correlationId: text(problem?.traceId)
		})))));
	}
	list(contractNumber) {
		return this.http.get(this.attachmentsUrl(contractNumber)).pipe(map((body) => Array.isArray(body) ? {
			kind: "loaded",
			attachments: body.map(readAttachment)
		} : {
			kind: "failed",
			message: `${LIST_FAILED} The server's answer could not be read.`,
			correlationId: null
		}), catchError((error) => from(problemOf(error)).pipe(map((problem) => ({
			kind: "failed",
			message: text(problem?.detail) ?? LIST_FAILED,
			correlationId: text(problem?.traceId)
		})))));
	}
	content(contractNumber, documentId) {
		return this.http.get(`${this.attachmentsUrl(contractNumber)}/${encodeURIComponent(documentId)}/content`, { responseType: "blob" }).pipe(map((blob) => ({
			kind: "done",
			blob
		})), catchError((error) => from(problemOf(error)).pipe(map((problem) => ({
			kind: "failed",
			message: text(problem?.detail) ?? text(problem?.title) ?? CONTENT_FAILED,
			correlationId: text(problem?.traceId)
		})))));
	}
	add(contractNumber, upload, flags) {
		return this.write(this.http.post(this.attachmentsUrl(contractNumber), formOf(upload, flags)));
	}
	replace(contractNumber, documentId, upload, flags) {
		return this.write(this.http.put(`${this.attachmentsUrl(contractNumber)}/${encodeURIComponent(documentId)}`, formOf(upload, flags)));
	}
	remove(contractNumber, documentId, flags) {
		return this.write(this.http.delete(`${this.attachmentsUrl(contractNumber)}/${encodeURIComponent(documentId)}`, { params: paramsOf(flags) }));
	}
	write(request) {
		return request.pipe(map((result) => ({
			kind: "saved",
			result
		})), catchError((error) => from(problemOf(error)).pipe(switchMap((problem) => of(writeFailure(error, problem))))));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractAttachmentsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpContractAttachmentsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpContractAttachmentsSource,
	decorators: [{ type: Injectable }]
});
function formOf(upload, flags) {
	const form = new FormData();
	form.append("file", upload.file, upload.file.name);
	form.append("documentType", upload.documentType);
	if (flags?.sendNotification === true) form.append("sendNotification", "true");
	if (flags?.confirmResend === true) form.append("confirmResend", "true");
	return form;
}
function paramsOf(flags) {
	let params = new HttpParams();
	if (flags?.sendNotification === true) params = params.set("sendNotification", "true");
	if (flags?.confirmResend === true) params = params.set("confirmResend", "true");
	return params;
}
function writeFailure(error, problem) {
	const status = error instanceof HttpErrorResponse ? error.status : 0;
	const type = text(problem?.type);
	const detail = text(problem?.detail);
	const correlationId = text(problem?.traceId);
	if (status === 409 && type !== null && CONFLICTS.has(type)) return {
		kind: "conflict",
		type,
		detail: detail ?? text(problem?.title) ?? "This change was already made. Send it again?",
		correlationId
	};
	const fieldErrors = fieldErrorsOf(problem?.errors);
	const reasons = Object.values(fieldErrors).flat();
	const outcomeUnknown = type === "ctrm-write-outcome-unknown";
	return {
		kind: "refused",
		message: outcomeUnknown ? OUTCOME_UNKNOWN : status === 401 || status === 403 ? detail ?? NOT_ALLOWED : reasons.length > 0 ? reasons.join(" ") : detail ?? text(problem?.title) ?? WRITE_FAILED,
		fieldErrors,
		correlationId,
		outcomeUnknown
	};
}
function readOptions(body) {
	const raw = body !== null && typeof body === "object" ? body : null;
	if (raw === null || !Array.isArray(raw["acceptedFormats"]) || !Array.isArray(raw["documentTypes"])) return null;
	const strings = (value) => Array.isArray(value) ? value.filter((entry) => typeof entry === "string") : [];
	const number = (value) => typeof value === "number" && Number.isFinite(value) ? value : 0;
	return {
		acceptedFormats: strings(raw["acceptedFormats"]).map((format) => format.toLowerCase()),
		acceptedMediaTypes: strings(raw["acceptedMediaTypes"]),
		maxFileBytes: number(raw["maxFileBytes"]),
		maxSetBytes: number(raw["maxSetBytes"]),
		maxDocumentsPerContract: number(raw["maxDocumentsPerContract"]),
		documentTypes: raw["documentTypes"].flatMap((entry) => {
			const type = entry !== null && typeof entry === "object" ? entry : {};
			const code = text(type["code"]);
			return code === null ? [] : [{
				code,
				displayName: text(type["displayName"]) ?? code
			}];
		})
	};
}
function readAttachment(value) {
	const row = value !== null && typeof value === "object" ? value : {};
	const status = text(row["status"]);
	return {
		documentId: String(row["documentId"] ?? ""),
		documentType: text(row["documentType"]) ?? "",
		fileName: text(row["fileName"]) ?? "",
		mediaType: text(row["mediaType"]) ?? "",
		byteCount: typeof row["byteCount"] === "number" ? row["byteCount"] : 0,
		sha256: text(row["sha256"]) ?? "",
		status: status !== null && STATUSES.has(status) ? status : "Unknown",
		supersedesDocumentId: row["supersedesDocumentId"] == null ? null : String(row["supersedesDocumentId"]),
		createdByUpn: text(row["createdByUpn"]) ?? "",
		createdAtUtc: text(row["createdAtUtc"]) ?? "",
		statusChangedAtUtc: text(row["statusChangedAtUtc"])
	};
}
function fieldErrorsOf(raw) {
	if (typeof raw !== "object" || raw === null) return {};
	return Object.fromEntries(Object.entries(raw).filter((entry) => Array.isArray(entry[1]) && entry[1].every((reason) => typeof reason === "string")));
}
function text(value) {
	return typeof value === "string" && value.trim() !== "" ? value : null;
}
const SAMPLE_ATTACHMENT_OPTIONS = {
	acceptedFormats: ["pdf"],
	acceptedMediaTypes: ["application/pdf"],
	maxFileBytes: 10485760,
	maxSetBytes: 26214400,
	maxDocumentsPerContract: 50,
	documentTypes: [{
		code: "CHEMICAL_ATTESTATION",
		displayName: "Chemical attestation"
	}, {
		code: "OTHER",
		displayName: "Other"
	}]
};
const AUTHOR = "spec@scoular.com";
const SAMPLE_CONTRACT_ATTACHMENTS = [
	row("5003", "CHEMICAL_ATTESTATION", "Chemical attestation v2.pdf", 182404, "Current", "5001", "2026-10-19T15:02:00Z"),
	row("5002", "OTHER", "Scale ticket.pdf", 64211, "Removed", null, "2026-10-19T14:40:00Z", "2026-10-19T14:55:00Z"),
	row("5001", "CHEMICAL_ATTESTATION", "Chemical attestation.pdf", 179880, "Superseded", null, "2026-10-18T09:10:00Z", "2026-10-19T15:02:00Z")
];
function row(documentId, documentType, fileName, byteCount, status, supersedesDocumentId, createdAtUtc, statusChangedAtUtc = null) {
	return {
		documentId,
		documentType,
		fileName,
		mediaType: "application/pdf",
		byteCount,
		sha256: `sample-${documentId}`,
		status,
		supersedesDocumentId,
		createdByUpn: AUTHOR,
		createdAtUtc,
		statusChangedAtUtc
	};
}
var SampleContractAttachmentsSource = class SampleContractAttachmentsSource {
	sets = /* @__PURE__ */ new Map();
	next = 6001;
	options() {
		return of({
			kind: "loaded",
			options: SAMPLE_ATTACHMENT_OPTIONS
		});
	}
	list(contractNumber) {
		return of({
			kind: "loaded",
			attachments: [...this.setOf(contractNumber)]
		});
	}
	content(_contractNumber, documentId) {
		return of({
			kind: "done",
			blob: new Blob([samplePdf(`Attachment ${documentId}`)], { type: "application/pdf" })
		});
	}
	add(contractNumber, upload, flags) {
		const set = this.setOf(contractNumber);
		const same = set.find((held) => held.status === "Current" && this.isSame(held, upload));
		if (same !== void 0) return flags?.confirmResend === true ? of(this.saved(contractNumber, [{
			action: "Resent",
			documentId: same.documentId,
			supersededDocumentId: null
		}])) : of(this.alreadyAttached(contractNumber, same));
		const stored = this.store(set, upload, null);
		return of(this.saved(contractNumber, [{
			action: "Stored",
			documentId: stored.documentId,
			supersededDocumentId: null
		}]));
	}
	replace(contractNumber, documentId, upload, flags) {
		const set = this.setOf(contractNumber);
		const target = set.find((held) => held.documentId === documentId && held.status === "Current");
		if (target === void 0) return of(this.refused(`Document ${documentId} is not a current attachment of this contract.`, "attachment.document"));
		if (this.isSame(target, upload)) return flags?.confirmResend === true ? of(this.saved(contractNumber, [{
			action: "Resent",
			documentId,
			supersededDocumentId: null
		}])) : of(this.alreadyAttached(contractNumber, target));
		const stored = this.store(set, upload, documentId);
		this.setStatus(set, documentId, "Superseded");
		return of(this.saved(contractNumber, [{
			action: "Stored",
			documentId: stored.documentId,
			supersededDocumentId: documentId
		}]));
	}
	remove(contractNumber, documentId, flags) {
		const set = this.setOf(contractNumber);
		const target = set.find((held) => held.documentId === documentId);
		if (target?.status === "Removed") return flags?.confirmResend === true ? of(this.saved(contractNumber, [{
			action: "AlreadyRemoved",
			documentId,
			supersededDocumentId: null
		}])) : of({
			kind: "conflict",
			type: "attachment-already-removed",
			detail: `Document ${documentId} of contract ${contractNumber} is already removed in CWS. Nothing was sent to CTRM. To send the removal again anyway, repeat the request with confirmResend=true.`,
			correlationId: "sample-trace-409"
		});
		if (target?.status !== "Current") return of(this.refused(`Document ${documentId} is not a current attachment of this contract.`, "attachment.document"));
		this.setStatus(set, documentId, "Removed");
		return of(this.saved(contractNumber, [{
			action: "Removed",
			documentId,
			supersededDocumentId: null
		}]));
	}
	setOf(contractNumber) {
		let set = this.sets.get(contractNumber);
		if (set === void 0) {
			set = [...SAMPLE_CONTRACT_ATTACHMENTS];
			this.sets.set(contractNumber, set);
		}
		return set;
	}
	isSame(held, upload) {
		return held.fileName === upload.file.name && held.byteCount === upload.file.size && held.documentType === upload.documentType;
	}
	store(set, upload, supersedes) {
		const stored = row(String(this.next++), upload.documentType, upload.file.name, upload.file.size, "Current", supersedes, (/* @__PURE__ */ new Date()).toISOString());
		set.unshift(stored);
		return stored;
	}
	setStatus(set, documentId, status) {
		const index = set.findIndex((held) => held.documentId === documentId);
		if (index >= 0) set[index] = {
			...set[index],
			status,
			statusChangedAtUtc: (/* @__PURE__ */ new Date()).toISOString()
		};
	}
	saved(contractNumber, changes) {
		return {
			kind: "saved",
			result: {
				contractNumber,
				action: "Updated",
				detail: "",
				warnings: [],
				attachments: { changes }
			}
		};
	}
	alreadyAttached(contractNumber, held) {
		return {
			kind: "conflict",
			type: "attachment-already-attached",
			detail: `Contract ${contractNumber} already holds this file as document ${held.documentId} (${held.documentType}). Nothing was sent to CTRM. Sending it again is safe, because CTRM keeps one copy of the file; repeat the request with confirmResend=true to do that.`,
			correlationId: "sample-trace-409"
		};
	}
	refused(reason, key) {
		return {
			kind: "refused",
			message: reason,
			fieldErrors: { [key]: [reason] },
			correlationId: "sample-trace-422",
			outcomeUnknown: false
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractAttachmentsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: SampleContractAttachmentsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: SampleContractAttachmentsSource,
	decorators: [{ type: Injectable }]
});
function auditAttachmentsOf(action, detailsJson) {
	if (detailsJson === null || detailsJson.trim() === "") return [];
	let parsed;
	try {
		parsed = JSON.parse(detailsJson);
	} catch {
		return [];
	}
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return [];
	const record = parsed;
	const id = (value) => typeof value === "string" && value.trim() !== "" ? value : typeof value === "number" ? String(value) : null;
	if (action === "AttachmentAdd" || action === "AttachmentReplace" || action === "AttachmentRemove" || action === "AttachmentRestore") {
		const documentId = id(record["documentId"]);
		if (documentId === null) return [];
		const type = id(record["documentType"]);
		const superseded = id(record["supersededDocumentId"]);
		return [`Document ${documentId}${type === null ? "" : ` (${type})`}${superseded === null ? "" : `, replacing document ${superseded}`}`];
	}
	if (!Array.isArray(record["attachments"])) return [];
	return record["attachments"].flatMap((entry) => {
		const change = entry ?? {};
		const documentId = id(change["documentId"]);
		if (documentId === null) return [];
		const superseded = id(change["supersededDocumentId"]);
		switch (change["action"]) {
			case "Stored": return [`Document ${documentId} stored${superseded === null ? "" : `, replacing document ${superseded}`}`];
			case "Resent": return [`Document ${documentId} sent again`];
			case "Removed": return [`Document ${documentId} removed`];
			case "AlreadyRemoved": return [`Removal of document ${documentId} sent again`];
			default: return [`Document ${documentId} changed`];
		}
	});
}
const CONTRACT_PLACEHOLDER = "{contract}";
const CWS_EXTERNAL_LINKS = new InjectionToken("CWS_EXTERNAL_LINKS", { factory: () => ({}) });
function checkExternalLinks(links) {
	const powerBi = links?.powerBi?.trim() || void 0;
	const template = links?.fileBound?.contractUrlTemplate?.trim() || void 0;
	if (powerBi) httpsUrl(powerBi, "powerBi");
	if (template) {
		if (!(template.split(CONTRACT_PLACEHOLDER).length === 2) || httpsUrl(template.replace("{contract}", "a"), "fileBound").host !== httpsUrl(template.replace("{contract}", "b"), "fileBound").host) refuse("fileBound", `needs one ${CONTRACT_PLACEHOLDER}, outside the host`);
	}
	return {
		powerBi,
		fileBound: template ? { contractUrlTemplate: template } : void 0
	};
}
function httpsUrl(value, name) {
	const url = URL.canParse(value) ? new URL(value) : null;
	return url?.protocol === "https:" ? url : refuse(name, "must be an absolute https: URL");
}
function refuse(name, rule) {
	throw new Error(`CWS links.${name} ${rule}`);
}
function fileBoundUrlFor(links, contractNumber) {
	const template = links.fileBound?.contractUrlTemplate;
	const number = contractNumber?.trim();
	if (!template || !number) return null;
	const encoded = encodeURIComponent(number);
	return template.replace(CONTRACT_PLACEHOLDER, () => encoded);
}
export { ADDENDUM_CONFLICT_MESSAGE, ADDENDUM_DATE_ANCHOR, ADDENDUM_ENTRY_FIELD_PREFIX, ADDENDUM_FIELD_PRESENTATION, ADDENDUM_GENERATION_SOURCE, ADDENDUM_INITIALS_ANCHOR, ADDENDUM_LIST_SOURCE, ADDENDUM_PDF_SOURCE, ADDENDUM_PLACEHOLDER_NOTICE, ADDENDUM_PREVIEW_SOURCE, ADDENDUM_REFUSED_SIGNATURE_FORM, ADDENDUM_SIGNATURE_ANCHOR, ADDENDUM_TAB, ADDENDUM_TEMPLATE_SOURCE, ADDENDUM_TYPE_SOURCE, APPROVAL_ACTION_SOURCE, APPROVAL_CONTRACT_SOURCE, APPROVAL_QUEUE_NOT_DEPLOYED, APPROVAL_QUEUE_REFUSALS, APPROVAL_QUEUE_SOURCE, AVAILABILITY_SOURCE, AVAILABILITY_STATES, AvailabilityGate, BROKER_STAGE_CAUTION, CLOSED_REFUSAL, CLOSE_PROVENANCE_WARNING, CODE_SEARCH_SOURCES_PROVIDER, CONFIRMED_COLUMN, CONFIRM_CHG_CTRM_FIELDS, CONFIRM_CHG_WHEN_UNPRICED, CONSTRAINT_VALUE_LABELS, CONTRACTS_API_URL, CONTRACT_ATTACHMENTS_SOURCE, CONTRACT_CODE_PREFIXES, CONTRACT_CODE_PREFIX_LABELS, CONTRACT_COPY_IDENTITY_FIELDS, CONTRACT_DETAIL_SOURCE, CONTRACT_DOCUMENTS_SOURCE, CONTRACT_EXPORT_COLUMNS, CONTRACT_EXPORT_SOURCE, CONTRACT_GRID_COLUMNS, CONTRACT_IDEMPOTENCY_KEY, CONTRACT_LAYOUT_CTRM_FIELDS, CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT, CONTRACT_LAYOUT_EMPTY_NOTES, CONTRACT_LAYOUT_FIELDS, CONTRACT_LAYOUT_FIELD_NOTES, CONTRACT_LAYOUT_GROUP_HEADINGS, CONTRACT_LAYOUT_HALF_FIELDS, CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS, CONTRACT_LAYOUT_SECTIONS, CONTRACT_LAYOUT_SECTION_NOTES, CONTRACT_LAYOUT_WIDE_FIELDS, CONTRACT_LIST_SOURCE, CONTRACT_LOG_SOURCE, CONTRACT_NOTES_MAX_ROWS, CONTRACT_NUMBER_SOURCE, CONTRACT_NUMBER_WIDTH, CONTRACT_PLACEHOLDER, CONTRACT_READ_ONLY_FIELDS, CONTRACT_STATE_SOURCE, CONTRACT_TABS, CONTRACT_TEMPLATE_SOURCE, CONTRACT_TEXT_FAILED_MESSAGE, CONTRACT_TEXT_SOURCE, CONTRACT_WRITABLE_FIELDS, CONTRACT_WRITE_SOURCE, CTRM_CONTRACT_NOT_FOUND, CUSTOMER_NAME_EXPORT_COLUMN, CUSTOMER_SOURCE, CWS_CONTRACT_EVENTS_VERSION, CWS_CONTRACT_FIELDS, CWS_EXTERNAL_LINKS, ConfirmationProgressComponent, ContractFormComponent, CustomerCellComponent, CwsContractEvents, DEFAULT_ADDENDUM_CONTENT_FORMAT, DEFAULT_ADDENDUM_LANGUAGE, DEFAULT_PAGE_SIZE, DEFAULT_TRADE_UNIT_SOURCE, DOCUMENTS_TAB, DRAFT_CLOCK, DRAFT_STORAGE, FAMILY_B_ADDENDUM_FIELD_SETS, FILTER_PARAM, FOCUS_PARAM, FORM_CONFIG_ADMIN_SOURCE, FORM_CONFIG_SOURCE, GRID_COLUMNS_UNAVAILABLE, GRID_COLUMN_OWNER, GRID_COLUMN_PREFERENCE_SOURCE, GRID_COLUMN_SERVER_SOURCE, HOME_GRID_COLUMNS_SOURCE, HttpAddendumGenerationSource, HttpAddendumListSource, HttpAddendumPdfSource, HttpAddendumPreviewSource, HttpAddendumTemplateSource, HttpAddendumTypeSource, HttpApprovalActionSource, HttpApprovalContractSource, HttpApprovalQueueSource, HttpAvailabilitySource, HttpContractAttachmentsSource, HttpContractDetailSource, HttpContractDocumentsSource, HttpContractExportSource, HttpContractListSource, HttpContractLogSource, HttpContractNumberSource, HttpContractStateSource, HttpContractTemplateSource, HttpContractTextSource, HttpContractWriteSource, HttpCustomerSource, HttpFormConfigAdminSource, HttpGridColumnPreferenceSource, HttpHomeGridColumnsSource, HttpLocationSource, HttpMarketReferenceSource, HttpMeSource, HttpOriginDestinationSource, HttpPermissionCatalogSource, HttpPricingSource, HttpRoleAdminSource, HttpTradeUnitValuesSource, HttpTradeUnitVisibilitySource, HttpWeightLimitCheckSource, INTERCOMPANY_PURCHASE_REFUSAL, INVALID_PARAM_ALIASES, LOCATION_SOURCE, LOG_TAB, LocalFirstDefaultTradeUnitSource, LocalFirstGridColumnPreferenceSource, MARKET_REFERENCE_SOURCE, MAX_ECM_RECIPIENTS, MAX_PAGE_SIZE, ME_SOURCE, NOTES_WARNING, NOTE_MAX_BYTES, NUMBER_CHECK_FAILED_MESSAGE, NUMBER_CHECK_UNCONFIRMED_MESSAGE, NUMBER_ISSUE_GENERIC_MESSAGE, OBJECT_ID_REFUSAL, ORIGIN_DESTINATION_SEARCH_SET, ORIGIN_DESTINATION_SOURCE, PERMISSION_CATALOG_SOURCE, PINNED_GRID_COLUMN, PRICING_SOURCE, PermissionKeys, RECORD_DRAFT_STORE, RECORD_ORIGIN_PARAM, REFERENCE_ROUTES, REMARK_NOTE_MAX_LENGTH, REMARK_TYPES, ROLE_ADMIN_SOURCE, SAMPLE_ADDENDUM_TYPES, SAMPLE_APPROVER_INITIALS, SAMPLE_ATTACHMENT_OPTIONS, SAMPLE_CONTRACT_ATTACHMENTS, SAMPLE_CONTRACT_DOCUMENTS, SAMPLE_CONTRACT_TEXT_TEMPLATES, SAMPLE_CUSTOMERS, SAMPLE_HIDDEN_TRADE_UNITS, SAMPLE_LOCATIONS, SAMPLE_ME, SAMPLE_ORIGIN_DESTINATION_CODES, SAMPLE_RAIL_WEIGHT_LIMITS, SAMPLE_REDACTED_CUSTOMER_ID, SAMPLE_STONEX_ADDENDUM_TYPES, SAMPLE_TRADER_EMAIL, SCOULAR_EMAIL_DOMAIN, SIMULATED_PERMISSION_CATALOG, SampleAddendumGenerationSource, SampleAddendumListSource, SampleAddendumPdfSource, SampleAddendumPreviewSource, SampleAddendumTemplateSource, SampleAddendumTypeSource, SampleApprovalQueueSource, SampleAvailabilitySource, SampleContractAttachmentsSource, SampleContractDocumentsSource, SampleContractExportSource, SampleContractListSource, SampleContractTextSource, SampleCustomerSource, SampleHomeGridColumnsSource, SampleMeSource, SampleOriginDestinationSource, SamplePermissionCatalogSource, SampleRecordAddendumTemplateSource, SampleRecordAddendumTypeSource, SampleRoleAdminSource, SampleTradeUnitVisibilitySource, SampleTraderEmailSource, SaveAnnouncementStore, SessionRecordDraftStore, SimulatedApprovalActionSource, SimulatedWeightLimitCheckSource, TRADER_EMAIL_SOURCE, TRADE_UNIT_VALUES_SOURCE, TRADE_UNIT_VISIBILITY_SOURCE, TRADE_UNIT_VISIBILITY_UNAVAILABLE, TYPED_NUMBER_AVAILABLE_MESSAGE, TYPED_NUMBER_CHECKING_MESSAGE, TYPED_NUMBER_GENERIC_MESSAGE, TYPED_NUMBER_SHORT_MESSAGE, UNKNOWN_SETTINGS_SCOPE, WEIGHT_LIMIT_CHECKING_MESSAGE, WEIGHT_LIMIT_CHECK_SOURCE, WEIGHT_LIMIT_DRIVER_MESSAGE, WEIGHT_LIMIT_NOT_CHECKED, acceptAttributeOf, acceptedFormatsLabel, addendumAnchorProblems, addendumEntryFieldsOf, addendumFieldLabelFallback, addendumTemplatesFor, addendumTypeFor, adminRefusalOf, approveRefusalFor, attachmentChangesSentence, auditActionOf, auditAttachmentsOf, auditChangesOf, auditNoteIdOf, availabilityNotice, buildContracts, changedContractTextCodes, checkExternalLinks, classifyIntercompany, classifyInvalidParam, classifyInvalidParams, coerceForControl, collectionLabel, columnKeysOf, commodityGroupsFrom, conditionOfConflict, confirmChgComponents, confirmationProgress, contractDocumentName, contractRowTone, contractStatusBadge, contractTextBaseline, contractTextNotesPayload, contractTextRefusal, copyExclusions, copyPriceSequences, copyableValues, customerDisplayName, defaultTradeUnitOf, describeAuditAction, describeCollectionCopy, destinationOf, diffConfigDocuments, documentTypeLabel, draftOf, draftStorageKey, editFromSequence, editRefusalFor, emptiedTabs, entryFieldFor, fieldDestinationViolations, fileBoundUrlFor, fileExtensionOf, filenameFrom, filterFromParam, filterToParam, flatPrice, flatPriceAgrees, formatContractDate, formatPrice, formatQuantity, formatShipPeriod, formatShortDate, fromRouteParams, gridColumnChoices, groupByCompany, groupContractDocuments, hasFirstApproval, hasScope, holdsAnyPermissionIn, initialQuery, injectLocationCodes, injectTradeUnitLabel, isAddendumEntryField, isEntraObjectId, isIntercompanyPurchase, isPurchaseContract, isRedactedName, isScoularAddress, isServerSorted, labelOf, listCollections, logNoteSizeRefusal, looksLikeCtrmFieldName, mergeCodeSearchHits, messageForTypedNumberCondition, narrowToConfigured, normaliseCode, normalizeContractListPage, noteByteLength, noteSizeRefusal, parseSortParam, pickedFileRefusal, planCollectionCopy, project, readableBytes, recordOrigin, recordOriginKey, recordTrail, remainingNoteBytes, remarkKey, remarkValuesOf, remarksChanged, remarksPayload, rowCapFrom, rowCapNotice, rowCapReachedFrom, sameContractText, sampleAddendumTemplate, samplePdf, sampleRecordAddendumTemplateDrafts, savedCodeDescriptions, seedFromCtrmValues, settingsScopeOf, shipPeriodRowOf, shipPeriodWriteRow, summarizeAddendumList, tabsAfterCascade, templateValuesOf, toAvailabilityState, toContractListParams, toContractTabId, toCtrmValue, toRouteParams, toSortParam, tradeUnitGridColumnKeys, typeDraftOf, unpricedOpenOutcomeOf, userGridColumnKeys, visibleGridColumnKeys, weightLimitMessage, weightLimitRuleApplies, wholeDaysBetween, writesBlockedBy };

//# sourceMappingURL=cws-domain-contracts.mjs.map
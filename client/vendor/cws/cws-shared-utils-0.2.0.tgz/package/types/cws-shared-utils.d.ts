/**
 * Contract date entry (BR-020, control pattern C3).
 *
 * Lives in @cws/shared-utils rather than the form engine because two libraries need it: the engine
 * for ship-period chaining and description generation, and @cws/shared-ui for the C3 masked date
 * control. Putting it in either of those would have forced a dependency between them in the wrong
 * direction — the engine renders *through* the UI kit (03 §3), so the kit must not depend on the
 * engine. This library is the leaf of the graph, so both can use it without a cycle.
 *
 * The function names still say "ship period" for the original caller; 02a C3 applies the same
 * parsing to contract date, price date and the LC dates.
 *
 * Grain traders type dates as digits, at speed, exactly as the green screen trained them. The
 * calendar popup exists but must never be required (02a §1.1, C3), so parsing is the primary input
 * path and has to be forgiving of the three shapes the legacy system accepted.
 *
 * Everything here is pure and clock-free: the parser never consults "today", so tests are
 * deterministic and there is no time-zone dependence. Callers that need the not-in-the-past check
 * pass the reference date in explicitly.
 */
/** Canonical ISO `yyyy-MM-dd` — the wire and storage form. */
export type IsoDate = string;
export interface ParsedDate {
  readonly year: number;
  readonly month: number;
  readonly day: number;
}
/** Expands a 2-digit year using the BR-020 pivot. */
export declare function expandTwoDigitYear(twoDigitYear: number): number;
/** True when the year/month/day triple is a real calendar date (rejects 02-30, 04-31, non-leap 02-29). */
export declare function isRealDate({ year, month, day }: ParsedDate): boolean;
/** Formats a validated triple as `yyyy-MM-dd`. */
export declare function toIsoDate({ year, month, day }: ParsedDate): IsoDate;
/** Splits an ISO date back into its parts. Returns `null` for anything not `yyyy-MM-dd`. */
export declare function fromIsoDate(iso: IsoDate): ParsedDate | null;
/**
 * Parses ship-period date entry per BR-020.
 *
 * Accepts `MMDDYYYY`, `MMDDYY` (pivoted 1930–2029), and `M/D/YYYY`, `M/D/YY` or year-less `M/D` —
 * each of those three with `.` in place of `/`. Surrounding whitespace is ignored. Returns `null`
 * for anything else: the caller keeps the raw text on the control and shows an inline error so the
 * user can correct it rather than losing what they typed (02a C3).
 *
 * 🔴 **A year-less entry needs `defaultYear`, and omitting it REFUSES rather than guessing.** This
 * module's contract is that it never consults the clock — that is what makes it deterministic under
 * test and free of time-zone dependence — so the year a shorthand expands against is the caller's
 * decision and has to be passed in.
 *
 * ⚠ **Which year that should be is a real question, not a formality.** #198 warns against resolving
 * against "today" without deciding what today means on an edit, because CTRM keys `LOCCOMCON` on the
 * **contract date** rather than the wall clock and a 2025 contract edited in 2026 is a live case
 * (#75). Ruled 2026-09-11: the shorthand expands against the **wall-clock year**, on the grounds
 * that it is a typing aid — it expands at the keystroke and leaves an ordinary explicit date behind,
 * so it is not a resolution rule and does not pre-empt #75. Making the parameter required at the
 * call site is what keeps that a decision rather than a default.
 */
export declare function parseShipPeriodDate(input: string, defaultYear?: number): IsoDate | null;
/** Last calendar day of the month containing `iso`. BR-020 defaults an omitted end date to it. */
export declare function endOfMonth(iso: IsoDate): IsoDate | null;
/** First calendar day of the month containing `iso`. */
export declare function startOfMonth(iso: IsoDate): IsoDate | null;
/** Adds `count` months, clamping the day to the target month's length (Jan 31 + 1 → Feb 28/29). */
export declare function addMonths(iso: IsoDate, count: number): IsoDate | null;
/** Chronological comparison of two ISO dates. Safe as plain string compare, but named for intent. */
export declare function compareIsoDates(left: IsoDate, right: IsoDate): number;
/**
 * Adds `count` days, crossing month and year boundaries.
 *
 * Added for the calendar picker, whose arrow keys move by a day and a week and whose grid starts
 * on the Sunday on or before the first of the month -- so every cell it renders is an offset from
 * some other date. Here rather than in the picker for the reason this whole module exists: a second
 * implementation of date arithmetic is how two parts of one screen come to disagree about what
 * follows 28 February.
 *
 * ⚠ **UTC throughout**, like everything else here. `new Date(y, m, d)` is local time and would shift
 * a date across a boundary for anyone west of Greenwich -- the class of bug that only appears for
 * some users, in some months.
 */
export declare function addDays(iso: IsoDate, count: number): IsoDate | null;
/**
 * The day of the week, 0 (Sunday) to 6 (Saturday), or `null` for an unreadable date.
 *
 * UTC, so it cannot disagree with {@link addDays} about which day a date falls on.
 */
export declare function dayOfWeek(iso: IsoDate): number | null;
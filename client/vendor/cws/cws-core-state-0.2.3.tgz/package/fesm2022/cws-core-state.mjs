import * as i0 from "@angular/core";
import { Injectable, InjectionToken, computed, inject, signal } from "@angular/core";
var AccessNotice = class AccessNotice {
	current = signal(null, ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	message = this.current.asReadonly();
	refuse(message) {
		this.current.set(message);
	}
	clear() {
		this.current.set(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AccessNotice,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AccessNotice,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AccessNotice,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const PERMISSION_CONTEXT = new InjectionToken("PERMISSION_CONTEXT");
const allPermissions = (overrides = {}) => ({
	canWriteContracts: () => true,
	canAccessAdmin: () => true,
	canApproveContracts: () => true,
	canEditPricing: () => true,
	canSeeSystemNotices: () => true,
	writeRefusal: () => null,
	...overrides
});
const noPermissions = () => ({
	canWriteContracts: () => false,
	canAccessAdmin: () => false,
	canApproveContracts: () => false,
	canEditPricing: () => false,
	canSeeSystemNotices: () => false,
	writeRefusal: () => null
});
const TRADE_UNIT_CONTEXT = new InjectionToken("TRADE_UNIT_CONTEXT");
const STORAGE_KEY = "cms.tradeUnit";
var TradeUnitStore = class TradeUnitStore {
	active = signal(read(), ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	code = computed(() => this.active(), ...ngDevMode ? [{ debugName: "code" }] : /* istanbul ignore next */ []);
	hasSelection = computed(() => this.active() !== null, ...ngDevMode ? [{ debugName: "hasSelection" }] : /* istanbul ignore next */ []);
	select(code) {
		const value = code?.trim() ? code.trim() : null;
		this.active.set(value);
		write(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TradeUnitStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TradeUnitStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TradeUnitStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
function read() {
	try {
		return globalThis.sessionStorage?.getItem(STORAGE_KEY) ?? null;
	} catch {
		return null;
	}
}
function write(value) {
	try {
		if (value === null) globalThis.sessionStorage?.removeItem(STORAGE_KEY);
		else globalThis.sessionStorage?.setItem(STORAGE_KEY, value);
	} catch {}
}
const injectTradeUnit = () => inject(TRADE_UNIT_CONTEXT);
export { AccessNotice, PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT, TradeUnitStore, allPermissions, injectTradeUnit, noPermissions };

//# sourceMappingURL=cws-core-state.mjs.map
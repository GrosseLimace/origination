import * as i0 from "@angular/core";
import { InjectionToken } from "@angular/core";
/**
 * The one sentence explaining why a navigation did not happen.
 *
 * ### Why this exists at all, rather than a query parameter on the redirect
 *
 * A guard that refuses `/admin` has to say so *somewhere*, and the obvious implementation is to
 * redirect to `/` carrying `?denied=admin` and let the workspace render it. That was rejected for a
 * reason specific to this application: **the workspace's query string is its shareable state.**
 * Filters, sort, page and the saved view all live there and people paste those URLs at each other,
 * so a parameter that means "you were refused something" would travel to a recipient who was
 * refused nothing, and survive a reload that should have cleared it.
 *
 * ### ⚠ It is transient ON PURPOSE, which makes it the exception to the notices-panel rule
 *
 * The 2026-09-15 ruling is that standing conditions belong in `cms-notices-panel` and **the outcome
 * of something the user just did stays out of it**. A refused navigation is squarely the second
 * kind — it is an event, not a property of the screen it lands on — so it renders as a banner in the
 * shell and is cleared, rather than sitting behind a disclosure describing the workspace.
 *
 * 🔴 **The shell clears it on the next navigation**, so it cannot follow the user around the
 * application. Without that it is a message that outlives its cause, which is worse than no message:
 * it would still be on screen two screens later with nothing to explain it.
 */
export declare class AccessNotice {
  private readonly current;
  /** The message to show, or `null`. Read by the shell. */
  readonly message: import("@angular/core").Signal<string | null>;
  /**
   * Record that a navigation was refused.
   *
   * ⚠ Takes the **whole sentence**, not a module name. The wording differs per module — what an
   * account lacks for Admin is not what it lacks for approvals — and building the sentence here
   * would put copy in a state container, where nobody looks for it.
   */
  refuse(message: string): void;
  clear(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AccessNotice, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * What a feature screen is allowed to do, as the shell understands it.
 *
 * ### 🔴 This is a HINT for the UI, never the enforcement
 *
 * The API is the only thing that decides whether a write is permitted — `CwsContractWriter` requires
 * `Admin`, and `POST`/`PUT /api/v1/contracts` both carry it. Everything here exists so the screen can
 * say *in advance* what the server will say at Save, rather than letting someone fill 104 fields and
 * meet a `403` (#155).
 *
 * ⚠ So a bug here costs a user a misleading button, not an unauthorised write. **Do not let that
 * reasoning run the other way**: a future screen must not treat a `true` from this as permission to
 * skip a server call, because the token is supplied by the host under Module Federation and this
 * library cannot vouch for it.
 *
 * ### Why a token rather than reading the auth service
 *
 * `@cws/core-auth` owns MSAL, and no feature library may depend on MSAL directly — embedded under
 * Module Federation the **host** supplies the identity (docs/02 §1a, 03 §3.4), so a feature that
 * imported MSAL could not be embedded at all. This is the same seam {@link TradeUnitContext} uses,
 * for the same reason.
 *
 * ### 🔴 Named by INTENT, not by role — and that is what makes F1.3 a small change here
 *
 * Every member is a question about *what the caller may do*, never *which role they hold*. Today all
 * four resolve to the same `Admin` test in one file, which looks like redundancy and is not: when
 * F1.3's per-trade-unit matrix lands (#138) these stop agreeing with each other, and the screens
 * that consume them need no edit at all. A screen that asked the auth service for the Admin role
 * would need finding and rewriting; a screen that asks `canEditPricing()` already asks the right
 * question.
 *
 * ⚠ **So the one rule for consumers: read a function off this context, never inspect roles.** There
 * is a spec asserting that no feature library reads the role list at all, for exactly this reason —
 * see `permission-gating.spec.ts`.
 *
 * ### ⚠ What this will have to become, and why it is deliberately NOT that yet
 *
 * #138 scopes every permission to a **trade unit**, and the trade unit is a signal that changes
 * under the user. So these will become either trade-unit-taking functions or async-resolved state,
 * and **the boolean-returning shape here cannot express either**. That is a known, priced change:
 * this interface and `shell-permissions.ts` are the two files it touches, plus whatever the shape
 * change forces on consumers.
 *
 * 🔴 **Do not pre-emptively widen the signature to take a trade unit.** #138 is `BACKEND` and blocked
 * on a business ruling that has not been made, so the parameter's meaning is not yet decided — a
 * guessed shape would be a second thing to migrate rather than none.
 */
export interface PermissionContext {
  /**
   * Whether the signed-in caller may write contracts.
   *
   * ⚠ **False is ambiguous by design**, exactly as `CmsAuthService.roles` is: not signed in, no role
   * assigned, and a token that could not be acquired all read the same. Treat it as "the API will
   * refuse this write" — the one conclusion true in all three cases — and let the API's own 401/403
   * say which.
   */
  readonly canWriteContracts: () => boolean;
  /**
   * Whether the caller may reach the administration module at all.
   *
   * 🔴 **Separate from {@link canWriteContracts} even though both are `Admin` today**, because they
   * are different questions with different answers under F1.3: writing contracts is expected to be
   * scoped per trade unit, while administering the application is not a per-contract capability at
   * all. Collapsing them now would have to be un-collapsed later, in the consumers rather than here.
   *
   * ⚠ This gates **visibility and routing**, never data. The admin endpoints carry `CwsAdmin` on the
   * API and refuse a non-admin regardless of what this returns.
   */
  readonly canAccessAdmin: () => boolean;
  /**
   * Whether the caller may approve or reject a contract.
   *
   * ⚠ **This is OUR authority, not CTRM's.** CTRM runs a per-location approval check of its own
   * (`wnr051e`, the Portal's *"You do NOT have authority to approve this contract"*) which no
   * published route exposes, so a `true` here does not promise CTRM will agree. Screens must word
   * the refusal as what this account lacks rather than speaking for CTRM's rule.
   *
   * ⚠ And the commit is simulated regardless while #108 is open — `approveContracts` OOMs at the
   * CTRM origin for every request shape — so this gates the control, and the screen still has to say
   * the decision did not reach CTRM.
   */
  readonly canApproveContracts: () => boolean;
  /**
   * Whether the caller may add, change or remove price sequences.
   *
   * Separate from {@link canWriteContracts} because the API's write surface already separates them —
   * the three pricing writes are their own endpoints — and because BR-001's price permission is a
   * distinct grant in the legacy model (`sc_cms_CTRM_UserPermission` carries `Price*` alongside
   * `ContractInsert`/`Update`). They happen to agree today; the requirement is that they need not.
   */
  readonly canEditPricing: () => boolean;
  /**
   * Whether the caller sees the screens' environment and system caveats: simulated data, CTRM
   * warnings, row caps, field-limit sources and the like (#1223).
   *
   * 🔴 **The Entra `Admin` role only** (JFrisbie, 2026-10-27), so it is NOT {@link canAccessAdmin}: a
   * holder of `settings:manage` reaches the Admin module and still does not see these. Notices that
   * change what a user does on the screen (a queue's scope, a read-only account, the template picker)
   * are shown to everyone and do not read this.
   *
   * ⚠ Optional, so no host implementation breaks, and **absent means no**: a host that does not answer
   * shows its users none of the caveats. A visibility hint only; nothing in them is data a non-admin
   * cannot already read.
   */
  readonly canSeeSystemNotices?: () => boolean;
  /**
   * Resolves once the answers above are final, for a guard that must not refuse on a provisional
   * `false` (a bookmark to `/admin` arriving before `/me` has answered). Optional, so no existing
   * implementation breaks; absent means the answers are already final.
   */
  readonly settled?: () => Promise<void>;
  /**
   * Why **every CTRM write** is refused in the active trade unit, whatever the caller is granted, or
   * `null` (#411, C-15).
   *
   * 🔴 **The four answers above are GRANTS; this is a refusal on top of them.** A trade unit that is
   * not onboarded is read-only for everyone, Admin included, and the API refuses the write
   * (`TradeUnitWriteAuthorizer`). Keeping it apart from the grants lets a screen show a granted
   * control *disabled with this message* (the F4.3a style) instead of hiding it, because the reason
   * is about the trade unit, not about the account.
   *
   * ⚠ For CTRM writes only. A write that lands in CWS's own SQL (templates, addendum generation,
   * administration) does not read it.
   *
   * Optional, so no existing implementation breaks; absent means no such refusal is known.
   */
  readonly writeRefusal?: () => PermissionWriteRefusal | null;
}
/** A refusal of every CTRM write in the active trade unit, and the sentence that says so. */
export interface PermissionWriteRefusal {
  /**
   * `NotOnboarded`: the trade unit has no configuration yet (C-15). `PermissionsUnavailable`: the
   * permissions could not be read, so nothing counts as onboarded and nothing can be authorized.
   */
  readonly kind: 'NotOnboarded' | 'PermissionsUnavailable';
  /** One sentence for the user, shown at the refused control. */
  readonly message: string;
}
export declare const PERMISSION_CONTEXT: InjectionToken<PermissionContext>;
/**
 * A {@link PermissionContext} for specs.
 *
 * ### 🔴 One factory rather than a stub per spec
 *
 * Five screens consume this context. Written inline, a sixth capability would break five specs
 * separately and be patched five times — and the fifth person to patch one would reach for
 * `as unknown as PermissionContext` and quietly opt that screen out of the type. One factory means
 * a new capability is one edit here and a compiler error nowhere else.
 *
 * ### ⚠ It GRANTS everything by default, which is the opposite of the safe-looking choice
 *
 * Default-deny reads as the careful option and is wrong for this seam: almost every spec that
 * provides this context has a subject that is not permission at all — the grid's sorting, the
 * record's tabs, the pricing editor's arithmetic — and under default-deny those screens would render
 * with their controls missing and the specs would be silently testing a read-only variant of the
 * thing they name.
 *
 * So the default is "a fully entitled user", which is what those specs have always implicitly had,
 * and a spec that is *about* the gate says so at its call site:
 *
 * ```ts
 * render(Screen, { providers: [{ provide: PERMISSION_CONTEXT, useValue: allPermissions({ canEditPricing: () => false }) }] });
 * ```
 *
 * ⚠ **This is a test double and it proves nothing about the real resolver.** The shell's own matrix
 * exercises `shellPermissionContext` directly for that reason — see `permission-gating.spec.ts`.
 * Anything asserted through this factory is a claim about the SCREEN's reaction to a capability,
 * never about which capabilities a principal actually has.
 */
export declare const allPermissions: (overrides?: Partial<PermissionContext>) => PermissionContext;
/** Nothing granted — a signed-in account with no app role, which is a real population. */
export declare const noPermissions: () => PermissionContext;
/**
 * The trade unit a feature is operating under.
 *
 * A token rather than a concrete service because **the shell is not the only host**. Standalone,
 * the shell owns the choice and the switcher writes it. Embedded under Module Federation the *host*
 * supplies it, alongside the token — docs/02 §1a: "Host supplies user context/token". A feature that
 * injected the shell's store directly could not be embedded at all.
 */
export interface TradeUnitContext {
  /** The active CTRM location code, or `null` before one is chosen. */
  readonly code: () => string | null;
}
export declare const TRADE_UNIT_CONTEXT: InjectionToken<TradeUnitContext>;
/**
 * The shell's implementation of {@link TradeUnitContext}.
 *
 * **Trade unit is a first-class shell concept, not screen state** (docs/02 §1.1): the nav entries are
 * permission-gated per active trade unit, and switching re-resolves form config, permissions and
 * reference data. Holding it per screen would let the contract list and the contract form disagree
 * about which unit is active — a whole class of bug rather than an inconvenience.
 *
 * Remembered for the session, per correction C-15. `sessionStorage` rather than `localStorage`
 * deliberately: the choice should not outlive the tab, because coming back days later to a silently
 * pre-selected unit is how someone reads the wrong location's contracts without noticing.
 */
export declare class TradeUnitStore implements TradeUnitContext {
  private readonly active;
  readonly code: import("@angular/core").Signal<string | null>;
  /** True once a unit is chosen — the precondition `contract/list` imposes (#40 finding 2). */
  readonly hasSelection: import("@angular/core").Signal<boolean>;
  select(code: string | null): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<TradeUnitStore, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** Reads the active trade unit from whichever host supplied it. */
export declare const injectTradeUnit: () => TradeUnitContext;
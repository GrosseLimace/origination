import { HttpErrorResponse, HttpInterceptorFn } from "@angular/common/http";
/**
 * What a failure *is*, so a screen branches on a named case rather than on a status code.
 *
 * ⚠ **`CtrmFault` already has a system-outage banner** — `RemoteData`'s error surface and the shell's
 * outage strip — and this classification exists to reach it consistently, not to replace it.
 */
export declare const ProblemKind: {
  /** 422 — CTRM or FluentValidation refused the request. The only kind carrying reasons. */
  readonly Validation: "Validation";
  /** 401 — no token, or one the API would not accept. */
  readonly Unauthenticated: "Unauthenticated";
  /** 403 — authenticated, but not entitled. */
  readonly Forbidden: "Forbidden";
  /** 502 `ctrm-fault` — CTRM could not be reached or answered unusably. */
  readonly CtrmFault: "CtrmFault";
  /** 503 `ctrm-unavailable` — CTRM is administratively closed (a night run, a maintenance window). */
  readonly CtrmUnavailable: "CtrmUnavailable";
  readonly Unknown: "Unknown";
};
export type ProblemKind = (typeof ProblemKind)[keyof typeof ProblemKind];
/**
 * A parsed RFC 7807 body.
 *
 * 🔴 **`errors` and `formErrors` are deliberately separate, and merging them would be a regression.**
 * `CtrmResultExtensions` says why in its own remarks: an earlier API draft put form-level text into
 * `errors["_form"]`, which made `errors` a mixture of control names and one magic string the client
 * had to remember to special-case — *"and forgetting it fails silently."* Keeping them apart means
 * **every key in `errors` is addressable on the form by construction**, and form-level text has
 * nowhere to hide.
 */
export interface CwsProblem {
  readonly status: number;
  readonly kind: ProblemKind;
  readonly title: string | null;
  readonly detail: string | null;
  readonly type: string | null;
  readonly traceId: string | null;
  /** Control name → messages. Strictly addressable; never form-level text. */
  readonly errors: Readonly<Record<string, readonly string[]>>;
  /**
   * Reasons that address no control.
   *
   * Always an array — the API omits the member entirely when there are none and tells clients to
   * read it as `formErrors ?? []`, so normalising here means no consumer repeats that.
   */
  readonly formErrors: readonly string[];
  /**
   * The `reference` extension: the code a person quotes to the Help Desk (#1141), such as
   * `CWS-WRITE-NO-USER`. Present only when the server sent one.
   */
  readonly reference?: string;
}
/**
 * Parses an RFC 7807 body into {@link CwsProblem}.
 *
 * Total by construction: a body that is absent, a string, HTML from a gateway, or JSON of an
 * unexpected shape all produce a `CwsProblem` with empty collections rather than throwing. A parser
 * that threw inside an error handler would replace a described failure with an undescribed one.
 */
export declare function parseProblem(error: HttpErrorResponse): CwsProblem;
/**
 * Parses anything that might be an HTTP failure.
 *
 * 🔴 **Deliberately not narrowed to `HttpErrorResponse`.** The interceptor produces one, but a
 * source is free to re-throw a plain `{ status, error }` and several do — so a reader that
 * `instanceof`-checked would silently return no reasons for those, which is the field-scoped errors
 * vanishing rather than failing. Measured: narrowing it broke eight record-screen tests that throw
 * exactly that shape.
 *
 * Total: an absent, primitive or oddly-shaped value yields an empty problem rather than throwing.
 */
export declare function problemFrom(error: unknown): CwsProblem;
/**
 * The problem `type` values the API answers a lost CTRM write with, once it has read the contract
 * back to settle it (#513, "A+"). Both arrive as a `502`, because CTRM gave no answer, and they tell
 * the screen OPPOSITE things about a retry — which is why they are named here rather than left to
 * the status code (#556). They come from `CtrmResultExtensions.Faulted` in the API.
 */
export declare const CtrmWriteProblemType: {
  /** Read back: the change is NOT in CTRM. Nothing was saved, and saving again is safe. */
  readonly NotApplied: "ctrm-write-not-applied";
  /** The read-back itself failed. The change may or may not be in CTRM. */
  readonly OutcomeUnknown: "ctrm-write-outcome-unknown";
};
/**
 * What a failed WRITE means for the data behind it (#556).
 *
 * - `refused` — the API or CTRM said no, so nothing changed. A `422` carries the reasons.
 * - `not-applied` — CTRM did not answer, and reading back showed the change is not there.
 * - `outcome-unknown` — **nobody knows whether the change landed.** Saving again may apply it twice,
 *   and on a create that is a second contract.
 */
export type WriteFailureOutcome = 'refused' | 'not-applied' | 'outcome-unknown';
/**
 * Classifies a failed write by its problem type first and its status second.
 *
 * 🔴 **Anything that is not a recognisable refusal reads as `outcome-unknown`, never as "not
 * saved".** A status `0` is a browser that never got an answer; a `500`, a bare `502`, a `504` or a
 * generic `ctrm-fault` may all have been raised after CTRM took the write, and CTRM answers `202`
 * whatever the outcome (C-4). Saying "not saved" when that is not known is how a retry becomes a
 * duplicate write. The two directions are not symmetric: telling a user "might have saved" about a
 * write that did not land costs a reload, while "not saved" about one that did costs a second
 * contract.
 *
 * ⚠ A `503 ctrm-unavailable` is a refusal: the API's gate and circuit breaker answer it before any
 * call to CTRM is made. A bare `503` with no type is not, for the same reason a bare `502` is not a
 * CTRM fault we can describe.
 */
export declare function writeOutcomeOf(problem: CwsProblem): WriteFailureOutcome;
/** True when the value has already been through {@link parseProblem}. */
export declare function isCwsProblem(value: unknown): value is CwsProblem;
/**
 * **F2.4's last piece — one place that reads an RFC 7807 body, for every feature at once.**
 *
 * Three feature sources each hand-rolled their own translation and each said in a comment that this
 * interceptor was the real home for it. It replaces the error body with the parsed
 * {@link CwsProblem}, so a screen reads named fields instead of digging through an unknown shape.
 *
 * 🔴 **`errors` passes through untouched, and that is load-bearing.** The control-mapping path that
 * lands a field-scoped 422 on its control and its tab already works (2026-09-17); this must not
 * reshape what it consumes. `CwsProblem` keeps `errors` under its own name and with its own meaning
 * — control name → messages — so that path is unchanged. What the interceptor adds is `formErrors`
 * reaching the screen at all, normalised to `[]` rather than absent.
 *
 * ⚠ **It re-throws, always.** An interceptor that swallowed a failure, or converted one into an
 * empty success, would produce the save-appeared-to-work shape this repository keeps recording —
 * and on a full-replace upsert that is a data question, not a cosmetic one.
 *
 * ⚠ **It classifies but does not render.** 502 `ctrm-fault` already has a system-outage banner and
 * 401 already redirects through MSAL; the interceptor names the case so those existing paths are
 * reached consistently, and deliberately does not invent a second one.
 */
export declare const problemDetailsInterceptor: HttpInterceptorFn;
/**
 * The three `403` problem types a CTRM write is refused with when CWS cannot confirm the signed-in
 * user in CTRM (#994, PR #1134; `CtrmResultExtensions.WriteIdentityRefused` in the API).
 */
export declare const WriteIdentityProblemType: {
  /** No active CTRM user has the email. */
  readonly NoUser: "ctrm-user-not-found";
  /** More than one active CTRM user has the email. */
  readonly EmailShared: "ctrm-user-ambiguous";
  /** The CTRM user's IBM i profile is blank or not enabled. */
  readonly ProfileUnconfirmed: "ctrm-user-profile-unconfirmed";
};
/** What a screen says for one of them: the server's sentence, and the code to quote. */
export interface WriteIdentityRefusal {
  readonly detail: string;
  readonly reference: string;
}
/**
 * **#1141: a write refused because the signed-in user is not confirmed in CTRM**, or `null` for
 * anything else, so every other `403` keeps the words its screen already uses.
 *
 * The detail is the server's, without its trailing `Reference: <code>.`, and the reference is the
 * `reference` extension (or that trailing code), so a screen shows the sentence through
 * `cms-status-message` and the code through `cms-reference-line`, once each. The code replaces the
 * trace id in that line: it is what the Help Desk acts on.
 */
export declare function writeIdentityRefusalOf(problem: CwsProblem): WriteIdentityRefusal | null;
import { HttpErrorResponse } from "@angular/common/http";
import { catchError, from, switchMap, throwError } from "rxjs";
const ProblemKind = {
	Validation: "Validation",
	Unauthenticated: "Unauthenticated",
	Forbidden: "Forbidden",
	CtrmFault: "CtrmFault",
	CtrmUnavailable: "CtrmUnavailable",
	Unknown: "Unknown"
};
const CTRM_FAULT_TYPE = "ctrm-fault";
const CTRM_UNAVAILABLE_TYPE = "ctrm-unavailable";
function text(value) {
	return typeof value === "string" && value.trim() !== "" ? value : null;
}
function messages(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((entry) => typeof entry === "string" && entry.trim() !== "");
}
function readErrors(value) {
	if (value === null || typeof value !== "object" || Array.isArray(value)) return {};
	const result = {};
	for (const [key, entry] of Object.entries(value)) {
		const reasons = messages(entry);
		if (reasons.length > 0) result[key] = reasons;
	}
	return result;
}
function classify(status, type) {
	if (status === 422) return ProblemKind.Validation;
	if (status === 401) return ProblemKind.Unauthenticated;
	if (status === 403) return ProblemKind.Forbidden;
	if (type === CTRM_FAULT_TYPE || status === 502) return ProblemKind.CtrmFault;
	if (type === CTRM_UNAVAILABLE_TYPE || status === 503) return ProblemKind.CtrmUnavailable;
	return ProblemKind.Unknown;
}
function parseProblem(error) {
	const body = error.error !== null && typeof error.error === "object" ? error.error : {};
	const type = text(body.type);
	const reference = text(body.reference);
	return {
		...reference === null ? {} : { reference },
		status: error.status,
		kind: classify(error.status, type),
		title: text(body.title),
		detail: text(body.detail),
		type,
		traceId: text(body.traceId),
		errors: readErrors(body.errors),
		formErrors: messages(body.formErrors)
	};
}
function problemFrom(error) {
	if (error instanceof HttpErrorResponse) return parseProblem(error);
	if (error === null || typeof error !== "object") return parseProblem(new HttpErrorResponse({
		status: 0,
		error: null
	}));
	const candidate = error;
	return parseProblem(new HttpErrorResponse({
		status: typeof candidate.status === "number" ? candidate.status : 0,
		error: candidate.error ?? null
	}));
}
const CtrmWriteProblemType = {
	NotApplied: "ctrm-write-not-applied",
	OutcomeUnknown: "ctrm-write-outcome-unknown"
};
function writeOutcomeOf(problem) {
	if (problem.type === CtrmWriteProblemType.NotApplied) return "not-applied";
	if (problem.type === CtrmWriteProblemType.OutcomeUnknown) return "outcome-unknown";
	if (problem.type === CTRM_UNAVAILABLE_TYPE) return "refused";
	return problem.status === 0 || problem.status >= 500 ? "outcome-unknown" : "refused";
}
function isCwsProblem(value) {
	return value !== null && typeof value === "object" && "kind" in value && "formErrors" in value && "errors" in value;
}
const problemDetailsInterceptor = (request, next) => next(request).pipe(catchError((error) => {
	if (!(error instanceof HttpErrorResponse)) return throwError(() => error);
	if (error.error instanceof Blob || error.error instanceof ArrayBuffer) return from(binaryProblemOf(error)).pipe(switchMap((body) => throwError(() => body === void 0 ? error : described(error, body))));
	return throwError(() => described(error, error.error));
}));
function described(error, body) {
	return new HttpErrorResponse({
		error: parseProblem(new HttpErrorResponse({
			error: body,
			headers: error.headers,
			status: error.status
		})),
		headers: error.headers,
		status: error.status,
		statusText: error.statusText,
		url: error.url ?? void 0
	});
}
const JSON_TYPE = /(^|[/+])json\s*(;|$)/i;
async function binaryProblemOf(error) {
	const body = error.error;
	const type = (body instanceof Blob && body.type !== "" ? body.type : error.headers?.get("Content-Type")) ?? "";
	if (!JSON_TYPE.test(type.trim())) return;
	try {
		const text = body instanceof Blob ? await body.text() : new TextDecoder().decode(body);
		return JSON.parse(text);
	} catch {
		return;
	}
}
const WriteIdentityProblemType = {
	NoUser: "ctrm-user-not-found",
	EmailShared: "ctrm-user-ambiguous",
	ProfileUnconfirmed: "ctrm-user-profile-unconfirmed"
};
const FALLBACKS = {
	[WriteIdentityProblemType.NoUser]: {
		detail: "No active CTRM user is linked to your email, so CTRM cannot record this change as yours. Ask the Help Desk to set one up.",
		reference: "CWS-WRITE-NO-USER"
	},
	[WriteIdentityProblemType.EmailShared]: {
		detail: "Your email is linked to more than one CTRM user, so CTRM cannot tell which one made this change. Ask the Help Desk to remove the duplicate.",
		reference: "CWS-WRITE-EMAIL-SHARED"
	},
	[WriteIdentityProblemType.ProfileUnconfirmed]: {
		detail: "CTRM could not confirm that your CTRM user is enabled. Ask the Help Desk to check it.",
		reference: "CWS-WRITE-PROFILE"
	}
};
const TRAILING_REFERENCE = /\s*Reference:\s*([A-Za-z0-9-]+)\.?\s*$/;
function writeIdentityRefusalOf(problem) {
	if (problem.status !== 403 || problem.type === null || !Object.hasOwn(FALLBACKS, problem.type)) return null;
	const fallback = FALLBACKS[problem.type];
	const said = problem.detail?.trim() ?? "";
	const trailing = TRAILING_REFERENCE.exec(said);
	const reference = problem.reference ?? trailing?.[1] ?? fallback.reference;
	const detail = trailing !== null && trailing[1] === reference ? said.slice(0, trailing.index).trim() : said;
	return {
		detail: detail === "" ? fallback.detail : detail,
		reference
	};
}
export { CtrmWriteProblemType, ProblemKind, WriteIdentityProblemType, isCwsProblem, parseProblem, problemDetailsInterceptor, problemFrom, writeIdentityRefusalOf, writeOutcomeOf };

//# sourceMappingURL=cws-core-http.mjs.map
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, HostListener, computed, inject, input, signal } from "@angular/core";
import { toObservable, toSignal } from "@angular/core/rxjs-interop";
import { ActivatedRoute } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { CONTRACT_LIST_SOURCE, DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE, PRICING_SOURCE, RECORD_ORIGIN_PARAM, flatPrice, flatPriceAgrees, formatContractDate, formatQuantity, formatShipPeriod, formatShortDate, fromRouteParams, injectTradeUnitLabel, recordOrigin, recordOriginKey, toRouteParams, toSortParam } from "@cws/domain-contracts";
import { AsyncContainerComponent, BreadcrumbComponent, ClearSortButtonComponent, DataGridComponent, DateInputComponent, EMPTY_FILTER, FilterBuilderComponent, FilterSelectComponent, GridExportComponent, GridToolbarComponent, NoticesPanelComponent, PageHeaderComponent, PagerComponent, RefreshButtonComponent, SAVED_FILTER_SCOPES, SearchShortcutDirective, compareBySorts, injectConfirm, matchesGroup, matchesSearch, remoteLoading } from "@cws/shared-ui";
import { filter, firstValueFrom, of, switchMap } from "rxjs";
import * as i1 from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { DecimalPipe } from "@angular/common";
function pricedQuantity(row) {
	if (row.quantity === null || row.unpricedQuantity === null) return null;
	return row.quantity - row.unpricedQuantity;
}
function needsPricing(row) {
	return (row.unpricedQuantity ?? 0) > 0;
}
const quantityColumn = (key, header, value, tooltip) => ({
	key,
	header,
	align: "end",
	sortable: true,
	width: 135,
	format: (row) => formatQuantity(value(row)),
	sortValue: (row) => value(row) ?? Number.NEGATIVE_INFINITY,
	...tooltip === void 0 ? {} : { tooltip: () => tooltip }
});
const PRICING_GRID_COLUMNS = [
	{
		key: "contractNumber",
		header: "Contract",
		sortable: true,
		width: 130,
		format: (row) => row.contractNumber
	},
	{
		key: "contractDate",
		header: "Date",
		sortable: true,
		width: 90,
		format: (row) => formatShortDate(row.contractDate),
		sortValue: (row) => row.contractDate ?? "",
		tooltip: (row) => formatContractDate(row.contractDate)
	},
	{
		key: "customerId",
		header: "Customer",
		sortable: true,
		width: 180,
		format: (row) => row.customerId ?? ""
	},
	{
		key: "commodity",
		header: "Commodity",
		sortable: true,
		width: 120,
		format: (row) => row.commodity ?? ""
	},
	{
		key: "priceTypeCode",
		header: "Type",
		sortable: true,
		width: 80,
		format: (row) => row.priceTypeCode ?? ""
	},
	quantityColumn("quantity", "Contract Qty", (row) => row.quantity, "The contract quantity CTRM holds, in the contract’s own unit."),
	quantityColumn("pricedQuantity", "Priced", pricedQuantity, "Contract quantity minus unpriced quantity. Derived here — CTRM does not return it on this route."),
	quantityColumn("unpricedQuantity", "Unpriced", (row) => row.unpricedQuantity, "What still needs a price. This is the figure the queue is built on."),
	quantityColumn("appliedQuantity", "Applied", (row) => row.appliedQuantity, "Quantity applied against shipments."),
	quantityColumn("openQuantity", "Open", (row) => row.openQuantity, "Quantity still open."),
	{
		key: "shipPeriodBegin",
		header: "Ship Period",
		sortable: true,
		width: 180,
		format: formatShipPeriod,
		sortValue: (row) => row.shipPeriodBegin ?? ""
	},
	{
		key: "marketZone",
		header: "Zone",
		sortable: true,
		width: 90,
		format: (row) => row.marketZone ?? ""
	},
	{
		key: "trader",
		header: "Trader",
		sortable: true,
		width: 140,
		format: (row) => row.trader ?? row.traderInitials ?? ""
	}
];
const DEFAULT_SORTS = [{
	key: "unpricedQuantity",
	direction: "desc"
}];
var PricingPageComponent = class PricingPageComponent {
	source = inject(CONTRACT_LIST_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	approvalsIntent = {
		kind: "module",
		module: "pricing-approvals"
	};
	approvalsHref = computed(() => this.hostContext.hrefFor(this.approvalsIntent), ...ngDevMode ? [{ debugName: "approvalsHref" }] : /* istanbul ignore next */ []);
	followApprovals(event) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(this.approvalsIntent);
	}
	columns = PRICING_GRID_COLUMNS;
	initial = fromRouteParams(this.route.snapshot.queryParamMap);
	sorts = signal(this.route.snapshot.queryParamMap.get("sort") === null ? DEFAULT_SORTS : this.initial.sorts, ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	defaultSorts = DEFAULT_SORTS;
	searchTerm = signal(this.initial.query.search ?? "", ...ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []);
	focusKey = signal(this.initial.focus, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	query = computed(() => {
		return {
			status: "Open",
			...this.tradeUnit.code() === null ? {} : { tradeUnit: this.tradeUnit.code() },
			sort: toSortParam(this.sorts()),
			page: 1,
			pageSize: MAX_PAGE_SIZE
		};
	}, ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	data = toSignal(toObservable(computed(() => ({
		query: this.query(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ query }) => this.source.list(query))), { initialValue: remoteLoading() });
	containerState = computed(() => this.hasTradeUnit() ? this.data() : {
		status: "loaded",
		value: emptyPage(this.query())
	}, ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	result = computed(() => {
		const state = this.data();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "result" }] : /* istanbul ignore next */ []);
	fetched = computed(() => this.result()?.rows ?? [], ...ngDevMode ? [{ debugName: "fetched" }] : /* istanbul ignore next */ []);
	queue = computed(() => {
		const term = this.searchTerm();
		const filtered = this.fetched().filter((row) => needsPricing(row) && matchesGroup(row, this.columns, this.filter()) && matchesSearch(row, this.columns, term));
		const sorts = this.sorts();
		return sorts.length === 0 ? filtered : [...filtered].sort((left, right) => compareBySorts(this.columns, sorts, left, right));
	}, ...ngDevMode ? [{ debugName: "queue" }] : /* istanbul ignore next */ []);
	page = signal(this.initial.query.page, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	pageSize = DEFAULT_PAGE_SIZE;
	totalPages = computed(() => Math.max(1, Math.ceil(this.queue().length / this.pageSize)), ...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const start = (this.currentPage() - 1) * this.pageSize;
		return this.queue().slice(start, start + this.pageSize);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	currentPage = computed(() => Math.min(Math.max(this.page(), 1), this.totalPages()), ...ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []);
	rangeLabel = computed(() => {
		const total = this.queue().length;
		if (total === 0) return "";
		return `${(this.currentPage() - 1) * this.pageSize + 1}–${Math.min(this.currentPage() * this.pageSize, total)} of ${total}`;
	}, ...ngDevMode ? [{ debugName: "rangeLabel" }] : /* istanbul ignore next */ []);
	onPage(page) {
		this.page.set(page);
	}
	onPageStep(step) {
		this.page.set(Math.min(Math.max(this.currentPage() + step, 1), this.totalPages()));
	}
	isRefreshing = computed(() => this.data().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => this.result()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.result()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [
		"Where pricing and approvals are done",
		...this.isSimulated() ? ["Simulated rows, not read from CTRM"] : [],
		...this.warnings()
	], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	hasTradeUnit = computed(() => {
		const code = this.tradeUnit.code();
		return code !== null && code !== "";
	}, ...ngDevMode ? [{ debugName: "hasTradeUnit" }] : /* istanbul ignore next */ []);
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportFilename = (scope) => {
		return `unpriced-${this.tradeUnit.code() ?? "all"}-${scope === "page" ? `page-${this.currentPage()}` : "all"}`;
	};
	exportAllRows = () => Promise.resolve(this.queue());
	emptyMessage = computed(() => this.hasTradeUnit() ? "Every open contract in this trade unit is fully priced." : "Choose a trade unit in the top bar to load unpriced contracts.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	moreThanOnePage = computed(() => (this.result()?.totalPages ?? 1) > 1, ...ngDevMode ? [{ debugName: "moreThanOnePage" }] : /* istanbul ignore next */ []);
	totalOpen = computed(() => this.result()?.totalCount ?? 0, ...ngDevMode ? [{ debugName: "totalOpen" }] : /* istanbul ignore next */ []);
	trackByContract = (row) => row.contractNumber;
	onSortChange(sorts) {
		this.sorts.set(sorts);
	}
	filter = signal(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	savedFilterScope = SAVED_FILTER_SCOPES.pricing;
	onRulesChange(group) {
		this.filter.set(group);
		this.page.set(1);
	}
	onViewChange(view) {
		this.filter.set(view.group);
		this.sorts.set(view.sort);
		this.page.set(1);
	}
	onSearch(term) {
		this.searchTerm.set(term);
		this.page.set(1);
	}
	refresh() {
		this.attempt.update((value) => value + 1);
	}
	retry() {
		this.refresh();
	}
	onRowActivate(row) {
		const params = toRouteParams(this.query(), this.sorts(), row.contractNumber);
		const search = this.searchTerm().trim();
		const returnTo = new URLSearchParams({
			...params,
			...search === "" ? {} : { search },
			...this.currentPage() > 1 ? { page: String(this.currentPage()) } : {}
		}).toString();
		this.hostContext.navigate({
			kind: "review",
			origin: "pricing",
			contractNumber: row.contractNumber,
			params: {
				returnTo,
				[RECORD_ORIGIN_PARAM]: "pricing"
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: PricingPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: PricingPageComponent,
		isStandalone: true,
		selector: "cms-pricing-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    title=\"Pricing\"\r\n    description=\"Open contracts with quantity still to price, most outstanding first.\"\r\n  >\r\n    <!--\r\n      🔴 A LINK in the header actions, not a fifth module in the shell nav.\r\n      Approving price sequences is something you do having read this queue, not a separate place in\r\n      the application — and the nav is the four modules of docs/02 §1.1, which this is not one of.\r\n    -->\r\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /pricing/approvals escapes. -->\r\n    <a\r\n      cmsPageHeaderActions\r\n      [attr.href]=\"approvalsHref()\"\r\n      (click)=\"followApprovals($event)\"\r\n      class=\"scoular-btn scoular-btn-secondary\"\r\n    >\r\n      Pricing approvals\r\n    </a>\r\n  </cms-page-header>\r\n\r\n  <!--\r\n    ⚠ **This block used to say price entry was impossible from this application**, citing two\r\n    blockers: that `prices` is not writable on `upsertContract`, and that the API published no pricing\r\n    route. The first is still true and is why a contract cannot be created *with* its prices. The\r\n    second stopped being true when `PricingEndpoints` shipped, and nothing re-pointed the sentence —\r\n    so this queue told users to go to the green screen while the editor it links to was live.\r\n\r\n    The rule that missed it is the one this repository keeps re-learning: a statement on screen is not\r\n    re-checked by the change that falsifies it unless something asserts it. There is a test for this\r\n    wording now.\r\n  -->\r\n  <!--\r\n    Standing notices, in the shared collapsible panel — the same one the workspace and the approval\r\n    queue use (JFrisbie, 2026-09-14). This screen opened with a capability warning, a simulated-data\r\n    banner and one row per server warning, ahead of the queue itself.\r\n  -->\r\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Where pricing is done</div>\r\n      <div class=\"scoular-alert-description\">\r\n        Opening a row shows that contract's price sequences, where they can be added, changed and\r\n        removed. Approving them is on Pricing approvals, linked above. A contract cannot be created\r\n        with its prices already on it — CTRM does not accept them on a contract write — so prices are\r\n        always entered after the contract exists.\r\n      </div>\r\n    </div>\r\n\r\n    @if (isSimulated()) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Simulated data</div>\r\n        <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\r\n      </div>\r\n    }\r\n\r\n    @for (warning of warnings(); track warning) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n      </div>\r\n    }\r\n  </cms-notices-panel>\r\n\r\n  <!--\r\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto` — the same\r\n    order and the same split as the workspace grid and the approvals queue, so the controls do not\r\n    move between screens (JFrisbie, 2026-09-10).\r\n  -->\r\n  <!--\r\n    🔴 **The width goes on the LABEL, never on the field.** `.scoular-form-input` is `@apply w-full`\r\n    and the design system compiles unlayered, so a `w-32` on the input silently loses to it and the\r\n    field fills its wrapper — every filter here measured **193px** regardless of its class, which is\r\n    what pushed the refresh/pager block onto a second line at 1280px. Seventh instance of this trap;\r\n    the remedy is to put the declaration on the wrapper, which has no design-system class to fight.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <cms-grid-toolbar>\r\n    <!--\r\n      One search box, replacing four per-field boxes plus a server-side search (JFrisbie,\r\n      2026-09-10).\r\n\r\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so\r\n      Customer, Commodity, Trader and Price type are all still reachable, along with the four\r\n      columns the old boxes could not narrow on.\r\n\r\n      ⚠ **Applied CLIENT-SIDE and no longer sent as a request parameter.** The server matches\r\n      three fields where this box matches all eight, so sending it too would narrow the fetched\r\n      set by a different rule than the one on screen. It costs nothing: the API fetches the whole\r\n      status set for the trade unit either way — `ContractListProjector` filters in process —\r\n      which is also why this screen already asks for the largest page it can.\r\n\r\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\r\n      move as a user goes between the two screens.\r\n    -->\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        autocomplete=\"off\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"searchTerm()\"\r\n        (input)=\"onSearch($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!--\r\n      Saved views and the rule builder, the same pair the workspace and the approvals queue carry.\r\n      Its OWN scope: a view from another grid would carry rules against columns this one does not\r\n      render and match nothing, which here reads as \"nothing to price\".\r\n\r\n      The width is on the wrapper, never the control - .scoular-form-input is @apply w-full and the\r\n      design system compiles unlayered, so a w-* on the control itself would lose.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\r\n      (click)=\"builder.beginAdd()\"\r\n    >\r\n      + Add filter\r\n    </button>\r\n\r\n    <!--\r\n      Clear sort, hidden until the queue is sorted some other way -- see the approval queue's own\r\n      note. This screen arrives largest-outstanding-first, so that ordering is the screen's doing\r\n      rather than the user's, and returning to it is what \"clear\" has to mean here.\r\n    -->\r\n    <cms-clear-sort-button\r\n      [sorts]=\"sorts()\"\r\n      [defaultSorts]=\"defaultSorts\"\r\n      (clear)=\"onSortChange($event)\"\r\n    />\r\n\r\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\r\n      <!--\r\n        Export, the same shared control the workspace and the approval queue carry. Both scopes are\r\n        cheap here - this screen fetches one large page and narrows in the browser - and the choice\r\n        is still offered, because \"what I am looking at\" and \"everything the filter matched\" are\r\n        different files on a paged grid. See `cms-grid-export`.\r\n      -->\r\n      <cms-grid-export\r\n        [columns]=\"columns\"\r\n        [pageRows]=\"rows()\"\r\n        [totalCount]=\"queue().length\"\r\n        [allRows]=\"exportAllRows\"\r\n        [filename]=\"exportFilename\"\r\n        [disabled]=\"!hasTradeUnit() || queue().length === 0\"\r\n        (failed)=\"exportError.set($event)\"\r\n      />\r\n\r\n      <cms-refresh-button\r\n        label=\"Refresh the unpriced queue\"\r\n        [busy]=\"isRefreshing()\"\r\n        [disabled]=\"!hasTradeUnit()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <cms-pager\r\n        [page]=\"currentPage()\"\r\n        [totalPages]=\"totalPages()\"\r\n        position=\"top\"\r\n        (goTo)=\"onPage($event)\"\r\n      />\r\n    </div>\r\n  </cms-grid-toolbar>\r\n\r\n  <!--\r\n    Chips and the rule editor. Renders nothing when there are no rules and the editor is closed, so\r\n    it leaves no empty band above the queue. Its own add button is suppressed because the toolbar\r\n    carries one - one owner for the editor state.\r\n  -->\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onRulesChange($event)\"\r\n  />\r\n\r\n  <!--\r\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\r\n    failed export is the outcome of something the user just did.\r\n  -->\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\r\n\r\n    This screen used to render a `scoular-card` above the container and hide the container behind\r\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\r\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\r\n    read as a notice about the data rather than as the absence of any.\r\n\r\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\r\n    unit the request is certain to 422, which is why the screen never issues one.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    [empty]=\"!hasTradeUnit() || queue().length === 0\"\r\n    [emptyMessage]=\"emptyMessage()\"\r\n      loadingLabel=\"Loading unpriced contracts\"\r\n      (retry)=\"retry()\"\r\n    >\r\n      <!--\r\n        ⚠ **`striped` is safe here because this queue declares no `rowTone`** — the same condition the\r\n        approvals queue records. A stripe and a semantic tint are both a background on the `<tr>`, and\r\n        together the tint stops meaning anything. The grid enforces the precedence rather than\r\n        trusting this binding, but adding a tone to this queue later would make the stripe the wrong\r\n        call rather than merely a redundant one.\r\n      -->\r\n      <cms-data-grid\r\n        [rows]=\"rows()\"\r\n        [columns]=\"columns\"\r\n        label=\"Contracts with quantity to price\"\r\n        [striped]=\"true\"\r\n        [sorts]=\"sorts()\"\r\n        [trackBy]=\"trackByContract\"\r\n        [focusKey]=\"focusKey()\"\r\n        (sortChange)=\"onSortChange($event)\"\r\n        (rowActivate)=\"onRowActivate($event)\"\r\n        (pageStep)=\"onPageStep($event)\"\r\n      />\r\n\r\n      <!--\r\n        The footer, matching the workspace grid: record count left, pager right.\r\n\r\n        🔴 The count is over the QUEUE, not over what the server sent — `1–50 of 87` means 87\r\n        contracts need pricing, which is what the screen is about. The second line keeps the\r\n        client-side filter honest: it names how many open contracts were read to find them, and warns\r\n        when the server had more pages than it sent, because the filter cannot see past those.\r\n      -->\r\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\r\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <p>{{ rangeLabel() }}</p>\r\n          <p class=\"cws:mt-0.5 cws:text-xs\">\r\n            Found in {{ fetched().length }} open contracts read.\r\n            @if (moreThanOnePage()) {\r\n              <span class=\"cws:text-amber-700 cws:dark:text-amber-400\">\r\n                This trade unit has {{ totalOpen() }} open contracts and the server sent the first\r\n                page only — there may be more to price than is listed here.\r\n              </span>\r\n            }\r\n          </p>\r\n        </div>\r\n\r\n        <cms-pager\r\n          [page]=\"currentPage()\"\r\n          [totalPages]=\"totalPages()\"\r\n          position=\"bottom\"\r\n          (goTo)=\"onPage($event)\"\r\n        />\r\n      </footer>\r\n  </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep"
				]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: PricingPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pricing-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FilterBuilderComponent,
				FilterSelectComponent,
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				SearchShortcutDirective,
				GridExportComponent,
				GridToolbarComponent,
				NoticesPanelComponent,
				PagerComponent,
				RefreshButtonComponent,
				PageHeaderComponent
			],
			template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    title=\"Pricing\"\r\n    description=\"Open contracts with quantity still to price, most outstanding first.\"\r\n  >\r\n    <!--\r\n      🔴 A LINK in the header actions, not a fifth module in the shell nav.\r\n      Approving price sequences is something you do having read this queue, not a separate place in\r\n      the application — and the nav is the four modules of docs/02 §1.1, which this is not one of.\r\n    -->\r\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /pricing/approvals escapes. -->\r\n    <a\r\n      cmsPageHeaderActions\r\n      [attr.href]=\"approvalsHref()\"\r\n      (click)=\"followApprovals($event)\"\r\n      class=\"scoular-btn scoular-btn-secondary\"\r\n    >\r\n      Pricing approvals\r\n    </a>\r\n  </cms-page-header>\r\n\r\n  <!--\r\n    ⚠ **This block used to say price entry was impossible from this application**, citing two\r\n    blockers: that `prices` is not writable on `upsertContract`, and that the API published no pricing\r\n    route. The first is still true and is why a contract cannot be created *with* its prices. The\r\n    second stopped being true when `PricingEndpoints` shipped, and nothing re-pointed the sentence —\r\n    so this queue told users to go to the green screen while the editor it links to was live.\r\n\r\n    The rule that missed it is the one this repository keeps re-learning: a statement on screen is not\r\n    re-checked by the change that falsifies it unless something asserts it. There is a test for this\r\n    wording now.\r\n  -->\r\n  <!--\r\n    Standing notices, in the shared collapsible panel — the same one the workspace and the approval\r\n    queue use (JFrisbie, 2026-09-14). This screen opened with a capability warning, a simulated-data\r\n    banner and one row per server warning, ahead of the queue itself.\r\n  -->\r\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Where pricing is done</div>\r\n      <div class=\"scoular-alert-description\">\r\n        Opening a row shows that contract's price sequences, where they can be added, changed and\r\n        removed. Approving them is on Pricing approvals, linked above. A contract cannot be created\r\n        with its prices already on it — CTRM does not accept them on a contract write — so prices are\r\n        always entered after the contract exists.\r\n      </div>\r\n    </div>\r\n\r\n    @if (isSimulated()) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Simulated data</div>\r\n        <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\r\n      </div>\r\n    }\r\n\r\n    @for (warning of warnings(); track warning) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n      </div>\r\n    }\r\n  </cms-notices-panel>\r\n\r\n  <!--\r\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto` — the same\r\n    order and the same split as the workspace grid and the approvals queue, so the controls do not\r\n    move between screens (JFrisbie, 2026-09-10).\r\n  -->\r\n  <!--\r\n    🔴 **The width goes on the LABEL, never on the field.** `.scoular-form-input` is `@apply w-full`\r\n    and the design system compiles unlayered, so a `w-32` on the input silently loses to it and the\r\n    field fills its wrapper — every filter here measured **193px** regardless of its class, which is\r\n    what pushed the refresh/pager block onto a second line at 1280px. Seventh instance of this trap;\r\n    the remedy is to put the declaration on the wrapper, which has no design-system class to fight.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <cms-grid-toolbar>\r\n    <!--\r\n      One search box, replacing four per-field boxes plus a server-side search (JFrisbie,\r\n      2026-09-10).\r\n\r\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so\r\n      Customer, Commodity, Trader and Price type are all still reachable, along with the four\r\n      columns the old boxes could not narrow on.\r\n\r\n      ⚠ **Applied CLIENT-SIDE and no longer sent as a request parameter.** The server matches\r\n      three fields where this box matches all eight, so sending it too would narrow the fetched\r\n      set by a different rule than the one on screen. It costs nothing: the API fetches the whole\r\n      status set for the trade unit either way — `ContractListProjector` filters in process —\r\n      which is also why this screen already asks for the largest page it can.\r\n\r\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\r\n      move as a user goes between the two screens.\r\n    -->\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        autocomplete=\"off\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"searchTerm()\"\r\n        (input)=\"onSearch($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!--\r\n      Saved views and the rule builder, the same pair the workspace and the approvals queue carry.\r\n      Its OWN scope: a view from another grid would carry rules against columns this one does not\r\n      render and match nothing, which here reads as \"nothing to price\".\r\n\r\n      The width is on the wrapper, never the control - .scoular-form-input is @apply w-full and the\r\n      design system compiles unlayered, so a w-* on the control itself would lose.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\r\n      (click)=\"builder.beginAdd()\"\r\n    >\r\n      + Add filter\r\n    </button>\r\n\r\n    <!--\r\n      Clear sort, hidden until the queue is sorted some other way -- see the approval queue's own\r\n      note. This screen arrives largest-outstanding-first, so that ordering is the screen's doing\r\n      rather than the user's, and returning to it is what \"clear\" has to mean here.\r\n    -->\r\n    <cms-clear-sort-button\r\n      [sorts]=\"sorts()\"\r\n      [defaultSorts]=\"defaultSorts\"\r\n      (clear)=\"onSortChange($event)\"\r\n    />\r\n\r\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\r\n      <!--\r\n        Export, the same shared control the workspace and the approval queue carry. Both scopes are\r\n        cheap here - this screen fetches one large page and narrows in the browser - and the choice\r\n        is still offered, because \"what I am looking at\" and \"everything the filter matched\" are\r\n        different files on a paged grid. See `cms-grid-export`.\r\n      -->\r\n      <cms-grid-export\r\n        [columns]=\"columns\"\r\n        [pageRows]=\"rows()\"\r\n        [totalCount]=\"queue().length\"\r\n        [allRows]=\"exportAllRows\"\r\n        [filename]=\"exportFilename\"\r\n        [disabled]=\"!hasTradeUnit() || queue().length === 0\"\r\n        (failed)=\"exportError.set($event)\"\r\n      />\r\n\r\n      <cms-refresh-button\r\n        label=\"Refresh the unpriced queue\"\r\n        [busy]=\"isRefreshing()\"\r\n        [disabled]=\"!hasTradeUnit()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <cms-pager\r\n        [page]=\"currentPage()\"\r\n        [totalPages]=\"totalPages()\"\r\n        position=\"top\"\r\n        (goTo)=\"onPage($event)\"\r\n      />\r\n    </div>\r\n  </cms-grid-toolbar>\r\n\r\n  <!--\r\n    Chips and the rule editor. Renders nothing when there are no rules and the editor is closed, so\r\n    it leaves no empty band above the queue. Its own add button is suppressed because the toolbar\r\n    carries one - one owner for the editor state.\r\n  -->\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onRulesChange($event)\"\r\n  />\r\n\r\n  <!--\r\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\r\n    failed export is the outcome of something the user just did.\r\n  -->\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\r\n\r\n    This screen used to render a `scoular-card` above the container and hide the container behind\r\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\r\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\r\n    read as a notice about the data rather than as the absence of any.\r\n\r\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\r\n    unit the request is certain to 422, which is why the screen never issues one.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    [empty]=\"!hasTradeUnit() || queue().length === 0\"\r\n    [emptyMessage]=\"emptyMessage()\"\r\n      loadingLabel=\"Loading unpriced contracts\"\r\n      (retry)=\"retry()\"\r\n    >\r\n      <!--\r\n        ⚠ **`striped` is safe here because this queue declares no `rowTone`** — the same condition the\r\n        approvals queue records. A stripe and a semantic tint are both a background on the `<tr>`, and\r\n        together the tint stops meaning anything. The grid enforces the precedence rather than\r\n        trusting this binding, but adding a tone to this queue later would make the stripe the wrong\r\n        call rather than merely a redundant one.\r\n      -->\r\n      <cms-data-grid\r\n        [rows]=\"rows()\"\r\n        [columns]=\"columns\"\r\n        label=\"Contracts with quantity to price\"\r\n        [striped]=\"true\"\r\n        [sorts]=\"sorts()\"\r\n        [trackBy]=\"trackByContract\"\r\n        [focusKey]=\"focusKey()\"\r\n        (sortChange)=\"onSortChange($event)\"\r\n        (rowActivate)=\"onRowActivate($event)\"\r\n        (pageStep)=\"onPageStep($event)\"\r\n      />\r\n\r\n      <!--\r\n        The footer, matching the workspace grid: record count left, pager right.\r\n\r\n        🔴 The count is over the QUEUE, not over what the server sent — `1–50 of 87` means 87\r\n        contracts need pricing, which is what the screen is about. The second line keeps the\r\n        client-side filter honest: it names how many open contracts were read to find them, and warns\r\n        when the server had more pages than it sent, because the filter cannot see past those.\r\n      -->\r\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\r\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <p>{{ rangeLabel() }}</p>\r\n          <p class=\"cws:mt-0.5 cws:text-xs\">\r\n            Found in {{ fetched().length }} open contracts read.\r\n            @if (moreThanOnePage()) {\r\n              <span class=\"cws:text-amber-700 cws:dark:text-amber-400\">\r\n                This trade unit has {{ totalOpen() }} open contracts and the server sent the first\r\n                page only — there may be more to price than is listed here.\r\n              </span>\r\n            }\r\n          </p>\r\n        </div>\r\n\r\n        <cms-pager\r\n          [page]=\"currentPage()\"\r\n          [totalPages]=\"totalPages()\"\r\n          position=\"bottom\"\r\n          (goTo)=\"onPage($event)\"\r\n        />\r\n      </footer>\r\n  </cms-async-container>\r\n</section>\r\n"
		}]
	}]
});
function emptyPage(query) {
	return {
		rows: [],
		totalCount: 0,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: 1,
		dataOrigin: "Simulated",
		filteredInProcess: false,
		warnings: []
	};
}
function formatPrice$1(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", {
		minimumFractionDigits: 4,
		maximumFractionDigits: 5
	});
}
function formatAmount$1(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
}
const PRICE_SEQUENCE_COLUMNS = [
	{
		key: "priceSequence",
		header: "Seq",
		format: (row) => String(row.priceSequence),
		sortValue: (row) => row.priceSequence
	},
	{
		key: "pricedQuantity",
		header: "Priced qty",
		format: (row) => formatAmount$1(row.pricedQuantity),
		sortValue: (row) => row.pricedQuantity
	},
	{
		key: "openQuantity",
		header: "Open qty",
		format: (row) => formatAmount$1(row.openQuantity),
		sortValue: (row) => row.openQuantity
	},
	{
		key: "appliedQuantity",
		header: "Applied qty",
		format: (row) => formatAmount$1(row.appliedQuantity),
		sortValue: (row) => row.appliedQuantity
	},
	{
		key: "unsettledQuantity",
		header: "Unsettled qty",
		format: (row) => formatAmount$1(row.unsettledQuantity),
		sortValue: (row) => row.unsettledQuantity
	},
	{
		key: "settledQuantity",
		header: "Settled qty",
		format: (row) => formatAmount$1(row.settledQuantity),
		sortValue: (row) => row.settledQuantity
	},
	{
		key: "pricedLoads",
		header: "Priced loads",
		format: (row) => String(row.pricedLoads),
		sortValue: (row) => row.pricedLoads
	},
	{
		key: "appliedLoads",
		header: "Applied loads",
		format: (row) => String(row.appliedLoads),
		sortValue: (row) => row.appliedLoads
	},
	{
		key: "settledLoads",
		header: "Settled loads",
		format: (row) => String(row.settledLoads),
		sortValue: (row) => row.settledLoads
	},
	{
		key: "price",
		header: "Flat price",
		format: (row) => formatPrice$1(row.price),
		sortValue: (row) => row.price
	},
	{
		key: "basisPrice",
		header: "Basis",
		format: (row) => formatPrice$1(row.basisPrice),
		sortValue: (row) => row.basisPrice
	},
	{
		key: "hedgePrice",
		header: "Futures",
		format: (row) => formatPrice$1(row.hedgePrice),
		sortValue: (row) => row.hedgePrice
	},
	{
		key: "hedgeMarketCode",
		header: "Market",
		format: (row) => row.hedgeMarketCode ? row.hedgeMarketCodeDescription ? `${row.hedgeMarketCode} — ${row.hedgeMarketCodeDescription}` : row.hedgeMarketCode : ""
	},
	{
		key: "hedgeMarketMonth",
		header: "Month",
		format: (row) => row.hedgeMarketMonth ?? ""
	},
	{
		key: "priceDate",
		header: "Price date",
		format: (row) => formatShortDate(row.priceDate),
		sortValue: (row) => row.priceDate ?? ""
	},
	{
		key: "traderInitials",
		header: "Trader",
		format: (row) => row.traderInitials ?? ""
	},
	{
		key: "approval",
		header: "Approval",
		format: (row) => row.isApproved ? row.approverInitials ? `Approved — ${row.approverInitials}` : "Approved" : "Pending",
		sortValue: (row) => row.isApproved ? 1 : 0
	},
	{
		key: "remark",
		header: "Remark",
		format: (row) => row.remark ?? ""
	}
];
var PricingDetailPageComponent = class PricingDetailPageComponent {
	source = inject(PRICING_SOURCE);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	returnTo = this.route.snapshot.queryParamMap.get("returnTo");
	returnParams = computed(() => Object.fromEntries(new URLSearchParams(this.returnTo ?? "")), ...ngDevMode ? [{ debugName: "returnParams" }] : /* istanbul ignore next */ []);
	origin = computed(() => recordOrigin(this.originKey(), "pricing"), ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	originKey = computed(() => recordOriginKey(this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM), "pricing"), ...ngDevMode ? [{ debugName: "originKey" }] : /* istanbul ignore next */ []);
	originIntent = computed(() => ({
		kind: "origin",
		origin: this.originKey(),
		params: this.returnParams()
	}), ...ngDevMode ? [{ debugName: "originIntent" }] : /* istanbul ignore next */ []);
	recordIntent = computed(() => ({
		kind: "contract",
		contractNumber: this.contractNumber(),
		params: this.recordLinkParams()
	}), ...ngDevMode ? [{ debugName: "recordIntent" }] : /* istanbul ignore next */ []);
	recordHref = computed(() => this.hostContext.hrefFor(this.recordIntent()), ...ngDevMode ? [{ debugName: "recordHref" }] : /* istanbul ignore next */ []);
	follow(event, intent) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(intent);
	}
	followRecord(event) {
		this.follow(event, this.recordIntent());
	}
	crumbs = computed(() => {
		const intent = this.originIntent();
		return [{
			label: this.origin().label,
			path: this.origin().path,
			link: {
				href: this.hostContext.hrefFor(intent),
				follow: (event) => this.follow(event, intent)
			}
		}];
	}, ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	tradeUnitLabel = injectTradeUnitLabel();
	recordLinkParams = computed(() => ({
		[RECORD_ORIGIN_PARAM]: "pricing",
		...this.returnTo === null ? {} : { returnTo: this.returnTo }
	}), ...ngDevMode ? [{ debugName: "recordLinkParams" }] : /* istanbul ignore next */ []);
	onEscape() {
		if (this.draft() !== null) {
			this.cancelEdit();
			return;
		}
		this.hostContext.navigate(this.originIntent());
	}
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	columns = PRICE_SEQUENCE_COLUMNS;
	sorts = signal([], ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	reload = signal(0, ...ngDevMode ? [{ debugName: "reload" }] : /* istanbul ignore next */ []);
	loaded = toSignal(toObservable(computed(() => ({
		contract: this.contractNumber(),
		nonce: this.reload()
	}))).pipe(switchMap(({ contract }) => this.source.contractPrices(contract))), { initialValue: remoteLoading() });
	state = computed(() => this.loaded(), ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	afterWrite = signal(null, ...ngDevMode ? [{ debugName: "afterWrite" }] : /* istanbul ignore next */ []);
	unverified = signal(null, ...ngDevMode ? [{ debugName: "unverified" }] : /* istanbul ignore next */ []);
	writeError = signal(null, ...ngDevMode ? [{ debugName: "writeError" }] : /* istanbul ignore next */ []);
	writeFormErrors = signal([], ...ngDevMode ? [{ debugName: "writeFormErrors" }] : /* istanbul ignore next */ []);
	deleteNotApplied = signal(null, ...ngDevMode ? [{ debugName: "deleteNotApplied" }] : /* istanbul ignore next */ []);
	lastAcknowledgement = signal(null, ...ngDevMode ? [{ debugName: "lastAcknowledgement" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	canEditPricing = computed(() => this.permissions.canEditPricing(), ...ngDevMode ? [{ debugName: "canEditPricing" }] : /* istanbul ignore next */ []);
	rowActions = computed(() => {
		if (!this.canEditPricing()) return [];
		return [{
			label: "Edit",
			tone: "outline",
			run: (row) => this.startEdit(row),
			disabled: () => this.busy() ? "A pricing write is in flight" : false
		}, {
			label: "Remove",
			tone: "secondary",
			run: (row) => this.askDelete(row),
			disabled: () => this.busy() ? "A pricing write is in flight" : false
		}];
	}, ...ngDevMode ? [{ debugName: "rowActions" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const written = this.afterWrite();
		if (written !== null) return this.sortRows(written);
		const state = this.state();
		return state.status === "loaded" ? this.sortRows(state.value.prices) : [];
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	sortRows(rows) {
		const chain = this.sorts();
		return chain.length === 0 ? rows : [...rows].sort((left, right) => compareBySorts(this.columns, chain, left, right));
	}
	draft = signal(null, ...ngDevMode ? [{ debugName: "draft" }] : /* istanbul ignore next */ []);
	draftFlatPrice = computed(() => {
		const draft = this.draft();
		return draft === null ? 0 : flatPrice({
			basisPrice: numberOrNull(draft.basisPrice),
			adjustments: draft.adjustments,
			hedgePrice: numberOrNull(draft.hedgePrice)
		});
	}, ...ngDevMode ? [{ debugName: "draftFlatPrice" }] : /* istanbul ignore next */ []);
	storedPriceDisagrees = computed(() => {
		const draft = this.draft();
		if (draft === null || draft.isNew) return false;
		const stored = this.rows().find((row) => row.priceSequence === draft.priceSequence);
		return stored !== void 0 && !flatPriceAgrees(this.draftFlatPrice(), stored.price);
	}, ...ngDevMode ? [{ debugName: "storedPriceDisagrees" }] : /* istanbul ignore next */ []);
	startCreate() {
		this.clearMessages();
		this.draft.set({
			priceSequence: 0,
			isNew: true,
			pricedQuantity: "",
			pricedLoads: "",
			hedgePrice: "",
			basisPrice: "",
			adjustments: 0,
			hedgeMarketCode: "",
			hedgeMarketMonthCode: "",
			priceDate: "",
			description: "",
			remark: "",
			printFlag: true
		});
	}
	startEdit(row) {
		this.clearMessages();
		this.draft.set({
			priceSequence: row.priceSequence,
			isNew: false,
			pricedQuantity: String(row.pricedQuantity),
			pricedLoads: String(row.pricedLoads),
			hedgePrice: String(row.hedgePrice),
			basisPrice: String(row.basisPrice),
			adjustments: row.adjustments,
			hedgeMarketCode: row.hedgeMarketCode ?? "",
			hedgeMarketMonthCode: row.hedgeMarketMonth ?? "",
			priceDate: row.priceDate ?? "",
			description: row.priceDescription ?? "",
			remark: row.remark ?? "",
			printFlag: (row.printFlag ?? "Y").toUpperCase() !== "N"
		});
	}
	cancelEdit() {
		this.draft.set(null);
	}
	patch(key, value) {
		const draft = this.draft();
		if (draft !== null) this.draft.set({
			...draft,
			[key]: value
		});
	}
	patchText(key, raw) {
		this.patch(key, raw);
	}
	canSave = computed(() => {
		const draft = this.draft();
		const quantity = draft === null ? null : numberOrNull(draft.pricedQuantity);
		return quantity !== null && quantity > 0;
	}, ...ngDevMode ? [{ debugName: "canSave" }] : /* istanbul ignore next */ []);
	save() {
		const draft = this.draft();
		if (draft === null || !this.canSave() || this.busy()) return;
		const edit = {
			priceSequence: draft.isNew ? 0 : draft.priceSequence,
			pricedQuantity: numberOrNull(draft.pricedQuantity),
			pricedLoads: numberOrNull(draft.pricedLoads),
			hedgePrice: numberOrNull(draft.hedgePrice),
			basisPrice: numberOrNull(draft.basisPrice),
			hedgeMarketCode: draft.hedgeMarketCode || null,
			hedgeMarketMonthCode: draft.hedgeMarketMonthCode || null,
			priceDate: draft.priceDate || null,
			description: draft.description || null,
			remark: draft.remark || null,
			printFlag: draft.printFlag ? "Y" : "N"
		};
		this.run(this.source.save(this.contractNumber(), [edit]), () => this.draft.set(null));
	}
	confirm = injectConfirm();
	askDelete(row) {
		if (this.busy()) return;
		this.clearMessages();
		this.confirm({
			title: `Remove price sequence ${row.priceSequence}?`,
			message: "This removes the sequence from CTRM. The list will be re-read afterwards, because a pricing delete cannot report its own outcome.",
			confirmLabel: "Remove sequence",
			cancelLabel: "Keep it",
			destructive: true
		}).subscribe((confirmed) => {
			if (confirmed) this.removeSequence(row);
		});
	}
	removeSequence(row) {
		if (this.busy()) return;
		const removed = row.priceSequence;
		this.run(this.source.remove(this.contractNumber(), removed), () => void 0, (written) => written.verified && written.prices.some((price) => price.priceSequence === removed) ? `CTRM accepted the request, but price sequence ${removed} is still listed when the prices are read back, so it was not removed. Refresh to check, then try again.` : null);
	}
	run(write, onAccepted, notApplied = () => null) {
		this.busy.set(true);
		this.clearMessages();
		write.subscribe((result) => {
			if (result.status === "loading") return;
			this.busy.set(false);
			if (result.status !== "loaded") {
				this.writeError.set(result.status === "error" ? result.error.message : "That change did not complete.");
				this.writeFormErrors.set(result.status === "error" ? result.error.formErrors ?? [] : []);
				return;
			}
			onAccepted();
			this.afterWrite.set(result.value.prices);
			const reason = notApplied(result.value);
			if (reason !== null) {
				this.deleteNotApplied.set(reason);
				return;
			}
			this.lastAcknowledgement.set(result.value.acknowledgement);
			if (!result.value.verified) this.unverified.set("CTRM accepted the change but we could not read the prices back, so the list below may be out of date. Refresh to confirm.");
		});
	}
	refresh() {
		this.clearMessages();
		this.afterWrite.set(null);
		this.reload.update((value) => value + 1);
	}
	clearMessages() {
		this.writeError.set(null);
		this.writeFormErrors.set([]);
		this.unverified.set(null);
		this.deleteNotApplied.set(null);
		this.lastAcknowledgement.set(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: PricingDetailPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: PricingDetailPageComponent,
		isStandalone: true,
		selector: "cms-pricing-detail-page",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: { "document:keydown.escape": "onEscape()" } },
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    [title]=\"'Price sequences — ' + contractNumber()\"\r\n    description=\"Flat price is basis plus adjustments plus futures. CTRM computes the stored price itself.\"\r\n  >\r\n    <!--\r\n      🔴 The shared trail, replacing a lookalike that was not a breadcrumb.\r\n\r\n      This was an anchor, a `<span>/</span>` and a second `<span>` — visually a trail, and to a screen\r\n      reader three unrelated pieces of text: no list, no `aria-current`, and a `/` separator where the\r\n      other two detail screens use `&rsaquo;`. So the one control a user meets on every detail screen\r\n      changed shape depending which screen they were on.\r\n\r\n      `returnParams()` carries the queue's packed state, so the crumb returns the user to the row they\r\n      opened rather than to a reset queue — the same journey the approvals review screen keeps.\r\n    -->\r\n    <cms-breadcrumb\r\n      cmsPageHeaderBreadcrumb\r\n      [crumbs]=\"crumbs()\"\r\n      [current]=\"contractNumber()\"\r\n      [context]=\"tradeUnitLabel()\"\r\n      [queryParams]=\"returnParams()\"\r\n    />\r\n\r\n    <!--\r\n      The contract behind these sequences. Carries `from=pricing` so the record's own breadcrumb comes\r\n      back through this screen rather than dropping the user on the workspace.\r\n    -->\r\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\r\n    <a\r\n      cmsPageHeaderActions\r\n      [attr.href]=\"recordHref()\"\r\n      (click)=\"followRecord($event)\"\r\n      class=\"scoular-btn scoular-btn-secondary\"\r\n    >\r\n      View full record\r\n    </a>\r\n\r\n    <!-- The shared control, replacing a hand-rolled text button. See the pricing approvals note. -->\r\n    <cms-refresh-button\r\n      cmsPageHeaderActions\r\n      label=\"Refresh price sequences\"\r\n      [busy]=\"busy()\"\r\n      (refresh)=\"refresh()\"\r\n    />\r\n    @if (canEditPricing()) {\r\n      <button\r\n        cmsPageHeaderActions\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n        [disabled]=\"busy() || draft() !== null\"\r\n        (click)=\"startCreate()\"\r\n      >\r\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\r\n        Add price sequence\r\n      </button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  <!--\r\n    🔴 The one sentence standing in for three absent controls (F4.3a, extending #155).\r\n\r\n    Add, Edit and Remove are hidden rather than disabled: this screen shows a handful of\r\n    sequences, so disabling would put two dead buttons on every row plus one in the header, each\r\n    promising an action the account cannot take. One statement is more useful than five refusals.\r\n\r\n    ⚠ This screen has no `cms-notices-panel` and deliberately does not gain one for this. A panel\r\n    is a disclosure over several standing conditions; introducing one to hold a single line would\r\n    hide that line behind a collapsed summary, which is the opposite of what it is for.\r\n  -->\r\n  @if (!canEditPricing()) {\r\n    <p role=\"status\" class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      This account can view price sequences but not change them. Pricing needs the\r\n      <strong>Admin</strong> role on this application.\r\n    </p>\r\n  }\r\n\r\n  <!--\r\n    🔴 `role=\"alert\"`, and deliberately NOT the notices panel (F2.4, #373).\r\n\r\n    This is an EVENT — the user pressed something and it was refused — not a standing statement about\r\n    the record. The notices panel is for the latter, and putting an outcome there would make it\r\n    indistinguishable from a condition that was already true before they acted.\r\n\r\n    `formErrors` are rendered as a LIST inside the same alert rather than as a second banner: they are\r\n    reasons for the failure the title already names, and a second box would read as a second failure.\r\n  -->\r\n  @if (writeError(); as message) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-title\">That change was not saved</div>\r\n      <div class=\"scoular-alert-description\">\r\n        {{ message }}\r\n\r\n        @if (writeFormErrors().length > 0) {\r\n          <ul class=\"cws:mt-2 cws:list-disc cws:space-y-1 cws:pl-5\">\r\n            @for (reason of writeFormErrors(); track reason) {\r\n              <li>{{ reason }}</li>\r\n            }\r\n          </ul>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  @if (unverified(); as message) {\r\n    <!--\r\n      🔴 Accepted, state unknown — deliberately NOT an error. By this point the write has happened, and\r\n      telling a user their save failed when it did not is how the same price gets entered twice.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Saved, but not confirmed</div>\r\n      <div class=\"scoular-alert-description\">{{ message }}</div>\r\n    </div>\r\n  }\r\n\r\n  @if (deleteNotApplied(); as message) {\r\n    <!--\r\n      🔴 #156: a delete answered 202 and the re-read still lists the row. Its own title, because it is\r\n      neither the success CTRM's acknowledgement claims nor a refusal: the request was accepted and\r\n      the row is still there. `role=\"alert\"` because it is the outcome of what the user just pressed.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n      <div class=\"scoular-alert-title\">The delete did not take effect</div>\r\n      <div class=\"scoular-alert-description\">{{ message }}</div>\r\n    </div>\r\n  }\r\n\r\n  @if (lastAcknowledgement(); as message) {\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n      <div class=\"scoular-alert-description\">CTRM said: {{ message }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    The editor sits ABOVE the grid while open, so the grid below is the \"before\" the user is changing\r\n    and stays visible as context.\r\n  -->\r\n  @if (draft(); as editing) {\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        {{ editing.isNew ? 'New price sequence' : 'Price sequence ' + editing.priceSequence }}\r\n      </h3>\r\n\r\n      @if (editing.isNew) {\r\n        <!--\r\n          ⚠ Stated rather than implied, and no number is shown. An add sends sequence 0 and CTRM\r\n          assigns the number on save (CQ00132, #581), so any figure here would be a guess. The grid\r\n          shows the number CTRM gave it once the save is read back.\r\n        -->\r\n        <p class=\"cws:mb-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          CTRM assigns the sequence number on save.\r\n        </p>\r\n      }\r\n\r\n      <div class=\"cws:grid cws:grid-cols-1 cws:gap-4 cws:sm:grid-cols-2 cws:2xl:grid-cols-4\">\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Priced quantity *</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"decimal\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.pricedQuantity ?? ''\"\r\n            (input)=\"patchText('pricedQuantity', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Loads</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"numeric\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.pricedLoads ?? ''\"\r\n            (input)=\"patchText('pricedLoads', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Futures price</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"decimal\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.hedgePrice ?? ''\"\r\n            (input)=\"patchText('hedgePrice', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Basis</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"decimal\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.basisPrice ?? ''\"\r\n            (input)=\"patchText('basisPrice', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market code</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.hedgeMarketCode\"\r\n            (input)=\"patch('hedgeMarketCode', $any($event.target).value)\"\r\n          />\r\n          <!--\r\n            🔴 **Still typed, and that is a decision rather than unfinished work — see the class\r\n            remarks.** These two fields are the *price sequence's* hedge market and month (`dsPrc`),\r\n            which is a different CTRM record from the contract header's four market fields (`ConDS`)\r\n            and is written by a different program. The cascade the record screen runs is read from\r\n            `WNR051E`, which validates the **contract** write; applying it here would assume one\r\n            program's rules govern another's record, which is Known Issue 34 exactly.\r\n\r\n            ⚠ And the lookup is not available on this screen anyway: filtering a month list needs the\r\n            location and commodity, and the pricing API's response carries neither. Adding it needs\r\n            `ContractPrices` to carry them, which is a backend change.\r\n\r\n            The note the user sees no longer cites an issue number — it says what is true of the\r\n            field.\r\n          -->\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            The hedge market and month for this sequence, typed as CTRM stores them.\r\n          </span>\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market month</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.hedgeMarketMonthCode\"\r\n            (input)=\"patch('hedgeMarketMonthCode', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          🔴 The shared C3 control, not a native date input.\r\n\r\n          What stood here was `type=\"date\"`, whose picker is the BROWSER's -- unstyleable,\r\n          different in every engine, and showing a locale-driven display form. It also refuses the\r\n          MMDDYYYY and MMDDYY shapes BR-020 requires, so a trader typing at green-screen speed had\r\n          to stop and use a mouse on the one screen where speed matters most.\r\n\r\n          `[ngModel]`/`(ngModelChange)` rather than `[(ngModel)]` because the editor is patched\r\n          field by field through `patch`, which is what keeps the draft a single object.\r\n        -->\r\n        <cms-date-input\r\n          label=\"Price date\"\r\n          controlId=\"pricing-detail-price-date\"\r\n          [ngModel]=\"editing.priceDate\"\r\n          (ngModelChange)=\"patch('priceDate', $event)\"\r\n        />\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Description</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.description\"\r\n            (input)=\"patch('description', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm cws:sm:col-span-2\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Remark</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.remark\"\r\n            (input)=\"patch('remark', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2 cws:text-sm\">\r\n          <input\r\n            type=\"checkbox\"\r\n            [checked]=\"editing.printFlag\"\r\n            (change)=\"patch('printFlag', $any($event.target).checked)\"\r\n          />\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Print on confirmation</span>\r\n        </label>\r\n      </div>\r\n\r\n      <!--\r\n        BR-050, live. `role=\"status\"` so a screen reader hears the total change rather than having to\r\n        go looking for it after every keystroke.\r\n      -->\r\n      <div class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:border-t cws:border-slate-200 cws:pt-3 cws:dark:border-slate-700\">\r\n        <p class=\"cws:text-sm\" role=\"status\">\r\n          <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">Flat price (basis + adjustments + futures):</span>\r\n          <strong class=\"cws:ml-2 cws:text-slate-900 cws:dark:text-white\">{{ draftFlatPrice() | number: '1.4-5' }}</strong>\r\n          @if (editing.adjustments) {\r\n            <span class=\"cws:ml-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              includes adjustments {{ editing.adjustments | number: '1.4-5' }}\r\n            </span>\r\n          }\r\n        </p>\r\n\r\n        @if (storedPriceDisagrees()) {\r\n          <!--\r\n            ⚠ Surfaced rather than corrected. CTRM owns the stored price; showing our own sum in its\r\n            place would hide a real divergence in the system of record.\r\n          -->\r\n          <p class=\"cws:text-xs cws:text-scoular-yellow-dark cws:dark:text-scoular-yellow\">\r\n            This differs from the price CTRM has stored for this sequence.\r\n          </p>\r\n        }\r\n      </div>\r\n\r\n      <div class=\"cws:mt-4 cws:flex cws:items-center cws:gap-2\">\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n          [disabled]=\"!canSave() || busy()\"\r\n          (click)=\"save()\"\r\n        >\r\n          {{ busy() ? 'Saving…' : 'Save sequence' }}\r\n        </button>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">\r\n          Cancel\r\n        </button>\r\n\r\n        @if (!canSave()) {\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            A priced quantity greater than zero is required.\r\n          </span>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    The delete confirmation used to be rendered here, inline, as a `scoular-alert` carrying\r\n    `role=\"alertdialog\"`. It moved to the shared `cms-confirm-dialog` on 2026-09-16 — see\r\n    `askDelete()` — because it was a dialog in name only: the page behind it stayed operable, so the\r\n    one irreversible action on this screen could be scrolled past. The shared one traps focus, makes\r\n    the background inert and answers Escape.\r\n  -->\r\n\r\n  <!--\r\n    🔴 `(retry)` is bound, and it was not. The container renders its Retry button whenever the\r\n    load failed, so an unbound handler is a button that does nothing -- on the one screen where\r\n    the user has just been told the read failed. It calls the same reload the header Refresh\r\n    does, so retrying means exactly what refreshing means.\r\n\r\n    ⚠ The empty state goes through `[empty]`/`emptyMessage` rather than an `@if` INSIDE the\r\n    container. Hand-rolling it there bypassed the `[cmsEmptyAction]` slot and gave this screen\r\n    its own spacing, so two screens showing \"nothing here\" did not look alike.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"state()\"\r\n    [empty]=\"rows().length === 0\"\r\n    emptyMessage=\"This contract has no price sequences yet.\"\r\n    loadingLabel=\"Loading price sequences\"\r\n    (retry)=\"refresh()\"\r\n  >\r\n    @if (rows().length > 0) {\r\n      <!--\r\n        Striped for consistency with the two pricing queues, and tone-free like them. ⚠ This grid is\r\n        usually a handful of rows, where zebra earns less than it does on a long queue — it is here so\r\n        that the three pricing screens do not disagree about what a row looks like.\r\n      -->\r\n      <!--\r\n        🔴 Edit and Remove are grid row actions, not a second list beneath the grid.\r\n\r\n        This screen rendered every sequence TWICE -- once in the grid and again as a list item\r\n        carrying the two buttons -- so thirty sequences were sixty visual rows for thirty records,\r\n        and the second copy had to repeat the sequence number to say which row it belonged to. The\r\n        approval queue already had the right shape; this screen predates it.\r\n\r\n        The list also carried an \"approved\" marker, which the grid already has as a column -- so\r\n        removing the list loses nothing, and the state stays in the row it describes.\r\n      -->\r\n      <cms-data-grid\r\n        [rows]=\"rows()\"\r\n        [columns]=\"columns\"\r\n        label=\"Price sequences\"\r\n        [striped]=\"true\"\r\n        [sorts]=\"sorts()\"\r\n        [actions]=\"rowActions()\"\r\n        (sortChange)=\"sorts.set($event)\"\r\n      />\r\n\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: BreadcrumbComponent,
				selector: "cms-breadcrumb",
				inputs: [
					"crumbs",
					"current",
					"context",
					"queryParams"
				]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep"
				]
			},
			{
				kind: "component",
				type: DateInputComponent,
				selector: "cms-date-input",
				inputs: [
					"label",
					"controlId",
					"required",
					"readOnly",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "pipe",
				type: DecimalPipe,
				name: "number"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: PricingDetailPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pricing-detail-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				BreadcrumbComponent,
				DataGridComponent,
				DateInputComponent,
				DecimalPipe,
				FormsModule,
				PageHeaderComponent,
				RefreshButtonComponent
			],
			template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    [title]=\"'Price sequences — ' + contractNumber()\"\r\n    description=\"Flat price is basis plus adjustments plus futures. CTRM computes the stored price itself.\"\r\n  >\r\n    <!--\r\n      🔴 The shared trail, replacing a lookalike that was not a breadcrumb.\r\n\r\n      This was an anchor, a `<span>/</span>` and a second `<span>` — visually a trail, and to a screen\r\n      reader three unrelated pieces of text: no list, no `aria-current`, and a `/` separator where the\r\n      other two detail screens use `&rsaquo;`. So the one control a user meets on every detail screen\r\n      changed shape depending which screen they were on.\r\n\r\n      `returnParams()` carries the queue's packed state, so the crumb returns the user to the row they\r\n      opened rather than to a reset queue — the same journey the approvals review screen keeps.\r\n    -->\r\n    <cms-breadcrumb\r\n      cmsPageHeaderBreadcrumb\r\n      [crumbs]=\"crumbs()\"\r\n      [current]=\"contractNumber()\"\r\n      [context]=\"tradeUnitLabel()\"\r\n      [queryParams]=\"returnParams()\"\r\n    />\r\n\r\n    <!--\r\n      The contract behind these sequences. Carries `from=pricing` so the record's own breadcrumb comes\r\n      back through this screen rather than dropping the user on the workspace.\r\n    -->\r\n    <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\r\n    <a\r\n      cmsPageHeaderActions\r\n      [attr.href]=\"recordHref()\"\r\n      (click)=\"followRecord($event)\"\r\n      class=\"scoular-btn scoular-btn-secondary\"\r\n    >\r\n      View full record\r\n    </a>\r\n\r\n    <!-- The shared control, replacing a hand-rolled text button. See the pricing approvals note. -->\r\n    <cms-refresh-button\r\n      cmsPageHeaderActions\r\n      label=\"Refresh price sequences\"\r\n      [busy]=\"busy()\"\r\n      (refresh)=\"refresh()\"\r\n    />\r\n    @if (canEditPricing()) {\r\n      <button\r\n        cmsPageHeaderActions\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n        [disabled]=\"busy() || draft() !== null\"\r\n        (click)=\"startCreate()\"\r\n      >\r\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\r\n        Add price sequence\r\n      </button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  <!--\r\n    🔴 The one sentence standing in for three absent controls (F4.3a, extending #155).\r\n\r\n    Add, Edit and Remove are hidden rather than disabled: this screen shows a handful of\r\n    sequences, so disabling would put two dead buttons on every row plus one in the header, each\r\n    promising an action the account cannot take. One statement is more useful than five refusals.\r\n\r\n    ⚠ This screen has no `cms-notices-panel` and deliberately does not gain one for this. A panel\r\n    is a disclosure over several standing conditions; introducing one to hold a single line would\r\n    hide that line behind a collapsed summary, which is the opposite of what it is for.\r\n  -->\r\n  @if (!canEditPricing()) {\r\n    <p role=\"status\" class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      This account can view price sequences but not change them. Pricing needs the\r\n      <strong>Admin</strong> role on this application.\r\n    </p>\r\n  }\r\n\r\n  <!--\r\n    🔴 `role=\"alert\"`, and deliberately NOT the notices panel (F2.4, #373).\r\n\r\n    This is an EVENT — the user pressed something and it was refused — not a standing statement about\r\n    the record. The notices panel is for the latter, and putting an outcome there would make it\r\n    indistinguishable from a condition that was already true before they acted.\r\n\r\n    `formErrors` are rendered as a LIST inside the same alert rather than as a second banner: they are\r\n    reasons for the failure the title already names, and a second box would read as a second failure.\r\n  -->\r\n  @if (writeError(); as message) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-title\">That change was not saved</div>\r\n      <div class=\"scoular-alert-description\">\r\n        {{ message }}\r\n\r\n        @if (writeFormErrors().length > 0) {\r\n          <ul class=\"cws:mt-2 cws:list-disc cws:space-y-1 cws:pl-5\">\r\n            @for (reason of writeFormErrors(); track reason) {\r\n              <li>{{ reason }}</li>\r\n            }\r\n          </ul>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  @if (unverified(); as message) {\r\n    <!--\r\n      🔴 Accepted, state unknown — deliberately NOT an error. By this point the write has happened, and\r\n      telling a user their save failed when it did not is how the same price gets entered twice.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Saved, but not confirmed</div>\r\n      <div class=\"scoular-alert-description\">{{ message }}</div>\r\n    </div>\r\n  }\r\n\r\n  @if (deleteNotApplied(); as message) {\r\n    <!--\r\n      🔴 #156: a delete answered 202 and the re-read still lists the row. Its own title, because it is\r\n      neither the success CTRM's acknowledgement claims nor a refusal: the request was accepted and\r\n      the row is still there. `role=\"alert\"` because it is the outcome of what the user just pressed.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n      <div class=\"scoular-alert-title\">The delete did not take effect</div>\r\n      <div class=\"scoular-alert-description\">{{ message }}</div>\r\n    </div>\r\n  }\r\n\r\n  @if (lastAcknowledgement(); as message) {\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n      <div class=\"scoular-alert-description\">CTRM said: {{ message }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    The editor sits ABOVE the grid while open, so the grid below is the \"before\" the user is changing\r\n    and stays visible as context.\r\n  -->\r\n  @if (draft(); as editing) {\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        {{ editing.isNew ? 'New price sequence' : 'Price sequence ' + editing.priceSequence }}\r\n      </h3>\r\n\r\n      @if (editing.isNew) {\r\n        <!--\r\n          ⚠ Stated rather than implied, and no number is shown. An add sends sequence 0 and CTRM\r\n          assigns the number on save (CQ00132, #581), so any figure here would be a guess. The grid\r\n          shows the number CTRM gave it once the save is read back.\r\n        -->\r\n        <p class=\"cws:mb-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          CTRM assigns the sequence number on save.\r\n        </p>\r\n      }\r\n\r\n      <div class=\"cws:grid cws:grid-cols-1 cws:gap-4 cws:sm:grid-cols-2 cws:2xl:grid-cols-4\">\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Priced quantity *</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"decimal\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.pricedQuantity ?? ''\"\r\n            (input)=\"patchText('pricedQuantity', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Loads</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"numeric\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.pricedLoads ?? ''\"\r\n            (input)=\"patchText('pricedLoads', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Futures price</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"decimal\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.hedgePrice ?? ''\"\r\n            (input)=\"patchText('hedgePrice', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Basis</span>\r\n          <input\r\n            type=\"text\"\r\n            inputmode=\"decimal\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.basisPrice ?? ''\"\r\n            (input)=\"patchText('basisPrice', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market code</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.hedgeMarketCode\"\r\n            (input)=\"patch('hedgeMarketCode', $any($event.target).value)\"\r\n          />\r\n          <!--\r\n            🔴 **Still typed, and that is a decision rather than unfinished work — see the class\r\n            remarks.** These two fields are the *price sequence's* hedge market and month (`dsPrc`),\r\n            which is a different CTRM record from the contract header's four market fields (`ConDS`)\r\n            and is written by a different program. The cascade the record screen runs is read from\r\n            `WNR051E`, which validates the **contract** write; applying it here would assume one\r\n            program's rules govern another's record, which is Known Issue 34 exactly.\r\n\r\n            ⚠ And the lookup is not available on this screen anyway: filtering a month list needs the\r\n            location and commodity, and the pricing API's response carries neither. Adding it needs\r\n            `ContractPrices` to carry them, which is a backend change.\r\n\r\n            The note the user sees no longer cites an issue number — it says what is true of the\r\n            field.\r\n          -->\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            The hedge market and month for this sequence, typed as CTRM stores them.\r\n          </span>\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Market month</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.hedgeMarketMonthCode\"\r\n            (input)=\"patch('hedgeMarketMonthCode', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          🔴 The shared C3 control, not a native date input.\r\n\r\n          What stood here was `type=\"date\"`, whose picker is the BROWSER's -- unstyleable,\r\n          different in every engine, and showing a locale-driven display form. It also refuses the\r\n          MMDDYYYY and MMDDYY shapes BR-020 requires, so a trader typing at green-screen speed had\r\n          to stop and use a mouse on the one screen where speed matters most.\r\n\r\n          `[ngModel]`/`(ngModelChange)` rather than `[(ngModel)]` because the editor is patched\r\n          field by field through `patch`, which is what keeps the draft a single object.\r\n        -->\r\n        <cms-date-input\r\n          label=\"Price date\"\r\n          controlId=\"pricing-detail-price-date\"\r\n          [ngModel]=\"editing.priceDate\"\r\n          (ngModelChange)=\"patch('priceDate', $event)\"\r\n        />\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Description</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.description\"\r\n            (input)=\"patch('description', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm cws:sm:col-span-2\">\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Remark</span>\r\n          <input\r\n            type=\"text\"\r\n            class=\"scoular-form-input\"\r\n            [value]=\"editing.remark\"\r\n            (input)=\"patch('remark', $any($event.target).value)\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2 cws:text-sm\">\r\n          <input\r\n            type=\"checkbox\"\r\n            [checked]=\"editing.printFlag\"\r\n            (change)=\"patch('printFlag', $any($event.target).checked)\"\r\n          />\r\n          <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Print on confirmation</span>\r\n        </label>\r\n      </div>\r\n\r\n      <!--\r\n        BR-050, live. `role=\"status\"` so a screen reader hears the total change rather than having to\r\n        go looking for it after every keystroke.\r\n      -->\r\n      <div class=\"cws:mt-4 cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:border-t cws:border-slate-200 cws:pt-3 cws:dark:border-slate-700\">\r\n        <p class=\"cws:text-sm\" role=\"status\">\r\n          <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">Flat price (basis + adjustments + futures):</span>\r\n          <strong class=\"cws:ml-2 cws:text-slate-900 cws:dark:text-white\">{{ draftFlatPrice() | number: '1.4-5' }}</strong>\r\n          @if (editing.adjustments) {\r\n            <span class=\"cws:ml-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              includes adjustments {{ editing.adjustments | number: '1.4-5' }}\r\n            </span>\r\n          }\r\n        </p>\r\n\r\n        @if (storedPriceDisagrees()) {\r\n          <!--\r\n            ⚠ Surfaced rather than corrected. CTRM owns the stored price; showing our own sum in its\r\n            place would hide a real divergence in the system of record.\r\n          -->\r\n          <p class=\"cws:text-xs cws:text-scoular-yellow-dark cws:dark:text-scoular-yellow\">\r\n            This differs from the price CTRM has stored for this sequence.\r\n          </p>\r\n        }\r\n      </div>\r\n\r\n      <div class=\"cws:mt-4 cws:flex cws:items-center cws:gap-2\">\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n          [disabled]=\"!canSave() || busy()\"\r\n          (click)=\"save()\"\r\n        >\r\n          {{ busy() ? 'Saving…' : 'Save sequence' }}\r\n        </button>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">\r\n          Cancel\r\n        </button>\r\n\r\n        @if (!canSave()) {\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            A priced quantity greater than zero is required.\r\n          </span>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    The delete confirmation used to be rendered here, inline, as a `scoular-alert` carrying\r\n    `role=\"alertdialog\"`. It moved to the shared `cms-confirm-dialog` on 2026-09-16 — see\r\n    `askDelete()` — because it was a dialog in name only: the page behind it stayed operable, so the\r\n    one irreversible action on this screen could be scrolled past. The shared one traps focus, makes\r\n    the background inert and answers Escape.\r\n  -->\r\n\r\n  <!--\r\n    🔴 `(retry)` is bound, and it was not. The container renders its Retry button whenever the\r\n    load failed, so an unbound handler is a button that does nothing -- on the one screen where\r\n    the user has just been told the read failed. It calls the same reload the header Refresh\r\n    does, so retrying means exactly what refreshing means.\r\n\r\n    ⚠ The empty state goes through `[empty]`/`emptyMessage` rather than an `@if` INSIDE the\r\n    container. Hand-rolling it there bypassed the `[cmsEmptyAction]` slot and gave this screen\r\n    its own spacing, so two screens showing \"nothing here\" did not look alike.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"state()\"\r\n    [empty]=\"rows().length === 0\"\r\n    emptyMessage=\"This contract has no price sequences yet.\"\r\n    loadingLabel=\"Loading price sequences\"\r\n    (retry)=\"refresh()\"\r\n  >\r\n    @if (rows().length > 0) {\r\n      <!--\r\n        Striped for consistency with the two pricing queues, and tone-free like them. ⚠ This grid is\r\n        usually a handful of rows, where zebra earns less than it does on a long queue — it is here so\r\n        that the three pricing screens do not disagree about what a row looks like.\r\n      -->\r\n      <!--\r\n        🔴 Edit and Remove are grid row actions, not a second list beneath the grid.\r\n\r\n        This screen rendered every sequence TWICE -- once in the grid and again as a list item\r\n        carrying the two buttons -- so thirty sequences were sixty visual rows for thirty records,\r\n        and the second copy had to repeat the sequence number to say which row it belonged to. The\r\n        approval queue already had the right shape; this screen predates it.\r\n\r\n        The list also carried an \"approved\" marker, which the grid already has as a column -- so\r\n        removing the list loses nothing, and the state stays in the row it describes.\r\n      -->\r\n      <cms-data-grid\r\n        [rows]=\"rows()\"\r\n        [columns]=\"columns\"\r\n        label=\"Price sequences\"\r\n        [striped]=\"true\"\r\n        [sorts]=\"sorts()\"\r\n        [actions]=\"rowActions()\"\r\n        (sortChange)=\"sorts.set($event)\"\r\n      />\r\n\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n"
		}]
	}],
	propDecorators: {
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape"]
		}],
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}]
	}
});
function numberOrNull(raw) {
	const trimmed = raw.trim();
	if (trimmed === "") return null;
	const parsed = Number(trimmed);
	return Number.isFinite(parsed) ? parsed : null;
}
function formatPrice(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", {
		minimumFractionDigits: 4,
		maximumFractionDigits: 5
	});
}
function formatAmount(value) {
	return value === null || value === void 0 ? "" : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
}
const APPROVAL_QUEUE_COLUMNS = [
	{
		key: "contract",
		header: "Contract",
		format: (row) => row.contract
	},
	{
		key: "priceSequence",
		header: "Seq",
		format: (row) => String(row.priceSequence),
		sortValue: (row) => row.priceSequence
	},
	{
		key: "pricedQuantity",
		header: "Priced qty",
		format: (row) => formatAmount(row.pricedQuantity),
		sortValue: (row) => row.pricedQuantity
	},
	{
		key: "pricedLoads",
		header: "Loads",
		format: (row) => String(row.pricedLoads),
		sortValue: (row) => row.pricedLoads
	},
	{
		key: "price",
		header: "Flat price",
		format: (row) => formatPrice(row.price),
		sortValue: (row) => row.price
	},
	{
		key: "hedgePrice",
		header: "Futures",
		format: (row) => formatPrice(row.hedgePrice),
		sortValue: (row) => row.hedgePrice
	},
	{
		key: "hedgeMarketCode",
		header: "Market",
		format: (row) => row.hedgeMarketCode ?? ""
	},
	{
		key: "hedgeMarketMonth",
		header: "Month",
		format: (row) => row.hedgeMarketMonth ?? ""
	},
	{
		key: "priceDate",
		header: "Price date",
		format: (row) => formatShortDate(row.priceDate),
		sortValue: (row) => row.priceDate ?? ""
	},
	{
		key: "traderInitials",
		header: "Trader",
		format: (row) => row.traderInitials ?? ""
	},
	{
		key: "approverInitials",
		header: "Approver",
		format: (row) => row.approverInitials ?? ""
	},
	{
		key: "approvalTimestamp",
		header: "Approved",
		format: (row) => formatShortDate(row.approvalTimestamp),
		sortValue: (row) => row.approvalTimestamp ?? ""
	}
];
var PricingApprovalsPageComponent = class PricingApprovalsPageComponent {
	source = inject(PRICING_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	canApprove = computed(() => this.permissions.canApproveContracts(), ...ngDevMode ? [{ debugName: "canApprove" }] : /* istanbul ignore next */ []);
	columns = APPROVAL_QUEUE_COLUMNS;
	sorts = signal([], ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	search = signal("", ...ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []);
	emptyMessage = computed(() => this.hasScope() ? "Nothing is awaiting pricing approval here." : "Choose a trade unit in the top bar to load the approval queue.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	reload = signal(0, ...ngDevMode ? [{ debugName: "reload" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	message = signal(null, ...ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []);
	failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	query = computed(() => ({ location: this.tradeUnit.code() ?? void 0 }), ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	hasScope = computed(() => this.query().location !== void 0, ...ngDevMode ? [{ debugName: "hasScope" }] : /* istanbul ignore next */ []);
	loaded = toSignal(toObservable(computed(() => ({
		query: this.query(),
		nonce: this.reload()
	}))).pipe(switchMap(({ query }) => query.location === void 0 ? of(remoteLoading()) : this.source.unapproved(query))), { initialValue: remoteLoading() });
	state = computed(() => this.hasScope() ? this.loaded() : {
		status: "loaded",
		value: emptyPrices()
	}, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	mayBeTruncated = computed(() => {
		const state = this.state();
		return state.status === "loaded" && state.value.mayBeTruncated;
	}, ...ngDevMode ? [{ debugName: "mayBeTruncated" }] : /* istanbul ignore next */ []);
	truncationCeiling = computed(() => {
		const state = this.state();
		return state.status === "loaded" ? state.value.truncationCeiling : 0;
	}, ...ngDevMode ? [{ debugName: "truncationCeiling" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [...this.mayBeTruncated() ? ["CTRM may have sent fewer rows than exist"] : [], ...this.canApprove() ? [] : ["This account cannot approve pricing"]], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	queue = computed(() => {
		const state = this.state();
		if (state.status !== "loaded") return [];
		const all = state.value.prices;
		const term = this.search().trim();
		const group = this.filter();
		const kept = all.filter((row) => matchesGroup(row, this.columns, group) && (term === "" || matchesSearch(row, this.columns, term)));
		const chain = this.sorts();
		return chain.length === 0 ? kept : [...kept].sort((left, right) => compareBySorts(this.columns, chain, left, right));
	}, ...ngDevMode ? [{ debugName: "queue" }] : /* istanbul ignore next */ []);
	pageSize = DEFAULT_PAGE_SIZE;
	page = signal(1, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	totalPages = computed(() => Math.max(1, Math.ceil(this.queue().length / this.pageSize)), ...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	currentPage = computed(() => Math.min(Math.max(this.page(), 1), this.totalPages()), ...ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const start = (this.currentPage() - 1) * this.pageSize;
		return this.queue().slice(start, start + this.pageSize);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	onPage(page) {
		this.page.set(page);
	}
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportFilename = (scope) => {
		return `pricing-approvals-${this.tradeUnit.code() ?? "all"}-${scope === "page" ? `page-${this.currentPage()}` : "all"}`;
	};
	exportAllRows = () => Promise.resolve(this.queue());
	filter = signal(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	savedFilterScope = SAVED_FILTER_SCOPES.pricingApprovals;
	onRulesChange(group) {
		this.filter.set(group);
		this.page.set(1);
	}
	onSearch(term) {
		this.search.set(term);
		this.page.set(1);
	}
	onViewChange(view) {
		this.filter.set(view.group);
		this.sorts.set(view.sort);
		this.page.set(1);
	}
	selected = signal(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	keyOf(row) {
		return `${row.contract}|${row.priceSequence}`;
	}
	isSelected(row) {
		return this.selected().has(this.keyOf(row));
	}
	toggle(row) {
		const key = this.keyOf(row);
		const next = new Set(this.selected());
		if (!next.delete(key)) next.add(key);
		this.selected.set(next);
	}
	clearSelection() {
		this.selected.set(/* @__PURE__ */ new Set());
	}
	selectVisible() {
		this.selected.set(new Set(this.rows().map((row) => this.keyOf(row))));
	}
	selectedCount = computed(() => {
		const keys = this.selected();
		return this.rows().filter((row) => keys.has(this.keyOf(row))).length;
	}, ...ngDevMode ? [{ debugName: "selectedCount" }] : /* istanbul ignore next */ []);
	selectionByContract() {
		const keys = this.selected();
		const grouped = /* @__PURE__ */ new Map();
		for (const row of this.rows()) {
			if (!keys.has(this.keyOf(row))) continue;
			const existing = grouped.get(row.contract);
			if (existing) existing.push(row.priceSequence);
			else grouped.set(row.contract, [row.priceSequence]);
		}
		return grouped;
	}
	approveOne(row) {
		this.selected.set(/* @__PURE__ */ new Set([this.keyOf(row)]));
		this.approveSelected();
	}
	async approveSelected() {
		if (this.busy() || this.selectedCount() === 0) return;
		this.busy.set(true);
		this.message.set(null);
		this.failure.set(null);
		const grouped = this.selectionByContract();
		const approved = [];
		let failedContract = null;
		let failureReason = "";
		for (const [contract, sequences] of grouped) {
			const result = await firstLoadedValue(this.source.approve(contract, sequences));
			if (result.status !== "loaded") {
				failedContract = contract;
				failureReason = result.status === "error" ? result.error.message : "The approval did not complete.";
				break;
			}
			approved.push(`${contract} (${sequences.length})`);
		}
		this.busy.set(false);
		this.clearSelection();
		this.reload.update((value) => value + 1);
		if (approved.length > 0) this.message.set(`Approved: ${approved.join(", ")}.`);
		if (failedContract !== null) this.failure.set(`${contractCount(approved.length)} before ${failedContract} failed: ${failureReason} Approvals already made cannot be undone — re-check the queue before retrying.`);
	}
	refresh() {
		this.message.set(null);
		this.failure.set(null);
		this.clearSelection();
		this.reload.update((value) => value + 1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: PricingApprovalsPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: PricingApprovalsPageComponent,
		isStandalone: true,
		selector: "cms-pricing-approvals-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    title=\"Pricing approvals\"\r\n    description=\"Price sequences awaiting approval. Approval cannot be undone.\"\r\n  >\r\n    <!--\r\n      ⚠ **Refresh MOVED to the grid toolbar** (JFrisbie, 2026-09-17). It was the shared control\r\n      already, but it was the only one of the four grids putting it in the page header, and the\r\n      toolbar is now one standard set on every grid. Nothing is left in the header actions slot\r\n      here, so the slot itself is gone rather than left rendering an empty box.\r\n    -->\r\n  </cms-page-header>\r\n\r\n  <cms-grid-toolbar>\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-md\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"search()\"\r\n        (input)=\"onSearch($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!-- Saved views and the rule builder, under this grid own scope. Width on the wrapper, never\r\n         the control: .scoular-form-input is @apply w-full and the design system compiles unlayered. -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-outline cws:shrink-0\" (click)=\"builder.beginAdd()\">\r\n      + Add filter\r\n    </button>\r\n\r\n    <!--\r\n      🔴 **The Trader box and the Approver type dropdown stood here and are GONE** (JFrisbie,\r\n      2026-09-17). The toolbar is now one standard set on every grid — search, view, add filter,\r\n      clear sort, export, refresh, pager — and nothing else.\r\n\r\n      ⚠ **The Trader box was an entry path, not a narrowing.** It was the only way to load this queue\r\n      with no trade unit selected, because the route needs a trader OR a location. It now needs a\r\n      trade unit; the empty state says so. Both this and the approver type remain request parameters\r\n      the source still accepts, so either control is a template change away from returning.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"sorts.set($event)\" />\r\n\r\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\r\n      <!--\r\n        Export, the same shared control as the other three grids. Both scopes are cheap here — the\r\n        route has no paging at all, so the whole queue is in memory — and the choice is still offered,\r\n        because \"this page\" and \"everything matched\" are different files now that the grid pages.\r\n      -->\r\n      <cms-grid-export\r\n        [columns]=\"columns\"\r\n        [pageRows]=\"rows()\"\r\n        [totalCount]=\"queue().length\"\r\n        [allRows]=\"exportAllRows\"\r\n        [filename]=\"exportFilename\"\r\n        [disabled]=\"!hasScope() || queue().length === 0\"\r\n        (failed)=\"exportError.set($event)\"\r\n      />\r\n\r\n      <cms-refresh-button\r\n        label=\"Refresh pricing approvals\"\r\n        [busy]=\"busy()\"\r\n        [disabled]=\"!hasScope()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <cms-pager\r\n        [page]=\"currentPage()\"\r\n        [totalPages]=\"totalPages()\"\r\n        position=\"top\"\r\n        (goTo)=\"onPage($event)\"\r\n      />\r\n    </div>\r\n  </cms-grid-toolbar>\r\n\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onRulesChange($event)\"\r\n  />\r\n\r\n  <!--\r\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\r\n    failed export is the outcome of something the user just did.\r\n  -->\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    🔴 ONE presentation of the precondition, through the container, matching every other screen.\r\n\r\n    This was a tinted `scoular-alert-info` with a title, which read as a NOTICE about the data\r\n    rather than as the absence of any. CTRM refuses this route with neither a trader nor a location,\r\n    so the screen still issues no request -- only the way it says so has changed.\r\n  -->\r\n    @if (message(); as text) {\r\n      <div class=\"scoular-alert scoular-alert-success\" role=\"status\">\r\n        <div class=\"scoular-alert-description\">{{ text }}</div>\r\n      </div>\r\n    }\r\n\r\n    @if (failure(); as text) {\r\n      <!--\r\n        🔴 A partial failure, reported as one. Approval has no inverse, so a run that stopped part-way\r\n        has already committed everything before the failure — naming what succeeded is what stops the\r\n        user retrying the whole selection and being refused on the half that went through.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n        <div class=\"scoular-alert-title\">The approval run stopped part-way</div>\r\n        <div class=\"scoular-alert-description\">{{ text }}</div>\r\n      </div>\r\n    }\r\n\r\n    <!--\r\n      The standing notice, in the shared collapsible panel.\r\n\r\n      ⚠ **The success and failure messages above are deliberately NOT in it.** The panel is for\r\n      standing conditions — environment, data origin, capability gaps — and never for the outcome of\r\n      something the user just did. An approval run that stopped part-way has already committed half\r\n      its selection; behind a collapsed panel that is a message nobody reads.\r\n    -->\r\n    <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n      @if (mayBeTruncated()) {\r\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n          <div class=\"scoular-alert-title\">This queue may be incomplete</div>\r\n          <div class=\"scoular-alert-description\">\r\n            <!--\r\n              ⚠ The advice used to read \"narrow by trader\", and that box came off the toolbar on\r\n              2026-09-17 — so the sentence named a control the screen no longer has. A filter rule on\r\n              Trader narrows what is DISPLAYED and cannot make CTRM send more, which is the honest\r\n              thing to say rather than pointing at a workaround that no longer exists.\r\n            -->\r\n            CTRM returns at most {{ truncationCeiling() }} rows for this queue and does not say when\r\n            it has more, so rows may be missing before any filter is applied.\r\n          </div>\r\n        </div>\r\n      }\r\n      <!--\r\n        ⚠ Projected content AND a summary line, always both. `cms-notices-panel` gates the whole\r\n        panel on the summary count, so content added here without a matching summary is not\r\n        merely uncounted — it is not rendered at all.\r\n      -->\r\n      @if (!canApprove()) {\r\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n          <div class=\"scoular-alert-title\">Read-only for this account</div>\r\n          <div class=\"scoular-alert-description\">\r\n            You can see the unapproved queue but not commit an approval. Approving needs the\r\n            <strong>Admin</strong> role on this application.\r\n          </div>\r\n        </div>\r\n      }\r\n    </cms-notices-panel>\r\n\r\n    <!--\r\n      🔴 The whole decision toolbar, gated as one (F4.3a).\r\n\r\n      Selecting rows is only ever a prelude to approving them, so leaving the selection controls\r\n      behind a hidden Approve would be a gesture that collects rows and then has nowhere to send\r\n      them. The notices panel above carries the reason.\r\n    -->\r\n    @if (canApprove()) {\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n          [disabled]=\"selectedCount() === 0 || busy()\"\r\n          (click)=\"approveSelected()\"\r\n        >\r\n          {{ busy() ? 'Approving…' : 'Approve ' + selectedCount() + ' selected' }}\r\n        </button>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary\"\r\n          [disabled]=\"rows().length === 0 || busy()\"\r\n          (click)=\"selectVisible()\"\r\n        >\r\n          <!--\r\n            ⚠ \"these N\", never \"all\". With a filter applied, \"all\" reads as the whole queue — and\r\n            approving something you cannot see is the one mistake this screen cannot undo.\r\n          -->\r\n          Select these {{ rows().length }}\r\n        </button>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary\"\r\n          [disabled]=\"selectedCount() === 0 || busy()\"\r\n          (click)=\"clearSelection()\"\r\n        >\r\n          Clear selection\r\n        </button>\r\n      </div>\r\n    }\r\n\r\n    <!-- `(retry)` bound and the empty state routed through the container. See the pricing detail\r\n         screen for why both matter. -->\r\n    <cms-async-container\r\n      [data]=\"state()\"\r\n      [empty]=\"!hasScope() || rows().length === 0\"\r\n      [emptyMessage]=\"emptyMessage()\"\r\n      loadingLabel=\"Loading pricing approvals\"\r\n      (retry)=\"refresh()\"\r\n    >\r\n      @if (rows().length > 0) {\r\n        <!-- Tone-free, so the stripe cannot compete with a semantic tint — see the pricing queue. -->\r\n        <cms-data-grid\r\n          [rows]=\"rows()\"\r\n          [columns]=\"columns\"\r\n          label=\"Price sequences awaiting approval\"\r\n          [striped]=\"true\"\r\n          [sorts]=\"sorts()\"\r\n          (sortChange)=\"sorts.set($event)\"\r\n        />\r\n\r\n        <!--\r\n          Selection lives beside the grid rather than inside it: the shared grid renders columns from\r\n          data and has no concept of a row action, and giving it one for this screen would put a\r\n          checkbox column into every grid in the application.\r\n        -->\r\n        <ul class=\"cws:mt-3 cws:flex cws:flex-col cws:gap-1\">\r\n          @for (row of rows(); track row.contract + '|' + row.priceSequence) {\r\n            <li class=\"cws:flex cws:items-center cws:gap-3 cws:text-sm\">\r\n              <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"isSelected(row)\"\r\n                  [disabled]=\"busy()\"\r\n                  (change)=\"toggle(row)\"\r\n                />\r\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">\r\n                  {{ row.contract }} · seq {{ row.priceSequence }}\r\n                </span>\r\n              </label>\r\n\r\n              @if (canApprove()) {\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40\"\r\n                  [disabled]=\"busy()\"\r\n                  (click)=\"approveOne(row)\"\r\n                >\r\n                  Approve this one\r\n                </button>\r\n              }\r\n            </li>\r\n          }\r\n        </ul>\r\n\r\n        <!--\r\n          The footer pager and the range, matching the other three grids.\r\n\r\n          🔴 **Both numbers are about the QUEUE, not the page** — a user deciding whether they have\r\n          seen everything is asking about the queue, and \"1-50 of 50\" on a 2,000-row queue is the\r\n          claim that would mislead them. The grid above renders the page; this says how much of the\r\n          queue that is.\r\n        -->\r\n        <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-2\">\r\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Showing {{ rows().length }} of {{ queue().length }} awaiting approval\r\n          </p>\r\n\r\n          <cms-pager\r\n            [page]=\"currentPage()\"\r\n            [totalPages]=\"totalPages()\"\r\n            position=\"bottom\"\r\n            (goTo)=\"onPage($event)\"\r\n          />\r\n        </div>\r\n      }\r\n    </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep"
				]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: PricingApprovalsPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pricing-approvals-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FilterBuilderComponent,
				FilterSelectComponent,
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				SearchShortcutDirective,
				GridExportComponent,
				GridToolbarComponent,
				NoticesPanelComponent,
				PageHeaderComponent,
				PagerComponent,
				RefreshButtonComponent
			],
			template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    title=\"Pricing approvals\"\r\n    description=\"Price sequences awaiting approval. Approval cannot be undone.\"\r\n  >\r\n    <!--\r\n      ⚠ **Refresh MOVED to the grid toolbar** (JFrisbie, 2026-09-17). It was the shared control\r\n      already, but it was the only one of the four grids putting it in the page header, and the\r\n      toolbar is now one standard set on every grid. Nothing is left in the header actions slot\r\n      here, so the slot itself is gone rather than left rendering an empty box.\r\n    -->\r\n  </cms-page-header>\r\n\r\n  <cms-grid-toolbar>\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-md\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"search()\"\r\n        (input)=\"onSearch($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!-- Saved views and the rule builder, under this grid own scope. Width on the wrapper, never\r\n         the control: .scoular-form-input is @apply w-full and the design system compiles unlayered. -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-outline cws:shrink-0\" (click)=\"builder.beginAdd()\">\r\n      + Add filter\r\n    </button>\r\n\r\n    <!--\r\n      🔴 **The Trader box and the Approver type dropdown stood here and are GONE** (JFrisbie,\r\n      2026-09-17). The toolbar is now one standard set on every grid — search, view, add filter,\r\n      clear sort, export, refresh, pager — and nothing else.\r\n\r\n      ⚠ **The Trader box was an entry path, not a narrowing.** It was the only way to load this queue\r\n      with no trade unit selected, because the route needs a trader OR a location. It now needs a\r\n      trade unit; the empty state says so. Both this and the approver type remain request parameters\r\n      the source still accepts, so either control is a template change away from returning.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"sorts.set($event)\" />\r\n\r\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\r\n      <!--\r\n        Export, the same shared control as the other three grids. Both scopes are cheap here — the\r\n        route has no paging at all, so the whole queue is in memory — and the choice is still offered,\r\n        because \"this page\" and \"everything matched\" are different files now that the grid pages.\r\n      -->\r\n      <cms-grid-export\r\n        [columns]=\"columns\"\r\n        [pageRows]=\"rows()\"\r\n        [totalCount]=\"queue().length\"\r\n        [allRows]=\"exportAllRows\"\r\n        [filename]=\"exportFilename\"\r\n        [disabled]=\"!hasScope() || queue().length === 0\"\r\n        (failed)=\"exportError.set($event)\"\r\n      />\r\n\r\n      <cms-refresh-button\r\n        label=\"Refresh pricing approvals\"\r\n        [busy]=\"busy()\"\r\n        [disabled]=\"!hasScope()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <cms-pager\r\n        [page]=\"currentPage()\"\r\n        [totalPages]=\"totalPages()\"\r\n        position=\"top\"\r\n        (goTo)=\"onPage($event)\"\r\n      />\r\n    </div>\r\n  </cms-grid-toolbar>\r\n\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onRulesChange($event)\"\r\n  />\r\n\r\n  <!--\r\n    ⚠ Beside the grid rather than in the notices panel: that panel holds standing conditions, and a\r\n    failed export is the outcome of something the user just did.\r\n  -->\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    🔴 ONE presentation of the precondition, through the container, matching every other screen.\r\n\r\n    This was a tinted `scoular-alert-info` with a title, which read as a NOTICE about the data\r\n    rather than as the absence of any. CTRM refuses this route with neither a trader nor a location,\r\n    so the screen still issues no request -- only the way it says so has changed.\r\n  -->\r\n    @if (message(); as text) {\r\n      <div class=\"scoular-alert scoular-alert-success\" role=\"status\">\r\n        <div class=\"scoular-alert-description\">{{ text }}</div>\r\n      </div>\r\n    }\r\n\r\n    @if (failure(); as text) {\r\n      <!--\r\n        🔴 A partial failure, reported as one. Approval has no inverse, so a run that stopped part-way\r\n        has already committed everything before the failure — naming what succeeded is what stops the\r\n        user retrying the whole selection and being refused on the half that went through.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n        <div class=\"scoular-alert-title\">The approval run stopped part-way</div>\r\n        <div class=\"scoular-alert-description\">{{ text }}</div>\r\n      </div>\r\n    }\r\n\r\n    <!--\r\n      The standing notice, in the shared collapsible panel.\r\n\r\n      ⚠ **The success and failure messages above are deliberately NOT in it.** The panel is for\r\n      standing conditions — environment, data origin, capability gaps — and never for the outcome of\r\n      something the user just did. An approval run that stopped part-way has already committed half\r\n      its selection; behind a collapsed panel that is a message nobody reads.\r\n    -->\r\n    <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n      @if (mayBeTruncated()) {\r\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n          <div class=\"scoular-alert-title\">This queue may be incomplete</div>\r\n          <div class=\"scoular-alert-description\">\r\n            <!--\r\n              ⚠ The advice used to read \"narrow by trader\", and that box came off the toolbar on\r\n              2026-09-17 — so the sentence named a control the screen no longer has. A filter rule on\r\n              Trader narrows what is DISPLAYED and cannot make CTRM send more, which is the honest\r\n              thing to say rather than pointing at a workaround that no longer exists.\r\n            -->\r\n            CTRM returns at most {{ truncationCeiling() }} rows for this queue and does not say when\r\n            it has more, so rows may be missing before any filter is applied.\r\n          </div>\r\n        </div>\r\n      }\r\n      <!--\r\n        ⚠ Projected content AND a summary line, always both. `cms-notices-panel` gates the whole\r\n        panel on the summary count, so content added here without a matching summary is not\r\n        merely uncounted — it is not rendered at all.\r\n      -->\r\n      @if (!canApprove()) {\r\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n          <div class=\"scoular-alert-title\">Read-only for this account</div>\r\n          <div class=\"scoular-alert-description\">\r\n            You can see the unapproved queue but not commit an approval. Approving needs the\r\n            <strong>Admin</strong> role on this application.\r\n          </div>\r\n        </div>\r\n      }\r\n    </cms-notices-panel>\r\n\r\n    <!--\r\n      🔴 The whole decision toolbar, gated as one (F4.3a).\r\n\r\n      Selecting rows is only ever a prelude to approving them, so leaving the selection controls\r\n      behind a hidden Approve would be a gesture that collects rows and then has nowhere to send\r\n      them. The notices panel above carries the reason.\r\n    -->\r\n    @if (canApprove()) {\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n          [disabled]=\"selectedCount() === 0 || busy()\"\r\n          (click)=\"approveSelected()\"\r\n        >\r\n          {{ busy() ? 'Approving…' : 'Approve ' + selectedCount() + ' selected' }}\r\n        </button>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary\"\r\n          [disabled]=\"rows().length === 0 || busy()\"\r\n          (click)=\"selectVisible()\"\r\n        >\r\n          <!--\r\n            ⚠ \"these N\", never \"all\". With a filter applied, \"all\" reads as the whole queue — and\r\n            approving something you cannot see is the one mistake this screen cannot undo.\r\n          -->\r\n          Select these {{ rows().length }}\r\n        </button>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary\"\r\n          [disabled]=\"selectedCount() === 0 || busy()\"\r\n          (click)=\"clearSelection()\"\r\n        >\r\n          Clear selection\r\n        </button>\r\n      </div>\r\n    }\r\n\r\n    <!-- `(retry)` bound and the empty state routed through the container. See the pricing detail\r\n         screen for why both matter. -->\r\n    <cms-async-container\r\n      [data]=\"state()\"\r\n      [empty]=\"!hasScope() || rows().length === 0\"\r\n      [emptyMessage]=\"emptyMessage()\"\r\n      loadingLabel=\"Loading pricing approvals\"\r\n      (retry)=\"refresh()\"\r\n    >\r\n      @if (rows().length > 0) {\r\n        <!-- Tone-free, so the stripe cannot compete with a semantic tint — see the pricing queue. -->\r\n        <cms-data-grid\r\n          [rows]=\"rows()\"\r\n          [columns]=\"columns\"\r\n          label=\"Price sequences awaiting approval\"\r\n          [striped]=\"true\"\r\n          [sorts]=\"sorts()\"\r\n          (sortChange)=\"sorts.set($event)\"\r\n        />\r\n\r\n        <!--\r\n          Selection lives beside the grid rather than inside it: the shared grid renders columns from\r\n          data and has no concept of a row action, and giving it one for this screen would put a\r\n          checkbox column into every grid in the application.\r\n        -->\r\n        <ul class=\"cws:mt-3 cws:flex cws:flex-col cws:gap-1\">\r\n          @for (row of rows(); track row.contract + '|' + row.priceSequence) {\r\n            <li class=\"cws:flex cws:items-center cws:gap-3 cws:text-sm\">\r\n              <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"isSelected(row)\"\r\n                  [disabled]=\"busy()\"\r\n                  (change)=\"toggle(row)\"\r\n                />\r\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\">\r\n                  {{ row.contract }} · seq {{ row.priceSequence }}\r\n                </span>\r\n              </label>\r\n\r\n              @if (canApprove()) {\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40\"\r\n                  [disabled]=\"busy()\"\r\n                  (click)=\"approveOne(row)\"\r\n                >\r\n                  Approve this one\r\n                </button>\r\n              }\r\n            </li>\r\n          }\r\n        </ul>\r\n\r\n        <!--\r\n          The footer pager and the range, matching the other three grids.\r\n\r\n          🔴 **Both numbers are about the QUEUE, not the page** — a user deciding whether they have\r\n          seen everything is asking about the queue, and \"1-50 of 50\" on a 2,000-row queue is the\r\n          claim that would mislead them. The grid above renders the page; this says how much of the\r\n          queue that is.\r\n        -->\r\n        <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-2\">\r\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Showing {{ rows().length }} of {{ queue().length }} awaiting approval\r\n          </p>\r\n\r\n          <cms-pager\r\n            [page]=\"currentPage()\"\r\n            [totalPages]=\"totalPages()\"\r\n            position=\"bottom\"\r\n            (goTo)=\"onPage($event)\"\r\n          />\r\n        </div>\r\n      }\r\n    </cms-async-container>\r\n</section>\r\n"
		}]
	}]
});
function contractCount(count) {
	if (count === 0) return "Nothing was approved";
	return count === 1 ? "1 contract was approved" : `${count} contracts were approved`;
}
async function firstLoadedValue(source) {
	return firstValueFrom(source.pipe(filter((value) => value.status !== "loading")));
}
function emptyPrices() {
	return {
		prices: [],
		count: 0,
		truncationCeiling: 0,
		mayBeTruncated: false
	};
}
export { APPROVAL_QUEUE_COLUMNS, PRICE_SEQUENCE_COLUMNS, PRICING_GRID_COLUMNS, PricingApprovalsPageComponent, PricingDetailPageComponent, PricingPageComponent, needsPricing, pricedQuantity };

//# sourceMappingURL=cws-features-pricing.mjs.map
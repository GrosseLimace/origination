import { ADDENDUM_LIST_SOURCE, ADDENDUM_PDF_SOURCE, ADDENDUM_PREVIEW_SOURCE, ADDENDUM_TAB, ADDENDUM_TEMPLATE_SOURCE, ADDENDUM_TYPE_SOURCE, AvailabilityGate, CLOSED_REFUSAL, CLOSE_PROVENANCE_WARNING, CONTRACT_ATTACHMENTS_SOURCE, CONTRACT_DETAIL_SOURCE, CONTRACT_DOCUMENTS_SOURCE, CONTRACT_IDEMPOTENCY_KEY, CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT, CONTRACT_LAYOUT_EMPTY_NOTES, CONTRACT_LAYOUT_FIELDS, CONTRACT_LAYOUT_FIELD_NOTES, CONTRACT_LAYOUT_GROUP_HEADINGS, CONTRACT_LAYOUT_HALF_FIELDS, CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS, CONTRACT_LAYOUT_SECTIONS, CONTRACT_LAYOUT_SECTION_NOTES, CONTRACT_LAYOUT_WIDE_FIELDS, CONTRACT_LOG_SOURCE, CONTRACT_NUMBER_SOURCE, CONTRACT_NUMBER_WIDTH, CONTRACT_READ_ONLY_FIELDS, CONTRACT_STATE_SOURCE, CONTRACT_TABS, CONTRACT_TEMPLATE_SOURCE, CONTRACT_TEXT_FAILED_MESSAGE, CONTRACT_TEXT_SOURCE, CONTRACT_WRITABLE_FIELDS, CONTRACT_WRITE_SOURCE, CUSTOMER_SOURCE, CWS_EXTERNAL_LINKS, ContractFormComponent, CwsContractEvents, DOCUMENTS_TAB, FORM_CONFIG_ADMIN_SOURCE, FORM_CONFIG_SOURCE, INTERCOMPANY_PURCHASE_REFUSAL, LOG_TAB, MARKET_REFERENCE_SOURCE, ME_SOURCE, NUMBER_CHECK_FAILED_MESSAGE, NUMBER_CHECK_UNCONFIRMED_MESSAGE, NUMBER_ISSUE_GENERIC_MESSAGE, PRICING_SOURCE, RECORD_DRAFT_STORE, RECORD_ORIGIN_PARAM, REMARK_NOTE_MAX_LENGTH, REMARK_TYPES, SaveAnnouncementStore, TRADER_EMAIL_SOURCE, TYPED_NUMBER_AVAILABLE_MESSAGE, TYPED_NUMBER_CHECKING_MESSAGE, TYPED_NUMBER_SHORT_MESSAGE, WEIGHT_LIMIT_CHECKING_MESSAGE, WEIGHT_LIMIT_CHECK_SOURCE, WEIGHT_LIMIT_DRIVER_MESSAGE, acceptAttributeOf, acceptedFormatsLabel, addendumEntryFieldsOf, addendumTemplatesFor, addendumTypeFor, attachmentChangesSentence, auditAttachmentsOf, auditChangesOf, auditNoteIdOf, classifyIntercompany, classifyInvalidParams, conditionOfConflict, confirmChgComponents, confirmationProgress, contractDocumentName, contractStatusBadge, contractTextBaseline, contractTextNotesPayload, contractTextRefusal, copyExclusions, copyPriceSequences, copyableValues, describeAuditAction, describeCollectionCopy, documentTypeLabel, fileBoundUrlFor, formatContractDate, groupContractDocuments, holdsAnyPermissionIn, injectLocationCodes, injectTradeUnitLabel, isIntercompanyPurchase, isRedactedName, isScoularAddress, listCollections, logNoteSizeRefusal, messageForTypedNumberCondition, pickedFileRefusal, planCollectionCopy, readableBytes, recordOrigin, recordOriginKey, recordTrail, remainingNoteBytes, remarkKey, remarkValuesOf, remarksChanged, remarksPayload, sameContractText, savedCodeDescriptions, seedFromCtrmValues, shipPeriodRowOf, shipPeriodWriteRow, summarizeAddendumList, tabsAfterCascade, templateValuesOf, toCtrmValue, weightLimitMessage, weightLimitRuleApplies } from "@cws/domain-contracts";
import { ControlPattern, MAX_SHIP_PERIODS, ReconciliationState, ShipPeriodIssueCode, ValidationSummaryComponent, buildShipPeriodDescription, hasOverlappingPeriods, isZeroOrBlank, marketCascade, nextShipPeriod, presentationMaps, reconcileShipPeriods, validateShipPeriods, validationSummary, withSavedCodeDescriptions } from "@cws/shared-form-engine";
import { CtrmWriteProblemType, problemFrom, writeOutcomeOf } from "@cws/core-http";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, HostListener, Injectable, afterRenderEffect, computed, effect, inject, input, linkedSignal, output, signal, untracked, viewChild } from "@angular/core";
import { takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { ActivatedRoute, RouterLink } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { formatDisplayDate, parseShipPeriodDate } from "@cws/shared-utils";
import { AsyncContainerComponent, BreadcrumbComponent, DataGridComponent, DropdownDirective, LOOKUP_ATTRIBUTE, NoticesPanelComponent, OPEN_LOOKUP_EVENT, ReferenceLineComponent, RefreshButtonComponent, StatusBadgeComponent, StatusMessageComponent, compareBySorts, correlationIdOf, downloadBlob, focusWithoutOpening, injectConfirm, mutationFailed, mutationRefused, mutationSucceeded, registerShortcuts, remoteError, remoteLoaded, remoteLoading } from "@cws/shared-ui";
import { EMPTY, Subject, catchError, debounceTime, distinctUntilChanged, filter, map, merge, of, startWith, switchMap, take, tap, timer } from "rxjs";
const CONTRACT_DETAIL_SECTIONS = CONTRACT_LAYOUT_SECTIONS;
const DETAIL_EMPTY_NOTES = CONTRACT_LAYOUT_EMPTY_NOTES;
function aggregateValues(contract) {
	const header = contract.header;
	return {
		contract_date: header.contractDate ?? null,
		location: header.tradeUnit ?? null,
		trader_initials: header.traderInitials ?? null,
		customer_id: header.customerId ?? null,
		customer_contract: header.customerContract ?? null,
		customer_merchant: contract.customerMerchant ?? null,
		payment_terms_code: header.paymentTerms ?? null,
		price_type_code: header.priceTypeCode ?? null,
		price: header.price ?? null,
		basis_price: header.basisPrice ?? null,
		hedge_price: contract.hedgePrice ?? null,
		freight_adj: contract.freightAdjustment ?? null,
		contract_currency: contract.currency ?? null,
		market_zone: header.marketZone ?? null,
		basis_location: contract.basisLocation ?? null,
		quantity: header.quantity ?? null,
		quantity_uom: header.quantityUom ?? null,
		descriptive_quantity: contract.descriptiveQuantity ?? null,
		origin_code: contract.originCode ?? null,
		destination_code: contract.destinationCode ?? null,
		ship_period_description: contract.shipPeriodDescription ?? null,
		broker_id: contract.brokerId ?? null,
		broker_contract: contract.brokerContract ?? null,
		customer_name: isRedactedName(header.customerName) ? null : header.customerName ?? null,
		origin_name: header.originName ?? null,
		destination_name: header.destinationName ?? null,
		inco_terms_description: contract.incoTermsDescription ?? null,
		named_place: contract.namedPlace ?? null
	};
}
function withResolvedTrader(config, contract) {
	const initials = contract?.header.traderInitials?.trim() ?? "";
	const name = contract?.header.trader?.trim() ?? "";
	if (initials === "" || name === "") return config;
	return {
		...config,
		sections: config.sections.map((section) => ({
			...section,
			fields: section.fields.map((field) => field.componentName === TRADER_INITIALS_COMPONENT ? {
				...field,
				controlPattern: ControlPattern.SearchableCodeCombo,
				allowedValues: [{
					code: initials,
					description: name
				}]
			} : field)
		}))
	};
}
const TRADER_INITIALS_COMPONENT = "TraderInitials";
const MARKET_MONTH_COMPONENTS = ["BasisMarketMonth", "HedgeMarketMonth"];
function withMarketMonths(config, months) {
	if (months === null || months.length === 0) return config;
	const upgraded = new Set(MARKET_MONTH_COMPONENTS);
	return {
		...config,
		sections: config.sections.map((section) => ({
			...section,
			fields: section.fields.map((field) => upgraded.has(field.componentName) ? {
				...field,
				controlPattern: ControlPattern.SearchableCodeCombo,
				allowedValues: months
			} : field)
		}))
	};
}
function mergeContractValues(contract, writableValues) {
	const supplementary = writableValues ?? {};
	if (contract === null) return supplementary;
	const modelled = Object.fromEntries(Object.entries(aggregateValues(contract)).filter(([, value]) => value !== null));
	return {
		...supplementary,
		...modelled
	};
}
const CONFIRMATION_STAGES = [
	{
		label: "Trader approval",
		value: (c) => c.header.traderApprovalStatus
	},
	{
		label: "Customer confirmation",
		value: (c) => c.header.customerConfirmStatus
	},
	{
		label: "Broker confirmation",
		value: (c) => c.header.brokerConfirmStatus,
		emptyNote: "Populates on the detail route only"
	}
];
function formatFieldValue(value, kind) {
	if (value === null || value === void 0 || value === "") return "";
	switch (kind) {
		case "date": return formatContractDate(String(value));
		case "price": return formatNumeric(value, price);
		case "quantity":
		case "number": return formatNumeric(value, quantity);
		default: return String(value);
	}
}
function formatNumeric(value, formatter) {
	const numeric = typeof value === "number" ? value : Number(value);
	return Number.isFinite(numeric) ? formatter.format(numeric) : String(value);
}
const price = new Intl.NumberFormat("en-US", {
	minimumFractionDigits: 4,
	maximumFractionDigits: 4
});
const quantity = new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 });
function listStateOf(answer) {
	switch (answer.kind) {
		case "done": return {
			status: "loaded",
			items: answer.value
		};
		case "unavailable": return {
			status: "unavailable",
			reason: answer.reason
		};
		default: return {
			status: "failed",
			message: answer.message
		};
	}
}
const NO_TYPE_SOURCE = "Addendum types are not offered here, so no template can be offered: whether Legal has approved this type is unknown.";
const LIST_FAILED = "The addendum list could not be read. Please try again.";
function listStates(source, absent) {
	if (source === null) return of({
		status: "unavailable",
		reason: absent
	});
	return source.list().pipe(map((answer) => listStateOf(answer)), catchError(() => of({
		status: "failed",
		message: LIST_FAILED
	})), startWith({ status: "loading" }));
}
var PdfFrameComponent = class PdfFrameComponent {
	blob = input.required(...ngDevMode ? [{ debugName: "blob" }] : /* istanbul ignore next */ []);
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	fileName = input("document.pdf", ...ngDevMode ? [{ debugName: "fileName" }] : /* istanbul ignore next */ []);
	frame = viewChild("frame", ...ngDevMode ? [{ debugName: "frame" }] : /* istanbul ignore next */ []);
	current = null;
	constructor() {
		afterRenderEffect(() => {
			const blob = this.blob();
			const frame = this.frame()?.nativeElement;
			if (frame === void 0) return;
			if (this.current?.blob !== blob) {
				this.revoke();
				this.current = {
					blob,
					url: URL.createObjectURL(blob)
				};
			}
			const url = this.current.url;
			if (url.startsWith("blob:") && frame.src !== url) frame.src = url;
		});
		inject(DestroyRef).onDestroy(() => this.revoke());
	}
	download() {
		downloadBlob(this.fileName(), this.blob());
	}
	revoke() {
		if (this.current !== null) {
			URL.revokeObjectURL(this.current.url);
			this.current = null;
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: PdfFrameComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.1",
		type: PdfFrameComponent,
		isStandalone: true,
		selector: "cws-pdf-frame",
		inputs: {
			blob: {
				classPropertyName: "blob",
				publicName: "blob",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			fileName: {
				classPropertyName: "fileName",
				publicName: "fileName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		viewQueries: [{
			propertyName: "frame",
			first: true,
			predicate: ["frame"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div class="cws:space-y-2">
      <div class="cws:flex cws:justify-end">
        <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm" (click)="download()">
          Download
        </button>
      </div>
      <iframe
        #frame
        class="cws:h-[70vh] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700"
        [title]="title()"
        data-testid="pdf-frame"
      ></iframe>
    </div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: PdfFrameComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-pdf-frame",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <div class="cws:space-y-2">
      <div class="cws:flex cws:justify-end">
        <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm" (click)="download()">
          Download
        </button>
      </div>
      <iframe
        #frame
        class="cws:h-[70vh] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700"
        [title]="title()"
        data-testid="pdf-frame"
      ></iframe>
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		blob: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "blob",
				required: true
			}]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		fileName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fileName",
				required: false
			}]
		}],
		frame: [{
			type: i0.ViewChild,
			args: ["frame", { isSignal: true }]
		}]
	}
});
var StoredAddendumComponent = class StoredAddendumComponent {
	addendum = input.required(...ngDevMode ? [{ debugName: "addendum" }] : /* istanbul ignore next */ []);
	earlier = input(0, ...ngDevMode ? [{ debugName: "earlier" }] : /* istanbul ignore next */ []);
	source = inject(ADDENDUM_PDF_SOURCE, { optional: true });
	destroyRef = inject(DestroyRef);
	canOpen = this.source !== null;
	state = linkedSignal({
		...ngDevMode ? { debugName: "state" } : /* istanbul ignore next */ {},
		source: this.addendum,
		computation: () => ({ status: "idle" })
	});
	blob = computed(() => {
		const state = this.state();
		return state.status === "open" ? state.blob : null;
	}, ...ngDevMode ? [{ debugName: "blob" }] : /* istanbul ignore next */ []);
	unavailableReason = computed(() => {
		const state = this.state();
		return state.status === "unavailable" ? state.reason : null;
	}, ...ngDevMode ? [{ debugName: "unavailableReason" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const state = this.state();
		return state.status === "failed" ? mutationFailed(state) : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	fileName = computed(() => `addendum-${this.addendum().addendumId}.pdf`, ...ngDevMode ? [{ debugName: "fileName" }] : /* istanbul ignore next */ []);
	open() {
		const source = this.source;
		const target = this.addendum();
		if (source === null || this.state().status === "loading") return;
		this.state.set({ status: "loading" });
		source.pdf(target.contractNumber, target.addendumId).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (answer) => {
				if (this.addendum() !== target) return;
				if (answer.kind === "done") this.state.set({
					status: "open",
					blob: answer.value
				});
				else if (answer.kind === "unavailable") this.state.set({
					status: "unavailable",
					reason: answer.reason
				});
				else this.state.set({
					status: "failed",
					message: answer.message,
					...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
				});
			},
			error: () => {
				if (this.addendum() === target) this.state.set({
					status: "failed",
					message: "The addendum could not be opened. Try again."
				});
			}
		});
	}
	close() {
		this.state.set({ status: "idle" });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: StoredAddendumComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: StoredAddendumComponent,
		isStandalone: true,
		selector: "cws-stored-addendum",
		inputs: {
			addendum: {
				classPropertyName: "addendum",
				publicName: "addendum",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			earlier: {
				classPropertyName: "earlier",
				publicName: "earlier",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<div class=\"cws:space-y-2\" data-testid=\"stored-addendum\">\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n    <div>\r\n      <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">\r\n        Stored addendum {{ addendum().addendumId }}\r\n      </p>\r\n      @if (earlier() > 0) {\r\n        <p class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"stored-addendum-earlier\">\r\n          {{ earlier() }} earlier version{{ earlier() === 1 ? '' : 's' }}\r\n        </p>\r\n      }\r\n    </div>\r\n\r\n    @if (canOpen) {\r\n      @if (blob() !== null) {\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"close()\">\r\n          Close addendum\r\n        </button>\r\n      } @else {\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\r\n          [disabled]=\"state().status === 'loading'\"\r\n          (click)=\"open()\"\r\n        >\r\n          Open addendum\r\n        </button>\r\n      }\r\n    }\r\n  </div>\r\n\r\n  <cms-status-message [outcome]=\"failure()\" (dismissed)=\"close()\" />\r\n\r\n  @if (unavailableReason(); as reason) {\r\n    <!-- The route is wired before the backend publishes it. Said, never a crash or a silent blank. -->\r\n    <div class=\"scoular-alert scoular-alert-info\" data-testid=\"stored-addendum-unavailable\">\r\n      <div class=\"scoular-alert-title\">Not available yet</div>\r\n      <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n    </div>\r\n  }\r\n\r\n  @if (blob(); as pdf) {\r\n    <cws-pdf-frame [blob]=\"pdf\" title=\"Stored addendum\" [fileName]=\"fileName()\" />\r\n  }\r\n</div>\r\n",
		dependencies: [{
			kind: "component",
			type: PdfFrameComponent,
			selector: "cws-pdf-frame",
			inputs: [
				"blob",
				"title",
				"fileName"
			]
		}, {
			kind: "component",
			type: StatusMessageComponent,
			selector: "cms-status-message",
			inputs: ["outcome", "dismissMs"],
			outputs: ["dismissed"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: StoredAddendumComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-stored-addendum",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [PdfFrameComponent, StatusMessageComponent],
			template: "<div class=\"cws:space-y-2\" data-testid=\"stored-addendum\">\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n    <div>\r\n      <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">\r\n        Stored addendum {{ addendum().addendumId }}\r\n      </p>\r\n      @if (earlier() > 0) {\r\n        <p class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"stored-addendum-earlier\">\r\n          {{ earlier() }} earlier version{{ earlier() === 1 ? '' : 's' }}\r\n        </p>\r\n      }\r\n    </div>\r\n\r\n    @if (canOpen) {\r\n      @if (blob() !== null) {\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"close()\">\r\n          Close addendum\r\n        </button>\r\n      } @else {\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\r\n          [disabled]=\"state().status === 'loading'\"\r\n          (click)=\"open()\"\r\n        >\r\n          Open addendum\r\n        </button>\r\n      }\r\n    }\r\n  </div>\r\n\r\n  <cms-status-message [outcome]=\"failure()\" (dismissed)=\"close()\" />\r\n\r\n  @if (unavailableReason(); as reason) {\r\n    <!-- The route is wired before the backend publishes it. Said, never a crash or a silent blank. -->\r\n    <div class=\"scoular-alert scoular-alert-info\" data-testid=\"stored-addendum-unavailable\">\r\n      <div class=\"scoular-alert-title\">Not available yet</div>\r\n      <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n    </div>\r\n  }\r\n\r\n  @if (blob(); as pdf) {\r\n    <cws-pdf-frame [blob]=\"pdf\" title=\"Stored addendum\" [fileName]=\"fileName()\" />\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		addendum: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "addendum",
				required: true
			}]
		}],
		earlier: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "earlier",
				required: false
			}]
		}]
	}
});
var ContractAddendumSectionComponent = class ContractAddendumSectionComponent {
	previewSource = inject(ADDENDUM_PREVIEW_SOURCE, { optional: true });
	destroyRef = inject(DestroyRef);
	addendumType = input(null, ...ngDevMode ? [{ debugName: "addendumType" }] : /* istanbul ignore next */ []);
	specialType = input(null, ...ngDevMode ? [{ debugName: "specialType" }] : /* istanbul ignore next */ []);
	templatesState = input(null, ...ngDevMode ? [{ debugName: "templatesState" }] : /* istanbul ignore next */ []);
	typesState = input({
		status: "unavailable",
		reason: NO_TYPE_SOURCE
	}, ...ngDevMode ? [{ debugName: "typesState" }] : /* istanbul ignore next */ []);
	tradeUnit = input(null, ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	canEdit = input(false, ...ngDevMode ? [{ debugName: "canEdit" }] : /* istanbul ignore next */ []);
	previewContract = input(null, ...ngDevMode ? [{ debugName: "previewContract" }] : /* istanbul ignore next */ []);
	saveErrors = input([], ...ngDevMode ? [{ debugName: "saveErrors" }] : /* istanbul ignore next */ []);
	storedAddendum = input(null, ...ngDevMode ? [{ debugName: "storedAddendum" }] : /* istanbul ignore next */ []);
	earlierAddendums = input(0, ...ngDevMode ? [{ debugName: "earlierAddendums" }] : /* istanbul ignore next */ []);
	addendumListProblem = input(null, ...ngDevMode ? [{ debugName: "addendumListProblem" }] : /* istanbul ignore next */ []);
	missingRequired = input([], ...ngDevMode ? [{ debugName: "missingRequired" }] : /* istanbul ignore next */ []);
	offered = computed(() => this.templatesState() !== null && this.previewSource !== null, ...ngDevMode ? [{ debugName: "offered" }] : /* istanbul ignore next */ []);
	code = computed(() => (this.specialType() ?? "").trim(), ...ngDevMode ? [{ debugName: "code" }] : /* istanbul ignore next */ []);
	values = linkedSignal({
		...ngDevMode ? { debugName: "values" } : /* istanbul ignore next */ {},
		source: () => this.code(),
		computation: () => ({})
	});
	touched = linkedSignal({
		...ngDevMode ? { debugName: "touched" } : /* istanbul ignore next */ {},
		source: () => this.code(),
		computation: () => false
	});
	edited = this.touched.asReadonly();
	templates = computed(() => {
		const templates = this.templatesState();
		const types = this.typesState();
		if (templates === null || templates.status !== "loaded" || types.status !== "loaded") return [];
		return addendumTemplatesFor(templates.items, types.items, this.specialType(), this.tradeUnit());
	}, ...ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []);
	typeNotAvailable = computed(() => {
		const types = this.typesState();
		const code = (this.specialType() ?? "").trim();
		if (types.status !== "loaded") return false;
		const type = types.items.find((candidate) => candidate.specialType.trim() === code);
		return type === void 0 || !type.available;
	}, ...ngDevMode ? [{ debugName: "typeNotAvailable" }] : /* istanbul ignore next */ []);
	selectedTemplateId = linkedSignal({
		...ngDevMode ? { debugName: "selectedTemplateId" } : /* istanbul ignore next */ {},
		source: () => this.templates(),
		computation: (templates, previous) => previous !== void 0 && templates.some((template) => template.id === previous.value) ? previous.value : templates[0]?.id ?? null
	});
	selectedTemplate = computed(() => this.templates().find((template) => template.id === this.selectedTemplateId()) ?? null, ...ngDevMode ? [{ debugName: "selectedTemplate" }] : /* istanbul ignore next */ []);
	entryFields = computed(() => addendumEntryFieldsOf(this.selectedTemplate()), ...ngDevMode ? [{ debugName: "entryFields" }] : /* istanbul ignore next */ []);
	usedFields = computed(() => new Set(this.selectedTemplate()?.fields.map((mapping) => mapping.field) ?? []), ...ngDevMode ? [{ debugName: "usedFields" }] : /* istanbul ignore next */ []);
	preview = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []);
	canPressPreview = computed(() => this.offered() && this.canEdit() && this.previewContract() !== null && this.selectedTemplateId() !== null && this.preview().status !== "previewing" && this.previewHold().length === 0, ...ngDevMode ? [{ debugName: "canPressPreview" }] : /* istanbul ignore next */ []);
	previewHold = computed(() => [...this.missingRequired(), ...this.entryFields().filter((field) => this.usedFields().has(field.cwsField) && this.valueOf(field).trim() === "").map((field) => field.label)], ...ngDevMode ? [{ debugName: "previewHold" }] : /* istanbul ignore next */ []);
	unavailableReason = computed(() => {
		const templates = this.templatesState();
		const types = this.typesState();
		const preview = this.preview();
		if (preview.status === "unavailable") return preview.reason;
		if (templates?.status === "unavailable") return templates.reason;
		return types.status === "unavailable" ? types.reason : null;
	}, ...ngDevMode ? [{ debugName: "unavailableReason" }] : /* istanbul ignore next */ []);
	draft() {
		const offered = new Set(this.entryFields().map((field) => field.cwsField));
		return {
			templateId: this.selectedTemplateId(),
			fields: Object.fromEntries(Object.entries(this.values()).filter(([name]) => offered.has(name)).map(([name, value]) => [name, value.trim()]).filter(([, value]) => value !== ""))
		};
	}
	markSaved() {
		this.touched.set(false);
	}
	inputType(field) {
		return field.controlPattern === ControlPattern.MaskedDate ? "date" : "text";
	}
	inputMode(field) {
		return field.controlPattern === ControlPattern.QuantityDecimal ? "decimal" : null;
	}
	valueOf(field) {
		return this.values()[field.cwsField] ?? "";
	}
	setValue(field, value) {
		this.values.update((values) => ({
			...values,
			[field.cwsField]: value
		}));
		this.touched.set(true);
	}
	selectTemplate(value) {
		const id = Number(value);
		this.selectedTemplateId.set(Number.isFinite(id) ? id : null);
		this.touched.set(true);
	}
	runPreview() {
		const source = this.previewSource;
		const contract = this.previewContract()?.() ?? null;
		if (source === null || contract === null || !this.canPressPreview()) return;
		this.preview.set({ status: "previewing" });
		source.preview({
			contractNumber: contract.contractNumber,
			fields: contract.fields,
			...contract.collections === void 0 ? {} : { collections: contract.collections },
			addendum: this.draft()
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") this.preview.set({
				status: "open",
				blob: answer.value
			});
			else if (answer.kind === "unavailable") this.preview.set({
				status: "unavailable",
				reason: answer.reason
			});
			else this.preview.set({
				status: "failed",
				message: answer.message,
				...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
			});
		});
	}
	previewBlob = computed(() => {
		const state = this.preview();
		return state.status === "open" ? state.blob : null;
	}, ...ngDevMode ? [{ debugName: "previewBlob" }] : /* istanbul ignore next */ []);
	previewOutcome = computed(() => {
		const state = this.preview();
		return state.status === "failed" ? mutationFailed(state) : null;
	}, ...ngDevMode ? [{ debugName: "previewOutcome" }] : /* istanbul ignore next */ []);
	closePreview() {
		this.preview.set({ status: "idle" });
	}
	templatesFailure = computed(() => {
		const templates = this.templatesState();
		const types = this.typesState();
		if (templates?.status === "failed") return templates.message;
		return types.status === "failed" ? types.message : null;
	}, ...ngDevMode ? [{ debugName: "templatesFailure" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ContractAddendumSectionComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ContractAddendumSectionComponent,
		isStandalone: true,
		selector: "cws-contract-addendum-section",
		inputs: {
			addendumType: {
				classPropertyName: "addendumType",
				publicName: "addendumType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			specialType: {
				classPropertyName: "specialType",
				publicName: "specialType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			templatesState: {
				classPropertyName: "templatesState",
				publicName: "templatesState",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			typesState: {
				classPropertyName: "typesState",
				publicName: "typesState",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tradeUnit: {
				classPropertyName: "tradeUnit",
				publicName: "tradeUnit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canEdit: {
				classPropertyName: "canEdit",
				publicName: "canEdit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			previewContract: {
				classPropertyName: "previewContract",
				publicName: "previewContract",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			saveErrors: {
				classPropertyName: "saveErrors",
				publicName: "saveErrors",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			storedAddendum: {
				classPropertyName: "storedAddendum",
				publicName: "storedAddendum",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			earlierAddendums: {
				classPropertyName: "earlierAddendums",
				publicName: "earlierAddendums",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			addendumListProblem: {
				classPropertyName: "addendumListProblem",
				publicName: "addendumListProblem",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			missingRequired: {
				classPropertyName: "missingRequired",
				publicName: "missingRequired",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<section class=\"scoular-card cws:space-y-4 cws:p-4\" aria-labelledby=\"contract-addendum-heading\" data-testid=\"addendum-section\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 id=\"contract-addendum-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      <!-- #1043: the server's name for the type, not a frontend list's. -->\r\n      Addendum@if (addendumType(); as type) {<span>: {{ type.displayName }}</span>}\r\n    </h3>\r\n    <!--\r\n      #830: the values are saved with the contract now, so \"never sent\" would be false. What stays true\r\n      is that they are not CTRM fields: the Contract Workspace keeps them and prints them, and CTRM\r\n      receives the document.\r\n    -->\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      These values are kept by the Contract Workspace and printed on the addendum. Saving the contract\r\n      saves the addendum with it; CTRM receives the addendum document, not these fields.\r\n    </p>\r\n  </header>\r\n\r\n  <!--\r\n    🔴 The no-signature-image caveat, as visible text and never a title attribute. Who signs a\r\n    CWS-generated addendum once Cara is retired is an open question (tracked on #245 and #330), and\r\n    until it is answered the generated PDF carries the anchors and nothing else. The issue numbers\r\n    stay in this comment: the user-facing-copy guard refuses them on screen, and a trader cannot open\r\n    an issue anyway.\r\n\r\n    ⚠ Deliberately not role=\"alert\": it is a standing condition of every addendum generated here, not\r\n    something that just happened.\r\n  -->\r\n  <div class=\"scoular-alert scoular-alert-warning\" data-testid=\"addendum-signature-caveat\">\r\n    <div class=\"scoular-alert-title\">No signature image</div>\r\n    <div class=\"scoular-alert-description\">\r\n      Who signs an addendum generated here, now that Cara is being retired, has not been decided yet.\r\n      The generated document carries the signature, date and initials anchors, but no signature image.\r\n    </div>\r\n  </div>\r\n\r\n  <!--\r\n    #1043: the picked template's addendum_* fields, and only those. Its CTRM fields come from the\r\n    contract, and its customer and addendum-date fields from the server, so they get no control.\r\n  -->\r\n  @if (selectedTemplate() !== null && entryFields().length === 0) {\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-nothing-to-enter\">\r\n      Nothing to fill in for this template: everything it prints comes from the contract, the customer\r\n      record or the date it is generated.\r\n    </p>\r\n  }\r\n\r\n  <div class=\"cws:grid cws:grid-cols-1 cws:gap-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\r\n    @for (field of entryFields(); track field.cwsField) {\r\n      <label class=\"cws:space-y-1\">\r\n        <div class=\"cws:flex cws:items-baseline cws:gap-0.5\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ field.label }}</span>\r\n          <!-- #818: the picked template prints this field, so it may not be blank. The server enforces it. -->\r\n          @if (usedFields().has(field.cwsField)) {\r\n            <span class=\"cws:shrink-0 cws:text-red-700\" aria-hidden=\"true\">*</span>\r\n          }\r\n        </div>\r\n        <input\r\n          class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n          [attr.aria-required]=\"usedFields().has(field.cwsField) ? 'true' : null\"\r\n          [attr.name]=\"field.cwsField\"\r\n          [type]=\"inputType(field)\"\r\n          [attr.inputmode]=\"inputMode(field)\"\r\n          [value]=\"valueOf(field)\"\r\n          [disabled]=\"!canEdit()\"\r\n          (input)=\"setValue(field, $any($event.target).value)\"\r\n        />\r\n      </label>\r\n    }\r\n  </div>\r\n\r\n  @if (saveErrors().length > 0) {\r\n    <!-- #830: the save's addendum.* refusals, beside the fields they concern. The banner lists them too. -->\r\n    <ul class=\"cws:list-disc cws:space-y-1 cws:rounded cws:bg-rose-50 cws:py-2 cws:pr-3 cws:pl-6 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"addendum-save-errors\">\r\n      @for (reason of saveErrors(); track reason) {\r\n        <li>{{ reason }}</li>\r\n      }\r\n    </ul>\r\n  }\r\n\r\n  @if (storedAddendum(); as stored) {\r\n    <cws-stored-addendum [addendum]=\"stored\" [earlier]=\"earlierAddendums()\" />\r\n  } @else if (earlierAddendums() > 0) {\r\n    <p class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"addendum-no-current\">\r\n      No current addendum. {{ earlierAddendums() }} earlier version{{ earlierAddendums() === 1 ? ' was' : 's were' }}\r\n      withdrawn or replaced.\r\n    </p>\r\n  }\r\n\r\n  @if (addendumListProblem(); as problem) {\r\n    <p class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"addendum-list-problem\">\r\n      Could not check for a stored addendum. {{ problem }}\r\n    </p>\r\n  }\r\n\r\n  @if (!offered()) {\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-not-offered\">\r\n      Previewing an addendum is not offered here.\r\n    </p>\r\n  } @else {\r\n    @if (unavailableReason(); as reason) {\r\n      <!-- The route is wired before the backend publishes it. Said, never a crash or a silent blank. -->\r\n      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"addendum-unavailable\">\r\n        <div class=\"scoular-alert-title\">Not available yet</div>\r\n        <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n      </div>\r\n    }\r\n\r\n    @if (templatesFailure(); as message) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ message }}\r\n      </p>\r\n    }\r\n\r\n    @if (typeNotAvailable()) {\r\n      <!--\r\n        #676: a template is offered only for a type Legal has made available. Said, so an empty picker\r\n        is not read as \"nobody has written one\".\r\n      -->\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-type-not-available\">\r\n        This addendum type is not available yet, so no template is offered for it.\r\n      </p>\r\n    }\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template</span>\r\n        <select\r\n          class=\"scoular-form-input cws:mt-1 cws:w-72\"\r\n          name=\"addendumTemplate\"\r\n          [disabled]=\"templates().length === 0 || !canEdit()\"\r\n          (change)=\"selectTemplate($any($event.target).value)\"\r\n        >\r\n          @for (template of templates(); track template.id) {\r\n            <option [value]=\"template.id\" [selected]=\"template.id === selectedTemplateId()\">\r\n              {{ template.name }} (version {{ template.version }})\r\n            </option>\r\n          } @empty {\r\n            <option value=\"\">No active template for this addendum</option>\r\n          }\r\n        </select>\r\n      </label>\r\n\r\n      <!--\r\n        #830 (ruled by GEstevez, 2026-10-13): Generate became Preview. It renders from the values on\r\n        the screen and stores nothing; the addendum is stored when the contract is saved.\r\n      -->\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"!canPressPreview()\" (click)=\"runPreview()\">\r\n        @if (preview().status === 'previewing') { Previewing… } @else { Preview addendum }\r\n      </button>\r\n    </div>\r\n\r\n    @if (!canEdit()) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Edit the contract to change or preview its addendum.\r\n      </p>\r\n    } @else if (previewHold().length > 0) {\r\n      <!-- JFrisbie, 2026-10-23: no preview until every required field is filled. -->\r\n      <p role=\"status\" class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"addendum-preview-hold\">\r\n        Fill in the required fields to preview: {{ previewHold().join(', ') }}.\r\n      </p>\r\n    } @else {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        The preview is a draft and stores nothing. Saving the contract stores the addendum.\r\n      </p>\r\n    }\r\n\r\n    <!-- #803: a refused preview, with the server's reference. -->\r\n    <cms-status-message [outcome]=\"previewOutcome()\" (dismissed)=\"closePreview()\" />\r\n\r\n    @if (previewBlob(); as blob) {\r\n      <div class=\"cws:space-y-2\" data-testid=\"addendum-preview\">\r\n        <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-3\">\r\n          <p class=\"cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\" role=\"status\">\r\n            Draft preview. Every page reads DRAFT - NOT SAVED.\r\n          </p>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"closePreview()\">\r\n            Close preview\r\n          </button>\r\n        </div>\r\n        <cws-pdf-frame [blob]=\"blob\" title=\"Addendum draft preview\" fileName=\"addendum-draft.pdf\" />\r\n      </div>\r\n    }\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: PdfFrameComponent,
				selector: "cws-pdf-frame",
				inputs: [
					"blob",
					"title",
					"fileName"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "component",
				type: StoredAddendumComponent,
				selector: "cws-stored-addendum",
				inputs: ["addendum", "earlier"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ContractAddendumSectionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-addendum-section",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				PdfFrameComponent,
				StatusMessageComponent,
				StoredAddendumComponent
			],
			template: "<section class=\"scoular-card cws:space-y-4 cws:p-4\" aria-labelledby=\"contract-addendum-heading\" data-testid=\"addendum-section\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 id=\"contract-addendum-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      <!-- #1043: the server's name for the type, not a frontend list's. -->\r\n      Addendum@if (addendumType(); as type) {<span>: {{ type.displayName }}</span>}\r\n    </h3>\r\n    <!--\r\n      #830: the values are saved with the contract now, so \"never sent\" would be false. What stays true\r\n      is that they are not CTRM fields: the Contract Workspace keeps them and prints them, and CTRM\r\n      receives the document.\r\n    -->\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      These values are kept by the Contract Workspace and printed on the addendum. Saving the contract\r\n      saves the addendum with it; CTRM receives the addendum document, not these fields.\r\n    </p>\r\n  </header>\r\n\r\n  <!--\r\n    🔴 The no-signature-image caveat, as visible text and never a title attribute. Who signs a\r\n    CWS-generated addendum once Cara is retired is an open question (tracked on #245 and #330), and\r\n    until it is answered the generated PDF carries the anchors and nothing else. The issue numbers\r\n    stay in this comment: the user-facing-copy guard refuses them on screen, and a trader cannot open\r\n    an issue anyway.\r\n\r\n    ⚠ Deliberately not role=\"alert\": it is a standing condition of every addendum generated here, not\r\n    something that just happened.\r\n  -->\r\n  <div class=\"scoular-alert scoular-alert-warning\" data-testid=\"addendum-signature-caveat\">\r\n    <div class=\"scoular-alert-title\">No signature image</div>\r\n    <div class=\"scoular-alert-description\">\r\n      Who signs an addendum generated here, now that Cara is being retired, has not been decided yet.\r\n      The generated document carries the signature, date and initials anchors, but no signature image.\r\n    </div>\r\n  </div>\r\n\r\n  <!--\r\n    #1043: the picked template's addendum_* fields, and only those. Its CTRM fields come from the\r\n    contract, and its customer and addendum-date fields from the server, so they get no control.\r\n  -->\r\n  @if (selectedTemplate() !== null && entryFields().length === 0) {\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-nothing-to-enter\">\r\n      Nothing to fill in for this template: everything it prints comes from the contract, the customer\r\n      record or the date it is generated.\r\n    </p>\r\n  }\r\n\r\n  <div class=\"cws:grid cws:grid-cols-1 cws:gap-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\r\n    @for (field of entryFields(); track field.cwsField) {\r\n      <label class=\"cws:space-y-1\">\r\n        <div class=\"cws:flex cws:items-baseline cws:gap-0.5\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ field.label }}</span>\r\n          <!-- #818: the picked template prints this field, so it may not be blank. The server enforces it. -->\r\n          @if (usedFields().has(field.cwsField)) {\r\n            <span class=\"cws:shrink-0 cws:text-red-700\" aria-hidden=\"true\">*</span>\r\n          }\r\n        </div>\r\n        <input\r\n          class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n          [attr.aria-required]=\"usedFields().has(field.cwsField) ? 'true' : null\"\r\n          [attr.name]=\"field.cwsField\"\r\n          [type]=\"inputType(field)\"\r\n          [attr.inputmode]=\"inputMode(field)\"\r\n          [value]=\"valueOf(field)\"\r\n          [disabled]=\"!canEdit()\"\r\n          (input)=\"setValue(field, $any($event.target).value)\"\r\n        />\r\n      </label>\r\n    }\r\n  </div>\r\n\r\n  @if (saveErrors().length > 0) {\r\n    <!-- #830: the save's addendum.* refusals, beside the fields they concern. The banner lists them too. -->\r\n    <ul class=\"cws:list-disc cws:space-y-1 cws:rounded cws:bg-rose-50 cws:py-2 cws:pr-3 cws:pl-6 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"addendum-save-errors\">\r\n      @for (reason of saveErrors(); track reason) {\r\n        <li>{{ reason }}</li>\r\n      }\r\n    </ul>\r\n  }\r\n\r\n  @if (storedAddendum(); as stored) {\r\n    <cws-stored-addendum [addendum]=\"stored\" [earlier]=\"earlierAddendums()\" />\r\n  } @else if (earlierAddendums() > 0) {\r\n    <p class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"addendum-no-current\">\r\n      No current addendum. {{ earlierAddendums() }} earlier version{{ earlierAddendums() === 1 ? ' was' : 's were' }}\r\n      withdrawn or replaced.\r\n    </p>\r\n  }\r\n\r\n  @if (addendumListProblem(); as problem) {\r\n    <p class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"addendum-list-problem\">\r\n      Could not check for a stored addendum. {{ problem }}\r\n    </p>\r\n  }\r\n\r\n  @if (!offered()) {\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-not-offered\">\r\n      Previewing an addendum is not offered here.\r\n    </p>\r\n  } @else {\r\n    @if (unavailableReason(); as reason) {\r\n      <!-- The route is wired before the backend publishes it. Said, never a crash or a silent blank. -->\r\n      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"addendum-unavailable\">\r\n        <div class=\"scoular-alert-title\">Not available yet</div>\r\n        <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n      </div>\r\n    }\r\n\r\n    @if (templatesFailure(); as message) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ message }}\r\n      </p>\r\n    }\r\n\r\n    @if (typeNotAvailable()) {\r\n      <!--\r\n        #676: a template is offered only for a type Legal has made available. Said, so an empty picker\r\n        is not read as \"nobody has written one\".\r\n      -->\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-type-not-available\">\r\n        This addendum type is not available yet, so no template is offered for it.\r\n      </p>\r\n    }\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template</span>\r\n        <select\r\n          class=\"scoular-form-input cws:mt-1 cws:w-72\"\r\n          name=\"addendumTemplate\"\r\n          [disabled]=\"templates().length === 0 || !canEdit()\"\r\n          (change)=\"selectTemplate($any($event.target).value)\"\r\n        >\r\n          @for (template of templates(); track template.id) {\r\n            <option [value]=\"template.id\" [selected]=\"template.id === selectedTemplateId()\">\r\n              {{ template.name }} (version {{ template.version }})\r\n            </option>\r\n          } @empty {\r\n            <option value=\"\">No active template for this addendum</option>\r\n          }\r\n        </select>\r\n      </label>\r\n\r\n      <!--\r\n        #830 (ruled by GEstevez, 2026-10-13): Generate became Preview. It renders from the values on\r\n        the screen and stores nothing; the addendum is stored when the contract is saved.\r\n      -->\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"!canPressPreview()\" (click)=\"runPreview()\">\r\n        @if (preview().status === 'previewing') { Previewing… } @else { Preview addendum }\r\n      </button>\r\n    </div>\r\n\r\n    @if (!canEdit()) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Edit the contract to change or preview its addendum.\r\n      </p>\r\n    } @else if (previewHold().length > 0) {\r\n      <!-- JFrisbie, 2026-10-23: no preview until every required field is filled. -->\r\n      <p role=\"status\" class=\"cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"addendum-preview-hold\">\r\n        Fill in the required fields to preview: {{ previewHold().join(', ') }}.\r\n      </p>\r\n    } @else {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        The preview is a draft and stores nothing. Saving the contract stores the addendum.\r\n      </p>\r\n    }\r\n\r\n    <!-- #803: a refused preview, with the server's reference. -->\r\n    <cms-status-message [outcome]=\"previewOutcome()\" (dismissed)=\"closePreview()\" />\r\n\r\n    @if (previewBlob(); as blob) {\r\n      <div class=\"cws:space-y-2\" data-testid=\"addendum-preview\">\r\n        <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-3\">\r\n          <p class=\"cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\" role=\"status\">\r\n            Draft preview. Every page reads DRAFT - NOT SAVED.\r\n          </p>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"closePreview()\">\r\n            Close preview\r\n          </button>\r\n        </div>\r\n        <cws-pdf-frame [blob]=\"blob\" title=\"Addendum draft preview\" fileName=\"addendum-draft.pdf\" />\r\n      </div>\r\n    }\r\n  }\r\n</section>\r\n"
		}]
	}],
	propDecorators: {
		addendumType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "addendumType",
				required: false
			}]
		}],
		specialType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "specialType",
				required: false
			}]
		}],
		templatesState: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "templatesState",
				required: false
			}]
		}],
		typesState: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "typesState",
				required: false
			}]
		}],
		tradeUnit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tradeUnit",
				required: false
			}]
		}],
		canEdit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canEdit",
				required: false
			}]
		}],
		previewContract: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "previewContract",
				required: false
			}]
		}],
		saveErrors: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "saveErrors",
				required: false
			}]
		}],
		storedAddendum: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "storedAddendum",
				required: false
			}]
		}],
		earlierAddendums: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "earlierAddendums",
				required: false
			}]
		}],
		addendumListProblem: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "addendumListProblem",
				required: false
			}]
		}],
		missingRequired: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "missingRequired",
				required: false
			}]
		}]
	}
});
const ATTACHMENT_SAVES_CONTRACT = "This saves the contract: the version bumps and approval is required again.";
const ATTACHMENT_EXPIRES_CARA = "Saving will also store a CWS addendum and expire the Cara one.";
const RESEND_NOTE = "Sending it again saves the contract again, and approval is required again.";
const STATUS_LABELS$1 = {
	Current: "Current",
	Superseded: "Superseded",
	Removed: "Removed",
	Unknown: "Status not recognised"
};
var ContractAttachmentsComponent = class ContractAttachmentsComponent {
	source = inject(CONTRACT_ATTACHMENTS_SOURCE, { optional: true });
	confirm = injectConfirm();
	contractNumber = input(null, ...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	canWrite = input(false, ...ngDevMode ? [{ debugName: "canWrite" }] : /* istanbul ignore next */ []);
	caraWarning = input(false, ...ngDevMode ? [{ debugName: "caraWarning" }] : /* istanbul ignore next */ []);
	saveErrors = input([], ...ngDevMode ? [{ debugName: "saveErrors" }] : /* istanbul ignore next */ []);
	announcesSaves = input(true, ...ngDevMode ? [{ debugName: "announcesSaves" }] : /* istanbul ignore next */ []);
	saved = output();
	pendingChange = output();
	offered = this.source !== null;
	isCreate = computed(() => this.contractNumber() === null, ...ngDevMode ? [{ debugName: "isCreate" }] : /* istanbul ignore next */ []);
	optionsState = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "optionsState" }] : /* istanbul ignore next */ []);
	listState = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "listState" }] : /* istanbul ignore next */ []);
	viewer = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "viewer" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	picked = signal(null, ...ngDevMode ? [{ debugName: "picked" }] : /* istanbul ignore next */ []);
	documentType = signal("", ...ngDevMode ? [{ debugName: "documentType" }] : /* istanbul ignore next */ []);
	replacing = signal(null, ...ngDevMode ? [{ debugName: "replacing" }] : /* istanbul ignore next */ []);
	pending = signal([], ...ngDevMode ? [{ debugName: "pending" }] : /* istanbul ignore next */ []);
	pendingKey = 0;
	listSubscription = null;
	contentSubscription = null;
	writeSubscription = null;
	options = computed(() => {
		const state = this.optionsState();
		return state.status === "loaded" ? state.options : null;
	}, ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	accept = computed(() => {
		const options = this.options();
		return options === null ? "" : acceptAttributeOf(options);
	}, ...ngDevMode ? [{ debugName: "accept" }] : /* istanbul ignore next */ []);
	hint = computed(() => {
		const options = this.options();
		return options === null ? null : `${acceptedFormatsLabel(options)} only, up to ${readableBytes(options.maxFileBytes)} a file.`;
	}, ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	attachments = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.attachments : [];
	}, ...ngDevMode ? [{ debugName: "attachments" }] : /* istanbul ignore next */ []);
	canPick = computed(() => this.offered && this.options() !== null && this.canWrite(), ...ngDevMode ? [{ debugName: "canPick" }] : /* istanbul ignore next */ []);
	canSend = computed(() => this.canPick() && !this.busy() && this.picked() !== null && this.documentType() !== "", ...ngDevMode ? [{ debugName: "canSend" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const number = this.contractNumber();
			untracked(() => {
				this.readOptions();
				this.viewer.set({ status: "idle" });
				if (number !== null) this.readList(number);
			});
		});
		inject(DestroyRef).onDestroy(() => {
			this.listSubscription?.unsubscribe();
			this.contentSubscription?.unsubscribe();
			this.writeSubscription?.unsubscribe();
		});
	}
	statusLabel(attachment) {
		return STATUS_LABELS$1[attachment.status];
	}
	typeLabel(code) {
		return documentTypeLabel(code, this.options());
	}
	size(bytes) {
		return readableBytes(bytes);
	}
	onPick(event) {
		const input = event.target;
		const file = input.files?.[0] ?? null;
		const options = this.options();
		input.value = "";
		if (file === null || options === null) return;
		const refusal = pickedFileRefusal(file, options);
		if (refusal !== null) {
			this.picked.set(null);
			this.outcome.set(mutationRefused(refusal));
			return;
		}
		this.outcome.set(null);
		this.picked.set(file);
	}
	onType(event) {
		this.documentType.set(event.target.value);
	}
	startReplace(attachment) {
		this.replacing.set(attachment);
		this.documentType.set(attachment.documentType);
		this.picked.set(null);
		this.outcome.set(null);
	}
	cancelReplace() {
		this.replacing.set(null);
		this.picked.set(null);
	}
	send() {
		const file = this.picked();
		const documentType = this.documentType();
		if (file === null || documentType === "" || !this.canPick()) return;
		if (this.isCreate()) {
			this.addPending(file, documentType);
			return;
		}
		const number = this.contractNumber();
		const target = this.replacing();
		const upload = {
			file,
			documentType
		};
		const source = this.source;
		this.askToSave(target === null ? "Attach and save" : "Replace and save", false).subscribe((agreed) => {
			if (!agreed) return;
			this.run((flags) => target === null ? source.add(number, upload, flags) : source.replace(number, target.documentId, upload, flags), target === null ? `Attached ${file.name}.` : `Replaced ${target.fileName} with ${file.name}.`);
		});
	}
	remove(attachment) {
		const number = this.contractNumber();
		if (number === null || this.source === null || !this.canWrite() || this.busy()) return;
		const source = this.source;
		this.askToSave("Remove and save", true).subscribe((agreed) => {
			if (agreed) this.run((flags) => source.remove(number, attachment.documentId, flags), `Removed ${attachment.fileName}.`);
		});
	}
	removePending(key) {
		this.pending.update((files) => files.filter((file) => file.key !== key));
		this.pendingChange.emit(this.pending().map(({ file, documentType }) => ({
			file,
			documentType
		})));
	}
	open(attachment) {
		const number = this.contractNumber();
		if (number === null || this.source === null) return;
		const documentId = attachment.documentId;
		this.contentSubscription?.unsubscribe();
		this.viewer.set({
			status: "loading",
			documentId
		});
		this.contentSubscription = this.source.content(number, documentId).subscribe((content) => {
			this.viewer.set(content.kind === "done" ? {
				status: "open",
				documentId,
				blob: content.blob,
				fileName: attachment.fileName
			} : {
				status: "failed",
				documentId,
				message: content.message,
				correlationId: content.correlationId
			});
		});
	}
	closeViewer() {
		this.contentSubscription?.unsubscribe();
		this.viewer.set({ status: "idle" });
	}
	retryList() {
		const number = this.contractNumber();
		if (number !== null) this.readList(number);
	}
	retryOptions() {
		this.readOptions();
	}
	askToSave(confirmLabel, destructive) {
		return this.confirm({
			title: "Save the contract?",
			message: this.caraWarning() ? `${ATTACHMENT_SAVES_CONTRACT} ${ATTACHMENT_EXPIRES_CARA}` : ATTACHMENT_SAVES_CONTRACT,
			confirmLabel,
			cancelLabel: "Cancel",
			destructive
		});
	}
	run(call, done, resend = false) {
		this.busy.set(true);
		this.outcome.set(null);
		this.writeSubscription?.unsubscribe();
		this.writeSubscription = call(resend ? { confirmResend: true } : {}).subscribe((answer) => {
			this.busy.set(false);
			switch (answer.kind) {
				case "saved": {
					const changes = attachmentChangesSentence(answer.result.attachments?.changes ?? []);
					const message = `${done} The contract was saved: its version went up and it needs approval again.${answer.result.addendum?.action === "Stored" ? " A CWS addendum was stored with it." : ""}${changes === "" ? "" : ` ${changes}`}`;
					if (this.announcesSaves()) this.outcome.set(mutationSucceeded(message));
					this.picked.set(null);
					this.replacing.set(null);
					this.readList(this.contractNumber());
					this.saved.emit({
						result: answer.result,
						message
					});
					break;
				}
				case "conflict":
					this.confirm({
						title: answer.type === "attachment-already-removed" ? "Already removed" : "Already attached",
						message: `${answer.detail} ${RESEND_NOTE}`,
						confirmLabel: "Continue",
						cancelLabel: "Cancel"
					}).subscribe((agreed) => {
						if (agreed) this.run(call, done, true);
					});
					break;
				case "refused":
					this.outcome.set(mutationFailed({
						message: answer.message,
						correlationId: answer.correlationId
					}));
					if (answer.outcomeUnknown) this.readList(this.contractNumber());
			}
		});
	}
	async addPending(file, documentType) {
		const options = this.options();
		const current = this.pending();
		if (current.length >= options.maxDocumentsPerContract) {
			this.outcome.set(mutationRefused(`A contract holds at most ${options.maxDocumentsPerContract} documents.`));
			return;
		}
		const total = current.reduce((sum, entry) => sum + entry.file.size, 0) + file.size;
		if (total > options.maxSetBytes) {
			this.outcome.set(mutationRefused(`These files come to ${readableBytes(total)}, over the ${readableBytes(options.maxSetBytes)} limit for a contract.`));
			return;
		}
		for (const entry of current) if (entry.documentType === documentType && await sameBytes(entry.file, file)) {
			this.outcome.set(mutationRefused(`${file.name} is already in this list as ${entry.file.name}, with the same type.`));
			return;
		}
		this.pending.set([...current, {
			key: ++this.pendingKey,
			file,
			documentType
		}]);
		this.picked.set(null);
		this.outcome.set(null);
		this.pendingChange.emit(this.pending().map(({ file: picked, documentType: type }) => ({
			file: picked,
			documentType: type
		})));
	}
	readOptions() {
		if (this.source === null) return;
		this.optionsState.set({ status: "loading" });
		this.source.options().subscribe((read) => {
			this.optionsState.set(read.kind === "loaded" ? {
				status: "loaded",
				options: read.options
			} : {
				status: "failed",
				message: read.message,
				correlationId: read.correlationId
			});
		});
	}
	readList(number) {
		if (this.source === null) return;
		this.listSubscription?.unsubscribe();
		if (this.listState().status !== "loaded") this.listState.set({ status: "loading" });
		this.listSubscription = this.source.list(number).subscribe((read) => {
			this.listState.set(read.kind === "loaded" ? {
				status: "loaded",
				attachments: read.attachments
			} : {
				status: "failed",
				message: read.message,
				correlationId: read.correlationId
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ContractAttachmentsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ContractAttachmentsComponent,
		isStandalone: true,
		selector: "cws-contract-attachments",
		inputs: {
			contractNumber: {
				classPropertyName: "contractNumber",
				publicName: "contractNumber",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canWrite: {
				classPropertyName: "canWrite",
				publicName: "canWrite",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			caraWarning: {
				classPropertyName: "caraWarning",
				publicName: "caraWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			saveErrors: {
				classPropertyName: "saveErrors",
				publicName: "saveErrors",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			announcesSaves: {
				classPropertyName: "announcesSaves",
				publicName: "announcesSaves",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			saved: "saved",
			pendingChange: "pendingChange"
		},
		ngImport: i0,
		template: "<section\r\n  class=\"cws:space-y-3 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n  aria-labelledby=\"attachments-heading\"\r\n  data-testid=\"attachments-panel\"\r\n>\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-baseline cws:justify-between cws:gap-2\">\r\n    <h3 id=\"attachments-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      Attachments\r\n      @if (isCreate()) {\r\n        <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">(sent with the first Save)</span>\r\n      }\r\n    </h3>\r\n    @if (hint(); as text) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"attachments-hint\">{{ text }}</p>\r\n    }\r\n  </div>\r\n\r\n  @if (!offered) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"attachments-not-offered\">\r\n      Attachments are not offered here.\r\n    </p>\r\n  } @else {\r\n    @if (optionsState(); as state) {\r\n      @if (state.status === 'failed') {\r\n        <!-- Nothing hard-coded to fall back on: without the options, nothing can be attached. -->\r\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-testid=\"attachments-options-failed\">\r\n          <div class=\"scoular-alert-description cws:space-y-2\">\r\n            <p>{{ state.message }}</p>\r\n            <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"retryOptions()\">Retry</button>\r\n          </div>\r\n        </div>\r\n      }\r\n    }\r\n\r\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\r\n\r\n    @if (canPick()) {\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\" data-testid=\"attachments-picker\">\r\n        @if (replacing(); as target) {\r\n          <p class=\"cws:w-full cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"attachments-replacing\">\r\n            Replacing {{ target.fileName }}.\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"cancelReplace()\">\r\n              Cancel replace\r\n            </button>\r\n          </p>\r\n        }\r\n\r\n        <!--\r\n          The file picker as a button (JFrisbie, 2026-10-23). The browser's own control drew as plain\r\n          text, so nothing said it could be clicked. The input stays in the label, visually hidden, so\r\n          the keyboard and screen readers still reach the real control; the ring follows its focus.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\">\r\n          <span aria-hidden=\"true\">File</span>\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n            <label\r\n              class=\"scoular-btn scoular-btn-secondary cws:cursor-pointer cws:has-[:focus-visible]:outline-2 cws:has-[:focus-visible]:outline-offset-2 cws:has-[:focus-visible]:outline-scoular-blue\"\r\n              [class.cws:pointer-events-none]=\"busy()\"\r\n              [class.cws:opacity-50]=\"busy()\"\r\n            >\r\n              <span aria-hidden=\"true\">⤒</span>\r\n              Choose file\r\n              <input\r\n                type=\"file\"\r\n                class=\"sr-only\"\r\n                [accept]=\"accept()\"\r\n                [disabled]=\"busy()\"\r\n                (change)=\"onPick($event)\"\r\n                data-testid=\"attachments-file\"\r\n              />\r\n            </label>\r\n            <span class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"attachments-chosen\">\r\n              @if (picked(); as file) {\r\n                <span data-testid=\"attachments-picked\">{{ file.name }} · {{ size(file.size) }}</span>\r\n              } @else {\r\n                No file chosen\r\n              }\r\n            </span>\r\n          </div>\r\n        </div>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\">\r\n          Document type\r\n          <select\r\n            class=\"scoular-form-input\"\r\n            [value]=\"documentType()\"\r\n            [disabled]=\"busy()\"\r\n            (change)=\"onType($event)\"\r\n            data-testid=\"attachments-type\"\r\n          >\r\n            <option value=\"\" [selected]=\"documentType() === ''\">Choose a type</option>\r\n            @for (type of options()?.documentTypes ?? []; track type.code) {\r\n              <option [value]=\"type.code\" [selected]=\"documentType() === type.code\">{{ type.displayName }}</option>\r\n            }\r\n          </select>\r\n        </label>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary\"\r\n          [disabled]=\"!canSend()\"\r\n          (click)=\"send()\"\r\n          data-testid=\"attachments-send\"\r\n        >\r\n          {{ isCreate() ? 'Add to the new contract' : replacing() ? 'Replace' : 'Attach' }}\r\n        </button>\r\n\r\n      </div>\r\n    }\r\n\r\n    @if (isCreate()) {\r\n      @if (pending().length > 0) {\r\n        <ul class=\"cws:divide-y cws:divide-slate-200 cws:text-sm cws:dark:divide-slate-700\" data-testid=\"attachments-pending\">\r\n          @for (entry of pending(); track entry.key) {\r\n            <li class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:py-2\">\r\n              <span class=\"cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ entry.file.name }}\r\n                <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">· {{ typeLabel(entry.documentType) }} · {{ size(entry.file.size) }}</span>\r\n              </span>\r\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"removePending(entry.key)\">\r\n                Take off\r\n              </button>\r\n            </li>\r\n          }\r\n        </ul>\r\n      }\r\n\r\n      @for (reason of saveErrors(); track $index) {\r\n        <p class=\"cws:text-sm cws:text-red-700 cws:dark:text-red-300\" role=\"alert\" data-testid=\"attachments-save-error\">{{ reason }}</p>\r\n      }\r\n    } @else {\r\n      @switch (listState().status) {\r\n        @case ('loading') {\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the attachments…</p>\r\n        }\r\n\r\n        @case ('failed') {\r\n          <!-- 🔴 Never an empty list: \"no attachments\" is a claim a failed read cannot make. -->\r\n          @if (listState(); as state) {\r\n            @if (state.status === 'failed') {\r\n              <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"attachments-failed\">\r\n                <div class=\"scoular-alert-description cws:space-y-2\">\r\n                  <p>{{ state.message }}</p>\r\n                  <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                  <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"retryList()\">Retry</button>\r\n                </div>\r\n              </div>\r\n            }\r\n          }\r\n        }\r\n\r\n        @case ('loaded') {\r\n          @if (attachments().length === 0) {\r\n            <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"attachments-empty\">No attachments yet.</p>\r\n          } @else {\r\n            <table class=\"cws:w-full cws:text-left cws:text-sm\" data-testid=\"attachments-list\">\r\n              <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                <tr>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">File</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Type</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Size</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Status</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Added by</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:font-medium\"><span class=\"cws:sr-only\">Actions</span></th>\r\n                </tr>\r\n              </thead>\r\n              <tbody class=\"cws:divide-y cws:divide-slate-200 cws:dark:divide-slate-700\">\r\n                @for (attachment of attachments(); track attachment.documentId) {\r\n                  <tr [attr.data-document-id]=\"attachment.documentId\" [attr.data-status]=\"attachment.status\">\r\n                    <td class=\"cws:py-2 cws:pr-2\">\r\n                      <!-- Every version opens, a superseded or removed one included: the server serves them by id. -->\r\n                      <button type=\"button\" class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\" (click)=\"open(attachment)\">\r\n                        {{ attachment.fileName || 'Document ' + attachment.documentId }}\r\n                      </button>\r\n                    </td>\r\n                    <td class=\"cws:py-2 cws:pr-2\">{{ typeLabel(attachment.documentType) }}</td>\r\n                    <td class=\"cws:py-2 cws:pr-2\">{{ size(attachment.byteCount) }}</td>\r\n                    <td class=\"cws:py-2 cws:pr-2\">\r\n                      <cms-status-badge [tone]=\"attachment.status === 'Current' ? 'positive' : 'neutral'\" [small]=\"true\">{{\r\n                        statusLabel(attachment)\r\n                      }}</cms-status-badge>\r\n                    </td>\r\n                    <td class=\"cws:py-2 cws:pr-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      {{ attachment.createdByUpn }} · <time [attr.datetime]=\"attachment.createdAtUtc\">{{ attachment.createdAtUtc }}</time>\r\n                    </td>\r\n                    <td class=\"cws:py-2 cws:text-right cws:whitespace-nowrap\">\r\n                      @if (canPick() && attachment.status === 'Current') {\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\r\n                          [disabled]=\"busy()\"\r\n                          (click)=\"startReplace(attachment)\"\r\n                        >Replace</button>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1\"\r\n                          [disabled]=\"busy()\"\r\n                          (click)=\"remove(attachment)\"\r\n                        >Remove</button>\r\n                      }\r\n                    </td>\r\n                  </tr>\r\n                }\r\n              </tbody>\r\n            </table>\r\n          }\r\n\r\n          @switch (viewer().status) {\r\n            @case ('loading') {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the attachment…</p>\r\n            }\r\n            @case ('open') {\r\n              @if (viewer(); as state) {\r\n                @if (state.status === 'open') {\r\n                  <div class=\"cws:space-y-2\" data-testid=\"attachments-viewer\">\r\n                    <div class=\"cws:flex cws:justify-end\">\r\n                      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"closeViewer()\">Close</button>\r\n                    </div>\r\n                    <cws-pdf-frame [blob]=\"state.blob\" [title]=\"state.fileName\" [fileName]=\"state.fileName\" />\r\n                  </div>\r\n                }\r\n              }\r\n            }\r\n            @case ('failed') {\r\n              @if (viewer(); as state) {\r\n                @if (state.status === 'failed') {\r\n                  <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"attachments-viewer-failed\">\r\n                    <div class=\"scoular-alert-description cws:space-y-1\">\r\n                      <p>{{ state.message }}</p>\r\n                      <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                    </div>\r\n                  </div>\r\n                }\r\n              }\r\n            }\r\n          }\r\n        }\r\n      }\r\n    }\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: PdfFrameComponent,
				selector: "cws-pdf-frame",
				inputs: [
					"blob",
					"title",
					"fileName"
				]
			},
			{
				kind: "component",
				type: ReferenceLineComponent,
				selector: "cms-reference-line",
				inputs: ["correlationId", "sent"]
			},
			{
				kind: "component",
				type: StatusBadgeComponent,
				selector: "cms-status-badge",
				inputs: ["tone", "small"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ContractAttachmentsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-attachments",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				PdfFrameComponent,
				ReferenceLineComponent,
				StatusBadgeComponent,
				StatusMessageComponent
			],
			template: "<section\r\n  class=\"cws:space-y-3 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n  aria-labelledby=\"attachments-heading\"\r\n  data-testid=\"attachments-panel\"\r\n>\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-baseline cws:justify-between cws:gap-2\">\r\n    <h3 id=\"attachments-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      Attachments\r\n      @if (isCreate()) {\r\n        <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">(sent with the first Save)</span>\r\n      }\r\n    </h3>\r\n    @if (hint(); as text) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"attachments-hint\">{{ text }}</p>\r\n    }\r\n  </div>\r\n\r\n  @if (!offered) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"attachments-not-offered\">\r\n      Attachments are not offered here.\r\n    </p>\r\n  } @else {\r\n    @if (optionsState(); as state) {\r\n      @if (state.status === 'failed') {\r\n        <!-- Nothing hard-coded to fall back on: without the options, nothing can be attached. -->\r\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-testid=\"attachments-options-failed\">\r\n          <div class=\"scoular-alert-description cws:space-y-2\">\r\n            <p>{{ state.message }}</p>\r\n            <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"retryOptions()\">Retry</button>\r\n          </div>\r\n        </div>\r\n      }\r\n    }\r\n\r\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\r\n\r\n    @if (canPick()) {\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\" data-testid=\"attachments-picker\">\r\n        @if (replacing(); as target) {\r\n          <p class=\"cws:w-full cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"attachments-replacing\">\r\n            Replacing {{ target.fileName }}.\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"cancelReplace()\">\r\n              Cancel replace\r\n            </button>\r\n          </p>\r\n        }\r\n\r\n        <!--\r\n          The file picker as a button (JFrisbie, 2026-10-23). The browser's own control drew as plain\r\n          text, so nothing said it could be clicked. The input stays in the label, visually hidden, so\r\n          the keyboard and screen readers still reach the real control; the ring follows its focus.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\">\r\n          <span aria-hidden=\"true\">File</span>\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n            <label\r\n              class=\"scoular-btn scoular-btn-secondary cws:cursor-pointer cws:has-[:focus-visible]:outline-2 cws:has-[:focus-visible]:outline-offset-2 cws:has-[:focus-visible]:outline-scoular-blue\"\r\n              [class.cws:pointer-events-none]=\"busy()\"\r\n              [class.cws:opacity-50]=\"busy()\"\r\n            >\r\n              <span aria-hidden=\"true\">⤒</span>\r\n              Choose file\r\n              <input\r\n                type=\"file\"\r\n                class=\"sr-only\"\r\n                [accept]=\"accept()\"\r\n                [disabled]=\"busy()\"\r\n                (change)=\"onPick($event)\"\r\n                data-testid=\"attachments-file\"\r\n              />\r\n            </label>\r\n            <span class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"attachments-chosen\">\r\n              @if (picked(); as file) {\r\n                <span data-testid=\"attachments-picked\">{{ file.name }} · {{ size(file.size) }}</span>\r\n              } @else {\r\n                No file chosen\r\n              }\r\n            </span>\r\n          </div>\r\n        </div>\r\n\r\n        <label class=\"cws:flex cws:flex-col cws:gap-1 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\">\r\n          Document type\r\n          <select\r\n            class=\"scoular-form-input\"\r\n            [value]=\"documentType()\"\r\n            [disabled]=\"busy()\"\r\n            (change)=\"onType($event)\"\r\n            data-testid=\"attachments-type\"\r\n          >\r\n            <option value=\"\" [selected]=\"documentType() === ''\">Choose a type</option>\r\n            @for (type of options()?.documentTypes ?? []; track type.code) {\r\n              <option [value]=\"type.code\" [selected]=\"documentType() === type.code\">{{ type.displayName }}</option>\r\n            }\r\n          </select>\r\n        </label>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary\"\r\n          [disabled]=\"!canSend()\"\r\n          (click)=\"send()\"\r\n          data-testid=\"attachments-send\"\r\n        >\r\n          {{ isCreate() ? 'Add to the new contract' : replacing() ? 'Replace' : 'Attach' }}\r\n        </button>\r\n\r\n      </div>\r\n    }\r\n\r\n    @if (isCreate()) {\r\n      @if (pending().length > 0) {\r\n        <ul class=\"cws:divide-y cws:divide-slate-200 cws:text-sm cws:dark:divide-slate-700\" data-testid=\"attachments-pending\">\r\n          @for (entry of pending(); track entry.key) {\r\n            <li class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:py-2\">\r\n              <span class=\"cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ entry.file.name }}\r\n                <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">· {{ typeLabel(entry.documentType) }} · {{ size(entry.file.size) }}</span>\r\n              </span>\r\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"removePending(entry.key)\">\r\n                Take off\r\n              </button>\r\n            </li>\r\n          }\r\n        </ul>\r\n      }\r\n\r\n      @for (reason of saveErrors(); track $index) {\r\n        <p class=\"cws:text-sm cws:text-red-700 cws:dark:text-red-300\" role=\"alert\" data-testid=\"attachments-save-error\">{{ reason }}</p>\r\n      }\r\n    } @else {\r\n      @switch (listState().status) {\r\n        @case ('loading') {\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the attachments…</p>\r\n        }\r\n\r\n        @case ('failed') {\r\n          <!-- 🔴 Never an empty list: \"no attachments\" is a claim a failed read cannot make. -->\r\n          @if (listState(); as state) {\r\n            @if (state.status === 'failed') {\r\n              <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"attachments-failed\">\r\n                <div class=\"scoular-alert-description cws:space-y-2\">\r\n                  <p>{{ state.message }}</p>\r\n                  <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                  <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"retryList()\">Retry</button>\r\n                </div>\r\n              </div>\r\n            }\r\n          }\r\n        }\r\n\r\n        @case ('loaded') {\r\n          @if (attachments().length === 0) {\r\n            <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"attachments-empty\">No attachments yet.</p>\r\n          } @else {\r\n            <table class=\"cws:w-full cws:text-left cws:text-sm\" data-testid=\"attachments-list\">\r\n              <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                <tr>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">File</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Type</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Size</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Status</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:pr-2 cws:font-medium\">Added by</th>\r\n                  <th scope=\"col\" class=\"cws:py-1 cws:font-medium\"><span class=\"cws:sr-only\">Actions</span></th>\r\n                </tr>\r\n              </thead>\r\n              <tbody class=\"cws:divide-y cws:divide-slate-200 cws:dark:divide-slate-700\">\r\n                @for (attachment of attachments(); track attachment.documentId) {\r\n                  <tr [attr.data-document-id]=\"attachment.documentId\" [attr.data-status]=\"attachment.status\">\r\n                    <td class=\"cws:py-2 cws:pr-2\">\r\n                      <!-- Every version opens, a superseded or removed one included: the server serves them by id. -->\r\n                      <button type=\"button\" class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\" (click)=\"open(attachment)\">\r\n                        {{ attachment.fileName || 'Document ' + attachment.documentId }}\r\n                      </button>\r\n                    </td>\r\n                    <td class=\"cws:py-2 cws:pr-2\">{{ typeLabel(attachment.documentType) }}</td>\r\n                    <td class=\"cws:py-2 cws:pr-2\">{{ size(attachment.byteCount) }}</td>\r\n                    <td class=\"cws:py-2 cws:pr-2\">\r\n                      <cms-status-badge [tone]=\"attachment.status === 'Current' ? 'positive' : 'neutral'\" [small]=\"true\">{{\r\n                        statusLabel(attachment)\r\n                      }}</cms-status-badge>\r\n                    </td>\r\n                    <td class=\"cws:py-2 cws:pr-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      {{ attachment.createdByUpn }} · <time [attr.datetime]=\"attachment.createdAtUtc\">{{ attachment.createdAtUtc }}</time>\r\n                    </td>\r\n                    <td class=\"cws:py-2 cws:text-right cws:whitespace-nowrap\">\r\n                      @if (canPick() && attachment.status === 'Current') {\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\r\n                          [disabled]=\"busy()\"\r\n                          (click)=\"startReplace(attachment)\"\r\n                        >Replace</button>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1\"\r\n                          [disabled]=\"busy()\"\r\n                          (click)=\"remove(attachment)\"\r\n                        >Remove</button>\r\n                      }\r\n                    </td>\r\n                  </tr>\r\n                }\r\n              </tbody>\r\n            </table>\r\n          }\r\n\r\n          @switch (viewer().status) {\r\n            @case ('loading') {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the attachment…</p>\r\n            }\r\n            @case ('open') {\r\n              @if (viewer(); as state) {\r\n                @if (state.status === 'open') {\r\n                  <div class=\"cws:space-y-2\" data-testid=\"attachments-viewer\">\r\n                    <div class=\"cws:flex cws:justify-end\">\r\n                      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"closeViewer()\">Close</button>\r\n                    </div>\r\n                    <cws-pdf-frame [blob]=\"state.blob\" [title]=\"state.fileName\" [fileName]=\"state.fileName\" />\r\n                  </div>\r\n                }\r\n              }\r\n            }\r\n            @case ('failed') {\r\n              @if (viewer(); as state) {\r\n                @if (state.status === 'failed') {\r\n                  <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"attachments-viewer-failed\">\r\n                    <div class=\"scoular-alert-description cws:space-y-1\">\r\n                      <p>{{ state.message }}</p>\r\n                      <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                    </div>\r\n                  </div>\r\n                }\r\n              }\r\n            }\r\n          }\r\n        }\r\n      }\r\n    }\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: false
			}]
		}],
		canWrite: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canWrite",
				required: false
			}]
		}],
		caraWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "caraWarning",
				required: false
			}]
		}],
		saveErrors: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "saveErrors",
				required: false
			}]
		}],
		announcesSaves: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "announcesSaves",
				required: false
			}]
		}],
		saved: [{
			type: i0.Output,
			args: ["saved"]
		}],
		pendingChange: [{
			type: i0.Output,
			args: ["pendingChange"]
		}]
	}
});
async function sameBytes(left, right) {
	if (left.size !== right.size) return false;
	const [a, b] = await Promise.all([bytesOf(left), bytesOf(right)]);
	return a.length === b.length && a.every((value, index) => value === b[index]);
}
function bytesOf(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(new Uint8Array(reader.result));
		reader.onerror = () => reject(reader.error);
		reader.readAsArrayBuffer(file);
	});
}
const STATUS_LABELS = {
	available: "Ready",
	pending: "Generating…",
	expired: "Expired",
	notStored: "File not kept",
	unknown: "Status not recognised"
};
const CANNOT_OPEN = {
	pending: "This document is still being generated, so it cannot be opened yet.",
	expired: "This document has expired, so it can no longer be opened.",
	notStored: "CTRM still lists this document, but no longer holds its file, so it cannot be opened.",
	unknown: "CTRM reported a status this screen does not recognise, so the document is not opened rather than guessed at."
};
const INLINE_EXTENSIONS = {
	"application/pdf": ".pdf",
	"image/png": ".png",
	"image/jpeg": ".jpg",
	"image/gif": ".gif"
};
function mediaTypeOf(blob) {
	return blob.type.split(";")[0].trim().toLowerCase();
}
function isShownInline(blob) {
	return Object.hasOwn(INLINE_EXTENSIONS, mediaTypeOf(blob));
}
function downloadNameOf(document, blob) {
	const fileName = document.fileName?.trim();
	if (fileName) return fileName;
	const name = contractDocumentName(document);
	const extension = INLINE_EXTENSIONS[mediaTypeOf(blob)] ?? "";
	return extension !== "" && !name.toLowerCase().endsWith(extension) ? `${name}${extension}` : name;
}
const ROLE_BADGES = {
	draft: "Draft",
	approved: "Approved",
	confirmed: "Confirmed"
};
var ContractDocumentsTabComponent = class ContractDocumentsTabComponent {
	source = inject(CONTRACT_DOCUMENTS_SOURCE, { optional: true });
	host = inject(ElementRef);
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	offered = this.source !== null;
	listState = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "listState" }] : /* istanbul ignore next */ []);
	viewer = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "viewer" }] : /* istanbul ignore next */ []);
	selectedEntry = signal(null, ...ngDevMode ? [{ debugName: "selectedEntry" }] : /* istanbul ignore next */ []);
	recheckIn = signal(null, ...ngDevMode ? [{ debugName: "recheckIn" }] : /* istanbul ignore next */ []);
	recheckExhausted = signal(false, ...ngDevMode ? [{ debugName: "recheckExhausted" }] : /* istanbul ignore next */ []);
	rechecks = 0;
	listSubscription = null;
	recheckSubscription = null;
	contentSubscription = null;
	frame = viewChild("viewerFrame", ...ngDevMode ? [{ debugName: "frame" }] : /* istanbul ignore next */ []);
	grouping = computed(() => {
		const state = this.listState();
		return groupContractDocuments(state.status === "loaded" ? state.response.documents : []);
	}, ...ngDevMode ? [{ debugName: "grouping" }] : /* istanbul ignore next */ []);
	isEmpty = computed(() => {
		const state = this.listState();
		return state.status === "loaded" && state.response.documents.length === 0;
	}, ...ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => {
		const state = this.listState();
		return state.status === "loaded" && state.response.dataOrigin === "Simulated";
	}, ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.response.warnings : [];
	}, ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	visibleDocuments = computed(() => this.grouping().groups.flatMap((group) => group.documents), ...ngDevMode ? [{ debugName: "visibleDocuments" }] : /* istanbul ignore next */ []);
	selected = computed(() => this.visibleDocuments().find((document) => document.documentEntry === this.selectedEntry()) ?? null, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	selectedViewer = computed(() => {
		const state = this.viewer();
		return state.status !== "idle" && state.entry === this.selectedEntry() ? state : { status: "idle" };
	}, ...ngDevMode ? [{ debugName: "selectedViewer" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			this.contractNumber();
			untracked(() => {
				this.selectedEntry.set(null);
				this.setViewer({ status: "idle" });
				this.retry();
			});
		});
		afterRenderEffect(() => {
			const state = this.selectedViewer();
			const frame = this.frame()?.nativeElement;
			if (frame !== void 0 && state.status === "open" && state.url.startsWith("blob:") && frame.src !== state.url) frame.src = state.url;
		});
		inject(DestroyRef).onDestroy(() => {
			this.listSubscription?.unsubscribe();
			this.recheckSubscription?.unsubscribe();
			this.contentSubscription?.unsubscribe();
			this.revoke(this.viewer());
		});
	}
	retry() {
		this.rechecks = 0;
		this.recheckExhausted.set(false);
		this.load(false);
	}
	statusLabel(document) {
		return STATUS_LABELS[document.status];
	}
	roleBadge(document) {
		return ROLE_BADGES[document.role] ?? null;
	}
	nameOf(document) {
		return contractDocumentName(document);
	}
	cannotOpenReason(document) {
		return document.status === "available" ? null : CANNOT_OPEN[document.status];
	}
	open(document) {
		this.selectedEntry.set(document.documentEntry);
		const current = this.viewer();
		if (document.status !== "available" || this.source === null) {
			this.contentSubscription?.unsubscribe();
			this.setViewer({ status: "idle" });
			return;
		}
		if (current.status !== "idle" && current.entry === document.documentEntry && current.status !== "failed") return;
		const entry = document.documentEntry;
		this.contentSubscription?.unsubscribe();
		this.setViewer({
			status: "loading",
			entry
		});
		this.contentSubscription = this.source.content(this.contractNumber(), entry).subscribe((content) => {
			switch (content.kind) {
				case "done":
					this.setViewer(isShownInline(content.blob) ? {
						status: "open",
						entry,
						url: URL.createObjectURL(content.blob),
						blob: content.blob
					} : {
						status: "downloadOnly",
						entry,
						blob: content.blob
					});
					break;
				case "unavailable":
					this.setViewer({
						status: "unavailable",
						entry,
						reason: content.reason
					});
					break;
				case "refused":
					this.setViewer({
						status: "refused",
						entry,
						title: content.title,
						detail: content.detail,
						correlationId: content.correlationId
					});
					break;
				case "failed": this.setViewer({
					status: "failed",
					entry,
					title: content.title,
					message: content.message,
					correlationId: content.correlationId
				});
			}
		});
	}
	print() {
		this.frame()?.nativeElement.contentWindow?.print();
	}
	download() {
		const state = this.selectedViewer();
		const document = this.selected();
		if (state.status !== "open" && state.status !== "downloadOnly" || document === null) return;
		downloadBlob(downloadNameOf(document, state.blob), state.blob);
	}
	onKeydown(event) {
		if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "p") {
			if (this.selectedViewer().status === "open") {
				event.preventDefault();
				this.print();
			}
			return;
		}
		if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
		const items = Array.from(this.host.nativeElement.querySelectorAll("button[data-document-entry]"));
		const index = items.indexOf(event.target);
		if (index === -1) return;
		event.preventDefault();
		items[event.key === "ArrowDown" ? Math.min(index + 1, items.length - 1) : Math.max(index - 1, 0)].focus();
	}
	load(silent) {
		this.listSubscription?.unsubscribe();
		this.stopRecheck();
		const number = this.contractNumber().trim();
		if (!silent) this.listState.set({ status: "loading" });
		if (this.source === null || number === "") return;
		this.listSubscription = this.source.list(number).subscribe((read) => {
			switch (read.kind) {
				case "loaded":
					this.listState.set({
						status: "loaded",
						response: read.response
					});
					break;
				case "refused":
					this.listState.set({
						status: "refused",
						title: read.title,
						detail: read.detail
					});
					break;
				case "failed": this.listState.set({
					status: "failed",
					message: read.message,
					...read.correlationId === void 0 ? {} : { correlationId: read.correlationId }
				});
			}
			this.scheduleRecheck();
		});
	}
	scheduleRecheck() {
		if (!this.visibleDocuments().some((document) => document.status === "pending")) return;
		if (this.rechecks >= 20) {
			this.recheckExhausted.set(true);
			return;
		}
		this.recheckSubscription = timer(0, 1e3).pipe(take(16)).subscribe((tick) => {
			const left = 15 - tick;
			if (left > 0) this.recheckIn.set(left);
			else {
				this.rechecks++;
				this.load(true);
			}
		});
	}
	stopRecheck() {
		this.recheckSubscription?.unsubscribe();
		this.recheckSubscription = null;
		this.recheckIn.set(null);
	}
	setViewer(next) {
		const current = this.viewer();
		if (current.status === "open" && (next.status !== "open" || next.url !== current.url)) this.revoke(current);
		this.viewer.set(next);
	}
	revoke(state) {
		if (state.status === "open") URL.revokeObjectURL(state.url);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ContractDocumentsTabComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ContractDocumentsTabComponent,
		isStandalone: true,
		selector: "cws-contract-documents-tab",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: { "keydown": "onKeydown($event)" } },
		viewQueries: [{
			propertyName: "frame",
			first: true,
			predicate: ["viewerFrame"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<section class=\"cws:space-y-3\" aria-label=\"Documents\" data-testid=\"documents-tab\">\r\n  @if (!offered) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-not-offered\">\r\n      Documents are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (listState().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the documents…</p>\r\n      }\r\n\r\n      @case ('refused') {\r\n        <!--\r\n          A 403. For `ctrm-user-ambiguous` and `ctrm-user-not-found` the server's `detail` says what to\r\n          do (ask the Help Desk), so it is shown as it came rather than paraphrased here.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'refused') {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-testid=\"documents-refused\">\r\n              <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n              <div class=\"scoular-alert-description\">{{ state.detail }}</div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('failed') {\r\n        <!--\r\n          🔴 Criterion 4: a failed read says so and offers Retry. It must never fall through to the\r\n          list, whose empty state would tell the user this contract has no documents.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'failed') {\r\n            <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-failed\">\r\n              <div class=\"scoular-alert-title\">The documents could not be loaded</div>\r\n              <div class=\"scoular-alert-description cws:space-y-2\">\r\n                <p>{{ state.message }}</p>\r\n                @if (state.correlationId) {\r\n                  <p class=\"cws:text-xs\">Reference: <span class=\"cws:font-mono\">{{ state.correlationId }}</span></p>\r\n                }\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"retry()\">Retry</button>\r\n              </div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('loaded') {\r\n        @if (isSimulated()) {\r\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-simulated\">\r\n            These documents are simulated: the CTRM documents service is not connected yet.\r\n          </p>\r\n        }\r\n\r\n        @for (warning of warnings(); track $index) {\r\n          <div class=\"scoular-alert scoular-alert-warning\">\r\n            <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n          </div>\r\n        }\r\n\r\n        @if (isEmpty()) {\r\n          <!-- docs/02a §6.4a's empty state. Reached only from a SUCCESSFUL read of zero rows. -->\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-empty\">\r\n            No documents yet — generated when the contract is saved or approved.\r\n          </p>\r\n        } @else {\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-[18rem_1fr]\">\r\n            <!--\r\n              The left rail. Each document is a button, so Enter and a click open it natively; ↑/↓ are\r\n              handled on the host and move focus between these buttons only.\r\n            -->\r\n            <nav aria-label=\"Contract documents\" class=\"cws:space-y-4\" data-testid=\"documents-list\">\r\n              @if (grouping().heldBack > 0 && !grouping().approved) {\r\n                <!--\r\n                  The first-approval rule: the contract document is held back until the contract's first\r\n                  approval. Said, so the Contract group is not silently missing.\r\n                -->\r\n                <div class=\"cws:space-y-1\" data-testid=\"documents-held-back\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">Contract</h3>\r\n                  <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    The contract document is shown here once the contract has been approved.\r\n                  </p>\r\n                </div>\r\n              }\r\n\r\n              @for (group of grouping().groups; track group.id) {\r\n                <div class=\"cws:space-y-1\" [attr.data-testid]=\"'documents-group-' + group.id\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    {{ group.title }}\r\n                  </h3>\r\n                  <ul class=\"cws:space-y-1\">\r\n                    @for (document of group.documents; track document.documentEntry) {\r\n                      <li>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"cws:flex cws:w-full cws:items-center cws:gap-2 cws:rounded-md cws:px-2 cws:py-1.5 cws:text-left cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                          [class.cws:bg-slate-100]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:dark:bg-slate-700]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:hover:bg-slate-50]=\"document.documentEntry !== selectedEntry()\"\r\n                          [class.cws:dark:hover:bg-slate-800]=\"document.documentEntry !== selectedEntry()\"\r\n                          [attr.aria-current]=\"document.documentEntry === selectedEntry() ? 'true' : null\"\r\n                          [attr.data-document-entry]=\"document.documentEntry\"\r\n                          (click)=\"open(document)\"\r\n                        >\r\n                          <span class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-slate-900 cws:dark:text-white\">{{ nameOf(document) }}</span>\r\n                          @if (roleBadge(document); as badge) {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-sky-50 cws:text-sky-800 cws:dark:bg-sky-500/10 cws:dark:text-sky-200\">{{ badge }}</span>\r\n                          }\r\n                          @if (document.status !== 'available') {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-slate-100 cws:text-slate-700 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ statusLabel(document) }}</span>\r\n                          }\r\n                        </button>\r\n                      </li>\r\n                    }\r\n                  </ul>\r\n                </div>\r\n              }\r\n\r\n              @if (recheckIn(); as seconds) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\" data-testid=\"documents-recheck\">\r\n                  Generating… checking again in {{ seconds }}s.\r\n                </p>\r\n              }\r\n              @if (recheckExhausted()) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-recheck-stopped\">\r\n                  A document is still being generated. Use Retry to check again.\r\n                  <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:ml-1\" (click)=\"retry()\">Retry</button>\r\n                </p>\r\n              }\r\n            </nav>\r\n\r\n            <!-- The right pane: the inline viewer (C11), or why the selected document cannot be opened. -->\r\n            <div\r\n              class=\"cws:min-h-96 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              data-testid=\"documents-viewer\"\r\n            >\r\n              @if (selected(); as document) {\r\n                <div class=\"cws:mb-3 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n                  <h3 class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    {{ nameOf(document) }}\r\n                  </h3>\r\n                  @if (document.createdStamp) {\r\n                    <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Created {{ document.createdStamp }}</span>\r\n                  }\r\n                  @if (selectedViewer().status === 'open') {\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"print()\">Print</button>\r\n                  }\r\n                  @if (selectedViewer().status === 'open' || selectedViewer().status === 'downloadOnly') {\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"download()\">Download</button>\r\n                  }\r\n                </div>\r\n\r\n                @if (cannotOpenReason(document); as reason) {\r\n                  <!--\r\n                    C11: a pending document is never a raw error. It and the other unopenable states say\r\n                    why in plain words, and none of them asks the server for content.\r\n                  -->\r\n                  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"documents-cannot-open\">{{ reason }}</p>\r\n                  @if (document.status === 'pending') {\r\n                    <div class=\"cws:mt-3 cws:h-64 cws:animate-pulse cws:rounded-md cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></div>\r\n                  }\r\n                } @else {\r\n                  @switch (selectedViewer().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the document…</p>\r\n                    }\r\n                    @case ('open') {\r\n                      <iframe\r\n                        #viewerFrame\r\n                        class=\"cws:h-[70vh] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700\"\r\n                        [title]=\"nameOf(document)\"\r\n                        data-testid=\"documents-frame\"\r\n                      ></iframe>\r\n                    }\r\n                    @case ('downloadOnly') {\r\n                      <!--\r\n                        #495: not a PDF or an image, so it is not put in the frame. The server sends such a\r\n                        file as a download too, and the browser could not show it.\r\n                      -->\r\n                      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"documents-download-only\">\r\n                        <div class=\"scoular-alert-title\">This file can't be shown here</div>\r\n                        <div class=\"scoular-alert-description\">\r\n                          Only PDFs and images open in the viewer. Use Download to open it on your computer.\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @case ('unavailable') {\r\n                      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"documents-content-unavailable\">\r\n                        <div class=\"scoular-alert-title\">Can't be opened here yet</div>\r\n                        <div class=\"scoular-alert-description\">\r\n                          @if (selectedViewer(); as state) {\r\n                            @if (state.status === 'unavailable') { {{ state.reason }} }\r\n                          }\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @case ('refused') {\r\n                      <!-- #1004: an answer Try again cannot change, with the reference a person quotes to support. -->\r\n                      @if (selectedViewer(); as state) {\r\n                        @if (state.status === 'refused') {\r\n                          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-content-refused\">\r\n                            <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n                            <div class=\"scoular-alert-description cws:space-y-2\">\r\n                              <p>{{ state.detail }}</p>\r\n                              <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                            </div>\r\n                          </div>\r\n                        }\r\n                      }\r\n                    }\r\n                    @case ('failed') {\r\n                      @if (selectedViewer(); as state) {\r\n                        @if (state.status === 'failed') {\r\n                          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-content-failed\">\r\n                            @if (state.title) {\r\n                              <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n                            }\r\n                            <div class=\"scoular-alert-description cws:space-y-2\">\r\n                              <p>{{ state.message }}</p>\r\n                              <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"open(document)\">Try again</button>\r\n                            </div>\r\n                          </div>\r\n                        }\r\n                      }\r\n                    }\r\n                    @default {\r\n                      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"open(document)\">Open</button>\r\n                    }\r\n                  }\r\n                }\r\n              } @else {\r\n                <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Select a document to view it.</p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n      }\r\n    }\r\n  }\r\n</section>\r\n",
		dependencies: [{
			kind: "component",
			type: ReferenceLineComponent,
			selector: "cms-reference-line",
			inputs: ["correlationId", "sent"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ContractDocumentsTabComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-documents-tab",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ReferenceLineComponent],
			host: { "(keydown)": "onKeydown($event)" },
			template: "<section class=\"cws:space-y-3\" aria-label=\"Documents\" data-testid=\"documents-tab\">\r\n  @if (!offered) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-not-offered\">\r\n      Documents are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (listState().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the documents…</p>\r\n      }\r\n\r\n      @case ('refused') {\r\n        <!--\r\n          A 403. For `ctrm-user-ambiguous` and `ctrm-user-not-found` the server's `detail` says what to\r\n          do (ask the Help Desk), so it is shown as it came rather than paraphrased here.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'refused') {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-testid=\"documents-refused\">\r\n              <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n              <div class=\"scoular-alert-description\">{{ state.detail }}</div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('failed') {\r\n        <!--\r\n          🔴 Criterion 4: a failed read says so and offers Retry. It must never fall through to the\r\n          list, whose empty state would tell the user this contract has no documents.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'failed') {\r\n            <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-failed\">\r\n              <div class=\"scoular-alert-title\">The documents could not be loaded</div>\r\n              <div class=\"scoular-alert-description cws:space-y-2\">\r\n                <p>{{ state.message }}</p>\r\n                @if (state.correlationId) {\r\n                  <p class=\"cws:text-xs\">Reference: <span class=\"cws:font-mono\">{{ state.correlationId }}</span></p>\r\n                }\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"retry()\">Retry</button>\r\n              </div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('loaded') {\r\n        @if (isSimulated()) {\r\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-simulated\">\r\n            These documents are simulated: the CTRM documents service is not connected yet.\r\n          </p>\r\n        }\r\n\r\n        @for (warning of warnings(); track $index) {\r\n          <div class=\"scoular-alert scoular-alert-warning\">\r\n            <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n          </div>\r\n        }\r\n\r\n        @if (isEmpty()) {\r\n          <!-- docs/02a §6.4a's empty state. Reached only from a SUCCESSFUL read of zero rows. -->\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-empty\">\r\n            No documents yet — generated when the contract is saved or approved.\r\n          </p>\r\n        } @else {\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-[18rem_1fr]\">\r\n            <!--\r\n              The left rail. Each document is a button, so Enter and a click open it natively; ↑/↓ are\r\n              handled on the host and move focus between these buttons only.\r\n            -->\r\n            <nav aria-label=\"Contract documents\" class=\"cws:space-y-4\" data-testid=\"documents-list\">\r\n              @if (grouping().heldBack > 0 && !grouping().approved) {\r\n                <!--\r\n                  The first-approval rule: the contract document is held back until the contract's first\r\n                  approval. Said, so the Contract group is not silently missing.\r\n                -->\r\n                <div class=\"cws:space-y-1\" data-testid=\"documents-held-back\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">Contract</h3>\r\n                  <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    The contract document is shown here once the contract has been approved.\r\n                  </p>\r\n                </div>\r\n              }\r\n\r\n              @for (group of grouping().groups; track group.id) {\r\n                <div class=\"cws:space-y-1\" [attr.data-testid]=\"'documents-group-' + group.id\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    {{ group.title }}\r\n                  </h3>\r\n                  <ul class=\"cws:space-y-1\">\r\n                    @for (document of group.documents; track document.documentEntry) {\r\n                      <li>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"cws:flex cws:w-full cws:items-center cws:gap-2 cws:rounded-md cws:px-2 cws:py-1.5 cws:text-left cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                          [class.cws:bg-slate-100]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:dark:bg-slate-700]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:hover:bg-slate-50]=\"document.documentEntry !== selectedEntry()\"\r\n                          [class.cws:dark:hover:bg-slate-800]=\"document.documentEntry !== selectedEntry()\"\r\n                          [attr.aria-current]=\"document.documentEntry === selectedEntry() ? 'true' : null\"\r\n                          [attr.data-document-entry]=\"document.documentEntry\"\r\n                          (click)=\"open(document)\"\r\n                        >\r\n                          <span class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-slate-900 cws:dark:text-white\">{{ nameOf(document) }}</span>\r\n                          @if (roleBadge(document); as badge) {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-sky-50 cws:text-sky-800 cws:dark:bg-sky-500/10 cws:dark:text-sky-200\">{{ badge }}</span>\r\n                          }\r\n                          @if (document.status !== 'available') {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-slate-100 cws:text-slate-700 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ statusLabel(document) }}</span>\r\n                          }\r\n                        </button>\r\n                      </li>\r\n                    }\r\n                  </ul>\r\n                </div>\r\n              }\r\n\r\n              @if (recheckIn(); as seconds) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\" data-testid=\"documents-recheck\">\r\n                  Generating… checking again in {{ seconds }}s.\r\n                </p>\r\n              }\r\n              @if (recheckExhausted()) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-recheck-stopped\">\r\n                  A document is still being generated. Use Retry to check again.\r\n                  <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:ml-1\" (click)=\"retry()\">Retry</button>\r\n                </p>\r\n              }\r\n            </nav>\r\n\r\n            <!-- The right pane: the inline viewer (C11), or why the selected document cannot be opened. -->\r\n            <div\r\n              class=\"cws:min-h-96 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              data-testid=\"documents-viewer\"\r\n            >\r\n              @if (selected(); as document) {\r\n                <div class=\"cws:mb-3 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n                  <h3 class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    {{ nameOf(document) }}\r\n                  </h3>\r\n                  @if (document.createdStamp) {\r\n                    <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Created {{ document.createdStamp }}</span>\r\n                  }\r\n                  @if (selectedViewer().status === 'open') {\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"print()\">Print</button>\r\n                  }\r\n                  @if (selectedViewer().status === 'open' || selectedViewer().status === 'downloadOnly') {\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"download()\">Download</button>\r\n                  }\r\n                </div>\r\n\r\n                @if (cannotOpenReason(document); as reason) {\r\n                  <!--\r\n                    C11: a pending document is never a raw error. It and the other unopenable states say\r\n                    why in plain words, and none of them asks the server for content.\r\n                  -->\r\n                  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"documents-cannot-open\">{{ reason }}</p>\r\n                  @if (document.status === 'pending') {\r\n                    <div class=\"cws:mt-3 cws:h-64 cws:animate-pulse cws:rounded-md cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></div>\r\n                  }\r\n                } @else {\r\n                  @switch (selectedViewer().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the document…</p>\r\n                    }\r\n                    @case ('open') {\r\n                      <iframe\r\n                        #viewerFrame\r\n                        class=\"cws:h-[70vh] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700\"\r\n                        [title]=\"nameOf(document)\"\r\n                        data-testid=\"documents-frame\"\r\n                      ></iframe>\r\n                    }\r\n                    @case ('downloadOnly') {\r\n                      <!--\r\n                        #495: not a PDF or an image, so it is not put in the frame. The server sends such a\r\n                        file as a download too, and the browser could not show it.\r\n                      -->\r\n                      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"documents-download-only\">\r\n                        <div class=\"scoular-alert-title\">This file can't be shown here</div>\r\n                        <div class=\"scoular-alert-description\">\r\n                          Only PDFs and images open in the viewer. Use Download to open it on your computer.\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @case ('unavailable') {\r\n                      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"documents-content-unavailable\">\r\n                        <div class=\"scoular-alert-title\">Can't be opened here yet</div>\r\n                        <div class=\"scoular-alert-description\">\r\n                          @if (selectedViewer(); as state) {\r\n                            @if (state.status === 'unavailable') { {{ state.reason }} }\r\n                          }\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @case ('refused') {\r\n                      <!-- #1004: an answer Try again cannot change, with the reference a person quotes to support. -->\r\n                      @if (selectedViewer(); as state) {\r\n                        @if (state.status === 'refused') {\r\n                          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-content-refused\">\r\n                            <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n                            <div class=\"scoular-alert-description cws:space-y-2\">\r\n                              <p>{{ state.detail }}</p>\r\n                              <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                            </div>\r\n                          </div>\r\n                        }\r\n                      }\r\n                    }\r\n                    @case ('failed') {\r\n                      @if (selectedViewer(); as state) {\r\n                        @if (state.status === 'failed') {\r\n                          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-content-failed\">\r\n                            @if (state.title) {\r\n                              <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n                            }\r\n                            <div class=\"scoular-alert-description cws:space-y-2\">\r\n                              <p>{{ state.message }}</p>\r\n                              <cms-reference-line [correlationId]=\"state.correlationId\" />\r\n                              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"open(document)\">Try again</button>\r\n                            </div>\r\n                          </div>\r\n                        }\r\n                      }\r\n                    }\r\n                    @default {\r\n                      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"open(document)\">Open</button>\r\n                    }\r\n                  }\r\n                }\r\n              } @else {\r\n                <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Select a document to view it.</p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n      }\r\n    }\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}],
		frame: [{
			type: i0.ViewChild,
			args: ["viewerFrame", { isSignal: true }]
		}]
	}
});
var ContractTextSectionComponent = class ContractTextSectionComponent {
	answer = input.required(...ngDevMode ? [{ debugName: "answer" }] : /* istanbul ignore next */ []);
	values = input.required(...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	editing = input(false, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	locked = input(null, ...ngDevMode ? [{ debugName: "locked" }] : /* istanbul ignore next */ []);
	refusal = input(null, ...ngDevMode ? [{ debugName: "refusal" }] : /* istanbul ignore next */ []);
	reconfirms = input(false, ...ngDevMode ? [{ debugName: "reconfirms" }] : /* istanbul ignore next */ []);
	textChange = output();
	rows = computed(() => {
		const values = this.values();
		const editable = this.editing() && this.locked() === null;
		return this.answer().codes.map((code) => {
			const text = values[code.code] ?? code.contractText ?? code.templateText;
			return {
				code,
				label: code.description?.trim() || code.code,
				text,
				showsTemplate: text.trim() === "" || sameContractText(text, code.templateText),
				canEdit: editable && code.editable,
				remaining: remainingNoteBytes(text)
			};
		});
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	anyEditable = computed(() => this.rows().some((row) => row.canEdit), ...ngDevMode ? [{ debugName: "anyEditable" }] : /* istanbul ignore next */ []);
	change(code, text) {
		this.textChange.emit({
			code,
			text
		});
	}
	restore(row) {
		this.textChange.emit({
			code: row.code.code,
			text: row.code.templateText
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ContractTextSectionComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ContractTextSectionComponent,
		isStandalone: true,
		selector: "cws-contract-text-section",
		inputs: {
			answer: {
				classPropertyName: "answer",
				publicName: "answer",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			values: {
				classPropertyName: "values",
				publicName: "values",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			editing: {
				classPropertyName: "editing",
				publicName: "editing",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			locked: {
				classPropertyName: "locked",
				publicName: "locked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			refusal: {
				classPropertyName: "refusal",
				publicName: "refusal",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reconfirms: {
				classPropertyName: "reconfirms",
				publicName: "reconfirms",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { textChange: "textChange" },
		ngImport: i0,
		template: "<section\r\n  class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n  aria-labelledby=\"contract-text-heading\"\r\n  data-testid=\"contract-text-section\"\r\n>\r\n  <h3 id=\"contract-text-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n    Contract text\r\n    <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">({{ answer().archetype }})</span>\r\n  </h3>\r\n\r\n  @if (anyEditable()) {\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n      Each field shows the template text until you change it. Clearing a field returns it to the template.\r\n    </p>\r\n  }\r\n\r\n  @if (locked(); as reason) {\r\n    <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\" data-testid=\"contract-text-locked\">\r\n      {{ reason }}\r\n    </p>\r\n  }\r\n\r\n  @if (reconfirms()) {\r\n    <!--\r\n      #907, business question 1: a PROPOSAL pending the business's answer. Non-blocking: it says what\r\n      CTRM will do (wnr051e $ChkCfmChg on BCO and FI) and never stops the save.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning cws:mt-3\" role=\"status\" data-testid=\"contract-text-reconfirm\">\r\n      <div class=\"scoular-alert-title\">Saving will re-confirm this contract</div>\r\n      <div class=\"scoular-alert-description\">\r\n        On a {{ answer().archetype }} contract, a change to contract text makes CTRM print the confirmation\r\n        again and record a new confirmation version.\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <ol class=\"cws:mt-3 cws:space-y-4\">\r\n    @for (row of rows(); track row.code.code) {\r\n      <li class=\"cws:text-sm\" [attr.data-testid]=\"'contract-text-' + row.code.code\">\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-2\">\r\n          <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\" [id]=\"'contract-text-label-' + row.code.code\">\r\n            {{ row.label }}\r\n          </span>\r\n          <span\r\n            class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs\"\r\n            [class.cws:bg-slate-100]=\"row.showsTemplate\"\r\n            [class.cws:text-slate-700]=\"row.showsTemplate\"\r\n            [class.cws:bg-sky-100]=\"!row.showsTemplate\"\r\n            [class.cws:text-sky-800]=\"!row.showsTemplate\"\r\n            data-testid=\"contract-text-origin\"\r\n          >\r\n            {{ row.showsTemplate ? 'Template' : 'This contract' }}\r\n          </span>\r\n        </div>\r\n\r\n        @if (row.canEdit) {\r\n          <textarea\r\n            class=\"cws:mt-1 cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n            rows=\"3\"\r\n            [attr.name]=\"'contract-text-' + row.code.code\"\r\n            [attr.aria-labelledby]=\"'contract-text-label-' + row.code.code\"\r\n            [attr.aria-describedby]=\"'contract-text-count-' + row.code.code\"\r\n            [value]=\"row.text\"\r\n            (input)=\"change(row.code.code, $any($event.target).value)\"\r\n          ></textarea>\r\n          <div class=\"cws:mt-1 cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-xs\">\r\n            @if (!row.showsTemplate) {\r\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"restore(row)\">\r\n                Use the template\r\n              </button>\r\n            } @else {\r\n              <span></span>\r\n            }\r\n            <span\r\n              [id]=\"'contract-text-count-' + row.code.code\"\r\n              [class.cws:text-red-700]=\"row.remaining < 0\"\r\n              [class.cws:text-slate-500]=\"row.remaining >= 0\"\r\n            >\r\n              {{ row.remaining < 0 ? -row.remaining + ' characters over' : row.remaining + ' characters remaining' }}\r\n            </span>\r\n          </div>\r\n        } @else if (row.text.trim() !== '') {\r\n          <p class=\"cws:mt-1 cws:whitespace-pre-line cws:text-slate-900 cws:dark:text-slate-100\">{{ row.text }}</p>\r\n        } @else {\r\n          <p class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\">No text.</p>\r\n        }\r\n      </li>\r\n    }\r\n  </ol>\r\n\r\n  @if (refusal(); as reason) {\r\n    <p role=\"alert\" class=\"cws:mt-3 cws:text-sm cws:text-red-700 cws:dark:text-red-300\" data-testid=\"contract-text-refusal\">\r\n      {{ reason }}\r\n    </p>\r\n  }\r\n</section>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ContractTextSectionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-text-section",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<section\r\n  class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n  aria-labelledby=\"contract-text-heading\"\r\n  data-testid=\"contract-text-section\"\r\n>\r\n  <h3 id=\"contract-text-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n    Contract text\r\n    <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">({{ answer().archetype }})</span>\r\n  </h3>\r\n\r\n  @if (anyEditable()) {\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n      Each field shows the template text until you change it. Clearing a field returns it to the template.\r\n    </p>\r\n  }\r\n\r\n  @if (locked(); as reason) {\r\n    <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\" data-testid=\"contract-text-locked\">\r\n      {{ reason }}\r\n    </p>\r\n  }\r\n\r\n  @if (reconfirms()) {\r\n    <!--\r\n      #907, business question 1: a PROPOSAL pending the business's answer. Non-blocking: it says what\r\n      CTRM will do (wnr051e $ChkCfmChg on BCO and FI) and never stops the save.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning cws:mt-3\" role=\"status\" data-testid=\"contract-text-reconfirm\">\r\n      <div class=\"scoular-alert-title\">Saving will re-confirm this contract</div>\r\n      <div class=\"scoular-alert-description\">\r\n        On a {{ answer().archetype }} contract, a change to contract text makes CTRM print the confirmation\r\n        again and record a new confirmation version.\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <ol class=\"cws:mt-3 cws:space-y-4\">\r\n    @for (row of rows(); track row.code.code) {\r\n      <li class=\"cws:text-sm\" [attr.data-testid]=\"'contract-text-' + row.code.code\">\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-2\">\r\n          <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\" [id]=\"'contract-text-label-' + row.code.code\">\r\n            {{ row.label }}\r\n          </span>\r\n          <span\r\n            class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs\"\r\n            [class.cws:bg-slate-100]=\"row.showsTemplate\"\r\n            [class.cws:text-slate-700]=\"row.showsTemplate\"\r\n            [class.cws:bg-sky-100]=\"!row.showsTemplate\"\r\n            [class.cws:text-sky-800]=\"!row.showsTemplate\"\r\n            data-testid=\"contract-text-origin\"\r\n          >\r\n            {{ row.showsTemplate ? 'Template' : 'This contract' }}\r\n          </span>\r\n        </div>\r\n\r\n        @if (row.canEdit) {\r\n          <textarea\r\n            class=\"cws:mt-1 cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n            rows=\"3\"\r\n            [attr.name]=\"'contract-text-' + row.code.code\"\r\n            [attr.aria-labelledby]=\"'contract-text-label-' + row.code.code\"\r\n            [attr.aria-describedby]=\"'contract-text-count-' + row.code.code\"\r\n            [value]=\"row.text\"\r\n            (input)=\"change(row.code.code, $any($event.target).value)\"\r\n          ></textarea>\r\n          <div class=\"cws:mt-1 cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-xs\">\r\n            @if (!row.showsTemplate) {\r\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"restore(row)\">\r\n                Use the template\r\n              </button>\r\n            } @else {\r\n              <span></span>\r\n            }\r\n            <span\r\n              [id]=\"'contract-text-count-' + row.code.code\"\r\n              [class.cws:text-red-700]=\"row.remaining < 0\"\r\n              [class.cws:text-slate-500]=\"row.remaining >= 0\"\r\n            >\r\n              {{ row.remaining < 0 ? -row.remaining + ' characters over' : row.remaining + ' characters remaining' }}\r\n            </span>\r\n          </div>\r\n        } @else if (row.text.trim() !== '') {\r\n          <p class=\"cws:mt-1 cws:whitespace-pre-line cws:text-slate-900 cws:dark:text-slate-100\">{{ row.text }}</p>\r\n        } @else {\r\n          <p class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\">No text.</p>\r\n        }\r\n      </li>\r\n    }\r\n  </ol>\r\n\r\n  @if (refusal(); as reason) {\r\n    <p role=\"alert\" class=\"cws:mt-3 cws:text-sm cws:text-red-700 cws:dark:text-red-300\" data-testid=\"contract-text-refusal\">\r\n      {{ reason }}\r\n    </p>\r\n  }\r\n</section>\r\n"
		}]
	}],
	propDecorators: {
		answer: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "answer",
				required: true
			}]
		}],
		values: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "values",
				required: true
			}]
		}],
		editing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editing",
				required: false
			}]
		}],
		locked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "locked",
				required: false
			}]
		}],
		refusal: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "refusal",
				required: false
			}]
		}],
		reconfirms: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reconfirms",
				required: false
			}]
		}],
		textChange: [{
			type: i0.Output,
			args: ["textChange"]
		}]
	}
});
var PricingCopyStore = class PricingCopyStore {
	entries = signal(/* @__PURE__ */ new Map(), ...ngDevMode ? [{ debugName: "entries" }] : /* istanbul ignore next */ []);
	entry(target) {
		return this.entries().get(target) ?? null;
	}
	start(pricing, source, target) {
		this.put({
			source,
			target,
			run: null,
			failure: null
		});
		pricing.contractPrices(source).pipe(filter((state) => state.status === "loaded" || state.status === "error"), take(1)).subscribe((state) => {
			if (state.status !== "loaded") {
				this.put({
					source,
					target,
					run: null,
					failure: `The prices of ${source} could not be read, so none were copied. ${target} was created and stands.`
				});
				return;
			}
			copyPriceSequences(pricing, target, state.value.prices).subscribe((run) => this.put({
				source,
				target,
				run,
				failure: null
			}));
		});
	}
	retryNotCopied(pricing, target) {
		const entry = this.entry(target);
		const rows = entry?.run?.rows ?? [];
		const indexes = rows.flatMap((row, index) => row.outcome === "not-copied" ? [index] : []);
		if (entry === null || entry.run === null || indexes.length === 0) return;
		const original = entry.run;
		copyPriceSequences(pricing, target, indexes.map((index) => rows[index].source)).subscribe((retry) => {
			const merged = [...original.rows];
			retry.rows.forEach((row, position) => merged[indexes[position]] = row);
			this.put({
				...entry,
				run: {
					target,
					rows: merged,
					done: retry.done
				}
			});
		});
	}
	dismiss(target) {
		const next = new Map(this.entries());
		next.delete(target);
		this.entries.set(next);
	}
	put(entry) {
		this.entries.set(new Map(this.entries()).set(entry.target, entry));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: PricingCopyStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: PricingCopyStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: PricingCopyStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var PricingCopyPanelComponent = class PricingCopyPanelComponent {
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	store = inject(PricingCopyStore);
	pricing = inject(PRICING_SOURCE, { optional: true });
	host = inject(CMS_HOST_CONTEXT);
	entry = computed(() => this.store.entry(this.contractNumber()), ...ngDevMode ? [{ debugName: "entry" }] : /* istanbul ignore next */ []);
	rows = computed(() => this.entry()?.run?.rows ?? [], ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	done = computed(() => this.entry()?.run?.done ?? false, ...ngDevMode ? [{ debugName: "done" }] : /* istanbul ignore next */ []);
	count = (outcome) => this.rows().filter((row) => row.outcome === outcome).length;
	copied = computed(() => this.count("copied"), ...ngDevMode ? [{ debugName: "copied" }] : /* istanbul ignore next */ []);
	notCopied = computed(() => this.count("not-copied"), ...ngDevMode ? [{ debugName: "notCopied" }] : /* istanbul ignore next */ []);
	unconfirmed = computed(() => this.count("unconfirmed"), ...ngDevMode ? [{ debugName: "unconfirmed" }] : /* istanbul ignore next */ []);
	summary = computed(() => {
		const entry = this.entry();
		const total = this.rows().length;
		if (entry === null || entry.run === null) return `Copying prices from ${entry?.source ?? "the source contract"}…`;
		if (!this.done()) {
			const settled = this.rows().filter((row) => row.outcome !== "pending").length;
			return `Copying prices from ${entry.source}: ${settled} of ${total}, one at a time.`;
		}
		if (total === 0) return `${entry.source} has no price sequences, so none were copied.`;
		if (this.copied() === 0) return `No price was copied. ${entry.target} was created and stands; add its prices on its pricing page, or retry the ones not copied.`;
		const tail = this.unconfirmed() > 0 ? " An unconfirmed price may already be on the contract: check its pricing before adding it again." : "";
		return `${this.copied()} of ${total} price sequences copied from ${entry.source}, each UNAPPROVED.${tail}`;
	}, ...ngDevMode ? [{ debugName: "summary" }] : /* istanbul ignore next */ []);
	canRetry = computed(() => this.done() && this.notCopied() > 0 && this.pricing !== null, ...ngDevMode ? [{ debugName: "canRetry" }] : /* istanbul ignore next */ []);
	outcomeLabel(row) {
		switch (row.outcome) {
			case "copied": return "Copied";
			case "not-copied": return "Not copied";
			case "unconfirmed": return "Unconfirmed";
			default: return "Waiting";
		}
	}
	retry() {
		if (this.pricing !== null) this.store.retryNotCopied(this.pricing, this.contractNumber());
	}
	openPricing() {
		this.host.navigate({
			kind: "review",
			origin: "pricing",
			contractNumber: this.contractNumber(),
			params: {}
		});
	}
	dismiss() {
		this.store.dismiss(this.contractNumber());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: PricingCopyPanelComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: PricingCopyPanelComponent,
		isStandalone: true,
		selector: "cws-pricing-copy-panel",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0,
		template: "@if (entry(); as current) {\r\n  <section\r\n    class=\"scoular-card cws:space-y-3 cws:p-4\"\r\n    role=\"region\"\r\n    [attr.aria-label]=\"'Prices copied from ' + current.source\"\r\n  >\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-start cws:justify-between cws:gap-3\">\r\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        Prices copied from {{ current.source }}\r\n      </h3>\r\n      <div class=\"cws:flex cws:flex-wrap cws:gap-2\">\r\n        @if (canRetry()) {\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-primary scoular-btn-sm\" (click)=\"retry()\">\r\n            Retry the {{ notCopied() }} not copied\r\n          </button>\r\n        }\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-outline scoular-btn-sm\" (click)=\"openPricing()\">\r\n          Open its pricing\r\n        </button>\r\n        @if (done() || current.failure !== null) {\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-outline scoular-btn-sm\" (click)=\"dismiss()\">\r\n            Dismiss\r\n          </button>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n    @if (current.failure; as failure) {\r\n      <p class=\"cws:text-sm cws:text-rose-700 cws:dark:text-rose-300\" role=\"alert\">{{ failure }}</p>\r\n    } @else {\r\n      <p class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"copy-summary\" role=\"status\">\r\n        {{ summary() }}\r\n      </p>\r\n\r\n      @if (rows().length > 0) {\r\n        <table class=\"cws:w-full cws:text-left cws:text-sm\">\r\n          <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Sequence</th>\r\n              <th class=\"cws:py-1\">Price</th>\r\n              <th class=\"cws:py-1\">Priced quantity</th>\r\n              <th class=\"cws:py-1\">Outcome</th>\r\n              <th class=\"cws:py-1\">On this contract</th>\r\n              <th class=\"cws:py-1\">Note</th>\r\n            </tr>\r\n          </thead>\r\n          <tbody>\r\n            @for (row of rows(); track row.source.priceSequence) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.source.priceSequence }}</td>\r\n                <td class=\"cws:py-1\">{{ row.source.price }}</td>\r\n                <td class=\"cws:py-1\">{{ row.source.pricedQuantity }}</td>\r\n                <td class=\"cws:py-1 cws:font-medium\" data-testid=\"copy-outcome\"\r\n                    [class.cws:text-emerald-700]=\"row.outcome === 'copied'\"\r\n                    [class.cws:text-rose-700]=\"row.outcome === 'not-copied'\"\r\n                    [class.cws:text-amber-700]=\"row.outcome === 'unconfirmed'\">\r\n                  {{ outcomeLabel(row) }}\r\n                </td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.newSequence ?? '—' }}</td>\r\n                <td class=\"cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  <span>{{ row.reason }}</span>\r\n                  @if (row.outcome === 'not-copied') {\r\n                    <!-- #803: a row that was not copied carries the server's reference, or says why not. -->\r\n                    <cms-reference-line [correlationId]=\"row.correlationId\" />\r\n                  }\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n    }\r\n  </section>\r\n}\r\n",
		dependencies: [{
			kind: "component",
			type: ReferenceLineComponent,
			selector: "cms-reference-line",
			inputs: ["correlationId", "sent"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: PricingCopyPanelComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-pricing-copy-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ReferenceLineComponent],
			template: "@if (entry(); as current) {\r\n  <section\r\n    class=\"scoular-card cws:space-y-3 cws:p-4\"\r\n    role=\"region\"\r\n    [attr.aria-label]=\"'Prices copied from ' + current.source\"\r\n  >\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-start cws:justify-between cws:gap-3\">\r\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        Prices copied from {{ current.source }}\r\n      </h3>\r\n      <div class=\"cws:flex cws:flex-wrap cws:gap-2\">\r\n        @if (canRetry()) {\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-primary scoular-btn-sm\" (click)=\"retry()\">\r\n            Retry the {{ notCopied() }} not copied\r\n          </button>\r\n        }\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-outline scoular-btn-sm\" (click)=\"openPricing()\">\r\n          Open its pricing\r\n        </button>\r\n        @if (done() || current.failure !== null) {\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-outline scoular-btn-sm\" (click)=\"dismiss()\">\r\n            Dismiss\r\n          </button>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n    @if (current.failure; as failure) {\r\n      <p class=\"cws:text-sm cws:text-rose-700 cws:dark:text-rose-300\" role=\"alert\">{{ failure }}</p>\r\n    } @else {\r\n      <p class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"copy-summary\" role=\"status\">\r\n        {{ summary() }}\r\n      </p>\r\n\r\n      @if (rows().length > 0) {\r\n        <table class=\"cws:w-full cws:text-left cws:text-sm\">\r\n          <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Sequence</th>\r\n              <th class=\"cws:py-1\">Price</th>\r\n              <th class=\"cws:py-1\">Priced quantity</th>\r\n              <th class=\"cws:py-1\">Outcome</th>\r\n              <th class=\"cws:py-1\">On this contract</th>\r\n              <th class=\"cws:py-1\">Note</th>\r\n            </tr>\r\n          </thead>\r\n          <tbody>\r\n            @for (row of rows(); track row.source.priceSequence) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.source.priceSequence }}</td>\r\n                <td class=\"cws:py-1\">{{ row.source.price }}</td>\r\n                <td class=\"cws:py-1\">{{ row.source.pricedQuantity }}</td>\r\n                <td class=\"cws:py-1 cws:font-medium\" data-testid=\"copy-outcome\"\r\n                    [class.cws:text-emerald-700]=\"row.outcome === 'copied'\"\r\n                    [class.cws:text-rose-700]=\"row.outcome === 'not-copied'\"\r\n                    [class.cws:text-amber-700]=\"row.outcome === 'unconfirmed'\">\r\n                  {{ outcomeLabel(row) }}\r\n                </td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.newSequence ?? '—' }}</td>\r\n                <td class=\"cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  <span>{{ row.reason }}</span>\r\n                  @if (row.outcome === 'not-copied') {\r\n                    <!-- #803: a row that was not copied carries the server's reference, or says why not. -->\r\n                    <cms-reference-line [correlationId]=\"row.correlationId\" />\r\n                  }\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n    }\r\n  </section>\r\n}\r\n"
		}]
	}],
	propDecorators: { contractNumber: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "contractNumber",
			required: true
		}]
	}] }
});
const CONTRACT_KEY_REQUIRED = [
	"ContractPrefixType",
	"ContractPrefixCommodity",
	"ContractNumber"
];
function withContractKeyRequired(config) {
	return {
		...config,
		sections: config.sections.map((section) => ({
			...section,
			fields: section.fields.map((field) => CONTRACT_KEY_REQUIRED.includes(field.componentName) ? {
				...field,
				behaviour: {
					...field.behaviour,
					required: true
				},
				mandatedFlags: field.mandatedFlags.includes("required") ? field.mandatedFlags : [...field.mandatedFlags, "required"]
			} : field)
		}))
	};
}
const CONFIRMATION_STYLE = {
	positive: {
		chip: "cws:bg-emerald-50 cws:dark:bg-emerald-500/10",
		dot: "cws:bg-emerald-500",
		text: "cws:text-emerald-700 cws:dark:text-emerald-300"
	},
	caution: {
		chip: "cws:bg-amber-50 cws:dark:bg-amber-500/10",
		dot: "cws:bg-amber-500",
		text: "cws:text-amber-700 cws:dark:text-amber-300"
	},
	negative: {
		chip: "cws:bg-rose-50 cws:dark:bg-rose-500/10",
		dot: "cws:bg-rose-500",
		text: "cws:text-rose-700 cws:dark:text-rose-300"
	},
	info: {
		chip: "cws:bg-sky-50 cws:dark:bg-sky-500/10",
		dot: "cws:bg-sky-500",
		text: "cws:text-sky-700 cws:dark:text-sky-300"
	},
	neutral: {
		chip: "cws:bg-slate-100 cws:dark:bg-slate-700/40",
		dot: "cws:bg-slate-400 cws:dark:bg-slate-500",
		text: "cws:text-slate-600 cws:dark:text-slate-300"
	}
};
var ContractRecordPageComponent = class ContractRecordPageComponent {
	details = inject(CONTRACT_DETAIL_SOURCE);
	writes = inject(CONTRACT_WRITE_SOURCE);
	mintIdempotencyKey = inject(CONTRACT_IDEMPOTENCY_KEY);
	createKey = null;
	numbers = inject(CONTRACT_NUMBER_SOURCE);
	configs = inject(FORM_CONFIG_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	events = inject(CwsContractEvents);
	requestNavigation(intent) {
		this.hostContext.navigate(intent);
		this.events.emit({
			type: "navigation-requested",
			intent
		});
	}
	customers = inject(CUSTOMER_SOURCE, { optional: true });
	customerConfirmation = signal(null, ...ngDevMode ? [{ debugName: "customerConfirmation" }] : /* istanbul ignore next */ []);
	tradeUnitLabel = injectTradeUnitLabel();
	contractNumber = input("", {
		...ngDevMode ? { debugName: "contractNumber" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? ""
	});
	mode = input("view", {
		...ngDevMode ? { debugName: "mode" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "view"
	});
	isCreate = computed(() => this.mode() === "create", ...ngDevMode ? [{ debugName: "isCreate" }] : /* istanbul ignore next */ []);
	isView = computed(() => this.mode() === "view", ...ngDevMode ? [{ debugName: "isView" }] : /* istanbul ignore next */ []);
	externalLinks = inject(CWS_EXTERNAL_LINKS);
	fileBoundUrl = computed(() => this.isCreate() ? null : fileBoundUrlFor(this.externalLinks, this.contractNumber()), ...ngDevMode ? [{ debugName: "fileBoundUrl" }] : /* istanbul ignore next */ []);
	locationCodes = injectLocationCodes();
	intercompany = computed(() => classifyIntercompany({
		customerId: this.ctrmFieldValue("customer_id"),
		locationCodes: this.locationCodes()
	}), ...ngDevMode ? [{ debugName: "intercompany" }] : /* istanbul ignore next */ []);
	intercompanyLock = computed(() => isIntercompanyPurchase(this.intercompany(), this.ctrmFieldValue("contract_prefix_type")), ...ngDevMode ? [{ debugName: "intercompanyLock" }] : /* istanbul ignore next */ []);
	ctrmFieldValue(ctrmField) {
		const held = this.ctrmValues()?.[ctrmField];
		return typeof held === "string" && held.trim() !== "" ? held : null;
	}
	isEditable = computed(() => !this.isView() && !this.contractReadOnly(), ...ngDevMode ? [{ debugName: "isEditable" }] : /* istanbul ignore next */ []);
	contractReadOnly = computed(() => this.isClosed() || this.intercompanyLock(), ...ngDevMode ? [{ debugName: "contractReadOnly" }] : /* istanbul ignore next */ []);
	readOnlyReason = computed(() => this.isClosed() ? CLOSED_REFUSAL : this.intercompanyLock() ? INTERCOMPANY_PURCHASE_REFUSAL : null, ...ngDevMode ? [{ debugName: "readOnlyReason" }] : /* istanbul ignore next */ []);
	route = inject(ActivatedRoute);
	returnTo = this.route.snapshot.queryParamMap.get("returnTo");
	copyFrom = this.route.snapshot.queryParamMap.get("copyFrom");
	linkCustomer = linkParam(this.route, "customer");
	linkTemplate = linkParam(this.route, "template");
	linkTradeUnit = linkParam(this.route, "tradeUnit");
	linkTradeUnitRefused = computed(() => this.isCreate() && this.linkTradeUnit !== null && this.linkTradeUnit !== this.tradeUnit.code(), ...ngDevMode ? [{ debugName: "linkTradeUnitRefused" }] : /* istanbul ignore next */ []);
	activeTradeUnit = computed(() => this.tradeUnit.code(), ...ngDevMode ? [{ debugName: "activeTradeUnit" }] : /* istanbul ignore next */ []);
	linkTemplateRefusal = signal(null, ...ngDevMode ? [{ debugName: "linkTemplateRefusal" }] : /* istanbul ignore next */ []);
	linkTemplateSettled = false;
	applyLinkTemplate = effect(() => {
		const wanted = this.linkTemplate;
		if (wanted === null || this.linkTemplateSettled || !this.isCreate() || this.builtForm() === null) return;
		if (!this.canUseTemplates()) {
			this.linkTemplateSettled = true;
			this.linkTemplateRefusal.set("unsupported");
			return;
		}
		const state = this.templateList();
		if (state.status === "loading" || state.status === "idle") return;
		this.linkTemplateSettled = true;
		if (state.status === "error") {
			this.linkTemplateRefusal.set("unreadable");
			return;
		}
		const name = wanted.toLowerCase();
		const match = state.value.find((each) => String(each.id) === wanted) ?? state.value.find((each) => each.name.trim().toLowerCase() === name);
		if (match === void 0) {
			this.linkTemplateRefusal.set("missing");
			return;
		}
		untracked(() => this.onApplyTemplate(String(match.id)));
	}, ...ngDevMode ? [{ debugName: "applyLinkTemplate" }] : /* istanbul ignore next */ []);
	pricing = inject(PRICING_SOURCE, { optional: true });
	pricingCopies = inject(PricingCopyStore);
	addendumLists = inject(ADDENDUM_LIST_SOURCE, { optional: true });
	addendumListAttempt = signal(0, ...ngDevMode ? [{ debugName: "addendumListAttempt" }] : /* istanbul ignore next */ []);
	hasAddendumSection = computed(() => this.addendumType() !== null || this.saveErrorGroups().addendum.length > 0, ...ngDevMode ? [{ debugName: "hasAddendumSection" }] : /* istanbul ignore next */ []);
	addendumListRead = toSignal(toObservable(computed(() => ({
		number: this.contractNumber().trim(),
		attempt: this.attempt(),
		saved: this.addendumListAttempt(),
		section: this.hasAddendumSection()
	}))).pipe(switchMap(({ number, section }) => this.addendumLists === null || number.length === 0 || !section ? of(null) : this.addendumLists.list(number).pipe(catchError(() => of({
		kind: "failed",
		message: "The stored addendums could not be listed. Please try again."
	})), map((call) => ({
		number,
		call
	}))))), { initialValue: null });
	currentAddendumListRead = computed(() => {
		const read = this.addendumListRead();
		return read !== null && read.number === this.contractNumber().trim() ? read : null;
	}, ...ngDevMode ? [{ debugName: "currentAddendumListRead" }] : /* istanbul ignore next */ []);
	addendumSummary = computed(() => {
		const read = this.currentAddendumListRead();
		return read !== null && read.call.kind === "done" ? summarizeAddendumList(read.number, read.call.value) : {
			current: null,
			earlier: 0
		};
	}, ...ngDevMode ? [{ debugName: "addendumSummary" }] : /* istanbul ignore next */ []);
	storedAddendum = computed(() => this.addendumSummary().current, ...ngDevMode ? [{ debugName: "storedAddendum" }] : /* istanbul ignore next */ []);
	earlierAddendums = computed(() => this.addendumSummary().earlier, ...ngDevMode ? [{ debugName: "earlierAddendums" }] : /* istanbul ignore next */ []);
	addendumListProblem = computed(() => {
		const call = this.currentAddendumListRead()?.call;
		return call !== void 0 && (call.kind === "failed" || call.kind === "conflict") ? call.message : null;
	}, ...ngDevMode ? [{ debugName: "addendumListProblem" }] : /* istanbul ignore next */ []);
	saveAnnouncements = inject(SaveAnnouncementStore);
	arrivedAfterSave = signal(null, ...ngDevMode ? [{ debugName: "arrivedAfterSave" }] : /* istanbul ignore next */ []);
	pricingCopyOffered = this.pricing !== null;
	isCopyWithPricing = computed(() => this.isCopy() && this.route.snapshot.queryParamMap.get("withPricing") === "true" && this.pricing !== null, ...ngDevMode ? [{ debugName: "isCopyWithPricing" }] : /* istanbul ignore next */ []);
	copyPricingConfirm = signal(false, ...ngDevMode ? [{ debugName: "copyPricingConfirm" }] : /* istanbul ignore next */ []);
	sourcePriceCount = computed(() => this.contract()?.prices.length ?? 0, ...ngDevMode ? [{ debugName: "sourcePriceCount" }] : /* istanbul ignore next */ []);
	copyWithPricingIntent = computed(() => ({
		kind: "new-contract",
		params: {
			copyFrom: this.contractNumber(),
			withPricing: "true"
		}
	}), ...ngDevMode ? [{ debugName: "copyWithPricingIntent" }] : /* istanbul ignore next */ []);
	confirmCopyWithPricing() {
		this.copyPricingConfirm.set(false);
		this.requestNavigation(this.copyWithPricingIntent());
	}
	returnParams = computed(() => Object.fromEntries(new URLSearchParams(this.returnTo ?? "")), ...ngDevMode ? [{ debugName: "returnParams" }] : /* istanbul ignore next */ []);
	originParam = this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM);
	origin = computed(() => recordOrigin(this.originParam), ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	trail = computed(() => recordTrail(this.origin(), this.contractNumber()), ...ngDevMode ? [{ debugName: "trail" }] : /* istanbul ignore next */ []);
	editIntent = computed(() => ({
		kind: "contract",
		contractNumber: this.contractNumber(),
		mode: "edit",
		params: this.editParams()
	}), ...ngDevMode ? [{ debugName: "editIntent" }] : /* istanbul ignore next */ []);
	newIntent = {
		kind: "new-contract",
		params: {}
	};
	copyIntent = computed(() => ({
		kind: "new-contract",
		params: { copyFrom: this.contractNumber() }
	}), ...ngDevMode ? [{ debugName: "copyIntent" }] : /* istanbul ignore next */ []);
	cancelIntent = computed(() => this.isCreate() ? {
		kind: "origin",
		origin: "contracts",
		params: {}
	} : {
		kind: "contract",
		contractNumber: this.contractNumber(),
		params: this.cancelParams()
	}, ...ngDevMode ? [{ debugName: "cancelIntent" }] : /* istanbul ignore next */ []);
	crumbs = computed(() => this.trail().map((crumb, index) => {
		const intent = index === 0 ? {
			kind: "origin",
			origin: this.originParam ?? "",
			params: this.returnParams()
		} : {
			kind: "review",
			origin: this.originParam ?? "",
			contractNumber: this.contractNumber(),
			params: this.returnParams()
		};
		return {
			...crumb,
			link: {
				href: this.hrefFor(intent),
				follow: (event) => this.follow(event, intent)
			}
		};
	}), ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	hrefFor(intent) {
		return this.hostContext.hrefFor(intent);
	}
	cancelDisabled = computed(() => this.save().status === "saving", ...ngDevMode ? [{ debugName: "cancelDisabled" }] : /* istanbul ignore next */ []);
	savedPanelTitle = computed(() => {
		const result = this.save().result;
		if (result === void 0) return "";
		const number = (result.contractNumber ?? "").trim() || this.contractNumber();
		return savedSentence(result.action, number, this.isCopy() ? (this.copyFrom ?? "").trim() : null);
	}, ...ngDevMode ? [{ debugName: "savedPanelTitle" }] : /* istanbul ignore next */ []);
	followCancel(event) {
		if (this.cancelDisabled()) {
			event.preventDefault();
			return;
		}
		this.follow(event, this.cancelIntent());
	}
	follow(event, intent) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.requestNavigation(intent);
	}
	currentCrumb = computed(() => {
		switch (this.mode()) {
			case "create": return "New contract";
			case "edit": return `${this.contractNumber()} — editing`;
			default: return this.contractNumber();
		}
	}, ...ngDevMode ? [{ debugName: "currentCrumb" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	createDrivers = signal({}, ...ngDevMode ? [{ debugName: "createDrivers" }] : /* istanbul ignore next */ []);
	resolutionKey = computed(() => {
		this.attempt();
		if (!this.isCreate() && this.contractNumber() !== "") return { contractNumber: this.contractNumber() };
		const drivers = this.createDrivers();
		return {
			...this.tradeUnit.code() !== null ? { locationCode: this.tradeUnit.code() } : {},
			...drivers.textClass !== void 0 ? { contractTypeClass: drivers.textClass } : {},
			...drivers.commodity !== void 0 ? { commodityCode: drivers.commodity } : {}
		};
	}, ...ngDevMode ? [{ debugName: "resolutionKey" }] : /* istanbul ignore next */ []);
	configState = toSignal(toObservable(this.resolutionKey).pipe(switchMap((key) => this.configs.load(key))), { initialValue: remoteLoading() });
	retainedBundle = linkedSignal({
		...ngDevMode ? { debugName: "retainedBundle" } : /* istanbul ignore next */ {},
		source: this.configState,
		computation: (state, previous) => state.status === "loaded" ? state.value : previous?.value ?? null
	});
	bundle = computed(() => {
		const retained = this.retainedBundle();
		return retained === null ? null : {
			...retained,
			config: withContractKeyRequired(withSavedCodeDescriptions(withMarketMonths(withResolvedTrader(retained.config, this.contract()), this.marketMonths()), this.savedCodePairs(), this.isView() ? "view" : "edit", this.changedCodes()))
		};
	}, ...ngDevMode ? [{ debugName: "bundle" }] : /* istanbul ignore next */ []);
	savedCodePairs = computed(() => {
		const values = this.ctrmValues();
		return this.isCreate() || values === null ? /* @__PURE__ */ new Map() : savedCodeDescriptions(values);
	}, ...ngDevMode ? [{ debugName: "savedCodePairs" }] : /* istanbul ignore next */ []);
	changedValues = signal(/* @__PURE__ */ new Map(), ...ngDevMode ? [{ debugName: "changedValues" }] : /* istanbul ignore next */ []);
	watchChangedValues(form) {
		const text = (value) => value === null || value === void 0 ? "" : String(value).trim();
		const snapshot = () => {
			const seeded = this.initialValues();
			const changed = /* @__PURE__ */ new Map();
			for (const field of CONTRACT_LAYOUT_FIELDS) {
				const control = form.control(field.componentName);
				if (control?.dirty && text(control.value) !== text(seeded[field.componentName])) changed.set(field.componentName, control.value);
			}
			return changed;
		};
		this.changedValues.set(snapshot());
		form.group.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.changedValues.set(snapshot()));
	}
	changedCodes = computed(() => {
		const changed = this.changedValues();
		const codes = /* @__PURE__ */ new Map();
		for (const field of CONTRACT_LAYOUT_FIELDS) if (field.descriptionField !== void 0 && changed.has(field.componentName)) {
			const value = changed.get(field.componentName);
			codes.set(field.componentName, typeof value === "string" ? value : null);
		}
		return codes;
	}, ...ngDevMode ? [{ debugName: "changedCodes" }] : /* istanbul ignore next */ []);
	confirmChgChanges = computed(() => {
		const header = this.contract()?.header;
		if (this.isView() || this.isCreate() || header === void 0) return null;
		if (confirmationProgress(header).find((stage) => stage.key === "customer")?.state !== "complete") return null;
		const material = confirmChgComponents(this.cascadeFacts()?.priceType ?? null);
		const labels = CONTRACT_LAYOUT_FIELDS.filter((field) => material.has(field.componentName) && this.changedValues().has(field.componentName)).map((field) => field.label);
		return labels.length === 0 ? null : labels;
	}, ...ngDevMode ? [{ debugName: "confirmChgChanges" }] : /* istanbul ignore next */ []);
	containerState = computed(() => {
		const config = this.configState();
		const retained = this.retainedBundle();
		if (config.status === "error" || config.status !== "loaded" && retained === null) return config;
		const aggregate = this.aggregate();
		if (aggregate !== null && aggregate.status !== "loaded") return aggregate;
		return config.status === "loaded" ? config : remoteLoaded(retained);
	}, ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	aggregate = toSignal(toObservable(computed(() => ({
		number: this.contractNumber(),
		create: this.isCreate(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ number, create }) => create || number.trim().length === 0 ? of(null) : this.details.get(number))), { initialValue: null });
	response = computed(() => {
		const override = this.stateOverride();
		if (override !== null && override.contract.header.contractNumber === this.contractNumber()) return override;
		const state = this.aggregate();
		return state !== null && state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "response" }] : /* istanbul ignore next */ []);
	lastAnnouncedLoad = null;
	announceLoad = effect(() => {
		const state = this.aggregate();
		const mode = this.mode();
		const contractNumber = this.contractNumber();
		if (state === null || mode === "create" || state.status !== "loaded" && state.status !== "error") return;
		const key = `${this.attempt()}|${contractNumber}|${state.status}`;
		if (key === this.lastAnnouncedLoad) return;
		this.lastAnnouncedLoad = key;
		untracked(() => this.events.emit(state.status === "loaded" ? {
			type: "contract-opened",
			contractNumber,
			mode
		} : {
			type: "error",
			operation: "load",
			contractNumber,
			message: state.error.message,
			...state.error.correlationId === void 0 ? {} : { correlationId: state.error.correlationId }
		}));
	}, ...ngDevMode ? [{ debugName: "announceLoad" }] : /* istanbul ignore next */ []);
	contract = computed(() => this.response()?.contract ?? null, ...ngDevMode ? [{ debugName: "contract" }] : /* istanbul ignore next */ []);
	prefill = toSignal(toObservable(computed(() => ({
		number: this.contractNumber(),
		create: this.isCreate(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ number, create }) => create || number.trim().length === 0 ? of({ status: "absent" }) : this.writes.fields(number).pipe(map((value) => ({
		status: "loaded",
		fields: value.fields
	})), catchError(() => of({ status: "failed" })), startWith({ status: "loading" })))), { initialValue: { status: "loading" } });
	copySource = toSignal(toObservable(computed(() => ({
		source: this.copyFrom,
		create: this.isCreate(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ source, create }) => !create || source === null || source.trim().length === 0 ? of({ status: "absent" }) : this.writes.fields(source).pipe(map((value) => ({
		status: "loaded",
		fields: value.fields
	})), catchError(() => of({ status: "failed" })), startWith({ status: "loading" })))), { initialValue: { status: "loading" } });
	isCopy = computed(() => this.isCreate() && this.copyFrom !== null && this.copyFrom.trim().length > 0, ...ngDevMode ? [{ debugName: "isCopy" }] : /* istanbul ignore next */ []);
	copyFailed = computed(() => this.isCopy() && this.copySource().status === "failed", ...ngDevMode ? [{ debugName: "copyFailed" }] : /* istanbul ignore next */ []);
	copySourceDetail = toSignal(toObservable(computed(() => ({
		source: this.copyFrom,
		copy: this.isCopy(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ source, copy }) => !copy || source === null ? of(null) : this.details.get(source.trim()).pipe(catchError(() => of(remoteError({ message: "unread" })))))), { initialValue: null });
	collectionCopy = computed(() => {
		const detail = this.copySourceDetail();
		const bundle = this.bundle();
		if (!this.isCopy() || this.copySource().status !== "loaded" || detail === null || bundle === null) return null;
		if (detail.status !== "loaded" && detail.status !== "error") return null;
		return planCollectionCopy({
			source: detail.status === "loaded" ? detail.value : null,
			catalog: bundle.constraints?.document.collections ?? null,
			behaviour: bundle.config.collections
		});
	}, ...ngDevMode ? [{ debugName: "collectionCopy" }] : /* istanbul ignore next */ []);
	copySummary = computed(() => {
		const plan = this.collectionCopy();
		const carried = (plan?.outcomes ?? []).filter((outcome) => outcome.status === "carried").map((outcome) => outcome.name);
		const what = carried.length > 0 ? `its ${listCollections(carried)} were copied` : "no collections were copied";
		const prices = this.isCopyWithPricing() && plan?.pricesExcluded !== true ? "; its prices are copied once this contract is created" : "";
		return `Copied from ${this.copyFrom} — ${what}${prices}`;
	}, ...ngDevMode ? [{ debugName: "copySummary" }] : /* istanbul ignore next */ []);
	collectionCopySentences = computed(() => {
		const plan = this.collectionCopy();
		return plan === null ? [] : describeCollectionCopy(plan, this.isCopyWithPricing());
	}, ...ngDevMode ? [{ debugName: "collectionCopySentences" }] : /* istanbul ignore next */ []);
	copiedShipPeriods = signal([], ...ngDevMode ? [{ debugName: "copiedShipPeriods" }] : /* istanbul ignore next */ []);
	copiedCollectionsSeeded = false;
	seedCopiedCollections = effect(() => {
		const plan = this.collectionCopy();
		if (plan === null || this.copiedCollectionsSeeded) return;
		this.copiedCollectionsSeeded = true;
		const rows = plan.shipPeriods.map(shipPeriodRowOf);
		untracked(() => {
			if (rows.length > 0) {
				this.copiedShipPeriods.set(rows);
				this.shipPeriodRows.set(rows);
			}
			if (plan.remarks.length > 0) this.remarkValues.set(remarkValuesOf(plan.remarks));
		});
	}, ...ngDevMode ? [{ debugName: "seedCopiedCollections" }] : /* istanbul ignore next */ []);
	copiedValues = computed(() => {
		const state = this.copySource();
		if (state.status !== "loaded") return {};
		return copyableValues(state.fields, copyExclusions(this.bundle()?.config ?? null));
	}, ...ngDevMode ? [{ debugName: "copiedValues" }] : /* istanbul ignore next */ []);
	valuesReady = computed(() => {
		if (this.isCreate()) {
			const copy = this.copySource().status;
			if (!this.isCopy() || copy === "failed") return true;
			const detail = this.copySourceDetail()?.status;
			return copy === "loaded" && (detail === "loaded" || detail === "error");
		}
		const status = this.prefill().status;
		return status === "loaded" || status === "failed";
	}, ...ngDevMode ? [{ debugName: "valuesReady" }] : /* istanbul ignore next */ []);
	ctrmValues = computed(() => {
		const state = this.prefill();
		return state.status === "loaded" ? state.fields : null;
	}, ...ngDevMode ? [{ debugName: "ctrmValues" }] : /* istanbul ignore next */ []);
	values = computed(() => mergeContractValues(this.contract(), this.ctrmValues()), ...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	initialValues = computed(() => seedFromCtrmValues(this.values()), ...ngDevMode ? [{ debugName: "initialValues" }] : /* istanbul ignore next */ []);
	defaultValues = computed(() => {
		if (!this.isCreate()) return {};
		const code = this.tradeUnit.code();
		const issued = this.issuedNumber();
		return {
			...code === null || code === "" ? {} : { Location: code },
			...this.copiedValues(),
			...this.linkCustomer === null ? {} : { CustomerId: this.linkCustomer },
			...issued === null ? {} : { ContractNumber: issued },
			...this.carried()
		};
	}, ...ngDevMode ? [{ debugName: "defaultValues" }] : /* istanbul ignore next */ []);
	prefillFailed = computed(() => !this.isCreate() && this.bundle() !== null && this.prefill().status === "failed", ...ngDevMode ? [{ debugName: "prefillFailed" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => this.response()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.response()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	unavailableLists = computed(() => this.bundle()?.unavailableLists ?? [], ...ngDevMode ? [{ debugName: "unavailableLists" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [
		...this.isSimulated() ? ["Simulated contract, not read from CTRM"] : [],
		...this.isCopy() && !this.copyFailed() ? [this.copySummary()] : [],
		...this.isCreate() ? ["Confirmations and quantities appear once this contract is saved"] : [],
		...this.isEditable() ? ["Shipment dates are optional on this contract"] : [],
		...this.configDefaultsOnly() ? ["Showing default field settings"] : [],
		...this.constraintsNotice() === "bundled" ? ["Field limits are the copy built into this app"] : [],
		...this.constraintsNotice() === "unavailable" ? ["Some field limits are not checked here"] : [],
		...this.isEditable() && this.unavailableLists().length > 0 ? ["Some code lists are unavailable"] : [],
		...this.unmodelled().length > 0 ? [`${this.unmodelled().length} CTRM collections on this contract are not read by CMS`] : [],
		...this.provenanceLabel() !== null ? [this.provenanceLabel()] : [],
		...this.warnings()
	], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	unmodelled = computed(() => this.response()?.unmodelledCollections ?? [], ...ngDevMode ? [{ debugName: "unmodelled" }] : /* istanbul ignore next */ []);
	stages = CONFIRMATION_STAGES;
	fieldNotes = computed(() => this.presentation().fieldNotes, ...ngDevMode ? [{ debugName: "fieldNotes" }] : /* istanbul ignore next */ []);
	pinnedNotes = computed(() => {
		const allocation = this.shipPeriodAllocation();
		const confirmation = this.customerConfirmation();
		return {
			...allocation === null ? {} : { Quantity: allocation },
			...confirmation === null ? {} : { CustomerId: confirmation.note }
		};
	}, ...ngDevMode ? [{ debugName: "pinnedNotes" }] : /* istanbul ignore next */ []);
	shipPeriodAllocation = computed(() => {
		const periods = this.contract()?.shipPeriods ?? [];
		if (periods.length === 0) return null;
		const allocated = periods.reduce((total, period) => total + (period.quantity ?? 0), 0);
		const lead = `This contract’s ${periods.length === 1 ? "shipment period allocates" : `${periods.length} shipment periods allocate`} ${allocated.toLocaleString("en-US")}.`;
		if (this.shipPeriodGateBlocks()) return `${lead} That no longer matches the quantity entered, so this cannot be saved: ${this.shipPeriodReconciliation()?.summary ?? ""}. CTRM requires them to sum, and the periods have to change with it — which this screen cannot do yet.`;
		return `${lead} CTRM requires them to sum to the contract quantity, so changing this on its own is refused — the periods have to change with it, and this screen cannot edit them yet.`;
	}, ...ngDevMode ? [{ debugName: "shipPeriodAllocation" }] : /* istanbul ignore next */ []);
	headerQuantity = signal(null, ...ngDevMode ? [{ debugName: "headerQuantity" }] : /* istanbul ignore next */ []);
	seededShipPeriods = signal([], ...ngDevMode ? [{ debugName: "seededShipPeriods" }] : /* istanbul ignore next */ []);
	shipPeriodRows = signal([], ...ngDevMode ? [{ debugName: "shipPeriodRows" }] : /* istanbul ignore next */ []);
	shipPeriodsChanged = computed(() => !sameShipPeriods(this.shipPeriodRows(), this.seededShipPeriods()), ...ngDevMode ? [{ debugName: "shipPeriodsChanged" }] : /* istanbul ignore next */ []);
	maxShipPeriods = MAX_SHIP_PERIODS;
	nextShipPeriodProposal = computed(() => nextShipPeriod(this.shipPeriodRows()), ...ngDevMode ? [{ debugName: "nextShipPeriodProposal" }] : /* istanbul ignore next */ []);
	shipPeriodValidation = computed(() => {
		const rows = this.shipPeriodRows();
		const loaded = [...this.seededShipPeriods(), ...this.copiedShipPeriods()];
		return validateShipPeriods(rows, todayIso()).filter((issue) => issue.code !== ShipPeriodIssueCode.BeginDateInPast || issue.rowIndex === null || !loaded.some((seeded) => sameShipPeriod(seeded, rows[issue.rowIndex])));
	}, ...ngDevMode ? [{ debugName: "shipPeriodValidation" }] : /* istanbul ignore next */ []);
	shipPeriodRowsBlock = computed(() => this.shipPeriodsChanged() && this.shipPeriodValidation().length > 0, ...ngDevMode ? [{ debugName: "shipPeriodRowsBlock" }] : /* istanbul ignore next */ []);
	shipPeriodHoldReason = computed(() => {
		if (this.shipPeriodGateBlocks()) return "The shipment periods do not sum to the contract quantity. See Shipping Info.";
		return this.shipPeriodRowsBlock() ? "A shipment period has an error, so this cannot be saved until it is fixed. See Shipping Info." : null;
	}, ...ngDevMode ? [{ debugName: "shipPeriodHoldReason" }] : /* istanbul ignore next */ []);
	shipPeriodIssues = computed(() => {
		const issues = /* @__PURE__ */ new Map();
		for (const issue of this.shipPeriodValidation()) {
			if (issue.rowIndex === null) continue;
			const held = issues.get(issue.rowIndex);
			if (held === void 0) issues.set(issue.rowIndex, [issue]);
			else held.push(issue);
		}
		return issues;
	}, ...ngDevMode ? [{ debugName: "shipPeriodIssues" }] : /* istanbul ignore next */ []);
	shipPeriodCollectionIssues = computed(() => this.shipPeriodValidation().filter((issue) => issue.rowIndex === null), ...ngDevMode ? [{ debugName: "shipPeriodCollectionIssues" }] : /* istanbul ignore next */ []);
	shipPeriodsOverlap = computed(() => hasOverlappingPeriods(this.shipPeriodRows()), ...ngDevMode ? [{ debugName: "shipPeriodsOverlap" }] : /* istanbul ignore next */ []);
	seedShipPeriods = effect(() => {
		const periods = this.contract()?.shipPeriods;
		if (periods === void 0) return;
		const rows = periods.map(shipPeriodRowOf);
		untracked(() => {
			this.seededShipPeriods.set(rows);
			this.shipPeriodRows.set(rows);
		});
	}, ...ngDevMode ? [{ debugName: "seedShipPeriods" }] : /* istanbul ignore next */ []);
	addShipPeriod() {
		const proposal = this.nextShipPeriodProposal();
		if (proposal === null) return;
		this.shipPeriodRows.update((rows) => [...rows, proposal]);
		this.regenerateShipPeriodDescription();
	}
	shipPeriodCollections() {
		if (!this.shipPeriodsChanged()) return;
		return { ship_periods: this.shipPeriodRows().map(shipPeriodWriteRow) };
	}
	lmsFlagRead = computed(() => this.isCreate() ? LMS_FLAG_NONE : this.contract()?.lmsFlag ?? LMS_FLAG_UNKNOWN, ...ngDevMode ? [{ debugName: "lmsFlagRead" }] : /* istanbul ignore next */ []);
	savedLmsFlag = linkedSignal({
		...ngDevMode ? { debugName: "savedLmsFlag" } : /* istanbul ignore next */ {},
		source: this.lmsFlagRead,
		computation: (flag) => flag.state === "manual" || flag.state === "automatic"
	});
	lmsFlagValue = linkedSignal({
		...ngDevMode ? { debugName: "lmsFlagValue" } : /* istanbul ignore next */ {},
		source: this.savedLmsFlag,
		computation: (saved) => saved
	});
	canEditLmsFlag = computed(() => {
		const flag = this.lmsFlagRead();
		return this.isEditable() && this.canWrite() && flag.editable && (flag.state === "none" || flag.state === "manual");
	}, ...ngDevMode ? [{ debugName: "canEditLmsFlag" }] : /* istanbul ignore next */ []);
	lmsFlagChanged = computed(() => this.canEditLmsFlag() && this.lmsFlagValue() !== this.savedLmsFlag(), ...ngDevMode ? [{ debugName: "lmsFlagChanged" }] : /* istanbul ignore next */ []);
	lmsFlagUnknownMessage = LMS_FLAG_UNKNOWN_MESSAGE;
	setLmsFlag(value) {
		this.lmsFlagValue.set(value);
	}
	contractTexts = inject(CONTRACT_TEXT_SOURCE, { optional: true });
	contractTextAttempt = signal(0, ...ngDevMode ? [{ debugName: "contractTextAttempt" }] : /* istanbul ignore next */ []);
	contractTextRead = toSignal(toObservable(computed(() => ({
		number: this.contractNumber().trim(),
		create: this.isCreate(),
		attempt: this.attempt(),
		saved: this.contractTextAttempt()
	}))).pipe(switchMap(({ number, create }) => this.contractTexts === null || create || number.length === 0 ? of(null) : this.contractTexts.load(number).pipe(catchError(() => of({
		kind: "failed",
		message: CONTRACT_TEXT_FAILED_MESSAGE
	})), map((call) => ({
		number,
		call
	}))))), { initialValue: null });
	contractTextCall = computed(() => {
		const read = this.contractTextRead();
		return read !== null && read.number === this.contractNumber().trim() ? read.call : null;
	}, ...ngDevMode ? [{ debugName: "contractTextCall" }] : /* istanbul ignore next */ []);
	contractText = computed(() => {
		const call = this.contractTextCall();
		return call?.kind === "loaded" ? call.value : null;
	}, ...ngDevMode ? [{ debugName: "contractText" }] : /* istanbul ignore next */ []);
	contractTextFailure = computed(() => {
		const call = this.contractTextCall();
		return call?.kind === "failed" ? call.message : null;
	}, ...ngDevMode ? [{ debugName: "contractTextFailure" }] : /* istanbul ignore next */ []);
	savedContractText = linkedSignal({
		...ngDevMode ? { debugName: "savedContractText" } : /* istanbul ignore next */ {},
		source: this.contractText,
		computation: (answer) => answer === null ? {} : contractTextBaseline(answer)
	});
	contractTextValues = linkedSignal({
		...ngDevMode ? { debugName: "contractTextValues" } : /* istanbul ignore next */ {},
		source: this.savedContractText,
		computation: (saved) => saved
	});
	contractTextLocked = computed(() => {
		const answer = this.contractText();
		if (answer === null) return null;
		return !answer.notesReadable || (this.response()?.incompleteCollections ?? []).includes("notes") || this.contract()?.lmsFlag?.state === "unknown" ? "This contract’s notes could not be read, so its contract text cannot be changed safely. Reload the contract to try again." : null;
	}, ...ngDevMode ? [{ debugName: "contractTextLocked" }] : /* istanbul ignore next */ []);
	canEditContractText = computed(() => this.isEditable() && this.canWrite() && this.contractText() !== null && this.contractTextLocked() === null, ...ngDevMode ? [{ debugName: "canEditContractText" }] : /* istanbul ignore next */ []);
	contractTextNotes = computed(() => {
		const answer = this.contractText();
		return answer === null || !this.canEditContractText() ? void 0 : contractTextNotesPayload(this.contract()?.notes ?? [], answer, this.savedContractText(), this.contractTextValues());
	}, ...ngDevMode ? [{ debugName: "contractTextNotes" }] : /* istanbul ignore next */ []);
	contractTextDirty = computed(() => this.contractTextNotes() !== void 0, ...ngDevMode ? [{ debugName: "contractTextDirty" }] : /* istanbul ignore next */ []);
	contractTextRefusalMessage = computed(() => {
		const answer = this.contractText();
		return answer === null || !this.canEditContractText() ? null : contractTextRefusal(this.contract()?.notes ?? [], answer, this.savedContractText(), this.contractTextValues());
	}, ...ngDevMode ? [{ debugName: "contractTextRefusalMessage" }] : /* istanbul ignore next */ []);
	contractTextReconfirms = computed(() => this.contractTextDirty() && (this.contractText()?.reconfirmsOnChange ?? false), ...ngDevMode ? [{ debugName: "contractTextReconfirms" }] : /* istanbul ignore next */ []);
	setContractText(change) {
		this.contractTextValues.update((values) => ({
			...values,
			[change.code]: change.text
		}));
	}
	savedRemarks = linkedSignal({
		...ngDevMode ? { debugName: "savedRemarks" } : /* istanbul ignore next */ {},
		source: () => this.isCreate() ? [] : this.contract()?.remarks ?? [],
		computation: (remarks) => remarkValuesOf(remarks)
	});
	remarkValues = linkedSignal({
		...ngDevMode ? { debugName: "remarkValues" } : /* istanbul ignore next */ {},
		source: this.savedRemarks,
		computation: (saved) => saved
	});
	remarkTypeConfig = computed(() => this.bundle()?.config.remarkTypes ?? {}, ...ngDevMode ? [{ debugName: "remarkTypeConfig" }] : /* istanbul ignore next */ []);
	remarkTypes = computed(() => REMARK_TYPES.filter((type) => this.remarkTypeConfig()[type.code]?.visible !== false), ...ngDevMode ? [{ debugName: "remarkTypes" }] : /* istanbul ignore next */ []);
	remarkRequired(code) {
		const config = this.remarkTypeConfig()[code];
		return config?.required === true && config.visible !== false;
	}
	remarksTouched = signal(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "remarksTouched" }] : /* istanbul ignore next */ []);
	touchRemark(code) {
		if (!this.remarksTouched().has(code)) this.remarksTouched.update((touched) => /* @__PURE__ */ new Set([...touched, code]));
	}
	remarkSummaryItems = computed(() => {
		if (!this.isEditable()) return [];
		const refused = this.save().fieldErrors ?? {};
		const values = this.remarkValues();
		const saved = this.savedRemarks();
		const touched = this.remarksTouched();
		const fixable = this.canEditRemarks();
		return this.remarkTypes().flatMap((type) => {
			const key = remarkKey(type.code);
			const reasons = refused[key] ?? [];
			const base = {
				componentName: key,
				label: type.label,
				sectionId: "",
				hidden: false
			};
			if (reasons.length > 0) return [{
				...base,
				message: reasons.join(" "),
				source: "server",
				blocking: false,
				noticed: true
			}];
			if (!fixable || !this.remarkRequired(type.code) || (values[type.code] ?? "").trim() !== "") return [];
			return [{
				...base,
				message: "Enter a value.",
				source: "client",
				blocking: true,
				noticed: touched.has(type.code) || (values[type.code] ?? "") !== (saved[type.code] ?? "")
			}];
		});
	}, ...ngDevMode ? [{ debugName: "remarkSummaryItems" }] : /* istanbul ignore next */ []);
	remarkMessage(code) {
		const item = this.remarkSummaryItems().find((candidate) => candidate.componentName === remarkKey(code));
		return item !== void 0 && item.noticed ? item.message : null;
	}
	remarkKey = remarkKey;
	remarkMaxLength = REMARK_NOTE_MAX_LENGTH;
	remarksUnread = computed(() => !this.isCreate() && (this.response()?.incompleteCollections ?? []).includes("remarks"), ...ngDevMode ? [{ debugName: "remarksUnread" }] : /* istanbul ignore next */ []);
	canEditRemarks = computed(() => this.isEditable() && this.canWrite() && !this.remarksUnread(), ...ngDevMode ? [{ debugName: "canEditRemarks" }] : /* istanbul ignore next */ []);
	remarksDirty = computed(() => remarksChanged(this.savedRemarks(), this.remarkValues()), ...ngDevMode ? [{ debugName: "remarksDirty" }] : /* istanbul ignore next */ []);
	remarkOf(code) {
		return this.remarkValues()[code] ?? "";
	}
	setRemark(code, value) {
		this.remarkValues.update((values) => ({
			...values,
			[code]: value.slice(0, REMARK_NOTE_MAX_LENGTH)
		}));
	}
	writeCollections() {
		const shipPeriods = this.shipPeriodCollections();
		const remarks = this.remarksDirty() && !this.remarksUnread() ? { remarks: remarksPayload(this.remarkValues()) } : void 0;
		const contractTextNotes = this.contractTextNotes();
		const notes = contractTextNotes === void 0 ? void 0 : { notes: contractTextNotes };
		return shipPeriods === void 0 && remarks === void 0 && notes === void 0 ? void 0 : {
			...shipPeriods,
			...remarks,
			...notes
		};
	}
	carriedShipPeriodDate(value) {
		const text = formatFieldValue(value, "date");
		return text === "" ? "—" : text;
	}
	removeShipPeriod(index) {
		this.shipPeriodRows.update((rows) => rows.filter((_, position) => position !== index));
		this.regenerateShipPeriodDescription();
	}
	setShipPeriodDate(index, edge, input) {
		const parsed = parseShipPeriodDate(input, (/* @__PURE__ */ new Date()).getFullYear());
		this.shipPeriodRows.update((rows) => rows.map((row, position) => position === index ? {
			...row,
			[edge]: parsed
		} : row));
		this.regenerateShipPeriodDescription();
	}
	setShipPeriodQuantity(index, input) {
		const trimmed = input.trim();
		const parsed = trimmed === "" ? null : Number(trimmed);
		const quantity = parsed === null || Number.isNaN(parsed) ? null : parsed;
		this.shipPeriodRows.update((rows) => rows.map((row, position) => position === index ? {
			...row,
			quantity
		} : row));
	}
	regenerateShipPeriodDescription() {
		const control = this.form?.control("ShipPeriodDescription");
		if (control === void 0) return;
		const description = buildShipPeriodDescription(overallShipPeriod(this.shipPeriodRows()));
		control.setValue(description ?? "");
		control.markAsDirty();
	}
	shipPeriodReconciliation = computed(() => {
		const periods = this.shipPeriodRows();
		if (periods.length === 0) return null;
		return reconcileShipPeriods(periods, this.headerQuantity());
	}, ...ngDevMode ? [{ debugName: "shipPeriodReconciliation" }] : /* istanbul ignore next */ []);
	shipPeriodGateBlocks = computed(() => {
		const reconciliation = this.shipPeriodReconciliation();
		return reconciliation !== null && reconciliation.state !== ReconciliationState.Balanced;
	}, ...ngDevMode ? [{ debugName: "shipPeriodGateBlocks" }] : /* istanbul ignore next */ []);
	watchHeaderQuantity(form) {
		const control = form.control("Quantity");
		if (control === void 0) {
			this.headerQuantity.set(this.contract()?.header.quantity ?? null);
			return;
		}
		const read = () => {
			const held = control.value;
			if (held === null || held === void 0 || held === "") return null;
			const parsed = typeof held === "number" ? held : Number(held);
			return Number.isFinite(parsed) ? parsed : null;
		};
		this.headerQuantity.set(read());
		control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.headerQuantity.set(read()));
	}
	emptyNotes = CONTRACT_LAYOUT_EMPTY_NOTES;
	sectionNotes = CONTRACT_LAYOUT_SECTION_NOTES;
	wideFields = CONTRACT_LAYOUT_WIDE_FIELDS;
	presentation = computed(() => {
		const layout = {
			halfFields: CONTRACT_LAYOUT_HALF_FIELDS,
			hiddenLabelFields: CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS,
			fieldNotes: CONTRACT_LAYOUT_FIELD_NOTES
		};
		const config = this.bundle()?.config;
		return config === void 0 ? layout : presentationMaps(config, layout);
	}, ...ngDevMode ? [{ debugName: "presentation" }] : /* istanbul ignore next */ []);
	halfFields = computed(() => this.presentation().halfFields, ...ngDevMode ? [{ debugName: "halfFields" }] : /* istanbul ignore next */ []);
	groupHeadings = CONTRACT_LAYOUT_GROUP_HEADINGS;
	hiddenLabelFields = computed(() => this.presentation().hiddenLabelFields, ...ngDevMode ? [{ debugName: "hiddenLabelFields" }] : /* istanbul ignore next */ []);
	fieldCtrmNames = CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT;
	readOnlyFields = computed(() => ({
		...CONTRACT_READ_ONLY_FIELDS,
		...Object.fromEntries(this.cascade().derived.map((field) => [CASCADE_COMPONENTS[field], true]))
	}), ...ngDevMode ? [{ debugName: "readOnlyFields" }] : /* istanbul ignore next */ []);
	lockedFields = computed(() => this.isCreate() ? {} : CONTRACT_KEY_PARTS_READ_ONLY, ...ngDevMode ? [{ debugName: "lockedFields" }] : /* istanbul ignore next */ []);
	tabParam = toSignal(this.route.queryParamMap, { initialValue: null });
	configuredTabs = computed(() => {
		const resolved = this.bundle()?.config;
		const configured = [...tabsAfterCascade(resolved?.tabs ?? [], resolved?.sections ?? [])].sort((left, right) => left.order - right.order).map((tab) => ({
			id: tab.id,
			label: tab.label
		}));
		const tabs = configured.length > 0 ? configured : CONTRACT_TABS;
		const withAddendum = this.hasAddendumSection() ? [...tabs, ADDENDUM_TAB] : tabs;
		const withDocuments = this.canReadDocuments() ? [...withAddendum, DOCUMENTS_TAB] : withAddendum;
		return this.canReadLog() ? [...withDocuments, LOG_TAB] : withDocuments;
	}, ...ngDevMode ? [{ debugName: "configuredTabs" }] : /* istanbul ignore next */ []);
	activeTab = computed(() => {
		const requested = this.tabParam()?.get("tab");
		const available = this.configuredTabs();
		return available.some((tab) => tab.id === requested) ? requested : available[0].id;
	}, ...ngDevMode ? [{ debugName: "activeTab" }] : /* istanbul ignore next */ []);
	tabs = computed(() => this.configuredTabs().map((tab) => ({
		...tab,
		count: tab.id === DOCUMENTS_TAB.id ? null : tab.id === ADDENDUM_TAB.id ? this.addendumSection()?.entryFields().length ?? null : tab.id === LOG_TAB.id ? null : this.countFor(tab.id),
		current: tab.id === this.activeTab()
	})), ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	tabOfSection = computed(() => {
		const configured = this.bundle()?.config.sections ?? [];
		if (configured.length === 0) return new Map(CONTRACT_LAYOUT_SECTIONS.map((section) => [section.id, section.tab]));
		return new Map(configured.map((section) => [section.componentName, section.tab]));
	}, ...ngDevMode ? [{ debugName: "tabOfSection" }] : /* istanbul ignore next */ []);
	hideEmptyFields = signal(false, ...ngDevMode ? [{ debugName: "hideEmptyFields" }] : /* istanbul ignore next */ []);
	visibleSections = computed(() => {
		const active = this.activeTab();
		return (this.bundle()?.config.sections ?? []).filter((section) => this.tabFor(section.componentName) === active).map((section) => section.componentName);
	}, ...ngDevMode ? [{ debugName: "visibleSections" }] : /* istanbul ignore next */ []);
	tabFor(sectionId) {
		return this.tabOfSection().get(sectionId) ?? this.configuredTabs()[0].id;
	}
	showShipPeriods = computed(() => this.activeTab() === "shipping", ...ngDevMode ? [{ debugName: "showShipPeriods" }] : /* istanbul ignore next */ []);
	showPrices = computed(() => this.activeTab() === "pricing", ...ngDevMode ? [{ debugName: "showPrices" }] : /* istanbul ignore next */ []);
	showRemarks = computed(() => this.activeTab() === "remarks", ...ngDevMode ? [{ debugName: "showRemarks" }] : /* istanbul ignore next */ []);
	countFor(tab) {
		const states = this.builtForm()?.states();
		return (this.bundle()?.config.sections ?? []).filter((section) => section.visible && this.tabFor(section.componentName) === tab).reduce((total, section) => total + section.fields.filter((field) => {
			const state = states?.get(field.componentName) ?? field.behaviour;
			return state.visible && state.required;
		}).length, 0) + (tab === "remarks" ? REMARK_TYPES.filter((type) => this.remarkRequired(type.code)).length : 0);
	}
	paramsForTab(tab) {
		return {
			tab,
			...this.journeyParams
		};
	}
	journeyParams = Object.fromEntries(JOURNEY_PARAMS.flatMap((name) => {
		const value = this.route.snapshot.queryParamMap.get(name);
		return value === null ? [] : [[name, value]];
	}));
	editParams = computed(() => this.paramsForTab(this.activeTab()), ...ngDevMode ? [{ debugName: "editParams" }] : /* istanbul ignore next */ []);
	cancelParams = computed(() => this.isCreate() ? {} : this.paramsForTab(this.activeTab()), ...ngDevMode ? [{ debugName: "cancelParams" }] : /* istanbul ignore next */ []);
	contractDateLabel = computed(() => {
		const date = this.contract()?.header.contractDate ?? null;
		return date === null ? null : formatDisplayDate(date);
	}, ...ngDevMode ? [{ debugName: "contractDateLabel" }] : /* istanbul ignore next */ []);
	traderLabel = computed(() => {
		const header = this.contract()?.header;
		const initials = header?.traderInitials?.trim() || null;
		const name = header?.trader?.trim() || null;
		if (initials && name) return `${initials} — ${name}`;
		return initials ?? name;
	}, ...ngDevMode ? [{ debugName: "traderLabel" }] : /* istanbul ignore next */ []);
	quantityBreakdown = computed(() => {
		const q = this.contract()?.quantities ?? null;
		const uom = this.contract()?.header.quantityUom ?? null;
		return [
			{
				label: "Unpriced",
				value: q?.unpriced ?? null,
				uom
			},
			{
				label: "Priced",
				value: q?.priced ?? null,
				uom
			},
			{
				label: "Unshipped",
				value: q?.unshipped ?? null,
				uom
			},
			{
				label: "Applied",
				value: q?.applied ?? null,
				uom
			},
			{
				label: "Settled",
				value: q?.settled ?? null,
				uom
			},
			{
				label: "Open",
				value: q?.open ?? null,
				uom
			}
		];
	}, ...ngDevMode ? [{ debugName: "quantityBreakdown" }] : /* istanbul ignore next */ []);
	confirmations = computed(() => {
		const contract = this.contract();
		return this.stages.map((stage) => {
			const badge = contract === null ? null : contractStatusBadge(stage.value(contract));
			return {
				label: stage.label,
				badge,
				style: CONFIRMATION_STYLE[badge?.tone ?? "neutral"],
				emptyNote: this.isCreate() ? this.pendingNote : stage.emptyNote
			};
		});
	}, ...ngDevMode ? [{ debugName: "confirmations" }] : /* istanbul ignore next */ []);
	pendingNote = "available once the contract is saved";
	shipPeriodSorts = signal([], ...ngDevMode ? [{ debugName: "shipPeriodSorts" }] : /* istanbul ignore next */ []);
	priceSorts = signal([], ...ngDevMode ? [{ debugName: "priceSorts" }] : /* istanbul ignore next */ []);
	sortedShipPeriods = computed(() => this.sortCollection(this.contract()?.shipPeriods ?? [], this.shipPeriodSorts(), this.shipPeriodColumns), ...ngDevMode ? [{ debugName: "sortedShipPeriods" }] : /* istanbul ignore next */ []);
	sortedPrices = computed(() => this.sortCollection(this.contract()?.prices ?? [], this.priceSorts(), this.priceColumns), ...ngDevMode ? [{ debugName: "sortedPrices" }] : /* istanbul ignore next */ []);
	sortCollection(rows, sorts, columns) {
		if (sorts.length === 0) return rows;
		return [...rows].sort((left, right) => compareBySorts(columns, sorts, left, right));
	}
	shipPeriodColumns = [
		{
			key: "order",
			header: "#",
			width: 60,
			format: (row) => String(row.order),
			sortValue: (row) => row.order,
			sortable: true
		},
		{
			key: "begin",
			header: "Begins",
			width: 150,
			format: (row) => formatFieldValue(row.begin, "date"),
			sortValue: (row) => row.begin ?? "",
			sortable: true
		},
		{
			key: "end",
			header: "Ends",
			width: 150,
			format: (row) => formatFieldValue(row.end, "date"),
			sortValue: (row) => row.end ?? "",
			sortable: true
		},
		{
			key: "quantity",
			header: "Quantity",
			align: "end",
			width: 130,
			format: (row) => formatFieldValue(row.quantity, "quantity"),
			sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "latePickup",
			header: "Late pickup",
			width: 150,
			format: (row) => formatFieldValue(row.latePickup, "date"),
			sortValue: (row) => row.latePickup ?? "",
			sortable: true
		},
		{
			key: "earlyDelivery",
			header: "Early delivery",
			width: 150,
			format: (row) => formatFieldValue(row.earlyDelivery, "date"),
			sortValue: (row) => row.earlyDelivery ?? "",
			sortable: true
		}
	];
	priceColumns = [
		{
			key: "sequence",
			header: "Seq",
			width: 70,
			format: (row) => row.sequence === null ? "" : String(row.sequence),
			sortValue: (row) => row.sequence ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "quantity",
			header: "Quantity",
			align: "end",
			width: 130,
			format: (row) => formatFieldValue(row.quantity, "quantity"),
			sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "flatPrice",
			header: "Flat price",
			align: "end",
			width: 120,
			format: (row) => formatFieldValue(row.flatPrice, "price"),
			sortValue: (row) => row.flatPrice ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "basisPrice",
			header: "Basis",
			align: "end",
			width: 110,
			format: (row) => formatFieldValue(row.basisPrice, "price"),
			sortValue: (row) => row.basisPrice ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "hedgePrice",
			header: "Hedge",
			align: "end",
			width: 110,
			format: (row) => formatFieldValue(row.hedgePrice, "price"),
			sortValue: (row) => row.hedgePrice ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "freightAdjustment",
			header: "Freight adj",
			align: "end",
			width: 120,
			format: (row) => formatFieldValue(row.freightAdjustment, "price"),
			sortValue: (row) => row.freightAdjustment ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "marketMonth",
			header: "Market month",
			width: 150,
			format: (row) => row.marketMonthDescription ?? row.marketMonth ?? ""
		},
		{
			key: "priceDate",
			header: "Price date",
			width: 150,
			format: (row) => formatFieldValue(row.priceDate, "date"),
			sortValue: (row) => row.priceDate ?? "",
			sortable: true
		},
		{
			key: "remark",
			header: "Remark",
			width: 220,
			format: (row) => row.remark ?? "",
			sortable: true
		}
	];
	readable(name) {
		return name.replace(/_/g, " ");
	}
	save = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "save" }] : /* istanbul ignore next */ []);
	form = null;
	onFieldBlur(componentName) {
		if (componentName === "ContractNumber") {
			this.numberLeft.next();
			return;
		}
		if (componentName !== "CustomerId" || this.isView() || this.customers === null) return;
		const form = this.form;
		if (form === null) return;
		const raw = form.control("CustomerId")?.value;
		const id = typeof raw === "string" ? raw.trim() : "";
		if (id === "") {
			this.customerConfirmation.set(null);
			return;
		}
		if (this.customerConfirmation()?.id === id) return;
		this.customerConfirmation.set({
			id,
			note: "Looking up the customer…",
			name: null
		});
		this.customers.lookup(id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => {
			if (this.customerConfirmation()?.id !== id || state.status === "loading") return;
			if (state.status === "error") {
				this.customerConfirmation.set({
					id,
					note: state.error.message,
					name: null
				});
				return;
			}
			if (state.status !== "loaded") return;
			const { availability, name: rawName } = state.value;
			const name = isRedactedName(rawName) ? null : rawName?.trim() || null;
			switch (availability) {
				case "Resolved":
					this.customerConfirmation.set({
						id,
						note: name === null ? "The customer directory returned no usable name for this account." : `Confirmed: ${name}`,
						name
					});
					break;
				case "Redacted":
					this.customerConfirmation.set({
						id,
						note: "The customer's name is withheld for this application. The account number is still correct; showing the name needs a person to enable it.",
						name: null
					});
					break;
				case "Unknown": this.customerConfirmation.set({
					id,
					note: "No name on record for this id.",
					name: null
				});
			}
			form.seed({ CustomerName: this.customerConfirmation()?.name ?? null });
		});
	}
	onFormReady(form) {
		this.form = form;
		this.builtForm.set(form);
		for (const control of Object.values(form.group.controls.fields.controls)) control.events.pipe(filter((event) => "touched" in event), takeUntilDestroyed(this.destroyRef)).subscribe(() => this.formRevision.update((revision) => revision + 1));
		this.watchCascadeInputs(form);
		this.watchHeaderQuantity(form);
		this.watchDraft(form);
		this.watchSpecialType(form);
		this.watchChangedValues(form);
		this.watchWeightLimit(form);
		if (this.isCreate()) {
			this.watchCommodityPrefix(form);
			this.watchTypedNumber(form);
			this.watchDrivers(form);
			this.issueNumberOnEntry(form);
			if (this.linkCustomer !== null) this.onFieldBlur("CustomerId");
		}
	}
	liveSpecialType = signal(void 0, ...ngDevMode ? [{ debugName: "liveSpecialType" }] : /* istanbul ignore next */ []);
	watchSpecialType(form) {
		const control = form.control("SpecialType");
		if (control === void 0) {
			this.liveSpecialType.set(void 0);
			return;
		}
		const read = () => typeof control.value === "string" ? control.value : null;
		this.liveSpecialType.set(read());
		control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.liveSpecialType.set(read()));
	}
	addendumTemplateSource = inject(ADDENDUM_TEMPLATE_SOURCE, { optional: true });
	addendumTypeSource = inject(ADDENDUM_TYPE_SOURCE, { optional: true });
	addendumTypesState = toSignal(listStates(this.addendumTypeSource, NO_TYPE_SOURCE), { initialValue: { status: "loading" } });
	addendumTemplatesState = toSignal(this.addendumTemplateSource === null ? of(null) : listStates(this.addendumTemplateSource, ""), { initialValue: null });
	addendumType = computed(() => {
		const types = this.addendumTypesState();
		return types.status === "loaded" ? addendumTypeFor(types.items, this.addendumSpecialType()) : null;
	}, ...ngDevMode ? [{ debugName: "addendumType" }] : /* istanbul ignore next */ []);
	addendumSpecialType = computed(() => {
		const live = this.liveSpecialType();
		return live !== void 0 ? live : this.ctrmFieldValue("special_type");
	}, ...ngDevMode ? [{ debugName: "addendumSpecialType" }] : /* istanbul ignore next */ []);
	showAddendum = computed(() => this.activeTab() === ADDENDUM_TAB.id, ...ngDevMode ? [{ debugName: "showAddendum" }] : /* istanbul ignore next */ []);
	addendumSection = viewChild(ContractAddendumSectionComponent, ...ngDevMode ? [{ debugName: "addendumSection" }] : /* istanbul ignore next */ []);
	hasUnsavedWork = computed(() => this.isDirty() || (this.addendumSection()?.edited() ?? false) || this.remarksDirty() || this.lmsFlagChanged() || this.contractTextDirty(), ...ngDevMode ? [{ debugName: "hasUnsavedWork" }] : /* istanbul ignore next */ []);
	addendumForSave() {
		const section = this.addendumSection();
		if (section === void 0 || !this.hasAddendumSection()) return null;
		const stored = (this.ctrmFieldValue("special_type") ?? "").trim().toUpperCase();
		const current = (this.addendumSpecialType() ?? "").trim().toUpperCase();
		return this.isCreate() || section.edited() || stored !== current ? section.draft() : null;
	}
	addendumPreviewContract = () => {
		const form = this.form;
		if (form === null) return null;
		const collections = this.writeCollections();
		return {
			contractNumber: this.isCreate() ? null : this.contractNumber(),
			fields: this.payloadFor(form),
			...collections === void 0 ? {} : { collections }
		};
	};
	addendumTradeUnit = computed(() => this.contract()?.header.tradeUnit ?? this.tradeUnit.code() ?? null, ...ngDevMode ? [{ debugName: "addendumTradeUnit" }] : /* istanbul ignore next */ []);
	markets = inject(MARKET_REFERENCE_SOURCE);
	builtForm = signal(null, ...ngDevMode ? [{ debugName: "builtForm" }] : /* istanbul ignore next */ []);
	summaryItems = computed(() => {
		const form = this.builtForm();
		const config = this.bundle()?.config;
		if (form === null || config === void 0 || !this.isEditable()) return [];
		form.value();
		form.validity();
		this.formRevision();
		this.save();
		return [...this.withWeightLimitItem(validationSummary(form, config), form, config), ...this.remarkSummaryItems()];
	}, ...ngDevMode ? [{ debugName: "summaryItems" }] : /* istanbul ignore next */ []);
	formRevision = signal(0, ...ngDevMode ? [{ debugName: "formRevision" }] : /* istanbul ignore next */ []);
	summaryEntries = computed(() => {
		const labels = new Map(this.configuredTabs().map((tab) => [tab.id, tab.label]));
		this.tabOfSection();
		return this.summaryItems().filter((item) => item.noticed).map((item) => ({
			key: item.componentName,
			label: item.label,
			message: item.message,
			where: labels.get(this.tabOfSummaryItem(item) ?? "") ?? null,
			hidden: item.hidden,
			blocking: item.blocking
		}));
	}, ...ngDevMode ? [{ debugName: "summaryEntries" }] : /* istanbul ignore next */ []);
	summaryExpanded = signal(true, ...ngDevMode ? [{ debugName: "summaryExpanded" }] : /* istanbul ignore next */ []);
	summaryPanel = viewChild(ValidationSummaryComponent, ...ngDevMode ? [{ debugName: "summaryPanel" }] : /* istanbul ignore next */ []);
	chooseSummaryEntry(entry) {
		const item = this.summaryItems().find((candidate) => candidate.componentName === entry.key);
		if (item !== void 0) this.focusSummaryItem(item);
	}
	tabOfSummaryItem(item) {
		return item.componentName.startsWith(remarkKey("")) ? "remarks" : this.tabOfSection().get(item.sectionId);
	}
	focusSummaryItem(item) {
		const tab = this.tabOfSummaryItem(item) ?? CONTRACT_TABS[0].id;
		this.focusControl(tab, item.hidden ? null : item.componentName);
	}
	cascadeFacts = signal(null, ...ngDevMode ? [{ debugName: "cascadeFacts" }] : /* istanbul ignore next */ []);
	watchCascadeInputs(form) {
		const snapshot = () => {
			const read = (componentName) => {
				const held = form.control(componentName)?.value;
				return typeof held === "string" && held.trim() !== "" ? held.trim() : null;
			};
			return {
				location: read("Location"),
				commodityCode: read("CommodityCode"),
				priceType: read(CASCADE_COMPONENTS.priceType),
				priceMarketCode: read(CASCADE_COMPONENTS.priceMarketCode),
				priceMarketMonth: read(CASCADE_COMPONENTS.priceMarketMonth),
				hedgeMarketCode: read(CASCADE_COMPONENTS.hedgeMarketCode),
				hedgeMarketMonth: read(CASCADE_COMPONENTS.hedgeMarketMonth),
				hedgePrice: readPrice(form.control("HedgePrice")?.value)
			};
		};
		this.cascadeFacts.set(snapshot());
		form.group.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.cascadeFacts.set(snapshot()));
	}
	grainFactorsMarketCode = toSignal(toObservable(computed(() => {
		const facts = this.cascadeFacts();
		return facts === null || facts.location === null || facts.commodityCode === null ? null : {
			location: facts.location,
			commodityCode: facts.commodityCode
		};
	})).pipe(switchMap((key) => key === null ? of(void 0) : this.markets.marketCodes(key.location, key.commodityCode).pipe(map((rows) => rows === null ? void 0 : rows[0]?.code ?? null), catchError(() => of(null))))), { initialValue: void 0 });
	cascade = computed(() => {
		const facts = this.cascadeFacts();
		if (facts === null) return EMPTY_CASCADE;
		return marketCascade({
			priceType: facts.priceType,
			grainFactorsMarketCode: this.grainFactorsMarketCode(),
			priceMarketCode: facts.priceMarketCode,
			priceMarketMonth: facts.priceMarketMonth,
			hedgeMarketCode: facts.hedgeMarketCode,
			hedgeMarketMonth: facts.hedgeMarketMonth,
			hedgePrice: facts.hedgePrice
		});
	}, ...ngDevMode ? [{ debugName: "cascade" }] : /* istanbul ignore next */ []);
	requirementRedirect = computed(() => this.cascade().requirementRedirect, {
		...ngDevMode ? { debugName: "requirementRedirect" } : /* istanbul ignore next */ {},
		equal: (previous, next) => previous?.require === next?.require
	});
	applyRequirementRedirect = effect(() => {
		const form = this.builtForm();
		const redirect = this.requirementRedirect();
		if (form === null || this.isView()) return;
		form.setRequirements(redirect === null ? [] : [{
			componentName: CASCADE_COMPONENTS[redirect.require],
			required: true,
			message: HEDGE_MONTH_SOURCE_MESSAGES[redirect.require],
			source: REQUIREMENT_REDIRECT_SOURCE
		}, {
			componentName: CASCADE_COMPONENTS[redirect.relieve],
			required: false,
			source: REQUIREMENT_REDIRECT_SOURCE
		}]);
	}, ...ngDevMode ? [{ debugName: "applyRequirementRedirect" }] : /* istanbul ignore next */ []);
	marketMonths = toSignal(toObservable(computed(() => {
		const facts = this.cascadeFacts();
		const marketCode = this.cascade().priceMarketCode;
		return facts === null || facts.location === null || facts.commodityCode === null || marketCode === null ? null : {
			location: facts.location,
			commodityCode: facts.commodityCode,
			marketCode
		};
	})).pipe(switchMap((key) => key === null ? of(null) : this.markets.marketMonths(key.location, key.commodityCode, key.marketCode))), { initialValue: null });
	applyCascade = effect(() => {
		const form = this.builtForm();
		const derived = this.cascade();
		if (form === null || this.isView()) return;
		for (const field of derived.derived) {
			const control = form.control(CASCADE_COMPONENTS[field]);
			const next = derived[field];
			if (control === void 0 || control.value === next) continue;
			control.setValue(next, { emitEvent: false });
			control.markAsPristine();
		}
	}, ...ngDevMode ? [{ debugName: "applyCascade" }] : /* istanbul ignore next */ []);
	issueNumberOnEntry(form) {
		if (this.hasRequestedNumber) return;
		const existing = form.control("ContractNumber");
		if (existing === void 0 || typeof existing.value === "string" && existing.value.trim() !== "") return;
		this.hasRequestedNumber = true;
		this.numberIssue.set({ status: "issuing" });
		this.numbers.issue({}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (issued) => {
				const control = (this.form ?? form).control("ContractNumber");
				if (control !== void 0 && control.dirty && typeof control.value === "string" && control.value.trim() !== "") {
					this.numberIssue.set({ status: "issued" });
					return;
				}
				this.issuedNumber.set(issued.numberComponent);
				this.numberIssue.set({ status: "issued" });
				if (control === void 0) return;
				control.setValue(issued.numberComponent);
				control.markAsDirty();
			},
			error: (error) => {
				this.numberIssue.set({
					status: "failed",
					message: this.numberIssueMessageFor(error),
					correlationId: correlationIdOf(error)
				});
			}
		});
	}
	singleCharacter(form, componentName) {
		const value = form.control(componentName)?.value;
		const text = typeof value === "string" ? value.trim() : "";
		return text.length === 1 ? text : null;
	}
	numberIssueMessageFor(error) {
		const status = error?.status;
		if (status === 403) return "You do not have permission to issue a contract number. Type one, or ask for the contract-writer role.";
		if (status === 503) return "This environment cannot issue a real contract number, so none was requested. Type one instead — a simulated number would look real and would be saved against a real contract.";
		return NUMBER_ISSUE_GENERIC_MESSAGE;
	}
	issuedNumber = signal(null, ...ngDevMode ? [{ debugName: "issuedNumber" }] : /* istanbul ignore next */ []);
	hasRequestedNumber = false;
	watchCommodityPrefix(form) {
		const commodity = form.control("CommodityCode");
		const prefix = form.control("ContractPrefixCommodity");
		if (commodity === void 0 || prefix === void 0) return;
		const text = (value) => typeof value === "string" ? value.trim() : "";
		const apply = () => {
			const group = this.commodityGroup(text(commodity.value));
			const current = text(prefix.value);
			if (group === null || current !== "" && current !== this.lastDerivedPrefix) return;
			this.lastDerivedPrefix = group;
			if (current !== group) {
				prefix.setValue(group);
				prefix.markAsDirty();
			}
		};
		apply();
		commodity.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(apply);
	}
	watchTypedNumber(form) {
		this.typedNumberWatch?.unsubscribe();
		const parts = TYPED_NUMBER_KEY_PARTS.map((name) => form.control(name)).filter((control) => control !== void 0);
		const edits = merge(...parts.map((control) => control.valueChanges)).pipe(tap(() => this.typedNumberVerdict.set(null)), debounceTime(TYPED_NUMBER_PAUSE_MS), map(() => "pause"));
		this.typedNumberWatch = merge(edits, this.numberLeft.pipe(map(() => "left"))).pipe(switchMap((trigger) => {
			const typed = this.typedNumber(form);
			if (typed === null) return of(null);
			if (typed.length < CONTRACT_NUMBER_WIDTH) return trigger === "left" ? of({
				key: null,
				status: "short"
			}) : of(null);
			const key = this.typedNumberKey(form);
			if (key === null) return of(null);
			const current = this.typedNumberVerdict();
			if (current !== null && current.key === key && current.status !== "failed") return EMPTY;
			return this.numbers.check(key).pipe(map((verdict) => verdict.isAvailable ? {
				key,
				status: "free"
			} : {
				key,
				status: "taken",
				message: messageForTypedNumberCondition(conditionOfConflict(verdict.conflict))
			}), catchError(() => of({
				key,
				status: "failed"
			})), startWith({
				key,
				status: "checking"
			}));
		}), takeUntilDestroyed(this.destroyRef)).subscribe((verdict) => this.typedNumberVerdict.set(verdict));
	}
	typedNumberWatch = null;
	numberLeft = new Subject();
	typedNumberVerdict = signal(null, ...ngDevMode ? [{ debugName: "typedNumberVerdict" }] : /* istanbul ignore next */ []);
	fieldVerdicts = computed(() => {
		const number = this.typedNumberVerdict();
		const weight = this.weightLimitVerdict();
		if (number === null && weight === null) return NO_VERDICTS;
		return {
			...number === null ? {} : { ContractNumber: fieldVerdictOf(number) },
			...weight === null ? {} : weightLimitFieldVerdicts(weight)
		};
	}, ...ngDevMode ? [{ debugName: "fieldVerdicts" }] : /* istanbul ignore next */ []);
	watchWeightLimit(form) {
		this.weightLimitWatch?.unsubscribe();
		this.weightLimitVerdict.set(null);
		const source = this.weightLimits;
		if (source === null) return;
		const inputs = WEIGHT_LIMIT_INPUTS.map((name) => form.control(name)).filter((control) => control !== void 0);
		this.weightLimitWatch = merge(...inputs.map((control) => control.valueChanges)).pipe(tap(() => this.weightLimitVerdict.set(null)), debounceTime(WEIGHT_LIMIT_PAUSE_MS), switchMap(() => {
			const request = this.isEditable() ? this.weightLimitRequest(form) : null;
			if (request === null) return of(null);
			return source.check(request).pipe(map((verdict) => verdict.status === "notChecked" ? null : verdict), catchError(() => of(null)), startWith({ status: "checking" }));
		}), takeUntilDestroyed(this.destroyRef)).subscribe((verdict) => this.weightLimitVerdict.set(verdict));
	}
	weightLimitRequest(form) {
		const value = (componentName) => form.control(componentName)?.value;
		const code = (componentName) => {
			const held = value(componentName);
			return typeof held === "string" && held.trim() !== "" ? held.trim() : null;
		};
		const amount = (componentName) => {
			const held = value(componentName);
			const parsed = typeof held === "number" ? held : typeof held === "string" && held.trim() !== "" ? Number(held) : NaN;
			return Number.isFinite(parsed) ? parsed : null;
		};
		const type = code("TransportationTypeCode");
		if (type === null || !weightLimitRuleApplies(value("BuyersEquipment"), type)) return null;
		const quantity = amount("Quantity");
		const quantityUom = code("QuantityUnitOfMeasure");
		const units = amount("TransportationUnits");
		const location = code("Location") ?? (this.activeTradeUnit()?.trim() || null);
		if (quantity === null || quantity <= 0 || quantityUom === null || units === null || units < 0 || location === null) return null;
		return {
			contractNumber: this.isCreate() ? null : this.contractNumber().trim() || null,
			fields: {
				location,
				commodity_code: code("CommodityCode"),
				quantity,
				quantity_uom: quantityUom,
				buyers_equipment: "Y",
				transportation_type_code: type,
				transportation_units: units
			}
		};
	}
	withWeightLimitItem(items, form, config) {
		const verdict = this.weightLimitVerdict();
		if (verdict === null || verdict.status !== "outside") return items;
		const section = config.sections.find((candidate) => candidate.fields.some((field) => field.componentName === WEIGHT_LIMIT_FIELD));
		const field = section?.fields.find((candidate) => candidate.componentName === WEIGHT_LIMIT_FIELD);
		if (section === void 0 || field === void 0) return items;
		const existing = items.find((item) => item.componentName === WEIGHT_LIMIT_FIELD);
		if (existing?.blocking === true) return items;
		const hidden = !section.visible || !(form.states().get(WEIGHT_LIMIT_FIELD)?.visible ?? field.behaviour.visible);
		const item = {
			componentName: WEIGHT_LIMIT_FIELD,
			label: field.label,
			sectionId: section.componentName,
			message: weightLimitMessage(verdict),
			source: "client",
			hidden,
			blocking: !hidden,
			noticed: true
		};
		return existing === void 0 ? [...items, item] : items.map((candidate) => candidate === existing ? item : candidate);
	}
	weightLimitWatch = null;
	weightLimitVerdict = signal(null, ...ngDevMode ? [{ debugName: "weightLimitVerdict" }] : /* istanbul ignore next */ []);
	weightLimits = inject(WEIGHT_LIMIT_CHECK_SOURCE, { optional: true });
	lastDerivedPrefix = null;
	commodityGroup(code) {
		if (code === "") return null;
		const group = (this.bundle()?.config.sections.flatMap((section) => section.fields).find((candidate) => candidate.componentName === "CommodityCode"))?.allowedValues?.find((option) => option.code.trim().toUpperCase() === code.toUpperCase())?.group?.trim();
		return group === void 0 || group === "" ? null : group;
	}
	numberIssue = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "numberIssue" }] : /* istanbul ignore next */ []);
	numberIssueReference = computed(() => this.numberIssue().correlationId ?? null, ...ngDevMode ? [{ debugName: "numberIssueReference" }] : /* istanbul ignore next */ []);
	numberIssueFailure = computed(() => this.isCreate() && this.numberIssue().status === "failed" ? this.numberIssue().message ?? null : null, ...ngDevMode ? [{ debugName: "numberIssueFailure" }] : /* istanbul ignore next */ []);
	watchDrivers(form) {
		for (const [componentName, apply] of DRIVER_COMPONENTS) {
			const control = form.control(componentName);
			if (control === void 0) continue;
			control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((value) => {
				const next = typeof value === "string" ? value.trim() : "";
				if (next === (apply === "textClass" ? this.lastTextCode : this.lastCommodity)) return;
				if (apply === "textClass") this.lastTextCode = next;
				else this.lastCommodity = next;
				this.carried.set(this.dirtyValues(form));
				this.createDrivers.update((drivers) => ({
					...drivers,
					[apply === "textClass" ? "textClass" : "commodity"]: next === "" ? void 0 : next
				}));
			});
		}
	}
	lastTextCode = "";
	lastCommodity = "";
	destroyRef = inject(DestroyRef);
	carried = signal({}, ...ngDevMode ? [{ debugName: "carried" }] : /* istanbul ignore next */ []);
	dirtyValues(form) {
		const values = {};
		for (const field of CONTRACT_WRITABLE_FIELDS) {
			const control = form.control(field.componentName);
			if (control !== void 0 && control.dirty) values[field.componentName] = control.value;
		}
		return values;
	}
	formKey = computed(() => this.bundle()?.config.version ?? "none", ...ngDevMode ? [{ debugName: "formKey" }] : /* istanbul ignore next */ []);
	provenanceLabel = computed(() => {
		const provenance = this.bundle()?.provenance;
		if (provenance === void 0) return null;
		return `Configuration: ${provenance.matchedDimensions.length === 0 ? "any type · any location · any commodity" : provenance.matchedDimensions.map(DIMENSION_LABELS).join(" · ")}${provenance.version === null ? "" : ` · v${provenance.version}`}${provenance.effectiveFrom === null ? "" : ` · effective ${provenance.effectiveFrom}`}`;
	}, ...ngDevMode ? [{ debugName: "provenanceLabel" }] : /* istanbul ignore next */ []);
	configDefaultsOnly = computed(() => this.bundle()?.defaultsOnly === true, ...ngDevMode ? [{ debugName: "configDefaultsOnly" }] : /* istanbul ignore next */ []);
	constraintsNotice = computed(() => this.isEditable() ? this.bundle()?.constraintsNotice ?? null : null, ...ngDevMode ? [{ debugName: "constraintsNotice" }] : /* istanbul ignore next */ []);
	retry() {
		this.reissue();
	}
	refresh() {
		this.reissue();
	}
	isRefreshing = computed(() => this.containerState().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	reissue() {
		this.attempt.update((attempt) => attempt + 1);
	}
	availability = inject(AvailabilityGate);
	canWrite = computed(() => this.permissions.canWriteContracts() && this.writeRefusal() === null && !this.availability.writesBlocked(), ...ngDevMode ? [{ debugName: "canWrite" }] : /* istanbul ignore next */ []);
	writeRefusal = computed(() => this.permissions.writeRefusal?.() ?? null, ...ngDevMode ? [{ debugName: "writeRefusal" }] : /* istanbul ignore next */ []);
	ctrmWriteBlock = computed(() => {
		const refusal = this.writeRefusal();
		if (refusal !== null) return refusal.message;
		return this.availability.writesBlocked() ? `Saving to CTRM is paused: ${this.availability.notice().title}.` : null;
	}, ...ngDevMode ? [{ debugName: "ctrmWriteBlock" }] : /* istanbul ignore next */ []);
	canWriteCws = computed(() => this.permissions.canWriteContracts(), ...ngDevMode ? [{ debugName: "canWriteCws" }] : /* istanbul ignore next */ []);
	blockedByAvailability = computed(() => this.availability.writesBlocked(), ...ngDevMode ? [{ debugName: "blockedByAvailability" }] : /* istanbul ignore next */ []);
	availabilityTitle = computed(() => this.availability.notice().title, ...ngDevMode ? [{ debugName: "availabilityTitle" }] : /* istanbul ignore next */ []);
	contractState = inject(CONTRACT_STATE_SOURCE, { optional: true });
	closeProvenanceWarning = CLOSE_PROVENANCE_WARNING;
	stateOverride = signal(null, ...ngDevMode ? [{ debugName: "stateOverride" }] : /* istanbul ignore next */ []);
	stateAction = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "stateAction" }] : /* istanbul ignore next */ []);
	stateOutcome = signal(null, ...ngDevMode ? [{ debugName: "stateOutcome" }] : /* istanbul ignore next */ []);
	isClosed = computed(() => this.contract()?.header.isClosed === true, ...ngDevMode ? [{ debugName: "isClosed" }] : /* istanbul ignore next */ []);
	canChangeState = computed(() => !this.isCreate() && this.contractState !== null && this.contract() !== null, ...ngDevMode ? [{ debugName: "canChangeState" }] : /* istanbul ignore next */ []);
	templates = inject(CONTRACT_TEMPLATE_SOURCE, { optional: true });
	templateName = signal("", ...ngDevMode ? [{ debugName: "templateName" }] : /* istanbul ignore next */ []);
	templateState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "templateState" }] : /* istanbul ignore next */ []);
	templateReload = signal(0, ...ngDevMode ? [{ debugName: "templateReload" }] : /* istanbul ignore next */ []);
	templateOutcome = signal(null, ...ngDevMode ? [{ debugName: "templateOutcome" }] : /* istanbul ignore next */ []);
	templateList = toSignal(toObservable(computed(() => ({
		unit: this.tradeUnit.code(),
		reload: this.templateReload()
	}))).pipe(switchMap(({ unit }) => this.templates === null || unit === null || unit === "" ? of(remoteLoaded([])) : this.templates.list(unit))), { initialValue: remoteLoaded([]) });
	availableTemplates = computed(() => {
		const state = this.templateList();
		return state.status === "loaded" ? state.value : [];
	}, ...ngDevMode ? [{ debugName: "availableTemplates" }] : /* istanbul ignore next */ []);
	templatesFailed = computed(() => this.templateList().status === "error", ...ngDevMode ? [{ debugName: "templatesFailed" }] : /* istanbul ignore next */ []);
	canUseTemplates = computed(() => this.templates !== null, ...ngDevMode ? [{ debugName: "canUseTemplates" }] : /* istanbul ignore next */ []);
	canSaveTemplate = computed(() => this.canUseTemplates() && this.canWriteCws() && !this.isCreate() && this.templateName().trim().length > 0 && this.templateState().status !== "saving", ...ngDevMode ? [{ debugName: "canSaveTemplate" }] : /* istanbul ignore next */ []);
	onTemplateNameInput(value) {
		this.templateName.set(value);
		if (this.templateState().status !== "idle") {
			this.templateState.set({ status: "idle" });
			this.templateOutcome.set(null);
		}
	}
	onSaveTemplate() {
		const form = this.form;
		const unit = this.tradeUnit.code();
		if (this.templates === null || form === null || unit === null || !this.canSaveTemplate()) return;
		const name = this.templateName().trim();
		this.templateState.set({ status: "saving" });
		this.templateOutcome.set(null);
		this.templates.save(unit, name, this.resolvedValues(form)).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: () => {
				this.templateName.set("");
				this.templateState.set({ status: "saved" });
				this.templateOutcome.set(mutationSucceeded(`Template "${name}" saved.`));
				this.templateReload.update((count) => count + 1);
			},
			error: (error) => {
				const message = "That template could not be saved. Try again.";
				this.templateState.set({
					status: "failed",
					message
				});
				this.templateOutcome.set(mutationFailed({
					message,
					correlationId: correlationIdOf(error)
				}));
			}
		});
	}
	onDeleteTemplate(template) {
		const templates = this.templates;
		if (templates === null || !this.canWriteCws()) return;
		this.templateOutcome.set(null);
		this.confirm({
			title: "Delete this template?",
			message: `"${template.name}" will be removed for everyone in this trade unit. This cannot be undone.`,
			confirmLabel: "Delete template",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (!confirmed) return;
			templates.remove(template.id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
				next: () => {
					this.templateOutcome.set(mutationSucceeded(`Template "${template.name}" deleted.`));
					this.templateReload.update((count) => count + 1);
				},
				error: (error) => this.templateOutcome.set(mutationFailed({
					message: `"${template.name}" could not be deleted, so it is still there. Try again.`,
					correlationId: correlationIdOf(error)
				}))
			});
		});
	}
	onApplyTemplate(templateId) {
		const template = this.availableTemplates().find((each) => String(each.id) === templateId);
		const form = this.form;
		if (template === void 0 || form === null) return;
		const values = templateValuesOf(template);
		const byCtrmField = new Map(CONTRACT_WRITABLE_FIELDS.map((field) => [field.ctrmField, field.componentName]));
		const seed = {};
		for (const [ctrmField, value] of Object.entries(values)) {
			const componentName = byCtrmField.get(ctrmField);
			if (componentName !== void 0 && (value === null || [
				"string",
				"number",
				"boolean"
			].includes(typeof value))) seed[componentName] = value;
		}
		form.seed(seed);
		this.appliedTemplate.set(template.name);
	}
	appliedTemplate = signal(null, ...ngDevMode ? [{ debugName: "appliedTemplate" }] : /* istanbul ignore next */ []);
	resolvedValues(form) {
		const values = {};
		for (const field of CONTRACT_WRITABLE_FIELDS) {
			const value = form.control(field.componentName)?.value;
			if (value === null || value === void 0 || value === "") continue;
			values[field.ctrmField] = toCtrmValue(value, field.controlPattern);
		}
		return values;
	}
	logSource = inject(CONTRACT_LOG_SOURCE, { optional: true });
	meSource = inject(ME_SOURCE, { optional: true });
	canReadLog = computed(() => !this.isCreate() && (this.logSource !== null || this.templates !== null), ...ngDevMode ? [{ debugName: "canReadLog" }] : /* istanbul ignore next */ []);
	showLog = computed(() => this.activeTab() === "log", ...ngDevMode ? [{ debugName: "showLog" }] : /* istanbul ignore next */ []);
	documentsSource = inject(CONTRACT_DOCUMENTS_SOURCE, { optional: true });
	canReadDocuments = computed(() => !this.isCreate() && this.documentsSource !== null, ...ngDevMode ? [{ debugName: "canReadDocuments" }] : /* istanbul ignore next */ []);
	showDocuments = computed(() => this.activeTab() === DOCUMENTS_TAB.id, ...ngDevMode ? [{ debugName: "showDocuments" }] : /* istanbul ignore next */ []);
	attachmentsSource = inject(CONTRACT_ATTACHMENTS_SOURCE, { optional: true });
	attachmentsOffered = this.attachmentsSource !== null;
	canWriteAttachments = computed(() => this.isView() && this.canWriteCws() && !this.blockedByAvailability() && !this.intercompanyLock(), ...ngDevMode ? [{ debugName: "canWriteAttachments" }] : /* istanbul ignore next */ []);
	canPickCreateAttachments = computed(() => this.isCreate() && this.canWriteCws(), ...ngDevMode ? [{ debugName: "canPickCreateAttachments" }] : /* istanbul ignore next */ []);
	attachmentsCaraWarning = computed(() => this.addendumType() !== null && this.storedAddendum() === null, ...ngDevMode ? [{ debugName: "attachmentsCaraWarning" }] : /* istanbul ignore next */ []);
	pendingAttachments = signal([], ...ngDevMode ? [{ debugName: "pendingAttachments" }] : /* istanbul ignore next */ []);
	onAttachmentSaved(saved) {
		this.arrivedAfterSave.set(mutationSucceeded(saved.message));
		this.reissue();
	}
	logAvailable = computed(() => this.logSource !== null, ...ngDevMode ? [{ debugName: "logAvailable" }] : /* istanbul ignore next */ []);
	logAttempt = signal(0, ...ngDevMode ? [{ debugName: "logAttempt" }] : /* istanbul ignore next */ []);
	logReadKey = computed(() => ({
		number: this.contractNumber(),
		attempt: this.attempt(),
		logAttempt: this.logAttempt(),
		can: this.canReadLog()
	}), ...ngDevMode ? [{ debugName: "logReadKey" }] : /* istanbul ignore next */ []);
	auditTrail = toSignal(toObservable(this.logReadKey).pipe(switchMap(({ number, can }) => !can || this.logSource === null || number.trim().length === 0 ? of(remoteLoaded([])) : this.logSource.audit(number))), { initialValue: remoteLoading() });
	logNotes = toSignal(toObservable(this.logReadKey).pipe(switchMap(({ number, can }) => {
		const source = this.logSource;
		return !can || source === null || source.notes === void 0 || number.trim().length === 0 ? of(remoteLoaded([])) : source.notes(number);
	})), { initialValue: remoteLoading() });
	logNotesFailed = computed(() => this.logNotes().status === "error", ...ngDevMode ? [{ debugName: "logNotesFailed" }] : /* istanbul ignore next */ []);
	timeline = computed(() => {
		const trail = this.auditTrail();
		const notesState = this.logNotes();
		const notes = notesState.status === "loaded" ? notesState.value : [];
		const noteIds = new Set(notes.map((note) => note.id));
		const noteRows = notes.map((note) => ({
			kind: "note",
			text: note.note,
			key: `n-${note.id}`,
			at: note.createdAtUtc,
			atLabel: readableTimestamp(note.createdAtUtc),
			actor: note.actorUpn,
			what: "Note",
			detail: null,
			changes: [],
			collectionsReplaced: [],
			attachments: []
		}));
		const entries = (trail.status === "loaded" ? trail.value : []).filter((entry) => {
			const noteId = entry.action === "Note" ? auditNoteIdOf(entry.detailsJson) : null;
			return noteId === null || !noteIds.has(noteId);
		});
		const contractRows = trail.status === "loaded" ? entries.map((entry) => {
			const summary = auditChangesOf(entry.detailsJson);
			return {
				kind: "contract",
				text: null,
				key: `c-${entry.id}`,
				at: entry.timestampUtc,
				atLabel: readableTimestamp(entry.timestampUtc),
				actor: entry.actorUpn,
				what: describeAuditAction(entry.action),
				detail: entry.detailsJson,
				changes: (summary?.changes ?? []).map((change) => ({
					label: this.labelForCtrmField(change.field),
					from: change.from,
					to: change.to
				})),
				collectionsReplaced: summary?.collectionsReplaced ?? [],
				attachments: auditAttachmentsOf(entry.action, entry.detailsJson)
			};
		}) : [];
		const configRows = this.configAudit().map((entry) => ({
			kind: "configuration",
			text: null,
			key: `f-${entry.auditId}`,
			at: entry.timestampUtc,
			atLabel: readableTimestamp(entry.timestampUtc),
			actor: entry.actorUpn,
			what: `Form configuration ${entry.changeType.toLowerCase()}`,
			detail: null,
			changes: [],
			collectionsReplaced: [],
			attachments: []
		}));
		return [
			...contractRows,
			...noteRows,
			...configRows
		].sort((left, right) => newestFirst(left.at, right.at));
	}, ...ngDevMode ? [{ debugName: "timeline" }] : /* istanbul ignore next */ []);
	timelineState = computed(() => this.auditTrail().status, ...ngDevMode ? [{ debugName: "timelineState" }] : /* istanbul ignore next */ []);
	labelForCtrmField(ctrmField) {
		const layoutField = CONTRACT_LAYOUT_FIELDS.find((field) => field.ctrmField === ctrmField);
		if (layoutField === void 0) return ctrmField;
		return (this.bundle()?.config.sections ?? []).flatMap((section) => section.fields).find((field) => field.componentName === layoutField.componentName)?.label ?? layoutField.label;
	}
	formConfigAdmin = inject(FORM_CONFIG_ADMIN_SOURCE, { optional: true });
	configAuditState = toSignal(toObservable(computed(() => this.bundle()?.provenance?.configId ?? null)).pipe(distinctUntilChanged(), switchMap((configId) => configId === null || this.formConfigAdmin === null ? of(null) : this.formConfigAdmin.auditTrail(configId))), { initialValue: null });
	configAudit = computed(() => {
		const state = this.configAuditState();
		return state?.status === "loaded" ? state.value.entries : [];
	}, ...ngDevMode ? [{ debugName: "configAudit" }] : /* istanbul ignore next */ []);
	configAuditFailed = computed(() => this.configAuditState()?.status === "error", ...ngDevMode ? [{ debugName: "configAuditFailed" }] : /* istanbul ignore next */ []);
	noteText = signal("", ...ngDevMode ? [{ debugName: "noteText" }] : /* istanbul ignore next */ []);
	noteBytesRemaining = computed(() => remainingNoteBytes(this.noteText()), ...ngDevMode ? [{ debugName: "noteBytesRemaining" }] : /* istanbul ignore next */ []);
	noteRefusal = computed(() => logNoteSizeRefusal(this.noteText()), ...ngDevMode ? [{ debugName: "noteRefusal" }] : /* istanbul ignore next */ []);
	noteState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "noteState" }] : /* istanbul ignore next */ []);
	noteOutcome = signal(null, ...ngDevMode ? [{ debugName: "noteOutcome" }] : /* istanbul ignore next */ []);
	onNoteInput(value) {
		this.noteText.set(value);
		if (this.noteState().status !== "idle") {
			this.noteState.set({ status: "idle" });
			this.noteOutcome.set(null);
		}
	}
	canKeepLogNotes = this.logSource?.addNote !== void 0;
	canWriteLogNote = computed(() => this.canWriteCws() && this.writeRefusal() === null, ...ngDevMode ? [{ debugName: "canWriteLogNote" }] : /* istanbul ignore next */ []);
	canAddNote = computed(() => this.canKeepLogNotes && this.canWriteLogNote() && this.noteText().trim().length > 0 && this.noteRefusal() === null && this.noteState().status !== "saving", ...ngDevMode ? [{ debugName: "canAddNote" }] : /* istanbul ignore next */ []);
	noteInFlight = null;
	onAddNote() {
		const source = this.logSource;
		if (!this.canAddNote() || source?.addNote === void 0) return;
		const number = this.contractNumber();
		const text = this.noteText().trim();
		if (this.noteInFlight?.text !== text) this.noteInFlight = {
			text,
			clientNoteId: this.mintIdempotencyKey()
		};
		const { clientNoteId } = this.noteInFlight;
		this.noteState.set({ status: "saving" });
		this.noteOutcome.set(null);
		source.addNote(number, text, clientNoteId).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: () => {
				this.noteInFlight = null;
				this.noteText.set("");
				this.noteState.set({ status: "saved" });
				this.noteOutcome.set(mutationSucceeded(LOG_NOTE_ADDED_MESSAGE));
				this.logAttempt.update((attempt) => attempt + 1);
			},
			error: (error) => {
				const problem = problemFrom(error);
				const message = logNoteFailureOf(problem);
				this.noteState.set({
					status: "failed",
					message
				});
				this.noteOutcome.set(mutationFailed({
					message,
					correlationId: problem.traceId
				}));
				if (writeOutcomeOf(problem) !== "refused") this.logAttempt.update((attempt) => attempt + 1);
			}
		});
	}
	notifyText = signal("", ...ngDevMode ? [{ debugName: "notifyText" }] : /* istanbul ignore next */ []);
	notifyState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "notifyState" }] : /* istanbul ignore next */ []);
	notifyOutcome = signal(null, ...ngDevMode ? [{ debugName: "notifyOutcome" }] : /* istanbul ignore next */ []);
	me = toSignal(this.meSource === null ? of(null) : this.meSource.get().pipe(map((state) => state.status === "loaded" ? state.value : null)), { initialValue: null });
	mayNotify = computed(() => holdsAnyPermissionIn(this.me(), this.contract()?.header.tradeUnit ?? null), ...ngDevMode ? [{ debugName: "mayNotify" }] : /* istanbul ignore next */ []);
	canNotify = computed(() => this.mayNotify() !== false && this.notifyText().trim().length > 0 && this.recipients().length > 0 && this.notifyState().status !== "sending", ...ngDevMode ? [{ debugName: "canNotify" }] : /* istanbul ignore next */ []);
	traderEmails = inject(TRADER_EMAIL_SOURCE, { optional: true });
	traderInitials = computed(() => this.contract()?.header.traderInitials?.trim() || null, ...ngDevMode ? [{ debugName: "traderInitials" }] : /* istanbul ignore next */ []);
	traderEmail = toSignal(toObservable(this.traderInitials).pipe(distinctUntilChanged(), switchMap((initials) => initials === null || this.traderEmails === null ? of(null) : this.traderEmails.emailFor(initials).pipe(catchError(() => of(null))))), { initialValue: null });
	recipients = linkedSignal({
		...ngDevMode ? { debugName: "recipients" } : /* istanbul ignore next */ {},
		source: this.traderEmail,
		computation: (email) => email !== null && isScoularAddress(email) ? [email.trim()] : []
	});
	unresolvedTrader = computed(() => this.traderInitials() !== null && this.traderEmail() === null ? this.traderInitials() : null, ...ngDevMode ? [{ debugName: "unresolvedTrader" }] : /* istanbul ignore next */ []);
	recipientDraft = signal("", ...ngDevMode ? [{ debugName: "recipientDraft" }] : /* istanbul ignore next */ []);
	recipientError = signal(null, ...ngDevMode ? [{ debugName: "recipientError" }] : /* istanbul ignore next */ []);
	onRecipientInput(value) {
		this.recipientDraft.set(value);
		this.recipientError.set(null);
	}
	addRecipient() {
		const address = this.recipientDraft().trim();
		if (address === "") return;
		if (!isScoularAddress(address)) {
			this.recipientError.set("Only @scoular.com addresses can be notified.");
			return;
		}
		if (!this.recipients().some((chosen) => chosen.toLowerCase() === address.toLowerCase())) this.recipients.update((chosen) => [...chosen, address]);
		this.recipientDraft.set("");
	}
	removeRecipient(address) {
		this.recipients.update((chosen) => chosen.filter((each) => each !== address));
	}
	onNotifyInput(value) {
		this.notifyText.set(value);
		if (this.notifyState().status !== "idle") {
			this.notifyState.set({ status: "idle" });
			this.notifyOutcome.set(null);
		}
	}
	onNotifyTrader() {
		const source = this.logSource;
		const number = this.contractNumber();
		if (source === null || !this.canNotify()) return;
		this.notifyState.set({ status: "sending" });
		this.notifyOutcome.set(null);
		source.notifyTrader(number, this.notifyText().trim(), this.recipients()).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (answer) => {
				this.notifyState.set({ status: "accepted" });
				this.notifyOutcome.set(mutationSucceeded(notifyMessageFor(answer.delivered)));
				this.notifyText.set("");
			},
			error: (error) => {
				const message = "That message could not be sent, and nobody has been notified. Try again.";
				this.notifyState.set({
					status: "failed",
					message
				});
				this.notifyOutcome.set(mutationFailed({
					message,
					correlationId: correlationIdOf(error)
				}));
			}
		});
	}
	onCloseContract() {
		this.changeState("close", {
			title: "Close this contract?",
			message: `This contract will be closed in CTRM, and ${CLOSE_PROVENANCE_WARNING}. Re-opening it later does not restore what closing rewrote.`,
			confirmLabel: "Close contract",
			cancelLabel: "Keep it open",
			destructive: true
		});
	}
	onReopenContract() {
		this.changeState("reopen", {
			title: "Re-open this contract?",
			message: "This contract will be re-opened in CTRM. It does not restore the pricing-approval provenance that closing rewrote.",
			confirmLabel: "Re-open contract",
			cancelLabel: "Leave it closed"
		});
	}
	changeState(action, request) {
		const source = this.contractState;
		const number = this.contractNumber();
		if (source === null || number.trim().length === 0) return;
		this.confirm(request).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (!confirmed) return;
			this.stateAction.set({ status: "working" });
			this.stateOutcome.set(null);
			(action === "close" ? source.close(number) : source.reopen(number)).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
				next: (response) => {
					this.stateOverride.set(response);
					this.stateAction.set({ status: "idle" });
					this.stateOutcome.set(mutationSucceeded(action === "close" ? `Contract ${number} closed.` : `Contract ${number} re-opened.`));
				},
				error: (error) => {
					const message = stateFailureOf(action, problemFrom(error));
					this.stateAction.set({
						status: "failed",
						message
					});
					this.stateOutcome.set(mutationFailed({
						message,
						correlationId: correlationIdOf(error)
					}));
				}
			});
		});
	}
	canSave = computed(() => this.isEditable() && this.canWrite() && this.save().status !== "saving" && this.bundle() !== null && !this.shipPeriodGateBlocks() && !this.shipPeriodRowsBlock() && this.contractTextRefusalMessage() === null, ...ngDevMode ? [{ debugName: "canSave" }] : /* istanbul ignore next */ []);
	missingRequired = computed(() => {
		const labels = new Map(this.configuredTabs().map((tab) => [tab.id, tab.label]));
		return this.summaryItems().filter((item) => item.blocking && item.required === true).map((item) => ({
			label: item.label,
			where: labels.get(this.tabOfSummaryItem(item) ?? "") ?? null
		}));
	}, ...ngDevMode ? [{ debugName: "missingRequired" }] : /* istanbul ignore next */ []);
	missingRequiredLabels = computed(() => this.missingRequired().map((item) => item.label), ...ngDevMode ? [{ debugName: "missingRequiredLabels" }] : /* istanbul ignore next */ []);
	saveHoldText = computed(() => {
		const missing = this.missingRequired();
		return missing.length === 0 ? null : "Fill in the required fields first: " + missing.map((item) => item.where === null ? item.label : `${item.label} (${item.where})`).join(", ");
	}, ...ngDevMode ? [{ debugName: "saveHoldText" }] : /* istanbul ignore next */ []);
	onSave(notify = false) {
		const form = this.form;
		if (form === null || !this.canSave()) return;
		this.numberCheck.set(null);
		this.notifying.set(notify);
		const blockers = this.summaryItems().filter((item) => item.blocking);
		if (blockers.length > 0) {
			for (const item of blockers) form.control(item.componentName)?.markAsTouched();
			for (const type of REMARK_TYPES) if (blockers.some((item) => item.componentName === remarkKey(type.code))) this.touchRemark(type.code);
			this.summaryExpanded.set(true);
			this.focusSummaryItem(blockers[0]);
			return;
		}
		const typed = this.typedNumber(form);
		if (typed !== null && typed.length < CONTRACT_NUMBER_WIDTH) {
			this.numberCheck.set(TYPED_NUMBER_SHORT_MESSAGE);
			return;
		}
		const key = this.typedNumberKey(form);
		if (key === null) {
			this.submit(form, notify);
			return;
		}
		this.save.set({ status: "saving" });
		this.numbers.check(key).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (verdict) => {
				if (verdict.isAvailable) {
					this.submit(form, notify);
					return;
				}
				this.save.set({ status: "idle" });
				this.numberCheck.set(messageForTypedNumberCondition(conditionOfConflict(verdict.conflict)));
			},
			error: () => {
				this.save.set({ status: "idle" });
				this.numberCheck.set(NUMBER_CHECK_FAILED_MESSAGE);
			}
		});
	}
	typedNumberKey(form) {
		const number = this.typedNumber(form);
		if (number === null) return null;
		const prefixType = this.singleCharacter(form, "ContractPrefixType");
		const prefixCommodity = this.singleCharacter(form, "ContractPrefixCommodity");
		if (prefixType === null || prefixCommodity === null) return null;
		return `${prefixType}${prefixCommodity}${number}${this.singleCharacter(form, "ContractSuffix") ?? ""}`.trimEnd().toUpperCase();
	}
	typedNumber(form) {
		if (!this.isCreate()) return null;
		const value = form.control("ContractNumber")?.value;
		const number = typeof value === "string" ? value.trim() : "";
		return number === "" || number === this.issuedNumber() ? null : number;
	}
	numberCheck = signal(null, ...ngDevMode ? [{ debugName: "numberCheck" }] : /* istanbul ignore next */ []);
	notifying = signal(false, ...ngDevMode ? [{ debugName: "notifying" }] : /* istanbul ignore next */ []);
	submit(form, notify = false) {
		const changed = this.payloadFor(form);
		const collections = this.writeCollections();
		this.leavingWithDraftKept = false;
		this.serverRefusals = null;
		this.save.set({ status: "saving" });
		const addendum = this.addendumForSave();
		const options = {
			...notify ? { sendNotification: true } : {},
			...addendum === null ? {} : { addendum },
			...this.lmsFlagChanged() ? { lmsFlag: this.lmsFlagValue() } : {}
		};
		(this.isCreate() ? this.writes.create(changed, collections, {
			idempotencyKey: this.keyForCreate(),
			...options,
			...this.pendingAttachments().length === 0 ? {} : { attachments: this.pendingAttachments() }
		}) : Object.keys(options).length > 0 ? this.writes.update(this.contractNumber(), changed, collections, options) : this.writes.update(this.contractNumber(), changed, collections)).subscribe({
			next: (result) => {
				this.save.set({
					status: "saved",
					result
				});
				this.events.emit({
					type: "contract-saved",
					contractNumber: result.contractNumber,
					action: result.action,
					warnings: result.warnings
				});
				this.clearDraft();
				this.isDirty.set(false);
				this.createKey = null;
				if (this.isCreate() && this.isCopyWithPricing() && this.pricing !== null && this.collectionCopy()?.pricesExcluded !== true) this.pricingCopies.start(this.pricing, (this.copyFrom ?? "").trim(), result.contractNumber);
				const closing = this.closeAfterSave;
				this.closeAfterSave = false;
				const destination = this.destinationAfter(result);
				const notice = combinedNotice(addendumNotice(result, addendum !== null), notificationNotice(result), lmsWarningNotice(result));
				this.addendumSection()?.markSaved();
				if (!closing && destination === null) this.addendumListAttempt.update((n) => n + 1);
				this.savedRemarks.set(this.remarkValues());
				this.savedLmsFlag.set(this.lmsFlagValue());
				if (collections?.notes !== void 0) {
					this.savedContractText.set(this.contractTextValues());
					this.contractTextAttempt.update((n) => n + 1);
				}
				const saved = destination === null ? null : savedSentence(result.action, destination, this.isCopy() ? (this.copyFrom ?? "").trim() : null);
				const outcome = saved === null ? notice === null ? null : mutationSucceeded(notice.text, { stays: notice.stays }) : notice === null ? mutationSucceeded(saved) : mutationSucceeded(`${saved} ${notice.text}`, { stays: notice.stays });
				if (closing && outcome !== null) this.saveAnnouncements.announceForOrigin(recordOriginKey(this.originParam), outcome);
				else if (!closing && destination !== null && outcome !== null) this.saveAnnouncements.announce(destination, outcome);
				else if (!closing && notice !== null) this.arrivedAfterSave.set(mutationSucceeded(notice.text, { stays: notice.stays }));
				if (closing) this.requestNavigation({
					kind: "origin",
					origin: this.originParam ?? "",
					params: this.returnParams()
				});
				else if (destination !== null) this.requestNavigation({
					kind: "contract",
					contractNumber: destination
				});
			},
			error: (error) => {
				this.closeAfterSave = false;
				const failed = readProblem(error);
				this.save.set({
					status: "failed",
					...failed
				});
				this.events.emit({
					type: "error",
					operation: "save",
					contractNumber: this.isCreate() ? null : this.contractNumber(),
					message: failed.failure === "outcome-unknown" ? "The contract may have been saved" : "The contract was not saved",
					...failed.correlationId ? { correlationId: failed.correlationId } : {}
				});
				this.applyFieldErrors();
			}
		});
	}
	payloadFor(form) {
		const sendEverything = this.isCreate();
		const payload = {};
		const derived = new Set(this.cascade().derived.map((cascadeField) => CASCADE_COMPONENTS[cascadeField]));
		for (const field of CONTRACT_WRITABLE_FIELDS) {
			const control = form.control(field.componentName);
			if (control === void 0) continue;
			if (!sendEverything && !control.dirty) {
				if (this.ruleBlankedSinceLoad(form, field.componentName, control.value) || derived.has(field.componentName) && this.cascadeChangedSinceLoad(field.componentName, control.value)) payload[field.ctrmField] = isBlankValue(control.value) ? null : toCtrmValue(control.value, field.controlPattern);
				continue;
			}
			if (sendEverything && (control.value === null || control.value === void 0 || control.value === "")) continue;
			payload[field.ctrmField] = toCtrmValue(control.value, field.controlPattern);
		}
		return payload;
	}
	ruleBlankedSinceLoad(form, componentName, current) {
		if (form.fieldState(componentName)?.valueIntent.kind !== "blank" || !isBlankValue(current)) return false;
		const loaded = { fields: { [componentName]: this.initialValues()[componentName] } };
		return !isZeroOrBlank(loaded, componentName);
	}
	cascadeChangedSinceLoad(componentName, current) {
		return comparableText(current) !== comparableText(this.initialValues()[componentName]);
	}
	tabByCtrmField = TAB_BY_CTRM_FIELD;
	errorsByTab = computed(() => {
		const counts = /* @__PURE__ */ new Map();
		for (const ctrmField of Object.keys(this.save().fieldErrors ?? {})) {
			const tab = this.tabByCtrmField[ctrmField];
			if (tab !== void 0) counts.set(tab, (counts.get(tab) ?? 0) + 1);
		}
		const addendum = this.saveErrorGroups().addendum.length;
		if (addendum > 0) counts.set(ADDENDUM_TAB.id, addendum);
		return counts;
	}, ...ngDevMode ? [{ debugName: "errorsByTab" }] : /* istanbul ignore next */ []);
	unmappedErrors = computed(() => classifyInvalidParams(this.saveErrorGroups().contract).unrenderedFields.map(({ ctrmField, reasons }) => ({
		field: ctrmField,
		reasons
	})), ...ngDevMode ? [{ debugName: "unmappedErrors" }] : /* istanbul ignore next */ []);
	saveErrorGroups = computed(() => {
		const groups = {
			addendum: [],
			remarks: [],
			save: [],
			documents: [],
			attachments: [],
			lmsFlag: [],
			contract: {}
		};
		for (const [name, reasons] of Object.entries(this.save().fieldErrors ?? {})) if (name === "addendum" || name.startsWith("addendum.") || name === "addendum_document") groups.addendum.push(...reasons);
		else if (name === "attachment" || name === "attachments" || name.startsWith("attachment.")) groups.attachments.push(...reasons);
		else if (name === "save") groups.save.push(...reasons);
		else if (name === "lmsFlag") groups.lmsFlag.push(...reasons);
		else if (name.startsWith("documents.")) groups.documents.push(...reasons);
		else if (name === "remarks" || name.startsWith("remarks.") || name === "remark_note" || name === "remark_type") groups.remarks.push(...reasons);
		else groups.contract[name] = reasons;
		return groups;
	}, ...ngDevMode ? [{ debugName: "saveErrorGroups" }] : /* istanbul ignore next */ []);
	goToRemarks() {
		this.focusControl("remarks", null);
	}
	goToAddendum() {
		this.focusControl(ADDENDUM_TAB.id, null);
	}
	formLevelReasons = computed(() => [...this.save().formErrors ?? [], ...classifyInvalidParams(this.saveErrorGroups().contract).formReasons], ...ngDevMode ? [{ debugName: "formLevelReasons" }] : /* istanbul ignore next */ []);
	mappedErrors = computed(() => {
		const errors = this.save().fieldErrors ?? {};
		return CONTRACT_LAYOUT_FIELDS.flatMap((layoutField) => {
			const reasons = errors[layoutField.ctrmField];
			return reasons === void 0 ? [] : [{
				ctrmField: layoutField.ctrmField,
				componentName: layoutField.componentName,
				label: layoutField.label,
				tab: this.tabByCtrmField[layoutField.ctrmField] ?? CONTRACT_TABS[0].id,
				reasons
			}];
		});
	}, ...ngDevMode ? [{ debugName: "mappedErrors" }] : /* istanbul ignore next */ []);
	applyFieldErrors() {
		const form = this.form;
		const mapped = this.mappedErrors();
		if (mapped.length === 0 && this.saveErrorGroups().addendum.length > 0 && this.configuredTabs().some((tab) => tab.id === ADDENDUM_TAB.id)) {
			this.goToAddendum();
			return;
		}
		if (form === null || mapped.length === 0) return;
		const refusals = /* @__PURE__ */ new Map();
		for (const error of mapped) {
			const control = form.control(error.componentName);
			if (control !== void 0) {
				refusals.set(error.componentName, {
					value: control.value,
					message: error.reasons[0]
				});
				control.markAsTouched();
				control.setErrors({
					...control.errors ?? {},
					server: error.reasons[0]
				});
			}
		}
		this.serverRefusals = {
			form,
			byName: refusals
		};
		this.focusField(mapped[0]);
	}
	serverRefusals = null;
	reassertRefusals = afterRenderEffect(() => {
		this.activeTab();
		this.visibleSections();
		const form = this.builtForm();
		if (form === null) return;
		form.value();
		form.states();
		if (this.save().status !== "failed") return;
		untracked(() => this.restoreRefusals(form));
	}, ...ngDevMode ? [{ debugName: "reassertRefusals" }] : /* istanbul ignore next */ []);
	restoreRefusals(form) {
		const refusals = this.serverRefusals;
		if (refusals === null || refusals.form !== form) return;
		for (const [componentName, refusal] of refusals.byName) {
			const control = form.control(componentName);
			if (control === void 0 || !sameRefusedValue(control.value, refusal.value) || control.errors?.["server"] === refusal.message) continue;
			control.markAsTouched();
			control.setErrors({
				...control.errors ?? {},
				server: refusal.message
			});
		}
	}
	focusField(error) {
		this.focusControl(error.tab, error.componentName);
	}
	focusControl(tab, componentName) {
		this.pendingFocus.set(componentName === null ? null : {
			tab,
			componentName
		});
		this.requestNavigation({
			kind: "view-state",
			params: this.paramsForTab(tab)
		});
	}
	pendingFocus = signal(null, ...ngDevMode ? [{ debugName: "pendingFocus" }] : /* istanbul ignore next */ []);
	focusWhenRendered = afterRenderEffect(() => {
		const pending = this.pendingFocus();
		if (pending === null || this.activeTab() !== pending.tab) return;
		this.visibleSections();
		untracked(() => this.pendingFocus.set(null));
		const element = document.getElementById(pending.componentName);
		if (element !== null) {
			focusWithoutOpening(element);
			element.scrollIntoView?.({ block: "center" });
		}
	}, ...ngDevMode ? [{ debugName: "focusWhenRendered" }] : /* istanbul ignore next */ []);
	destinationAfter(result) {
		const expected = this.isCreate() ? "Created" : "Updated";
		if (result.action !== expected && !(result.action === "Unchanged" && !this.isCreate())) return null;
		const number = result.contractNumber.trim().length > 0 ? result.contractNumber.trim() : this.contractNumber().trim();
		return number.length > 0 ? number : null;
	}
	drafts = inject(RECORD_DRAFT_STORE);
	isDirty = signal(false, ...ngDevMode ? [{ debugName: "isDirty" }] : /* istanbul ignore next */ []);
	draftKey = computed(() => {
		if (this.isView()) return null;
		const tradeUnit = this.tradeUnit.code();
		return tradeUnit === null || tradeUnit === "" ? null : {
			mode: this.mode(),
			contractNumber: this.contractNumber(),
			tradeUnit
		};
	}, ...ngDevMode ? [{ debugName: "draftKey" }] : /* istanbul ignore next */ []);
	recoverableDraft = signal(null, ...ngDevMode ? [{ debugName: "recoverableDraft" }] : /* istanbul ignore next */ []);
	recoverableAt = computed(() => {
		const draft = this.recoverableDraft();
		if (draft === null) return null;
		const at = new Date(draft.at);
		return Number.isNaN(at.getTime()) ? null : at.toLocaleTimeString(void 0, {
			hour: "2-digit",
			minute: "2-digit"
		});
	}, ...ngDevMode ? [{ debugName: "recoverableAt" }] : /* istanbul ignore next */ []);
	confirmNavigation() {
		if (this.leavingWithDraftKept) return true;
		if (!this.hasUnsavedWork()) return true;
		if (!this.isEditable() || !this.canWrite()) {
			this.clearDraft();
			return true;
		}
		return this.confirmLeave().pipe(map((leaving) => {
			if (leaving) this.clearDraft();
			return leaving;
		}));
	}
	onBeforeUnload(event) {
		if (this.hasUnsavedWork() && this.canSave()) {
			event.preventDefault();
			event.returnValue = "";
		}
	}
	restoreDraft() {
		const form = this.form;
		const key = this.draftKey();
		if (form === null || key === null) {
			this.recoverableDraft.set(null);
			return;
		}
		const draft = this.drafts.read(key);
		if (draft !== null) {
			if (this.isCreate() && draft.idempotencyKey !== void 0) this.createKey = draft.idempotencyKey;
			for (const [componentName, value] of Object.entries(draft.values)) {
				const control = form.control(componentName);
				if (control !== void 0) {
					control.setValue(value, { emitEvent: false });
					control.markAsDirty();
				}
			}
			form.group.markAsDirty();
			this.isDirty.set(true);
		}
		this.recoverableDraft.set(null);
	}
	leavingWithDraftKept = false;
	reloadAfterUnknownSave() {
		const form = this.form;
		const key = this.draftKey();
		if (form !== null && key !== null) this.writeDraft(key, form);
		this.leavingWithDraftKept = true;
		if (this.isCreate()) this.requestNavigation({
			kind: "origin",
			origin: this.originParam ?? "",
			params: this.returnParams()
		});
		else this.requestNavigation({
			kind: "contract",
			contractNumber: this.contractNumber()
		});
	}
	discardDraft() {
		this.clearDraft();
		this.recoverableDraft.set(null);
		this.createKey = null;
	}
	keyForCreate() {
		this.createKey ??= this.mintIdempotencyKey();
		return this.createKey;
	}
	writeDraft(key, form) {
		this.drafts.write(key, this.dirtyValues(form), this.isCreate() ? this.keyForCreate() : void 0);
	}
	clearDraft() {
		const key = this.draftKey();
		if (key !== null) this.drafts.clear(key);
	}
	watchDraft(form) {
		const key = this.draftKey();
		if (key === null) return;
		const existing = this.drafts.read(key);
		if (existing !== null && Object.keys(existing.values).length > 0) this.recoverableDraft.set({ at: existing.savedAt });
		form.group.valueChanges.pipe(debounceTime(DRAFT_DEBOUNCE_MS), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
			const current = this.draftKey();
			if (current !== null) this.writeDraft(current, form);
		});
		form.group.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.isDirty.set(form.group.dirty));
	}
	confirm = injectConfirm();
	confirmLeave() {
		return this.confirm({
			title: "Leave without saving?",
			message: "This contract has changes that have not been sent to CTRM. Leaving now discards them.",
			confirmLabel: "Discard changes",
			cancelLabel: "Keep editing",
			destructive: true
		});
	}
	onEscape(event) {
		if (event.defaultPrevented || !this.isView()) return;
		this.requestNavigation({
			kind: "origin",
			origin: this.originParam ?? "",
			params: this.returnParams()
		});
	}
	host = inject(ElementRef);
	constructor() {
		effect(() => {
			if (this.bundle() === null) return;
			const outcome = untracked(() => this.saveAnnouncements.take(this.contractNumber()));
			if (outcome !== null) untracked(() => this.arrivedAfterSave.set(outcome));
		});
		this.registerRecordShortcuts();
	}
	registerRecordShortcuts() {
		registerShortcuts([
			{
				keys: "ctrl+s",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Save",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.canSave(),
				run: () => this.onSave()
			},
			{
				keys: "ctrl+shift+s",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Save and close",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.canSave(),
				run: () => this.saveAndClose()
			},
			{
				keys: "f8",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Validation summary (again: next item)",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.isEditable(),
				run: () => this.summaryPanel()?.focusNext()
			},
			{
				keys: "ctrl+pagedown",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Next section",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.bundle() !== null,
				run: () => this.stepSection(1)
			},
			{
				keys: "ctrl+pageup",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Previous section",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.bundle() !== null,
				run: () => this.stepSection(-1)
			},
			{
				keys: "enter",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Next field",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.bundle() !== null && this.isEditable(),
				accepts: (event) => advancesOnEnter(event),
				run: (event) => this.advanceField(event.target)
			},
			{
				keys: "f4",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Open the list or calendar of this field",
				group: "This contract",
				note: "F4 on the green screen",
				allowInTextInput: true,
				available: () => this.bundle() !== null && this.isEditable(),
				accepts: (event) => event.target instanceof Element && event.target.hasAttribute(LOOKUP_ATTRIBUTE),
				run: (event) => event.target?.dispatchEvent(new CustomEvent(OPEN_LOOKUP_EVENT))
			}
		]);
	}
	advanceField(from) {
		const fields = [...this.host.nativeElement.querySelectorAll(ADVANCE_STOPS)];
		fields[fields.indexOf(from) + 1]?.focus();
	}
	saveAndClose() {
		if (!this.canSave()) return;
		this.closeAfterSave = true;
		this.onSave();
	}
	closeAfterSave = false;
	stepSection(direction) {
		const sections = this.visibleSections();
		const element = this.host.nativeElement;
		const current = sections.findIndex((name) => this.sectionHasFocus(element, name));
		const next = current === -1 ? direction === 1 ? 0 : sections.length - 1 : current + direction;
		if (next >= 0 && next < sections.length) {
			this.focusSection(element, sections[next]);
			return;
		}
		const tabs = this.configuredTabs();
		const target = tabs.findIndex((tab) => tab.id === this.activeTab()) + direction;
		if (target < 0 || target >= tabs.length) return;
		this.requestNavigation({
			kind: "view-state",
			params: this.paramsForTab(tabs[target].id)
		});
	}
	sectionHasFocus(host, section) {
		const box = host.querySelector(`[data-section="${section}"]`);
		return box !== null && document.activeElement !== null && box.contains(document.activeElement);
	}
	focusSection(host, section) {
		const box = host.querySelector(`[data-section="${section}"]`);
		if (box === null) return;
		const focusable = box.querySelector("input:not([disabled]):not([readonly]), select:not([disabled]), textarea:not([disabled]):not([readonly]), button:not([disabled])");
		if (focusable === null) {
			box.scrollIntoView({ block: "start" });
			return;
		}
		focusable.focus();
		box.scrollIntoView({ block: "start" });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ContractRecordPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ContractRecordPageComponent,
		isStandalone: true,
		selector: "cms-contract-record-page",
		inputs: {
			contractNumber: {
				classPropertyName: "contractNumber",
				publicName: "contractNumber",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { listeners: {
			"window:beforeunload": "onBeforeUnload($event)",
			"document:keydown.escape": "onEscape($event)"
		} },
		viewQueries: [{
			propertyName: "addendumSection",
			first: true,
			predicate: ContractAddendumSectionComponent,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "summaryPanel",
			first: true,
			predicate: ValidationSummaryComponent,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<!--\r\n  The contract record screen — viewing, editing and creating, from one template.\r\n\r\n  🔴 THE SHAPE, and read this before adding anything to it (JFrisbie, 2026-09-01).\r\n\r\n  This page is four bands and nothing else:\r\n\r\n    1. breadcrumb + actions  where you are, and what you can do to this record\r\n    2. header                what this record IS\r\n    3. summary strip         the at-a-glance state — always visible, every tab, every mode\r\n    4. tabs + body           the fields of ONE tab, then that tab's collections\r\n\r\n  It used to be eleven full-width section cards stacked down the page with all four child grids after\r\n  them, which is \"so many fields prior to the child grids that it's just too much\" — 111 controls before\r\n  the first table. The tabs come from the Power App traders use today (`fxTabOptions`), so the grouping\r\n  is the business's rather than a fourth opinion from this lane. See `CONTRACT_TABS`.\r\n\r\n  The mode is still allowed to change exactly three things — whether the controls accept input, which\r\n  buttons are in the toolbar, and which contextual alerts apply. It must never change the SHAPE, or\r\n  add/edit stops looking like view, which is the whole point of one component.\r\n-->\r\n<section class=\"cws:space-y-4\">\r\n  <!--\r\n    `containerState()`, not the configuration's state alone: the record needs two reads, and gating on\r\n    the configuration rendered a full set of empty controls when the contract read had failed. See the\r\n    component.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    loadingLabel=\"Loading contract\"\r\n    (retry)=\"retry()\"\r\n  >\r\n    @if (bundle(); as loaded) {\r\n      <div class=\"cws:space-y-4\">\r\n        <!-- #803: the save that brought the user here, said by the screen they arrived on. -->\r\n        <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\r\n\r\n        <!--\r\n          🔴 THE TOP ROW — breadcrumb left, record actions hard right (JFrisbie, 2026-09-02).\r\n\r\n          The actions used to sit inside the header card, level with the contract number. They belong\r\n          ABOVE it, for the same reason the workspace grid puts *Add Contract* on its own header row:\r\n          they act on the whole record, so they read as page-level actions rather than as something\r\n          attached to the title. One placement across both screens is the point — nobody should have\r\n          to look somewhere different for the primary action depending on which screen they are on.\r\n\r\n          ⚠ The actions are a SIBLING of the `<nav>`, never inside it. A breadcrumb is navigation and\r\n          the ARIA pattern is what tells a screen-reader user so; anchors dropped in would be\r\n          announced as extra crumbs. The view spec pins the nav at exactly one anchor, so nesting\r\n          them here fails a test rather than shipping quietly.\r\n\r\n          **`items-end`, so the BOTTOM of the buttons meets the bottom of the breadcrumb text**\r\n          (JFrisbie, 2026-09-02). The buttons are ~38px against the crumb's 20px line box, so\r\n          `items-center` left them straddling it and neither edge lined up with anything.\r\n\r\n          ⚠ Not `items-baseline`, which is the tempting one and is wrong here: it would align the\r\n          button's *label* baseline with the crumb's, pushing the button's padding and border below\r\n          the text and putting the bottoms further out than `items-center` had them. The request is\r\n          about the buttons' bottom EDGE, which is a box alignment, not a text one.\r\n\r\n          The grid's header row is also `items-end`; it carries `self-start` on its action block only\r\n          because its left column is a heading over a description and the button was wanted level\r\n          with the top of that. Here the left column is one line, so the row's own alignment stands.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n          <!--\r\n            The trail back — one definition, shared with the approval review and pricing screens.\r\n\r\n            🔴 **This markup was the original and is now `cms-breadcrumb`.** It was correct here and\r\n            copied almost-correctly elsewhere: the pricing screen had grown an anchor and two spans\r\n            with no list and no `aria-current`, so the same control announced itself as navigation on\r\n            two screens out of three. Extracting the version that was right, rather than writing a\r\n            fourth, is what makes this change a no-op on this screen.\r\n\r\n            ⚠ **`trail()` still owns the JOURNEY** — which screens are behind you, and whether the\r\n            approvals review sits between the queue and here. The component owns only how a trail is\r\n            drawn. Those are different questions and they stayed in different places deliberately.\r\n\r\n            ⚠ `returnParams()` rides on every crumb; see the component for the silent failure that\r\n            guards against.\r\n          -->\r\n          <cms-breadcrumb\r\n            [crumbs]=\"crumbs()\"\r\n            [current]=\"currentCrumb()\"\r\n            [context]=\"tradeUnitLabel()\"\r\n            [queryParams]=\"returnParams()\"\r\n          />\r\n\r\n          <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n            @if (isView()) {\r\n              <!--\r\n                Refresh, to the LEFT of Edit and in view mode only (JFrisbie, 2026-09-03).\r\n\r\n                Re-reads this contract — both reads, the aggregate and `/fields` — without touching the\r\n                route, so the tab you are on and the journey back to the workspace both survive. It\r\n                sits inside the `isView()` branch rather than being rendered disabled in the other\r\n                modes, which is what \"only usable in view/idle\" asks for: while editing, the control\r\n                that re-reads from CTRM would compete with unsaved changes, and a disabled button is an\r\n                invitation to wonder why.\r\n\r\n                ⚠ So this is the one thing on this row that does NOT hold the same position in all\r\n                three modes. That is a deliberate exception to the invariant noted above: Save and\r\n                Cancel still occupy the place Edit and New occupy, and refresh is additive to the view\r\n                mode rather than a fourth mode-dependent slot.\r\n              -->\r\n              <cms-refresh-button\r\n                label=\"Refresh this contract\"\r\n                [busy]=\"isRefreshing()\"\r\n                (refresh)=\"refresh()\"\r\n              />\r\n\r\n            <!--\r\n              🔴 The three WRITE controls, together, gated as one (F4.3a, extending #155).\r\n\r\n              Copy, Edit and New all end at a screen whose Save requires the Admin role, so showing\r\n              them to a reader is an invitation to fill in 111 fields and be refused — the defect\r\n              #155 removed at the Save button, met three steps earlier.\r\n\r\n              ⚠ **Refresh stays outside this gate.** It re-reads the contract, which any signed-in\r\n              user may do (correction C-14 keeps reads un-scoped), and it is the one control on this\r\n              row a reader genuinely wants.\r\n\r\n              🔴 **Hidden, not disabled** — the opposite call from \"Copy contract w/ pricing\" three\r\n              lines down, and the difference is worth stating because both are deliberate. That item\r\n              is disabled because the capability does not exist for ANYONE and naming its blocker is\r\n              useful to every reader. These are absent because they do not exist for THIS ACCOUNT,\r\n              and a row of greyed buttons tells a user nothing they can act on. One sentence below\r\n              says why, once, instead of three disabled promises.\r\n\r\n              ⚠ Gated on the GRANT only (#411). A refusal that is about the trade unit (not onboarded)\r\n              or about CTRM (the availability gate) is not about this account, so the block stays and\r\n              the CTRM writes in it, Close and Re-open, are disabled with the reason instead. Copy, Edit\r\n              and New only navigate; the Save they lead to carries the same refusal.\r\n            -->\r\n            @if (canWriteCws()) {\r\n                <!--\r\n                  Copy, immediately right of Refresh (JFrisbie, 2026-09-10). BR-041.\r\n\r\n                  **One icon trigger opening a menu of two, rather than two buttons** (JFrisbie,\r\n                  2026-09-10). The first revision put both on the row, which made five controls and\r\n                  629px of toolbar for what is one decision with two answers — and it gave the rarer,\r\n                  currently-unavailable option exactly as much prominence as the ordinary one.\r\n\r\n                  Same shape as the workspace's Export menu: `cmsDropdown` for the open/close\r\n                  behaviour, `role=\"menu\"` markup owned here. The directive is deliberately behaviour\r\n                  and not a component, because a shared component would have had to pick between\r\n                  `role=\"menu\"` and `role=\"listbox\"` for every caller.\r\n\r\n                  ⚠ **The directive's Escape handling matters more on this screen than anywhere else.**\r\n                  This record screen binds Escape to navigate back to the contract list, and\r\n                  `DropdownDirective` calls `preventDefault()` when Escape actually dismissed a panel —\r\n                  so closing this menu with Escape does not also throw the user off the record. That\r\n                  interaction is already handled; do not add a local Escape listener.\r\n                -->\r\n                <div cmsDropdown #copyMenu=\"cmsDropdown\" class=\"cws:relative\">\r\n                  <!--\r\n                    Icon-only, so it needs both an `aria-label` and the 20px line box.\r\n\r\n                    🔴 **`h-5` on the icon wrapper is load-bearing, not decoration.** A `scoular-btn`\r\n                    is 38px only while it contains *text*: `py-2` plus a `text-sm` line box plus a 1px\r\n                    border. An icon has no line box, so an icon-only button renders **36px** and sits\r\n                    two pixels short of Edit and New beside it. The wrapper restores the line box the\r\n                    missing text would have occupied — and `h-5` is chosen because **height is\r\n                    uncontested**: the design system compiles unlayered and would beat a utility\r\n                    fighting its `py-2`, but it never declares a height. Measured at 38px against the\r\n                    other three controls across five viewport widths.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    aria-label=\"Copy this contract\"\r\n                    title=\"Copy this contract\"\r\n                    aria-haspopup=\"menu\"\r\n                    [attr.aria-expanded]=\"copyMenu.open()\"\r\n                    (click)=\"copyMenu.toggle()\"\r\n                  >\r\n                    <span class=\"cws:flex cws:h-5 cws:items-center\" aria-hidden=\"true\">\r\n                      <!--\r\n                        Two offset rounded rectangles — the conventional duplicate mark. Stroked in\r\n                        currentColor so it inherits the button's text colour in both themes, and\r\n                        `size-4` to match the refresh mark immediately left of it.\r\n                      -->\r\n                      <svg\r\n                        viewBox=\"0 0 24 24\"\r\n                        fill=\"none\"\r\n                        stroke=\"currentColor\"\r\n                        stroke-width=\"2\"\r\n                        stroke-linecap=\"round\"\r\n                        stroke-linejoin=\"round\"\r\n                        class=\"cws:size-4 cws:shrink-0\"\r\n                      >\r\n                        <rect x=\"8\" y=\"8\" width=\"14\" height=\"14\" rx=\"2\" ry=\"2\" />\r\n                        <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\" />\r\n                      </svg>\r\n                    </span>\r\n                  </button>\r\n\r\n                  @if (copyMenu.open()) {\r\n                    <!--\r\n                      `w-80` because the second item's subtext explains why it is unavailable, and the\r\n                      panel's own `min-w-[12rem]` would wrap it into four lines.\r\n\r\n                      Left-anchored (`right-0`) like every other menu on this row's side of the page,\r\n                      so it opens inward rather than off the edge of the viewport.\r\n                    -->\r\n                    <div\r\n                      class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\"\r\n                      role=\"menu\"\r\n                      aria-label=\"Copy contract\"\r\n                    >\r\n                      <div class=\"scoular-dropdown-header\">Create a copy of {{ contractNumber() }}</div>\r\n\r\n                      <!--\r\n                        An anchor rather than a button, so middle-click and \"open in new tab\" work and\r\n                        it carries a real `href` — the same reasoning the breadcrumb crumbs carry. It\r\n                        addresses the ordinary create route with a seed parameter, so a copy is a\r\n                        linkable URL rather than transient in-memory state: reload it and you still\r\n                        get the copy.\r\n\r\n                        ⚠ It carries no `returnTo`. The copy's Cancel goes to the workspace, exactly as\r\n                        an ordinary create's does, because abandoning a create should not land the user\r\n                        back on someone else's contract as though they had been editing it.\r\n\r\n                        `text-left` on the item is load-bearing for the same reason the Export menu\r\n                        records: `.scoular-dropdown-item` inherits `text-align: center` from `<button>`,\r\n                        and a subtext long enough to wrap centres its second line.\r\n                      -->\r\n                      <a\r\n                        role=\"menuitem\"\r\n                        class=\"scoular-dropdown-item cws:text-left\"\r\n                        [attr.href]=\"hrefFor(copyIntent())\"\r\n                        (click)=\"copyMenu.close(); follow($event, copyIntent())\"\r\n                      >\r\n                        <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                          <span>Copy contract</span>\r\n                          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            Every field, a new contract number, no pricing\r\n                          </span>\r\n                        </span>\r\n                      </a>\r\n\r\n                      <!--\r\n                        #459 (F3.4), go given 2026-10-07. Prices cannot ride the create (`prices` is\r\n                        not writable on `upsertContract`), so this is a **sequenced two-step**: create\r\n                        the contract, then post each price sequence UNAPPROVED over the pricing routes,\r\n                        every one read back. The second step can fail after the first has spent the\r\n                        number, which is why it ASKS first and says so, and why its results are shown\r\n                        per sequence on the contract it made (`cws-pricing-copy-panel`).\r\n\r\n                        ⚠ A host without a pricing seam keeps the item disabled with its reason, rather\r\n                        than starting a copy whose second half has nowhere to go.\r\n                      -->\r\n                      @if (pricingCopyOffered) {\r\n                        <button\r\n                          type=\"button\"\r\n                          role=\"menuitem\"\r\n                          class=\"scoular-dropdown-item cws:text-left\"\r\n                          [attr.aria-expanded]=\"copyPricingConfirm()\"\r\n                          (click)=\"copyPricingConfirm.set(!copyPricingConfirm())\"\r\n                        >\r\n                          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                            <span>Copy contract w/ pricing</span>\r\n                            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              Every field, then each price sequence, unapproved\r\n                            </span>\r\n                          </span>\r\n                        </button>\r\n\r\n                        @if (copyPricingConfirm()) {\r\n                          <div\r\n                            data-testid=\"copy-pricing-confirm\"\r\n                            class=\"cws:space-y-2 cws:border-t cws:border-slate-200 cws:px-4 cws:py-3 cws:text-xs cws:text-slate-600 cws:dark:border-slate-700 cws:dark:text-slate-300\"\r\n                          >\r\n                            <p>\r\n                              Creating the copy <strong>spends a new contract number</strong>, whatever\r\n                              then happens to the prices. Each price sequence is then posted unapproved\r\n                              and read back; any not copied are listed for you to retry.\r\n                            </p>\r\n                            @if (sourcePriceCount() > 10) {\r\n                              <p>\r\n                                {{ contractNumber() }} has {{ sourcePriceCount() }} price sequences, and\r\n                                each is posted one at a time, so this takes a while.\r\n                              </p>\r\n                            }\r\n                            <div class=\"cws:flex cws:gap-2\">\r\n                              <button\r\n                                type=\"button\"\r\n                                class=\"scoular-btn scoular-btn-primary scoular-btn-sm\"\r\n                                (click)=\"copyMenu.close(); confirmCopyWithPricing()\"\r\n                              >\r\n                                Copy with pricing\r\n                              </button>\r\n                              <button\r\n                                type=\"button\"\r\n                                class=\"scoular-btn scoular-btn-outline scoular-btn-sm\"\r\n                                (click)=\"copyPricingConfirm.set(false)\"\r\n                              >\r\n                                Cancel\r\n                              </button>\r\n                            </div>\r\n                          </div>\r\n                        }\r\n                      } @else {\r\n                        <button\r\n                          type=\"button\"\r\n                          role=\"menuitem\"\r\n                          disabled\r\n                          class=\"scoular-dropdown-item cws:text-left\"\r\n                          aria-describedby=\"copy-with-pricing-blocker\"\r\n                        >\r\n                          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                            <span>Copy contract w/ pricing</span>\r\n                            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              Not available here — this application has no pricing connection\r\n                            </span>\r\n                          </span>\r\n                        </button>\r\n\r\n                        <!--\r\n                          The disabled item's full reason, for a screen reader. `sr-only` positions\r\n                          absolutely, so it is out of flow and cannot affect the menu's layout — which is\r\n                          the trap that lifted a grid row by 28px on 2026-09-09, when `sr-only` went on a\r\n                          label row instead of on the label text.\r\n                        -->\r\n                        <span id=\"copy-with-pricing-blocker\" class=\"sr-only\">\r\n                          Copying with pricing is not available here, because this application has no\r\n                          pricing connection. Copy the contract, then add its price sequences on the\r\n                          pricing screen once it is saved.\r\n                        </span>\r\n                      }\r\n                    </div>\r\n                  }\r\n                </div>\r\n\r\n                <!--\r\n                  F3.5 — close / re-open, offered only where the host provided the action and the\r\n                  contract has loaded. Gated on `canWrite()` with the rest of this block.\r\n\r\n                  🔴 **Close CONFIRMS, and the confirmation carries the provenance sentence** — closing\r\n                  rewrites pricing-approval provenance and re-opening does not put it back, so the pair\r\n                  is not symmetric and the dialog says so rather than implying an undo.\r\n                -->\r\n                @if (canChangeState()) {\r\n                  <!-- #411: disabled with the reason as its title (the F4.3a style) when CTRM will not take it. -->\r\n                  @if (isClosed()) {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working' || ctrmWriteBlock() !== null\"\r\n                      [attr.title]=\"ctrmWriteBlock()\"\r\n                      (click)=\"onReopenContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Re-opening… } @else { Re-open contract }\r\n                    </button>\r\n                  } @else {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working' || ctrmWriteBlock() !== null\"\r\n                      [attr.title]=\"ctrmWriteBlock()\"\r\n                      (click)=\"onCloseContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Closing… } @else { Close contract }\r\n                    </button>\r\n                  }\r\n                }\r\n\r\n                <!--\r\n                  Carries the tab, so Edit → Cancel returns you to the tab you were reading.\r\n                  JFrisbie, 2026-10-23: a read-only contract (closed, or an intercompany purchase) offers\r\n                  no Edit, and says why where it would be.\r\n                -->\r\n                @if (readOnlyReason(); as reason) {\r\n                  <p role=\"status\" class=\"cws:self-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"read-only-reason\">\r\n                    {{ reason }}. It cannot be edited.\r\n                  </p>\r\n                } @else {\r\n                  <a\r\n                    [attr.href]=\"hrefFor(editIntent())\"\r\n                    (click)=\"follow($event, editIntent())\"\r\n                    class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                  >\r\n                    Edit contract\r\n                  </a>\r\n                }\r\n\r\n                <a\r\n                  [attr.href]=\"hrefFor(newIntent)\"\r\n                  (click)=\"follow($event, newIntent)\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                >\r\n                  New contract\r\n                </a>\r\n\r\n                @if (writeRefusal(); as refusal) {\r\n                  <!-- The visible half of the disabled controls' title, said once (#411). -->\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    {{ refusal.message }}\r\n                  </p>\r\n                }\r\n            } @else {\r\n              <!--\r\n                The reason, once — matching the wording the Save gate already uses so a user who\r\n                meets both does not read them as two different problems.\r\n\r\n                `role=\"status\"` rather than `alert`: it is a standing property of the screen, not\r\n                something that just happened.\r\n              -->\r\n              <p role=\"status\" class=\"cws:self-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                Editing needs the <strong>Admin</strong> role on this application.\r\n              </p>\r\n            }\r\n            } @else {\r\n              <!--\r\n                JFrisbie, 2026-10-23: greyed out while a required field on any tab is blank, and the hover\r\n                names them. aria-disabled rather than disabled, so a press still runs the hold: the summary\r\n                opens and the first blank field gets focus.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                [disabled]=\"!canSave()\"\r\n                [attr.aria-disabled]=\"saveHoldText() !== null ? 'true' : null\"\r\n                [class.cws:opacity-50]=\"saveHoldText() !== null\"\r\n                [class.cws:cursor-not-allowed]=\"saveHoldText() !== null\"\r\n                [attr.title]=\"saveHoldText()\"\r\n                data-testid=\"save-contract\"\r\n                (click)=\"onSave()\"\r\n              >\r\n                @if (save().status === 'saving' && !notifying()) {\r\n                  Saving…\r\n                } @else {\r\n                  <!--\r\n                    **One label in both modes** — \"Save contract\" whether adding or editing (JFrisbie,\r\n                    2026-09-03). It read \"Create contract\" on a create and \"Save changes\" on an edit.\r\n                    One verb for one action: the button does the same thing to the same record either\r\n                    way, and the mode is already unmistakable from the heading, the breadcrumb and the\r\n                    URL.\r\n\r\n                    ⚠ It therefore stops being the thing that tells the two modes apart, which two\r\n                    tests were using it for. Those now discriminate on the **heading** — \"New contract\"\r\n                    against the contract number — which is the more honest signal anyway: it is what a\r\n                    user reads to know which record they are on.\r\n                  -->\r\n                  Save contract\r\n                }\r\n              </button>\r\n\r\n              <!--\r\n                #812: Save & Notify (docs/02 §3.2, BR-064). The same save, asking CTRM to email the\r\n                contract's trader, which CTRM does only when the contract needs approval. Offered to\r\n                every writer (JFrisbie, 2026-10-15). Not the Log tab's Notify trader, which sends CWS's\r\n                own email.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-secondary\"\r\n                [disabled]=\"!canSave()\"\r\n                [attr.aria-disabled]=\"saveHoldText() !== null ? 'true' : null\"\r\n                [class.cws:opacity-50]=\"saveHoldText() !== null\"\r\n                [class.cws:cursor-not-allowed]=\"saveHoldText() !== null\"\r\n                [attr.title]=\"saveHoldText()\"\r\n                aria-describedby=\"save-and-notify-hint\"\r\n                (click)=\"onSave(true)\"\r\n              >\r\n                @if (save().status === 'saving' && notifying()) {\r\n                  Saving…\r\n                } @else {\r\n                  Save and notify\r\n                }\r\n              </button>\r\n              <span id=\"save-and-notify-hint\" class=\"cws:sr-only\">\r\n                CTRM emails the contract's trader if the contract needs approval.\r\n              </span>\r\n\r\n              @for (reason of saveErrorGroups().save; track reason) {\r\n                <!-- #830: another save of this contract is running. Said beside Save, as the API asks. -->\r\n                <p role=\"status\" class=\"cws:max-w-64 cws:self-center cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\" data-testid=\"save-in-flight\">\r\n                  {{ reason }}\r\n                </p>\r\n              }\r\n\r\n              @if (canWrite() && shipPeriodHoldReason(); as reason) {\r\n                <!--\r\n                  #839: the reason a ship period holds Save, beside Save. It used to show only at the\r\n                  foot of Shipping Info, one tab away from a user looking at a grey button.\r\n                -->\r\n                <!-- Bounded rather than full width: this row does not wrap, and full width squeezed Save. -->\r\n                <p role=\"status\" class=\"cws:max-w-64 cws:self-center cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\r\n                  {{ reason }}\r\n                </p>\r\n              }\r\n\r\n              @if (!canWrite()) {\r\n                <!--\r\n                  🔴 The REASON, not just a grey button (#155). Writing contracts needs the Admin app\r\n                  role — `CwsContractWriter` — while reading needs only Admin or User, so a perfectly\r\n                  legitimate user reaches this screen, fills it in and is refused at Save with nothing\r\n                  having said why.\r\n\r\n                  ⚠ Worded as what the account lacks rather than \"you do not have permission\", because\r\n                  the fix is an Entra app-role assignment someone has to request by name — the same\r\n                  reason the trade-unit picker names the role rather than saying access denied (#65).\r\n\r\n                  `role=\"status\"` rather than `alert`: it is a standing condition of the screen, not an\r\n                  event, and an assertive announcement on every render of a read-only record is noise.\r\n                -->\r\n                <!--\r\n                  #485: a night run now closes the availability gate every night, and an Admin was told\r\n                  they lacked the Admin role. The two gates have two sentences; the role one wins when\r\n                  both are closed, because it is the one the user can act on.\r\n                -->\r\n                <!--\r\n                  #411: the trade unit's refusal sits between the two, as the server orders them —\r\n                  permission, then onboarding — and ahead of CTRM's availability.\r\n                -->\r\n                @if (canWriteCws() && writeRefusal(); as refusal) {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    {{ refusal.message }} Your changes stay on this screen.\r\n                  </p>\r\n                } @else if (canWriteCws() && blockedByAvailability()) {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving to CTRM is paused: {{ availabilityTitle() }}. Your changes stay on this\r\n                    screen.\r\n                  </p>\r\n                } @else {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving needs the <strong>Admin</strong> role on this application. Your account can\r\n                    view contracts but not write them.\r\n                  </p>\r\n                }\r\n              }\r\n\r\n              <!--\r\n                Cancel carries its OWN parameters, not Edit's. An edit returns to this record on the tab\r\n                it was editing; a create returns to the workspace, where a `tab` parameter would be\r\n                meaningless noise in a URL people copy and share.\r\n              -->\r\n              <!-- #967: refused while a save is in flight; see `cancelDisabled`. -->\r\n              <a\r\n                [attr.href]=\"hrefFor(cancelIntent())\"\r\n                (click)=\"followCancel($event)\"\r\n                [attr.aria-disabled]=\"cancelDisabled() ? 'true' : null\"\r\n                [class.cws:opacity-50]=\"cancelDisabled()\"\r\n                [class.cws:cursor-not-allowed]=\"cancelDisabled()\"\r\n                class=\"scoular-btn scoular-btn-secondary\"\r\n              >\r\n                Cancel\r\n              </a>\r\n            }\r\n          </div>\r\n\r\n          <!--\r\n            #803: the last close or re-open. A failure is an alert, not a status: this DID just happen,\r\n            and it needs to interrupt. It also states that nothing changed, because the failure a user\r\n            most fears here is a half-applied one.\r\n\r\n            ⚠ Rendered only while there is an outcome, and `basis-full` so it takes a line of its own.\r\n            This row is `justify-between`: an always-present third child, even an empty one, split the\r\n            free space three ways and pulled the actions off the right edge to the middle.\r\n          -->\r\n          @if (stateOutcome()) {\r\n            <div class=\"cws:basis-full\" data-testid=\"state-outcome\">\r\n              <cms-status-message [outcome]=\"stateOutcome()\" (dismissed)=\"stateOutcome.set(null)\" />\r\n            </div>\r\n          }\r\n\r\n          @if (summaryEntries().length > 0) {\r\n            <!--\r\n              The validation summary (#791, docs/02 §3.1, 02a §6.2), beside the save actions. Every\r\n              field with an error, client or server, in form order; F8 reaches it. It is where a held\r\n              save explains itself: the entries marked \"must fix\" are what holds it (#791's ruling).\r\n            -->\r\n            <cms-validation-summary\r\n              class=\"cws:basis-full\"\r\n              [entries]=\"summaryEntries()\"\r\n              [(expanded)]=\"summaryExpanded\"\r\n              (chosen)=\"chooseSummaryEntry($event)\"\r\n            />\r\n          }\r\n        </div>\r\n\r\n        <!--\r\n          Header band. The contract number is the page's identity, so it is the h2 — the shell owns the\r\n          only h1.\r\n\r\n          The actions moved out of this card onto the row above it; see the comment there. What has NOT\r\n          changed is that they occupy the same place in all three modes, so the toolbar does not move\r\n          under the pointer when the mode changes — that invariant is why the whole block moved rather\r\n          than only the two view-mode buttons.\r\n        -->\r\n        <header\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <div class=\"cws:space-y-1\">\r\n            <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n              <!--\r\n                The same heading in view and edit, on purpose: a record's identity does not change\r\n                because it is being edited. A create has no number yet — CTRM issues it at reservation\r\n                (03 §2.6) — so the heading says what is being made.\r\n              -->\r\n              <h2 class=\"cws:text-xl cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                {{ isCreate() ? 'New contract' : contractNumber() }}\r\n              </h2>\r\n              @if (contract()?.version; as version) {\r\n                <!-- CTRM's version, not a CMS revision. Muted so it cannot be read as part of the key. -->\r\n                <span\r\n                  class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n                  title=\"CTRM contract version\"\r\n                >\r\n                  v{{ version }}\r\n                </span>\r\n              }\r\n              <!--\r\n                FileBound's document archive for this contract (docs/02 §8, #756). Pushed right with\r\n                `ml-auto` so it never reads as part of the number. Absent when no template is\r\n                configured, and on a create, which has no number yet. A new tab with\r\n                `noopener noreferrer`, because it leaves CWS.\r\n              -->\r\n              @if (fileBoundUrl(); as url) {\r\n                <a\r\n                  [href]=\"url\"\r\n                  target=\"_blank\"\r\n                  rel=\"noopener noreferrer\"\r\n                  class=\"cws:ml-auto cws:rounded cws:text-sm cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\r\n                  data-testid=\"filebound-link\"\r\n                >\r\n                  Document archive (FileBound)\r\n                  <span class=\"cws:sr-only\">(opens in a new tab)</span>\r\n                </a>\r\n              }\r\n            </div>\r\n            <!--\r\n              🔴 The header as an executive summary (JFrisbie, 2026-09-15 — UX brief item 1): what\r\n              contract this is, and the business context, without scrolling.\r\n\r\n              ⚠ **Status and the key quantities are deliberately NOT repeated here.** The brief's\r\n              sketch puts them in this block; they already sit in the summary band immediately below,\r\n              which is always visible in every mode and on every tab. Two copies of \"Priced 9,000 BU\"\r\n              one line apart is a number that can disagree with itself, which this repository has paid\r\n              for more than once — and the band is not a scroll away, it is the next element.\r\n\r\n              ⚠ **\"Last Modified\" is absent because CTRM does not send one.** Nothing on the aggregate\r\n              carries it; `version` is the nearest thing CTRM has and it is already beside the number.\r\n              Inventing a timestamp from the read would be a fact about our request, not the contract.\r\n\r\n              ⚠ **The CUSTOMER here is the id.** `getContract` carries no customer-name field and\r\n              never will; the name comes from the customer directory and is shown on the Customer\r\n              name field below, where the record screen also confirms a typed id on blur (F4.3b).\r\n              The header keeps the id because the id is the fact CTRM holds.\r\n            -->\r\n            <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n              @if (contract(); as detail) {\r\n                <!--\r\n                  Both the code and the name where we have them, for the same reason the grid's heading\r\n                  carries both: a code identifies a trade unit to CTRM, a name identifies it to a trader.\r\n                -->\r\n                {{ detail.header.commodity ?? 'Commodity not set' }}\r\n                @if (detail.header.tradeUnit) {\r\n                  · Trade unit {{ detail.header.tradeUnit }}\r\n                }\r\n                @if (detail.header.customerId) {\r\n                  · Customer {{ detail.header.customerId }}\r\n                }\r\n                @if (contractDateLabel(); as date) {\r\n                  · {{ date }}\r\n                }\r\n                @if (traderLabel(); as trader) {\r\n                  · Trader {{ trader }}\r\n                }\r\n              } @else {\r\n                Trade unit {{ loaded.config.tradeUnit }} · Field definitions from CTRM\r\n              }\r\n            </p>\r\n            <!--\r\n              #973: the LMS flag, CTRM contract note LMSFLAG (the server half #985). In the header\r\n              because it is a fact about the whole contract, not a field on one tab, and the header is\r\n              visible in every mode and on every tab.\r\n\r\n              - `none`/`manual`: a checkbox in edit and create, \"No\"/\"Yes\" in view.\r\n              - `automatic`: a read-only \"Yes\", because CTRM sets it for an LMS special type and the\r\n                API refuses clearing it.\r\n              - `unknown`: said, never shown as an unticked box that may be wrong.\r\n\r\n              A native checkbox with its own label, as \"Hide empty fields\" is. Only a change the user\r\n              made is sent; see `lmsFlagChanged`.\r\n            -->\r\n            <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-x-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"lms-flag\">\r\n              @if (lmsFlagRead().state === 'unknown') {\r\n                <span role=\"status\" data-testid=\"lms-flag-unknown\">{{ lmsFlagUnknownMessage }}</span>\r\n              } @else if (canEditLmsFlag()) {\r\n                <label class=\"cws:inline-flex cws:cursor-pointer cws:items-center cws:gap-2\">\r\n                  <input\r\n                    type=\"checkbox\"\r\n                    class=\"cws:size-4 cws:accent-scoular-blue\"\r\n                    [checked]=\"lmsFlagValue()\"\r\n                    (change)=\"setLmsFlag($any($event.target).checked)\"\r\n                    data-testid=\"lms-flag-checkbox\"\r\n                  />\r\n                  LMS contract\r\n                </label>\r\n              } @else {\r\n                <span>\r\n                  LMS contract:\r\n                  <strong data-testid=\"lms-flag-value\">{{ lmsFlagValue() ? 'Yes' : 'No' }}</strong>\r\n                </span>\r\n                @if (lmsFlagRead().state === 'automatic') {\r\n                  <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"lms-flag-automatic\">\r\n                    (set by CTRM for this special type)\r\n                  </span>\r\n                }\r\n              }\r\n              @for (reason of saveErrorGroups().lmsFlag; track reason) {\r\n                <p role=\"alert\" class=\"cws:basis-full cws:text-xs cws:text-red-700 cws:dark:text-red-300\" data-testid=\"lms-flag-error\">\r\n                  {{ reason }}\r\n                </p>\r\n              }\r\n            </div>\r\n          </div>\r\n\r\n        </header>\r\n\r\n        <!--\r\n          🔴 THE SUMMARY STRIP — the at-a-glance state, above the tabs and outside them.\r\n\r\n          Confirmations (docs/02 §4.4) and CTRM's computed quantity breakdown (docs/04 §6) were two\r\n          full-width cards stacked before any field, and then invisible from wherever you scrolled to.\r\n          They are the answers to \"is this approved\" and \"what is left to price\", which are the two\r\n          questions somebody opens a contract to ask — so they sit in one compact band that never\r\n          scrolls away behind a tab.\r\n\r\n          ⚠ **These are NOT form fields and must not become inputs.** All six quantities are\r\n          `access: readOnly` in the constraint dictionary — CTRM refuses them on a write — and all three\r\n          confirmation statuses are derived by BR-065 from a populated field. An input box here would\r\n          invite an edit that cannot exist.\r\n        -->\r\n        <!--\r\n          🔴 **ONE ROW, and the height is the requirement** (JFrisbie, 2026-09-15, from a screenshot).\r\n\r\n          This briefly stacked — confirmations above, a six-card quantity grid below — which gave the\r\n          cards room and cost roughly three times the vertical space on a band whose whole job is to be\r\n          glanceable without scrolling. The boxes are kept and made compact instead: label and value on\r\n          ONE line rather than stacked, so each is a chip rather than a tile.\r\n\r\n          ⚠ `items-center` and `gap-x-8`, not `justify-between` alone — the two groups wrap\r\n          independently at narrow widths, and without a row gap they collide before they wrap.\r\n        -->\r\n        <!--\r\n          🔴 **No border and no shadow on the band itself** (2026-09-21 restyle).\r\n\r\n          The card sat inside a page that already separates it — white on slate-50 in light, slate-800\r\n          on slate-900 in dark — so the border and the shadow were the outermost of THREE nested\r\n          borders around the same information. Removing it costs 2px of height and one visual edge.\r\n\r\n          ⚠ **The fill and the rounding stay.** Without them the band stops being an object and the\r\n          chips read as loose text under the header, which is the failure the original card was\r\n          solving. What is gone is the chrome, not the container.\r\n        -->\r\n        <div\r\n          class=\"cws:flex cws:flex-col cws:gap-3 cws:rounded-lg cws:bg-white cws:px-4 cws:py-3 cws:lg:flex-row cws:lg:flex-wrap cws:lg:items-center cws:lg:justify-between cws:lg:gap-x-8 cws:dark:bg-slate-800\"\r\n        >\r\n          <!--\r\n            🔴 WORKFLOW CARDS, not inline pills (JFrisbie, 2026-09-15 — UX brief item 2).\r\n\r\n            The three statuses read as disconnected captions in a row. As cards they read as what they\r\n            are: three checkpoints on one contract, each with a state.\r\n\r\n            ⚠ **Three independent fields that happen to progress, NOT a state machine.** BR-065 derives\r\n            each from a populated field, so a later stage can be set with an earlier one blank — which\r\n            is why these stay three separate cards rather than becoming a connected stepper. A stepper\r\n            would assert an ordering the data does not have, and would render a contract whose broker\r\n            confirmed before its trader approved as though something had gone wrong.\r\n\r\n            The pill keeps the colour. It carries the state in a word as well as a hue, which is what\r\n            makes the card readable without relying on colour at all.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Contract confirmations\">\r\n            @for (stage of confirmations(); track stage.label) {\r\n              <!--\r\n                🔴 **The chip IS the status now — no pill inside it.** The tint, the dot and the word\r\n                are one box.\r\n\r\n                🔴 **`items-baseline` + an explicit `/5` leading on every text node, and this is the\r\n                whole alignment story for the band** (JFrisbie, 2026-09-21, from a screenshot of the\r\n                running app).\r\n\r\n                The first version of this restyle used `items-center` here and `items-baseline` on the\r\n                quantity chips, with `h-7` fixing the box height. Every box lined up — measured at a\r\n                uniform 28px, which is why the geometry pass called it done — and **the TEXT inside\r\n                them sat on four different baselines**: 46, 47, 48.8 and 51, a 5px spread. `Rejected`\r\n                floated against its own label, and the six metrics sat on a different line from the\r\n                three statuses.\r\n\r\n                🔑 **`items-center` centres each flex item independently**, so an 11px label and a 14px\r\n                value in the same chip are centred separately and their baselines cannot agree. And a\r\n                fixed `h-7` hid it: the boxes were identical, so nothing about the geometry looked\r\n                wrong.\r\n\r\n                The fix is to let the LINE BOX set the height instead. Both text nodes carry `/5`\r\n                (20px), padding is `py-1`, so every chip is 4 + 20 + 4 = **28px — exactly what `h-7`\r\n                was giving** — but now derived from a shared line box, so all eighteen pieces of text\r\n                in the ribbon rest on one baseline.\r\n\r\n                ⚠ **Do not reintroduce `h-7`, and do not drop the `/5`.** Either one restores a height\r\n                that is correct while the text inside drifts, which is the failure a box measurement\r\n                cannot see.\r\n              -->\r\n              <!--\r\n                (The chips were previously 36/34/30 tall depending on whether a badge was inside;\r\n                that raggedness is what the uniform line box removed.)\r\n\r\n                🔑 **The dot is not decoration.** Roughly 1 in 12 men has a colour vision deficiency\r\n                (docs/02a §4), and the state is already carried by the WORD — the dot adds a second\r\n                non-colour cue of position and presence, so the three stages are distinguishable at a\r\n                glance even where the hues are not.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-2 cws:rounded-md cws:px-2.5 cws:py-1\"\r\n                [class]=\"stage.style.chip\"\r\n              >\r\n                <!--\r\n                  ⚠ `self-center`, because an empty inline box has its baseline at its BOTTOM edge —\r\n                  under `items-baseline` the dot would otherwise sit on the text baseline rather than\r\n                  beside the middle of the word.\r\n                -->\r\n                <!--\r\n                  ⚠ The dot sits INSIDE the `<dt>` (#764): a `<div>` in a `<dl>` may hold only\r\n                  `<dt>`/`<dd>`, and a bare `<span>` beside them failed axe's definition-list rule. It\r\n                  is an inline-block with `align-middle`, so the `<dt>` keeps its text baseline for the\r\n                  band's `items-baseline`; `aria-hidden` because the word carries the state.\r\n                -->\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  <span\r\n                    class=\"cws:mr-2 cws:inline-block cws:size-1.5 cws:rounded-full cws:align-middle\"\r\n                    [class]=\"stage.style.dot\"\r\n                    aria-hidden=\"true\"\r\n                  ></span>{{ stage.label }}\r\n                </dt>\r\n                <dd class=\"cws:shrink-0 cws:text-sm/5 cws:font-semibold\" [class]=\"stage.style.text\">\r\n                  @if (stage.badge; as badge) {\r\n                    {{ badge.label }}\r\n                  } @else {\r\n                    <!--\r\n                      ⚠ Still visibly DIFFERENT from a set status rather than an empty pill — the\r\n                      neutral tone plus a lighter weight. An empty pill reads as a status; this reads\r\n                      as no status, which is the truth.\r\n                    -->\r\n                    <span class=\"cws:font-normal\" [title]=\"stage.emptyNote ?? ''\">Not set</span>\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n\r\n          <!--\r\n            🔴 KPI CARDS, not label/value pairs (JFrisbie, 2026-09-15 — UX brief item 3).\r\n\r\n            These were six captions in a flex row, which is how the most important numbers on the page\r\n            ended up the most visually understated. As cards the figure leads and the label supports\r\n            it, which is the reading order a trader actually wants.\r\n\r\n            CTRM's numbers, never recalculated here: disagreeing with the system of record about a\r\n            settled quantity would be worse than not showing it. `tabular-nums` so the figures line up\r\n            as a column of numbers rather than drifting with their digit widths.\r\n\r\n            ⚠ **The unit travels with the number** — see `quantityBreakdown`. A bare grain quantity is a\r\n            recorded defect on this project, not a nicety.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Quantity breakdown\">\r\n            @for (measure of quantityBreakdown(); track measure.label) {\r\n              <!--\r\n                🔴 **A fill, not a border, and no left accent.** These were bordered pills carrying a\r\n                4px coloured edge each — six of them, which was the densest chrome in the band. A flat\r\n                tint separates a chip from the card just as well and draws no lines.\r\n\r\n                ⚠ **Uniformly slate, deliberately.** Colour in this band means status; these are\r\n                arithmetic. The removed accent and the reasoning are on `quantityBreakdown`.\r\n\r\n                The hierarchy is carried by weight and size instead: the label drops to 11px and the\r\n                figure stays `font-semibold`, so the number leads its chip without either growing.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-1.5 cws:rounded-md cws:bg-slate-100 cws:px-2.5 cws:py-1 cws:dark:bg-slate-700/40\"\r\n              >\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  {{ measure.label }}\r\n                </dt>\r\n                <dd class=\"cws:text-sm/5 cws:font-semibold cws:tabular-nums cws:text-slate-900 cws:dark:text-white\">\r\n                  @if (measure.value === null) {\r\n                    <!-- An em dash, never 0: CTRM holding no figure is not a quantity of nothing. -->\r\n                    <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">—</span>\r\n                  } @else {\r\n                    {{ measure.value.toLocaleString('en-US') }}\r\n                    @if (measure.uom; as uom) {\r\n                      <span class=\"cws:text-[11px]/5 cws:font-normal cws:text-slate-600 cws:dark:text-slate-400\">\r\n                        {{ uom }}\r\n                      </span>\r\n                    }\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n        </div>\r\n\r\n        <!--\r\n          🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\r\n          workspace grid and the approval screens. Up to five full-width banners used to sit between\r\n          the summary strip and the tabs, so on a create the form began below the fold.\r\n\r\n          ⚠ **Widened 2026-09-17 to nine, and four of them came from OUTSIDE this stack** — the copy\r\n          provenance, the create-pending note, the configuration provenance line under the tabs, and\r\n          the unmodelled-collections note that sat at the very bottom of the record. They were not\r\n          part of the original five because they were not full-width banners between the strip and\r\n          the tabs; they were still standing conditions, and scattering them was costing more than\r\n          their individual size suggested.\r\n\r\n          🔴 **What is in here and what is NOT is the load-bearing decision, and it is not about\r\n          length.** Standing conditions of the screen go in; **the outcome of something the user just\r\n          did stays out** — every banner below this point is the second kind (a save result, a save\r\n          failure, a copy whose source could not be read, a contract number that was not issued, a\r\n          prefill that failed). Two of those carry `role=\"alert\"` because they must interrupt, and\r\n          behind a collapsed panel they would be messages nobody sees. Before this change both kinds\r\n          rendered identically, which is exactly why the distinction needs stating.\r\n\r\n          ⚠ **The summaries live in `noticeSummaries` and must stay in this order.** Nothing enforces\r\n          it.\r\n        -->\r\n        <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n          @if (isSimulated()) {\r\n            <!--\r\n              Same banner and the same reason as the grid: a demo that silently shows generated data is\r\n              how generated data gets quoted as a production readout.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Simulated data</div>\r\n              <div class=\"scoular-alert-description\">\r\n                This contract is generated locally, not read from CTRM.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCopy() && !copyFailed()) {\r\n            <!--\r\n              A copy says what it is a copy of, and says what it did NOT bring with it.\r\n\r\n              🔴 The second half is the load-bearing half. A user who pressed \"Copy contract\" has every\r\n              reason to believe the new contract carries everything the old one did. The number never\r\n              comes (deliberately — see `CONTRACT_COPY_IDENTITY_FIELDS`, it is what stops the copy\r\n              overwriting its source), the prices only through copy-with-pricing, and the collections\r\n              as `describeCollectionCopy` says (#960): each one names why it was left out, and only one\r\n              actually left out is named. Stating them here is the difference between a copy the user\r\n              can trust and one they have to audit.\r\n\r\n              ⚠ **In the panel, where the copy FAILURE three blocks below is not, and the split is the\r\n              membership rule rather than a judgement about length.** \"This record is a copy of X\" is\r\n              true for the whole life of the screen — a standing condition of what the user is looking\r\n              at. \"X could not be read\" is the outcome of the action they just took, it carries\r\n              `role=\"alert\"`, and behind a disclosure it would be a message nobody sees.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Copied from {{ copyFrom }}</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Every writable field was carried across and can be changed before saving. A\r\n                <strong>new contract number</strong> has been issued — this will create a new contract\r\n                and cannot alter {{ copyFrom }}.\r\n                @if (isCopyWithPricing() && collectionCopy()?.pricesExcluded !== true) {\r\n                  <!-- #459: the prices are the second step, posted only once this create succeeds. -->\r\n                  <strong>Its prices are copied once this contract is created</strong>, one sequence at\r\n                  a time and each unapproved, with the result shown on the new contract.\r\n                }\r\n              </div>\r\n              @if (collectionCopySentences().length > 0) {\r\n                <!-- #960: what came across of the collections, and why the rest did not. -->\r\n                <ul class=\"scoular-alert-description cws:list-disc cws:pl-5\" data-testid=\"copy-collections\">\r\n                  @for (sentence of collectionCopySentences(); track sentence) {\r\n                    <li>{{ sentence }}</li>\r\n                  }\r\n                </ul>\r\n              }\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate() && canUseTemplates()) {\r\n            <!--\r\n              F3.3 — create from a template.\r\n\r\n              🔴 **Applying a template seeds the FULL set it carries, not the fields somebody typed.**\r\n              A template is captured whole precisely so applying it is whole; carrying only part of it\r\n              across is the defect that generalised from one field to forty.\r\n\r\n              ⚠ Through `seed`, so the values arrive as defaults rather than as edits — the same\r\n              distinction the customer-name confirmation makes, and it matters because six derived\r\n              descriptions sit on CTRM's re-confirmation list.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Start from a template</div>\r\n              <div class=\"scoular-alert-description\">\r\n                @if (templatesFailed()) {\r\n                  <!-- Not the same as \"this trade unit has none\", which would be a claim. -->\r\n                  <span>The templates for this trade unit could not be loaded.</span>\r\n                } @else if (availableTemplates().length === 0) {\r\n                  <span>This trade unit has no saved templates yet.</span>\r\n                } @else {\r\n                  <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n                    <span>Apply a template</span>\r\n                    <select\r\n                      class=\"cws:rounded cws:border cws:border-slate-300 cws:p-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      (change)=\"onApplyTemplate($any($event.target).value)\"\r\n                    >\r\n                      <option value=\"\">Choose…</option>\r\n                      @for (template of availableTemplates(); track template.id) {\r\n                        <option [value]=\"template.id\">{{ template.name }}</option>\r\n                      }\r\n                    </select>\r\n                  </label>\r\n\r\n                  @if (appliedTemplate(); as applied) {\r\n                    <p class=\"cws:mt-1\">\r\n                      Applied <strong>{{ applied }}</strong>. Every value it carried can be changed\r\n                      before saving.\r\n                    </p>\r\n                  }\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate()) {\r\n            <!--\r\n              Why the confirmation pills and the quantity breakdown are empty on a create.\r\n\r\n              ⚠ **The per-stage `emptyNote` is a `title` attribute only**, so it is a tooltip and not a\r\n              visible statement — this is the only place the reason is readable. It moved in here rather\r\n              than being deleted: a panel summary renders in BOTH states, so it is still on screen.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some values appear once this contract is saved</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Confirmations and CTRM’s computed quantity breakdown are {{ pendingNote }}, so those\r\n                panels are empty rather than failing to load.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable()) {\r\n            <!--\r\n              The standing caveat about what can be ENTERED — one of the three things the mode may\r\n              change, which is why it is gated on the mode rather than shown always.\r\n\r\n              ⚠ **This is the notice in here with the strongest claim to being left out**, and it is\r\n              the one to pull back up if the panel proves too quiet. Known Issue 30's instruction is\r\n              that anyone shown this screen reads it as the agreed field set, and unlike the approval\r\n              screen's CTRM caveat **there is no restatement of this at the point of action** — no\r\n              message appears at Save saying the contract has no ship periods. What makes collapsing\r\n              it defensible rather than a loss: the omission is *recoverable* (ship periods can be\r\n              added in CTRM afterwards) and the fields are optional, so a contract saved without them\r\n              is valid rather than wrong.\r\n            -->\r\n            <!--\r\n              🔴 **REWORDED 2026-09-25 (ruled by JFrisbie on #226). The previous text said shipment\r\n              dates \"cannot be entered here\", and that stopped being true when F2.3b built the\r\n              editable ship-period table** — which is available in create mode, since the editable\r\n              branch is gated on the form being writable rather than on the record existing.\r\n\r\n              ⚠ **What is kept is the half #226 was actually about**: they are OPTIONAL, a contract\r\n              saved without them genuinely has NONE, and CTRM derives none of its own. That was\r\n              settled from CTRM source rather than by spending a contract number — ship periods are\r\n              twelve positional slots and the read unpivots them on a non-sentinel begin date, so a\r\n              slot nobody filled never becomes a row. A user who assumes CTRM fills them in gets a\r\n              contract with zero ship periods and does not know it.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <!--\r\n                ⚠ Deliberately NOT word-for-word the panel summary. They render together when the\r\n                panel is open, and two identical lines read as a rendering fault; the summary states\r\n                the fact and the title states the consequence.\r\n              -->\r\n              <div class=\"scoular-alert-title\">Shipment dates are optional, not missing</div>\r\n              <div class=\"scoular-alert-description\">\r\n                All 108 of CTRM’s writable contract fields are here, and\r\n                <strong>ship periods can be entered on the Shipping tab</strong>. They are\r\n                <strong>optional</strong>, not missing: a contract saved without them genuinely has none,\r\n                because CTRM derives no shipment dates of its own. If you do enter them, CTRM refuses a\r\n                contract whose ship quantities do not sum to the header quantity — this screen states\r\n                the running total and blocks Save while they disagree, so that refusal is not reached.\r\n                Fields, widths and decimal places are read from CTRM’s own definitions, so what\r\n                you type is validated exactly as CTRM would; the tab grouping follows the Power App, and\r\n                the <em>Additional fields</em> tab holds the CTRM fields it never surfaced.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (configDefaultsOnly()) {\r\n            <!--\r\n              The configuration could not be resolved, so this record is on the layout's defaults.\r\n\r\n              The consequence is actionable and invisible otherwise: a field an admin marked required\r\n              may not be marked required here, and one they hid may be showing. The save still enforces\r\n              the real configuration server-side, so the failure a user would otherwise meet is a\r\n              refusal naming a field the form never asked for — which reads as a bug in the form.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Showing default field settings</div>\r\n              <div class=\"scoular-alert-description\">\r\n                The form configuration could not be loaded, so this record shows every field with default\r\n                settings. Anything an administrator has configured for this trade unit — hidden fields,\r\n                extra required fields, custom tabs — is not reflected here. Saving still applies the real\r\n                configuration, so a save may be refused for a field this form did not mark as required.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (constraintsNotice() === 'bundled') {\r\n            <!--\r\n              #732. CTRM's field definitions could not be read, and neither could the configuration, so\r\n              the widths and decimal places on this form come from the copy built into the app. That copy\r\n              is the same generated document as of this build, so it can lag a newer server.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Field limits are the copy built into this app</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM’s field definitions could not be loaded, so this form checks lengths and decimal places\r\n                against the limits built into this app. They match CTRM as of this release; if CTRM has\r\n                changed a field since, a save may be refused for it.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (constraintsNotice() === 'unavailable') {\r\n            <!--\r\n              #732. The configuration resolved, so widths and decimal places come from the server and are\r\n              live. Only the integer-digit check needs the document itself, and that is what is missing.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some field limits are not checked here</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM’s field definitions could not be loaded. Lengths and decimal places are still checked,\r\n                but digits before the decimal point are not checked on this form. CTRM checks them when you\r\n                save.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable() && unavailableLists().length > 0) {\r\n            <!--\r\n              Which dropdowns have no values, and why. A combo rendering an empty list looks like a bug in\r\n              this screen; it is a known gap in the reference route (issues 44 and 83).\r\n\r\n              ⚠ The description names no issue number: a trader cannot open one, and the sentence has to\r\n              stand on its own as \"typed, not picked, and that is expected\".\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some lists are unavailable</div>\r\n              <div class=\"scoular-alert-description\">\r\n                {{ unavailableLists().join(', ') }} returned no values, so those fields accept a typed code\r\n                instead of offering a list. The reference routes they need are parameterised and not\r\n                callable yet.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (unmodelled().length > 0) {\r\n            <!--\r\n              🔑 Shown deliberately, and the endpoint goes out of its way to make it possible.\r\n\r\n              These are child collections CTRM DOES return and CMS does not read yet. Hiding them would\r\n              make this screen answer \"this contract has no quality factors\" when the truth is \"CMS does\r\n              not read quality factors\" — a difference that matters to anyone using this screen to check\r\n              data, and one nobody could detect from the outside.\r\n\r\n              ⚠ **It used to sit at the very bottom of the record, below every tab's content.** That is\r\n              the one place a statement about the WHOLE record is least likely to be read, and it was\r\n              below the fold on every contract. In the panel it keeps its scope and gains a reader.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-title\">Not read by CMS yet</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM returns {{ unmodelled().length }} further collections on this contract that this\r\n                application does not read:\r\n                <span class=\"cws:font-medium\">\r\n                  @for (name of unmodelled(); track name; let last = $last) {\r\n                    <span [title]=\"name\">{{ readable(name) }}</span>{{ last ? '' : ', ' }}\r\n                  }\r\n                </span>\r\n                — so an empty section means “not read”, not “not present”.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (provenanceLabel() !== null) {\r\n            <!--\r\n              Which configuration row is in force.\r\n\r\n              It answers the question nobody could otherwise answer from the screen: \"why is this field\r\n              required here and not on the contract I looked at before?\" It is the admin's debugging\r\n              thread — which is exactly why it belongs behind the disclosure rather than as a permanent\r\n              muted line under the tabs, where it was one more thing between the user and the fields.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-description\">{{ provenanceLabel() }}</div>\r\n            </div>\r\n          }\r\n\r\n          @for (warning of warnings(); track warning) {\r\n            <!-- CTRM warnings are surfaced, not dropped (correction C-2). Rare on a read, never silent. -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n            </div>\r\n          }\r\n        </cms-notices-panel>\r\n\r\n        <!--\r\n          #459: copy-with-pricing's per-sequence results, on the contract the copy made. Outside the\r\n          notices panel because it is the outcome of something the user just did. Renders nothing for\r\n          a contract no copy was made to in this session.\r\n        -->\r\n        @if (!isCreate()) {\r\n          <cws-pricing-copy-panel [contractNumber]=\"contractNumber()\" />\r\n        }\r\n\r\n        <!--\r\n          A number that could not be issued is stated rather than left as an empty field, because the\r\n          three causes need three different actions and none of them is \"wait\". The field stays\r\n          editable throughout, so this is a notice and not a blocker.\r\n        -->\r\n        @if (numberIssueFailure()) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">A contract number was not issued</div>\r\n            <div class=\"scoular-alert-description\">{{ numberIssueFailure() }}</div>\r\n            <!-- #803: the server's reference, or why there is none. -->\r\n            <cms-reference-line [correlationId]=\"numberIssueReference()\" />\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          #204. A number the user typed was checked before the create and refused, or the check could\r\n          not run. The contract was NOT saved, so this interrupts (role=\"alert\").\r\n        -->\r\n        @if (numberCheck(); as reason) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"number-check-failure\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          BR-066, #143. On a customer-confirmed contract, changing a field CTRM's ConfirmChg diffs makes\r\n          the save start a new confirmation round. Said before the save, once the user has changed one,\r\n          because after the save it is already done. role=\"status\": a consequence to weigh, not an error.\r\n        -->\r\n        @if (confirmChgChanges(); as changed) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\" data-testid=\"confirm-chg-warning\">\r\n            <div class=\"scoular-alert-title\">Saving re-opens customer confirmation</div>\r\n            <div class=\"scoular-alert-description\">\r\n              This contract is confirmed, and you changed {{ changed.join(', ') }}. When you save, CTRM\r\n              issues a new confirmation version and a new confirmation for the customer to confirm again.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          A copy whose source could not be read is an ERROR, not a notice, and it must not look like\r\n          an ordinary blank create. The user asked for a copy; blank fields here would read as the\r\n          source contract's values and get saved.\r\n        -->\r\n        @if (copyFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">{{ copyFrom }} could not be read, so nothing was copied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is blank because the read of {{ copyFrom }} failed — <strong>not</strong>\r\n              because that contract is empty. <strong>Do not save from this state</strong> expecting a\r\n              copy: it would create a new contract carrying only what you type here. Reload to try\r\n              again, or start from {{ copyFrom }} and press Copy contract once it loads.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          #813: what a deep link asked for and did not get. Outcomes of how the screen was reached, so\r\n          banners rather than lines in the notices panel, beside the copy failure above. role=\"status\":\r\n          the screen is usable, it is simply not quite what the link described.\r\n        -->\r\n        @if (linkTradeUnitRefused()) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">The trade unit in this link was not applied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              The link asked for trade unit {{ linkTradeUnit }}, which could not be confirmed as one of\r\n              your trade units, so this contract is being created under the active trade unit\r\n              @if (activeTradeUnit(); as active) {\r\n                ({{ active }}).\r\n              } @else {\r\n                (none is selected).\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (linkTemplateRefusal(); as refusal) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">The template “{{ linkTemplate }}” in this link was not applied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              @switch (refusal) {\r\n                @case ('missing') {\r\n                  This trade unit has no template by that name or id, so the form starts without one.\r\n                }\r\n                @case ('unreadable') {\r\n                  The trade unit’s templates could not be loaded, so the form starts without one.\r\n                  Reload to try again.\r\n                }\r\n                @default {\r\n                  Templates are not available here, so the form starts without one.\r\n                }\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The values failing to load is stated, never absorbed. In view mode it stops an empty record\r\n          reading as an empty contract; in edit mode it is worse than that and the text says so.\r\n        -->\r\n        @if (prefillFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">This contract’s current values could not be loaded</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is showing blank because the read failed — <strong>not</strong> because the\r\n              contract is empty.\r\n              @if (isEditable()) {\r\n                <strong>Do not save from this state</strong>: a field you fill in here would be written\r\n                over whatever CTRM currently holds.\r\n              }\r\n              Reload the page, and if it keeps failing the contract can still be worked on the green\r\n              screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The save outcome, including WHICH of upsert's two paths CTRM took. A create that reports\r\n          \"Updated\" overwrote an existing contract and an update that reports \"Created\" made a new one;\r\n          both are shown rather than folded into a plain success, because that discriminator is the only\r\n          thing standing between a silent mistake and a caught one (docs/04e).\r\n        -->\r\n        @if (save().result; as result) {\r\n          <div class=\"scoular-alert scoular-alert-success\" role=\"status\">\r\n            <!-- #967: our words, the same sentence the next screen is left; never CTRM's `detail`. -->\r\n            <div class=\"scoular-alert-title\" data-testid=\"save-result-title\">{{ savedPanelTitle() }}</div>\r\n            <div class=\"scoular-alert-description\">\r\n              @if (!isCreate() && result.action === 'Created') {\r\n                <strong>\r\n                  ⚠ This was expected to update an existing contract and CTRM reports it created a new\r\n                  one. Check the contract number before continuing.\r\n                </strong>\r\n              }\r\n              @if (isCreate() && result.action === 'Updated') {\r\n                <strong>\r\n                  ⚠ This was expected to create a contract and CTRM reports it updated an existing one.\r\n                  An existing contract may have been overwritten.\r\n                </strong>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n\r\n        @if (recoverableDraft() !== null) {\r\n          <!--\r\n            🔴 An OFFER, never an automatic restore — F3.2f.\r\n\r\n            Silently repopulating a form would be indistinguishable from the contract genuinely\r\n            holding those values, and the user has no way to tell which they are looking at. Worse\r\n            under a full-replace upsert: a restored draft that the user does not notice is a set of\r\n            edits they never made, sent as if they had.\r\n\r\n            ⚠ `role=\"status\"` rather than `alert`: it is waiting for them, not interrupting them.\r\n          -->\r\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">Unsaved changes were recovered</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <p>\r\n                This form had unsaved changes when it was last open\r\n                @if (recoverableAt(); as at) {\r\n                  <span>, at {{ at }}</span>\r\n                }.\r\n              </p>\r\n              <div class=\"cws:mt-2 cws:flex cws:gap-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-primary\" (click)=\"restoreDraft()\">\r\n                  Restore them\r\n                </button>\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"discardDraft()\">\r\n                  Discard\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 #556: a failed save is THREE different things, and only one of them is a refusal.\r\n\r\n          A 422 is CTRM or the API saying no, with reasons. A lost CTRM answer is not a refusal at all:\r\n          the API reads the contract back to settle it (#513), and either the change is not there\r\n          (`not-applied`: safe to save again) or nobody can tell (`outcome-unknown`, and a status 0).\r\n          Saying \"not saved\" about the last case is how a retry becomes a duplicate write, and on a\r\n          create a second contract. The draft is kept in all three; only a success clears it.\r\n        -->\r\n        @if (save().status === 'failed' && save().failure === 'outcome-unknown') {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract may have been saved</div>\r\n            <!-- #803: the server's reference, or why there is none. -->\r\n            <cms-reference-line [correlationId]=\"save().correlationId\" />\r\n            <div class=\"scoular-alert-description\">\r\n              <!--\r\n                #951: the server's own sentence, because only it knows whether CTRM was silent or\r\n                answered with a database error (#929). The advice after it is keyed on the type alone.\r\n              -->\r\n              <p data-testid=\"save-lost-detail\">\r\n                {{ save().lostDetail ?? 'The answer to this save was lost, so it is not known whether the change was applied.' }}\r\n              </p>\r\n              <p>\r\n                Your edits are kept on this screen.\r\n                @if (isCreate()) {\r\n                  Check the contract list for the new contract before saving again, or a second\r\n                  contract may be created and the change applied twice.\r\n                } @else {\r\n                  Reload the contract to see what CTRM holds before saving again, or the change may be\r\n                  applied twice. Pressing Edit there offers these edits back.\r\n                }\r\n              </p>\r\n              <div class=\"cws:mt-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"reloadAfterUnknownSave()\">\r\n                  {{ isCreate() ? 'Check the contract list' : 'Reload the contract' }}\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        } @else if (save().status === 'failed' && save().failure === 'not-applied') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <!-- #951: the server's sentence, then the advice this type always carries (#556). -->\r\n            <div class=\"scoular-alert-description\">\r\n              <p data-testid=\"save-lost-detail\">\r\n                {{ save().lostDetail ?? 'CTRM’s answer could not be used, and reading the contract back shows the change is not there.' }}\r\n              </p>\r\n              <p>Your edits are kept, and it is safe to save again.</p>\r\n            </div>\r\n            <cms-reference-line [correlationId]=\"save().correlationId\" />\r\n          </div>\r\n        } @else if (save().status === 'failed') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5\">\r\n                <!--\r\n                  The API's own form-level text, plus any refusal whose `invalid_params[].name` is\r\n                  not a field name at all — a CTRM procedure name or composite (docs/04 §8.2). Those\r\n                  used to render below as a bolded field, which invented a field that does not exist.\r\n                -->\r\n                @for (reason of formLevelReasons(); track reason) {\r\n                  <li>{{ reason }}</li>\r\n                }\r\n\r\n                <!--\r\n                  #830: the save's refusals that are not CTRM fields, each under a name a user can read.\r\n                  The addendum ones link to the section's tab, where they are said again beside it.\r\n                -->\r\n                @for (reason of saveErrorGroups().save; track reason) {\r\n                  <li><strong>Save</strong> — {{ reason }}</li>\r\n                }\r\n                @for (reason of saveErrorGroups().lmsFlag; track reason) {\r\n                  <!-- #973: said again beside the box, in the header. -->\r\n                  <li><strong>LMS flag</strong> — {{ reason }}</li>\r\n                }\r\n                @for (reason of saveErrorGroups().addendum; track reason) {\r\n                  <li>\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                      (click)=\"goToAddendum()\"\r\n                    >\r\n                      <strong>Addendum</strong>\r\n                    </button>\r\n                    — {{ reason }}\r\n                  </li>\r\n                }\r\n                @for (reason of saveErrorGroups().remarks; track reason) {\r\n                  <li>\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                      (click)=\"goToRemarks()\"\r\n                    >\r\n                      <strong>Remarks</strong>\r\n                    </button>\r\n                    — {{ reason }}\r\n                  </li>\r\n                }\r\n                @for (reason of saveErrorGroups().documents; track reason) {\r\n                  <li>\r\n                    <strong>CTRM documents</strong> — {{ reason }} This is a system problem, not something to\r\n                    change on this screen. Try again later, and quote the reference if it persists.\r\n                  </li>\r\n                }\r\n\r\n                <!--\r\n                  🔴 Each field reason is now a BUTTON that goes to its control, and the reason is also\r\n                  on the control itself. This list used to admit, in its own words, that the field a\r\n                  reason named \"may be on a tab you are not looking at\" — which is a message the user\r\n                  has to go hunting for, barely better than none.\r\n\r\n                  ⚠ A button rather than an anchor: it switches tab AND moves focus, and the focus move\r\n                  is the half that makes it useful. An anchor would advertise an href that does only\r\n                  half the job.\r\n                -->\r\n                @for (error of mappedErrors(); track error.ctrmField) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                        (click)=\"focusField(error)\"\r\n                      >\r\n                        <strong>{{ error.label }}</strong>\r\n                      </button>\r\n                      — {{ reason }}\r\n                    </li>\r\n                  }\r\n                }\r\n\r\n                <!--\r\n                  ⚠ Refusals naming a field this screen does not render. Kept visible rather than\r\n                  dropped: CTRM validates a set that is not identical to what this layout shows, and a\r\n                  swallowed reason leaves a save that failed for no stated cause. Named by the CTRM\r\n                  field, because that is the only name we have for it.\r\n                -->\r\n                @for (error of unmappedErrors(); track error.field) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li><strong>{{ error.field }}</strong> — {{ reason }}</li>\r\n                  }\r\n                }\r\n              </ul>\r\n            </div>\r\n            <!-- #803: the server's reference, or why there is none. -->\r\n            <cms-reference-line [correlationId]=\"save().correlationId\" />\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 THE TABS, and they are ANCHORS rather than buttons.\r\n\r\n          Each tab is a real link to this same record with a different `tab` query parameter, which buys\r\n          three things a click handler would not: the tab is in the URL so a refresh keeps it and a link\r\n          to \"the shipping fields of this contract\" can be sent (docs/02 §1.3 asks this of every route);\r\n          middle-click and open-in-new-tab work; and the browser Back button walks the tabs. It is the\r\n          same reasoning the breadcrumb and Cancel already carry.\r\n\r\n          `aria-current=\"page\"` marks the active one — the correct ARIA for a set of links, where\r\n          `role=\"tab\"` would be a promise of keyboard semantics these are not implementing. Tab/Shift+Tab\r\n          moves between them because they are links, which is what a keyboard user expects of links.\r\n\r\n          ⚠ `queryParamsHandling` is deliberately NOT used. `paramsForTab` states every parameter it\r\n          keeps, so a future parameter has to be added on purpose — `merge` would silently carry\r\n          anything, including a stale `focus` from the grid.\r\n        -->\r\n        <!--\r\n          The tab row also carries view mode's \"Hide empty fields\" (2026-10-14), so the fields start\r\n          directly under the tabs. The toggle is a SIBLING of the `<nav>`, never inside it: it filters\r\n          what this tab shows and is not navigation.\r\n\r\n          🔴 **A segmented control** (2026-10-14): one shared rounded rail, only as wide as its tabs, with\r\n          the current tab a raised surface inside it. The rail replaces the underline, so the row draws\r\n          none. It never wraps: a narrow screen scrolls the rail sideways, and the focus ring is drawn\r\n          INSIDE each tab (`-outline-offset-2`) so the rail's overflow cannot clip it.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-x-4 cws:gap-y-2\">\r\n        <nav aria-label=\"Contract sections\" class=\"cws:min-w-0 cws:max-w-full\">\r\n          <ul class=\"cws:inline-flex cws:max-w-full cws:gap-0.5 cws:overflow-x-auto cws:rounded-xl cws:border cws:border-slate-200 cws:bg-slate-100 cws:p-1 cws:[scrollbar-width:thin] cws:dark:border-slate-700 cws:dark:bg-slate-800/70\">\r\n            @for (tab of tabs(); track tab.id) {\r\n              <li>\r\n                <!--\r\n                  The current tab is a raised surface (white, a hairline ring, the faintest shadow) with\r\n                  the label in Scoular blue; the others are transparent, and hovering one darkens the rail under it\r\n                  rather than lightening it, so a hovered tab never reads as the selected one.\r\n                -->\r\n                <a\r\n                  [routerLink]=\"[]\"\r\n                  [queryParams]=\"paramsForTab(tab.id)\"\r\n                  [attr.aria-current]=\"tab.current ? 'page' : null\"\r\n                  class=\"cws:flex cws:items-center cws:gap-1.5 cws:rounded-lg cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:whitespace-nowrap cws:transition-colors cws:focus-visible:outline-2 cws:focus-visible:-outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                  [class.cws:bg-white]=\"tab.current\"\r\n                  [class.cws:text-scoular-blue]=\"tab.current\"\r\n                  [class.cws:shadow-xs]=\"tab.current\"\r\n                  [class.cws:ring-1]=\"tab.current\"\r\n                  [class.cws:ring-slate-200]=\"tab.current\"\r\n                  [class.cws:dark:bg-slate-700]=\"tab.current\"\r\n                  [class.cws:dark:text-sky-300]=\"tab.current\"\r\n                  [class.cws:dark:ring-slate-600]=\"tab.current\"\r\n                  [class.cws:text-slate-600]=\"!tab.current\"\r\n                  [class.cws:hover:bg-slate-200/70]=\"!tab.current\"\r\n                  [class.cws:hover:text-slate-900]=\"!tab.current\"\r\n                  [class.cws:dark:text-slate-400]=\"!tab.current\"\r\n                  [class.cws:dark:hover:bg-slate-700/30]=\"!tab.current\"\r\n                  [class.cws:dark:hover:text-slate-100]=\"!tab.current\"\r\n                >\r\n                  {{ tab.label }}\r\n\r\n                  <!--\r\n                    🔴 How many refusals landed on this tab. Without it a save that failed on a field\r\n                    two tabs away shows an error banner and four tabs that look identical — the user\r\n                    has to open each one to find what CTRM objected to.\r\n\r\n                    ⚠ The count is in the accessible name too, not only the glyph: a screen-reader user\r\n                    gets \"Shipping Info, 2 problems\" rather than \"Shipping Info, 2\".\r\n                  -->\r\n                  @if (errorsByTab().get(tab.id); as problems) {\r\n                    <span\r\n                      class=\"scoular-badge scoular-badge-sm cws:bg-red-100 cws:text-red-800 cws:dark:bg-red-900/40 cws:dark:text-red-200\"\r\n                      [attr.aria-label]=\"problems + (problems === 1 ? ' problem' : ' problems')\"\r\n                    >\r\n                      {{ problems }}\r\n                    </span>\r\n                  }\r\n                  <!--\r\n                    The count is fields PLUS collections. The Remarks tab has no fields at all — remarks\r\n                    and notes are CTRM collections rather than `base_data` scalars — and would otherwise\r\n                    read `0` beside two populated tables. The Documents tab has no count at all (null),\r\n                    because a `0` beside it would read as \"this contract has no documents\".\r\n                  -->\r\n                  @if (tab.count) {\r\n                  <!-- Secondary to the label: smaller, normal weight, a soft fill rather than a solid one. -->\r\n                  <span\r\n                    class=\"cws:rounded-full cws:px-1.5 cws:text-xs cws:leading-5 cws:font-normal cws:tabular-nums\"\r\n                    [class.cws:bg-scoular-blue/10]=\"tab.current\"\r\n                    [class.cws:text-scoular-blue]=\"tab.current\"\r\n                    [class.cws:dark:bg-sky-400/15]=\"tab.current\"\r\n                    [class.cws:dark:text-sky-300]=\"tab.current\"\r\n                    [class.cws:bg-slate-200/70]=\"!tab.current\"\r\n                    [class.cws:text-slate-600]=\"!tab.current\"\r\n                    [class.cws:dark:bg-slate-700]=\"!tab.current\"\r\n                    [class.cws:dark:text-slate-300]=\"!tab.current\"\r\n                    [attr.aria-label]=\"tab.count + ' required'\"\r\n                    [attr.title]=\"tab.count + (tab.count === 1 ? ' required field' : ' required fields')\"\r\n                    data-testid=\"tab-required-count\"\r\n                  >\r\n                    {{ tab.count }}\r\n                  </span>\r\n                  }\r\n                </a>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </nav>\r\n\r\n        @if (!isEditable() && visibleSections().length > 0) {\r\n          <!--\r\n            \"Hide empty fields\" (2026-10-13), for READING only: the sheet drops entries with no value and\r\n            sections left with none. A display filter in `cms-contract-form`; configuration, the form and\r\n            the save are untouched, and Edit always shows every configured field.\r\n\r\n            A native checkbox with its own label: it is a two-state preference, not a command.\r\n          -->\r\n          <div class=\"cws:ml-auto cws:self-center cws:py-2\">\r\n            <label class=\"cws:inline-flex cws:cursor-pointer cws:items-center cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-400\">\r\n              <input\r\n                type=\"checkbox\"\r\n                class=\"cws:size-4 cws:accent-scoular-blue\"\r\n                [checked]=\"hideEmptyFields()\"\r\n                (change)=\"hideEmptyFields.set($any($event.target).checked)\"\r\n                data-hide-empty\r\n              />\r\n              Hide empty fields\r\n            </label>\r\n          </div>\r\n        }\r\n        </div>\r\n\r\n        <!--\r\n          🔴 THE FIELDS. One form, always mounted, showing one tab's sections.\r\n\r\n          `[visibleSections]` narrows what RENDERS. The form group is always built from the whole\r\n          configuration — see the input's own remarks. Wrapping this in `@if (activeTab() === …)` would\r\n          destroy and rebuild the component on every tab click, discarding everything typed and resetting\r\n          the `dirty` flags the save path reads. That is the trap here, and it looks like the obvious\r\n          implementation.\r\n\r\n          `[readOnly]` is the entire difference between reading a contract and editing one.\r\n\r\n          🔴 It binds `!isEditable()`, not `isView()` (F2.3c, #423). BR-002 makes the WHOLE form\r\n          read-only for an intercompany purchase, and this binding is the one place that decision\r\n          lands — bound to the mode alone, an intercompany purchase opened in edit mode rendered\r\n          fully editable and the rule existed only in the requirements.\r\n\r\n          Gated on `valuesReady()`: the form seeds ONCE in `ngOnInit`, so rendering before this\r\n          contract's values arrive builds it from nothing and never re-seeds.\r\n        -->\r\n        <!--\r\n          BR-002's read-only reason, which docs/02a §6.2 requires a banner for: \"read-only … banner\r\n          explains why\". A locked form with no explanation reads as a broken screen, and this one\r\n          cannot be unlocked from here.\r\n\r\n          ⚠ **Deliberately NOT `role=\"alert\"`.** It is a standing condition of the contract, not an\r\n          event that just happened — the same distinction the save outcome above observes in the\r\n          other direction. An alert role would interrupt a screen-reader user on arrival to announce\r\n          something that has always been true of this record.\r\n        -->\r\n        @if (intercompanyLock()) {\r\n          <div class=\"scoular-alert scoular-alert-info\">\r\n            <div class=\"scoular-alert-title\">This contract is read-only</div>\r\n            <!--\r\n              ⚠ No rule number in the copy. `user-facing-copy.spec.ts` refused \"(BR-002)\" here and\r\n              was right: a business-rule identifier names something only the development team can\r\n              act on, and the trader reading this needs to know what to do instead.\r\n            -->\r\n            <div class=\"scoular-alert-description\">\r\n              It is an intercompany purchase, and those are not editable here. The contract can\r\n              still be worked on the green screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (valuesReady()) {\r\n          <!--\r\n            🔴 `@for (… of [formKey()]; track key)` — the ONE place this screen rebuilds the form on\r\n            purpose, and it is not the tab switch.\r\n\r\n            A driver change (contract type, commodity) re-resolves the configuration, and a different\r\n            configuration is genuinely a different set of controls — so unlike tabs, this cannot be a\r\n            display filter. Re-keying rebuilds it; `watchDrivers` snapshots the dirty values first and\r\n            they come back through `[defaultValues]` marked dirty, so nothing typed is lost and the\r\n            save payload is unchanged. Keyed on the configuration's own version, so a re-resolve that\r\n            wins the same row does not churn the form.\r\n          -->\r\n          @for (key of [formKey()]; track key) {\r\n            <cms-contract-form\r\n              [config]=\"loaded.config\"\r\n              [tradeUnit]=\"loaded.tradeUnit\"\r\n              [readOnly]=\"!isEditable()\"\r\n              [visibleSections]=\"visibleSections()\"\r\n              [hideEmptyFields]=\"hideEmptyFields()\"\r\n              [fieldNotes]=\"fieldNotes()\"\r\n              [pinnedNotes]=\"pinnedNotes()\"\r\n              [emptyNotes]=\"emptyNotes\"\r\n              [sectionNotes]=\"sectionNotes\"\r\n              [wideFields]=\"wideFields\"\r\n              [halfFields]=\"halfFields()\"\r\n              [hiddenLabelFields]=\"hiddenLabelFields()\"\r\n              [groupHeadings]=\"groupHeadings\"\r\n              [fieldCtrmNames]=\"fieldCtrmNames\"\r\n              [constraints]=\"loaded.constraints ?? null\"\r\n              [readOnlyFields]=\"readOnlyFields()\"\r\n              [lockedFields]=\"lockedFields()\"\r\n              [fieldVerdicts]=\"fieldVerdicts()\"\r\n              [initialValues]=\"initialValues()\"\r\n              [defaultValues]=\"defaultValues()\"\r\n              (ready)=\"onFormReady($event)\"\r\n              (fieldBlur)=\"onFieldBlur($event)\"\r\n            />\r\n          }\r\n        } @else {\r\n          <div class=\"scoular-card cws:p-6\" role=\"status\" aria-live=\"polite\">\r\n            Loading this contract’s current values…\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          F10.3b — the Addendum section, for every special type the server lists an addendum type for\r\n          (#1043; it was a frontend list of three, which hid KA and SA).\r\n\r\n          🔴 OUTSIDE `cms-contract-form`, and that is how an addendum field is kept out of the save.\r\n          The form is the CTRM\r\n          payload; these values are CWS's and live in the section's own state, so the save path has no\r\n          control to read them from. `hasAddendumSection()` is false for every other special type, blank\r\n          included, and the section does not render at all.\r\n        -->\r\n        @if (hasAddendumSection()) {\r\n          <!--\r\n            #830: kept MOUNTED off its tab, and hidden, because Save reads the section's values and a\r\n            tab switch used to destroy them. `hidden` rather than a class, so no stylesheet can show it.\r\n            #923: its tab is the Addendum tab, which the form leaves empty, so it renders under the tabs.\r\n          -->\r\n          <div [hidden]=\"!showAddendum()\">\r\n            <cws-contract-addendum-section\r\n              [addendumType]=\"addendumType()\"\r\n              [templatesState]=\"addendumTemplatesState()\"\r\n              [typesState]=\"addendumTypesState()\"\r\n              [specialType]=\"addendumSpecialType()\"\r\n              [tradeUnit]=\"addendumTradeUnit()\"\r\n              [canEdit]=\"isEditable() && canWriteCws()\"\r\n              [previewContract]=\"addendumPreviewContract\"\r\n              [missingRequired]=\"missingRequiredLabels()\"\r\n              [saveErrors]=\"saveErrorGroups().addendum\"\r\n              [storedAddendum]=\"storedAddendum()\"\r\n              [earlierAddendums]=\"earlierAddendums()\"\r\n              [addendumListProblem]=\"addendumListProblem()\"\r\n            />\r\n            <!--\r\n              #485 (ruled 2026-10-02): the addendum is CWS-owned (ADDENDUM-ARCHITECTURE D1), so the grant\r\n              and edit mode, never the CTRM gate: a night run, a closed CTRM and a trade unit's CTRM\r\n              refusal (#411) do not stop it being edited or previewed. Saving it rides on the contract\r\n              save, which keeps its own gate.\r\n            -->\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The child collections, each on the tab whose fields describe it — ship periods with the\r\n          shipping fields, prices with the pricing fields, remarks and notes on the tab named after them.\r\n          That is what the Power App does (its `Ship Period` component is inside `Shipping Info`) and it\r\n          is what removes the long tail: nothing here sits after 111 controls any more.\r\n\r\n          ⚠ The grids themselves are UNCHANGED — same columns, sort behaviour, resizing and cell-level\r\n          Ctrl+C. Only where they appear has moved.\r\n        -->\r\n        @if (showPrices()) {\r\n          <!--\r\n            Price sequences, read-only on this aggregate — prices are written through the pricing API,\r\n            never through the contract upsert (C-8). So this stays a table in edit mode too.\r\n\r\n            ⚠ These are NOT the pricing API's price records. Known Issue 34: two CTRM routes both return\r\n            \"a price\" and disagree on names (`flat_price` vs `price`, 12 members vs 36). Do not reuse\r\n            this table's columns on the pricing screen.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Price sequences\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ contract()?.prices?.length ?? 0 }})\r\n              </span>\r\n            </h3>\r\n            @if (contract()?.prices?.length) {\r\n              <cms-data-grid\r\n                [rows]=\"sortedPrices()\"\r\n                [columns]=\"priceColumns\"\r\n                label=\"Price sequences\"\r\n                columnsKey=\"record.prices\"\r\n                [sorts]=\"priceSorts()\"\r\n                (sortChange)=\"priceSorts.set($event)\"\r\n              />\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                {{\r\n                  isCreate()\r\n                    ? 'Prices are added on the pricing screen, ' + pendingNote + '.'\r\n                    : 'This contract has no priced sequences.'\r\n                }}\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showShipPeriods()) {\r\n          <!--\r\n            Ship periods (BR-020…BR-023). Max 12, CTRM's cap.\r\n\r\n            🔴 **EDITABLE in edit mode as of F2.3b (#372).** This block carried the opposite claim —\r\n            \"read-only in EVERY mode … `ship_periods` is one of the 11 child collections the contract\r\n            upsert path does not carry, so there is nothing this screen could save\". The API's\r\n            `ContractWriteBody.Collections` does carry all seven, so the sentence was describing a\r\n            limit that had been lifted.\r\n\r\n            ⚠ Read-only still, whenever the form is: view mode, and BR-002's intercompany lock.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Ship periods\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ shipPeriodRows().length }})\r\n              </span>\r\n            </h3>\r\n\r\n            @if (isEditable()) {\r\n              <!--\r\n                The editable collection. A plain table rather than `cms-data-grid`, which renders\r\n                values and has no cell-editing affordance — and rather than a `FormArray`, which\r\n                would mean changing the shared `ContractForm` for every screen that mounts it.\r\n              -->\r\n              <table class=\"cws:w-full cws:text-left cws:text-sm\">\r\n                <caption class=\"sr-only\">Ship periods, editable</caption>\r\n                <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  <tr>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Begin</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">End</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Quantity</th>\r\n                    <!--\r\n                      #1018: CTRM's late pickup and early delivery dates, shown read-only. The save\r\n                      writes the whole collection, so each row re-sends what CTRM holds; no\r\n                      requirement asks for them to be edited here.\r\n                    -->\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Late pickup</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Early delivery</th>\r\n                    <th scope=\"col\" class=\"cws:py-1\"><span class=\"sr-only\">Actions</span></th>\r\n                  </tr>\r\n                </thead>\r\n                <tbody>\r\n                  @for (row of shipPeriodRows(); track $index) {\r\n                    <tr class=\"cws:border-t cws:border-slate-200 cws:dark:border-slate-700\">\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <!--\r\n                          BR-020 — the three entry forms CTRM accepts (`MMDDYYYY`, `MMDDYY` with a\r\n                          1930–2029 pivot, `MM/DD/YYYY`) are parsed on change by\r\n                          `parseShipPeriodDate`. A text input rather than `type=\"date\"` for exactly\r\n                          that reason: a native date picker would refuse the shorthand a trader types.\r\n                        -->\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'Begin date, period ' + ($index + 1)\"\r\n                          [value]=\"row.beginDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'beginDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'End date, period ' + ($index + 1)\"\r\n                          [value]=\"row.endDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'endDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          inputmode=\"decimal\"\r\n                          class=\"scoular-form-input cws:w-32 cws:text-right cws:tabular-nums\"\r\n                          [attr.aria-label]=\"'Quantity, period ' + ($index + 1)\"\r\n                          [value]=\"row.quantity ?? ''\"\r\n                          (change)=\"setShipPeriodQuantity($index, $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3 cws:tabular-nums\" data-testid=\"ship-period-late-pickup\">\r\n                        {{ carriedShipPeriodDate(row.latePickupDate) }}\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3 cws:tabular-nums\" data-testid=\"ship-period-early-delivery\">\r\n                        {{ carriedShipPeriodDate(row.earlyDeliveryDate) }}\r\n                      </td>\r\n                      <td class=\"cws:py-1\">\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\"\r\n                          (click)=\"removeShipPeriod($index)\"\r\n                        >\r\n                          Remove<span class=\"sr-only\"> period {{ $index + 1 }}</span>\r\n                        </button>\r\n                      </td>\r\n                    </tr>\r\n                    @if (shipPeriodIssues().get($index); as issues) {\r\n                      <tr>\r\n                        <td colspan=\"6\" class=\"cws:pb-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                          @for (issue of issues; track issue.code) {\r\n                            <span class=\"cws:mr-3\">{{ issue.message }}</span>\r\n                          }\r\n                        </td>\r\n                      </tr>\r\n                    }\r\n                  }\r\n                </tbody>\r\n              </table>\r\n\r\n              <!--\r\n                BR-022. The action DISABLES at CTRM's 12-period cap rather than silently doing\r\n                nothing — `nextShipPeriod` returns null there, which is the whole reason it does.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-sm scoular-btn-outline\"\r\n                [disabled]=\"nextShipPeriodProposal() === null\"\r\n                (click)=\"addShipPeriod()\"\r\n              >\r\n                Add period\r\n              </button>\r\n\r\n              @if (nextShipPeriodProposal() === null) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  A contract may have at most {{ maxShipPeriods }} ship periods.\r\n                </p>\r\n              }\r\n\r\n              @for (issue of shipPeriodCollectionIssues(); track issue.code) {\r\n                <p class=\"cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ issue.message }}</p>\r\n              }\r\n\r\n              <!--\r\n                BR-022's overlap test is a WARNING, not a refusal: CTRM permits overlapping periods,\r\n                so blocking the save here would invent a rule the system of record does not have.\r\n              -->\r\n              @if (shipPeriodsOverlap()) {\r\n                <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-300\">\r\n                  Two periods overlap. CTRM allows this — check it is what you meant.\r\n                </p>\r\n              }\r\n            } @else if (shipPeriodRows().length) {\r\n              <!--\r\n                No \"sorted within this page\" caveat here, unlike the contract grid: this collection\r\n                arrives whole (CTRM caps ship periods at 12), so the sort covers every row there is.\r\n              -->\r\n              <cms-data-grid\r\n                [rows]=\"sortedShipPeriods()\"\r\n                [columns]=\"shipPeriodColumns\"\r\n                label=\"Ship periods\"\r\n                columnsKey=\"record.ship-periods\"\r\n                [sorts]=\"shipPeriodSorts()\"\r\n                (sortChange)=\"shipPeriodSorts.set($event)\"\r\n              />\r\n\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                This contract has no ship periods. That is valid — CTRM neither requires shipment\r\n                dates nor supplies a default for them.\r\n              </p>\r\n            }\r\n\r\n            <!--\r\n              BR-021 — the running Σ against the contract quantity (#371, 02a §6.2).\r\n\r\n              🔴 **Outside the read-only branch as of F2.3b.** It used to sit inside the grid's `@if`,\r\n              so it rendered only where the periods could not be changed — and disappeared in edit\r\n              mode, which is the only mode in which a user can unbalance it. A gate that hides itself\r\n              exactly when it becomes reachable is worse than not having one.\r\n\r\n              Pinned under the collection rather than beside the Quantity field, because it is a\r\n              statement about the collection. It states the DELTA, not merely that something is\r\n              wrong: a gate that blocks without saying by how much leaves the user to redo arithmetic\r\n              the screen has already done.\r\n\r\n              `role=\"status\"` so a screen reader hears the total resolve as the quantity is typed,\r\n              rather than discovering it on pressing Save.\r\n            -->\r\n            @if (shipPeriodReconciliation(); as reconciliation) {\r\n              <p\r\n                data-testid=\"ship-period-reconciliation\"\r\n                role=\"status\"\r\n                class=\"cws:rounded-md cws:border cws:px-3 cws:py-2 cws:text-sm\"\r\n                [class.cws:border-emerald-300]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:bg-emerald-50]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:text-emerald-900]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:border-red-300]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:bg-red-50]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:text-red-900]=\"shipPeriodGateBlocks()\"\r\n              >\r\n                {{ reconciliation.summary }}\r\n                @if (shipPeriodGateBlocks()) {\r\n                  <span class=\"cws:block cws:font-medium\">\r\n                    CTRM requires the shipment periods to sum to the contract quantity, so this\r\n                    cannot be saved until they match.\r\n                  </span>\r\n                }\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showRemarks()) {\r\n          <!--\r\n            The Remarks tab carries no FIELDS — remarks and notes are CTRM collections (`RmkDS`,\r\n            `NoteDS`), not `base_data` scalars. #789: in edit and create, remarks are edited here as the\r\n            whole collection (C-19's 11 types). #912: CTRM's notes listed here are contract text\r\n            (#907); the Log tab's Add Note keeps CWS's own log and never writes them, so this no longer\r\n            points there.\r\n          -->\r\n          @if (isView()) {\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-description\">\r\n                Edit the contract to change its remarks.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          <!--\r\n            #907: the contract text, CTRM's CNTTX notes for the contract's archetype, over the proposed\r\n            GET /contracts/{n}/contract-text. Absent while the server does not offer it (today), with no\r\n            banner. Saved with the contract, as the notes collection with the edits applied.\r\n          -->\r\n          @if (contractText(); as answer) {\r\n            <div class=\"cws:mb-4\">\r\n              <cws-contract-text-section\r\n                [answer]=\"answer\"\r\n                [values]=\"contractTextValues()\"\r\n                [editing]=\"isEditable() && canWrite()\"\r\n                [locked]=\"contractTextLocked()\"\r\n                [refusal]=\"contractTextRefusalMessage()\"\r\n                [reconfirms]=\"contractTextReconfirms()\"\r\n                (textChange)=\"setContractText($event)\"\r\n              />\r\n            </div>\r\n          } @else if (contractTextFailure(); as failure) {\r\n            <p class=\"cws:mb-4 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"contract-text-failed\">\r\n              {{ failure }}\r\n            </p>\r\n          }\r\n\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- Remarks (BR-030, C-19). 11 types, 72 characters each. -->\r\n            @if (!isView()) {\r\n              <!--\r\n                #789: the editor. One row per CTRM type, in the Power App's order. The whole collection\r\n                is sent, packed, and only when a remark changed (both are full replaces). #1006: which\r\n                types are shown and required comes from the configuration (#1022); without it, all 11\r\n                are shown and none is required.\r\n              -->\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n                data-testid=\"remarks-editor\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Remarks</h3>\r\n\r\n                @if (remarksUnread()) {\r\n                  <!--\r\n                    🔴 THE REFUSAL THAT PREVENTS DATA LOSS (#788). CTRM failed to read the remarks, so the\r\n                    empty list proves nothing, and saving remarks replaces the whole collection.\r\n                  -->\r\n                  <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\" data-testid=\"remarks-unread\">\r\n                    This contract's remarks could not be read, so they cannot be edited safely — saving\r\n                    them would replace the remarks CTRM still holds. Reload the contract to try again.\r\n                  </p>\r\n                }\r\n\r\n                <div class=\"cws:mt-3 cws:grid cws:grid-cols-1 cws:gap-3\">\r\n                  <!--\r\n                    #1006: the types the configuration offers (a hidden type's stored remark still goes\r\n                    back in the write), each marked and held when the configuration requires it. The\r\n                    input's id is its summary key, `remarks.<code>`, so a summary line can focus it.\r\n                  -->\r\n                  @for (type of remarkTypes(); track type.code) {\r\n                    <div class=\"cws:space-y-1\">\r\n                      <label class=\"cws:block cws:space-y-1\">\r\n                        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">{{ type.label }}</span>\r\n                        @if (remarkRequired(type.code)) {\r\n                          <span class=\"cws:ml-0.5 cws:text-xs cws:text-red-700\" aria-hidden=\"true\">*</span>\r\n                        }\r\n                        <input\r\n                          class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n                          [id]=\"remarkKey(type.code)\"\r\n                          [attr.name]=\"'remark-' + type.code\"\r\n                          [attr.maxlength]=\"remarkMaxLength\"\r\n                          [attr.aria-describedby]=\"'remark-' + type.code + '-count' + (remarkMessage(type.code) === null ? '' : ' remark-' + type.code + '-error')\"\r\n                          [attr.aria-required]=\"remarkRequired(type.code) ? 'true' : null\"\r\n                          [attr.aria-invalid]=\"remarkMessage(type.code) === null ? null : 'true'\"\r\n                          [value]=\"remarkOf(type.code)\"\r\n                          [disabled]=\"!canEditRemarks()\"\r\n                          (input)=\"setRemark(type.code, $any($event.target).value)\"\r\n                          (blur)=\"touchRemark(type.code)\"\r\n                        />\r\n                      </label>\r\n                      @if (remarkMessage(type.code); as message) {\r\n                        <span [id]=\"'remark-' + type.code + '-error'\" class=\"cws:block cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ message }}</span>\r\n                      }\r\n                      <!-- Outside the label, so the field's name is the type alone; read out as its description. -->\r\n                      <span [id]=\"'remark-' + type.code + '-count'\" class=\"cws:block cws:text-right cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        {{ remarkMaxLength - remarkOf(type.code).length }} characters remaining\r\n                      </span>\r\n                    </div>\r\n                  }\r\n                </div>\r\n\r\n                @if (saveErrorGroups().remarks.length > 0) {\r\n                  <ul class=\"cws:mt-3 cws:list-disc cws:space-y-1 cws:rounded cws:bg-rose-50 cws:py-2 cws:pr-3 cws:pl-6 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"remarks-save-errors\">\r\n                    @for (reason of saveErrorGroups().remarks; track reason) {\r\n                      <li>{{ reason }}</li>\r\n                    }\r\n                  </ul>\r\n                }\r\n              </div>\r\n            } @else {\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Remarks\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.remarks?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.remarks?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-2\">\r\n                  @for (remark of contract()?.remarks ?? []; track remark.order) {\r\n                    <li class=\"cws:flex cws:gap-3 cws:text-sm\">\r\n                      <!--\r\n                        The number is CMS's, not CTRM's — RmkDS has no sequence subfield, so it is array\r\n                        position. Muted rather than labelled \"seq\" so it is not mistaken for a CTRM id.\r\n                      -->\r\n                      <span\r\n                        class=\"cws:w-5 cws:shrink-0 cws:text-right cws:tabular-nums cws:text-slate-500 cws:dark:text-slate-400\"\r\n                        title=\"Position in CTRM’s array — not a CTRM sequence number\"\r\n                      >\r\n                        {{ remark.order }}\r\n                      </span>\r\n                      <span class=\"cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        @if (remark.type) {\r\n                          <span class=\"cws:mr-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            [{{ remark.type }}]\r\n                          </span>\r\n                        }\r\n                        {{ remark.text }}\r\n                      </span>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Remarks are ' + pendingNote + '.' : 'No remarks.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n            }\r\n\r\n            <!--\r\n              Notes. `whitespace-pre-line` because a note runs to 32 000 characters and will contain its\r\n              own line breaks — collapsing them would turn a structured note into one unreadable\r\n              paragraph.\r\n            -->\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Notes\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.notes?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.notes?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (note of contract()?.notes ?? []; track note.order) {\r\n                    <li class=\"cws:text-sm\">\r\n                      @if (note.prefix || note.code) {\r\n                        <div class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          {{ note.prefix }}{{ note.prefix && note.code ? ' · ' : '' }}{{ note.code }}\r\n                        </div>\r\n                      }\r\n                      <p class=\"cws:whitespace-pre-line cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        {{ note.text }}\r\n                      </p>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Notes are ' + pendingNote + '.' : 'No notes.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (showDocuments()) {\r\n          <!--\r\n            F10.2 — the Documents tab. It reads its own list and content, so the record's own reads are\r\n            untouched by it, and it is appended by this screen rather than configured (see DOCUMENTS_TAB).\r\n          -->\r\n          <!-- One stacked column, spaced like every other block (JFrisbie, 2026-10-23). -->\r\n          <div class=\"cws:flex cws:flex-col cws:gap-4\">\r\n          <cws-contract-documents-tab [contractNumber]=\"contractNumber()\" />\r\n\r\n          @if (attachmentsOffered) {\r\n            <!--\r\n              #915 / F10.6 — CWS's own attachments, a sibling of CTRM's set above rather than inside it,\r\n              so the Documents tab component is unchanged. Each write is its own contract update.\r\n            -->\r\n            <cws-contract-attachments\r\n              [contractNumber]=\"contractNumber()\"\r\n              [canWrite]=\"canWriteAttachments()\"\r\n              [caraWarning]=\"attachmentsCaraWarning()\"\r\n              [announcesSaves]=\"false\"\r\n              (saved)=\"onAttachmentSaved($event)\"\r\n            />\r\n          }\r\n          </div>\r\n        }\r\n\r\n        @if (isCreate() && attachmentsOffered) {\r\n          <!--\r\n            #915 / F10.6 — on a create there is no Documents tab, so the files to send with the first\r\n            Save are picked here, on every tab. Nothing is sent until Save.\r\n          -->\r\n          <cws-contract-attachments\r\n            [contractNumber]=\"null\"\r\n            [canWrite]=\"canPickCreateAttachments()\"\r\n            [saveErrors]=\"saveErrorGroups().attachments\"\r\n            (pendingChange)=\"pendingAttachments.set($event)\"\r\n          />\r\n        }\r\n\r\n        @if (showLog()) {\r\n          <!--\r\n            F3.7 — the Log tab: what happened to this contract, a note to add to it, and a message to\r\n            its trader. It carries no form fields, which is why it is appended by this screen rather\r\n            than coming from the resolved configuration (see `LOG_TAB`).\r\n          -->\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- The timeline. Absent where the host offered no audit backend. -->\r\n            @if (logAvailable()) {\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">History</h3>\r\n\r\n              @if (configAuditFailed()) {\r\n                <!--\r\n                  #458: the contract's own entries still list; this says the configuration half is\r\n                  missing, so \"the form never changed\" is not read into its absence.\r\n                -->\r\n                <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n                  Form-configuration changes could not be read, so only the contract's own changes are\r\n                  listed.\r\n                </p>\r\n              }\r\n\r\n              @if (logNotesFailed()) {\r\n                <!-- #912: the history still says a note was added; this says its words are missing. -->\r\n                <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n                  The notes on this contract could not be read, so a note added is listed without its words.\r\n                </p>\r\n              }\r\n\r\n              @if (timelineState() === 'loading') {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Loading the history…</p>\r\n              } @else if (timelineState() === 'error') {\r\n                <!--\r\n                  🔴 An unreadable history and an empty one must not look the same. \"Nothing has\r\n                  happened to this contract\" is a claim, and this screen cannot make it here.\r\n                -->\r\n                <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\r\n                  The history for this contract could not be loaded, so what is shown may be\r\n                  incomplete.\r\n                </p>\r\n              } @else if (timeline().length === 0) {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  Nothing has been recorded against this contract yet.\r\n                </p>\r\n              } @else {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (row of timeline(); track row.key) {\r\n                    <li class=\"cws:border-l-2 cws:pl-3\"\r\n                        [class.cws:border-slate-300]=\"row.kind !== 'configuration'\"\r\n                        [class.cws:border-amber-400]=\"row.kind === 'configuration'\">\r\n                      <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\">\r\n                        {{ row.what }}\r\n                        @if (row.kind === 'configuration') {\r\n                          <!-- Distinguishable, so a configuration edit is never read as a contract change. -->\r\n                          <span\r\n                            class=\"cws:ml-1 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\r\n                          >Configuration</span>\r\n                        }\r\n                      </p>\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        <!-- #567: the reader's local time; the exact instant stays in `datetime`. -->\r\n                        {{ row.actor || 'Unattributed' }} · <time [attr.datetime]=\"row.at\">{{ row.atLabel }}</time>\r\n                      </p>\r\n                      @if (row.text !== null) {\r\n                        <!-- #912: a log note's words, line breaks kept, as the server stored them. -->\r\n                        <p data-testid=\"log-note-text\" class=\"cws:mt-1 cws:whitespace-pre-line cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">{{ row.text }}</p>\r\n                      }\r\n                      <!--\r\n                        #567: what the write changed, from the entry's detailsJson. Rendered only when\r\n                        it parses and names something, so every other entry reads exactly as before.\r\n                      -->\r\n                      @if (row.changes.length > 0 || row.collectionsReplaced.length > 0) {\r\n                        <dl class=\"cws:mt-1 cws:space-y-0.5 cws:text-xs cws:text-slate-700 cws:dark:text-slate-300\">\r\n                          @for (change of row.changes; track $index) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">{{ change.label }}</dt>\r\n                              <dd>\r\n                                <span>{{ change.from ?? '(empty)' }}</span>\r\n                                <span aria-hidden=\"true\"> → </span>\r\n                                <span class=\"cws:sr-only\"> changed to </span>\r\n                                <span>{{ change.to ?? '(empty)' }}</span>\r\n                              </dd>\r\n                            </div>\r\n                          }\r\n                          @if (row.collectionsReplaced.length > 0) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">Replaced whole</dt>\r\n                              <dd>{{ row.collectionsReplaced.join(', ') }}</dd>\r\n                            </div>\r\n                          }\r\n                        </dl>\r\n                      }\r\n                      <!-- #915: attachment changes, by document id and type. The audit holds no file name. -->\r\n                      @if (row.attachments.length > 0) {\r\n                        <dl class=\"cws:mt-1 cws:text-xs cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"log-attachments\">\r\n                          <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                            <dt class=\"cws:font-medium\">Attachments</dt>\r\n                            <dd>{{ row.attachments.join('; ') }}</dd>\r\n                          </div>\r\n                        </dl>\r\n                      }\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              }\r\n            </div>\r\n\r\n            }\r\n\r\n            <div class=\"cws:space-y-4\">\r\n              <!--\r\n                Add Note (#912): CWS's own log, over the log backend's notes route. Never CTRM's notes\r\n                collection, which is contract text (#907). A log source without the route offers none.\r\n              -->\r\n              @if (logAvailable() && canKeepLogNotes) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Add a note</h3>\r\n\r\n                <!--\r\n                  #912: the #331 refusal (\"the existing notes could not be read\") is gone. It guarded a\r\n                  write that replaced CTRM's notes whole; a log note replaces nothing.\r\n                -->\r\n                @if (!canWriteLogNote()) {\r\n                  <!--\r\n                    #912: the grant, then the trade unit's onboarding. Not CTRM's availability: nothing\r\n                    is written to CTRM, so a night run does not stop a note.\r\n                  -->\r\n                  <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    @if (!canWriteCws()) {\r\n                      Adding a note needs the <strong>Admin</strong> role on this application.\r\n                    } @else {\r\n                      {{ writeRefusal()?.message }}\r\n                    }\r\n                  </p>\r\n                } @else {\r\n                  <label class=\"cws:mt-2 cws:block\">\r\n                    <span class=\"sr-only\">Note</span>\r\n                    <textarea\r\n                      rows=\"4\"\r\n                      class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      [value]=\"noteText()\"\r\n                      (input)=\"onNoteInput($any($event.target).value)\"\r\n                    ></textarea>\r\n                  </label>\r\n\r\n                  @if (noteRefusal(); as refusal) {\r\n                    <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ refusal }}</p>\r\n                  } @else {\r\n                    <!-- The budget at the control, not only a refusal at save. -->\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      {{ noteBytesRemaining() }} characters remaining\r\n                    </p>\r\n                  }\r\n\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-primary cws:mt-2\"\r\n                    [disabled]=\"!canAddNote()\"\r\n                    (click)=\"onAddNote()\"\r\n                  >\r\n                    @if (noteState().status === 'saving') { Saving… } @else { Add note }\r\n                  </button>\r\n\r\n                  <!-- #803: the last Add note, with the server's reference on a failure. -->\r\n                  <div class=\"cws:mt-1\" data-testid=\"note-outcome\">\r\n                    <cms-status-message [outcome]=\"noteOutcome()\" (dismissed)=\"noteOutcome.set(null)\" />\r\n                  </div>\r\n                }\r\n              </div>\r\n\r\n              }\r\n\r\n              <!-- Save as template (F3.3). -->\r\n              @if (canUseTemplates() && !isCreate()) {\r\n                <div\r\n                  class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n                >\r\n                  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    Save as a template\r\n                  </h3>\r\n\r\n                  <!-- #485: CWS SQL, so permissions only; the CTRM availability gate does not apply. -->\r\n                  @if (!canWriteCws()) {\r\n                    <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      Saving a template needs the <strong>Admin</strong> role on this application.\r\n                    </p>\r\n                  } @else {\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      <!--\r\n                        Says what is captured and what the server removes, because a user who does not\r\n                        know the exclusions exist will expect the template to reproduce the contract\r\n                        exactly and will read the difference as a defect.\r\n                      -->\r\n                      Captures every writable field on this contract as it stands. Fields excluded from\r\n                      copying are removed when the template is read back.\r\n                    </p>\r\n\r\n                    <label class=\"cws:mt-2 cws:block\">\r\n                      <span class=\"sr-only\">Template name</span>\r\n                      <input\r\n                        type=\"text\"\r\n                        class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                        placeholder=\"Template name\"\r\n                        [value]=\"templateName()\"\r\n                        (input)=\"onTemplateNameInput($any($event.target).value)\"\r\n                      />\r\n                    </label>\r\n\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                      [disabled]=\"!canSaveTemplate()\"\r\n                      (click)=\"onSaveTemplate()\"\r\n                    >\r\n                      @if (templateState().status === 'saving') { Saving… } @else { Save as template }\r\n                    </button>\r\n\r\n                    <!-- #803: the last template save or delete, with the server's reference on a failure. -->\r\n                    <div class=\"cws:mt-1\" data-testid=\"template-outcome\">\r\n                      <cms-status-message [outcome]=\"templateOutcome()\" (dismissed)=\"templateOutcome.set(null)\" />\r\n                    </div>\r\n\r\n                    <!--\r\n                      #457 — the trade unit's templates, each deletable. Deleting confirms first: it\r\n                      cannot be undone, and a template is shared by everyone in the trade unit.\r\n                    -->\r\n                    @if (availableTemplates().length > 0) {\r\n                      <h4 class=\"cws:mt-4 cws:text-xs cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n                        This trade unit's templates\r\n                      </h4>\r\n                      <ul class=\"cws:mt-1 cws:space-y-1\">\r\n                        @for (template of availableTemplates(); track template.id) {\r\n                          <li class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-sm cws:text-slate-800 cws:dark:text-slate-100\">\r\n                            <span>{{ template.name }}</span>\r\n                            <button\r\n                              type=\"button\"\r\n                              class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\r\n                              (click)=\"onDeleteTemplate(template)\"\r\n                            >\r\n                              Delete<span class=\"sr-only\"> template {{ template.name }}</span>\r\n                            </button>\r\n                          </li>\r\n                        }\r\n                      </ul>\r\n                    }\r\n\r\n                  }\r\n                </div>\r\n              }\r\n\r\n              <!-- Notify Trader. Needs the log backend, which owns the route. -->\r\n              @if (logAvailable()) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Notify the trader</h3>\r\n\r\n                @if (mayNotify() === false) {\r\n                  <!--\r\n                    #865: the server's rule since #847, said before the user writes a message it would\r\n                    refuse. Any permission in the contract's trade unit is enough.\r\n                  -->\r\n                  <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"notify-not-allowed\">\r\n                    Notifying the trader needs a permission in this contract’s trade unit.\r\n                  </p>\r\n                }\r\n\r\n                <!--\r\n                  #458 — who receives it, as ruled on #513: the contract's trader by default, plus\r\n                  anyone on our domain, checked here before the server refuses it.\r\n                -->\r\n                <div class=\"cws:mt-2 cws:space-y-1\">\r\n                  <p class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">To</p>\r\n\r\n                  @if (recipients().length > 0) {\r\n                    <ul class=\"cws:flex cws:flex-wrap cws:gap-1\" aria-label=\"Recipients\">\r\n                      @for (address of recipients(); track address) {\r\n                        <li class=\"cws:flex cws:items-center cws:gap-1 cws:rounded cws:bg-slate-100 cws:px-2 cws:py-0.5 cws:text-xs cws:text-slate-800 cws:dark:bg-slate-700 cws:dark:text-slate-100\">\r\n                          {{ address }}\r\n                          <button\r\n                            type=\"button\"\r\n                            class=\"cws:text-slate-500 cws:hover:text-slate-900 cws:dark:text-slate-400 cws:dark:hover:text-white\"\r\n                            (click)=\"removeRecipient(address)\"\r\n                          >\r\n                            <span aria-hidden=\"true\">×</span><span class=\"sr-only\">Remove {{ address }}</span>\r\n                          </button>\r\n                        </li>\r\n                      }\r\n                    </ul>\r\n                  }\r\n\r\n                  @if (unresolvedTrader(); as initials) {\r\n                    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      The contract's trader ({{ initials }}) cannot be added automatically yet. Add their\r\n                      address below.\r\n                    </p>\r\n                  }\r\n\r\n                  <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n                    <label class=\"cws:flex-1\">\r\n                      <span class=\"sr-only\">Add a recipient on our domain</span>\r\n                      <input\r\n                        type=\"email\"\r\n                        name=\"notifyRecipient\"\r\n                        class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                        placeholder=\"name@scoular.com\"\r\n                        [value]=\"recipientDraft()\"\r\n                        [attr.aria-invalid]=\"recipientError() !== null ? 'true' : null\"\r\n                        [attr.aria-describedby]=\"recipientError() !== null ? 'notify-recipient-error' : null\"\r\n                        (input)=\"onRecipientInput($any($event.target).value)\"\r\n                        (keydown.enter)=\"addRecipient()\"\r\n                      />\r\n                    </label>\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"addRecipient()\">\r\n                      Add recipient\r\n                    </button>\r\n                  </div>\r\n\r\n                  @if (recipientError(); as message) {\r\n                    <p id=\"notify-recipient-error\" class=\"cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ message }}</p>\r\n                  }\r\n                </div>\r\n\r\n                <label class=\"cws:mt-2 cws:block\">\r\n                  <span class=\"sr-only\">Message to the trader</span>\r\n                  <textarea\r\n                    rows=\"3\"\r\n                    class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                    [value]=\"notifyText()\"\r\n                    (input)=\"onNotifyInput($any($event.target).value)\"\r\n                  ></textarea>\r\n                </label>\r\n\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                  [disabled]=\"!canNotify()\"\r\n                  (click)=\"onNotifyTrader()\"\r\n                >\r\n                  @if (notifyState().status === 'sending') { Sending… } @else { Notify trader }\r\n                </button>\r\n\r\n                <!--\r\n                  #803: the last Notify trader. 🔴 \"Accepted\", never \"sent\": the route answers 202,\r\n                  which on this estate says the request was taken and nothing about whether it\r\n                  reached anybody. A failure carries the server's reference.\r\n                -->\r\n                <div class=\"cws:mt-1\" data-testid=\"notify-outcome\">\r\n                  <cms-status-message [outcome]=\"notifyOutcome()\" (dismissed)=\"notifyOutcome.set(null)\" />\r\n                </div>\r\n              </div>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n      </div>\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: BreadcrumbComponent,
				selector: "cms-breadcrumb",
				inputs: [
					"crumbs",
					"current",
					"context",
					"queryParams"
				]
			},
			{
				kind: "component",
				type: ContractAddendumSectionComponent,
				selector: "cws-contract-addendum-section",
				inputs: [
					"addendumType",
					"specialType",
					"templatesState",
					"typesState",
					"tradeUnit",
					"canEdit",
					"previewContract",
					"saveErrors",
					"storedAddendum",
					"earlierAddendums",
					"addendumListProblem",
					"missingRequired"
				]
			},
			{
				kind: "component",
				type: PricingCopyPanelComponent,
				selector: "cws-pricing-copy-panel",
				inputs: ["contractNumber"]
			},
			{
				kind: "component",
				type: ContractAttachmentsComponent,
				selector: "cws-contract-attachments",
				inputs: [
					"contractNumber",
					"canWrite",
					"caraWarning",
					"saveErrors",
					"announcesSaves"
				],
				outputs: ["saved", "pendingChange"]
			},
			{
				kind: "component",
				type: ContractDocumentsTabComponent,
				selector: "cws-contract-documents-tab",
				inputs: ["contractNumber"]
			},
			{
				kind: "component",
				type: ContractFormComponent,
				selector: "cms-contract-form",
				inputs: [
					"config",
					"tradeUnit",
					"facts",
					"readOnly",
					"instanceId",
					"visibleSections",
					"hideEmptyFields",
					"fieldNotes",
					"pinnedNotes",
					"emptyNotes",
					"sectionNotes",
					"wideFields",
					"halfFields",
					"fieldCtrmNames",
					"constraints",
					"hiddenLabelFields",
					"groupHeadings",
					"readOnlyFields",
					"lockedFields",
					"fieldVerdicts",
					"initialValues",
					"defaultValues"
				],
				outputs: ["ready", "fieldBlur"]
			},
			{
				kind: "component",
				type: ContractTextSectionComponent,
				selector: "cws-contract-text-section",
				inputs: [
					"answer",
					"values",
					"editing",
					"locked",
					"refusal",
					"reconfirms"
				],
				outputs: ["textChange"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"columnMenu",
					"columnsKey",
					"lockedColumns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"rowLabel",
					"activateLabel",
					"selectable",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep",
					"rowToggle",
					"selectAll"
				]
			},
			{
				kind: "directive",
				type: DropdownDirective,
				selector: "[cmsDropdown]",
				exportAs: ["cmsDropdown"]
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: ReferenceLineComponent,
				selector: "cms-reference-line",
				inputs: ["correlationId", "sent"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "component",
				type: ValidationSummaryComponent,
				selector: "cms-validation-summary",
				inputs: ["entries", "expanded"],
				outputs: ["expandedChange", "chosen"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ContractRecordPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-contract-record-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				BreadcrumbComponent,
				ContractAddendumSectionComponent,
				PricingCopyPanelComponent,
				ContractAttachmentsComponent,
				ContractDocumentsTabComponent,
				ContractFormComponent,
				ContractTextSectionComponent,
				DataGridComponent,
				DropdownDirective,
				NoticesPanelComponent,
				ReferenceLineComponent,
				RefreshButtonComponent,
				RouterLink,
				StatusMessageComponent,
				ValidationSummaryComponent
			],
			template: "<!--\r\n  The contract record screen — viewing, editing and creating, from one template.\r\n\r\n  🔴 THE SHAPE, and read this before adding anything to it (JFrisbie, 2026-09-01).\r\n\r\n  This page is four bands and nothing else:\r\n\r\n    1. breadcrumb + actions  where you are, and what you can do to this record\r\n    2. header                what this record IS\r\n    3. summary strip         the at-a-glance state — always visible, every tab, every mode\r\n    4. tabs + body           the fields of ONE tab, then that tab's collections\r\n\r\n  It used to be eleven full-width section cards stacked down the page with all four child grids after\r\n  them, which is \"so many fields prior to the child grids that it's just too much\" — 111 controls before\r\n  the first table. The tabs come from the Power App traders use today (`fxTabOptions`), so the grouping\r\n  is the business's rather than a fourth opinion from this lane. See `CONTRACT_TABS`.\r\n\r\n  The mode is still allowed to change exactly three things — whether the controls accept input, which\r\n  buttons are in the toolbar, and which contextual alerts apply. It must never change the SHAPE, or\r\n  add/edit stops looking like view, which is the whole point of one component.\r\n-->\r\n<section class=\"cws:space-y-4\">\r\n  <!--\r\n    `containerState()`, not the configuration's state alone: the record needs two reads, and gating on\r\n    the configuration rendered a full set of empty controls when the contract read had failed. See the\r\n    component.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    loadingLabel=\"Loading contract\"\r\n    (retry)=\"retry()\"\r\n  >\r\n    @if (bundle(); as loaded) {\r\n      <div class=\"cws:space-y-4\">\r\n        <!-- #803: the save that brought the user here, said by the screen they arrived on. -->\r\n        <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\r\n\r\n        <!--\r\n          🔴 THE TOP ROW — breadcrumb left, record actions hard right (JFrisbie, 2026-09-02).\r\n\r\n          The actions used to sit inside the header card, level with the contract number. They belong\r\n          ABOVE it, for the same reason the workspace grid puts *Add Contract* on its own header row:\r\n          they act on the whole record, so they read as page-level actions rather than as something\r\n          attached to the title. One placement across both screens is the point — nobody should have\r\n          to look somewhere different for the primary action depending on which screen they are on.\r\n\r\n          ⚠ The actions are a SIBLING of the `<nav>`, never inside it. A breadcrumb is navigation and\r\n          the ARIA pattern is what tells a screen-reader user so; anchors dropped in would be\r\n          announced as extra crumbs. The view spec pins the nav at exactly one anchor, so nesting\r\n          them here fails a test rather than shipping quietly.\r\n\r\n          **`items-end`, so the BOTTOM of the buttons meets the bottom of the breadcrumb text**\r\n          (JFrisbie, 2026-09-02). The buttons are ~38px against the crumb's 20px line box, so\r\n          `items-center` left them straddling it and neither edge lined up with anything.\r\n\r\n          ⚠ Not `items-baseline`, which is the tempting one and is wrong here: it would align the\r\n          button's *label* baseline with the crumb's, pushing the button's padding and border below\r\n          the text and putting the bottoms further out than `items-center` had them. The request is\r\n          about the buttons' bottom EDGE, which is a box alignment, not a text one.\r\n\r\n          The grid's header row is also `items-end`; it carries `self-start` on its action block only\r\n          because its left column is a heading over a description and the button was wanted level\r\n          with the top of that. Here the left column is one line, so the row's own alignment stands.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n          <!--\r\n            The trail back — one definition, shared with the approval review and pricing screens.\r\n\r\n            🔴 **This markup was the original and is now `cms-breadcrumb`.** It was correct here and\r\n            copied almost-correctly elsewhere: the pricing screen had grown an anchor and two spans\r\n            with no list and no `aria-current`, so the same control announced itself as navigation on\r\n            two screens out of three. Extracting the version that was right, rather than writing a\r\n            fourth, is what makes this change a no-op on this screen.\r\n\r\n            ⚠ **`trail()` still owns the JOURNEY** — which screens are behind you, and whether the\r\n            approvals review sits between the queue and here. The component owns only how a trail is\r\n            drawn. Those are different questions and they stayed in different places deliberately.\r\n\r\n            ⚠ `returnParams()` rides on every crumb; see the component for the silent failure that\r\n            guards against.\r\n          -->\r\n          <cms-breadcrumb\r\n            [crumbs]=\"crumbs()\"\r\n            [current]=\"currentCrumb()\"\r\n            [context]=\"tradeUnitLabel()\"\r\n            [queryParams]=\"returnParams()\"\r\n          />\r\n\r\n          <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n            @if (isView()) {\r\n              <!--\r\n                Refresh, to the LEFT of Edit and in view mode only (JFrisbie, 2026-09-03).\r\n\r\n                Re-reads this contract — both reads, the aggregate and `/fields` — without touching the\r\n                route, so the tab you are on and the journey back to the workspace both survive. It\r\n                sits inside the `isView()` branch rather than being rendered disabled in the other\r\n                modes, which is what \"only usable in view/idle\" asks for: while editing, the control\r\n                that re-reads from CTRM would compete with unsaved changes, and a disabled button is an\r\n                invitation to wonder why.\r\n\r\n                ⚠ So this is the one thing on this row that does NOT hold the same position in all\r\n                three modes. That is a deliberate exception to the invariant noted above: Save and\r\n                Cancel still occupy the place Edit and New occupy, and refresh is additive to the view\r\n                mode rather than a fourth mode-dependent slot.\r\n              -->\r\n              <cms-refresh-button\r\n                label=\"Refresh this contract\"\r\n                [busy]=\"isRefreshing()\"\r\n                (refresh)=\"refresh()\"\r\n              />\r\n\r\n            <!--\r\n              🔴 The three WRITE controls, together, gated as one (F4.3a, extending #155).\r\n\r\n              Copy, Edit and New all end at a screen whose Save requires the Admin role, so showing\r\n              them to a reader is an invitation to fill in 111 fields and be refused — the defect\r\n              #155 removed at the Save button, met three steps earlier.\r\n\r\n              ⚠ **Refresh stays outside this gate.** It re-reads the contract, which any signed-in\r\n              user may do (correction C-14 keeps reads un-scoped), and it is the one control on this\r\n              row a reader genuinely wants.\r\n\r\n              🔴 **Hidden, not disabled** — the opposite call from \"Copy contract w/ pricing\" three\r\n              lines down, and the difference is worth stating because both are deliberate. That item\r\n              is disabled because the capability does not exist for ANYONE and naming its blocker is\r\n              useful to every reader. These are absent because they do not exist for THIS ACCOUNT,\r\n              and a row of greyed buttons tells a user nothing they can act on. One sentence below\r\n              says why, once, instead of three disabled promises.\r\n\r\n              ⚠ Gated on the GRANT only (#411). A refusal that is about the trade unit (not onboarded)\r\n              or about CTRM (the availability gate) is not about this account, so the block stays and\r\n              the CTRM writes in it, Close and Re-open, are disabled with the reason instead. Copy, Edit\r\n              and New only navigate; the Save they lead to carries the same refusal.\r\n            -->\r\n            @if (canWriteCws()) {\r\n                <!--\r\n                  Copy, immediately right of Refresh (JFrisbie, 2026-09-10). BR-041.\r\n\r\n                  **One icon trigger opening a menu of two, rather than two buttons** (JFrisbie,\r\n                  2026-09-10). The first revision put both on the row, which made five controls and\r\n                  629px of toolbar for what is one decision with two answers — and it gave the rarer,\r\n                  currently-unavailable option exactly as much prominence as the ordinary one.\r\n\r\n                  Same shape as the workspace's Export menu: `cmsDropdown` for the open/close\r\n                  behaviour, `role=\"menu\"` markup owned here. The directive is deliberately behaviour\r\n                  and not a component, because a shared component would have had to pick between\r\n                  `role=\"menu\"` and `role=\"listbox\"` for every caller.\r\n\r\n                  ⚠ **The directive's Escape handling matters more on this screen than anywhere else.**\r\n                  This record screen binds Escape to navigate back to the contract list, and\r\n                  `DropdownDirective` calls `preventDefault()` when Escape actually dismissed a panel —\r\n                  so closing this menu with Escape does not also throw the user off the record. That\r\n                  interaction is already handled; do not add a local Escape listener.\r\n                -->\r\n                <div cmsDropdown #copyMenu=\"cmsDropdown\" class=\"cws:relative\">\r\n                  <!--\r\n                    Icon-only, so it needs both an `aria-label` and the 20px line box.\r\n\r\n                    🔴 **`h-5` on the icon wrapper is load-bearing, not decoration.** A `scoular-btn`\r\n                    is 38px only while it contains *text*: `py-2` plus a `text-sm` line box plus a 1px\r\n                    border. An icon has no line box, so an icon-only button renders **36px** and sits\r\n                    two pixels short of Edit and New beside it. The wrapper restores the line box the\r\n                    missing text would have occupied — and `h-5` is chosen because **height is\r\n                    uncontested**: the design system compiles unlayered and would beat a utility\r\n                    fighting its `py-2`, but it never declares a height. Measured at 38px against the\r\n                    other three controls across five viewport widths.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    aria-label=\"Copy this contract\"\r\n                    title=\"Copy this contract\"\r\n                    aria-haspopup=\"menu\"\r\n                    [attr.aria-expanded]=\"copyMenu.open()\"\r\n                    (click)=\"copyMenu.toggle()\"\r\n                  >\r\n                    <span class=\"cws:flex cws:h-5 cws:items-center\" aria-hidden=\"true\">\r\n                      <!--\r\n                        Two offset rounded rectangles — the conventional duplicate mark. Stroked in\r\n                        currentColor so it inherits the button's text colour in both themes, and\r\n                        `size-4` to match the refresh mark immediately left of it.\r\n                      -->\r\n                      <svg\r\n                        viewBox=\"0 0 24 24\"\r\n                        fill=\"none\"\r\n                        stroke=\"currentColor\"\r\n                        stroke-width=\"2\"\r\n                        stroke-linecap=\"round\"\r\n                        stroke-linejoin=\"round\"\r\n                        class=\"cws:size-4 cws:shrink-0\"\r\n                      >\r\n                        <rect x=\"8\" y=\"8\" width=\"14\" height=\"14\" rx=\"2\" ry=\"2\" />\r\n                        <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\" />\r\n                      </svg>\r\n                    </span>\r\n                  </button>\r\n\r\n                  @if (copyMenu.open()) {\r\n                    <!--\r\n                      `w-80` because the second item's subtext explains why it is unavailable, and the\r\n                      panel's own `min-w-[12rem]` would wrap it into four lines.\r\n\r\n                      Left-anchored (`right-0`) like every other menu on this row's side of the page,\r\n                      so it opens inward rather than off the edge of the viewport.\r\n                    -->\r\n                    <div\r\n                      class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\"\r\n                      role=\"menu\"\r\n                      aria-label=\"Copy contract\"\r\n                    >\r\n                      <div class=\"scoular-dropdown-header\">Create a copy of {{ contractNumber() }}</div>\r\n\r\n                      <!--\r\n                        An anchor rather than a button, so middle-click and \"open in new tab\" work and\r\n                        it carries a real `href` — the same reasoning the breadcrumb crumbs carry. It\r\n                        addresses the ordinary create route with a seed parameter, so a copy is a\r\n                        linkable URL rather than transient in-memory state: reload it and you still\r\n                        get the copy.\r\n\r\n                        ⚠ It carries no `returnTo`. The copy's Cancel goes to the workspace, exactly as\r\n                        an ordinary create's does, because abandoning a create should not land the user\r\n                        back on someone else's contract as though they had been editing it.\r\n\r\n                        `text-left` on the item is load-bearing for the same reason the Export menu\r\n                        records: `.scoular-dropdown-item` inherits `text-align: center` from `<button>`,\r\n                        and a subtext long enough to wrap centres its second line.\r\n                      -->\r\n                      <a\r\n                        role=\"menuitem\"\r\n                        class=\"scoular-dropdown-item cws:text-left\"\r\n                        [attr.href]=\"hrefFor(copyIntent())\"\r\n                        (click)=\"copyMenu.close(); follow($event, copyIntent())\"\r\n                      >\r\n                        <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                          <span>Copy contract</span>\r\n                          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            Every field, a new contract number, no pricing\r\n                          </span>\r\n                        </span>\r\n                      </a>\r\n\r\n                      <!--\r\n                        #459 (F3.4), go given 2026-10-07. Prices cannot ride the create (`prices` is\r\n                        not writable on `upsertContract`), so this is a **sequenced two-step**: create\r\n                        the contract, then post each price sequence UNAPPROVED over the pricing routes,\r\n                        every one read back. The second step can fail after the first has spent the\r\n                        number, which is why it ASKS first and says so, and why its results are shown\r\n                        per sequence on the contract it made (`cws-pricing-copy-panel`).\r\n\r\n                        ⚠ A host without a pricing seam keeps the item disabled with its reason, rather\r\n                        than starting a copy whose second half has nowhere to go.\r\n                      -->\r\n                      @if (pricingCopyOffered) {\r\n                        <button\r\n                          type=\"button\"\r\n                          role=\"menuitem\"\r\n                          class=\"scoular-dropdown-item cws:text-left\"\r\n                          [attr.aria-expanded]=\"copyPricingConfirm()\"\r\n                          (click)=\"copyPricingConfirm.set(!copyPricingConfirm())\"\r\n                        >\r\n                          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                            <span>Copy contract w/ pricing</span>\r\n                            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              Every field, then each price sequence, unapproved\r\n                            </span>\r\n                          </span>\r\n                        </button>\r\n\r\n                        @if (copyPricingConfirm()) {\r\n                          <div\r\n                            data-testid=\"copy-pricing-confirm\"\r\n                            class=\"cws:space-y-2 cws:border-t cws:border-slate-200 cws:px-4 cws:py-3 cws:text-xs cws:text-slate-600 cws:dark:border-slate-700 cws:dark:text-slate-300\"\r\n                          >\r\n                            <p>\r\n                              Creating the copy <strong>spends a new contract number</strong>, whatever\r\n                              then happens to the prices. Each price sequence is then posted unapproved\r\n                              and read back; any not copied are listed for you to retry.\r\n                            </p>\r\n                            @if (sourcePriceCount() > 10) {\r\n                              <p>\r\n                                {{ contractNumber() }} has {{ sourcePriceCount() }} price sequences, and\r\n                                each is posted one at a time, so this takes a while.\r\n                              </p>\r\n                            }\r\n                            <div class=\"cws:flex cws:gap-2\">\r\n                              <button\r\n                                type=\"button\"\r\n                                class=\"scoular-btn scoular-btn-primary scoular-btn-sm\"\r\n                                (click)=\"copyMenu.close(); confirmCopyWithPricing()\"\r\n                              >\r\n                                Copy with pricing\r\n                              </button>\r\n                              <button\r\n                                type=\"button\"\r\n                                class=\"scoular-btn scoular-btn-outline scoular-btn-sm\"\r\n                                (click)=\"copyPricingConfirm.set(false)\"\r\n                              >\r\n                                Cancel\r\n                              </button>\r\n                            </div>\r\n                          </div>\r\n                        }\r\n                      } @else {\r\n                        <button\r\n                          type=\"button\"\r\n                          role=\"menuitem\"\r\n                          disabled\r\n                          class=\"scoular-dropdown-item cws:text-left\"\r\n                          aria-describedby=\"copy-with-pricing-blocker\"\r\n                        >\r\n                          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                            <span>Copy contract w/ pricing</span>\r\n                            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              Not available here — this application has no pricing connection\r\n                            </span>\r\n                          </span>\r\n                        </button>\r\n\r\n                        <!--\r\n                          The disabled item's full reason, for a screen reader. `sr-only` positions\r\n                          absolutely, so it is out of flow and cannot affect the menu's layout — which is\r\n                          the trap that lifted a grid row by 28px on 2026-09-09, when `sr-only` went on a\r\n                          label row instead of on the label text.\r\n                        -->\r\n                        <span id=\"copy-with-pricing-blocker\" class=\"sr-only\">\r\n                          Copying with pricing is not available here, because this application has no\r\n                          pricing connection. Copy the contract, then add its price sequences on the\r\n                          pricing screen once it is saved.\r\n                        </span>\r\n                      }\r\n                    </div>\r\n                  }\r\n                </div>\r\n\r\n                <!--\r\n                  F3.5 — close / re-open, offered only where the host provided the action and the\r\n                  contract has loaded. Gated on `canWrite()` with the rest of this block.\r\n\r\n                  🔴 **Close CONFIRMS, and the confirmation carries the provenance sentence** — closing\r\n                  rewrites pricing-approval provenance and re-opening does not put it back, so the pair\r\n                  is not symmetric and the dialog says so rather than implying an undo.\r\n                -->\r\n                @if (canChangeState()) {\r\n                  <!-- #411: disabled with the reason as its title (the F4.3a style) when CTRM will not take it. -->\r\n                  @if (isClosed()) {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working' || ctrmWriteBlock() !== null\"\r\n                      [attr.title]=\"ctrmWriteBlock()\"\r\n                      (click)=\"onReopenContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Re-opening… } @else { Re-open contract }\r\n                    </button>\r\n                  } @else {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working' || ctrmWriteBlock() !== null\"\r\n                      [attr.title]=\"ctrmWriteBlock()\"\r\n                      (click)=\"onCloseContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Closing… } @else { Close contract }\r\n                    </button>\r\n                  }\r\n                }\r\n\r\n                <!--\r\n                  Carries the tab, so Edit → Cancel returns you to the tab you were reading.\r\n                  JFrisbie, 2026-10-23: a read-only contract (closed, or an intercompany purchase) offers\r\n                  no Edit, and says why where it would be.\r\n                -->\r\n                @if (readOnlyReason(); as reason) {\r\n                  <p role=\"status\" class=\"cws:self-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"read-only-reason\">\r\n                    {{ reason }}. It cannot be edited.\r\n                  </p>\r\n                } @else {\r\n                  <a\r\n                    [attr.href]=\"hrefFor(editIntent())\"\r\n                    (click)=\"follow($event, editIntent())\"\r\n                    class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                  >\r\n                    Edit contract\r\n                  </a>\r\n                }\r\n\r\n                <a\r\n                  [attr.href]=\"hrefFor(newIntent)\"\r\n                  (click)=\"follow($event, newIntent)\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                >\r\n                  New contract\r\n                </a>\r\n\r\n                @if (writeRefusal(); as refusal) {\r\n                  <!-- The visible half of the disabled controls' title, said once (#411). -->\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    {{ refusal.message }}\r\n                  </p>\r\n                }\r\n            } @else {\r\n              <!--\r\n                The reason, once — matching the wording the Save gate already uses so a user who\r\n                meets both does not read them as two different problems.\r\n\r\n                `role=\"status\"` rather than `alert`: it is a standing property of the screen, not\r\n                something that just happened.\r\n              -->\r\n              <p role=\"status\" class=\"cws:self-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                Editing needs the <strong>Admin</strong> role on this application.\r\n              </p>\r\n            }\r\n            } @else {\r\n              <!--\r\n                JFrisbie, 2026-10-23: greyed out while a required field on any tab is blank, and the hover\r\n                names them. aria-disabled rather than disabled, so a press still runs the hold: the summary\r\n                opens and the first blank field gets focus.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                [disabled]=\"!canSave()\"\r\n                [attr.aria-disabled]=\"saveHoldText() !== null ? 'true' : null\"\r\n                [class.cws:opacity-50]=\"saveHoldText() !== null\"\r\n                [class.cws:cursor-not-allowed]=\"saveHoldText() !== null\"\r\n                [attr.title]=\"saveHoldText()\"\r\n                data-testid=\"save-contract\"\r\n                (click)=\"onSave()\"\r\n              >\r\n                @if (save().status === 'saving' && !notifying()) {\r\n                  Saving…\r\n                } @else {\r\n                  <!--\r\n                    **One label in both modes** — \"Save contract\" whether adding or editing (JFrisbie,\r\n                    2026-09-03). It read \"Create contract\" on a create and \"Save changes\" on an edit.\r\n                    One verb for one action: the button does the same thing to the same record either\r\n                    way, and the mode is already unmistakable from the heading, the breadcrumb and the\r\n                    URL.\r\n\r\n                    ⚠ It therefore stops being the thing that tells the two modes apart, which two\r\n                    tests were using it for. Those now discriminate on the **heading** — \"New contract\"\r\n                    against the contract number — which is the more honest signal anyway: it is what a\r\n                    user reads to know which record they are on.\r\n                  -->\r\n                  Save contract\r\n                }\r\n              </button>\r\n\r\n              <!--\r\n                #812: Save & Notify (docs/02 §3.2, BR-064). The same save, asking CTRM to email the\r\n                contract's trader, which CTRM does only when the contract needs approval. Offered to\r\n                every writer (JFrisbie, 2026-10-15). Not the Log tab's Notify trader, which sends CWS's\r\n                own email.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-secondary\"\r\n                [disabled]=\"!canSave()\"\r\n                [attr.aria-disabled]=\"saveHoldText() !== null ? 'true' : null\"\r\n                [class.cws:opacity-50]=\"saveHoldText() !== null\"\r\n                [class.cws:cursor-not-allowed]=\"saveHoldText() !== null\"\r\n                [attr.title]=\"saveHoldText()\"\r\n                aria-describedby=\"save-and-notify-hint\"\r\n                (click)=\"onSave(true)\"\r\n              >\r\n                @if (save().status === 'saving' && notifying()) {\r\n                  Saving…\r\n                } @else {\r\n                  Save and notify\r\n                }\r\n              </button>\r\n              <span id=\"save-and-notify-hint\" class=\"cws:sr-only\">\r\n                CTRM emails the contract's trader if the contract needs approval.\r\n              </span>\r\n\r\n              @for (reason of saveErrorGroups().save; track reason) {\r\n                <!-- #830: another save of this contract is running. Said beside Save, as the API asks. -->\r\n                <p role=\"status\" class=\"cws:max-w-64 cws:self-center cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\" data-testid=\"save-in-flight\">\r\n                  {{ reason }}\r\n                </p>\r\n              }\r\n\r\n              @if (canWrite() && shipPeriodHoldReason(); as reason) {\r\n                <!--\r\n                  #839: the reason a ship period holds Save, beside Save. It used to show only at the\r\n                  foot of Shipping Info, one tab away from a user looking at a grey button.\r\n                -->\r\n                <!-- Bounded rather than full width: this row does not wrap, and full width squeezed Save. -->\r\n                <p role=\"status\" class=\"cws:max-w-64 cws:self-center cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\r\n                  {{ reason }}\r\n                </p>\r\n              }\r\n\r\n              @if (!canWrite()) {\r\n                <!--\r\n                  🔴 The REASON, not just a grey button (#155). Writing contracts needs the Admin app\r\n                  role — `CwsContractWriter` — while reading needs only Admin or User, so a perfectly\r\n                  legitimate user reaches this screen, fills it in and is refused at Save with nothing\r\n                  having said why.\r\n\r\n                  ⚠ Worded as what the account lacks rather than \"you do not have permission\", because\r\n                  the fix is an Entra app-role assignment someone has to request by name — the same\r\n                  reason the trade-unit picker names the role rather than saying access denied (#65).\r\n\r\n                  `role=\"status\"` rather than `alert`: it is a standing condition of the screen, not an\r\n                  event, and an assertive announcement on every render of a read-only record is noise.\r\n                -->\r\n                <!--\r\n                  #485: a night run now closes the availability gate every night, and an Admin was told\r\n                  they lacked the Admin role. The two gates have two sentences; the role one wins when\r\n                  both are closed, because it is the one the user can act on.\r\n                -->\r\n                <!--\r\n                  #411: the trade unit's refusal sits between the two, as the server orders them —\r\n                  permission, then onboarding — and ahead of CTRM's availability.\r\n                -->\r\n                @if (canWriteCws() && writeRefusal(); as refusal) {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    {{ refusal.message }} Your changes stay on this screen.\r\n                  </p>\r\n                } @else if (canWriteCws() && blockedByAvailability()) {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving to CTRM is paused: {{ availabilityTitle() }}. Your changes stay on this\r\n                    screen.\r\n                  </p>\r\n                } @else {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving needs the <strong>Admin</strong> role on this application. Your account can\r\n                    view contracts but not write them.\r\n                  </p>\r\n                }\r\n              }\r\n\r\n              <!--\r\n                Cancel carries its OWN parameters, not Edit's. An edit returns to this record on the tab\r\n                it was editing; a create returns to the workspace, where a `tab` parameter would be\r\n                meaningless noise in a URL people copy and share.\r\n              -->\r\n              <!-- #967: refused while a save is in flight; see `cancelDisabled`. -->\r\n              <a\r\n                [attr.href]=\"hrefFor(cancelIntent())\"\r\n                (click)=\"followCancel($event)\"\r\n                [attr.aria-disabled]=\"cancelDisabled() ? 'true' : null\"\r\n                [class.cws:opacity-50]=\"cancelDisabled()\"\r\n                [class.cws:cursor-not-allowed]=\"cancelDisabled()\"\r\n                class=\"scoular-btn scoular-btn-secondary\"\r\n              >\r\n                Cancel\r\n              </a>\r\n            }\r\n          </div>\r\n\r\n          <!--\r\n            #803: the last close or re-open. A failure is an alert, not a status: this DID just happen,\r\n            and it needs to interrupt. It also states that nothing changed, because the failure a user\r\n            most fears here is a half-applied one.\r\n\r\n            ⚠ Rendered only while there is an outcome, and `basis-full` so it takes a line of its own.\r\n            This row is `justify-between`: an always-present third child, even an empty one, split the\r\n            free space three ways and pulled the actions off the right edge to the middle.\r\n          -->\r\n          @if (stateOutcome()) {\r\n            <div class=\"cws:basis-full\" data-testid=\"state-outcome\">\r\n              <cms-status-message [outcome]=\"stateOutcome()\" (dismissed)=\"stateOutcome.set(null)\" />\r\n            </div>\r\n          }\r\n\r\n          @if (summaryEntries().length > 0) {\r\n            <!--\r\n              The validation summary (#791, docs/02 §3.1, 02a §6.2), beside the save actions. Every\r\n              field with an error, client or server, in form order; F8 reaches it. It is where a held\r\n              save explains itself: the entries marked \"must fix\" are what holds it (#791's ruling).\r\n            -->\r\n            <cms-validation-summary\r\n              class=\"cws:basis-full\"\r\n              [entries]=\"summaryEntries()\"\r\n              [(expanded)]=\"summaryExpanded\"\r\n              (chosen)=\"chooseSummaryEntry($event)\"\r\n            />\r\n          }\r\n        </div>\r\n\r\n        <!--\r\n          Header band. The contract number is the page's identity, so it is the h2 — the shell owns the\r\n          only h1.\r\n\r\n          The actions moved out of this card onto the row above it; see the comment there. What has NOT\r\n          changed is that they occupy the same place in all three modes, so the toolbar does not move\r\n          under the pointer when the mode changes — that invariant is why the whole block moved rather\r\n          than only the two view-mode buttons.\r\n        -->\r\n        <header\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <div class=\"cws:space-y-1\">\r\n            <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n              <!--\r\n                The same heading in view and edit, on purpose: a record's identity does not change\r\n                because it is being edited. A create has no number yet — CTRM issues it at reservation\r\n                (03 §2.6) — so the heading says what is being made.\r\n              -->\r\n              <h2 class=\"cws:text-xl cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                {{ isCreate() ? 'New contract' : contractNumber() }}\r\n              </h2>\r\n              @if (contract()?.version; as version) {\r\n                <!-- CTRM's version, not a CMS revision. Muted so it cannot be read as part of the key. -->\r\n                <span\r\n                  class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n                  title=\"CTRM contract version\"\r\n                >\r\n                  v{{ version }}\r\n                </span>\r\n              }\r\n              <!--\r\n                FileBound's document archive for this contract (docs/02 §8, #756). Pushed right with\r\n                `ml-auto` so it never reads as part of the number. Absent when no template is\r\n                configured, and on a create, which has no number yet. A new tab with\r\n                `noopener noreferrer`, because it leaves CWS.\r\n              -->\r\n              @if (fileBoundUrl(); as url) {\r\n                <a\r\n                  [href]=\"url\"\r\n                  target=\"_blank\"\r\n                  rel=\"noopener noreferrer\"\r\n                  class=\"cws:ml-auto cws:rounded cws:text-sm cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\r\n                  data-testid=\"filebound-link\"\r\n                >\r\n                  Document archive (FileBound)\r\n                  <span class=\"cws:sr-only\">(opens in a new tab)</span>\r\n                </a>\r\n              }\r\n            </div>\r\n            <!--\r\n              🔴 The header as an executive summary (JFrisbie, 2026-09-15 — UX brief item 1): what\r\n              contract this is, and the business context, without scrolling.\r\n\r\n              ⚠ **Status and the key quantities are deliberately NOT repeated here.** The brief's\r\n              sketch puts them in this block; they already sit in the summary band immediately below,\r\n              which is always visible in every mode and on every tab. Two copies of \"Priced 9,000 BU\"\r\n              one line apart is a number that can disagree with itself, which this repository has paid\r\n              for more than once — and the band is not a scroll away, it is the next element.\r\n\r\n              ⚠ **\"Last Modified\" is absent because CTRM does not send one.** Nothing on the aggregate\r\n              carries it; `version` is the nearest thing CTRM has and it is already beside the number.\r\n              Inventing a timestamp from the read would be a fact about our request, not the contract.\r\n\r\n              ⚠ **The CUSTOMER here is the id.** `getContract` carries no customer-name field and\r\n              never will; the name comes from the customer directory and is shown on the Customer\r\n              name field below, where the record screen also confirms a typed id on blur (F4.3b).\r\n              The header keeps the id because the id is the fact CTRM holds.\r\n            -->\r\n            <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n              @if (contract(); as detail) {\r\n                <!--\r\n                  Both the code and the name where we have them, for the same reason the grid's heading\r\n                  carries both: a code identifies a trade unit to CTRM, a name identifies it to a trader.\r\n                -->\r\n                {{ detail.header.commodity ?? 'Commodity not set' }}\r\n                @if (detail.header.tradeUnit) {\r\n                  · Trade unit {{ detail.header.tradeUnit }}\r\n                }\r\n                @if (detail.header.customerId) {\r\n                  · Customer {{ detail.header.customerId }}\r\n                }\r\n                @if (contractDateLabel(); as date) {\r\n                  · {{ date }}\r\n                }\r\n                @if (traderLabel(); as trader) {\r\n                  · Trader {{ trader }}\r\n                }\r\n              } @else {\r\n                Trade unit {{ loaded.config.tradeUnit }} · Field definitions from CTRM\r\n              }\r\n            </p>\r\n            <!--\r\n              #973: the LMS flag, CTRM contract note LMSFLAG (the server half #985). In the header\r\n              because it is a fact about the whole contract, not a field on one tab, and the header is\r\n              visible in every mode and on every tab.\r\n\r\n              - `none`/`manual`: a checkbox in edit and create, \"No\"/\"Yes\" in view.\r\n              - `automatic`: a read-only \"Yes\", because CTRM sets it for an LMS special type and the\r\n                API refuses clearing it.\r\n              - `unknown`: said, never shown as an unticked box that may be wrong.\r\n\r\n              A native checkbox with its own label, as \"Hide empty fields\" is. Only a change the user\r\n              made is sent; see `lmsFlagChanged`.\r\n            -->\r\n            <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-x-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"lms-flag\">\r\n              @if (lmsFlagRead().state === 'unknown') {\r\n                <span role=\"status\" data-testid=\"lms-flag-unknown\">{{ lmsFlagUnknownMessage }}</span>\r\n              } @else if (canEditLmsFlag()) {\r\n                <label class=\"cws:inline-flex cws:cursor-pointer cws:items-center cws:gap-2\">\r\n                  <input\r\n                    type=\"checkbox\"\r\n                    class=\"cws:size-4 cws:accent-scoular-blue\"\r\n                    [checked]=\"lmsFlagValue()\"\r\n                    (change)=\"setLmsFlag($any($event.target).checked)\"\r\n                    data-testid=\"lms-flag-checkbox\"\r\n                  />\r\n                  LMS contract\r\n                </label>\r\n              } @else {\r\n                <span>\r\n                  LMS contract:\r\n                  <strong data-testid=\"lms-flag-value\">{{ lmsFlagValue() ? 'Yes' : 'No' }}</strong>\r\n                </span>\r\n                @if (lmsFlagRead().state === 'automatic') {\r\n                  <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"lms-flag-automatic\">\r\n                    (set by CTRM for this special type)\r\n                  </span>\r\n                }\r\n              }\r\n              @for (reason of saveErrorGroups().lmsFlag; track reason) {\r\n                <p role=\"alert\" class=\"cws:basis-full cws:text-xs cws:text-red-700 cws:dark:text-red-300\" data-testid=\"lms-flag-error\">\r\n                  {{ reason }}\r\n                </p>\r\n              }\r\n            </div>\r\n          </div>\r\n\r\n        </header>\r\n\r\n        <!--\r\n          🔴 THE SUMMARY STRIP — the at-a-glance state, above the tabs and outside them.\r\n\r\n          Confirmations (docs/02 §4.4) and CTRM's computed quantity breakdown (docs/04 §6) were two\r\n          full-width cards stacked before any field, and then invisible from wherever you scrolled to.\r\n          They are the answers to \"is this approved\" and \"what is left to price\", which are the two\r\n          questions somebody opens a contract to ask — so they sit in one compact band that never\r\n          scrolls away behind a tab.\r\n\r\n          ⚠ **These are NOT form fields and must not become inputs.** All six quantities are\r\n          `access: readOnly` in the constraint dictionary — CTRM refuses them on a write — and all three\r\n          confirmation statuses are derived by BR-065 from a populated field. An input box here would\r\n          invite an edit that cannot exist.\r\n        -->\r\n        <!--\r\n          🔴 **ONE ROW, and the height is the requirement** (JFrisbie, 2026-09-15, from a screenshot).\r\n\r\n          This briefly stacked — confirmations above, a six-card quantity grid below — which gave the\r\n          cards room and cost roughly three times the vertical space on a band whose whole job is to be\r\n          glanceable without scrolling. The boxes are kept and made compact instead: label and value on\r\n          ONE line rather than stacked, so each is a chip rather than a tile.\r\n\r\n          ⚠ `items-center` and `gap-x-8`, not `justify-between` alone — the two groups wrap\r\n          independently at narrow widths, and without a row gap they collide before they wrap.\r\n        -->\r\n        <!--\r\n          🔴 **No border and no shadow on the band itself** (2026-09-21 restyle).\r\n\r\n          The card sat inside a page that already separates it — white on slate-50 in light, slate-800\r\n          on slate-900 in dark — so the border and the shadow were the outermost of THREE nested\r\n          borders around the same information. Removing it costs 2px of height and one visual edge.\r\n\r\n          ⚠ **The fill and the rounding stay.** Without them the band stops being an object and the\r\n          chips read as loose text under the header, which is the failure the original card was\r\n          solving. What is gone is the chrome, not the container.\r\n        -->\r\n        <div\r\n          class=\"cws:flex cws:flex-col cws:gap-3 cws:rounded-lg cws:bg-white cws:px-4 cws:py-3 cws:lg:flex-row cws:lg:flex-wrap cws:lg:items-center cws:lg:justify-between cws:lg:gap-x-8 cws:dark:bg-slate-800\"\r\n        >\r\n          <!--\r\n            🔴 WORKFLOW CARDS, not inline pills (JFrisbie, 2026-09-15 — UX brief item 2).\r\n\r\n            The three statuses read as disconnected captions in a row. As cards they read as what they\r\n            are: three checkpoints on one contract, each with a state.\r\n\r\n            ⚠ **Three independent fields that happen to progress, NOT a state machine.** BR-065 derives\r\n            each from a populated field, so a later stage can be set with an earlier one blank — which\r\n            is why these stay three separate cards rather than becoming a connected stepper. A stepper\r\n            would assert an ordering the data does not have, and would render a contract whose broker\r\n            confirmed before its trader approved as though something had gone wrong.\r\n\r\n            The pill keeps the colour. It carries the state in a word as well as a hue, which is what\r\n            makes the card readable without relying on colour at all.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Contract confirmations\">\r\n            @for (stage of confirmations(); track stage.label) {\r\n              <!--\r\n                🔴 **The chip IS the status now — no pill inside it.** The tint, the dot and the word\r\n                are one box.\r\n\r\n                🔴 **`items-baseline` + an explicit `/5` leading on every text node, and this is the\r\n                whole alignment story for the band** (JFrisbie, 2026-09-21, from a screenshot of the\r\n                running app).\r\n\r\n                The first version of this restyle used `items-center` here and `items-baseline` on the\r\n                quantity chips, with `h-7` fixing the box height. Every box lined up — measured at a\r\n                uniform 28px, which is why the geometry pass called it done — and **the TEXT inside\r\n                them sat on four different baselines**: 46, 47, 48.8 and 51, a 5px spread. `Rejected`\r\n                floated against its own label, and the six metrics sat on a different line from the\r\n                three statuses.\r\n\r\n                🔑 **`items-center` centres each flex item independently**, so an 11px label and a 14px\r\n                value in the same chip are centred separately and their baselines cannot agree. And a\r\n                fixed `h-7` hid it: the boxes were identical, so nothing about the geometry looked\r\n                wrong.\r\n\r\n                The fix is to let the LINE BOX set the height instead. Both text nodes carry `/5`\r\n                (20px), padding is `py-1`, so every chip is 4 + 20 + 4 = **28px — exactly what `h-7`\r\n                was giving** — but now derived from a shared line box, so all eighteen pieces of text\r\n                in the ribbon rest on one baseline.\r\n\r\n                ⚠ **Do not reintroduce `h-7`, and do not drop the `/5`.** Either one restores a height\r\n                that is correct while the text inside drifts, which is the failure a box measurement\r\n                cannot see.\r\n              -->\r\n              <!--\r\n                (The chips were previously 36/34/30 tall depending on whether a badge was inside;\r\n                that raggedness is what the uniform line box removed.)\r\n\r\n                🔑 **The dot is not decoration.** Roughly 1 in 12 men has a colour vision deficiency\r\n                (docs/02a §4), and the state is already carried by the WORD — the dot adds a second\r\n                non-colour cue of position and presence, so the three stages are distinguishable at a\r\n                glance even where the hues are not.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-2 cws:rounded-md cws:px-2.5 cws:py-1\"\r\n                [class]=\"stage.style.chip\"\r\n              >\r\n                <!--\r\n                  ⚠ `self-center`, because an empty inline box has its baseline at its BOTTOM edge —\r\n                  under `items-baseline` the dot would otherwise sit on the text baseline rather than\r\n                  beside the middle of the word.\r\n                -->\r\n                <!--\r\n                  ⚠ The dot sits INSIDE the `<dt>` (#764): a `<div>` in a `<dl>` may hold only\r\n                  `<dt>`/`<dd>`, and a bare `<span>` beside them failed axe's definition-list rule. It\r\n                  is an inline-block with `align-middle`, so the `<dt>` keeps its text baseline for the\r\n                  band's `items-baseline`; `aria-hidden` because the word carries the state.\r\n                -->\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  <span\r\n                    class=\"cws:mr-2 cws:inline-block cws:size-1.5 cws:rounded-full cws:align-middle\"\r\n                    [class]=\"stage.style.dot\"\r\n                    aria-hidden=\"true\"\r\n                  ></span>{{ stage.label }}\r\n                </dt>\r\n                <dd class=\"cws:shrink-0 cws:text-sm/5 cws:font-semibold\" [class]=\"stage.style.text\">\r\n                  @if (stage.badge; as badge) {\r\n                    {{ badge.label }}\r\n                  } @else {\r\n                    <!--\r\n                      ⚠ Still visibly DIFFERENT from a set status rather than an empty pill — the\r\n                      neutral tone plus a lighter weight. An empty pill reads as a status; this reads\r\n                      as no status, which is the truth.\r\n                    -->\r\n                    <span class=\"cws:font-normal\" [title]=\"stage.emptyNote ?? ''\">Not set</span>\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n\r\n          <!--\r\n            🔴 KPI CARDS, not label/value pairs (JFrisbie, 2026-09-15 — UX brief item 3).\r\n\r\n            These were six captions in a flex row, which is how the most important numbers on the page\r\n            ended up the most visually understated. As cards the figure leads and the label supports\r\n            it, which is the reading order a trader actually wants.\r\n\r\n            CTRM's numbers, never recalculated here: disagreeing with the system of record about a\r\n            settled quantity would be worse than not showing it. `tabular-nums` so the figures line up\r\n            as a column of numbers rather than drifting with their digit widths.\r\n\r\n            ⚠ **The unit travels with the number** — see `quantityBreakdown`. A bare grain quantity is a\r\n            recorded defect on this project, not a nicety.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Quantity breakdown\">\r\n            @for (measure of quantityBreakdown(); track measure.label) {\r\n              <!--\r\n                🔴 **A fill, not a border, and no left accent.** These were bordered pills carrying a\r\n                4px coloured edge each — six of them, which was the densest chrome in the band. A flat\r\n                tint separates a chip from the card just as well and draws no lines.\r\n\r\n                ⚠ **Uniformly slate, deliberately.** Colour in this band means status; these are\r\n                arithmetic. The removed accent and the reasoning are on `quantityBreakdown`.\r\n\r\n                The hierarchy is carried by weight and size instead: the label drops to 11px and the\r\n                figure stays `font-semibold`, so the number leads its chip without either growing.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-1.5 cws:rounded-md cws:bg-slate-100 cws:px-2.5 cws:py-1 cws:dark:bg-slate-700/40\"\r\n              >\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  {{ measure.label }}\r\n                </dt>\r\n                <dd class=\"cws:text-sm/5 cws:font-semibold cws:tabular-nums cws:text-slate-900 cws:dark:text-white\">\r\n                  @if (measure.value === null) {\r\n                    <!-- An em dash, never 0: CTRM holding no figure is not a quantity of nothing. -->\r\n                    <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">—</span>\r\n                  } @else {\r\n                    {{ measure.value.toLocaleString('en-US') }}\r\n                    @if (measure.uom; as uom) {\r\n                      <span class=\"cws:text-[11px]/5 cws:font-normal cws:text-slate-600 cws:dark:text-slate-400\">\r\n                        {{ uom }}\r\n                      </span>\r\n                    }\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n        </div>\r\n\r\n        <!--\r\n          🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\r\n          workspace grid and the approval screens. Up to five full-width banners used to sit between\r\n          the summary strip and the tabs, so on a create the form began below the fold.\r\n\r\n          ⚠ **Widened 2026-09-17 to nine, and four of them came from OUTSIDE this stack** — the copy\r\n          provenance, the create-pending note, the configuration provenance line under the tabs, and\r\n          the unmodelled-collections note that sat at the very bottom of the record. They were not\r\n          part of the original five because they were not full-width banners between the strip and\r\n          the tabs; they were still standing conditions, and scattering them was costing more than\r\n          their individual size suggested.\r\n\r\n          🔴 **What is in here and what is NOT is the load-bearing decision, and it is not about\r\n          length.** Standing conditions of the screen go in; **the outcome of something the user just\r\n          did stays out** — every banner below this point is the second kind (a save result, a save\r\n          failure, a copy whose source could not be read, a contract number that was not issued, a\r\n          prefill that failed). Two of those carry `role=\"alert\"` because they must interrupt, and\r\n          behind a collapsed panel they would be messages nobody sees. Before this change both kinds\r\n          rendered identically, which is exactly why the distinction needs stating.\r\n\r\n          ⚠ **The summaries live in `noticeSummaries` and must stay in this order.** Nothing enforces\r\n          it.\r\n        -->\r\n        <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n          @if (isSimulated()) {\r\n            <!--\r\n              Same banner and the same reason as the grid: a demo that silently shows generated data is\r\n              how generated data gets quoted as a production readout.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Simulated data</div>\r\n              <div class=\"scoular-alert-description\">\r\n                This contract is generated locally, not read from CTRM.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCopy() && !copyFailed()) {\r\n            <!--\r\n              A copy says what it is a copy of, and says what it did NOT bring with it.\r\n\r\n              🔴 The second half is the load-bearing half. A user who pressed \"Copy contract\" has every\r\n              reason to believe the new contract carries everything the old one did. The number never\r\n              comes (deliberately — see `CONTRACT_COPY_IDENTITY_FIELDS`, it is what stops the copy\r\n              overwriting its source), the prices only through copy-with-pricing, and the collections\r\n              as `describeCollectionCopy` says (#960): each one names why it was left out, and only one\r\n              actually left out is named. Stating them here is the difference between a copy the user\r\n              can trust and one they have to audit.\r\n\r\n              ⚠ **In the panel, where the copy FAILURE three blocks below is not, and the split is the\r\n              membership rule rather than a judgement about length.** \"This record is a copy of X\" is\r\n              true for the whole life of the screen — a standing condition of what the user is looking\r\n              at. \"X could not be read\" is the outcome of the action they just took, it carries\r\n              `role=\"alert\"`, and behind a disclosure it would be a message nobody sees.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Copied from {{ copyFrom }}</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Every writable field was carried across and can be changed before saving. A\r\n                <strong>new contract number</strong> has been issued — this will create a new contract\r\n                and cannot alter {{ copyFrom }}.\r\n                @if (isCopyWithPricing() && collectionCopy()?.pricesExcluded !== true) {\r\n                  <!-- #459: the prices are the second step, posted only once this create succeeds. -->\r\n                  <strong>Its prices are copied once this contract is created</strong>, one sequence at\r\n                  a time and each unapproved, with the result shown on the new contract.\r\n                }\r\n              </div>\r\n              @if (collectionCopySentences().length > 0) {\r\n                <!-- #960: what came across of the collections, and why the rest did not. -->\r\n                <ul class=\"scoular-alert-description cws:list-disc cws:pl-5\" data-testid=\"copy-collections\">\r\n                  @for (sentence of collectionCopySentences(); track sentence) {\r\n                    <li>{{ sentence }}</li>\r\n                  }\r\n                </ul>\r\n              }\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate() && canUseTemplates()) {\r\n            <!--\r\n              F3.3 — create from a template.\r\n\r\n              🔴 **Applying a template seeds the FULL set it carries, not the fields somebody typed.**\r\n              A template is captured whole precisely so applying it is whole; carrying only part of it\r\n              across is the defect that generalised from one field to forty.\r\n\r\n              ⚠ Through `seed`, so the values arrive as defaults rather than as edits — the same\r\n              distinction the customer-name confirmation makes, and it matters because six derived\r\n              descriptions sit on CTRM's re-confirmation list.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Start from a template</div>\r\n              <div class=\"scoular-alert-description\">\r\n                @if (templatesFailed()) {\r\n                  <!-- Not the same as \"this trade unit has none\", which would be a claim. -->\r\n                  <span>The templates for this trade unit could not be loaded.</span>\r\n                } @else if (availableTemplates().length === 0) {\r\n                  <span>This trade unit has no saved templates yet.</span>\r\n                } @else {\r\n                  <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n                    <span>Apply a template</span>\r\n                    <select\r\n                      class=\"cws:rounded cws:border cws:border-slate-300 cws:p-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      (change)=\"onApplyTemplate($any($event.target).value)\"\r\n                    >\r\n                      <option value=\"\">Choose…</option>\r\n                      @for (template of availableTemplates(); track template.id) {\r\n                        <option [value]=\"template.id\">{{ template.name }}</option>\r\n                      }\r\n                    </select>\r\n                  </label>\r\n\r\n                  @if (appliedTemplate(); as applied) {\r\n                    <p class=\"cws:mt-1\">\r\n                      Applied <strong>{{ applied }}</strong>. Every value it carried can be changed\r\n                      before saving.\r\n                    </p>\r\n                  }\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate()) {\r\n            <!--\r\n              Why the confirmation pills and the quantity breakdown are empty on a create.\r\n\r\n              ⚠ **The per-stage `emptyNote` is a `title` attribute only**, so it is a tooltip and not a\r\n              visible statement — this is the only place the reason is readable. It moved in here rather\r\n              than being deleted: a panel summary renders in BOTH states, so it is still on screen.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some values appear once this contract is saved</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Confirmations and CTRM’s computed quantity breakdown are {{ pendingNote }}, so those\r\n                panels are empty rather than failing to load.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable()) {\r\n            <!--\r\n              The standing caveat about what can be ENTERED — one of the three things the mode may\r\n              change, which is why it is gated on the mode rather than shown always.\r\n\r\n              ⚠ **This is the notice in here with the strongest claim to being left out**, and it is\r\n              the one to pull back up if the panel proves too quiet. Known Issue 30's instruction is\r\n              that anyone shown this screen reads it as the agreed field set, and unlike the approval\r\n              screen's CTRM caveat **there is no restatement of this at the point of action** — no\r\n              message appears at Save saying the contract has no ship periods. What makes collapsing\r\n              it defensible rather than a loss: the omission is *recoverable* (ship periods can be\r\n              added in CTRM afterwards) and the fields are optional, so a contract saved without them\r\n              is valid rather than wrong.\r\n            -->\r\n            <!--\r\n              🔴 **REWORDED 2026-09-25 (ruled by JFrisbie on #226). The previous text said shipment\r\n              dates \"cannot be entered here\", and that stopped being true when F2.3b built the\r\n              editable ship-period table** — which is available in create mode, since the editable\r\n              branch is gated on the form being writable rather than on the record existing.\r\n\r\n              ⚠ **What is kept is the half #226 was actually about**: they are OPTIONAL, a contract\r\n              saved without them genuinely has NONE, and CTRM derives none of its own. That was\r\n              settled from CTRM source rather than by spending a contract number — ship periods are\r\n              twelve positional slots and the read unpivots them on a non-sentinel begin date, so a\r\n              slot nobody filled never becomes a row. A user who assumes CTRM fills them in gets a\r\n              contract with zero ship periods and does not know it.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <!--\r\n                ⚠ Deliberately NOT word-for-word the panel summary. They render together when the\r\n                panel is open, and two identical lines read as a rendering fault; the summary states\r\n                the fact and the title states the consequence.\r\n              -->\r\n              <div class=\"scoular-alert-title\">Shipment dates are optional, not missing</div>\r\n              <div class=\"scoular-alert-description\">\r\n                All 108 of CTRM’s writable contract fields are here, and\r\n                <strong>ship periods can be entered on the Shipping tab</strong>. They are\r\n                <strong>optional</strong>, not missing: a contract saved without them genuinely has none,\r\n                because CTRM derives no shipment dates of its own. If you do enter them, CTRM refuses a\r\n                contract whose ship quantities do not sum to the header quantity — this screen states\r\n                the running total and blocks Save while they disagree, so that refusal is not reached.\r\n                Fields, widths and decimal places are read from CTRM’s own definitions, so what\r\n                you type is validated exactly as CTRM would; the tab grouping follows the Power App, and\r\n                the <em>Additional fields</em> tab holds the CTRM fields it never surfaced.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (configDefaultsOnly()) {\r\n            <!--\r\n              The configuration could not be resolved, so this record is on the layout's defaults.\r\n\r\n              The consequence is actionable and invisible otherwise: a field an admin marked required\r\n              may not be marked required here, and one they hid may be showing. The save still enforces\r\n              the real configuration server-side, so the failure a user would otherwise meet is a\r\n              refusal naming a field the form never asked for — which reads as a bug in the form.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Showing default field settings</div>\r\n              <div class=\"scoular-alert-description\">\r\n                The form configuration could not be loaded, so this record shows every field with default\r\n                settings. Anything an administrator has configured for this trade unit — hidden fields,\r\n                extra required fields, custom tabs — is not reflected here. Saving still applies the real\r\n                configuration, so a save may be refused for a field this form did not mark as required.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (constraintsNotice() === 'bundled') {\r\n            <!--\r\n              #732. CTRM's field definitions could not be read, and neither could the configuration, so\r\n              the widths and decimal places on this form come from the copy built into the app. That copy\r\n              is the same generated document as of this build, so it can lag a newer server.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Field limits are the copy built into this app</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM’s field definitions could not be loaded, so this form checks lengths and decimal places\r\n                against the limits built into this app. They match CTRM as of this release; if CTRM has\r\n                changed a field since, a save may be refused for it.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (constraintsNotice() === 'unavailable') {\r\n            <!--\r\n              #732. The configuration resolved, so widths and decimal places come from the server and are\r\n              live. Only the integer-digit check needs the document itself, and that is what is missing.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some field limits are not checked here</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM’s field definitions could not be loaded. Lengths and decimal places are still checked,\r\n                but digits before the decimal point are not checked on this form. CTRM checks them when you\r\n                save.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable() && unavailableLists().length > 0) {\r\n            <!--\r\n              Which dropdowns have no values, and why. A combo rendering an empty list looks like a bug in\r\n              this screen; it is a known gap in the reference route (issues 44 and 83).\r\n\r\n              ⚠ The description names no issue number: a trader cannot open one, and the sentence has to\r\n              stand on its own as \"typed, not picked, and that is expected\".\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some lists are unavailable</div>\r\n              <div class=\"scoular-alert-description\">\r\n                {{ unavailableLists().join(', ') }} returned no values, so those fields accept a typed code\r\n                instead of offering a list. The reference routes they need are parameterised and not\r\n                callable yet.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (unmodelled().length > 0) {\r\n            <!--\r\n              🔑 Shown deliberately, and the endpoint goes out of its way to make it possible.\r\n\r\n              These are child collections CTRM DOES return and CMS does not read yet. Hiding them would\r\n              make this screen answer \"this contract has no quality factors\" when the truth is \"CMS does\r\n              not read quality factors\" — a difference that matters to anyone using this screen to check\r\n              data, and one nobody could detect from the outside.\r\n\r\n              ⚠ **It used to sit at the very bottom of the record, below every tab's content.** That is\r\n              the one place a statement about the WHOLE record is least likely to be read, and it was\r\n              below the fold on every contract. In the panel it keeps its scope and gains a reader.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-title\">Not read by CMS yet</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM returns {{ unmodelled().length }} further collections on this contract that this\r\n                application does not read:\r\n                <span class=\"cws:font-medium\">\r\n                  @for (name of unmodelled(); track name; let last = $last) {\r\n                    <span [title]=\"name\">{{ readable(name) }}</span>{{ last ? '' : ', ' }}\r\n                  }\r\n                </span>\r\n                — so an empty section means “not read”, not “not present”.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (provenanceLabel() !== null) {\r\n            <!--\r\n              Which configuration row is in force.\r\n\r\n              It answers the question nobody could otherwise answer from the screen: \"why is this field\r\n              required here and not on the contract I looked at before?\" It is the admin's debugging\r\n              thread — which is exactly why it belongs behind the disclosure rather than as a permanent\r\n              muted line under the tabs, where it was one more thing between the user and the fields.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-description\">{{ provenanceLabel() }}</div>\r\n            </div>\r\n          }\r\n\r\n          @for (warning of warnings(); track warning) {\r\n            <!-- CTRM warnings are surfaced, not dropped (correction C-2). Rare on a read, never silent. -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n            </div>\r\n          }\r\n        </cms-notices-panel>\r\n\r\n        <!--\r\n          #459: copy-with-pricing's per-sequence results, on the contract the copy made. Outside the\r\n          notices panel because it is the outcome of something the user just did. Renders nothing for\r\n          a contract no copy was made to in this session.\r\n        -->\r\n        @if (!isCreate()) {\r\n          <cws-pricing-copy-panel [contractNumber]=\"contractNumber()\" />\r\n        }\r\n\r\n        <!--\r\n          A number that could not be issued is stated rather than left as an empty field, because the\r\n          three causes need three different actions and none of them is \"wait\". The field stays\r\n          editable throughout, so this is a notice and not a blocker.\r\n        -->\r\n        @if (numberIssueFailure()) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">A contract number was not issued</div>\r\n            <div class=\"scoular-alert-description\">{{ numberIssueFailure() }}</div>\r\n            <!-- #803: the server's reference, or why there is none. -->\r\n            <cms-reference-line [correlationId]=\"numberIssueReference()\" />\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          #204. A number the user typed was checked before the create and refused, or the check could\r\n          not run. The contract was NOT saved, so this interrupts (role=\"alert\").\r\n        -->\r\n        @if (numberCheck(); as reason) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"number-check-failure\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          BR-066, #143. On a customer-confirmed contract, changing a field CTRM's ConfirmChg diffs makes\r\n          the save start a new confirmation round. Said before the save, once the user has changed one,\r\n          because after the save it is already done. role=\"status\": a consequence to weigh, not an error.\r\n        -->\r\n        @if (confirmChgChanges(); as changed) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\" data-testid=\"confirm-chg-warning\">\r\n            <div class=\"scoular-alert-title\">Saving re-opens customer confirmation</div>\r\n            <div class=\"scoular-alert-description\">\r\n              This contract is confirmed, and you changed {{ changed.join(', ') }}. When you save, CTRM\r\n              issues a new confirmation version and a new confirmation for the customer to confirm again.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          A copy whose source could not be read is an ERROR, not a notice, and it must not look like\r\n          an ordinary blank create. The user asked for a copy; blank fields here would read as the\r\n          source contract's values and get saved.\r\n        -->\r\n        @if (copyFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">{{ copyFrom }} could not be read, so nothing was copied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is blank because the read of {{ copyFrom }} failed — <strong>not</strong>\r\n              because that contract is empty. <strong>Do not save from this state</strong> expecting a\r\n              copy: it would create a new contract carrying only what you type here. Reload to try\r\n              again, or start from {{ copyFrom }} and press Copy contract once it loads.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          #813: what a deep link asked for and did not get. Outcomes of how the screen was reached, so\r\n          banners rather than lines in the notices panel, beside the copy failure above. role=\"status\":\r\n          the screen is usable, it is simply not quite what the link described.\r\n        -->\r\n        @if (linkTradeUnitRefused()) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">The trade unit in this link was not applied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              The link asked for trade unit {{ linkTradeUnit }}, which could not be confirmed as one of\r\n              your trade units, so this contract is being created under the active trade unit\r\n              @if (activeTradeUnit(); as active) {\r\n                ({{ active }}).\r\n              } @else {\r\n                (none is selected).\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (linkTemplateRefusal(); as refusal) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">The template “{{ linkTemplate }}” in this link was not applied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              @switch (refusal) {\r\n                @case ('missing') {\r\n                  This trade unit has no template by that name or id, so the form starts without one.\r\n                }\r\n                @case ('unreadable') {\r\n                  The trade unit’s templates could not be loaded, so the form starts without one.\r\n                  Reload to try again.\r\n                }\r\n                @default {\r\n                  Templates are not available here, so the form starts without one.\r\n                }\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The values failing to load is stated, never absorbed. In view mode it stops an empty record\r\n          reading as an empty contract; in edit mode it is worse than that and the text says so.\r\n        -->\r\n        @if (prefillFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">This contract’s current values could not be loaded</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is showing blank because the read failed — <strong>not</strong> because the\r\n              contract is empty.\r\n              @if (isEditable()) {\r\n                <strong>Do not save from this state</strong>: a field you fill in here would be written\r\n                over whatever CTRM currently holds.\r\n              }\r\n              Reload the page, and if it keeps failing the contract can still be worked on the green\r\n              screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The save outcome, including WHICH of upsert's two paths CTRM took. A create that reports\r\n          \"Updated\" overwrote an existing contract and an update that reports \"Created\" made a new one;\r\n          both are shown rather than folded into a plain success, because that discriminator is the only\r\n          thing standing between a silent mistake and a caught one (docs/04e).\r\n        -->\r\n        @if (save().result; as result) {\r\n          <div class=\"scoular-alert scoular-alert-success\" role=\"status\">\r\n            <!-- #967: our words, the same sentence the next screen is left; never CTRM's `detail`. -->\r\n            <div class=\"scoular-alert-title\" data-testid=\"save-result-title\">{{ savedPanelTitle() }}</div>\r\n            <div class=\"scoular-alert-description\">\r\n              @if (!isCreate() && result.action === 'Created') {\r\n                <strong>\r\n                  ⚠ This was expected to update an existing contract and CTRM reports it created a new\r\n                  one. Check the contract number before continuing.\r\n                </strong>\r\n              }\r\n              @if (isCreate() && result.action === 'Updated') {\r\n                <strong>\r\n                  ⚠ This was expected to create a contract and CTRM reports it updated an existing one.\r\n                  An existing contract may have been overwritten.\r\n                </strong>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n\r\n        @if (recoverableDraft() !== null) {\r\n          <!--\r\n            🔴 An OFFER, never an automatic restore — F3.2f.\r\n\r\n            Silently repopulating a form would be indistinguishable from the contract genuinely\r\n            holding those values, and the user has no way to tell which they are looking at. Worse\r\n            under a full-replace upsert: a restored draft that the user does not notice is a set of\r\n            edits they never made, sent as if they had.\r\n\r\n            ⚠ `role=\"status\"` rather than `alert`: it is waiting for them, not interrupting them.\r\n          -->\r\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">Unsaved changes were recovered</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <p>\r\n                This form had unsaved changes when it was last open\r\n                @if (recoverableAt(); as at) {\r\n                  <span>, at {{ at }}</span>\r\n                }.\r\n              </p>\r\n              <div class=\"cws:mt-2 cws:flex cws:gap-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-primary\" (click)=\"restoreDraft()\">\r\n                  Restore them\r\n                </button>\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"discardDraft()\">\r\n                  Discard\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 #556: a failed save is THREE different things, and only one of them is a refusal.\r\n\r\n          A 422 is CTRM or the API saying no, with reasons. A lost CTRM answer is not a refusal at all:\r\n          the API reads the contract back to settle it (#513), and either the change is not there\r\n          (`not-applied`: safe to save again) or nobody can tell (`outcome-unknown`, and a status 0).\r\n          Saying \"not saved\" about the last case is how a retry becomes a duplicate write, and on a\r\n          create a second contract. The draft is kept in all three; only a success clears it.\r\n        -->\r\n        @if (save().status === 'failed' && save().failure === 'outcome-unknown') {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract may have been saved</div>\r\n            <!-- #803: the server's reference, or why there is none. -->\r\n            <cms-reference-line [correlationId]=\"save().correlationId\" />\r\n            <div class=\"scoular-alert-description\">\r\n              <!--\r\n                #951: the server's own sentence, because only it knows whether CTRM was silent or\r\n                answered with a database error (#929). The advice after it is keyed on the type alone.\r\n              -->\r\n              <p data-testid=\"save-lost-detail\">\r\n                {{ save().lostDetail ?? 'The answer to this save was lost, so it is not known whether the change was applied.' }}\r\n              </p>\r\n              <p>\r\n                Your edits are kept on this screen.\r\n                @if (isCreate()) {\r\n                  Check the contract list for the new contract before saving again, or a second\r\n                  contract may be created and the change applied twice.\r\n                } @else {\r\n                  Reload the contract to see what CTRM holds before saving again, or the change may be\r\n                  applied twice. Pressing Edit there offers these edits back.\r\n                }\r\n              </p>\r\n              <div class=\"cws:mt-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"reloadAfterUnknownSave()\">\r\n                  {{ isCreate() ? 'Check the contract list' : 'Reload the contract' }}\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        } @else if (save().status === 'failed' && save().failure === 'not-applied') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <!-- #951: the server's sentence, then the advice this type always carries (#556). -->\r\n            <div class=\"scoular-alert-description\">\r\n              <p data-testid=\"save-lost-detail\">\r\n                {{ save().lostDetail ?? 'CTRM’s answer could not be used, and reading the contract back shows the change is not there.' }}\r\n              </p>\r\n              <p>Your edits are kept, and it is safe to save again.</p>\r\n            </div>\r\n            <cms-reference-line [correlationId]=\"save().correlationId\" />\r\n          </div>\r\n        } @else if (save().status === 'failed') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5\">\r\n                <!--\r\n                  The API's own form-level text, plus any refusal whose `invalid_params[].name` is\r\n                  not a field name at all — a CTRM procedure name or composite (docs/04 §8.2). Those\r\n                  used to render below as a bolded field, which invented a field that does not exist.\r\n                -->\r\n                @for (reason of formLevelReasons(); track reason) {\r\n                  <li>{{ reason }}</li>\r\n                }\r\n\r\n                <!--\r\n                  #830: the save's refusals that are not CTRM fields, each under a name a user can read.\r\n                  The addendum ones link to the section's tab, where they are said again beside it.\r\n                -->\r\n                @for (reason of saveErrorGroups().save; track reason) {\r\n                  <li><strong>Save</strong> — {{ reason }}</li>\r\n                }\r\n                @for (reason of saveErrorGroups().lmsFlag; track reason) {\r\n                  <!-- #973: said again beside the box, in the header. -->\r\n                  <li><strong>LMS flag</strong> — {{ reason }}</li>\r\n                }\r\n                @for (reason of saveErrorGroups().addendum; track reason) {\r\n                  <li>\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                      (click)=\"goToAddendum()\"\r\n                    >\r\n                      <strong>Addendum</strong>\r\n                    </button>\r\n                    — {{ reason }}\r\n                  </li>\r\n                }\r\n                @for (reason of saveErrorGroups().remarks; track reason) {\r\n                  <li>\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                      (click)=\"goToRemarks()\"\r\n                    >\r\n                      <strong>Remarks</strong>\r\n                    </button>\r\n                    — {{ reason }}\r\n                  </li>\r\n                }\r\n                @for (reason of saveErrorGroups().documents; track reason) {\r\n                  <li>\r\n                    <strong>CTRM documents</strong> — {{ reason }} This is a system problem, not something to\r\n                    change on this screen. Try again later, and quote the reference if it persists.\r\n                  </li>\r\n                }\r\n\r\n                <!--\r\n                  🔴 Each field reason is now a BUTTON that goes to its control, and the reason is also\r\n                  on the control itself. This list used to admit, in its own words, that the field a\r\n                  reason named \"may be on a tab you are not looking at\" — which is a message the user\r\n                  has to go hunting for, barely better than none.\r\n\r\n                  ⚠ A button rather than an anchor: it switches tab AND moves focus, and the focus move\r\n                  is the half that makes it useful. An anchor would advertise an href that does only\r\n                  half the job.\r\n                -->\r\n                @for (error of mappedErrors(); track error.ctrmField) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                        (click)=\"focusField(error)\"\r\n                      >\r\n                        <strong>{{ error.label }}</strong>\r\n                      </button>\r\n                      — {{ reason }}\r\n                    </li>\r\n                  }\r\n                }\r\n\r\n                <!--\r\n                  ⚠ Refusals naming a field this screen does not render. Kept visible rather than\r\n                  dropped: CTRM validates a set that is not identical to what this layout shows, and a\r\n                  swallowed reason leaves a save that failed for no stated cause. Named by the CTRM\r\n                  field, because that is the only name we have for it.\r\n                -->\r\n                @for (error of unmappedErrors(); track error.field) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li><strong>{{ error.field }}</strong> — {{ reason }}</li>\r\n                  }\r\n                }\r\n              </ul>\r\n            </div>\r\n            <!-- #803: the server's reference, or why there is none. -->\r\n            <cms-reference-line [correlationId]=\"save().correlationId\" />\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 THE TABS, and they are ANCHORS rather than buttons.\r\n\r\n          Each tab is a real link to this same record with a different `tab` query parameter, which buys\r\n          three things a click handler would not: the tab is in the URL so a refresh keeps it and a link\r\n          to \"the shipping fields of this contract\" can be sent (docs/02 §1.3 asks this of every route);\r\n          middle-click and open-in-new-tab work; and the browser Back button walks the tabs. It is the\r\n          same reasoning the breadcrumb and Cancel already carry.\r\n\r\n          `aria-current=\"page\"` marks the active one — the correct ARIA for a set of links, where\r\n          `role=\"tab\"` would be a promise of keyboard semantics these are not implementing. Tab/Shift+Tab\r\n          moves between them because they are links, which is what a keyboard user expects of links.\r\n\r\n          ⚠ `queryParamsHandling` is deliberately NOT used. `paramsForTab` states every parameter it\r\n          keeps, so a future parameter has to be added on purpose — `merge` would silently carry\r\n          anything, including a stale `focus` from the grid.\r\n        -->\r\n        <!--\r\n          The tab row also carries view mode's \"Hide empty fields\" (2026-10-14), so the fields start\r\n          directly under the tabs. The toggle is a SIBLING of the `<nav>`, never inside it: it filters\r\n          what this tab shows and is not navigation.\r\n\r\n          🔴 **A segmented control** (2026-10-14): one shared rounded rail, only as wide as its tabs, with\r\n          the current tab a raised surface inside it. The rail replaces the underline, so the row draws\r\n          none. It never wraps: a narrow screen scrolls the rail sideways, and the focus ring is drawn\r\n          INSIDE each tab (`-outline-offset-2`) so the rail's overflow cannot clip it.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-x-4 cws:gap-y-2\">\r\n        <nav aria-label=\"Contract sections\" class=\"cws:min-w-0 cws:max-w-full\">\r\n          <ul class=\"cws:inline-flex cws:max-w-full cws:gap-0.5 cws:overflow-x-auto cws:rounded-xl cws:border cws:border-slate-200 cws:bg-slate-100 cws:p-1 cws:[scrollbar-width:thin] cws:dark:border-slate-700 cws:dark:bg-slate-800/70\">\r\n            @for (tab of tabs(); track tab.id) {\r\n              <li>\r\n                <!--\r\n                  The current tab is a raised surface (white, a hairline ring, the faintest shadow) with\r\n                  the label in Scoular blue; the others are transparent, and hovering one darkens the rail under it\r\n                  rather than lightening it, so a hovered tab never reads as the selected one.\r\n                -->\r\n                <a\r\n                  [routerLink]=\"[]\"\r\n                  [queryParams]=\"paramsForTab(tab.id)\"\r\n                  [attr.aria-current]=\"tab.current ? 'page' : null\"\r\n                  class=\"cws:flex cws:items-center cws:gap-1.5 cws:rounded-lg cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:whitespace-nowrap cws:transition-colors cws:focus-visible:outline-2 cws:focus-visible:-outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                  [class.cws:bg-white]=\"tab.current\"\r\n                  [class.cws:text-scoular-blue]=\"tab.current\"\r\n                  [class.cws:shadow-xs]=\"tab.current\"\r\n                  [class.cws:ring-1]=\"tab.current\"\r\n                  [class.cws:ring-slate-200]=\"tab.current\"\r\n                  [class.cws:dark:bg-slate-700]=\"tab.current\"\r\n                  [class.cws:dark:text-sky-300]=\"tab.current\"\r\n                  [class.cws:dark:ring-slate-600]=\"tab.current\"\r\n                  [class.cws:text-slate-600]=\"!tab.current\"\r\n                  [class.cws:hover:bg-slate-200/70]=\"!tab.current\"\r\n                  [class.cws:hover:text-slate-900]=\"!tab.current\"\r\n                  [class.cws:dark:text-slate-400]=\"!tab.current\"\r\n                  [class.cws:dark:hover:bg-slate-700/30]=\"!tab.current\"\r\n                  [class.cws:dark:hover:text-slate-100]=\"!tab.current\"\r\n                >\r\n                  {{ tab.label }}\r\n\r\n                  <!--\r\n                    🔴 How many refusals landed on this tab. Without it a save that failed on a field\r\n                    two tabs away shows an error banner and four tabs that look identical — the user\r\n                    has to open each one to find what CTRM objected to.\r\n\r\n                    ⚠ The count is in the accessible name too, not only the glyph: a screen-reader user\r\n                    gets \"Shipping Info, 2 problems\" rather than \"Shipping Info, 2\".\r\n                  -->\r\n                  @if (errorsByTab().get(tab.id); as problems) {\r\n                    <span\r\n                      class=\"scoular-badge scoular-badge-sm cws:bg-red-100 cws:text-red-800 cws:dark:bg-red-900/40 cws:dark:text-red-200\"\r\n                      [attr.aria-label]=\"problems + (problems === 1 ? ' problem' : ' problems')\"\r\n                    >\r\n                      {{ problems }}\r\n                    </span>\r\n                  }\r\n                  <!--\r\n                    The count is fields PLUS collections. The Remarks tab has no fields at all — remarks\r\n                    and notes are CTRM collections rather than `base_data` scalars — and would otherwise\r\n                    read `0` beside two populated tables. The Documents tab has no count at all (null),\r\n                    because a `0` beside it would read as \"this contract has no documents\".\r\n                  -->\r\n                  @if (tab.count) {\r\n                  <!-- Secondary to the label: smaller, normal weight, a soft fill rather than a solid one. -->\r\n                  <span\r\n                    class=\"cws:rounded-full cws:px-1.5 cws:text-xs cws:leading-5 cws:font-normal cws:tabular-nums\"\r\n                    [class.cws:bg-scoular-blue/10]=\"tab.current\"\r\n                    [class.cws:text-scoular-blue]=\"tab.current\"\r\n                    [class.cws:dark:bg-sky-400/15]=\"tab.current\"\r\n                    [class.cws:dark:text-sky-300]=\"tab.current\"\r\n                    [class.cws:bg-slate-200/70]=\"!tab.current\"\r\n                    [class.cws:text-slate-600]=\"!tab.current\"\r\n                    [class.cws:dark:bg-slate-700]=\"!tab.current\"\r\n                    [class.cws:dark:text-slate-300]=\"!tab.current\"\r\n                    [attr.aria-label]=\"tab.count + ' required'\"\r\n                    [attr.title]=\"tab.count + (tab.count === 1 ? ' required field' : ' required fields')\"\r\n                    data-testid=\"tab-required-count\"\r\n                  >\r\n                    {{ tab.count }}\r\n                  </span>\r\n                  }\r\n                </a>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </nav>\r\n\r\n        @if (!isEditable() && visibleSections().length > 0) {\r\n          <!--\r\n            \"Hide empty fields\" (2026-10-13), for READING only: the sheet drops entries with no value and\r\n            sections left with none. A display filter in `cms-contract-form`; configuration, the form and\r\n            the save are untouched, and Edit always shows every configured field.\r\n\r\n            A native checkbox with its own label: it is a two-state preference, not a command.\r\n          -->\r\n          <div class=\"cws:ml-auto cws:self-center cws:py-2\">\r\n            <label class=\"cws:inline-flex cws:cursor-pointer cws:items-center cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-400\">\r\n              <input\r\n                type=\"checkbox\"\r\n                class=\"cws:size-4 cws:accent-scoular-blue\"\r\n                [checked]=\"hideEmptyFields()\"\r\n                (change)=\"hideEmptyFields.set($any($event.target).checked)\"\r\n                data-hide-empty\r\n              />\r\n              Hide empty fields\r\n            </label>\r\n          </div>\r\n        }\r\n        </div>\r\n\r\n        <!--\r\n          🔴 THE FIELDS. One form, always mounted, showing one tab's sections.\r\n\r\n          `[visibleSections]` narrows what RENDERS. The form group is always built from the whole\r\n          configuration — see the input's own remarks. Wrapping this in `@if (activeTab() === …)` would\r\n          destroy and rebuild the component on every tab click, discarding everything typed and resetting\r\n          the `dirty` flags the save path reads. That is the trap here, and it looks like the obvious\r\n          implementation.\r\n\r\n          `[readOnly]` is the entire difference between reading a contract and editing one.\r\n\r\n          🔴 It binds `!isEditable()`, not `isView()` (F2.3c, #423). BR-002 makes the WHOLE form\r\n          read-only for an intercompany purchase, and this binding is the one place that decision\r\n          lands — bound to the mode alone, an intercompany purchase opened in edit mode rendered\r\n          fully editable and the rule existed only in the requirements.\r\n\r\n          Gated on `valuesReady()`: the form seeds ONCE in `ngOnInit`, so rendering before this\r\n          contract's values arrive builds it from nothing and never re-seeds.\r\n        -->\r\n        <!--\r\n          BR-002's read-only reason, which docs/02a §6.2 requires a banner for: \"read-only … banner\r\n          explains why\". A locked form with no explanation reads as a broken screen, and this one\r\n          cannot be unlocked from here.\r\n\r\n          ⚠ **Deliberately NOT `role=\"alert\"`.** It is a standing condition of the contract, not an\r\n          event that just happened — the same distinction the save outcome above observes in the\r\n          other direction. An alert role would interrupt a screen-reader user on arrival to announce\r\n          something that has always been true of this record.\r\n        -->\r\n        @if (intercompanyLock()) {\r\n          <div class=\"scoular-alert scoular-alert-info\">\r\n            <div class=\"scoular-alert-title\">This contract is read-only</div>\r\n            <!--\r\n              ⚠ No rule number in the copy. `user-facing-copy.spec.ts` refused \"(BR-002)\" here and\r\n              was right: a business-rule identifier names something only the development team can\r\n              act on, and the trader reading this needs to know what to do instead.\r\n            -->\r\n            <div class=\"scoular-alert-description\">\r\n              It is an intercompany purchase, and those are not editable here. The contract can\r\n              still be worked on the green screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (valuesReady()) {\r\n          <!--\r\n            🔴 `@for (… of [formKey()]; track key)` — the ONE place this screen rebuilds the form on\r\n            purpose, and it is not the tab switch.\r\n\r\n            A driver change (contract type, commodity) re-resolves the configuration, and a different\r\n            configuration is genuinely a different set of controls — so unlike tabs, this cannot be a\r\n            display filter. Re-keying rebuilds it; `watchDrivers` snapshots the dirty values first and\r\n            they come back through `[defaultValues]` marked dirty, so nothing typed is lost and the\r\n            save payload is unchanged. Keyed on the configuration's own version, so a re-resolve that\r\n            wins the same row does not churn the form.\r\n          -->\r\n          @for (key of [formKey()]; track key) {\r\n            <cms-contract-form\r\n              [config]=\"loaded.config\"\r\n              [tradeUnit]=\"loaded.tradeUnit\"\r\n              [readOnly]=\"!isEditable()\"\r\n              [visibleSections]=\"visibleSections()\"\r\n              [hideEmptyFields]=\"hideEmptyFields()\"\r\n              [fieldNotes]=\"fieldNotes()\"\r\n              [pinnedNotes]=\"pinnedNotes()\"\r\n              [emptyNotes]=\"emptyNotes\"\r\n              [sectionNotes]=\"sectionNotes\"\r\n              [wideFields]=\"wideFields\"\r\n              [halfFields]=\"halfFields()\"\r\n              [hiddenLabelFields]=\"hiddenLabelFields()\"\r\n              [groupHeadings]=\"groupHeadings\"\r\n              [fieldCtrmNames]=\"fieldCtrmNames\"\r\n              [constraints]=\"loaded.constraints ?? null\"\r\n              [readOnlyFields]=\"readOnlyFields()\"\r\n              [lockedFields]=\"lockedFields()\"\r\n              [fieldVerdicts]=\"fieldVerdicts()\"\r\n              [initialValues]=\"initialValues()\"\r\n              [defaultValues]=\"defaultValues()\"\r\n              (ready)=\"onFormReady($event)\"\r\n              (fieldBlur)=\"onFieldBlur($event)\"\r\n            />\r\n          }\r\n        } @else {\r\n          <div class=\"scoular-card cws:p-6\" role=\"status\" aria-live=\"polite\">\r\n            Loading this contract’s current values…\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          F10.3b — the Addendum section, for every special type the server lists an addendum type for\r\n          (#1043; it was a frontend list of three, which hid KA and SA).\r\n\r\n          🔴 OUTSIDE `cms-contract-form`, and that is how an addendum field is kept out of the save.\r\n          The form is the CTRM\r\n          payload; these values are CWS's and live in the section's own state, so the save path has no\r\n          control to read them from. `hasAddendumSection()` is false for every other special type, blank\r\n          included, and the section does not render at all.\r\n        -->\r\n        @if (hasAddendumSection()) {\r\n          <!--\r\n            #830: kept MOUNTED off its tab, and hidden, because Save reads the section's values and a\r\n            tab switch used to destroy them. `hidden` rather than a class, so no stylesheet can show it.\r\n            #923: its tab is the Addendum tab, which the form leaves empty, so it renders under the tabs.\r\n          -->\r\n          <div [hidden]=\"!showAddendum()\">\r\n            <cws-contract-addendum-section\r\n              [addendumType]=\"addendumType()\"\r\n              [templatesState]=\"addendumTemplatesState()\"\r\n              [typesState]=\"addendumTypesState()\"\r\n              [specialType]=\"addendumSpecialType()\"\r\n              [tradeUnit]=\"addendumTradeUnit()\"\r\n              [canEdit]=\"isEditable() && canWriteCws()\"\r\n              [previewContract]=\"addendumPreviewContract\"\r\n              [missingRequired]=\"missingRequiredLabels()\"\r\n              [saveErrors]=\"saveErrorGroups().addendum\"\r\n              [storedAddendum]=\"storedAddendum()\"\r\n              [earlierAddendums]=\"earlierAddendums()\"\r\n              [addendumListProblem]=\"addendumListProblem()\"\r\n            />\r\n            <!--\r\n              #485 (ruled 2026-10-02): the addendum is CWS-owned (ADDENDUM-ARCHITECTURE D1), so the grant\r\n              and edit mode, never the CTRM gate: a night run, a closed CTRM and a trade unit's CTRM\r\n              refusal (#411) do not stop it being edited or previewed. Saving it rides on the contract\r\n              save, which keeps its own gate.\r\n            -->\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The child collections, each on the tab whose fields describe it — ship periods with the\r\n          shipping fields, prices with the pricing fields, remarks and notes on the tab named after them.\r\n          That is what the Power App does (its `Ship Period` component is inside `Shipping Info`) and it\r\n          is what removes the long tail: nothing here sits after 111 controls any more.\r\n\r\n          ⚠ The grids themselves are UNCHANGED — same columns, sort behaviour, resizing and cell-level\r\n          Ctrl+C. Only where they appear has moved.\r\n        -->\r\n        @if (showPrices()) {\r\n          <!--\r\n            Price sequences, read-only on this aggregate — prices are written through the pricing API,\r\n            never through the contract upsert (C-8). So this stays a table in edit mode too.\r\n\r\n            ⚠ These are NOT the pricing API's price records. Known Issue 34: two CTRM routes both return\r\n            \"a price\" and disagree on names (`flat_price` vs `price`, 12 members vs 36). Do not reuse\r\n            this table's columns on the pricing screen.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Price sequences\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ contract()?.prices?.length ?? 0 }})\r\n              </span>\r\n            </h3>\r\n            @if (contract()?.prices?.length) {\r\n              <cms-data-grid\r\n                [rows]=\"sortedPrices()\"\r\n                [columns]=\"priceColumns\"\r\n                label=\"Price sequences\"\r\n                columnsKey=\"record.prices\"\r\n                [sorts]=\"priceSorts()\"\r\n                (sortChange)=\"priceSorts.set($event)\"\r\n              />\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                {{\r\n                  isCreate()\r\n                    ? 'Prices are added on the pricing screen, ' + pendingNote + '.'\r\n                    : 'This contract has no priced sequences.'\r\n                }}\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showShipPeriods()) {\r\n          <!--\r\n            Ship periods (BR-020…BR-023). Max 12, CTRM's cap.\r\n\r\n            🔴 **EDITABLE in edit mode as of F2.3b (#372).** This block carried the opposite claim —\r\n            \"read-only in EVERY mode … `ship_periods` is one of the 11 child collections the contract\r\n            upsert path does not carry, so there is nothing this screen could save\". The API's\r\n            `ContractWriteBody.Collections` does carry all seven, so the sentence was describing a\r\n            limit that had been lifted.\r\n\r\n            ⚠ Read-only still, whenever the form is: view mode, and BR-002's intercompany lock.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Ship periods\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ shipPeriodRows().length }})\r\n              </span>\r\n            </h3>\r\n\r\n            @if (isEditable()) {\r\n              <!--\r\n                The editable collection. A plain table rather than `cms-data-grid`, which renders\r\n                values and has no cell-editing affordance — and rather than a `FormArray`, which\r\n                would mean changing the shared `ContractForm` for every screen that mounts it.\r\n              -->\r\n              <table class=\"cws:w-full cws:text-left cws:text-sm\">\r\n                <caption class=\"sr-only\">Ship periods, editable</caption>\r\n                <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  <tr>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Begin</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">End</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Quantity</th>\r\n                    <!--\r\n                      #1018: CTRM's late pickup and early delivery dates, shown read-only. The save\r\n                      writes the whole collection, so each row re-sends what CTRM holds; no\r\n                      requirement asks for them to be edited here.\r\n                    -->\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Late pickup</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Early delivery</th>\r\n                    <th scope=\"col\" class=\"cws:py-1\"><span class=\"sr-only\">Actions</span></th>\r\n                  </tr>\r\n                </thead>\r\n                <tbody>\r\n                  @for (row of shipPeriodRows(); track $index) {\r\n                    <tr class=\"cws:border-t cws:border-slate-200 cws:dark:border-slate-700\">\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <!--\r\n                          BR-020 — the three entry forms CTRM accepts (`MMDDYYYY`, `MMDDYY` with a\r\n                          1930–2029 pivot, `MM/DD/YYYY`) are parsed on change by\r\n                          `parseShipPeriodDate`. A text input rather than `type=\"date\"` for exactly\r\n                          that reason: a native date picker would refuse the shorthand a trader types.\r\n                        -->\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'Begin date, period ' + ($index + 1)\"\r\n                          [value]=\"row.beginDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'beginDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'End date, period ' + ($index + 1)\"\r\n                          [value]=\"row.endDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'endDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          inputmode=\"decimal\"\r\n                          class=\"scoular-form-input cws:w-32 cws:text-right cws:tabular-nums\"\r\n                          [attr.aria-label]=\"'Quantity, period ' + ($index + 1)\"\r\n                          [value]=\"row.quantity ?? ''\"\r\n                          (change)=\"setShipPeriodQuantity($index, $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3 cws:tabular-nums\" data-testid=\"ship-period-late-pickup\">\r\n                        {{ carriedShipPeriodDate(row.latePickupDate) }}\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3 cws:tabular-nums\" data-testid=\"ship-period-early-delivery\">\r\n                        {{ carriedShipPeriodDate(row.earlyDeliveryDate) }}\r\n                      </td>\r\n                      <td class=\"cws:py-1\">\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\"\r\n                          (click)=\"removeShipPeriod($index)\"\r\n                        >\r\n                          Remove<span class=\"sr-only\"> period {{ $index + 1 }}</span>\r\n                        </button>\r\n                      </td>\r\n                    </tr>\r\n                    @if (shipPeriodIssues().get($index); as issues) {\r\n                      <tr>\r\n                        <td colspan=\"6\" class=\"cws:pb-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                          @for (issue of issues; track issue.code) {\r\n                            <span class=\"cws:mr-3\">{{ issue.message }}</span>\r\n                          }\r\n                        </td>\r\n                      </tr>\r\n                    }\r\n                  }\r\n                </tbody>\r\n              </table>\r\n\r\n              <!--\r\n                BR-022. The action DISABLES at CTRM's 12-period cap rather than silently doing\r\n                nothing — `nextShipPeriod` returns null there, which is the whole reason it does.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-sm scoular-btn-outline\"\r\n                [disabled]=\"nextShipPeriodProposal() === null\"\r\n                (click)=\"addShipPeriod()\"\r\n              >\r\n                Add period\r\n              </button>\r\n\r\n              @if (nextShipPeriodProposal() === null) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  A contract may have at most {{ maxShipPeriods }} ship periods.\r\n                </p>\r\n              }\r\n\r\n              @for (issue of shipPeriodCollectionIssues(); track issue.code) {\r\n                <p class=\"cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ issue.message }}</p>\r\n              }\r\n\r\n              <!--\r\n                BR-022's overlap test is a WARNING, not a refusal: CTRM permits overlapping periods,\r\n                so blocking the save here would invent a rule the system of record does not have.\r\n              -->\r\n              @if (shipPeriodsOverlap()) {\r\n                <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-300\">\r\n                  Two periods overlap. CTRM allows this — check it is what you meant.\r\n                </p>\r\n              }\r\n            } @else if (shipPeriodRows().length) {\r\n              <!--\r\n                No \"sorted within this page\" caveat here, unlike the contract grid: this collection\r\n                arrives whole (CTRM caps ship periods at 12), so the sort covers every row there is.\r\n              -->\r\n              <cms-data-grid\r\n                [rows]=\"sortedShipPeriods()\"\r\n                [columns]=\"shipPeriodColumns\"\r\n                label=\"Ship periods\"\r\n                columnsKey=\"record.ship-periods\"\r\n                [sorts]=\"shipPeriodSorts()\"\r\n                (sortChange)=\"shipPeriodSorts.set($event)\"\r\n              />\r\n\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                This contract has no ship periods. That is valid — CTRM neither requires shipment\r\n                dates nor supplies a default for them.\r\n              </p>\r\n            }\r\n\r\n            <!--\r\n              BR-021 — the running Σ against the contract quantity (#371, 02a §6.2).\r\n\r\n              🔴 **Outside the read-only branch as of F2.3b.** It used to sit inside the grid's `@if`,\r\n              so it rendered only where the periods could not be changed — and disappeared in edit\r\n              mode, which is the only mode in which a user can unbalance it. A gate that hides itself\r\n              exactly when it becomes reachable is worse than not having one.\r\n\r\n              Pinned under the collection rather than beside the Quantity field, because it is a\r\n              statement about the collection. It states the DELTA, not merely that something is\r\n              wrong: a gate that blocks without saying by how much leaves the user to redo arithmetic\r\n              the screen has already done.\r\n\r\n              `role=\"status\"` so a screen reader hears the total resolve as the quantity is typed,\r\n              rather than discovering it on pressing Save.\r\n            -->\r\n            @if (shipPeriodReconciliation(); as reconciliation) {\r\n              <p\r\n                data-testid=\"ship-period-reconciliation\"\r\n                role=\"status\"\r\n                class=\"cws:rounded-md cws:border cws:px-3 cws:py-2 cws:text-sm\"\r\n                [class.cws:border-emerald-300]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:bg-emerald-50]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:text-emerald-900]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:border-red-300]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:bg-red-50]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:text-red-900]=\"shipPeriodGateBlocks()\"\r\n              >\r\n                {{ reconciliation.summary }}\r\n                @if (shipPeriodGateBlocks()) {\r\n                  <span class=\"cws:block cws:font-medium\">\r\n                    CTRM requires the shipment periods to sum to the contract quantity, so this\r\n                    cannot be saved until they match.\r\n                  </span>\r\n                }\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showRemarks()) {\r\n          <!--\r\n            The Remarks tab carries no FIELDS — remarks and notes are CTRM collections (`RmkDS`,\r\n            `NoteDS`), not `base_data` scalars. #789: in edit and create, remarks are edited here as the\r\n            whole collection (C-19's 11 types). #912: CTRM's notes listed here are contract text\r\n            (#907); the Log tab's Add Note keeps CWS's own log and never writes them, so this no longer\r\n            points there.\r\n          -->\r\n          @if (isView()) {\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-description\">\r\n                Edit the contract to change its remarks.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          <!--\r\n            #907: the contract text, CTRM's CNTTX notes for the contract's archetype, over the proposed\r\n            GET /contracts/{n}/contract-text. Absent while the server does not offer it (today), with no\r\n            banner. Saved with the contract, as the notes collection with the edits applied.\r\n          -->\r\n          @if (contractText(); as answer) {\r\n            <div class=\"cws:mb-4\">\r\n              <cws-contract-text-section\r\n                [answer]=\"answer\"\r\n                [values]=\"contractTextValues()\"\r\n                [editing]=\"isEditable() && canWrite()\"\r\n                [locked]=\"contractTextLocked()\"\r\n                [refusal]=\"contractTextRefusalMessage()\"\r\n                [reconfirms]=\"contractTextReconfirms()\"\r\n                (textChange)=\"setContractText($event)\"\r\n              />\r\n            </div>\r\n          } @else if (contractTextFailure(); as failure) {\r\n            <p class=\"cws:mb-4 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"contract-text-failed\">\r\n              {{ failure }}\r\n            </p>\r\n          }\r\n\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- Remarks (BR-030, C-19). 11 types, 72 characters each. -->\r\n            @if (!isView()) {\r\n              <!--\r\n                #789: the editor. One row per CTRM type, in the Power App's order. The whole collection\r\n                is sent, packed, and only when a remark changed (both are full replaces). #1006: which\r\n                types are shown and required comes from the configuration (#1022); without it, all 11\r\n                are shown and none is required.\r\n              -->\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n                data-testid=\"remarks-editor\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Remarks</h3>\r\n\r\n                @if (remarksUnread()) {\r\n                  <!--\r\n                    🔴 THE REFUSAL THAT PREVENTS DATA LOSS (#788). CTRM failed to read the remarks, so the\r\n                    empty list proves nothing, and saving remarks replaces the whole collection.\r\n                  -->\r\n                  <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\" data-testid=\"remarks-unread\">\r\n                    This contract's remarks could not be read, so they cannot be edited safely — saving\r\n                    them would replace the remarks CTRM still holds. Reload the contract to try again.\r\n                  </p>\r\n                }\r\n\r\n                <div class=\"cws:mt-3 cws:grid cws:grid-cols-1 cws:gap-3\">\r\n                  <!--\r\n                    #1006: the types the configuration offers (a hidden type's stored remark still goes\r\n                    back in the write), each marked and held when the configuration requires it. The\r\n                    input's id is its summary key, `remarks.<code>`, so a summary line can focus it.\r\n                  -->\r\n                  @for (type of remarkTypes(); track type.code) {\r\n                    <div class=\"cws:space-y-1\">\r\n                      <label class=\"cws:block cws:space-y-1\">\r\n                        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">{{ type.label }}</span>\r\n                        @if (remarkRequired(type.code)) {\r\n                          <span class=\"cws:ml-0.5 cws:text-xs cws:text-red-700\" aria-hidden=\"true\">*</span>\r\n                        }\r\n                        <input\r\n                          class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n                          [id]=\"remarkKey(type.code)\"\r\n                          [attr.name]=\"'remark-' + type.code\"\r\n                          [attr.maxlength]=\"remarkMaxLength\"\r\n                          [attr.aria-describedby]=\"'remark-' + type.code + '-count' + (remarkMessage(type.code) === null ? '' : ' remark-' + type.code + '-error')\"\r\n                          [attr.aria-required]=\"remarkRequired(type.code) ? 'true' : null\"\r\n                          [attr.aria-invalid]=\"remarkMessage(type.code) === null ? null : 'true'\"\r\n                          [value]=\"remarkOf(type.code)\"\r\n                          [disabled]=\"!canEditRemarks()\"\r\n                          (input)=\"setRemark(type.code, $any($event.target).value)\"\r\n                          (blur)=\"touchRemark(type.code)\"\r\n                        />\r\n                      </label>\r\n                      @if (remarkMessage(type.code); as message) {\r\n                        <span [id]=\"'remark-' + type.code + '-error'\" class=\"cws:block cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ message }}</span>\r\n                      }\r\n                      <!-- Outside the label, so the field's name is the type alone; read out as its description. -->\r\n                      <span [id]=\"'remark-' + type.code + '-count'\" class=\"cws:block cws:text-right cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        {{ remarkMaxLength - remarkOf(type.code).length }} characters remaining\r\n                      </span>\r\n                    </div>\r\n                  }\r\n                </div>\r\n\r\n                @if (saveErrorGroups().remarks.length > 0) {\r\n                  <ul class=\"cws:mt-3 cws:list-disc cws:space-y-1 cws:rounded cws:bg-rose-50 cws:py-2 cws:pr-3 cws:pl-6 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"remarks-save-errors\">\r\n                    @for (reason of saveErrorGroups().remarks; track reason) {\r\n                      <li>{{ reason }}</li>\r\n                    }\r\n                  </ul>\r\n                }\r\n              </div>\r\n            } @else {\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Remarks\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.remarks?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.remarks?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-2\">\r\n                  @for (remark of contract()?.remarks ?? []; track remark.order) {\r\n                    <li class=\"cws:flex cws:gap-3 cws:text-sm\">\r\n                      <!--\r\n                        The number is CMS's, not CTRM's — RmkDS has no sequence subfield, so it is array\r\n                        position. Muted rather than labelled \"seq\" so it is not mistaken for a CTRM id.\r\n                      -->\r\n                      <span\r\n                        class=\"cws:w-5 cws:shrink-0 cws:text-right cws:tabular-nums cws:text-slate-500 cws:dark:text-slate-400\"\r\n                        title=\"Position in CTRM’s array — not a CTRM sequence number\"\r\n                      >\r\n                        {{ remark.order }}\r\n                      </span>\r\n                      <span class=\"cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        @if (remark.type) {\r\n                          <span class=\"cws:mr-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            [{{ remark.type }}]\r\n                          </span>\r\n                        }\r\n                        {{ remark.text }}\r\n                      </span>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Remarks are ' + pendingNote + '.' : 'No remarks.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n            }\r\n\r\n            <!--\r\n              Notes. `whitespace-pre-line` because a note runs to 32 000 characters and will contain its\r\n              own line breaks — collapsing them would turn a structured note into one unreadable\r\n              paragraph.\r\n            -->\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Notes\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.notes?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.notes?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (note of contract()?.notes ?? []; track note.order) {\r\n                    <li class=\"cws:text-sm\">\r\n                      @if (note.prefix || note.code) {\r\n                        <div class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          {{ note.prefix }}{{ note.prefix && note.code ? ' · ' : '' }}{{ note.code }}\r\n                        </div>\r\n                      }\r\n                      <p class=\"cws:whitespace-pre-line cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        {{ note.text }}\r\n                      </p>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Notes are ' + pendingNote + '.' : 'No notes.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (showDocuments()) {\r\n          <!--\r\n            F10.2 — the Documents tab. It reads its own list and content, so the record's own reads are\r\n            untouched by it, and it is appended by this screen rather than configured (see DOCUMENTS_TAB).\r\n          -->\r\n          <!-- One stacked column, spaced like every other block (JFrisbie, 2026-10-23). -->\r\n          <div class=\"cws:flex cws:flex-col cws:gap-4\">\r\n          <cws-contract-documents-tab [contractNumber]=\"contractNumber()\" />\r\n\r\n          @if (attachmentsOffered) {\r\n            <!--\r\n              #915 / F10.6 — CWS's own attachments, a sibling of CTRM's set above rather than inside it,\r\n              so the Documents tab component is unchanged. Each write is its own contract update.\r\n            -->\r\n            <cws-contract-attachments\r\n              [contractNumber]=\"contractNumber()\"\r\n              [canWrite]=\"canWriteAttachments()\"\r\n              [caraWarning]=\"attachmentsCaraWarning()\"\r\n              [announcesSaves]=\"false\"\r\n              (saved)=\"onAttachmentSaved($event)\"\r\n            />\r\n          }\r\n          </div>\r\n        }\r\n\r\n        @if (isCreate() && attachmentsOffered) {\r\n          <!--\r\n            #915 / F10.6 — on a create there is no Documents tab, so the files to send with the first\r\n            Save are picked here, on every tab. Nothing is sent until Save.\r\n          -->\r\n          <cws-contract-attachments\r\n            [contractNumber]=\"null\"\r\n            [canWrite]=\"canPickCreateAttachments()\"\r\n            [saveErrors]=\"saveErrorGroups().attachments\"\r\n            (pendingChange)=\"pendingAttachments.set($event)\"\r\n          />\r\n        }\r\n\r\n        @if (showLog()) {\r\n          <!--\r\n            F3.7 — the Log tab: what happened to this contract, a note to add to it, and a message to\r\n            its trader. It carries no form fields, which is why it is appended by this screen rather\r\n            than coming from the resolved configuration (see `LOG_TAB`).\r\n          -->\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- The timeline. Absent where the host offered no audit backend. -->\r\n            @if (logAvailable()) {\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">History</h3>\r\n\r\n              @if (configAuditFailed()) {\r\n                <!--\r\n                  #458: the contract's own entries still list; this says the configuration half is\r\n                  missing, so \"the form never changed\" is not read into its absence.\r\n                -->\r\n                <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n                  Form-configuration changes could not be read, so only the contract's own changes are\r\n                  listed.\r\n                </p>\r\n              }\r\n\r\n              @if (logNotesFailed()) {\r\n                <!-- #912: the history still says a note was added; this says its words are missing. -->\r\n                <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n                  The notes on this contract could not be read, so a note added is listed without its words.\r\n                </p>\r\n              }\r\n\r\n              @if (timelineState() === 'loading') {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Loading the history…</p>\r\n              } @else if (timelineState() === 'error') {\r\n                <!--\r\n                  🔴 An unreadable history and an empty one must not look the same. \"Nothing has\r\n                  happened to this contract\" is a claim, and this screen cannot make it here.\r\n                -->\r\n                <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\r\n                  The history for this contract could not be loaded, so what is shown may be\r\n                  incomplete.\r\n                </p>\r\n              } @else if (timeline().length === 0) {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  Nothing has been recorded against this contract yet.\r\n                </p>\r\n              } @else {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (row of timeline(); track row.key) {\r\n                    <li class=\"cws:border-l-2 cws:pl-3\"\r\n                        [class.cws:border-slate-300]=\"row.kind !== 'configuration'\"\r\n                        [class.cws:border-amber-400]=\"row.kind === 'configuration'\">\r\n                      <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\">\r\n                        {{ row.what }}\r\n                        @if (row.kind === 'configuration') {\r\n                          <!-- Distinguishable, so a configuration edit is never read as a contract change. -->\r\n                          <span\r\n                            class=\"cws:ml-1 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\r\n                          >Configuration</span>\r\n                        }\r\n                      </p>\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        <!-- #567: the reader's local time; the exact instant stays in `datetime`. -->\r\n                        {{ row.actor || 'Unattributed' }} · <time [attr.datetime]=\"row.at\">{{ row.atLabel }}</time>\r\n                      </p>\r\n                      @if (row.text !== null) {\r\n                        <!-- #912: a log note's words, line breaks kept, as the server stored them. -->\r\n                        <p data-testid=\"log-note-text\" class=\"cws:mt-1 cws:whitespace-pre-line cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">{{ row.text }}</p>\r\n                      }\r\n                      <!--\r\n                        #567: what the write changed, from the entry's detailsJson. Rendered only when\r\n                        it parses and names something, so every other entry reads exactly as before.\r\n                      -->\r\n                      @if (row.changes.length > 0 || row.collectionsReplaced.length > 0) {\r\n                        <dl class=\"cws:mt-1 cws:space-y-0.5 cws:text-xs cws:text-slate-700 cws:dark:text-slate-300\">\r\n                          @for (change of row.changes; track $index) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">{{ change.label }}</dt>\r\n                              <dd>\r\n                                <span>{{ change.from ?? '(empty)' }}</span>\r\n                                <span aria-hidden=\"true\"> → </span>\r\n                                <span class=\"cws:sr-only\"> changed to </span>\r\n                                <span>{{ change.to ?? '(empty)' }}</span>\r\n                              </dd>\r\n                            </div>\r\n                          }\r\n                          @if (row.collectionsReplaced.length > 0) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">Replaced whole</dt>\r\n                              <dd>{{ row.collectionsReplaced.join(', ') }}</dd>\r\n                            </div>\r\n                          }\r\n                        </dl>\r\n                      }\r\n                      <!-- #915: attachment changes, by document id and type. The audit holds no file name. -->\r\n                      @if (row.attachments.length > 0) {\r\n                        <dl class=\"cws:mt-1 cws:text-xs cws:text-slate-700 cws:dark:text-slate-300\" data-testid=\"log-attachments\">\r\n                          <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                            <dt class=\"cws:font-medium\">Attachments</dt>\r\n                            <dd>{{ row.attachments.join('; ') }}</dd>\r\n                          </div>\r\n                        </dl>\r\n                      }\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              }\r\n            </div>\r\n\r\n            }\r\n\r\n            <div class=\"cws:space-y-4\">\r\n              <!--\r\n                Add Note (#912): CWS's own log, over the log backend's notes route. Never CTRM's notes\r\n                collection, which is contract text (#907). A log source without the route offers none.\r\n              -->\r\n              @if (logAvailable() && canKeepLogNotes) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Add a note</h3>\r\n\r\n                <!--\r\n                  #912: the #331 refusal (\"the existing notes could not be read\") is gone. It guarded a\r\n                  write that replaced CTRM's notes whole; a log note replaces nothing.\r\n                -->\r\n                @if (!canWriteLogNote()) {\r\n                  <!--\r\n                    #912: the grant, then the trade unit's onboarding. Not CTRM's availability: nothing\r\n                    is written to CTRM, so a night run does not stop a note.\r\n                  -->\r\n                  <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    @if (!canWriteCws()) {\r\n                      Adding a note needs the <strong>Admin</strong> role on this application.\r\n                    } @else {\r\n                      {{ writeRefusal()?.message }}\r\n                    }\r\n                  </p>\r\n                } @else {\r\n                  <label class=\"cws:mt-2 cws:block\">\r\n                    <span class=\"sr-only\">Note</span>\r\n                    <textarea\r\n                      rows=\"4\"\r\n                      class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      [value]=\"noteText()\"\r\n                      (input)=\"onNoteInput($any($event.target).value)\"\r\n                    ></textarea>\r\n                  </label>\r\n\r\n                  @if (noteRefusal(); as refusal) {\r\n                    <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ refusal }}</p>\r\n                  } @else {\r\n                    <!-- The budget at the control, not only a refusal at save. -->\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      {{ noteBytesRemaining() }} characters remaining\r\n                    </p>\r\n                  }\r\n\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-primary cws:mt-2\"\r\n                    [disabled]=\"!canAddNote()\"\r\n                    (click)=\"onAddNote()\"\r\n                  >\r\n                    @if (noteState().status === 'saving') { Saving… } @else { Add note }\r\n                  </button>\r\n\r\n                  <!-- #803: the last Add note, with the server's reference on a failure. -->\r\n                  <div class=\"cws:mt-1\" data-testid=\"note-outcome\">\r\n                    <cms-status-message [outcome]=\"noteOutcome()\" (dismissed)=\"noteOutcome.set(null)\" />\r\n                  </div>\r\n                }\r\n              </div>\r\n\r\n              }\r\n\r\n              <!-- Save as template (F3.3). -->\r\n              @if (canUseTemplates() && !isCreate()) {\r\n                <div\r\n                  class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n                >\r\n                  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    Save as a template\r\n                  </h3>\r\n\r\n                  <!-- #485: CWS SQL, so permissions only; the CTRM availability gate does not apply. -->\r\n                  @if (!canWriteCws()) {\r\n                    <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      Saving a template needs the <strong>Admin</strong> role on this application.\r\n                    </p>\r\n                  } @else {\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      <!--\r\n                        Says what is captured and what the server removes, because a user who does not\r\n                        know the exclusions exist will expect the template to reproduce the contract\r\n                        exactly and will read the difference as a defect.\r\n                      -->\r\n                      Captures every writable field on this contract as it stands. Fields excluded from\r\n                      copying are removed when the template is read back.\r\n                    </p>\r\n\r\n                    <label class=\"cws:mt-2 cws:block\">\r\n                      <span class=\"sr-only\">Template name</span>\r\n                      <input\r\n                        type=\"text\"\r\n                        class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                        placeholder=\"Template name\"\r\n                        [value]=\"templateName()\"\r\n                        (input)=\"onTemplateNameInput($any($event.target).value)\"\r\n                      />\r\n                    </label>\r\n\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                      [disabled]=\"!canSaveTemplate()\"\r\n                      (click)=\"onSaveTemplate()\"\r\n                    >\r\n                      @if (templateState().status === 'saving') { Saving… } @else { Save as template }\r\n                    </button>\r\n\r\n                    <!-- #803: the last template save or delete, with the server's reference on a failure. -->\r\n                    <div class=\"cws:mt-1\" data-testid=\"template-outcome\">\r\n                      <cms-status-message [outcome]=\"templateOutcome()\" (dismissed)=\"templateOutcome.set(null)\" />\r\n                    </div>\r\n\r\n                    <!--\r\n                      #457 — the trade unit's templates, each deletable. Deleting confirms first: it\r\n                      cannot be undone, and a template is shared by everyone in the trade unit.\r\n                    -->\r\n                    @if (availableTemplates().length > 0) {\r\n                      <h4 class=\"cws:mt-4 cws:text-xs cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n                        This trade unit's templates\r\n                      </h4>\r\n                      <ul class=\"cws:mt-1 cws:space-y-1\">\r\n                        @for (template of availableTemplates(); track template.id) {\r\n                          <li class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-sm cws:text-slate-800 cws:dark:text-slate-100\">\r\n                            <span>{{ template.name }}</span>\r\n                            <button\r\n                              type=\"button\"\r\n                              class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\r\n                              (click)=\"onDeleteTemplate(template)\"\r\n                            >\r\n                              Delete<span class=\"sr-only\"> template {{ template.name }}</span>\r\n                            </button>\r\n                          </li>\r\n                        }\r\n                      </ul>\r\n                    }\r\n\r\n                  }\r\n                </div>\r\n              }\r\n\r\n              <!-- Notify Trader. Needs the log backend, which owns the route. -->\r\n              @if (logAvailable()) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Notify the trader</h3>\r\n\r\n                @if (mayNotify() === false) {\r\n                  <!--\r\n                    #865: the server's rule since #847, said before the user writes a message it would\r\n                    refuse. Any permission in the contract's trade unit is enough.\r\n                  -->\r\n                  <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"notify-not-allowed\">\r\n                    Notifying the trader needs a permission in this contract’s trade unit.\r\n                  </p>\r\n                }\r\n\r\n                <!--\r\n                  #458 — who receives it, as ruled on #513: the contract's trader by default, plus\r\n                  anyone on our domain, checked here before the server refuses it.\r\n                -->\r\n                <div class=\"cws:mt-2 cws:space-y-1\">\r\n                  <p class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">To</p>\r\n\r\n                  @if (recipients().length > 0) {\r\n                    <ul class=\"cws:flex cws:flex-wrap cws:gap-1\" aria-label=\"Recipients\">\r\n                      @for (address of recipients(); track address) {\r\n                        <li class=\"cws:flex cws:items-center cws:gap-1 cws:rounded cws:bg-slate-100 cws:px-2 cws:py-0.5 cws:text-xs cws:text-slate-800 cws:dark:bg-slate-700 cws:dark:text-slate-100\">\r\n                          {{ address }}\r\n                          <button\r\n                            type=\"button\"\r\n                            class=\"cws:text-slate-500 cws:hover:text-slate-900 cws:dark:text-slate-400 cws:dark:hover:text-white\"\r\n                            (click)=\"removeRecipient(address)\"\r\n                          >\r\n                            <span aria-hidden=\"true\">×</span><span class=\"sr-only\">Remove {{ address }}</span>\r\n                          </button>\r\n                        </li>\r\n                      }\r\n                    </ul>\r\n                  }\r\n\r\n                  @if (unresolvedTrader(); as initials) {\r\n                    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      The contract's trader ({{ initials }}) cannot be added automatically yet. Add their\r\n                      address below.\r\n                    </p>\r\n                  }\r\n\r\n                  <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n                    <label class=\"cws:flex-1\">\r\n                      <span class=\"sr-only\">Add a recipient on our domain</span>\r\n                      <input\r\n                        type=\"email\"\r\n                        name=\"notifyRecipient\"\r\n                        class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                        placeholder=\"name@scoular.com\"\r\n                        [value]=\"recipientDraft()\"\r\n                        [attr.aria-invalid]=\"recipientError() !== null ? 'true' : null\"\r\n                        [attr.aria-describedby]=\"recipientError() !== null ? 'notify-recipient-error' : null\"\r\n                        (input)=\"onRecipientInput($any($event.target).value)\"\r\n                        (keydown.enter)=\"addRecipient()\"\r\n                      />\r\n                    </label>\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"addRecipient()\">\r\n                      Add recipient\r\n                    </button>\r\n                  </div>\r\n\r\n                  @if (recipientError(); as message) {\r\n                    <p id=\"notify-recipient-error\" class=\"cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ message }}</p>\r\n                  }\r\n                </div>\r\n\r\n                <label class=\"cws:mt-2 cws:block\">\r\n                  <span class=\"sr-only\">Message to the trader</span>\r\n                  <textarea\r\n                    rows=\"3\"\r\n                    class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                    [value]=\"notifyText()\"\r\n                    (input)=\"onNotifyInput($any($event.target).value)\"\r\n                  ></textarea>\r\n                </label>\r\n\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                  [disabled]=\"!canNotify()\"\r\n                  (click)=\"onNotifyTrader()\"\r\n                >\r\n                  @if (notifyState().status === 'sending') { Sending… } @else { Notify trader }\r\n                </button>\r\n\r\n                <!--\r\n                  #803: the last Notify trader. 🔴 \"Accepted\", never \"sent\": the route answers 202,\r\n                  which on this estate says the request was taken and nothing about whether it\r\n                  reached anybody. A failure carries the server's reference.\r\n                -->\r\n                <div class=\"cws:mt-1\" data-testid=\"notify-outcome\">\r\n                  <cms-status-message [outcome]=\"notifyOutcome()\" (dismissed)=\"notifyOutcome.set(null)\" />\r\n                </div>\r\n              </div>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n      </div>\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		addendumSection: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => ContractAddendumSectionComponent), { isSignal: true }]
		}],
		summaryPanel: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => ValidationSummaryComponent), { isSignal: true }]
		}],
		onBeforeUnload: [{
			type: HostListener,
			args: ["window:beforeunload", ["$event"]]
		}],
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	}
});
const ADVANCE_STOPS = [
	"input:not([type=\"hidden\"])",
	"select",
	"textarea",
	"[role=\"switch\"]"
].map((selector) => `[data-section] ${selector}:not([disabled]):not([tabindex="-1"])`).join(", ");
function advancesOnEnter(event) {
	const target = event.target;
	if (event.shiftKey || !(target instanceof HTMLElement) || target.closest("[data-section]") === null) return false;
	if (target.tagName !== "INPUT" && target.tagName !== "SELECT") return false;
	if ([
		"button",
		"checkbox",
		"radio",
		"reset",
		"submit",
		"image",
		"file"
	].includes(target.type)) return false;
	return !(target.getAttribute("role") === "combobox" && target.getAttribute("aria-expanded") === "true");
}
const DRIVER_COMPONENTS = [["TextCode", "textClass"], ["CommodityCode", "commodity"]];
function DIMENSION_LABELS(dimension) {
	switch (dimension) {
		case "contractTypeClass": return "contract type";
		case "locationCode": return "this trade unit";
		case "commodityCode": return "this commodity";
		default: return dimension;
	}
}
function readProblem(error) {
	const problem = problemFrom(error);
	const failure = writeOutcomeOf(problem);
	if (failure !== "refused") {
		const named = problem.type === CtrmWriteProblemType.NotApplied || problem.type === CtrmWriteProblemType.OutcomeUnknown;
		return {
			fieldErrors: {},
			formErrors: [],
			failure,
			correlationId: problem.traceId,
			lostDetail: named ? problem.detail : null
		};
	}
	const saidSomething = problem.formErrors.length > 0 || Object.keys(problem.errors).length > 0;
	return {
		failure,
		correlationId: problem.traceId,
		fieldErrors: problem.errors,
		formErrors: saidSomething ? problem.formErrors : ["The save was refused and no reason was given."]
	};
}
const NOTIFY_TRADER_DELIVERED_MESSAGE = "The email was handed to the mail service. That is not confirmation that it arrived.";
const NOTIFY_TRADER_RECORDED_MESSAGE = "The message was recorded on this contract’s log and was NOT sent: email is not switched on in this environment.";
const NOTIFY_TRADER_ACCEPTED_MESSAGE = "The message was accepted for sending. Acceptance is not confirmation that it arrived.";
function notifyMessageFor(delivered) {
	return delivered === true ? NOTIFY_TRADER_DELIVERED_MESSAGE : delivered === false ? NOTIFY_TRADER_RECORDED_MESSAGE : NOTIFY_TRADER_ACCEPTED_MESSAGE;
}
function stateFailureOf(action, problem) {
	const verb = action === "close" ? "closed" : "re-opened";
	const outcome = writeOutcomeOf(problem);
	const said = problem.type === CtrmWriteProblemType.NotApplied || problem.type === CtrmWriteProblemType.OutcomeUnknown ? problem.detail : null;
	if (outcome === "outcome-unknown") return `${said ?? `The answer was lost, so it is not known whether this contract was ${verb}.`} Reload the contract to see what CTRM holds before trying again.`;
	if (outcome === "not-applied") return `${said ?? `CTRM’s answer could not be used, and reading the contract back shows it was not ${verb}.`} It has not changed, and it is safe to try again.`;
	return action === "close" ? "This contract could not be closed, and it has not changed. Try again, or ask someone who can check CTRM." : "This contract could not be re-opened, and it has not changed. Try again, or ask someone who can check CTRM.";
}
const LOG_NOTE_ADDED_MESSAGE = "Note added.";
function logNoteFailureOf(problem) {
	const reasons = [...Object.values(problem.errors).flat(), ...problem.formErrors];
	if (problem.status === 400 || problem.status === 422) return reasons.length > 0 ? `That note was not added: ${reasons.join(" ")}` : "That note was not added: the server refused it and gave no reason.";
	if (problem.status === 403) return problem.detail ?? "That note was not added: adding a note needs permission to update contracts in this contract’s trade unit, and the trade unit must be onboarded.";
	if (problem.status === 404) return problem.type === "contract-not-found" ? problem.detail ?? "That note was not added: there is no such contract." : "That note was not added: this server does not keep notes yet.";
	if (writeOutcomeOf(problem) === "refused") return problem.detail ?? problem.title ?? "That note was not added.";
	return "The answer was lost, so it is not known whether the note was added. The history is read again; check it before adding the note again.";
}
function newestFirst(left, right) {
	const a = Date.parse(left);
	const b = Date.parse(right);
	return Number.isNaN(a) || Number.isNaN(b) ? right.localeCompare(left) : b - a;
}
const NOTIFY_REQUESTED_MESSAGE = "The trader will be emailed if this contract needs approval.";
const NOTIFY_UNKNOWN_MESSAGE = "CTRM’s answer could not be used and the save was confirmed by reading the contract back, so whether the trader was emailed is not known.";
const NOTIFY_NOT_SENT_MESSAGE = "Nothing had changed, so nothing was sent to CTRM and the trader was not emailed.";
const LMS_WARNING_MESSAGE = "CTRM asks you to verify whether or not this is an LMS contract.";
const LMS_FLAG_UNKNOWN_MESSAGE = "The LMS flag cannot be shown right now, because CTRM could not read this contract’s notes. Try again later.";
const LMS_FLAG_NONE = {
	state: "none",
	editable: true
};
const LMS_FLAG_UNKNOWN = {
	state: "unknown",
	editable: false
};
const NOTIFY_FAILED_MESSAGE = "The contract was saved, but CTRM could not notify the trader. Tell the trader directly.";
const ADDENDUM_STORED_MESSAGE = "A new addendum document was stored and sent to CTRM, so the contract goes back for approval and signature.";
const ADDENDUM_REUSED_MESSAGE = "The addendum’s text did not change, so no new document was issued.";
const ADDENDUM_WITHDRAWN_MESSAGE = "The addendum was withdrawn, because this special type takes none.";
function savedSentence(action, contractNumber, copiedFrom = null) {
	switch (action) {
		case "Created": return copiedFrom === null || copiedFrom === "" ? `Contract ${contractNumber} created.` : `Contract ${contractNumber} created as a copy of ${copiedFrom}.`;
		case "Unchanged": return `No changes to save on contract ${contractNumber}.`;
		default: return `Contract ${contractNumber} updated.`;
	}
}
function addendumNotice(result, carried) {
	switch (result.addendum?.action) {
		case "Stored": return {
			text: ADDENDUM_STORED_MESSAGE,
			stays: false
		};
		case "Withdrawn": return {
			text: ADDENDUM_WITHDRAWN_MESSAGE,
			stays: false
		};
		case "Reused": return carried ? {
			text: ADDENDUM_REUSED_MESSAGE,
			stays: false
		} : null;
		default: return null;
	}
}
function combinedNotice(...notices) {
	const present = notices.filter((notice) => notice !== null);
	return present.length === 0 ? null : {
		text: present.map((notice) => notice.text).join(" "),
		stays: present.some((notice) => notice.stays)
	};
}
function notificationNotice(result) {
	switch (result.notification) {
		case "Requested": return {
			text: result.confirmedByReadBack === true ? NOTIFY_UNKNOWN_MESSAGE : NOTIFY_REQUESTED_MESSAGE,
			stays: false
		};
		case "NotSent": return {
			text: NOTIFY_NOT_SENT_MESSAGE,
			stays: false
		};
		case "Failed": return {
			text: NOTIFY_FAILED_MESSAGE,
			stays: true
		};
		default: return null;
	}
}
function lmsWarningNotice(result) {
	return (result.warnings ?? []).some((warning) => /verify whether or not this is an? LMS contract/i.test(warning)) ? {
		text: LMS_WARNING_MESSAGE,
		stays: true
	} : null;
}
function readableTimestamp(at) {
	const parsed = new Date(at);
	return Number.isNaN(parsed.getTime()) ? at : parsed.toLocaleString(void 0, {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
}
const JOURNEY_PARAMS = [
	"copyFrom",
	"withPricing",
	RECORD_ORIGIN_PARAM,
	"returnTo",
	"tradeUnit",
	"customer",
	"template"
];
function linkParam(route, name) {
	const value = route.snapshot.queryParamMap.get(name)?.trim() ?? "";
	return value === "" ? null : value;
}
function todayIso() {
	const now = /* @__PURE__ */ new Date();
	const month = `${now.getMonth() + 1}`.padStart(2, "0");
	const day = `${now.getDate()}`.padStart(2, "0");
	return `${now.getFullYear()}-${month}-${day}`;
}
function isBlankValue(value) {
	return value === null || value === void 0 || typeof value === "string" && value.trim() === "";
}
function comparableText(value) {
	return value === null || value === void 0 ? "" : String(value).trim();
}
function overallShipPeriod(rows) {
	const begins = rows.map((row) => row.beginDate).filter((date) => date !== null);
	const ends = rows.map((row) => row.endDate).filter((date) => date !== null);
	return {
		beginDate: begins.length === 0 ? null : begins.reduce((a, b) => a < b ? a : b),
		endDate: ends.length === 0 ? null : ends.reduce((a, b) => a > b ? a : b),
		quantity: null
	};
}
function sameShipPeriods(left, right) {
	return left.length === right.length && left.every((row, index) => sameShipPeriod(row, right[index]));
}
function sameShipPeriod(left, right) {
	return left.beginDate === right.beginDate && left.endDate === right.endDate && left.quantity === right.quantity && (left.latePickupDate ?? null) === (right.latePickupDate ?? null) && (left.earlyDeliveryDate ?? null) === (right.earlyDeliveryDate ?? null);
}
const CASCADE_COMPONENTS = {
	priceType: "PriceTypeCode",
	priceMarketCode: "PriceMarketCode",
	priceMarketMonth: "BasisMarketMonth",
	hedgeMarketCode: "HedgeMarketCode",
	hedgeMarketMonth: "HedgeMarketMonth"
};
const EMPTY_CASCADE = {
	priceMarketCode: null,
	priceMarketMonth: null,
	hedgeMarketCode: null,
	hedgeMarketMonth: null,
	derived: [],
	pricesForbidden: false,
	requirementRedirect: null
};
const HEDGE_MONTH_SOURCE_MESSAGES = {
	priceMarketCode: "A hedge price needs a price market code. CTRM sets the hedge market month from it.",
	priceMarketMonth: "A hedge price needs a basis market month. CTRM sets the hedge market month from it."
};
const REQUIREMENT_REDIRECT_SOURCE = "market-cascade";
function readPrice(value) {
	return typeof value === "number" || typeof value === "string" ? value : null;
}
const DRAFT_DEBOUNCE_MS = 500;
const TYPED_NUMBER_KEY_PARTS = [
	"ContractPrefixType",
	"ContractPrefixCommodity",
	"ContractNumber",
	"ContractSuffix"
];
function sameRefusedValue(current, refused) {
	const normalise = (value) => {
		const text = typeof value === "string" ? value.trim() : value;
		return text === "" || text === void 0 ? null : text;
	};
	return Object.is(normalise(current), normalise(refused));
}
const NO_VERDICTS = {};
const TYPED_NUMBER_PAUSE_MS = 600;
const WEIGHT_LIMIT_FIELD = "TransportationTypeCode";
const WEIGHT_LIMIT_INPUTS = [
	"BuyersEquipment",
	WEIGHT_LIMIT_FIELD,
	"Quantity",
	"QuantityUnitOfMeasure",
	"TransportationUnits",
	"Location",
	"CommodityCode"
];
const WEIGHT_LIMIT_DRIVERS = ["Quantity", "TransportationUnits"];
const WEIGHT_LIMIT_PAUSE_MS = 600;
function weightLimitFieldVerdicts(state) {
	switch (state.status) {
		case "checking": return { [WEIGHT_LIMIT_FIELD]: {
			tone: "pending",
			message: WEIGHT_LIMIT_CHECKING_MESSAGE
		} };
		case "within": return { [WEIGHT_LIMIT_FIELD]: {
			tone: "valid",
			message: weightLimitMessage(state)
		} };
		case "outside": return {
			[WEIGHT_LIMIT_FIELD]: {
				tone: "invalid",
				message: weightLimitMessage(state)
			},
			...Object.fromEntries(WEIGHT_LIMIT_DRIVERS.map((name) => [name, {
				tone: "invalid",
				message: WEIGHT_LIMIT_DRIVER_MESSAGE
			}]))
		};
	}
}
function fieldVerdictOf(verdict) {
	switch (verdict.status) {
		case "checking": return {
			tone: "pending",
			message: TYPED_NUMBER_CHECKING_MESSAGE
		};
		case "free": return {
			tone: "valid",
			message: TYPED_NUMBER_AVAILABLE_MESSAGE
		};
		case "taken": return {
			tone: "invalid",
			message: verdict.message
		};
		case "failed": return {
			tone: "invalid",
			message: NUMBER_CHECK_UNCONFIRMED_MESSAGE
		};
		case "short": return {
			tone: "invalid",
			message: TYPED_NUMBER_SHORT_MESSAGE
		};
	}
}
const CONTRACT_KEY_PARTS_READ_ONLY = {
	ContractPrefixType: true,
	ContractPrefixCommodity: true,
	ContractNumber: true,
	ContractSuffix: true
};
const TAB_BY_CTRM_FIELD = Object.fromEntries(CONTRACT_LAYOUT_SECTIONS.flatMap((section) => section.fields.map((layoutField) => [layoutField.ctrmField, section.tab])));
export { ADDENDUM_REUSED_MESSAGE, ADDENDUM_STORED_MESSAGE, ADDENDUM_WITHDRAWN_MESSAGE, CONFIRMATION_STAGES, CONTRACT_DETAIL_SECTIONS, ContractRecordPageComponent, DETAIL_EMPTY_NOTES, LMS_FLAG_UNKNOWN_MESSAGE, LMS_WARNING_MESSAGE, LOG_NOTE_ADDED_MESSAGE, NOTIFY_FAILED_MESSAGE, NOTIFY_NOT_SENT_MESSAGE, NOTIFY_REQUESTED_MESSAGE, NOTIFY_TRADER_ACCEPTED_MESSAGE, NOTIFY_TRADER_DELIVERED_MESSAGE, NOTIFY_TRADER_RECORDED_MESSAGE, NOTIFY_UNKNOWN_MESSAGE, PricingCopyStore, aggregateValues, formatFieldValue, mergeContractValues, withMarketMonths, withResolvedTrader };

//# sourceMappingURL=cws-features-contract-summary.mjs.map
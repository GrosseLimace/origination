import * as i0 from "@angular/core";
import { ErrorHandler, InjectionToken } from "@angular/core";
import { IApplicationInsights } from "@microsoft/applicationinsights-web";
/**
 * The Application Insights connection string, or `null` when telemetry is not configured.
 *
 * Injected rather than imported from `environments/environment.ts` because this is a library: the
 * shell is only one of its consumers, a Module Federation host is the other (ADR-11), and a library
 * that reaches into an application's environment file cannot be reused by a host that has no such
 * file. Same reasoning as `CONTRACTS_API_URL`.
 *
 * ⚠ **The connection string is write-only and ships in the browser bundle** — `developer-docs`
 * says so explicitly — which is why it is not a secret, and equally why no PII may ride along with
 * the telemetry it authorises. See {@link redactTelemetryEnvelope}.
 */
export declare const APP_INSIGHTS_CONNECTION_STRING: InjectionToken<string | null>;
/**
 * The value reported as `ai.cloud.role`, which is what separates this SPA from the API and from the
 * external SPA in a query (`cloud_RoleName`).
 */
export declare const APP_INSIGHTS_ROLE_NAME: InjectionToken<string>;
/**
 * Treats an unconfigured or placeholder connection string as absent.
 *
 * 🔴 **The placeholder check is load-bearing, not defensive tidiness.** All four
 * `apps/cws-shell/src/environments/*.ts` files ship a sentinel of the form
 * `<DEV_CONNECTION_STRING_NOT_YET_CONFIGURED>`, so without this a developer machine would hand the
 * SDK a literal angle-bracketed string and the failure would surface as unexplained ingestion
 * errors rather than as "not configured". The sentinel form is `developer-docs`'s own.
 */
export declare function resolveConnectionString(raw: string | null | undefined): string | null;
/**
 * Reports an unhandled error to Application Insights and then **delegates to Angular's default
 * handler**.
 *
 * 🔴 **It must never swallow, and delegation rather than `console.error` is what guarantees that.**
 * `developer-docs/CLAUDE.md`'s pattern calls `console.error(error)` directly; this is a deliberate
 * strengthening of it, for two reasons:
 *
 * - Angular's `ErrorHandler` does more than log — it is the documented extension point, and a future
 *   Angular version changing what the default does would silently leave this one behind.
 * - A hand-rolled `console.error` diverges from what a developer sees with no custom handler
 *   installed, which makes a local reproduction subtly different from production.
 *
 * ⚠ **Reporting is wrapped so a telemetry failure cannot suppress the error.** If `trackException`
 * throws — a misconfigured SDK, a full buffer — the original error must still reach the default
 * handler, or installing telemetry would have made the application harder to debug rather than
 * easier. That is the exact inversion Known Issue 40 warns about: an instrument that costs more
 * than it returns.
 */
export declare class AppInsightsErrorHandler implements ErrorHandler {
  private readonly appInsights;
  private readonly fallback;
  handleError(error: unknown): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AppInsightsErrorHandler, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** Severity levels, mirrored so a caller needs no static import of the SDK. */
export declare const TelemetrySeverity: {
  readonly Verbose: 0;
  readonly Information: 1;
  readonly Warning: 2;
  readonly Error: 3;
  readonly Critical: 4;
};
export type TelemetrySeverityLevel = (typeof TelemetrySeverity)[keyof typeof TelemetrySeverity];
/**
 * **F1.6 — client-side Application Insights**, following `developer-docs/CLAUDE.md`
 * §Angular (Client-Side).
 *
 * Client telemetry is required for any Scoular SPA using MSAL, because server-side App Insights only
 * sees what the .NET app sees: MSAL errors, Angular template errors, unhandled rejections and
 * interceptor failures all happen in the browser and are invisible to it.
 *
 * 🔴 **The SDK is loaded with a dynamic `import()`, and that is a hard requirement rather than a
 * refinement.** Imported statically it lands in the initial chunk and costs **204 kB** — measured:
 * the shell went 767.99 kB → 971.99 kB and **failed** the 800 kB error budget outright. The
 * documented pattern imports it statically because it assumes an application, not a workspace with
 * a budget that is already tight (#252). Telemetry must never be on the first-paint path: nothing a
 * user does depends on it.
 *
 * 🔴 **Unconfigured is a supported state, and the whole service becomes a no-op.** It mirrors the
 * API, which registers server-side telemetry only when a connection string is present — a guard that
 * exists because `Microsoft.ApplicationInsights.AspNetCore` 3.x **throws** rather than no-ops when
 * unconfigured, which took down every developer machine once (Known Issue 8).
 *
 * ⚠ **A blocked beacon is silent.** If `connect-src` ever stops permitting the ingestion host, the
 * browser refuses the POST before it is sent: nothing in a HAR file, nothing in App Insights, and a
 * DevTools console line as the only evidence. `SecurityHeadersMiddleware` permits
 * `https://*.in.applicationinsights.azure.com` and `https://*.livediagnostics.monitor.azure.com`;
 * do not narrow them without reading `developer-docs/CLAUDE.md` §CSP Allow-List.
 */
export declare class AppInsightsService {
  /** Resolves once the SDK has loaded, or immediately when telemetry is not configured. */
  readonly ready: Promise<void>;
  private readonly router;
  private readonly roleName;
  private readonly connectionString;
  private insights;
  private pending;
  constructor();
  /**
   * True when a connection string is configured — **not** whether the SDK has finished loading.
   *
   * Deliberately the configuration question, because that is the one callers care about and it is
   * answerable synchronously. Await {@link ready} for the load.
   */
  get isEnabled(): boolean;
  /** The loaded SDK, or `null` while it is still loading or telemetry is off. Mainly for tests. */
  get instance(): IApplicationInsights | null;
  trackEvent(name: string, properties?: Record<string, unknown>): void;
  trackException(error: unknown, severityLevel?: TelemetrySeverityLevel, properties?: Record<string, unknown>): void;
  trackTrace(message: string, severityLevel?: TelemetrySeverityLevel, properties?: Record<string, unknown>): void;
  trackPageView(name?: string, uri?: string): void;
  /**
   * Sets the authenticated user context.
   *
   * ⚠ **The one deliberate exception to "no PII".** App Insights stores the authenticated user id by
   * design and it is what makes a support question answerable; pass the stable `oid` rather than the
   * UPN where the caller has it (C-13). It does not pass through the redaction initializer, which
   * scrubs telemetry *content* rather than this context field.
   */
  setAuthenticatedUser(userId: string | null): void;
  flush(): void;
  /** Runs now if the SDK is up, queues otherwise, and does nothing at all when unconfigured. */
  private enqueue;
  private load;
  static ɵfac: i0.ɵɵFactoryDeclaration<AppInsightsService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Scrubs anything that must never leave the browser, applied as the **last** telemetry initializer
 * so it sees whatever every earlier one produced.
 *
 * 🔴 **Three things are forbidden, and each has a different reason.**
 *
 * - **A bearer token** is a live credential. Known Issue 40 is this project's own instance: a
 *   diagnostic made *more* thorough — enumerating every header rather than filtering — wrote a live
 *   token to a console and a temp file. The lesson recorded there is that the instrument must
 *   exclude it **by name, in code, with a comment saying why**. This is that comment.
 * - **A user's email** is PII, and `developer-docs/EXTERNAL-SPA-GUIDE.md` states the rule for this
 *   estate: the connection string is write-only and visible in the bundle, so no PII in custom
 *   telemetry. ⚠ Note `setAuthenticatedUserContext` is a *separate, deliberate* channel — App
 *   Insights hashes and stores that by design — so this scrub covers the free-text surfaces only.
 * - **A full contract payload** is commercially sensitive and unbounded. A contract carries price,
 *   counterparty and quantity; none of it belongs in a telemetry property, and an exception message
 *   that serialised one would ship the lot.
 *
 * ⚠ **Redaction is by shape, not by key name.** A key-name allow-list would miss the case that
 * actually happens — a token or an email embedded *inside* an exception message or a URL — which is
 * exactly how the Known Issue 40 leak occurred.
 */
export declare const REDACTED_TOKEN = "[redacted:token]";
export declare const REDACTED_EMAIL = "[redacted:email]";
export declare const REDACTED_OVERSIZED = "[redacted:oversized]";
export declare const REDACTED_KEY = "[redacted]";
/** Scrubs a single string of every forbidden shape. */
export declare function scrubString(value: string): string;
/**
 * Scrubs an arbitrary value.
 *
 * An object or array is treated as a payload and dropped rather than walked: a contract aggregate
 * nests eleven collections, and a recursive walk would both cost more than telemetry is worth and
 * leave the decision about each new field to whoever adds it.
 */
export declare function scrubValue(value: unknown): unknown;
/** Scrubs a property bag in place, dropping forbidden keys entirely. */
export declare function scrubProperties(properties: Record<string, unknown> | undefined): void;
/**
 * Minimal structural view of the envelope, so this stays unit-testable without constructing the
 * SDK. The real `ITelemetryItem` is wider; these are the fields that can carry free text.
 */
export interface RedactableEnvelope {
  data?: Record<string, unknown>;
  baseData?: Record<string, unknown>;
  ext?: Record<string, unknown>;
}
/**
 * The telemetry initializer itself. Returns `true` so the item is still sent — scrubbed, never
 * dropped, because losing the diagnostic is not the goal.
 */
export declare function redactTelemetryEnvelope(envelope: RedactableEnvelope): boolean;
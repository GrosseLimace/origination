import * as i0 from "@angular/core";
import { ErrorHandler, Injectable, InjectionToken, inject } from "@angular/core";
import { Router } from "@angular/router";
const APP_INSIGHTS_CONNECTION_STRING = new InjectionToken("APP_INSIGHTS_CONNECTION_STRING");
const APP_INSIGHTS_ROLE_NAME = new InjectionToken("APP_INSIGHTS_ROLE_NAME");
function resolveConnectionString(raw) {
	if (raw === null || raw === void 0) return null;
	const trimmed = raw.trim();
	if (trimmed === "") return null;
	if (trimmed.startsWith("<") && trimmed.endsWith(">")) return null;
	return trimmed;
}
const MAX_VALUE_LENGTH = 2048;
const MAX_DEPTH = 8;
const BEARER_PATTERN = /\bBearer\s+[A-Za-z0-9\-._~+/]+=*/gi;
const JWT_PATTERN = /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}(?:\.[A-Za-z0-9_-]+)?/g;
const EMAIL_PATTERN = new RegExp(`[A-Za-z0-9._%+-]+(?:@|%(?:25)*40)[A-Za-z0-9.-]+\\.[A-Za-z]{2,}`, "g");
const FORBIDDEN_KEYS = /* @__PURE__ */ new Set([
	"authorization",
	"auth",
	"token",
	"access_token",
	"id_token",
	"password"
]);
const REDACTED_TOKEN = "[redacted:token]";
const REDACTED_EMAIL = "[redacted:email]";
const REDACTED_OVERSIZED = "[redacted:oversized]";
const REDACTED_KEY = "[redacted]";
function scrubString(value) {
	const scrubbed = value.replace(BEARER_PATTERN, REDACTED_TOKEN).replace(JWT_PATTERN, REDACTED_TOKEN).replace(EMAIL_PATTERN, REDACTED_EMAIL);
	return scrubbed.length > MAX_VALUE_LENGTH ? REDACTED_OVERSIZED : scrubbed;
}
function scrubValue(value) {
	if (typeof value === "string") return scrubString(value);
	if (value === null || value === void 0 || typeof value === "number" || typeof value === "boolean") return value;
	return REDACTED_OVERSIZED;
}
function scrubProperties(properties) {
	if (properties === void 0 || properties === null) return;
	for (const key of Object.keys(properties)) {
		if (FORBIDDEN_KEYS.has(key.toLowerCase())) {
			properties[key] = REDACTED_KEY;
			continue;
		}
		properties[key] = scrubValue(properties[key]);
	}
}
function redactTelemetryEnvelope(envelope) {
	scrubProperties(envelope.data);
	const seen = /* @__PURE__ */ new WeakSet();
	const baseData = envelope.baseData;
	if (baseData !== void 0 && baseData !== null) {
		scrubProperties(baseData["properties"]);
		scrubDeep(baseData, 0, seen);
	}
	scrubDeep(envelope.ext, 0, seen);
	return true;
}
function scrubDeep(value, depth, seen) {
	if (typeof value === "string") return scrubString(value);
	if (value === null || typeof value !== "object") return value;
	if (seen.has(value)) return value;
	if (depth >= MAX_DEPTH) return REDACTED_OVERSIZED;
	seen.add(value);
	if (Array.isArray(value)) {
		for (let index = 0; index < value.length; index++) value[index] = scrubDeep(value[index], depth + 1, seen);
		return value;
	}
	const record = value;
	for (const key of Object.keys(record)) {
		if (FORBIDDEN_KEYS.has(key.toLowerCase())) {
			record[key] = REDACTED_KEY;
			continue;
		}
		record[key] = scrubDeep(record[key], depth + 1, seen);
	}
	return value;
}
const TelemetrySeverity = {
	Verbose: 0,
	Information: 1,
	Warning: 2,
	Error: 3,
	Critical: 4
};
const MAX_PENDING = 100;
var AppInsightsService = class AppInsightsService {
	ready;
	router = inject(Router);
	roleName = inject(APP_INSIGHTS_ROLE_NAME, { optional: true }) ?? "cms-spa";
	connectionString = resolveConnectionString(inject(APP_INSIGHTS_CONNECTION_STRING, { optional: true }));
	insights = null;
	pending = [];
	constructor() {
		if (this.connectionString === null) {
			console.info("[telemetry] Application Insights is not configured; client telemetry is disabled.");
			this.ready = Promise.resolve();
			return;
		}
		this.ready = this.load(this.connectionString);
	}
	get isEnabled() {
		return this.connectionString !== null;
	}
	get instance() {
		return this.insights;
	}
	trackEvent(name, properties) {
		this.enqueue((sdk) => sdk.trackEvent({
			name,
			properties
		}));
	}
	trackException(error, severityLevel = TelemetrySeverity.Error, properties) {
		const exception = error instanceof Error ? error : new Error(String(error));
		this.enqueue((sdk) => sdk.trackException({
			exception,
			severityLevel,
			properties
		}));
	}
	trackTrace(message, severityLevel = TelemetrySeverity.Information, properties) {
		this.enqueue((sdk) => sdk.trackTrace({
			message,
			severityLevel,
			properties
		}));
	}
	trackPageView(name, uri) {
		this.enqueue((sdk) => sdk.trackPageView({
			name,
			uri
		}));
	}
	setAuthenticatedUser(userId) {
		this.enqueue((sdk) => {
			if (userId === null || userId === "") {
				sdk.clearAuthenticatedUserContext();
				return;
			}
			sdk.setAuthenticatedUserContext(userId, void 0, true);
		});
	}
	flush() {
		this.insights?.flush();
	}
	enqueue(action) {
		if (this.connectionString === null) return;
		if (this.insights !== null) {
			action(this.insights);
			return;
		}
		if (this.pending.length < MAX_PENDING) this.pending.push(action);
	}
	async load(connectionString) {
		try {
			const [{ ApplicationInsights, DistributedTracingModes }, { AngularPlugin }] = await Promise.all([import("@microsoft/applicationinsights-web"), import("@microsoft/applicationinsights-angularplugin-js")]);
			const angularPlugin = new AngularPlugin();
			const insights = new ApplicationInsights({ config: {
				connectionString,
				extensions: [angularPlugin],
				extensionConfig: { [angularPlugin.identifier]: { router: this.router } },
				enableAutoRouteTracking: true,
				autoTrackPageVisitTime: true,
				disableFetchTracking: false,
				disableAjaxTracking: false,
				distributedTracingMode: DistributedTracingModes.AI_AND_W3C,
				enableCorsCorrelation: true
			} });
			insights.loadAppInsights();
			insights.addTelemetryInitializer((envelope) => {
				envelope.tags = envelope.tags ?? {};
				envelope.tags["ai.cloud.role"] = this.roleName;
			});
			insights.addTelemetryInitializer((envelope) => redactTelemetryEnvelope(envelope));
			this.insights = insights;
			const queued = this.pending;
			this.pending = [];
			for (const action of queued) action(insights);
		} catch (error) {
			console.error("[telemetry] Application Insights failed to load; telemetry is off.", error);
			this.pending = [];
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AppInsightsService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AppInsightsService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: AppInsightsService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
var AppInsightsErrorHandler = class AppInsightsErrorHandler {
	appInsights = inject(AppInsightsService);
	fallback = new ErrorHandler();
	handleError(error) {
		try {
			this.appInsights.trackException(error);
		} catch (telemetryError) {
			console.error("[telemetry] Failed to report an unhandled error.", telemetryError);
		}
		this.fallback.handleError(error);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AppInsightsErrorHandler,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AppInsightsErrorHandler,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: AppInsightsErrorHandler,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
export { APP_INSIGHTS_CONNECTION_STRING, APP_INSIGHTS_ROLE_NAME, AppInsightsErrorHandler, AppInsightsService, REDACTED_EMAIL, REDACTED_KEY, REDACTED_OVERSIZED, REDACTED_TOKEN, TelemetrySeverity, redactTelemetryEnvelope, resolveConnectionString, scrubProperties, scrubString, scrubValue };

//# sourceMappingURL=cws-core-telemetry.mjs.map
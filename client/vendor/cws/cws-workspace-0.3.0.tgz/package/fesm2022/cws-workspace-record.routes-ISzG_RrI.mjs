import { mountBaseOf } from "./cws-workspace.mjs";
import { inject } from "@angular/core";
import { confirmNavigationGuard } from "@cws/shared-ui";
import { ADDENDUM_LIST_SOURCE, ADDENDUM_PDF_SOURCE, ADDENDUM_PREVIEW_SOURCE, ADDENDUM_TEMPLATE_SOURCE, ADDENDUM_TYPE_SOURCE, CONTRACT_ATTACHMENTS_SOURCE, CONTRACT_DOCUMENTS_SOURCE, CONTRACT_TEXT_SOURCE, HttpAddendumListSource, HttpAddendumPdfSource, HttpAddendumPreviewSource, HttpAddendumTemplateSource, HttpAddendumTypeSource, HttpContractAttachmentsSource, HttpContractDocumentsSource, HttpContractTextSource, ME_SOURCE } from "@cws/domain-contracts";
import { TradeUnitStore } from "@cws/core-state";
import { filter, firstValueFrom, map } from "rxjs";
import { Router } from "@angular/router";
import { AdminPageComponent, adminRoutes } from "@cws/features-admin";
import { provideHttpConstraintSource } from "@cws/features-contract-entry";
import { ContractRecordPageComponent } from "@cws/features-contract-summary";
const contractModeRedirect = (route) => {
	const mode = route.queryParamMap.get("mode")?.trim().toLowerCase();
	const target = mode === "edit" ? "edit" : mode === "approval" ? "approval" : null;
	const record = route.parent;
	const contractNumber = record?.paramMap.get("contractNumber");
	if (target === null || record === null || !contractNumber) return true;
	const base = record.parent ? mountBaseOf(record.parent) : "/";
	const rest = Object.fromEntries(Object.entries(route.queryParams).filter(([key]) => key !== "mode"));
	const commands = target === "edit" ? [
		base,
		"contracts",
		contractNumber,
		"edit"
	] : [
		base,
		"approvals",
		contractNumber
	];
	return inject(Router).createUrlTree(commands, { queryParams: rest });
};
const newContractLinkGuard = async (route) => {
	const wanted = route.queryParamMap.get("tradeUnit")?.trim() ?? "";
	const store = inject(TradeUnitStore);
	const me = inject(ME_SOURCE, { optional: true });
	if (wanted === "" || wanted === store.code() || me === null) return true;
	if (await firstValueFrom(me.get().pipe(filter((state) => state.status === "loaded" || state.status === "error"), map((state) => state.status === "loaded" && state.value.tradeUnits.some((unit) => unit.code === wanted)))).catch(() => false)) store.select(wanted);
	return true;
};
const ADDENDUM_PROVIDERS = [
	{
		provide: ADDENDUM_TEMPLATE_SOURCE,
		useClass: HttpAddendumTemplateSource
	},
	{
		provide: ADDENDUM_TYPE_SOURCE,
		useClass: HttpAddendumTypeSource
	},
	{
		provide: ADDENDUM_PREVIEW_SOURCE,
		useClass: HttpAddendumPreviewSource
	},
	{
		provide: ADDENDUM_PDF_SOURCE,
		useClass: HttpAddendumPdfSource
	},
	{
		provide: ADDENDUM_LIST_SOURCE,
		useClass: HttpAddendumListSource
	}
];
const RECORD_PROVIDERS = [
	...ADDENDUM_PROVIDERS,
	{
		provide: CONTRACT_DOCUMENTS_SOURCE,
		useClass: HttpContractDocumentsSource
	},
	{
		provide: CONTRACT_ATTACHMENTS_SOURCE,
		useClass: HttpContractAttachmentsSource
	},
	{
		provide: CONTRACT_TEXT_SOURCE,
		useClass: HttpContractTextSource
	}
];
const CREATE_RECORD_ROUTES = [{
	path: "",
	canActivate: [newContractLinkGuard],
	canDeactivate: [confirmNavigationGuard],
	providers: [...ADDENDUM_PROVIDERS, {
		provide: CONTRACT_ATTACHMENTS_SOURCE,
		useClass: HttpContractAttachmentsSource
	}],
	component: ContractRecordPageComponent
}];
const EDIT_RECORD_ROUTES = [{
	path: "",
	canDeactivate: [confirmNavigationGuard],
	providers: RECORD_PROVIDERS,
	component: ContractRecordPageComponent
}];
const VIEW_RECORD_ROUTES = [{
	path: "",
	canActivate: [contractModeRedirect],
	providers: RECORD_PROVIDERS,
	component: ContractRecordPageComponent
}];
const ADMIN_ROUTES = [{
	path: "",
	providers: [
		{
			provide: ADDENDUM_TEMPLATE_SOURCE,
			useClass: HttpAddendumTemplateSource
		},
		{
			provide: ADDENDUM_TYPE_SOURCE,
			useClass: HttpAddendumTypeSource
		},
		provideHttpConstraintSource()
	],
	component: AdminPageComponent,
	children: adminRoutes()
}];
export { ADMIN_ROUTES, CREATE_RECORD_ROUTES, EDIT_RECORD_ROUTES, VIEW_RECORD_ROUTES };

//# sourceMappingURL=cws-workspace-record.routes-ISzG_RrI.mjs.map
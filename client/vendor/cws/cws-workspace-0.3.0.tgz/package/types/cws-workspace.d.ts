import * as i0 from "@angular/core";
import { EnvironmentProviders, InjectionToken, Type } from "@angular/core";
import { CmsAuthConfig, CmsAuthService, CwsTokenProvider } from "@cws/core-auth";
import { AvailabilityGate, CtrmLocation, CwsExternalLinks } from "@cws/domain-contracts";
import { ActivatedRouteSnapshot, CanActivateFn, Router, Routes } from "@angular/router";
import { CmsHostContext, CmsHostRoutes, CwsModule } from "@cws/core-host-context";
import { PermissionContext, PermissionWriteRefusal, TradeUnitStore } from "@cws/core-state";
import { MutationOutcome, StatusTone, StorageRefusals } from "@cws/shared-ui";
/**
 * How the workspace gets its Contracts API token: one of two modes (ADR-18 ruling 4; D-14).
 *
 * - **The default — CWS's own MSAL instance** against the CWS SPA registration. Choose it when CWS
 *   should own sign-in and its failure modes; it costs a SPA redirect URI and a CORS origin per host
 *   origin per environment.
 * - **A host-supplied `CwsTokenProvider`**, when the host already holds an Entra session and consent
 *   for the CWS API scope. No MSAL instance runs in CWS. Observed 2026-10-22: Origination's
 *   registration acquired a Dev token for the CWS scope carrying `Admin` and `User`. Mode B is
 *   Originations' path.
 *
 * The API base is not repeated here, because it is `CwsWorkspaceConfig.apiUrl`.
 */
export type CwsWorkspaceAuth = (Omit<CmsAuthConfig, 'apiUrl'> & {
  readonly tokenProvider?: undefined;
}) | {
  readonly tokenProvider: CwsTokenProvider;
  readonly apiScopes: readonly string[];
};
/** What `provideCwsWorkspace` needs to know about the page it is mounted in. */
export interface CwsWorkspaceConfig {
  /** The Contracts API base. A request under it carries the CWS bearer; nothing else does. */
  readonly apiUrl: string;
  readonly auth: CwsWorkspaceAuth;
  /** Shown as the chip beside the module nav; `'prod'` shows nothing. */
  readonly environmentName: string;
  /** Who owns the page's light/dark theme. Standalone `'own'`, under a host `'host'`. */
  readonly theme: CwsThemeMode;
  /** D-17/D-18: `true` under a host — no brand lockup, no Sign out. Default `false`. */
  readonly embedded?: boolean;
  /** Application Insights. Absent means none is provided, nor an `ErrorHandler`. */
  readonly telemetry?: {
    readonly connectionString: string | null;
    readonly roleName: string;
  };
  /**
   * Power BI and FileBound (docs/02 §8, #756). Absent or blank means the link is not shown. Checked
   * when the workspace is provided, so a bad template fails at startup rather than on a click.
   */
  readonly links?: CwsExternalLinks;
}
/**
 * The environment chip beside the module nav: `'local'`, `'dev'`, `'qa'`; `'prod'` shows nothing.
 *
 * A token rather than the shell's `environment` file, because the workspace no longer lives in the
 * shell: a host mounting it has its own environments and says which one this is.
 */
export declare const CWS_ENVIRONMENT_NAME: InjectionToken<string>;
/**
 * Who owns the page's light/dark theme.
 *
 * - `'own'`, standalone: the workspace writes the `dark` class on `<html>` and keeps the choice.
 * - `'host'`, embedded: the host owns `<html>`, so the workspace never writes it, follows the host's
 *   class instead, and the user menu hides its theme switch.
 */
export type CwsThemeMode = 'own' | 'host';
export declare const CWS_THEME_MODE: InjectionToken<CwsThemeMode>;
/**
 * `true` when the workspace is mounted inside a host page (D-17, D-18; T0 2026-09-30).
 *
 * The host's own header carries the brand and owns the session, so the workspace then renders no
 * brand lockup and the user menu offers no Sign out: `logoutRedirect` would leave the host's page
 * and end the tenant session, signing the user out of the host too. Defaults to `false`, standalone.
 */
export declare const CWS_EMBEDDED: InjectionToken<boolean>;
/** What the user picked. `system` follows the OS rather than pinning either way. */
export type ThemePreference = 'light' | 'dark' | 'system';
/**
 * Light/dark theme for the workspace.
 *
 * ### Two modes, because the workspace now runs in two kinds of page (ADR-18)
 *
 * This used to live in the shell, on the grounds that writing to `document.documentElement` is
 * something no library should do inside a host's page. That reasoning still holds, and
 * `CWS_THEME_MODE` is how it is kept now that the workspace itself is a library:
 *
 * - **`own`** (standalone, the default): the store writes the `dark` class on `<html>` and keeps the
 *   choice, exactly as the shell did.
 * - **`host`** (embedded): the host owns `<html>`, so the store **never writes it**. It reads the
 *   host's `dark` class through a `MutationObserver`, so a host that toggles dark after the
 *   workspace mounted is followed rather than read once, and `CmsHostContext.theme()` agrees with
 *   what is on screen. The user menu hides its theme switch in this mode.
 *
 * **`localStorage`, unlike the trade unit's `sessionStorage`.** The reasoning that keeps the trade
 * unit per-tab is that coming back days later to a silently pre-selected unit is how someone reads
 * the wrong location's contracts. A theme has no equivalent hazard and the opposite expectation:
 * being asked to re-pick dark mode every morning is the annoyance, so this one is meant to outlive
 * the tab.
 */
export declare class ThemeStore {
  private readonly mode;
  /** #889: where a refused write is reported, so it is said rather than swallowed. */
  private readonly refusals;
  private readonly preference;
  /** The host's `dark` class, in `host` mode only. */
  private readonly hostDark;
  /** What the user chose — including `system`, which is not the same as either resolved value. */
  readonly selected: import("@angular/core").Signal<ThemePreference>;
  /** Whether dark is actually showing right now: the host's class in `host` mode. */
  readonly isDark: import("@angular/core").Signal<boolean>;
  constructor();
  set(preference: ThemePreference): void;
  /** Flips between light and dark, resolving `system` to the opposite of what is showing. */
  toggle(): void;
  private apply;
  /** Host mode: read the host's class now, then on every change to it, until this store is destroyed. */
  private followHost;
  static ɵfac: i0.ɵɵFactoryDeclaration<ThemeStore, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The URL of the route the workspace is mounted on: `'/'` standalone, `'/workbench/cws'` under the
 * embedding host. Pass the snapshot of the workspace's OWN route.
 *
 * ⚠ **A guard on a child route must derive the base with this, not read {@link CwsMountBase}.** The
 * workspace component sets `CwsMountBase` when it constructs, and the router constructs it only after
 * every guard on the way down has passed, so on a first navigation a child's guard would read the
 * default `'/'`. Under a host that is the host's own root (#615).
 */
export declare function mountBaseOf(mountRoute: ActivatedRouteSnapshot): string;
/**
 * Where the workspace is mounted: `'/'` standalone, `'/workbench/cws'` in the embedding-host proof.
 *
 * Every route the workspace builds for itself (`workspaceRoutes`, the admin guard's refusal, and from
 * PR 4 the module nav) is prefixed with this, so the same route table works at the root of the shell
 * and under any prefix a host chooses (ADR-18).
 *
 * ⚠ **Read once from the mounting route's snapshot by `CwsWorkspaceComponent`; a static prefix is
 * assumed.** A parameterised prefix (`/tenant/:id/cws`) would need re-deriving on every navigation.
 * That is documented in HOST-CONTRACT §9 and not built (Mentor 2026-09-30).
 */
export declare class CwsMountBase {
  private readonly base;
  readonly path: import("@angular/core").Signal<string>;
  set(path: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<CwsMountBase, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The workspace's route table, as the host contract sees it, under whatever base it is mounted at.
 *
 * 🔴 **This is the knowledge that used to live inside the record screen, and moving it out is the
 * whole point of F9.1.** The screen says *"open this contract"*; this table decides that
 * `{base}/contracts/{n}` is what that means here. Originations mounts the workspace under its own
 * prefix and no feature library changes.
 *
 * At `base() === '/'` it reproduces the standalone shell's table exactly (`SHELL_ROUTES`, which this
 * replaced in E9 PR 3); `workspace-host-context.spec.ts` pins that byte for byte.
 *
 * ⚠ `origin` takes the **raw** `from` parameter, including `null` arriving as `''` and whatever a
 * hand-edited URL carried. `recordOrigin` already narrows an unknown value to the `contracts` default
 * and documents why, so this reproduces exactly what the screen computed for itself before rather
 * than adding a second normalisation that could disagree with the breadcrumb.
 *
 * ⚠ `base` is a function, read on every call, because the base is only known once the workspace
 * component has read its mounting route (`CwsMountBase`), which is after this table is built.
 */
export declare function workspaceRoutes(base: () => string): CmsHostRoutes;
/**
 * Where each module lives under the mount base (E9 PR 4, F9.10). The one list: the chrome's nav and
 * the `module` intent both read it, so a module cannot have one path in the nav and another in a link.
 */
export declare const MODULE_SEGMENTS: Readonly<Record<CwsModule, readonly string[]>>;
/**
 * What the host context reads from the signed-in identity, and nothing more.
 *
 * Narrower than the whole `CmsAuthService` on purpose: in host-token mode (D-14) the chrome's
 * identity comes from `HostTokenAuthService`, provided **as** `CmsAuthService`, and it satisfies this
 * structurally, so it fits without a cast.
 */
export type WorkspaceHostAuth = Pick<CmsAuthService, 'isSignedIn' | 'userId' | 'username' | 'displayName' | 'accessToken'>;
/**
 * The workspace's {@link CmsHostContext}: the signed-in identity, `ThemeStore` for the theme,
 * `TradeUnitStore` for the trade unit, and the Angular `Router` for navigation under the mount base.
 *
 * Standalone, `base` answers `'/'` and this is exactly what the shell's own context was before
 * E9 PR 3 moved it here. Embedded, a host mounts the workspace under a prefix and every intent
 * resolves under it.
 *
 * Built as a factory over already-resolved dependencies rather than calling `inject()` itself, so
 * that a spec can construct it against stubs and still exercise **this** composition. A factory that
 * injected internally would force every spec to stand up MSAL to test a route mapping.
 *
 * ⚠ **`user()` carries no roles, deliberately.** `PERMISSION_CONTEXT` answers what a caller may do,
 * by intent-name, and is provided separately. See `CmsHostUser` for why a second route to that
 * question is the one that breaks under #138.
 */
export declare function workspaceHostContext(router: Router, auth: WorkspaceHostAuth, tradeUnits: TradeUnitStore, theme: ThemeStore, base: () => string): CmsHostContext;
/**
 * The workspace's answer to "what may this caller do": the token's `Admin` role, or what
 * `GET /api/v1/me` grants in the active trade unit (E9 PR 3; #411, F1.3; ruling 7).
 *
 * ### 🔴 The token's `Admin` is the override, and it is read first
 *
 * The server's `isAdmin` IS the token's `Admin` app role (`MeEndpoints.cs`: *"the override is a
 * property of the token"*), and the token is known before first paint. So an administrator's Admin
 * nav entry and enabled Save render on the first frame exactly as they did under the role-derived
 * `shellPermissionContext` this replaced, with no pop-in. `/me` adds the per-trade-unit grants when
 * it answers, and the API authorizes writes by the same keys in the contract's trade unit (F1.3
 * PR 3), so a `User` holding `contracts:update` here is a `User` the server will let save.
 *
 * ### ⚠ Fail closed
 *
 * While `/me` is loading, when it failed, and when it answered `status: 'Unavailable'`, a non-admin is
 * granted **nothing** and sees everything read-only. A provisional "yes" would show a Save the server
 * then refuses; a provisional "no" is only a disabled button for a moment. The admin guard waits for
 * {@link settled} rather than refusing on that provisional "no".
 *
 * ### ⚠ The four members stay separate, and the keys are provisional
 *
 * They are four answers rather than one because they are four grants (`contracts:update`,
 * `prices:update`, `contracts:approve`, `settings:manage`), which is the reason the old shell file
 * gave for not collapsing them, now true on the wire. **The keys are #411's provisional table and may
 * rename pending #138**; a published package carries them as behaviour, so the 0.2.0 CHANGELOG says
 * so. `canAccessAdmin` is the token's `Admin` or `settings:manage` in **any** trade unit (ruling 7,
 * JFrisbie 2026-09-30): the Admin module is not per trade unit.
 *
 * ⚠ This is a **UI hint**, never enforcement — see {@link PermissionContext}. The server decides.
 */
export declare class MePermissionContext implements PermissionContext {
  private readonly auth;
  private readonly tradeUnit;
  private readonly source;
  private readonly me;
  private readonly tokenIsAdmin;
  /** `/me`'s answer when it is final and usable; `null` grants nothing. */
  private readonly grants;
  private readonly isAdmin;
  private readonly has;
  readonly canWriteContracts: () => boolean;
  readonly canEditPricing: () => boolean;
  readonly canApproveContracts: () => boolean;
  readonly canAccessAdmin: () => boolean;
  /**
   * Why every CTRM write is refused in the active trade unit, whatever is granted (#411, C-15).
   *
   * - **Not onboarded, under an enforcing server**: read-only for everyone, Admin included, as
   *   `TradeUnitWriteAuthorizer` refuses it. Under `Report` (Dev and QA) the server allows the write
   *   and only logs it, so nothing is refused here either (JFrisbie, 2026-10-05): the client must
   *   never refuse what the server accepts.
   * - **Permissions unavailable**: `/me` answered `Unavailable`, or failed. Nothing can be shown to be
   *   onboarded, so every write is refused and the workspace says why once.
   *
   * ⚠ `null` while `/me` is loading, so an administrator's controls render on the first frame as the
   * header above describes; a write in that instant meets the server's refusal, not a silent one.
   * And `null` with no trade unit chosen, because no CTRM write can be made without one.
   */
  readonly writeRefusal: () => PermissionWriteRefusal | null;
  /** Resolves once `/me` has answered, either way; at once when there is no `/me` source. */
  settled(): Promise<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MePermissionContext, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** The CWS-owned notice route under the mount: `/access` standalone, `/<prefix>/access` under a host. Unguarded. */
export declare const ACCESS_NOTICE_PATH = "access";
/**
 * Signed in WITH a Contracts role, or a `UrlTree` to the access notice (FE-2, 2026-10-23).
 *
 * Replaces `cwsAuthGuard` on `cwsRoutes()`. That guard returns `false` when `ensureSignedIn()` fails,
 * which cancels the navigation and paints nothing: under Origination's host a user without consent,
 * assignment or a role saw a blank page or a workspace whose every call 403s. Angular resolves a
 * route's `canActivate` results in declaration order and a `false` beats any later `UrlTree`, so the
 * redirect has to come from the guard that decides sign-in, and that guard has to know the mount
 * base, which `@cws/core-auth` deliberately does not (D-14). Hence a workspace guard.
 *
 * A token with no `Admin`/`User` is refused here, not left to 403: the API's `CwsUser` policy refuses
 * every call without one, so there is nothing the home grid could show. The roles are read before
 * `ensureSignedIn()` resolves in both modes (#615), so this is not the cold-browser race the admin
 * guard documents. The notice page tells sign-in-blocked from roles-less; this guard need not.
 *
 * ⚠ Derived base, not `CwsMountBase`: a guard runs before the workspace component sets it (#615).
 */
export declare const canUseContractsGuard: CanActivateFn;
export type AccessNoticeState = 'signed-out' | 'sign-in-blocked' | 'no-role' | 'ok';
/**
 * Where `canUseContractsGuard` sends a user it refused (FE-2). Reads LIVE auth state rather than a
 * query parameter: the workspace's query string is shareable state (see `AccessNotice`), and a pasted
 * `/access` link must tell its reader the truth about their own account, which is the `ok` state.
 *
 * Four states, in this order. In Mode B `isSignedIn()` is "the host has an account", which it does
 * for every failure Origination reports: consent pending, assignment required, an expired session
 * and a roles-less token alike (host-token-auth.service.ts). The first three are fixable by the user
 * through one interaction, and the host's provider says so by setting `signInBlocked` (the same
 * signal the chrome's Sign in button watches), so they get `sign-in-blocked` and a button; only a
 * token that was issued and carries no role gets `no-role`, which has no action a user can take.
 * `ok` is checked after `sign-in-blocked` so a user whose roles are known but whose token is now
 * blocked is offered the sign-in rather than told all is well.
 */
export declare class AccessNoticePageComponent {
  protected readonly auth: CmsAuthService;
  protected readonly base: import("@angular/core").Signal<string>;
  protected readonly state: import("@angular/core").Signal<AccessNoticeState>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AccessNoticePageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AccessNoticePageComponent, "cws-access-notice-page", never, {}, {}, never, never, true, never>;
}
/**
 * The sentence a refused administrator sees.
 *
 * Exported so the guard and its spec share ONE string rather than agreeing by transcription — the
 * shape of defect that let a pricing queue tell users to use the green screen for days after that
 * stopped being true, because its test asserted the wording it had been handed rather than the fact
 * it existed to pin.
 *
 * ⚠ Worded as what the account LACKS, not "access denied". The fix is an Entra app-role assignment
 * someone has to request by name, so a user who cannot tell which role they need cannot act on it —
 * the same reasoning the trade-unit picker and the Save gate already carry.
 */
export declare const ADMIN_REFUSAL = "Administration needs the Admin role on this application. Your account can view contracts but not administer them.";
/**
 * Route guards that keep a user out of a module the nav already declines to show them.
 *
 * ### 🔴 The nav alone is not enough, and this is why the guard exists
 *
 * Hiding the Admin link stops it being *clicked*; it does nothing about a bookmark, a pasted URL, a
 * browser history entry from a session where the account had the role, or the back button. Without a
 * guard those all render the admin screen, whose every request then 403s — which looks like the
 * application being broken rather than a permission boundary, and is precisely the experience #155
 * exists to remove one screen further in.
 *
 * ### 🔴 It signs in FIRST, itself, because the route's guards run together (#615)
 *
 * **Roles are empty until a token has been read**, so a guard that looked before sign-in finished
 * would refuse a genuine administrator arriving on a cold browser, bounce them, and tell them they
 * lack a role they hold.
 *
 * ~~Angular runs `canActivate` guards in declaration order, so `[cwsAuthGuard, canAccessAdminGuard]`
 * puts sign-in first.~~ **It does not.** The router subscribes to all of a route's `canActivate`
 * guards at once and only *resolves* them in declaration order, so this guard used to read the roles
 * while `cwsAuthGuard` was still signing in. Warm navigations hid it, because by then the token had
 * been read; a cold deep link (a bookmark, a pasted URL) is exactly the case that could not hide it.
 *
 * So this guard awaits `CmsAuthService.ensureSignedIn()` before asking anything. It is the same
 * surface `MePermissionContext` reads the roles from, in both modes: `CmsAuthService` itself in
 * Mode A, `HostTokenAuthService` provided as it in Mode B. Each resolves `true` only once the token's
 * roles are read, and concurrent calls share one attempt, so this does not start a second sign-in
 * beside `cwsAuthGuard`'s. `cwsAuthGuard` stays on the route: every route carries it
 * (`cws.routes.spec.ts`), and it owns the "not signed in" outcome. This guard only declines to
 * decide until there is an identity to decide about.
 *
 * ⚠ **Not `canMatch`**, which is the tempting choice because it would also avoid downloading the
 * admin chunk. `canMatch` runs *before* `canActivate` — including before `cwsAuthGuard` — so it lands
 * in exactly the empty-roles trap above. The wasted chunk is the price of not lying to the user.
 *
 * ### ⚠ It waits for `settled` before refusing (D-7)
 *
 * The token's `Admin` is known at once, but `settings:manage` comes from `/me`. A non-admin holding
 * it who arrives by bookmark is `false` until `/me` answers, so the guard awaits
 * `PermissionContext.settled` (optional; absent means the answer is already final) and asks again.
 *
 * ### ⚠ A refusal lands on the MOUNT BASE, not on `/`
 *
 * Standalone the base is `/`. Under a host it is the workspace's prefix, and `/` would be the host's
 * own root, which would throw the user out of CWS altogether.
 *
 * ⚠ **Derived from this route's parent, not read from `CwsMountBase`** (#615). The workspace
 * component sets that when it constructs, which on a first navigation is after this guard has run,
 * so it still held its default `/`.
 */
export declare const canAccessAdminGuard: CanActivateFn;
/**
 * The user's own trade-unit visibility list, shared by the picker and the identity menu (#103).
 *
 * 🔴 **A PREFERENCE, NOT A PERMISSION** (C-14, C-15 a). It shortens the picker and denies nothing:
 * the picker always offers "Show all", never hides the active unit, and a deep link into a hidden
 * unit opens as it always did. **Do not consult this anywhere that decides what a user may read or
 * write.** A real restriction would be a spec correction plus server-side authorization.
 *
 * ⚠ **Provided by `provideCwsWorkspace`, never from root** — the `AvailabilityGate` lesson: from a
 * host's root injector this would find no source and quietly offer nothing.
 *
 * ⚠ **Read on first use, not at boot.** The picker and the curation panel call {@link load} when
 * opened, so the source's lazy chunk (#678) is not fetched on every page load.
 */
export declare class TradeUnitVisibilityStore {
  private readonly source;
  private readonly state;
  private readonly hidden;
  private readonly saves;
  /** The last save's outcome (#803), for the curation panel to say. */
  private readonly lastSave;
  /** Whether this host offers the capability at all. Without it there is nothing to curate. */
  readonly offered: boolean;
  /** Whether a saved list was read, so changes can be saved. */
  readonly available: import("@angular/core").Signal<boolean>;
  /** The read is still in flight. */
  readonly loading: import("@angular/core").Signal<boolean>;
  /** The last save did not reach the server. The choice still applies for this session. */
  readonly saveFailed: import("@angular/core").Signal<boolean>;
  /** The last save, said (#803): saved, and where (#1051), or not, with the server's reference. */
  readonly saveOutcome: import("@angular/core").Signal<MutationOutcome | null>;
  dismissSaveOutcome(): void;
  /**
   * The picker's escape hatch: show hidden units too, for this session, without changing the list.
   * A curated list with no way out would become a restriction by accident.
   */
  readonly showAll: import("@angular/core").WritableSignal<boolean>;
  readonly hiddenCount: import("@angular/core").Signal<number>;
  constructor();
  /** Reads the saved list once. Idempotent; a no-op without a source. */
  load(): void;
  isHidden(code: string): boolean;
  /**
   * Hides or shows one unit and saves the whole list.
   *
   * ⚠ Refused while the list is unavailable: a change that cannot be saved would apply now and
   * silently vanish on the next visit, which reads as the application forgetting.
   */
  setHidden(code: string, hide: boolean): void;
  /** The curation panel's way back to the full list. */
  unhideAll(): void;
  private commit;
  static ɵfac: i0.ɵɵFactoryDeclaration<TradeUnitVisibilityStore, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The shell's active-trade-unit switcher (docs/02 §1.1).
 *
 * Lives in the shell rather than on a screen because switching re-resolves form config, permissions
 * and reference data, and because the nav entries beside it are themselves permission-gated per
 * active trade unit — the shell cannot render its own navigation without knowing this value.
 *
 * **Deviation worth naming:** §1.1 puts the switcher inside the *user menu*, next to profile and
 * sign-out. C-15 then established that this is a picker over **1044 locations** needing
 * company → division → location navigation or typeahead. That is not a dropdown menu item; burying
 * it costs two clicks on the control users touch most and leaves nowhere for a typeahead to go. So
 * it is a first-class control in the bar. 02a was left as "final layout in 02a" and never resolved
 * it, so this is filling a gap rather than contradicting a decision — but it is a decision.
 *
 * **A button and a panel rather than a native `<select>`.** Partly weight — `scoular-form-select` is
 * `px-4 py-2` with a border, which made it ~10px taller than everything else in the bar and the only
 * filled block among text. Mostly direction: a native select cannot carry a typeahead over 1044
 * options, so the select was a dead end and this is the shape the real picker needs.
 *
 * The panel is a typeahead over a flat list of locations, without company headers (#840, which
 * corrects C-15's company → division navigation).
 */
export declare class TradeUnitPickerComponent {
  protected readonly store: TradeUnitStore;
  private readonly source;
  private readonly router;
  private readonly data;
  /** Optional: a host without an identity route gets a picker with no default and no markers. */
  private readonly meSource;
  private readonly me;
  private readonly identity;
  /**
   * The caller's trade units by code, for the onboarded marker.
   *
   * ⚠ A location absent from this map is **not** marked. `/me` lists the units the caller has; the
   * picker lists all 1044 CTRM locations (C-14 keeps reads unscoped), so most entries are simply not
   * the caller's and carry no onboarding status either way. Marking those would put a warning on
   * almost every row and make the real ones invisible.
   */
  private readonly mine;
  /**
   * Whether this location is one of the caller's trade units that CWS cannot configure yet (C-15 d).
   *
   * 🔴 **Marked, never hidden.** Hiding a trade unit the user knows they have reads as a permissions
   * fault — they would go and ask for access they already hold — whereas a marked row says the
   * truth: it is yours, and this application is not ready for it.
   */
  protected notOnboarded(code: string): boolean;
  /** Optional: a host without it gets the assigned default only, and no "make my default". */
  private readonly defaultSource;
  /** The user's own choice as last read or saved. `loading` until the read answers. */
  private readonly ownDefault;
  /** Where the last "make my default" landed, for the line under the search box. */
  protected readonly defaultKeptIn: import("@angular/core").WritableSignal<"account" | "failed" | "browser" | null>;
  /** The user's own default code, or `null` for none (or none readable). */
  protected readonly ownDefaultCode: import("@angular/core").Signal<string | null>;
  /** The default a new session opens on: the user's own, else the one assigned on the Roles page. */
  protected readonly effectiveDefault: import("@angular/core").Signal<string | null>;
  /** Whether the default shown is the user's own, rather than the assigned one. */
  protected readonly defaultIsOwn: import("@angular/core").Signal<boolean>;
  /**
   * Selects the default, once, when nothing is selected yet (C-15 c).
   *
   * 🔴 **Only when the store is empty.** A remembered session choice is the user's and outranks any
   * default; re-applying it on every load would silently move somebody off the unit they picked,
   * which is exactly how the wrong location's contracts get read without anyone noticing.
   *
   * ⚠ **The user's own choice is waited for** before the assigned one is used: selecting the assigned
   * default first would fill the store, and the user's own default could then never apply.
   *
   * ⚠ `null` when nothing is set either way, and nothing is selected then. Picking arbitrarily would
   * put a user on a trade unit nobody chose.
   */
  private readonly applyDefault;
  private readonly readOwnDefault;
  /** Makes the active trade unit the user's own default, or clears theirs with `null`. */
  protected setOwnDefault(code: string | null): void;
  /** Whether the picker offers "make my default" at all. */
  protected readonly defaultOffered: boolean;
  /** A location's name, for the default line. */
  protected nameOf(code: string): string;
  /**
   * Every location, ordered by code.
   *
   * 🔴 **Locations only, with no company headers** (#840). GEstevez ruled on the 2026-10-12 walk
   * that the picker shows trade-unit locations alone, and JFrisbie confirmed it on 2026-10-14; it
   * corrects C-15's company → division → location navigation. The company stays searchable.
   */
  protected readonly locations: import("@angular/core").Signal<readonly CtrmLocation[]>;
  /**
   * The user's own hidden list (#103). Optional: a host without it gets the full list, as before.
   *
   * 🔴 **A PREFERENCE, NOT A PERMISSION** (C-14, C-15 a). It only shortens this list. Show all is
   * always offered while anything is hidden, the active unit is never hidden (a deep link can arrive
   * with one selected), and an unreadable list hides nothing.
   */
  protected readonly visibility: TradeUnitVisibilityStore | null;
  /**
   * How many units the user's list is hiding. Always 0 when the list could not be read: the store
   * only fills it from an `available` answer, which is what makes an unreadable list hide nothing.
   */
  protected readonly hiddenCount: import("@angular/core").Signal<number>;
  /** {@link locations} less the user's hidden units, unless Show all is on. */
  private readonly visibleLocations;
  /** The typeahead term. Cleared when the panel closes, so reopening starts from the whole list. */
  protected readonly term: import("@angular/core").WritableSignal<string>;
  /**
   * The list narrowed by {@link term} — C-15's typeahead over 1044 locations.
   *
   * Matches on **location code, location name, company code and company name**, because a trader
   * knows a unit by whichever of those they happen to have. Searching only the name would fail
   * someone typing `0210`, and searching only the code would fail someone typing "Omaha" — and the
   * code is the thing CTRM and the contract itself show, so it cannot be the one left out.
   *
   * A location whose company matches is kept, which is what makes "scoular canada" a useful query
   * rather than one that returns nothing. With no company headers shown (#840), the search is the
   * only place the company still counts.
   *
   * Filtered in memory over ~1044 rows per keystroke, which is trivial and avoids a debounce that
   * would make short queries feel laggy. When this grows a server-side counterpart it belongs with
   * CR-4's filtering rather than as a second, separate search.
   */
  protected readonly filtered: import("@angular/core").Signal<readonly CtrmLocation[]>;
  /** How many locations the current term matches, for the empty state. */
  protected readonly matchCount: import("@angular/core").Signal<number>;
  /** Unique per instance, so two pickers on one page cannot share option ids. */
  protected readonly listboxId: string;
  /**
   * The keyboard-active option's index in {@link filtered}, or -1 for none.
   *
   * Typing makes the first match active, so Enter picks what was typed: the walk's t2 finding was
   * that a typed match could be picked only by click or Tab. With nothing typed nothing is active,
   * so Enter on an empty box picks nothing.
   */
  protected readonly activeIndex: import("@angular/core").WritableSignal<number>;
  protected optionId(code: string): string;
  protected readonly activeOptionId: import("@angular/core").Signal<string | null>;
  protected onTermInput(value: string): void;
  /** Arrows, Home and End move the active option; Enter picks it. Focus stays in the search box. */
  protected onSearchKeydown(event: KeyboardEvent, picker: {
    close(): void;
  }): void;
  /** On an option itself, the arrows move focus to the next or previous option. */
  protected onOptionKeydown(event: KeyboardEvent): void;
  protected choose(code: string, picker: {
    close(): void;
  }): void;
  private moveActive;
  /**
   * Clears the term, wired to the trigger's toggle so it runs on **open** as well as close.
   *
   * Resetting on open rather than only on close is what makes it reliable: the panel can also be
   * dismissed by clicking outside it, which never reaches this component, so a close-only reset would
   * leave a stale filter waiting the next time someone opened the picker.
   */
  protected resetSearch(): void;
  protected readonly failed: import("@angular/core").Signal<boolean>;
  /**
   * Why the list is missing, for the panel to show.
   *
   * The trigger stays terse — it is one line of chrome — but the panel is where someone goes when the
   * trigger says something is wrong, so it carries the actual reason and the correlation id
   * (docs/02 §9). "Sign in again" and "your account has no role" are opposite instructions, and the
   * panel used to give neither: it hardcoded one sentence for every possible cause (#65).
   */
  protected readonly failure: import("@angular/core").Signal<import("@cws/shared-ui").RemoteError | null>;
  /** What the trigger shows: the active unit, or why there is none. */
  protected readonly label: import("@angular/core").Signal<string>;
  /**
   * True on screens where changing the trade unit would destroy work in progress.
   *
   * **Disabled, not hidden.** Hiding it would make the active trade unit invisible on exactly the
   * screen where getting it wrong is most expensive — you are creating a contract *under* a unit,
   * and a deep link can arrive with one already set (docs/02 §1.3 `?tradeUnit=`). Visibility is
   * global; only mutability is contextual.
   *
   * The reason it must not change mid-form: form sections are config-driven per trade unit
   * (docs/02 §3), so a switch can restructure the form underneath whatever has been typed.
   *
   * Declared by the route rather than pushed up from the feature, so a screen opts in by saying so
   * in its own definition and no feature library has to reach into the shell.
   */
  protected readonly locked: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<TradeUnitPickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TradeUnitPickerComponent, "cms-trade-unit-picker", never, {}, {}, never, never, true, never>;
}
/**
 * The identity menu: who you are, and how to stop being them.
 *
 * Collapses what used to be three separate things in the top bar — role badge, name, sign-out
 * button — into one control. The bar is chrome; three items competing there crowded out the things
 * people actually navigate with.
 *
 * **One deliberate exception: "No role" stays outside the menu** (see the template). Its entire
 * value is being visible without a click — a signed-in user with no app role gets a 403 on every
 * request (#36), which is indistinguishable from a broken application unless the missing role is on
 * screen. Tidying that into a dropdown would tidy away the diagnosis. The *normal* role is inside,
 * where it is reference rather than a warning.
 *
 * Open/close behaviour comes from `DropdownDirective`, shared with the trade-unit picker. The ARIA
 * is not shared: this is a `menu` of actions, that is a `listbox` of values.
 */
export declare class UserMenuComponent {
  protected readonly auth: CmsAuthService;
  /**
   * The signed-in user's roles, **most privileged first** — Admin, then User.
   *
   * Sorted rather than shown in arrival order because the wire order is Entra's and means nothing:
   * `roles` is a JSON array whose sequence is not specified, so an account holding both could read
   * "User, Admin" one session and "Admin, User" the next. A stable, meaningful order is worth more
   * than fidelity to an order that carries no information.
   *
   * `Array.prototype.sort` is stable in every engine this ships to, so roles sharing a rank — every
   * unrecognised one — keep their relative order rather than shuffling between renders.
   */
  protected readonly sortedRoles: import("@angular/core").Signal<string[]>;
  /**
   * The badge variant for a role.
   *
   * Admin is **red** (JFrisbie, 2026-08-31) — the design system's own `scoular-badge-error`, which is
   * the sanctioned red badge rather than a hand-mixed one. It no longer matches the environment chip;
   * that was the earlier arrangement and is deliberately abandoned, because the two say different
   * things and a shared colour implied a relationship neither has.
   *
   * ⚠ **Tinted red, not a solid red fill, and that is a contrast decision rather than a style one.**
   * White on `scoular-red` (#EF4623) measures **3.8:1**, below the 4.5:1 minimum for body text, and
   * even `scoular-red-dark` (#DF3410) only reaches 4.5:1 — passing by a hair at 12px. The design
   * system's variant puts dark red text on a 10% tint instead and clears the bar comfortably.
   *
   * ✅ **This returns a TONE now, not a class string (2026-09-16).** The neutral variant used to be
   * spelled out here — `scoular-badge-neutral`'s `border-slate-100` is nearly invisible against the
   * menu, and the class carries no dark-mode rule — and it had to be spelled out, because the design
   * system compiled unlayered so a `border-slate-300` beside it was overruled and did nothing.
   * `components.css` now sits in `@layer components`, so those utilities win and the fix moved onto
   * the `neutral` tone in `cms-status-badge`, where the grid and the record page get it too.
   */
  protected badgeTone(role: string): StatusTone;
  /**
   * Theme lives here rather than as its own top-bar control.
   *
   * The bar is chrome and it already lost a role badge, a name and a sign-out button to this menu for
   * the same reason: three items competing there crowd out the things people navigate with. A theme
   * switch is set once and then never touched, which makes it the weakest possible claim on permanent
   * bar space — the opposite of "No role", which stays outside precisely because it is a warning.
   */
  protected readonly theme: ThemeStore;
  /**
   * Who owns the page's theme. In `host` mode the switch is hidden: the host owns `<html>`, so a
   * choice made here could not change what is on screen (D-9).
   */
  protected readonly themeMode: import("@cws/workspace").CwsThemeMode;
  /**
   * Embedded, the host owns the session, so there is no Sign out here (D-18). `signOut()` is
   * `logoutRedirect`, which would leave the host's page and end the tenant session, signing the user
   * out of the host as well.
   */
  protected readonly embedded: boolean;
  /**
   * The user's own trade-unit list (#103), a preference and never a permission. Optional: a host
   * without it offers no curation, as before.
   */
  protected readonly visibility: TradeUnitVisibilityStore | null;
  /** Whether the curation panel is open. Collapsed by default: it is a 1,044-row list. */
  protected readonly curating: import("@angular/core").WritableSignal<boolean>;
  /**
   * The curation panel, loaded on first open.
   *
   * 🔴 **A dynamic import, not a static one and not `@defer`** (#678). The chrome is in the initial
   * bundle, and the panel statically imported measured +6.9 kB of it, which crossed the 760 kB
   * warning. `@defer` measured worse again (764 kB), because its runtime came with it.
   */
  protected readonly curationPanel: import("@angular/core").WritableSignal<Type<unknown> | null>;
  private readonly curationHost;
  /**
   * Mounts the panel into its host once both exist. The host is created and destroyed with the
   * `@if`, so each opening gets a fresh, empty host and exactly one panel (pinned by a spec).
   */
  private readonly mountCuration;
  protected toggleCuration(): void;
  /** Ordered light → dark → system, so the two literal choices read as a pair. */
  protected readonly themeOptions: readonly {
    readonly value: ThemePreference;
    readonly label: string;
  }[];
  static ɵfac: i0.ɵɵFactoryDeclaration<UserMenuComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<UserMenuComponent, "cms-user-menu", never, {}, {}, never, never, true, never>;
}
/**
 * The module paths, for the route table's own spec to check itself against.
 *
 * 🔴 **Exported so the nav and the route table are verified against ONE list rather than two
 * hand-written ones.** Those are two strings in two files that have to agree, and nothing compared
 * them until the route table's spec existed — a nav entry pointing at a path with no route would have
 * passed every test in the workspace and 404'd in the browser.
 *
 * ⚠ **Every declared module, not the visible ones.** The route table must carry a route for Admin
 * whether or not this caller may see it: the guard refuses the *navigation*, and a missing route
 * would instead 404 — a different failure, with a worse message, that the guard could never reach.
 */
export declare const MODULE_PATHS: readonly string[];
/**
 * The whole Contract Workspace's chrome: top bar, module nav, trade-unit picker, user menu,
 * availability banner, the refusal notice and the shortcut layer, around a `<router-outlet>`.
 *
 * Standalone it is the root component the shell bootstraps; embedded (ADR-18) a host mounts it on a
 * route and passes `cwsRoutes()` as that route's children. It reads where it is mounted once, from
 * its own route, into {@link CwsMountBase}.
 */
export declare class CwsWorkspaceComponent {
  protected readonly auth: CmsAuthService;
  private readonly host;
  /**
   * Under a host the host's own header carries the brand, so there is no lockup (D-17). Its two
   * images resolve relative to the page and would 404 under a prefix anyway.
   */
  protected readonly embedded: boolean;
  /**
   * F1.4 - the availability gate, read by the banner above <main> and by every write screen.
   *
   * Provided once per workspace so there is ONE instance: two independent subscriptions could render
   * "CTRM is closed" beside an enabled Save, which is worse than either failure alone.
   */
  protected readonly availability: AvailabilityGate;
  private readonly permissions;
  /**
   * #411 — set when the permissions could not be read at all (`/me` answered `Unavailable`, or
   * failed). Said once here, beside the availability banner, because the cause is not any one
   * screen's; each screen still disables its CTRM writes with the reason at the control. A trade unit
   * that is merely not onboarded is said at the control only.
   */
  protected readonly permissionsUnavailable: import("@angular/core").Signal<boolean>;
  private readonly accessNotice;
  /**
   * The modules this caller may see.
   *
   * ⚠ **A computed over the context rather than a filtered constant**, because `roles()` is a signal
   * that fills in *after* first paint — the access token is acquired asynchronously. A list computed
   * once at construction would hide Admin from an administrator for the lifetime of the session.
   */
  protected readonly modules: import("@angular/core").Signal<{
    commands: readonly string[];
    module: CwsModule;
    label: string;
    exact: boolean;
    accessKey?: string;
    allowed?: (permissions: PermissionContext) => boolean;
  }[]>;
  /**
   * Where the workspace is mounted: `'/'` standalone, the host route's path embedded. Every chrome
   * link and shortcut is built under it (E9 PR 4, F9.10), so the chrome never links out of a host's
   * prefix. The brand link is the base itself.
   */
  protected readonly mountBase: CwsMountBase;
  /** The sentence explaining a refused navigation, or null. */
  protected readonly accessMessage: import("@angular/core").Signal<string | null>;
  /** #889: what the browser refused to remember this session, said on every screen until dismissed. */
  protected readonly storageRefusals: StorageRefusals;
  /**
   * Set when a logo image fails to load, which swaps in a text wordmark.
   *
   * Not defensive padding: a broken-image icon in the top bar of every screen is a worse failure
   * than a plain wordmark, and this kept the header usable before the assets existed.
   */
  protected readonly logoUnavailable: import("@angular/core").WritableSignal<boolean>;
  /**
   * The environment badge, or null in production.
   *
   * Naming the environment matters most when it is *not* production — the risk this guards is
   * someone acting on dev data believing it is real. In production the badge is noise.
   */
  protected readonly environmentLabel: import("@angular/core").WritableSignal<string | null>;
  constructor();
  /**
   * The global keyboard layer (docs/02a §4.1).
   *
   * ### 🔴 Driven from {@link MODULES}, so a nav entry and its shortcut cannot disagree
   *
   * The alternative — a second array of `{ keys, path }` beside the nav — is two lists that have to
   * agree with nothing comparing them, which is the shape `MODULE_PATHS` already exists to prevent
   * between the nav and the route table. Reading the same entries means a module added to the bar
   * either gets a key or does not, and can never get a key pointing somewhere else.
   *
   * ### 🔴 Gated on the same `allowed` predicate the nav is
   *
   * `available` reads {@link modules}, so `Alt+A` is registered only while Approvals is visible to
   * this caller. A shortcut that navigates to a screen the nav deliberately hides would be a hole
   * straight through F4.3a's gating — and it would be invisible, because nothing on screen would
   * suggest the key existed.
   *
   * ⚠ **`shell` scope, and this is the only place in the application allowed to use it**
   * (docs/02a §8). `shortcut-scopes.spec.ts` fails if a feature library registers at this scope.
   */
  private registerGlobalShortcuts;
  protected dismissAccessNotice(): void;
  /** Router commands for a module under the mount base: `['/', 'pricing']`, `['/workbench/cws', 'pricing']`. */
  private commandsFor;
  static ɵfac: i0.ɵɵFactoryDeclaration<CwsWorkspaceComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CwsWorkspaceComponent, "cws-workspace", never, {}, {}, never, never, true, never>;
}
/**
 * The workspace's route table: the module entry points of docs/02 §1.3 (ADR-18, E9 PR 3).
 *
 * **Mountable at `''` or as the `children` of a host's prefix route.** The standalone shell passes it
 * to `provideRouter` as is; a host mounts `CwsWorkspaceComponent` on its own route and passes this as
 * that route's children. A function rather than a constant, so every caller gets its own array and
 * none can mutate another's. ⚠ `withComponentInputBinding()` is the HOST's responsibility, because it
 * is a router feature: the record screen takes its contract number as a routed input and is blank
 * without it (HOST-CONTRACT, PR 6).
 *
 * Every route but one is guarded by `canUseContractsGuard` (FE-2, 0.3.0; `cwsAuthGuard` before it):
 * each one reads CTRM through the BFF, and every CTRM-backed endpoint needs `Admin` or `User` in the
 * `roles` claim (#36), so an unguarded route would render a screen whose every request 401s. A caller
 * whose sign-in fails, or whose token carries no Contracts role, is sent to the unguarded `access`
 * route, a notice that says which it was. **`access` is a reserved path under every mount** (public
 * contract, 0.3.0): a host must not route anything of its own there.
 */
export declare function cwsRoutes(): Routes;
/**
 * Everything the workspace needs, in one call: the standalone shell's `main.ts` and a host's mount
 * route both use it (ADR-18, E9 PR 3). It is `app.config.ts`'s provider list, moved here line by line
 * with its comments, plus the gate, the mount base, the theme and the configuration tokens.
 *
 * ⚠ **Not the router.** `provideRouter(cwsRoutes(), withComponentInputBinding())` stays with
 * whoever owns the page's router: the shell calls it, and a host mounts `cwsRoutes()` under its own.
 *
 * 🔴 **`provideCwsWorkspace.spec.ts` holds the golden list**: every token this must provide,
 * transcribed once from the shell's old `app.config.ts`. A seam dropped here fails there by name,
 * rather than as an `NG0201` on whichever screen first asks for it.
 */
export declare function provideCwsWorkspace(config: CwsWorkspaceConfig): EnvironmentProviders;
import { HttpClient, HttpErrorResponse, HttpParams } from "@angular/common/http";
import * as i0 from "@angular/core";
import { Injectable, inject } from "@angular/core";
import { CONSTRAINT_VALUE_LABELS, CONTRACTS_API_URL, CONTRACT_CODE_PREFIXES, CONTRACT_CODE_PREFIX_LABELS, CONTRACT_LAYOUT_SECTIONS, CONTRACT_TABS, LOCATION_SOURCE, REFERENCE_ROUTES, TRADE_UNIT_VALUES_SOURCE, commodityGroupsFrom, narrowToConfigured } from "@cws/domain-contracts";
import { AutoCalculationMode, BUNDLED_CONSTRAINT_DOCUMENT, CONSTRAINT_SOURCE, ConstraintCatalog, ContractComponent, ControlPattern, presentationFrom } from "@cws/shared-form-engine";
import { remoteError, remoteLoaded, remoteLoading } from "@cws/shared-ui";
import { catchError, combineLatest, distinctUntilChanged, from, map, of, shareReplay, startWith, switchMap, throwError } from "rxjs";
var HttpConstraintSource = class HttpConstraintSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	bundled = inject(BUNDLED_CONSTRAINT_DOCUMENT, { optional: true });
	snapshot$ = null;
	document() {
		this.snapshot$ ??= this.http.get(`${this.baseUrl}/meta/constraints`).pipe(map((document) => ({
			document,
			origin: "live"
		})), catchError((error) => {
			const load = this.bundled;
			return load === null ? throwError(() => error) : from(load()).pipe(map((document) => ({
				document,
				origin: "bundled"
			})));
		}), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
		return this.snapshot$;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpConstraintSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpConstraintSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpConstraintSource,
	decorators: [{ type: Injectable }]
});
function provideHttpConstraintSource() {
	return {
		provide: CONSTRAINT_SOURCE,
		useClass: HttpConstraintSource
	};
}
var HttpFormConfigSource = class HttpFormConfigSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	constraintSource = inject(CONSTRAINT_SOURCE, { optional: true }) ?? new HttpConstraintSource();
	referenceCache = /* @__PURE__ */ new Map();
	locations = inject(LOCATION_SOURCE);
	tradeUnitValues = inject(TRADE_UNIT_VALUES_SOURCE);
	configuredValues(key, resolved$) {
		const empty = /* @__PURE__ */ new Map();
		return resolved$.pipe(map((resolution) => resolution === "pending" || resolution === "unavailable" ? key.locationCode ?? "" : resolution.tradeUnitAttributes?.tradeUnit ?? key.locationCode ?? ""), distinctUntilChanged(), switchMap((tradeUnit) => tradeUnit === "" || tradeUnit === "*" || tradeUnit === "0000" ? of(empty) : this.tradeUnitValues.values(tradeUnit).pipe(map((rows) => {
			const grouped = /* @__PURE__ */ new Map();
			for (const row of rows) {
				const bucket = grouped.get(row.componentName) ?? [];
				bucket.push({
					value: row.value,
					include: row.include
				});
				grouped.set(row.componentName, bucket);
			}
			return grouped;
		}), catchError(() => of(empty)))), startWith(empty));
	}
	load(key) {
		const codeSets = CONTRACT_CODE_PREFIXES.map((prefix) => [`Codes:${prefix}`, this.referenceSet(`Codes:${prefix}`)]);
		const resolved$ = this.resolve(key).pipe(shareReplay({
			bufferSize: 1,
			refCount: true
		}));
		return combineLatest([
			resolved$,
			this.constraints(),
			this.referenceSet("Commodities"),
			this.referenceSet("MarketZones"),
			this.tradeUnits(),
			combineLatest(codeSets.map(([, stream]) => stream)),
			this.configuredValues(key, resolved$)
		]).pipe(map(([resolved, constraints, commodities, marketZones, tradeUnits, codeValues, configuredValues]) => {
			if (resolved === "pending" || constraints.status === "loading" || constraints.status === "idle") return remoteLoading();
			if (resolved === "unavailable" && constraints.status === "error") return remoteError(constraints.error);
			const values = {
				Commodities: commodities,
				MarketZones: marketZones,
				Locations: tradeUnits,
				...Object.fromEntries(codeSets.map(([set], index) => [set, codeValues[index]]))
			};
			const unavailableLists = Object.keys(values).filter((set) => {
				const fetched = values[set];
				return fetched !== void 0 && fetched !== null && fetched.length === 0;
			}).map((set) => set.startsWith("Codes:") ? CONTRACT_CODE_PREFIX_LABELS[set.slice(6)] ?? set : set);
			const tradeUnit = key.locationCode ?? "0000";
			if (resolved === "unavailable") {
				const snapshot = constraints.value;
				return remoteLoaded({
					config: buildConfig(tradeUnit, snapshot.document, values),
					tradeUnit: defaultTradeUnitAttributes(tradeUnit),
					defaultsOnly: true,
					unavailableLists,
					constraints: snapshot,
					...snapshot.origin === "bundled" ? { constraintsNotice: "bundled" } : {}
				});
			}
			return remoteLoaded({
				config: toResolvedConfig(resolved, values, configuredValues, constraints.status === "loaded" ? constraints.value.document : null),
				tradeUnit: {
					tradeUnit: resolved.tradeUnitAttributes.tradeUnit,
					autoCalculationMode: toAutoCalculationMode(resolved.tradeUnitAttributes.autoCalculationMode),
					pendingContractsEnabled: resolved.tradeUnitAttributes.pendingContractsEnabled,
					...homeGridColumnsOf(resolved.tradeUnitAttributes.homeGridColumns) ?? {}
				},
				provenance: resolved.provenance,
				unavailableLists,
				...constraints.status === "loaded" && constraints.value.origin === "live" ? { constraints: constraints.value } : { constraintsNotice: "unavailable" }
			});
		}), startWith(remoteLoading()));
	}
	resolve(key) {
		let params = new HttpParams();
		if (key.contractNumber !== void 0 && key.contractNumber !== "") params = params.set("contractNumber", key.contractNumber);
		else {
			if (key.contractTypeClass !== void 0 && key.contractTypeClass !== "") params = params.set("contractTypeClass", key.contractTypeClass);
			if (key.locationCode !== void 0 && key.locationCode !== "") params = params.set("locationCode", key.locationCode);
			if (key.commodityCode !== void 0 && key.commodityCode !== "") params = params.set("commodityCode", key.commodityCode);
		}
		return this.http.get(`${this.baseUrl}/form-configurations/resolve`, { params }).pipe(map((response) => response), catchError(() => of("unavailable")), startWith("pending"));
	}
	constraints() {
		return this.constraintSource.document().pipe(map((snapshot) => remoteLoaded(snapshot)), catchError((error) => of(remoteError(toConstraintsError(error)))), startWith(remoteLoading()));
	}
	referenceSet(set) {
		const cached = this.referenceCache.get(set);
		if (cached !== void 0) return cached;
		const [route, prefix] = set.startsWith("Codes:") ? [REFERENCE_ROUTES.codes, set.slice(6)] : [set, null];
		const url = prefix === null ? `${this.baseUrl}/reference/${route}` : `${this.baseUrl}/reference/${route}?prefix=${encodeURIComponent(prefix)}`;
		const stream = this.http.get(url).pipe(map((response) => (response.items ?? []).filter((item) => item.code !== null && item.code !== "").map((item) => ({
			code: item.code,
			description: item.description ?? item.code,
			...typeof item.groupCode === "string" && item.groupCode.trim() !== "" ? { group: item.groupCode.trim() } : {}
		}))), catchError(() => of([])), startWith(null), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
		this.referenceCache.set(set, stream);
		return stream;
	}
	tradeUnits() {
		return this.locations.list().pipe(map((state) => state.status === "loaded" ? state.value.locations.map((location) => ({
			code: location.code,
			description: [location.name, location.companyName].filter((part) => part !== null && part !== "").join(" · ") || location.code
		})) : []), catchError(() => of([])));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpFormConfigSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: HttpFormConfigSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: HttpFormConfigSource,
	decorators: [{ type: Injectable }]
});
const LAYOUT_BY_COMPONENT = new Map(CONTRACT_LAYOUT_SECTIONS.flatMap((section) => section.fields.map((field) => [field.componentName, field])));
function toResolvedConfig(response, values, configuredValues = /* @__PURE__ */ new Map(), document = null) {
	const catalog = document === null ? null : ConstraintCatalog.from(document);
	const sections = response.config.sections.map((section) => ({
		componentName: section.componentName,
		label: section.label,
		tab: section.tab,
		order: section.order,
		visible: section.visible,
		mandatedFlags: section.mandatedFlags,
		fields: section.fields.flatMap((field) => {
			const layout = LAYOUT_BY_COMPONENT.get(field.componentName);
			if (layout === void 0) return [];
			const { allowedValues: offered, unavailable } = codeListFor(layout, values, catalog);
			const allowedValues = narrowToConfigured(offered, configuredValues.get(field.componentName) ?? []);
			const control = controlFor(layout, unavailable);
			const presentation = presentationFrom(field.presentation);
			return [{
				componentName: field.componentName,
				ctrmField: layout.ctrmField,
				label: presentation?.label ?? field.label,
				...presentation === void 0 ? {} : { presentation },
				controlPattern: control.controlPattern,
				order: field.order,
				behaviour: field.behaviour,
				mandatedFlags: field.mandatedFlags,
				...allowedValues.length > 0 ? { allowedValues } : {},
				...control.warningText !== void 0 ? { warningText: control.warningText } : {},
				...layout.searchSet !== void 0 ? { searchSet: layout.searchSet } : {},
				...field.constraints !== null ? { constraints: field.constraints } : {}
			}];
		})
	}));
	const collections = collectionsFrom(response.config.collections);
	const remarkTypes = remarkTypesFrom(response.config.remarkTypes);
	return {
		tradeUnit: response.config.tradeUnit,
		version: response.config.version,
		tabs: response.config.tabs,
		sections,
		...collections === void 0 ? {} : { collections },
		...remarkTypes === void 0 ? {} : { remarkTypes }
	};
}
function remarkTypesFrom(raw) {
	if (raw === null || typeof raw !== "object" || Array.isArray(raw)) return;
	const remarkTypes = {};
	for (const [code, entry] of Object.entries(raw)) {
		if (entry === null || typeof entry !== "object") continue;
		const { visible, required } = entry;
		if (typeof visible === "boolean" && typeof required === "boolean") remarkTypes[code] = {
			visible,
			required
		};
	}
	return remarkTypes;
}
function collectionsFrom(raw) {
	if (raw === null || typeof raw !== "object" || Array.isArray(raw)) return;
	const collections = {};
	for (const [name, entry] of Object.entries(raw)) {
		if (entry === null || typeof entry !== "object") continue;
		const { excludeFromCopy, excludeFromTemplateCopy } = entry;
		if (typeof excludeFromCopy !== "boolean") continue;
		collections[name] = {
			excludeFromCopy,
			excludeFromTemplateCopy: excludeFromTemplateCopy === true
		};
	}
	return collections;
}
function toAutoCalculationMode(value) {
	return value === AutoCalculationMode.Price || value === AutoCalculationMode.Basis ? value : AutoCalculationMode.None;
}
function homeGridColumnsOf(value) {
	return Array.isArray(value) && value.every((key) => typeof key === "string") ? { homeGridColumns: value } : null;
}
function defaultTradeUnitAttributes(tradeUnit) {
	return {
		tradeUnit,
		autoCalculationMode: AutoCalculationMode.None,
		pendingContractsEnabled: false
	};
}
const DEFAULT_BEHAVIOUR$1 = {
	visible: true,
	required: false,
	readOnly: false,
	borderWarning: false,
	excludeFromCopy: false,
	excludeFromTemplateCopy: false
};
function buildConfig(tradeUnit, document, values) {
	const catalog = ConstraintCatalog.from(document);
	const sections = CONTRACT_LAYOUT_SECTIONS.map((section, sectionIndex) => ({
		componentName: section.id,
		label: section.title,
		tab: section.tab,
		order: sectionIndex,
		visible: true,
		mandatedFlags: [],
		fields: section.fields.map((field, fieldIndex) => toFieldConfig(field, fieldIndex, catalog, values))
	}));
	return {
		tradeUnit,
		version: `constraints-v${document.version}`,
		tabs: CONTRACT_TABS.map((tab, index) => ({
			id: tab.id,
			label: tab.label,
			order: index + 1,
			visible: true
		})),
		sections
	};
}
function toFieldConfig(field, order, catalog, values) {
	const entry = catalog.field(field.ctrmField);
	const { allowedValues, unavailable } = codeListFor(field, values, catalog);
	const control = controlFor(field, unavailable);
	return {
		componentName: field.componentName,
		ctrmField: field.ctrmField,
		label: field.label,
		controlPattern: control.controlPattern,
		order,
		behaviour: {
			...DEFAULT_BEHAVIOUR$1,
			readOnly: field.locked === true || !ConstraintCatalog.isWritable(entry)
		},
		mandatedFlags: [],
		...allowedValues.length > 0 ? { allowedValues } : {},
		...control.warningText !== void 0 ? { warningText: control.warningText } : {},
		...field.searchSet !== void 0 ? { searchSet: field.searchSet } : {},
		...toFieldConstraints(entry) ? { constraints: toFieldConstraints(entry) } : {}
	};
}
function codeListFor(field, values, catalog) {
	if (field.valuesFromConstraints === true) {
		const codes = catalog === null ? void 0 : ConstraintCatalog.allowedValues(catalog.field(field.ctrmField));
		const labels = CONSTRAINT_VALUE_LABELS[field.componentName] ?? {};
		return {
			allowedValues: (codes ?? []).map((code) => ({
				code,
				description: labels[code] ?? code
			})),
			unavailable: codes === void 0
		};
	}
	if (field.referenceSet !== void 0) {
		const fetched = field.referenceSet === "CommodityGroups" ? commodityGroupsFrom(values.Commodities) : values[field.referenceSet];
		return {
			allowedValues: fetched ?? [],
			unavailable: fetched !== void 0 && fetched !== null && fetched.length === 0
		};
	}
	return {
		allowedValues: [],
		unavailable: false
	};
}
function controlFor(field, unavailable) {
	if (unavailable && field.controlPattern === ControlPattern.SearchableCodeCombo) return {
		controlPattern: ControlPattern.TextWithCounter,
		warningText: "Code list unavailable — enter the code."
	};
	return { controlPattern: field.controlPattern };
}
function toFieldConstraints(entry) {
	if (entry === void 0) return;
	if (entry.type === "string" && entry.maxLength !== void 0) return { maxLength: entry.maxLength };
	const numeric = ConstraintCatalog.numeric(entry);
	if (numeric !== void 0) return { decimalPlaces: numeric.scale };
}
function toConstraintsError(error) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 401 || error.status === 403) return {
			message: "You are not signed in, or your account cannot create contracts.",
			correlationId: problem?.traceId
		};
		return {
			message: "We could not load the contract field definitions, so the form cannot enforce CTRM’s field limits. Rather than accept values CTRM would reject, the form is not shown.",
			correlationId: problem?.traceId
		};
	}
	return { message: "We could not load the contract field definitions. Please try again." };
}
const DEFAULT_BEHAVIOUR = {
	visible: true,
	required: false,
	readOnly: false,
	borderWarning: false,
	excludeFromCopy: false,
	excludeFromTemplateCopy: false
};
function field(componentName, label, controlPattern, order, extra = {}) {
	return {
		componentName,
		label,
		controlPattern,
		order,
		behaviour: {
			...DEFAULT_BEHAVIOUR,
			...extra.behaviour ?? {}
		},
		mandatedFlags: extra.mandatedFlags ?? [],
		...extra.allowedValues ? { allowedValues: extra.allowedValues } : {},
		...extra.constraints ? { constraints: extra.constraints } : {},
		...extra.warningText ? { warningText: extra.warningText } : {}
	};
}
const PRICE_TYPES = [
	{
		code: "P",
		description: "Priced"
	},
	{
		code: "U",
		description: "Unpriced / Basis"
	},
	{
		code: "D",
		description: "Deferred"
	},
	{
		code: "V",
		description: "Variable"
	}
];
const UNITS = [
	{
		code: "BU",
		description: "Bushels"
	},
	{
		code: "CWT",
		description: "Hundredweight"
	},
	{
		code: "TON",
		description: "Tons"
	}
];
const MARKET_MONTHS = [
	{
		code: "H",
		description: "MARCH"
	},
	{
		code: "K",
		description: "MAY"
	},
	{
		code: "N",
		description: "JULY"
	}
];
const MOCK_CONTRACT_FORM_CONFIG = {
	tradeUnit: "1234",
	version: "mock-1",
	tabs: [
		{
			id: "contract",
			label: "Contract Info",
			order: 1,
			visible: true
		},
		{
			id: "pricing",
			label: "Pricing & Quantity",
			order: 2,
			visible: true
		},
		{
			id: "shipping",
			label: "Shipping Info",
			order: 3,
			visible: true
		},
		{
			id: "remarks",
			label: "Remarks",
			order: 4,
			visible: true
		},
		{
			id: "additional",
			label: "Additional fields",
			order: 5,
			visible: true
		}
	],
	sections: [
		{
			componentName: "ContractInfo",
			label: "Contract Info",
			tab: "contract",
			order: 10,
			visible: true,
			mandatedFlags: ["visible"],
			fields: [
				field(ContractComponent.PriceTypeCode, "Price Type", ControlPattern.SearchableCodeCombo, 10, {
					allowedValues: PRICE_TYPES,
					behaviour: {
						...DEFAULT_BEHAVIOUR,
						required: true
					},
					mandatedFlags: ["visible", "required"]
				}),
				field(ContractComponent.Quantity, "Quantity", ControlPattern.QuantityDecimal, 20, {
					behaviour: {
						...DEFAULT_BEHAVIOUR,
						required: true
					},
					constraints: {
						decimalPlaces: 3,
						allowsNegative: false
					}
				}),
				field(ContractComponent.QuantityUnitOfMeasure, "Quantity UM", ControlPattern.SearchableCodeCombo, 30, { allowedValues: UNITS }),
				field("CustomerContract", "Customer Contract", ControlPattern.TextWithCounter, 40, { constraints: { maxLength: 10 } }),
				field("ContractDate", "Contract Date", ControlPattern.MaskedDate, 50)
			]
		},
		{
			componentName: "Pricing",
			label: "Pricing",
			tab: "contract",
			order: 20,
			visible: true,
			mandatedFlags: [],
			fields: [
				field(ContractComponent.Price, "Price", ControlPattern.QuantityDecimal, 10, { constraints: {
					decimalPlaces: 4,
					allowsNegative: false
				} }),
				field(ContractComponent.BasisPrice, "Basis", ControlPattern.QuantityDecimal, 20, { constraints: {
					decimalPlaces: 4,
					allowsNegative: true
				} }),
				field(ContractComponent.HedgePrice, "Hedge", ControlPattern.QuantityDecimal, 30, { constraints: {
					decimalPlaces: 4,
					allowsNegative: false
				} }),
				field(ContractComponent.GradeAdjustment, "Grade Adj", ControlPattern.QuantityDecimal, 40, { constraints: {
					decimalPlaces: 4,
					allowsNegative: true
				} }),
				field(ContractComponent.FreightAdjustment, "Freight Adj", ControlPattern.QuantityDecimal, 50, { constraints: {
					decimalPlaces: 4,
					allowsNegative: true
				} }),
				field(ContractComponent.PriceUnitOfMeasure, "Price UM", ControlPattern.SearchableCodeCombo, 60, { allowedValues: UNITS }),
				field(ContractComponent.BasisMarketMonth, "Basis Market Month", ControlPattern.SearchableCodeCombo, 70, { allowedValues: MARKET_MONTHS })
			]
		},
		{
			componentName: "Broker",
			label: "Broker",
			tab: "contract",
			order: 30,
			visible: true,
			mandatedFlags: [],
			fields: [
				field(ContractComponent.BrokerId, "Broker", ControlPattern.EntityTypeahead, 10),
				field(ContractComponent.BrokerRate, "Broker Rate", ControlPattern.QuantityDecimal, 20, { constraints: {
					decimalPlaces: 4,
					allowsNegative: false
				} }),
				field("BrokerContract", "Broker Contract", ControlPattern.TextWithCounter, 30, { constraints: { maxLength: 10 } }),
				field(ContractComponent.BrokerUnitOfMeasure, "Broker UM", ControlPattern.SearchableCodeCombo, 40, { allowedValues: UNITS })
			]
		},
		{
			componentName: "Remarks",
			label: "Remarks",
			tab: "remarks",
			order: 40,
			visible: true,
			mandatedFlags: [],
			fields: [
				field("Remarks", "Remark", ControlPattern.TextWithCounter, 10, {
					constraints: { maxLength: 72 },
					warningText: "Remarks print on the contract sent to the customer.",
					behaviour: {
						...DEFAULT_BEHAVIOUR,
						borderWarning: true
					}
				}),
				field("InternalNote", "Internal Note", ControlPattern.MultilineNote, 20, { constraints: { maxLength: 2e3 } }),
				field("PrintImmediately", "Print Immediately", ControlPattern.ToggleFlag, 30)
			]
		}
	]
};
const MOCK_TRADE_UNIT_ATTRIBUTES = {
	tradeUnit: "1234",
	autoCalculationMode: AutoCalculationMode.Price,
	pendingContractsEnabled: false
};
var MockFormConfigSource = class MockFormConfigSource {
	load() {
		return of(remoteLoaded({
			config: MOCK_CONTRACT_FORM_CONFIG,
			tradeUnit: MOCK_TRADE_UNIT_ATTRIBUTES
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: MockFormConfigSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: MockFormConfigSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: MockFormConfigSource,
	decorators: [{ type: Injectable }]
});
export { HttpConstraintSource, HttpFormConfigSource, MOCK_CONTRACT_FORM_CONFIG, MOCK_TRADE_UNIT_ATTRIBUTES, MockFormConfigSource, buildConfig, provideHttpConstraintSource, toResolvedConfig };

//# sourceMappingURL=cws-features-contract-entry.mjs.map
import { ConfiguredValue, ContractReferenceSet, FormConfigBundle, FormConfigResolutionKey, FormConfigSource } from "@cws/domain-contracts";
import { AllowedValue, ConstraintDocument, ConstraintSnapshot, ConstraintSource, FieldBehaviour, FieldConstraints, FormConfigProvenance, FormTabConfig, ResolvedFormConfig } from "@cws/shared-form-engine";
import { RemoteData } from "@cws/shared-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
import { Provider } from "@angular/core";
/**
 * **The record screen's configuration: resolved by the server, rendered by the client.**
 *
 * ✅ **F2.1 exists** — `GET /api/v1/form-configurations/resolve` (ADR-17) serves the resolved
 * configuration for a contract or a set of dimensions, with provenance. This class calls it and
 * overlays the rendering mechanics the server deliberately does not own.
 *
 * | Piece | Source |
 * |---|---|
 * | Which tabs exist, which sections are on them, per-field behaviour, order, labels | `GET /form-configurations/resolve` — **configuration** |
 * | Control patterns, dropdown wiring | `contract-layout.ts (@cws/domain-contracts)` — rendering, not policy |
 * | Column widths, precision, scale | folded into the resolve payload from `constraints.json` server-side (ADR-7) |
 * | Commodity and market-zone dropdowns | `GET /api/v1/reference/{set}` |
 * | Trade unit dropdown | `GET /api/v1/locations`, via the shell's cached source |
 *
 * ### The split is deliberate, and it is not arbitrary
 *
 * The server owns everything an admin can change — visibility, requiredness, read-only, order, tabs,
 * labels. The client owns how a control is *drawn*, because a control pattern is a property of the
 * widget rather than of the business rule, and shipping `ControlPattern.MaskedDate` through an API
 * would make the enum a wire contract that could not be refactored.
 *
 * ### Failure behaviour, and why the fallback exists rather than an error screen
 *
 * **A failed resolve falls back to assembling the configuration client-side** from the layout plus
 * `/meta/constraints`, flagged `defaultsOnly` so the screen can say so. That is strictly better than
 * failing: the layout and CTRM's own constraint document are enough to render a correct, safe form,
 * and refusing to show a contract because a *configuration* service is down would make the record
 * screen unavailable for a reason that has nothing to do with the contract.
 *
 * **Constraints remain required on that path.** Without the document there are no widths, and a form
 * that accepts 40 characters into a `char(7)` produces a CTRM rejection at save with no clue why.
 *
 * **Reference sets are optional throughout.** A dropdown that cannot load degrades to its static
 * values or to a free-text code, because the alternative — an empty combo — is a closed list of
 * nothing that blocks entry entirely. Three of the nine sets are empty on UAT and two refuse an
 * unparameterised call (#44, #83), so this is the expected path rather than the exceptional one, and
 * the screen names the missing lists rather than rendering them blank.
 */
export declare class HttpFormConfigSource implements FormConfigSource {
  private readonly http;
  private readonly baseUrl;
  /**
   * The constraint document for the session (#732): one read shared with every other consumer, with
   * the app's bundled copy behind it. Replaceable through `CONSTRAINT_SOURCE`.
   */
  private readonly constraintSource;
  /**
   * One in-flight/replayed stream per reference list, for the session.
   *
   * Keyed on the SET, not on the field. Six unit-of-measure fields share prefix `UM`, so without this
   * a form load would issue one request per field rather than one per list (#219 criterion 3).
   */
  private readonly referenceCache;
  private readonly locations;
  private readonly tradeUnitValues;
  /**
   * The trade unit's configured allowed values (F8.2), grouped by component.
   *
   * 🔴 **Settles as an EMPTY MAP when there is no trade unit or the call fails**, which
   * {@link toResolvedConfig} reads as *no narrowing*. The opposite default would empty every coded
   * combo on the form the moment the configuration service hiccupped, and the user would be looking
   * at a record they cannot complete with nothing saying why.
   */
  private configuredValues;
  load(key: FormConfigResolutionKey): Observable<RemoteData<FormConfigBundle>>;
  /**
   * `GET /api/v1/form-configurations/resolve`.
   *
   * Emits `'pending'` while in flight and `'unavailable'` on any failure — the caller then assembles
   * the fallback. The error is deliberately swallowed rather than surfaced: a configuration service
   * that is down must not take the record screen with it, and `defaultsOnly` is how the user is told.
   */
  private resolve;
  /**
   * The constraint document, through the session's constraint source (#732): `GET
   * /api/v1/meta/constraints` read once for every consumer, or the app's bundled copy when that read
   * fails. An error here means neither was available.
   */
  private constraints;
  /**
   * One reference set, degraded to an empty list on any failure.
   *
   * Deliberately swallows the error rather than surfacing it: a missing commodity list is a reduced
   * screen, not a broken one, and #44/#83 make an unavailable set routine. The empty result is
   * reported to the user through `unavailableLists`, so it is visible without being fatal.
   */
  private referenceSet;
  /**
   * The trade unit list, through the shell's own cached `LOCATION_SOURCE`.
   *
   * Reused rather than re-fetched: it is ~1044 rows, the shell's trade-unit picker has already asked
   * for it, and `HttpLocationSource` holds one copy for the session.
   *
   * Shown as `CODE — Name (Company)`, because a bare four-digit code identifies a trade unit to CTRM
   * and not to a trader — the same reasoning as the grid heading and the picker.
   */
  private tradeUnits;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpFormConfigSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** `GET /api/v1/form-configurations/resolve`. */
interface ResolveResponse {
  readonly config: {
    readonly tradeUnit: string;
    readonly version: string;
    readonly tabs: readonly FormTabConfig[];
    readonly sections: readonly ResolvedSection[];
    /** #959's collection copy flags (PR #991). Absent from a server without it; see {@link collectionsFrom}. */
    readonly collections?: unknown;
    /** #1022's remark type flags (#1006). Absent from a server without it; see {@link remarkTypesFrom}. */
    readonly remarkTypes?: unknown;
  };
  readonly tradeUnitAttributes: {
    readonly tradeUnit: string;
    readonly autoCalculationMode: string;
    readonly pendingContractsEnabled: boolean;
    /** #747's attribute. Not sent by the server until #747 lands. */
    readonly homeGridColumns?: unknown;
  };
  readonly provenance: FormConfigProvenance;
}
interface ResolvedSection {
  readonly componentName: string;
  readonly label: string;
  readonly tab: string;
  readonly order: number;
  readonly visible: boolean;
  readonly mandatedFlags: readonly string[];
  readonly fields: readonly ResolvedField[];
}
interface ResolvedField {
  readonly componentName: string;
  readonly label: string;
  readonly order: number;
  readonly behaviour: FieldBehaviour;
  readonly mandatedFlags: readonly string[];
  readonly constraints: FieldConstraints | null;
  /**
   * #221's per-field presentation, from #705. Absent from a server that predates it, which
   * {@link presentationFrom} reads as "the layout's value" — the soft failure the contract asks for.
   */
  readonly presentation?: unknown;
}
/**
 * Turns the resolve payload into what the form engine renders.
 *
 * ⚠ **A resolved field with no layout row is DROPPED, and that is the safe direction.** The registry
 * and the layout are generated from the same file, so a mismatch means one side is stale — and a
 * field with no control pattern cannot be drawn at all. Dropping it renders the rest of the record;
 * inventing a pattern would put a text box where a date picker belongs and let a user type a value
 * CTRM refuses.
 */
export declare function toResolvedConfig(response: ResolveResponse, values: ReferenceValues,
/**
 * The trade unit's configured allowed values (F8.2), keyed by component name.
 *
 * 🔴 **A component absent from this map is NOT narrowed** — absence is "no opinion", never
 * "allow nothing". Defaulted to empty so every existing caller keeps its behaviour exactly, which
 * is also the correct behaviour when the configuration service cannot be reached.
 */
configuredValues?: ReadonlyMap<string, readonly ConfiguredValue[]>,
/**
 * The constraint document, for the dropdowns whose codes are its `allowedValues` (#1007). `null`
 * when no copy could be read, which degrades those combos to a typed code.
 */
document?: ConstraintDocument | null): ResolvedFormConfig;
/**
 * Reference values by set, empty where the set could not be loaded.
 *
 * ⚠ **Partial, since #219 took the set count from 3 to 20.** A caller that supplies only the lists it
 * cares about — every test fixture, and the offline harness — must not be forced to enumerate
 * seventeen code tables it has no opinion about.
 *
 * 🔴 **Three states, not two, and an ABSENT set is not the same as an EMPTY one.**
 *
 * | | |
 * |---|---|
 * | absent (`undefined`) | the caller expressed no opinion — a fixture that names two lists is not asserting the other fifteen are broken |
 * | `null` | the fetch is in flight |
 * | `[]` | settled, and CTRM has no rows — **the only state that degrades a combo to a typed code** |
 *
 * ⚠ The comment this replaced claimed *"a dropdown that cannot load degrades to a typed code"*, and
 * that was **not what the code did** — an empty list produced a combo with zero options, which is the
 * closed list of nothing #219 criterion 7 exists to forbid. It is true now.
 */
type ReferenceValues = Readonly<Partial<Record<ContractReferenceSet, readonly AllowedValue[] | null>>>;
/**
 * Turns the layout plus the fetched document into the payload F2.1 will eventually serve.
 *
 * The `version` is the constraint document's own version rather than an invented string, so the ETag
 * this config would carry actually tracks something real.
 */
export declare function buildConfig(tradeUnit: string, document: ConstraintDocument, values: ReferenceValues): ResolvedFormConfig;
/**
 * **The CTRM constraint document for the session (#732, F2.4, ADR-7).**
 *
 * `GET /api/v1/meta/constraints`, read once and shared: the form-config source, the form builder and
 * the counters all key on it, and it changes only when the API is redeployed.
 *
 * 🔴 **Not root-provided, by rule (D-16; `no-root-provision.spec.ts`).** It injects `HttpClient`, and a
 * root-provided class would get the HOST's `HttpClient` under a host, with no CWS bearer. Instead
 * `HttpFormConfigSource` creates it in its own injection context, so it uses the workspace's
 * `HttpClient`. `LazyFormConfigSource` makes one `HttpFormConfigSource` per workspace, so there is one
 * of these, and one read, per session.
 *
 * ### When the read fails
 *
 * - **With a bundled copy** (`BUNDLED_CONSTRAINT_DOCUMENT`, supplied by the app): that copy, flagged
 *   `bundled` so the screen can say its limits are the ones built into the app.
 * - **Without one** (a host that supplies none): the error, unchanged. Never a guessed document.
 *
 * ⚠ **A failure is not cached.** `shareReplay` resets on error, so the next consumer reads the live
 * document again rather than being handed a failure from earlier in the session. A bundled snapshot
 * IS cached: it completes normally, and retrying a failing server on every screen would only slow
 * each one down.
 */
export declare class HttpConstraintSource implements ConstraintSource {
  private readonly http;
  private readonly baseUrl;
  private readonly bundled;
  private snapshot$;
  document(): Observable<ConstraintSnapshot>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HttpConstraintSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * `CONSTRAINT_SOURCE` as this class, for a route's `providers` (#924: the Admin section). A provider rather
 * than the class, so a library that wires it (`@cws/workspace`) needs no dependency on the token's own
 * library. Route-level only, never root (D-16), for the reason above.
 */
export declare function provideHttpConstraintSource(): Provider;
/**
 * A grain trade unit's contract form, near enough to the real thing to be worth clicking.
 *
 * Maximum lengths are the real CTRM column widths from `constraints.json` (ADR-7):
 * `customer_contract` 10, `remark_note` 72.
 */
export declare const MOCK_CONTRACT_FORM_CONFIG: ResolvedFormConfig;
/** Price mode, so BR-004 computes Price and locks it the moment an operand is entered. */
export declare const MOCK_TRADE_UNIT_ATTRIBUTES: {
  tradeUnit: string;
  autoCalculationMode: "Price";
  pendingContractsEnabled: boolean;
};
/**
 * Resolves immediately, but still through `RemoteData` — so `<cms-async-container>` is genuinely
 * exercised and swapping in the HTTP source changes nothing downstream.
 */
export declare class MockFormConfigSource implements FormConfigSource {
  load(): Observable<RemoteData<FormConfigBundle>>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MockFormConfigSource, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
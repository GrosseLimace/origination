import * as i0 from "@angular/core";
import { OnInit } from "@angular/core";
import { Routes } from "@angular/router";
import { AddendumFieldMapping, AddendumTemplate, AddendumType, ConfigFieldBehaviour, ConfigRemarkTypeBehaviour, ConfigTab, FormConfigAuditTrail, FormConfigDetail, FormConfigListResponse, FormConfigPreview, FormConfigRow, Role, RoleAssignment } from "@cws/domain-contracts";
import { ConstraintDocument, FieldPresentation } from "@cws/shared-form-engine";
import { ExportField, GridRowAction, MutationOutcome, RemoteData } from "@cws/shared-ui";
/**
 * **The Admin section's shell** (#825): the section's own navigation beside a routed page.
 *
 * Admin used to be one page stacking four unrelated areas. Each is now a route of its own (see
 * `adminRoutes()`), and this frames them: an Overview link, then each area this account may use, from
 * the one list the overview reads too (`ADMIN_AREAS`). A side list on a wide screen; a scrolling row
 * above the page on a narrow one.
 *
 * ⚠ **Kept as `AdminPageComponent`, selector `cms-admin-page`**, though it is now a shell: the class
 * is published, and the embedding host's provider closure is keyed on it.
 *
 * Provides `AdminScope` for the section, read once (#696): the navigation and the overview hide an
 * Admin-only area from an account KNOWN not to hold Admin, and the pages read the same answer.
 *
 * ⚠ The links are relative to this component's route, so under a host they stay inside its prefix.
 */
export declare class AdminPageComponent {
  private readonly access;
  /** The areas this account may use. Unknown is not "not Admin": the server decides. */
  protected readonly areas: import("@angular/core").Signal<import("@cws/features-admin").AdminArea[]>;
  protected readonly linkClass = "cws:block cws:whitespace-nowrap cws:rounded cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60 cws:aria-[current=page]:bg-slate-100 cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:bg-slate-700 cws:dark:aria-[current=page]:text-sky-300";
  static ɵfac: i0.ɵɵFactoryDeclaration<AdminPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AdminPageComponent, "cms-admin-page", never, {}, {}, never, never, true, never>;
}
/**
 * **The Admin section's pages, as children of `AdminPageComponent`** (#825).
 *
 * One route per administrative job, from `ADMIN_AREAS`; an area's tabs are child routes, so each is
 * linkable and Back moves between them. A page receives its tab as `data.view`, bound to its `view`
 * input by `withComponentInputBinding()` (the router feature the workspace already requires of a host).
 * Mounted on its own, without a `view`, a page renders every view at once, as it did on the old single
 * page, which is what its spec and the playground's single-page routes rely on.
 *
 * ⚠ A path the section does not have lands on the overview rather than on a blank outlet.
 *
 * A function, like `cwsRoutes()`, so every caller gets its own array.
 */
export declare function adminRoutes(): Routes;
/**
 * **The Admin section's areas, in one place** (#825).
 *
 * The shell's navigation, the overview's cards and the route table all read this list, so the three
 * cannot disagree about what Admin contains, what an area is called, or who sees it.
 *
 * Each area is one administrative job, with a route of its own. `views` are the tabs inside one job:
 * closely related views that share its title and purpose, each with a route of its own as well, so a
 * tab can be linked to and the browser's Back button moves between them.
 */
export interface AdminView {
  /** The view's segment under its area. `''` is the area's default view. */
  readonly path: string;
  readonly label: string;
}
export interface AdminArea {
  /** The area's segment under `admin`. */
  readonly path: string;
  readonly title: string;
  /** One sentence for the overview card and the navigation's description. */
  readonly summary: string;
  /**
   * Shown only to an account that is not KNOWN to lack the Admin role (#696). Unknown still sees it,
   * because hiding an Admin's area while `/me` is slow would be the worse failure; the server decides.
   */
  readonly adminOnly: boolean;
  /** The area's tabs, or none. */
  readonly views: readonly AdminView[];
}
export declare const ADMIN_AREAS: readonly AdminArea[];
/** An area by its path. Throws for a path the list does not hold, which is a programming error. */
export declare function adminArea(path: string): AdminArea;
/**
 * **The placeholders in a template's text, and the field each one prints** (#924).
 *
 * Pure, so the page, the mapping list and the preview read one answer, and each rule here can be shown
 * to fire against a fixture built to break it.
 *
 * ### 🔴 The pattern is the server's, character for character
 *
 * `AddendumRules.PlaceholderPattern` is `\{\{\s*(?<name>[A-Za-z0-9_]+)\s*\}\}`. A placeholder this
 * screen did not see would reach the server unmapped and be refused there; one it saw that the server
 * does not would be mapped for nothing. The e-signature anchors (`{{sig__es_:signer1:signature}}`)
 * carry colons, so neither side matches them.
 */
declare const PLACEHOLDER_PATTERN: RegExp;
/** The placeholder names in a template's text, each once, in the order they first appear. */
declare function templatePlaceholders(content: string | null | undefined): string[];
/**
 * The mapping the editor holds: placeholder to field. `''` is a placeholder the administrator left
 * with no field on purpose, which is different from one never touched (absent), because only an
 * untouched one takes a suggestion.
 */
type PlaceholderMappings = Readonly<Record<string, string>>;
/** The editor's mappings from a template's saved ones. */
declare function mappingsOf(fields: readonly AddendumFieldMapping[]): PlaceholderMappings;
/** One line of the placeholder list. */
interface PlaceholderRow {
  readonly placeholder: string;
  /** The field it prints, or `''` for none yet. */
  readonly field: string;
  /**
   * `false` for a mapping a saved template carries whose placeholder is no longer in the text. Kept,
   * and sent, until removed: dropping it on an unrelated save would change the template's version.
   */
  readonly inText: boolean;
  /** The field came from a name match, not from a pick. Shown, so it is never mistaken for a choice. */
  readonly suggested: boolean;
}
/**
 * The list the screen shows: every placeholder in the text, in order, then every saved mapping whose
 * placeholder the text no longer holds.
 *
 * `suggest` names the field a placeholder's own name matches exactly, if any. It fills only a
 * placeholder the administrator has not touched.
 */
declare function placeholderRows(content: string | null | undefined, mappings: PlaceholderMappings, suggest?: (placeholder: string) => string | null): PlaceholderRow[];
/** The placeholders in the text that print nothing yet: the server refuses these, so the screen does first. */
declare function unmappedPlaceholders(rows: readonly PlaceholderRow[]): string[];
/**
 * The server's sentence for unmapped placeholders (`AddendumRules.FieldProblems`), sorted as it sorts
 * them, so the refusal reads the same whichever side says it.
 */
declare function unmappedPlaceholdersMessage(placeholders: readonly string[]): string;
/**
 * What a save sends as `fields`: every mapped row, in the list's order (the text's, then the kept
 * mappings). The same `{ placeholder, field }` pairs as the old box sent. ⚠ Order carries nothing: the
 * server sorts by placeholder before it compares or stores (`AddendumAdminService.TemplateDraft`), so a
 * template opened and saved unchanged keeps its version.
 */
declare function fieldsOf(rows: readonly PlaceholderRow[]): AddendumFieldMapping[];
/** One field the picker offers. */
interface FieldOption {
  readonly value: string;
  readonly label: string;
}
/** A group of them, one `<optgroup>`. */
interface FieldOptionGroup {
  readonly label: string;
  readonly options: readonly FieldOption[];
}
/**
 * The CWS `addendum_*` fields a template's special types carry, one group per product.
 *
 * With no picked type that selects a product (none picked yet, or a StoneX type), every product's
 * fields are offered, each under its product's name, because hiding them all would leave nothing to
 * pick while the types are still being chosen.
 */
declare function addendumFieldGroups(specialTypes: readonly string[]): FieldOptionGroup[];
/** One field the server fills in itself, so neither the trader nor CTRM supplies it. */
interface ServerSuppliedField {
  readonly field: string;
  readonly label: string;
  /** Address line 2 and phone: an empty one drops its line. Every other field refuses a blank at render. */
  readonly optional: boolean;
  /** What the preview prints for it: invented, and recognisable as such. */
  readonly sample: string;
}
/** One group of them, offered under its own heading. */
interface ServerSuppliedFieldGroup {
  readonly label: string;
  readonly fields: readonly ServerSuppliedField[];
}
/**
 * **The fields the server supplies at render** (#1027, #1037; #1038): the contract customer's
 * merchandising name and address from the GraphQL customer master, and the addendum date the server
 * stamps.
 *
 * 🔴 **The authority is the server's `AddendumRules`** (`src/Scoular.Contracts.Application/Addendums/
 * AddendumRules.cs`: `AddendumDateField`, `CustomerFields`, `OptionalCustomerFields`), which refuses
 * any other `customer.*` or dotted field by name. No route serves the list, so this is the frontend's
 * ONE copy, and `addendum-placeholders.spec.ts` holds it to that file: a field added or renamed there
 * turns the spec red rather than leaving the picker a field short. Nothing else on the frontend may
 * restate these names; read them from here.
 */
declare const SERVER_SUPPLIED_FIELD_GROUPS: readonly ServerSuppliedFieldGroup[];
/** The server-supplied fields as picker groups, offered after the `addendum_*` fields and before CTRM's. */
declare function serverFieldGroups(): FieldOptionGroup[];
/**
 * Whether the server refuses a CTRM field on a template (`AddendumRules.FieldProblems`).
 *
 * - A field `constraints.json` flags `rewrittenOnWrite`: the addendum would print the value sent, not
 *   the one CTRM stores.
 * - A description of such a code (`AddendumRules.DescriptionsOfRewrittenCodes`: `text_description`,
 *   `language_description`, `price_market_month_description`, `hedge_market_month_description`). Read
 *   from the document as `<base>_description` describing `<base>` or `<base>_code`, so the list is not
 *   restated here. ⚠ The server's table stays the authority, and a spec pins these four.
 */
declare function refusedOnTemplate(document: ConstraintDocument, field: string): boolean;
/**
 * The CTRM fields a template may print: every `GET /meta/constraints` field the server accepts on a
 * template, by name. Never a hand-written list (ADR-7).
 */
declare function ctrmFieldGroup(document: ConstraintDocument): FieldOptionGroup;
/**
 * The field a placeholder's own name matches exactly, among those offered: `{{contract_number}}` to
 * `contract_number`, or `{{call_strike}}` to `addendum_call_strike`. Anything less than exact is left to
 * the administrator.
 */
declare function suggestedField(placeholder: string, groups: readonly FieldOptionGroup[]): string | null;
/** One run of the preview: template text, a sample value, or a placeholder that would print blank. */
interface PreviewSegment {
  readonly kind: 'text' | 'value' | 'missing';
  readonly text: string;
}
/**
 * A sample value for a field, by what kind of value it holds. Invented and recognisable as such: a
 * text value is the field's own name in brackets, so nothing in a preview can be read as real data.
 */
declare function sampleValueFor(field: string, document: ConstraintDocument | null): string;
/**
 * The draft as it would read with sample values (#924): each mapped placeholder replaced by a sample
 * of its field, each unmapped one marked. The anchors pass through, as they do on the server.
 */
declare function previewSegments(content: string, rows: readonly PlaceholderRow[], document: ConstraintDocument | null): PreviewSegment[];
/** A placeholder's field, as the list reports a change to it. */
interface PlaceholderFieldChange {
  readonly placeholder: string;
  readonly field: string;
}
/**
 * **The template's placeholders, each with the field it prints** (#924). Replaces the free-text
 * `placeholder = field` box.
 *
 * The rows come from the text as it is typed (`placeholderRows`), so nothing is typed twice. Each has
 * a picker of the fields on offer: the special types' `addendum_*` fields, the ones the server fills
 * in itself (#1038), then CTRM's from `GET /meta/constraints`. A row with no field says so here, before Save, because it would print blank.
 *
 * - **With no CTRM list** (`ctrmListed` false: no constraint source, or it could not be read), each row
 *   is a text box suggesting the `addendum_*` fields, and the server stays the check. Never an empty
 *   picker, which would leave a CTRM field impossible to choose.
 * - **A field the lists do not hold** (a template saved against an older list) is shown and kept,
 *   flagged, never dropped: dropping it would change the template on an unrelated save.
 * - **A saved mapping whose placeholder left the text** is listed below the rest, with a Remove. It is
 *   kept until removed, for the same reason.
 */
declare class AddendumPlaceholderFieldsComponent {
  readonly rows: import("@angular/core").InputSignal<readonly PlaceholderRow[]>;
  readonly groups: import("@angular/core").InputSignal<readonly FieldOptionGroup[]>;
  /** Whether CTRM's fields are among the groups. Without them each row is a text box. */
  readonly ctrmListed: import("@angular/core").InputSignal<boolean>;
  readonly describedBy: import("@angular/core").InputSignal<string | null>;
  readonly invalid: import("@angular/core").InputSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly fieldChange: import("@angular/core").OutputEmitterRef<PlaceholderFieldChange>;
  readonly removed: import("@angular/core").OutputEmitterRef<string>;
  protected readonly listId: string;
  protected readonly example = "{{contract_number}}";
  protected readonly offered: import("@angular/core").Signal<Set<string>>;
  protected braces(placeholder: string): string;
  protected pick(placeholder: string, field: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AddendumPlaceholderFieldsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AddendumPlaceholderFieldsComponent, "cws-addendum-placeholder-fields", never, {
    "rows": {
      "alias": "rows";
      "required": true;
      "isSignal": true;
    };
    "groups": {
      "alias": "groups";
      "required": true;
      "isSignal": true;
    };
    "ctrmListed": {
      "alias": "ctrmListed";
      "required": false;
      "isSignal": true;
    };
    "describedBy": {
      "alias": "describedBy";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "fieldChange": "fieldChange";
    "removed": "removed";
  }, never, never, true, never>;
}
/** One code a picker offers, with the words shown for it. */
interface CodeOption {
  readonly code: string;
  readonly label: string;
}
/**
 * **Several codes picked from a list, with typeahead** (#814). No free text where a list exists.
 *
 * The codes picked show as chips, each with its own Remove. The search box narrows the list and is
 * never the value: Enter adds the highlighted match, or the code typed exactly; a code the list does
 * not hold is refused here with `unknownMessage`, the server's own sentence, so it is said before
 * Save rather than after it.
 *
 * - **Keyboard:** the arrow keys and Home/End move the highlighted match (`aria-activedescendant`),
 *   Enter adds it, Escape closes the list, and Backspace in an empty box removes the last chip.
 * - **A code already picked that the list does not hold** (a template saved before a location went)
 *   is shown and flagged, never dropped: dropping it would change the template on an unrelated save.
 * - **With no list** (`options` is `null`, a host without the source), it is the comma-separated text
 *   box it replaces, and the server stays the only check.
 *
 * ⚠ The server's checks stay the authority. This says their sentences earlier; it decides nothing
 * they do not.
 */
declare class AdminCodePickerComponent {
  readonly label: import("@angular/core").InputSignal<string>;
  /** The form name, for the input. */
  readonly name: import("@angular/core").InputSignal<string | null>;
  readonly codes: import("@angular/core").InputSignal<readonly string[]>;
  /** What may be picked, or `null` when no list is available here (then it is a text box). */
  readonly options: import("@angular/core").InputSignal<readonly CodeOption[] | null>;
  /** The sentence for codes the list does not hold, as the server words it. */
  readonly unknownMessage: import("@angular/core").InputSignal<(codes: readonly string[]) => string>;
  /** Said under the picker when nothing is picked, e.g. what an empty list means. */
  readonly emptyMeaning: import("@angular/core").InputSignal<string | null>;
  /** Said under the picker always, e.g. that the list comes from a simulator. */
  readonly note: import("@angular/core").InputSignal<string | null>;
  readonly searchPlaceholder: import("@angular/core").InputSignal<string>;
  readonly freePlaceholder: import("@angular/core").InputSignal<string | null>;
  readonly describedBy: import("@angular/core").InputSignal<string | null>;
  readonly invalid: import("@angular/core").InputSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly codesChange: import("@angular/core").OutputEmitterRef<readonly string[]>;
  protected readonly labelId: string;
  protected readonly listId: string;
  protected readonly term: import("@angular/core").WritableSignal<string>;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  protected readonly active: import("@angular/core").WritableSignal<number>;
  protected readonly refusal: import("@angular/core").WritableSignal<string | null>;
  /** The options that match what is typed, not already picked, at most {@link MAX_MATCHES}. */
  protected readonly matches: import("@angular/core").Signal<readonly CodeOption[]>;
  protected readonly activeId: import("@angular/core").Signal<string | null>;
  protected optionId(index: number): string;
  protected known(code: string): boolean;
  protected chipLabel(code: string): string;
  protected onInput(value: string): void;
  protected onKeydown(event: KeyboardEvent): void;
  /**
   * Enter: the code typed exactly wins, then the highlighted match; anything else is refused with
   * the server's sentence and nothing is added.
   */
  private commit;
  protected add(code: string): void;
  protected remove(code: string): void;
  /**
   * The text box's own text, with no list. Kept as typed while it still parses to the same codes, so
   * typing "MNC, " is not rewritten to "MNC" under the caret before the next code is typed.
   */
  protected readonly freeText: import("@angular/core").WritableSignal<string>;
  protected onFreeInput(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AdminCodePickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AdminCodePickerComponent, "cws-admin-code-picker", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "codes": {
      "alias": "codes";
      "required": false;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "unknownMessage": {
      "alias": "unknownMessage";
      "required": true;
      "isSignal": true;
    };
    "emptyMeaning": {
      "alias": "emptyMeaning";
      "required": false;
      "isSignal": true;
    };
    "note": {
      "alias": "note";
      "required": false;
      "isSignal": true;
    };
    "searchPlaceholder": {
      "alias": "searchPlaceholder";
      "required": false;
      "isSignal": true;
    };
    "freePlaceholder": {
      "alias": "freePlaceholder";
      "required": false;
      "isSignal": true;
    };
    "describedBy": {
      "alias": "describedBy";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "codesChange": "codesChange";
  }, never, never, true, never>;
}
/** The Addendums page's views (#825). */
export type AddendumsView = 'all' | 'templates' | 'types';
/** What a list is doing. `unavailable` is a host whose API does not offer the route. */
type ListState$1 = {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
} | {
  readonly status: 'unavailable';
  readonly reason: string;
} | {
  readonly status: 'failed';
  readonly message: string;
  readonly correlationId?: string;
};
/** The editor's working copy. Plain fields, `ngModel`-bound and read only on Save. */
interface TemplateEditor {
  id: number | null;
  version: number | null;
  /** The `rowVersion` the editor opened on, sent back on `If-Match`. Null for a new template. */
  rowVersion: string | null;
  name: string;
  /** Special-type codes, picked from the addendum types (#814). */
  specialTypes: string[];
  language: string;
  contentFormat: string;
  /** CTRM location codes, picked from the location list (#814). Empty serves every trade unit. */
  tradeUnits: string[];
  active: boolean;
}
/**
 * The editor fields a `400`'s `errors.<key>` can land on, keyed as the server keys them
 * (`AddendumRules`). A key outside this list (`If-Match`, `actor`) is not a field, so its reason is
 * shown with the form's own error instead of being dropped.
 */
declare const EDITOR_FIELDS: readonly ["name", "specialTypes", "language", "tradeUnits", "contentFormat", "templateContent", "fields"];
type EditorField$1 = (typeof EDITOR_FIELDS)[number];
/**
 * The server's sentences for codes it does not know (`AddendumAdminService`), said here first (#814).
 * The trade-unit one drops the server's internal correction tag, which means nothing to a user.
 */
export declare function unknownTypesMessage(codes: readonly string[]): string;
export declare function unknownTradeUnitsMessage(codes: readonly string[]): string;
/**
 * What "not onboarded" means, said under the trade units wherever the indicator shows (#924). An
 * addendum is generated by a contract save, and a save is refused in a trade unit with no form
 * configuration, so a template is not used there until the trade unit is onboarded.
 */
export declare const NOT_ONBOARDED_EXPLANATION: string;
/** The sentence for a picked special type Legal has not made available (#924). */
export declare function typeNotAvailableMessage(code: string): string;
/**
 * **Addendum templates (F10.3b).** List, create, edit, deactivate and delete, with the version shown.
 *
 * ### 🔴 Save is refused HERE, before any request, when the anchors are wrong
 *
 * Legal requires a separate signature anchor and initials anchor on every template, and the signing
 * matcher refuses the `sig10__es_` form. A template that reached the server without them would be
 * refused there at best, and at worst stored and used, producing a document nobody can sign where
 * Legal requires. So the rule runs on Save and its reasons sit beside the content field, where the
 * administrator is looking when they paste in the approved text.
 *
 * ### The #624 contract (ADR-19, #676)
 *
 * A template serves one or more special types, carries a language and a content format, and maps
 * each placeholder to a field. Edits, deactivations and deletes go back on the `rowVersion` the list
 * gave; a stale one is a `409`, shown as *changed since you opened it* with a Reload, and never
 * retried. A `400`'s reasons land beside the field the server named.
 *
 * A host whose API lacks the routes still gets *not available yet*, never an empty table, which would
 * read as "there are no templates".
 *
 * The addendum types sit above the templates, in `AddendumTypesSectionComponent` (#798): code,
 * display name, family and whether Legal has made them available, created and edited there. A
 * template is offered on a record only for an available type.
 *
 * ⚠ **Deactivate and Delete are different on purpose.** Deactivating keeps the template and its
 * version history and stops it being offered on a record; deleting removes it, so it asks first.
 *
 * ### #924: set up from one form
 *
 * - **Placeholders are read from the content as it is typed**, each with a field picker
 *   (`AddendumPlaceholderFieldsComponent`): the special types' `addendum_*` fields, and CTRM's from
 *   `GET /meta/constraints` (`CONSTRAINT_SOURCE`, optional; without it, or when it cannot be read, each
 *   row is a text box). One with no field is shown before Save and refused there with the server's
 *   sentence. What is sent is the same `fields` list as before, so templates load and save unchanged.
 * - **Preview** shows the draft's text with sample values, here, before anything is saved. It is the
 *   text, not the PDF: the server previews only a SAVED template, from a contract.
 * - **Each required anchor is ticked off as it is typed.** Save still refuses a missing one.
 * - **#1038:** the picker also offers the fields the server fills in itself (the customer master and
 *   the addendum date, `SERVER_SUPPLIED_FIELD_GROUPS`), and "This text has no initials line" sends
 *   `initialsAnchorOptional`, which waives the initials anchor only. It is always sent, so re-saving a
 *   template that has no initials line keeps it so.
 * - **Where it is offered:** a picked special type that is not available says so with a Make
 *   available (after asking, because availability is Legal's approval), and "not onboarded" is
 *   explained under the trade units.
 */
export declare class AddendumTemplatesPageComponent {
  /**
   * Which of the page's views to show (#825): the templates, the types, or `all` of it as on the old
   * single Admin page. The Admin routes set it from `data.view`; mounted on its own the page shows both.
   */
  readonly view: import("@angular/core").InputSignalWithTransform<AddendumsView, AddendumsView | null | undefined>;
  protected readonly showTemplates: import("@angular/core").Signal<boolean>;
  protected readonly showTypes: import("@angular/core").Signal<boolean>;
  /** True when routed as one of the section's tabs, which is when the tabs are shown. */
  protected readonly routed: import("@angular/core").Signal<boolean>;
  protected readonly area: import("@cws/features-admin").AdminArea;
  private readonly source;
  private readonly typeSource;
  /** CTRM's field list for the placeholder pickers (#924). Optional: without it the rows are text boxes. */
  private readonly constraintSource;
  private readonly access;
  /**
   * The addendum types, read each time the editor opens so a type created above is offered at once
   * (#814). `null` while unread or when not available here; the picker is then a text box.
   */
  private readonly types;
  /** The special types on offer, each saying whether Legal has approved it. Unapproved stays pickable. */
  protected readonly typeOptions: import("@angular/core").Signal<readonly CodeOption[] | null>;
  /** Every CTRM location, with the onboarded indicator when `/me` has answered (#696). */
  protected readonly tradeUnitOptions: import("@angular/core").Signal<readonly CodeOption[] | null>;
  /**
   * Said under the trade units when the list is the simulator's (#814): on Dev that is a handful of
   * locations, and a real one such as 2087 is refused there. Read from the list, never hard-coded.
   */
  protected readonly tradeUnitNote: import("@angular/core").Signal<string | null>;
  protected readonly unknownTypesMessage: typeof unknownTypesMessage;
  protected readonly unknownTradeUnitsMessage: typeof unknownTradeUnitsMessage;
  protected readonly typeNotAvailableMessage: typeof typeNotAvailableMessage;
  /**
   * Why the template writes are not offered, or `null`. Every template route is Admin-only on the
   * server, so an account KNOWN not to hold the role sees them disabled with this reason rather than
   * meeting a 403 (#696). Unknown is not refused: the server decides then.
   */
  protected readonly writesRefused: import("@angular/core").Signal<"Needs the Admin role" | null>;
  private readonly confirm;
  private readonly destroyRef;
  /** The three anchors, for the editor's help text. From the domain library, never retyped. */
  protected readonly anchors: string[];
  protected readonly contentFormats: readonly ["text/plain"];
  protected readonly offered: boolean;
  protected readonly state: import("@angular/core").WritableSignal<ListState$1>;
  protected readonly unavailableReason: import("@angular/core").Signal<string | null>;
  protected readonly failure: import("@angular/core").Signal<{
    readonly status: "failed";
    readonly message: string;
    readonly correlationId?: string;
  } | null>;
  protected readonly templates: import("@angular/core").WritableSignal<readonly AddendumTemplate[]>;
  protected readonly editor: import("@angular/core").WritableSignal<TemplateEditor | null>;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  /** The template text being edited. A signal, so the placeholders and anchors follow it as it is typed (#924). */
  protected readonly content: import("@angular/core").WritableSignal<string>;
  /** Placeholder to field, as picked. Absent is untouched; `''` is no field, on purpose. */
  private readonly mappings;
  /** CTRM's constraint document, read once when an editor first opens; `null` when not available here. */
  private readonly constraints;
  private constraintsRequested;
  /** Whether CTRM's fields are on offer. Without them each placeholder's field is typed. */
  protected readonly ctrmListed: import("@angular/core").Signal<boolean>;
  /**
   * The fields a placeholder may print: the picked types' `addendum_*` fields, then the ones the server
   * fills in itself (the customer master and the addendum date, #1038), then CTRM's.
   */
  protected readonly fieldGroups: import("@angular/core").Signal<FieldOptionGroup[]>;
  /** Every placeholder in the text, with its field, then the saved mappings the text no longer uses. */
  protected readonly placeholderRows: import("@angular/core").Signal<PlaceholderRow[]>;
  /** Placeholders that would print blank: shown as they appear, and refused on Save. */
  protected readonly unmapped: import("@angular/core").Signal<string[]>;
  /** Whether the preview is open. It follows the text and the picks while it is. */
  protected readonly previewOpen: import("@angular/core").WritableSignal<boolean>;
  protected readonly preview: import("@angular/core").Signal<PreviewSegment[]>;
  /**
   * "This text has no initials line" (#1038), the template's `initialsAnchorOptional`. A signal, so
   * the anchor checklist follows it. Only the initials anchor is waived, as on the server.
   */
  protected readonly initialsOptional: import("@angular/core").WritableSignal<boolean>;
  /**
   * Each anchor, and whether the text holds it yet (#924). With no initials line the initials anchor
   * is listed as not required rather than as missing (#1038).
   */
  protected readonly anchorChecks: import("@angular/core").Signal<{
    anchor: string;
    present: boolean;
    required: boolean;
  }[]>;
  /**
   * The picked special types Legal has not made available (#924): the template is not offered for
   * them. A code the list does not know is the picker's to flag, so it is not repeated here.
   */
  protected readonly unavailableTypes: import("@angular/core").Signal<AddendumType[]>;
  /** Whether the type writes behind Make available are wired here at all. */
  protected readonly typeWritesOffered: boolean;
  /**
   * Each template's actions, for its ⋯ menu (#825; they were three inline buttons). Deactivate on an
   * active template only, as before; Delete still asks first (`remove`). Every write is refused with
   * the same reason the buttons gave: in flight, or the Admin role (#696).
   */
  protected readonly templateActions: import("@angular/core").Signal<Map<number, GridRowAction<AddendumTemplate>[]>>;
  /** Why the editor's content would be refused here, before any request. Shown beside the content. */
  protected readonly anchorProblems: import("@angular/core").WritableSignal<readonly string[]>;
  /** A field's reasons, from this screen's own checks or a server `400`, keyed as the server keys them. */
  protected readonly fieldErrors: import("@angular/core").WritableSignal<Partial<Record<"name" | "specialTypes" | "language" | "tradeUnits" | "contentFormat" | "templateContent" | "fields", readonly string[]>>>;
  /** Everything said beside the content field: the anchor checks here, then the server's reasons. */
  protected readonly contentProblems: import("@angular/core").Signal<string[]>;
  /**
   * The last write's outcome (#803): its success, or its failure with the server's reference. A
   * field's own reasons still sit beside the field; this says whether anything was saved.
   */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /** A `409`: the failure offers a Reload. It is never retried. */
  protected readonly reloadOffered: import("@angular/core").WritableSignal<boolean>;
  constructor();
  /** Reads the addendum types for the special-type picker. A failure leaves the text box. */
  private loadTypes;
  /**
   * Reads CTRM's constraint document once, for the placeholder pickers (#924). 🔴 **Fails soft**: a
   * failed read leaves the rows as text boxes with a sentence saying so, never an error over the form,
   * because the server checks every field on Save whether or not this list was read.
   */
  private loadConstraints;
  protected load(): void;
  /** After a `409`: drop the stale editor and read the current rows. Nothing was saved. */
  protected reload(): void;
  protected errorsFor(field: EditorField$1): readonly string[];
  protected startCreate(): void;
  protected startEdit(template: AddendumTemplate): void;
  protected cancelEdit(): void;
  /** A placeholder's field, picked or typed. */
  protected setField(change: PlaceholderFieldChange): void;
  /** Drops a saved mapping whose placeholder the text no longer holds. */
  protected removeMapping(placeholder: string): void;
  protected togglePreview(): void;
  /**
   * Makes a picked special type available from the template form (#924), so one template can be made
   * usable without leaving it. 🔴 **It asks first**: availability is Legal's approval of the type, and
   * once it is set every active template for the type is offered on a record. A `409` re-reads the
   * types and is never retried.
   */
  protected makeAvailable(type: AddendumType): void;
  protected clearOutcome(): void;
  /**
   * Validates, then sends. 🔴 **Nothing is sent while the anchors are wrong** — the refusal is the
   * point, so it returns before the source is touched. The same for a blank name, no special type,
   * or a placeholder with no field (#924), which would print blank.
   */
  protected save(): void;
  protected deactivate(template: AddendumTemplate): void;
  /** Deletes after asking. The confirmation names the template, so the answer is not a guess. */
  protected remove(template: AddendumTemplate): void;
  protected tradeUnitsLabel(template: AddendumTemplate): string;
  /** A picker's new codes, into the editor's working copy. */
  protected setCodes(field: 'specialTypes' | 'tradeUnits', codes: readonly string[]): void;
  private open;
  /**
   * Sends one write, then re-reads the list: the server's version number is the one shown.
   *
   * A `400` puts each `errors.<field>` beside its field; a key that is no field (`If-Match`) is said
   * with the form. A `409` is the conflict, with its Reload.
   */
  private run;
  static ɵfac: i0.ɵɵFactoryDeclaration<AddendumTemplatesPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AddendumTemplatesPageComponent, "cws-addendum-templates-page", never, {
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The form-configuration page's views (#825). */
export type FormConfigView = 'all' | 'rows' | 'preview';
/**
 * **Form configuration administration** (ADR-17, implementation brief §10.5).
 *
 * Two halves, and the second is the valuable one.
 *
 * ### The list
 *
 * Every configuration row including inactive ones, with its dimensions rendered as *Any* where they
 * are null — because a blank cell in a dimension column reads as missing data when it actually means
 * "this row applies to everything". Deactivating is soft and sends the row's `rowVersion`, so a
 * concurrent edit is a message rather than a silent overwrite.
 *
 * ### 🔑 The preview tool, and why it is not optional
 *
 * Pick any combination of dimensions and see **which row wins and why**. The resolution rules are
 * match-count-first with a significance tie-break over up to three dimensions and an effective date
 * (brief §6) — which is simple to state and genuinely hard to hold in your head once a dozen rows
 * exist. Without a preview, an admin's only way to check their work is to open a real contract and
 * infer the answer from the fields, and the answer they most need is for a combination no contract
 * they have to hand happens to be.
 *
 * It calls the **same** `resolve` endpoint the record screen calls, deliberately: a preview with its
 * own copy of the ranking rules would be a second answer to "which configuration wins", and the one
 * place an admin looks to check their work is the last place that should be able to disagree with
 * production.
 *
 * ### What this screen does NOT do yet
 *
 * There is no editor here. Creating and updating rows are `POST`/`PUT` on the same API and the
 * validation is already server-side with RFC 7807 errors — the missing piece is a field-by-field
 * grid with Required auto-checking Visible and non-configurable rows locked, which is real UI work
 * and is stated as absent rather than half-built. Read-and-preview is what makes the configuration
 * already in the database *legible*, which is the part nothing else provides.
 */
export declare class FormConfigAdminPageComponent {
  private readonly source;
  /**
   * Which of the page's views to show (#825): the configuration rows, the preview tool, or `all` of
   * it as on the old single Admin page. The Admin routes set it from `data.view`; mounted on its own
   * the page shows everything, so its spec and the playground's route are unchanged.
   */
  readonly view: import("@angular/core").InputSignalWithTransform<FormConfigView, FormConfigView | null | undefined>;
  protected readonly showRows: import("@angular/core").Signal<boolean>;
  protected readonly showPreview: import("@angular/core").Signal<boolean>;
  /** True when routed as one of the section's tabs, which is when the tabs are shown. */
  protected readonly routed: import("@angular/core").Signal<boolean>;
  protected readonly area: import("@cws/features-admin").AdminArea;
  /** Bumped after a deactivate, and by Retry, so the list genuinely re-reads. */
  private readonly attempt;
  protected readonly listState: import("@angular/core").WritableSignal<RemoteData<FormConfigListResponse>>;
  protected readonly rows: import("@angular/core").Signal<readonly FormConfigRow[]>;
  /**
   * Whether the rows came from a durable store.
   *
   * Said out loud for the same reason the grid names its data origin: no deployed environment has a
   * connection string today, so the honest answer is usually "in memory, gone on restart" — and an
   * admin who saves a configuration that vanishes on the next deploy without being told is owed an
   * explanation nobody can give them afterwards.
   */
  protected readonly storeOrigin: import("@angular/core").Signal<string | null>;
  protected readonly notDurable: import("@angular/core").Signal<boolean>;
  protected previewType: string;
  protected previewLocation: string;
  protected previewCommodity: string;
  protected previewContract: string;
  protected readonly previewState: import("@angular/core").WritableSignal<RemoteData<FormConfigPreview> | null>;
  /** What the preview resolved to, or null before anything has been previewed. */
  protected readonly preview: import("@angular/core").Signal<FormConfigPreview | null>;
  /**
   * The provenance sentence — the answer the tool exists to give.
   *
   * Says which dimensions matched rather than only the rank number: "rank 4" is meaningless to
   * anybody who has not read §6, and "matched this location and this commodity" is the same fact in
   * a form that needs no reference.
   */
  protected readonly previewProvenance: import("@angular/core").Signal<string | null>;
  /** Required fields in the resolved configuration, which is what an admin most often checks. */
  protected readonly previewRequired: import("@angular/core").Signal<readonly string[]>;
  /** Fields the resolved configuration hides — the other half of "what did I actually change?". */
  protected readonly previewHidden: import("@angular/core").Signal<readonly string[]>;
  /**
   * The tabs the preview reports.
   *
   * 🔴 **Runs the same cascade the record screen runs** (F8.3, ruled 2026-09-24): a tab whose every
   * section is hidden is dropped here too. This filtered on `tab.visible` alone, which made the
   * preview *confidently wrong* — it promised a tab the record screen was about to drop, and a
   * preview that disagrees with the thing it previews is worse than no preview.
   */
  protected readonly previewTabs: import("@angular/core").Signal<readonly string[]>;
  /**
   * Which row's history is open, or `null`. One at a time: the trail is fetched on demand rather
   * than with the list, because a list of 50 rows would otherwise pull 50 full document histories
   * to render 50 collapsed summaries nobody has opened.
   */
  protected readonly auditRowId: import("@angular/core").WritableSignal<number | null>;
  protected readonly auditState: import("@angular/core").WritableSignal<RemoteData<FormConfigAuditTrail>>;
  /**
   * The failure message, or empty.
   *
   * A computed rather than two `auditState()` reads in the template: narrowing does not survive
   * between two calls of the same signal, so the template form does not compile — and the shape
   * that would have compiled (`$any`) would have suppressed the check rather than satisfied it.
   */
  protected readonly auditError: import("@angular/core").Signal<string>;
  /**
   * The trail as the screen renders it: newest first, each entry paired with the diff against its
   * predecessor.
   *
   * 🔴 **The pairing happens BEFORE the reversal, and the order of those two steps is the whole
   * correctness of this screen.** The server serves oldest-first because the *before* of entry
   * *n* is entry *n−1*; reversing first and then pairing would diff every entry against its
   * successor and report every change backwards, with nothing to say so.
   */
  /** #700: the trail left out entries from trade units this account does not manage. */
  protected readonly auditPartial: import("@angular/core").Signal<boolean>;
  protected readonly auditEntries: import("@angular/core").Signal<{
    entry: import("@cws/domain-contracts").FormConfigAuditEntry;
    isOldest: boolean;
    changes: readonly import("@cws/domain-contracts").ConfigChange[];
  }[]>;
  protected toggleAudit(row: FormConfigRow): void;
  /**
   * What the editor is open on: `null` closed, `'new'` creating, or the row being edited.
   *
   * A loaded row rather than an id, because the editor needs the row's full document *and* its
   * `rowVersion` — and fetching them here keeps the concurrency token on the same read the admin
   * is looking at, which is what makes the 409 mean "someone changed it since you opened it".
   */
  protected readonly editorState: import("@angular/core").WritableSignal<FormConfigDetail | "closed" | "new">;
  protected readonly editorOpen: import("@angular/core").Signal<boolean>;
  protected readonly editingRow: import("@angular/core").Signal<FormConfigDetail | null>;
  protected readonly loadingEditor: import("@angular/core").WritableSignal<boolean>;
  /**
   * Each row's actions, for its ⋯ menu (#825; they were three inline buttons). Edit and Deactivate on
   * an active row only, as before; History on every row, because the audit outlives its subject
   * (F8.6). Built once per row per change, so a menu's actions keep their identity between renders.
   */
  protected readonly rowActions: import("@angular/core").Signal<Map<number, GridRowAction<FormConfigRow>[]>>;
  protected startNew(): void;
  protected edit(row: FormConfigRow): void;
  protected closeEditor(): void;
  /**
   * The last list-level write's outcome (#803): a save the editor finished, or a deactivate. A
   * deactivate's failure sits here, beside the list, with Reload; it no longer replaces the list.
   */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /** After a save: close, reload the list, and drop any stale preview. */
  protected onSaved(): void;
  constructor();
  protected reload(): void;
  protected runPreview(): void;
  /** Deactivates a row and reloads, so the list cannot show a row that is no longer active. */
  protected deactivate(row: FormConfigRow): void;
  /** `Any` rather than a blank cell — a null dimension means "applies to everything". */
  protected dimension(value: string | null): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormConfigAdminPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormConfigAdminPageComponent, "cms-form-config-admin-page", never, {
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The presentation members the editor sets; each is absent until an administrator sets it (#221). */
type PresentationKey = keyof FieldPresentation;
/**
 * How a field will be drawn on the record screen, for the editor's preview (#221): the layout's
 * value wherever the row sets nothing.
 */
export interface PresentationPreview {
  readonly half: boolean;
  readonly labelHidden: boolean;
  readonly label: string;
  /** The description shown, or `null` when none is. */
  readonly description: string | null;
}
/**
 * A field's presentation as it will render: the row's settings over the layout's (#221). The same
 * precedence `presentationMaps` applies on the record screen.
 */
export declare function previewPresentation(componentName: string, registryLabel: string, presentation: FieldPresentation | undefined): PresentationPreview;
/**
 * The field map as it goes on the wire: a `presentation` block only where something was set.
 *
 * 🔴 **An empty block is dropped, and so is every unset member**, so saving a row through the editor
 * never freezes today's layout values into it (the 2026-09-09 field-order lesson, #221).
 */
export declare function withSetPresentationOnly(fields: Readonly<Record<string, ConfigFieldBehaviour>>): Record<string, ConfigFieldBehaviour>;
/** One editable field row, joined from the registry and the document being edited. */
interface EditorField {
  readonly componentName: string;
  readonly label: string;
  readonly ctrmField: string;
  /** CTRM refuses this on a write — it can never be required, and the row says why. */
  readonly ctrmReadOnly: boolean;
  /** A driver or the contract number: visibility and requiredness are not the admin's to change. */
  readonly locked: boolean;
  readonly behaviour: ConfigFieldBehaviour;
}
/** One row of the "Collections on copy" block (#1000), joined from the registry and the document. */
interface EditorCollection {
  /** The CTRM collection name, from the registry. Never re-typed here. */
  readonly name: string;
  readonly label: string;
  /** `false`: a copy can never carry it, so its box is disabled with the reason. */
  readonly copyable: boolean;
  readonly excludeFromCopy: boolean;
}
/** One row of the "Remarks" block (#1006), joined from the registry and the document. */
interface EditorRemarkType {
  /** CTRM's `remark_type` code, from the registry. Never re-typed here. */
  readonly code: string;
  readonly label: string;
  readonly visible: boolean;
  readonly required: boolean;
}
/** Fields grouped as the layout groups them, so the grid reads like the screen it configures. */
interface EditorSection {
  readonly id: string;
  readonly label: string;
  readonly tab: string;
  readonly fields: readonly EditorField[];
}
export declare class FormConfigEditorComponent implements OnInit {
  private readonly source;
  /** The row to edit, or `null` to create a new one. */
  readonly editing: import("@angular/core").InputSignal<FormConfigDetail | null>;
  /** Raised after a successful save, so the list reloads and the editor closes. */
  readonly saved: import("@angular/core").OutputEmitterRef<void>;
  /** Raised on Cancel. */
  readonly cancelled: import("@angular/core").OutputEmitterRef<void>;
  protected contractTypeClass: string;
  protected locationCode: string;
  protected commodityCode: string;
  /**
   * ISO `yyyy-MM-dd`, or `null`/`''` when there is none. ⚠ `cms-date-input` writes `null` for text it
   * cannot parse, as well as for an empty field, so "blank" alone is not the test (#626).
   */
  protected effectiveFrom: string | null;
  /** The effective date's refusal, shown on the field; cleared as soon as the date changes. */
  protected readonly effectiveError: import("@angular/core").WritableSignal<string | null>;
  protected autoCalculationMode: string;
  protected pendingContractsEnabled: boolean;
  /**
   * Set while a save of a row for EVERY trade unit waits on the administrator's say-so (#844).
   *
   * 🔴 **The Dev walk made one by mistake (2026-10-12, row d1).** "Applies to trade unit" was left at
   * Any while a seed was set, and the create took over every Dev contract until the row was
   * deactivated. Such a row is still allowed, because an Admin needs one; it just takes a second,
   * deliberate click. Asked for a new row and for an edit that takes a trade unit's row to Any, and
   * not for an edit of a row that already applies to every trade unit.
   */
  protected readonly everyTradeUnitPending: import("@angular/core").WritableSignal<boolean>;
  /** The trade unit picker's change: picking one answers the question, so it is dropped. */
  protected setLocation(code: string): void;
  /** Whether this save would make a row for every trade unit that is not one already. */
  private asksBeforeEveryTradeUnit;
  /** The trade unit's column list, or `null` for every column. Sent only when set. */
  protected readonly homeGridColumns: import("@angular/core").WritableSignal<readonly string[] | null>;
  /**
   * Set when a save went through but the server's answer does not carry the list that was sent.
   *
   * 🔴 Until #747 the server does not know the attribute and drops it on save with no error, so a
   * save would look complete while keeping nothing. The answer IS the stored row, so its absence
   * there is the read-back.
   */
  protected readonly columnsNotKept: import("@angular/core").WritableSignal<boolean>;
  protected readonly lockedColumnKeys: readonly string[];
  private readonly allColumnKeys;
  /** The picker's list: the set columns first, in order, then the rest unticked. */
  protected readonly homeGridColumnFields: import("@angular/core").Signal<readonly ExportField[]>;
  protected onHomeGridColumnsChange(fields: readonly ExportField[]): void;
  protected resetHomeGridColumns(): void;
  /** The collection copy flags as edited. A missing entry is the default: the collection copies. */
  private readonly collectionFlags;
  /**
   * The flags the starting point carried: the row's own when editing, the resolution's for a new row.
   * The save sends only what differs from this (see {@link changedCollections}).
   */
  private readonly collectionBaseline;
  /**
   * One row per registry collection, in the registry's order, or `null` when the registry offers none.
   *
   * ⚠ **`null` is a server without #959** (PR #991): its registry has no `collections`, and the block
   * is not rendered at all rather than shown empty or as an error.
   */
  protected readonly collectionRows: import("@angular/core").Signal<readonly EditorCollection[] | null>;
  /** Ticks or clears one collection's Exclude from copy. Refused for a collection a copy never carries. */
  protected setCollectionExcluded(name: string, excludeFromCopy: boolean): void;
  /** Takes a starting point's collection flags as both the edited state and the baseline. */
  private startCollectionsFrom;
  /** Each remark type's flags as edited. A missing entry is the default: shown and optional. */
  private readonly remarkFlags;
  /** The flags the starting point carried, as {@link collectionBaseline} is for collections. */
  private readonly remarkBaseline;
  /**
   * One row per registry remark type, in the registry's order, or `null` when the registry offers none.
   *
   * ⚠ **`null` is a server without #1022**: its registry has no `remarkTypes`, and the block is not
   * rendered at all rather than shown empty or as an error.
   */
  protected readonly remarkRows: import("@angular/core").Signal<readonly EditorRemarkType[] | null>;
  /**
   * Ticks or clears one remark type's Visible or Required.
   *
   * The field grid's rule (see the note under it): **Required also ticks Visible and locks it**, since a
   * remark somebody must fill in cannot be one they cannot see. Clearing Visible is refused while
   * Required holds it.
   */
  protected setRemarkFlag(code: string, flag: keyof ConfigRemarkTypeBehaviour, value: boolean): void;
  /** Takes a starting point's remark flags as both the edited state and the baseline. */
  private startRemarksFrom;
  /** The trade unit typed into the seed box. */
  protected seedTradeUnit: string;
  /**
   * The row this new configuration was seeded from, or `null` when it was not.
   *
   * 🔴 **Carries the source's `rowVersion`, and that is the point of keeping it.** `POST
   * /form-configurations` does not evaluate `If-Match` — it has no source to be stale against — so
   * the guard against cloning a source that changed after it was copied lives here: {@link save}
   * reads the source again and compares this token, the same opaque value `If-Match` carries on an
   * update, before it creates anything.
   */
  protected readonly seededFrom: import("@angular/core").WritableSignal<{
    readonly id: number;
    readonly rowVersion: string;
    readonly tradeUnit: string;
    readonly dimensionKey: string;
    readonly version: number;
  } | null>;
  /** Why a seed was refused, or `null`. Not {@link error}: nothing was saved or failed to save. */
  protected readonly seedNotice: import("@angular/core").WritableSignal<string | null>;
  /**
   * The starting point's own sections, so what is saved keeps their placement exactly: the row
   * being edited, the row seeded from, or the resolution a new row copies.
   *
   * 🔴 **#792: an edit used to leave this `null`, so the save sent the LAYOUT's sections.** Dev's
   * rows put `pricing` on the `contract` tab and have no `pricing` tab; the editor sent
   * `pricing -> pricing` beside the row's tabs and the server refused every save (rule 5). `null`
   * now means only "nothing loaded yet", and falls back to the registry.
   */
  private readonly baseSections;
  /**
   * Which starting point is current. Every load of one — the open-time resolve, "Copy from what
   * currently applies", a seed — takes the next number, and an answer is adopted only if its number
   * is still current.
   *
   * 🔴 **Without it a slow resolve overwrites a seed.** A new row resolves as it opens; over HTTP
   * that answer can land after the administrator has seeded, and adopting it would replace the
   * seeded settings with the parent's while the screen still said "Seeded from trade unit …".
   */
  private startingPoint;
  protected readonly saving: import("@angular/core").WritableSignal<boolean>;
  /**
   * Why the editor cannot go on, as one outcome (#803): the registry that could not be read, a save
   * the server refused (with its reference), or a refusal made here before any request. A success
   * closes the editor, and the page announces it.
   */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /**
   * Field search, because 111 rows across 11 sections is not a list you scroll.
   *
   * 🔴 **A signal, and it was a plain property until 2026-09-23 — which meant the search had never
   * worked.** `sections()` is a `computed` reading this; a computed over a non-signal caches on
   * first evaluation and is never invalidated, so typing re-ran change detection, the template
   * called `sections()`, and got the same cached list back every time. The box accepted input and
   * filtered nothing.
   *
   * ⚠ **Nothing caught it because nothing tested it** — the screen looks completely normal, since a
   * filter that matches everything and a filter that is ignored render identically. It surfaced only
   * when the reorder guard needed to react to the same field and its banner would not appear.
   *
   * ⚠ Bound as `[ngModel]` + `(ngModelChange)` rather than the banana-in-a-box: `[(ngModel)]` writes
   * through to the property, which would replace the signal with a string.
   */
  protected readonly filter: import("@angular/core").WritableSignal<string>;
  private readonly registry;
  private readonly behaviours;
  private readonly tabs;
  protected readonly ready: import("@angular/core").Signal<boolean>;
  protected readonly isNew: import("@angular/core").Signal<boolean>;
  /**
   * 🔴 The registry fetch is here and NOT in the constructor, and that is a correctness fix
   * rather than a style preference.
   *
   * Signal inputs are not populated during construction. With an HTTP registry the response always
   * arrives after the input is set, so seeding from the constructor LOOKED correct — but a
   * synchronous source (a test stub, or a cached response) seeded before {@link editing} existed,
   * so the editor silently opened a blank NEW row while claiming to edit an existing one. That is
   * the same shape as the 2026-09-01 defect where synchronous mocks could not express a real
   * ordering race; here the mock exposed it instead.
   */
  ngOnInit(): void;
  /**
   * The editable tab list.
   *
   * Tabs are configuration (D7) — this is what replaces the legacy app's per-location BIO/FOG tabs,
   * which were `If(location = 4090)` conditionals in a template. Label and visibility are editable;
   * the id is not, because sections reference it.
   */
  protected readonly editableTabs: import("@angular/core").Signal<readonly ConfigTab[]>;
  /**
   * Section enablement per trade unit (F8.3).
   *
   * 🔴 **Held as editable state, where `save()` used to submit `registry.sections` verbatim.** That
   * pass-through is why nothing could turn a section off: the document has carried
   * `sections[].visible` since ADR-17 and the resolve projection has always emitted it, so the
   * storage and the consumer were both ready and only the editor was writing the seed's answer back
   * over the administrator's.
   *
   * ⚠ **A hidden section does NOT hide its tab, and that is the current behaviour rather than a
   * decision this makes.** The record screen filters tabs on `tab.visible` alone, so hiding every
   * section on a tab leaves the tab present and empty. {@link emptyTabWarning} surfaces that state
   * instead of pretending it cannot happen — see its own note.
   */
  protected readonly sectionVisibility: import("@angular/core").WritableSignal<Readonly<Record<string, boolean>>>;
  /** Toggles one section on or off for this configuration row. */
  protected toggleSection(sectionId: string, visible: boolean): void;
  /**
   * Whether a section is on, for the template.
   *
   * Reads the registry's own default when this row has said nothing, so a section added to the
   * layout after the row was written shows its layout state rather than defaulting to hidden.
   */
  protected sectionVisible(sectionId: string): boolean;
  /** The sections as they will be stored — the starting point's own, carrying this row's visibility. */
  protected readonly editableSections: import("@angular/core").Signal<{
    visible: boolean;
    id: string;
    label: string;
    tab: string;
    order: number;
  }[]>;
  /**
   * Tabs left with no visible section, named.
   *
   * ✅ **RULED 2026-09-24 (JFrisbie): it cascades.** The record screen and the preview tool both
   * drop an emptied tab now, so this is no longer a warning standing in for a decision — it tells
   * the administrator what *will* happen, at the moment they cause it.
   *
   * 🔑 **The predicate is {@link emptiedTabs}, shared with both of them rather than copied.** That
   * is what makes this message and the record screen's behaviour the same statement: a warning
   * computed from its own second copy of the rule could say "Shipping will be hidden" about a tab
   * the record screen kept, and nothing would report the disagreement. The Remarks guard lives
   * there too.
   */
  protected readonly emptyTabWarning: import("@angular/core").Signal<string | null>;
  /** The field grid, grouped by section and narrowed by the search box. */
  protected readonly sections: import("@angular/core").Signal<readonly EditorSection[]>;
  /**
   * Why reorder is unavailable right now, or `null` when it is available.
   *
   * 🔴 **Reorder is refused while the search box has content, and that is a correctness guard rather
   * than caution.** The grid shows a *filtered* section; "move up" against a filtered list either
   * swaps with the row above on screen — which is not the row above in the document — or silently
   * jumps the field past rows the administrator cannot see. Both write an order nobody chose.
   *
   * Refusing with a stated reason is the honest third option, and it is cheap to satisfy: clear the
   * search and the buttons come back.
   */
  protected readonly reorderBlockedReason: import("@angular/core").Signal<"Clear the search to reorder — moving a field while the list is filtered would place it against rows you cannot see." | null>;
  /**
   * Moves a field one place within its section — **the keyboard path**.
   *
   * Renumbering and the full-membership rule live in {@link applyOrder} and {@link orderedIn}, shared
   * with the drag ({@link placeField}), so the two gestures cannot disagree about what a move writes.
   */
  protected moveField(sectionId: string, componentName: string, delta: -1 | 1): void;
  /**
   * Moves a field to the position of another in the same section — **the drag** (F8.1).
   *
   * 🔑 **The same persistence path as the arrows, on purpose.** It computes a new sequence and hands
   * it to {@link applyOrder}, which is the one place a section is renumbered; the arrows do exactly
   * the same. So a drag and the equivalent key presses produce the same document, the save goes
   * through the same `If-Match` update, and there is no second renumbering rule to drift.
   *
   * The semantics are the export field picker's: the dragged field takes the target row's index, so
   * dropping on the last row makes it last and dropping on the first makes it first.
   */
  protected placeField(sectionId: string, componentName: string, onto: string): void;
  /**
   * A section's FULL membership in its current order, or `null` when reorder is unavailable.
   *
   * ⚠ Full membership, not the rendered rows. They are the same list while
   * {@link reorderBlockedReason} is null, which is the only time this answers, but taking the full
   * list means a future caller cannot reintroduce the filtered-reorder bug by accident.
   */
  private orderedIn;
  /**
   * Writes a section's new sequence, renumbered contiguously from 1.
   *
   * ⚠ **Renumbers the whole section rather than swapping two numbers.** The seed's orders are not
   * guaranteed dense or unique — they are the layout's, and nothing has ever required them to be —
   * so a swap can be a no-op between two fields that share a number, which reads on screen as the
   * control doing nothing. Renumbering from the resulting sequence makes the write describe exactly
   * what the grid shows.
   */
  private applyOrder;
  /** The field being dragged, so its row can show it. */
  protected readonly draggingField: import("@angular/core").WritableSignal<string | null>;
  /** The row the dragged field would land on, or `null` when the pointer is over no valid target. */
  protected readonly dropField: import("@angular/core").WritableSignal<string | null>;
  /** The section the drag began in; a drop is only valid inside it. */
  private dragSection;
  /**
   * **The drag, through the shared gesture** — never a copy of it (Known Issue 44).
   *
   * `PointerDragGesture` is the filter chip row's pointer implementation, extracted into shared-ui:
   * pointer events rather than HTML5 drag-and-drop, window listeners only while a press is followed,
   * and every way out (release, `pointercancel`, Escape, losing the window) ending it. What is here
   * is only what is specific to these rows — the grip names a field, a row names a drop — and the
   * rows' container carries `select-none`, which the gesture cannot apply for us.
   *
   * ⚠ The grip is only rendered while {@link reorderBlockedReason} is null, so a filtered list offers
   * nothing to press; {@link placeField} checks again regardless.
   */
  private readonly gesture;
  constructor();
  /** Bound on the rows' container, so it sees a press on any grip. */
  protected onRowPointerDown(event: PointerEvent): void;
  /**
   * The field that moved last, so the row can announce itself and keep focus.
   *
   * Without it a keyboard user presses the button, the list re-sorts under them, and focus lands
   * wherever the DOM happens to put it — which on a 111-row grid means losing your place entirely.
   */
  protected readonly movedField: import("@angular/core").WritableSignal<string | null>;
  /** Counts for the summary line, so an admin can see what they have done at a glance. */
  protected readonly requiredCount: import("@angular/core").Signal<number>;
  protected readonly hiddenCount: import("@angular/core").Signal<number>;
  /**
   * Ticks Required, and ticks Visible with it.
   *
   * Rule 2 made visible in the control rather than discovered at save: the server rejects
   * `required: true, visible: false` rather than silently fixing it, precisely so a document
   * always says what its author meant — which only works if the author cannot express the
   * contradiction.
   */
  protected setRequired(componentName: string, required: boolean): void;
  protected setVisible(componentName: string, visible: boolean): void;
  protected setFlag(componentName: string, flag: 'readOnly' | 'borderWarning' | 'excludeFromCopy' | 'excludeFromTemplateCopy', value: boolean): void;
  /** The field whose presentation controls are open, if any. */
  protected readonly openPresentation: import("@angular/core").WritableSignal<string | null>;
  protected togglePresentation(componentName: string): void;
  protected previewOf(field: EditorField): PresentationPreview;
  /** The layout's value for one setting, so a blank control can say what it falls back to. */
  protected layoutDefault(componentName: string): {
    readonly half: boolean;
    readonly labelHidden: boolean;
    readonly note: string | null;
  };
  /**
   * Sets one presentation member, or clears it back to the layout's value with `undefined`.
   * A tri-state select sends `''` for "the layout's", which clears too.
   */
  protected setPresentation(componentName: string, key: PresentationKey, value: boolean | string | undefined): void;
  /** A tri-state select's value: `''` is the layout's, otherwise `true` or `false`. */
  protected setPresentationFlag(componentName: string, key: 'halfWidth' | 'labelHidden' | 'tooltipEnabled', choice: string): void;
  protected flagChoice(value: boolean | undefined): string;
  /** Puts a field's presentation back to the layout's, which is what re-syncing it means. */
  protected resetPresentation(componentName: string): void;
  protected setTabVisible(id: string, visible: boolean): void;
  protected setTabLabel(id: string, label: string): void;
  /**
   * Loads whatever currently resolves for the dimensions typed in, as the starting point.
   *
   * Offered as a button as well as on open, because the dimensions can change after the editor is
   * open and the sensible starting point changes with them.
   */
  protected copyFromCurrent(): void;
  /** @param everyTradeUnitConfirmed The administrator confirmed a row for every trade unit (#844). */
  protected save(everyTradeUnitConfirmed?: boolean): void;
  /** Follows a create or update to its end. */
  private submit;
  /**
   * **Seeds this new row from another trade unit's configuration** (F8.1).
   *
   * Two reads, and both are needed. The resolve endpoint answers *which* row wins for the source
   * trade unit — the same answer the record screen gets, so "that trade unit's configuration" means
   * what its users actually see. Then that row is read whole, because the resolve payload carries
   * only visible/required/read-only per field and no order: seeding from it would silently reset the
   * other three flags and the whole field order.
   *
   * The type and commodity typed for the new row are kept for the source's resolve, so seeding a
   * CORN row copies the source's CORN configuration rather than its all-commodities one.
   */
  protected seedFromTradeUnit(): void;
  /**
   * Takes a stored row's document as this row's starting point, wholesale.
   *
   * 🔴 **Nothing is re-derived.** Tabs, sections, fields (in the source's own key order) and
   * attributes are the source's, so the document saved is byte-identical to the source's except the
   * dimensions it is saved under. Registry fields the source predates are completed at their
   * defaults, the same rule every stored row gets on read (§5.1 rule 7).
   */
  private adoptSeed;
  protected cancel(): void;
  /** Seeds the form: an existing row's own document, or the current resolution for a new one. */
  private seed;
  private completeFrom;
  private toEditorField;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormConfigEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormConfigEditorComponent, "cms-form-config-editor", never, {
    "editing": {
      "alias": "editing";
      "required": false;
      "isSignal": true;
    };
  }, {
    "saved": "saved";
    "cancelled": "cancelled";
  }, never, never, true, never>;
}
/** The Roles and permissions page's views (#825). */
export type RolesView = 'all' | 'roles' | 'assignments' | 'permissions';
/** The role being created or edited. Mutated by the form's bindings, like the template editor's. */
interface RoleEditor {
  readonly role: Role | null;
  name: string;
  displayName: string;
  description: string;
  parentRoleId: string | null;
  permissionKeys: string[];
}
/** The assignment being added. */
interface AssignmentForm {
  userObjectId: string;
  userUpn: string;
  roleId: string;
  tradeUnit: string;
  expiresOn: string;
  isDefault: boolean;
}
type ListState = {
  readonly status: 'idle' | 'loading' | 'loaded';
} | {
  readonly status: 'unavailable' | 'failed';
  readonly message: string;
};
/**
 * **Roles and permissions (F8.4), bound to the role admin API (#429).**
 *
 * 🔴 **The banner is a control, not decoration.** The seven permissions are provisional pending
 * the business ruling on issue #138, and the stopgap `CwsContractWriter` policy has already been
 * read **twice** as though this matrix were built. A screen that creates roles and assigns them is
 * the most convincing possible version of that mistake, so the screen says what it is, above the
 * content, every time. The row stays 🔄 on #138 whatever is built here.
 *
 * ### 🔑 The permission↔role mapping is the server's rows
 *
 * Each role's `permissionKeys` come from `GET /admin/roles` and go back whole on update (the server
 * replaces the set). The permission list comes from `GET /admin/permissions` through
 * `PERMISSION_CATALOG_SOURCE`. Nothing here branches on a particular permission or role, so #138's
 * ruling changes data, not this screen.
 *
 * ### ⚠ What this screen deliberately does NOT do
 *
 * It ships no role catalogue. 01 §5 rules the role list *"a workshop item and must not be invented
 * here"*. An administrator creates roles; the client seeds none.
 *
 * ### The server's rules, as the screen meets them
 *
 * - The built-in `Admin` role (`isSystem`) has its Edit and Delete disabled rather than letting the
 *   call answer `409`.
 * - A `409` (stale version, a held or inherited role) and a `503` (CTRM could not check the trade
 *   unit) show the server's sentence as-is.
 * - An object id that is not a GUID is refused here, before any request (C-13).
 * - After an assignment write the screen re-renders from the rows the server returns, rather than
 *   predicting where the default went.
 */
export declare class RolesPageComponent {
  /**
   * Which of the page's views to show (#825): roles, assignments, the permission list, or `all` of it
   * as on the old single Admin page. The Admin routes set it from `data.view`; mounted on its own the
   * page shows everything. The provisional banner is on every view.
   */
  readonly view: import("@angular/core").InputSignalWithTransform<RolesView, RolesView | null | undefined>;
  protected readonly showPermissions: import("@angular/core").Signal<boolean>;
  protected readonly showRoles: import("@angular/core").Signal<boolean>;
  protected readonly showAssignments: import("@angular/core").Signal<boolean>;
  /** True when routed as one of the section's tabs, which is when the tabs are shown. */
  protected readonly routed: import("@angular/core").Signal<boolean>;
  protected readonly area: import("@cws/features-admin").AdminArea;
  /**
   * #696, #825: an account KNOWN not to hold Admin gets the reason rather than the panel. Optional,
   * so a host or spec mounting this page without the Admin section's scope sees it as before.
   */
  private readonly access;
  protected readonly refused: import("@angular/core").Signal<boolean>;
  /** Each role's actions, for its ⋯ menu (#825). Refused with the reason the buttons gave. */
  protected readonly roleActions: import("@angular/core").Signal<Map<string, GridRowAction<Role>[]>>;
  /** One assignment's key: a user holds a role once per trade unit. */
  protected assignmentKey(row: RoleAssignment): string;
  /** Each assignment's actions, for its ⋯ menu (#825). Make default only where it is not already. */
  protected readonly assignmentActions: import("@angular/core").Signal<Map<string, GridRowAction<RoleAssignment>[]>>;
  private readonly catalogSource;
  private readonly source;
  private readonly confirm;
  private readonly destroyRef;
  private readonly answer;
  /** The catalogue once it has answered; the built-in copy until then is never shown as the API's. */
  private readonly catalog;
  /** The permissions to render. Empty while the catalogue is loading. */
  protected readonly permissions: import("@angular/core").Signal<readonly import("@cws/domain-contracts").PermissionCatalogEntry[]>;
  /** True when the permissions are the built-in copy rather than the server's answer. */
  protected readonly isBuiltInCopy: import("@angular/core").Signal<boolean>;
  protected readonly offered: boolean;
  protected readonly rolesState: import("@angular/core").WritableSignal<ListState>;
  /**
   * The roles an administrator manages. ⚠ Named `roleRows`, never `roles`: a feature library calling
   * a signal of that name is what `feature-reads-no-roles.spec.ts` refuses, because it reads as a
   * screen checking the caller's own roles. These are rows, not the caller's grants.
   */
  protected readonly roleRows: import("@angular/core").WritableSignal<readonly Role[]>;
  protected readonly storeOrigin: import("@angular/core").WritableSignal<string | null>;
  protected readonly roleEditor: import("@angular/core").WritableSignal<RoleEditor | null>;
  protected readonly roleBusy: import("@angular/core").WritableSignal<boolean>;
  /**
   * The last role write's outcome (#803): a success, or the server's sentence as-is (a stale version,
   * the built-in role, a held or inherited role) with its reference and a Reload.
   */
  protected readonly roleOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly roleFieldErrors: import("@angular/core").WritableSignal<Readonly<Record<string, readonly string[]>>>;
  protected readonly rolesProblem: import("@angular/core").Signal<string | null>;
  /** Roles an edited role could inherit from: every role but itself. */
  protected readonly parentChoices: import("@angular/core").Signal<Role[]>;
  protected readonly filter: {
    tradeUnit: string;
    userObjectId: string;
  };
  protected readonly assignmentsState: import("@angular/core").WritableSignal<ListState>;
  protected readonly assignments: import("@angular/core").WritableSignal<readonly RoleAssignment[]>;
  protected readonly assignmentBusy: import("@angular/core").WritableSignal<boolean>;
  /** The last assignment write's outcome (#803), with the server's reference on a failure. */
  protected readonly assignmentOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly assignmentFieldErrors: import("@angular/core").WritableSignal<Readonly<Record<string, readonly string[]>>>;
  protected readonly filterError: import("@angular/core").WritableSignal<string | null>;
  protected readonly assignment: AssignmentForm;
  /** The filter the shown rows were read with, so a write's returned rows are kept to it. */
  private shownFilter;
  protected readonly assignmentsProblem: import("@angular/core").Signal<string | null>;
  constructor();
  protected permissionName(key: string): string;
  protected roleName(id: string | null): string;
  protected systemReason(role: Role): string | null;
  protected loadRoles(): void;
  protected newRole(): void;
  protected editRole(role: Role): void;
  protected cancelRole(): void;
  protected hasPermission(editor: RoleEditor, key: string): boolean;
  protected togglePermission(editor: RoleEditor, key: string, granted: boolean): void;
  protected saveRole(): void;
  protected deleteRole(role: Role): void;
  private openRole;
  /** One role write, then a re-read: the version shown is always the server's. */
  private runRole;
  protected loadAssignments(): void;
  protected assign(): void;
  protected setDefault(row: RoleAssignment): void;
  protected revoke(row: RoleAssignment): void;
  /**
   * One assignment write. The server answers all of that user's rows, so the user's shown rows
   * are replaced by them (kept to the filter the list was read with), never patched by guesswork.
   */
  private runAssignment;
  static ɵfac: i0.ɵɵFactoryDeclaration<RolesPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RolesPageComponent, "cws-roles-page", never, {
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Injectable, computed, inject, input, linkedSignal, output, signal } from "@angular/core";
import { ActivatedRoute, RouterLink, RouterLinkActive, RouterOutlet } from "@angular/router";
import { takeUntilDestroyed, toSignal } from "@angular/core/rxjs-interop";
import { ADDENDUM_DATE_ANCHOR, ADDENDUM_INITIALS_ANCHOR, ADDENDUM_SIGNATURE_ANCHOR, ADDENDUM_TEMPLATE_SOURCE, ADDENDUM_TYPE_SOURCE, CONTRACTS_API_URL, CONTRACT_GRID_COLUMNS, CONTRACT_LAYOUT_FIELD_NOTES, CONTRACT_LAYOUT_HALF_FIELDS, CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS, DEFAULT_ADDENDUM_CONTENT_FORMAT, DEFAULT_ADDENDUM_LANGUAGE, FAMILY_B_ADDENDUM_FIELD_SETS, FORM_CONFIG_ADMIN_SOURCE, LOCATION_SOURCE, ME_SOURCE, OBJECT_ID_REFUSAL, PERMISSION_CATALOG_SOURCE, PINNED_GRID_COLUMN, ROLE_ADMIN_SOURCE, SIMULATED_PERMISSION_CATALOG, SamplePermissionCatalogSource, UNKNOWN_SETTINGS_SCOPE, addendumAnchorProblems, adminRefusalOf, diffConfigDocuments, emptiedTabs, gridColumnChoices, isEntraObjectId, settingsScopeOf, tabsAfterCascade, typeDraftOf, userGridColumnKeys } from "@cws/domain-contracts";
import { map, of } from "rxjs";
import * as i1 from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { CONSTRAINT_SOURCE } from "@cws/shared-form-engine";
import { AsyncContainerComponent, DateInputComponent, ExportFieldsComponent, PageHeaderComponent, PointerDragGesture, RowMenuComponent, StatusMessageComponent, elementUnder, injectConfirm, mutationFailed, mutationRefused, mutationSucceeded, remoteLoading } from "@cws/shared-ui";
import { HttpClient } from "@angular/common/http";
const ADMIN_AREAS = [
	{
		path: "form-configuration",
		title: "Form configuration",
		summary: "Which fields the contract record shows and requires, and which tabs it has, per contract type, trade unit and commodity.",
		adminOnly: false,
		views: [{
			path: "",
			label: "Configuration rows"
		}, {
			path: "preview",
			label: "Preview a resolution"
		}]
	},
	{
		path: "trade-unit-values",
		title: "Trade unit values",
		summary: "Narrow the code-list values and market months a trade unit offers on its contracts.",
		adminOnly: false,
		views: []
	},
	{
		path: "addendums",
		title: "Addendums",
		summary: "The in-house addendum templates, and the addendum types a contract can carry.",
		adminOnly: false,
		views: [{
			path: "",
			label: "Templates"
		}, {
			path: "types",
			label: "Types"
		}]
	},
	{
		path: "roles",
		title: "Roles and permissions",
		summary: "Roles, who holds them in which trade unit, and the provisional permission set they are built from.",
		adminOnly: true,
		views: [
			{
				path: "",
				label: "Roles"
			},
			{
				path: "assignments",
				label: "Assignments"
			},
			{
				path: "permissions",
				label: "Permissions"
			}
		]
	}
];
function adminArea(path) {
	const area = ADMIN_AREAS.find((each) => each.path === path);
	if (area === void 0) throw new Error(`No admin area "${path}".`);
	return area;
}
var AdminScope = class AdminScope {
	me = inject(ME_SOURCE, { optional: true });
	locationSource = inject(LOCATION_SOURCE, { optional: true });
	scope = toSignal(this.me === null ? of(UNKNOWN_SETTINGS_SCOPE) : this.me.get().pipe(map((state) => settingsScopeOf(state.status === "loaded" ? state.value : null))), { initialValue: UNKNOWN_SETTINGS_SCOPE });
	locationList = toSignal(this.locationSource === null ? of(null) : this.locationSource.list().pipe(map((state) => state.status === "loaded" ? state.value : null)), { initialValue: null });
	locations = computed(() => this.locationList()?.locations ?? null, ...ngDevMode ? [{ debugName: "locations" }] : /* istanbul ignore next */ []);
	locationOrigin = computed(() => this.locationList()?.dataOrigin ?? null, ...ngDevMode ? [{ debugName: "locationOrigin" }] : /* istanbul ignore next */ []);
	knownNotAdmin = computed(() => this.scope().known && !this.scope().isAdmin, ...ngDevMode ? [{ debugName: "knownNotAdmin" }] : /* istanbul ignore next */ []);
	nameOf(code) {
		return this.locations()?.find((location) => location.code === code)?.name ?? null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AdminScope,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AdminScope
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AdminScope,
	decorators: [{ type: Injectable }]
});
var AdminPageComponent = class AdminPageComponent {
	access = inject(AdminScope);
	areas = computed(() => ADMIN_AREAS.filter((area) => !area.adminOnly || !this.access.knownNotAdmin()), ...ngDevMode ? [{ debugName: "areas" }] : /* istanbul ignore next */ []);
	linkClass = "cws:block cws:whitespace-nowrap cws:rounded cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60 cws:aria-[current=page]:bg-slate-100 cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:bg-slate-700 cws:dark:aria-[current=page]:text-sky-300";
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AdminPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AdminPageComponent,
		isStandalone: true,
		selector: "cms-admin-page",
		host: { classAttribute: "cws:block" },
		providers: [AdminScope],
		ngImport: i0,
		template: `
    <div class="cws:grid cws:gap-6 cws:lg:grid-cols-[13rem_minmax(0,1fr)]">
      <nav aria-label="Admin" class="cws:min-w-0">
        <ul class="cws:flex cws:gap-1 cws:overflow-x-auto cws:border-b cws:border-slate-200 cws:pb-2 cws:lg:flex-col cws:lg:border-b-0 cws:lg:border-r cws:lg:pb-0 cws:lg:pr-3 cws:dark:border-slate-700">
          <li>
            <a
              [class]="linkClass"
              routerLink="."
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >Overview</a
            >
          </li>
          @for (area of areas(); track area.path) {
            <li>
              <!-- Not exact: an area stays marked on each of its tabs. -->
              <a
                [class]="linkClass"
                [routerLink]="area.path"
                routerLinkActive=""
                ariaCurrentWhenActive="page"
                >{{ area.title }}</a
              >
            </li>
          }
        </ul>
      </nav>

      <div class="cws:min-w-0">
        <router-outlet />
      </div>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			},
			{
				kind: "directive",
				type: RouterOutlet,
				selector: "router-outlet",
				inputs: ["name", "routerOutletData"],
				outputs: [
					"activate",
					"deactivate",
					"attach",
					"detach"
				],
				exportAs: ["outlet"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AdminPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-admin-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				RouterLink,
				RouterLinkActive,
				RouterOutlet
			],
			providers: [AdminScope],
			host: { class: "cws:block" },
			template: `
    <div class="cws:grid cws:gap-6 cws:lg:grid-cols-[13rem_minmax(0,1fr)]">
      <nav aria-label="Admin" class="cws:min-w-0">
        <ul class="cws:flex cws:gap-1 cws:overflow-x-auto cws:border-b cws:border-slate-200 cws:pb-2 cws:lg:flex-col cws:lg:border-b-0 cws:lg:border-r cws:lg:pb-0 cws:lg:pr-3 cws:dark:border-slate-700">
          <li>
            <a
              [class]="linkClass"
              routerLink="."
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >Overview</a
            >
          </li>
          @for (area of areas(); track area.path) {
            <li>
              <!-- Not exact: an area stays marked on each of its tabs. -->
              <a
                [class]="linkClass"
                [routerLink]="area.path"
                routerLinkActive=""
                ariaCurrentWhenActive="page"
                >{{ area.title }}</a
              >
            </li>
          }
        </ul>
      </nav>

      <div class="cws:min-w-0">
        <router-outlet />
      </div>
    </div>
  `
		}]
	}]
});
let nextId$2 = 0;
var AddendumPlaceholderFieldsComponent = class AddendumPlaceholderFieldsComponent {
	rows = input.required(...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	groups = input.required(...ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []);
	ctrmListed = input(true, ...ngDevMode ? [{ debugName: "ctrmListed" }] : /* istanbul ignore next */ []);
	describedBy = input(null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	invalid = input(false, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	fieldChange = output();
	removed = output();
	listId = `cws-addendum-fields-${nextId$2++}`;
	example = "{{contract_number}}";
	offered = computed(() => new Set(this.groups().flatMap((group) => group.options.map((option) => option.value))), ...ngDevMode ? [{ debugName: "offered" }] : /* istanbul ignore next */ []);
	braces(placeholder) {
		return `{{${placeholder}}}`;
	}
	pick(placeholder, field) {
		this.fieldChange.emit({
			placeholder,
			field: field.trim()
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AddendumPlaceholderFieldsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AddendumPlaceholderFieldsComponent,
		isStandalone: true,
		selector: "cws-addendum-placeholder-fields",
		inputs: {
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			groups: {
				classPropertyName: "groups",
				publicName: "groups",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			ctrmListed: {
				classPropertyName: "ctrmListed",
				publicName: "ctrmListed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedBy: {
				classPropertyName: "describedBy",
				publicName: "describedBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			fieldChange: "fieldChange",
			removed: "removed"
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <fieldset class="cws:space-y-2" [attr.aria-describedby]="describedBy()" [attr.aria-invalid]="invalid()" data-testid="placeholder-fields">
      <legend class="cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400">Fields</legend>
      <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
        Read from the template content: write a placeholder as {{ example }} where a value goes, then pick the
        field it prints. A CTRM field prints the contract's value; an addendum field prints what the trader enters;
        a customer-master or generated field is filled in by the server when the addendum is made.
      </p>

      @if (rows().length === 0) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-empty">
          No placeholders in the template content yet.
        </p>
      } @else {
        <table class="cws:w-full cws:text-left cws:text-xs">
          <thead class="cws:text-slate-500 cws:dark:text-slate-400">
            <tr>
              <th class="cws:py-1">Placeholder</th>
              <th class="cws:py-1">Field</th>
              <th class="cws:py-1" aria-label="Status"></th>
            </tr>
          </thead>
          <tbody>
            @for (row of rows(); track row.placeholder) {
              <tr class="cws:border-t cws:border-slate-100 cws:dark:border-slate-800" [attr.data-placeholder]="row.placeholder">
                <td class="cws:py-1 cws:pr-2 cws:font-mono">{{ braces(row.placeholder) }}</td>
                <td class="cws:py-1 cws:pr-2">
                  @if (ctrmListed()) {
                    <select
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [disabled]="disabled()"
                      (change)="pick(row.placeholder, $any($event.target).value)"
                    >
                      <option value="" [selected]="row.field === ''">Pick a field</option>
                      @if (row.field !== '' && !offered().has(row.field)) {
                        <option [value]="row.field" selected>{{ row.field }} · not in the list</option>
                      }
                      @for (group of groups(); track group.label) {
                        <optgroup [label]="group.label">
                          @for (option of group.options; track option.value) {
                            <option [value]="option.value" [selected]="option.value === row.field">{{ option.label }}</option>
                          }
                        </optgroup>
                      }
                    </select>
                  } @else {
                    <input
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [attr.list]="listId"
                      placeholder="contract_number, or addendum_call_strike"
                      [value]="row.field"
                      [disabled]="disabled()"
                      (input)="pick(row.placeholder, $any($event.target).value)"
                    />
                  }
                </td>
                <td class="cws:py-1">
                  @if (!row.inText) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400">Not in the text any more; kept until removed.</span>
                    <button
                      type="button"
                      class="scoular-btn scoular-btn-secondary cws:ml-2"
                      [attr.aria-label]="'Remove ' + row.placeholder"
                      [disabled]="disabled()"
                      (click)="removed.emit(row.placeholder)"
                    >
                      Remove
                    </button>
                  } @else if (row.field === '') {
                    <span class="cws:text-rose-700 cws:dark:text-rose-300" data-testid="placeholder-unmapped">No field: would print blank</span>
                  } @else if (row.suggested) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-suggested">Matched by name</span>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      }

      @if (!ctrmListed()) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-no-ctrm-list">
          CTRM's field list could not be read here, so type the field name. The server checks it on Save.
        </p>
        <datalist [id]="listId">
          @for (group of groups(); track group.label) {
            @for (option of group.options; track option.value) {
              <option [value]="option.value">{{ option.label }}</option>
            }
          }
        </datalist>
      }
    </fieldset>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AddendumPlaceholderFieldsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-addendum-placeholder-fields",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: `
    <fieldset class="cws:space-y-2" [attr.aria-describedby]="describedBy()" [attr.aria-invalid]="invalid()" data-testid="placeholder-fields">
      <legend class="cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400">Fields</legend>
      <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
        Read from the template content: write a placeholder as {{ example }} where a value goes, then pick the
        field it prints. A CTRM field prints the contract's value; an addendum field prints what the trader enters;
        a customer-master or generated field is filled in by the server when the addendum is made.
      </p>

      @if (rows().length === 0) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-empty">
          No placeholders in the template content yet.
        </p>
      } @else {
        <table class="cws:w-full cws:text-left cws:text-xs">
          <thead class="cws:text-slate-500 cws:dark:text-slate-400">
            <tr>
              <th class="cws:py-1">Placeholder</th>
              <th class="cws:py-1">Field</th>
              <th class="cws:py-1" aria-label="Status"></th>
            </tr>
          </thead>
          <tbody>
            @for (row of rows(); track row.placeholder) {
              <tr class="cws:border-t cws:border-slate-100 cws:dark:border-slate-800" [attr.data-placeholder]="row.placeholder">
                <td class="cws:py-1 cws:pr-2 cws:font-mono">{{ braces(row.placeholder) }}</td>
                <td class="cws:py-1 cws:pr-2">
                  @if (ctrmListed()) {
                    <select
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [disabled]="disabled()"
                      (change)="pick(row.placeholder, $any($event.target).value)"
                    >
                      <option value="" [selected]="row.field === ''">Pick a field</option>
                      @if (row.field !== '' && !offered().has(row.field)) {
                        <option [value]="row.field" selected>{{ row.field }} · not in the list</option>
                      }
                      @for (group of groups(); track group.label) {
                        <optgroup [label]="group.label">
                          @for (option of group.options; track option.value) {
                            <option [value]="option.value" [selected]="option.value === row.field">{{ option.label }}</option>
                          }
                        </optgroup>
                      }
                    </select>
                  } @else {
                    <input
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [attr.list]="listId"
                      placeholder="contract_number, or addendum_call_strike"
                      [value]="row.field"
                      [disabled]="disabled()"
                      (input)="pick(row.placeholder, $any($event.target).value)"
                    />
                  }
                </td>
                <td class="cws:py-1">
                  @if (!row.inText) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400">Not in the text any more; kept until removed.</span>
                    <button
                      type="button"
                      class="scoular-btn scoular-btn-secondary cws:ml-2"
                      [attr.aria-label]="'Remove ' + row.placeholder"
                      [disabled]="disabled()"
                      (click)="removed.emit(row.placeholder)"
                    >
                      Remove
                    </button>
                  } @else if (row.field === '') {
                    <span class="cws:text-rose-700 cws:dark:text-rose-300" data-testid="placeholder-unmapped">No field: would print blank</span>
                  } @else if (row.suggested) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-suggested">Matched by name</span>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      }

      @if (!ctrmListed()) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-no-ctrm-list">
          CTRM's field list could not be read here, so type the field name. The server checks it on Save.
        </p>
        <datalist [id]="listId">
          @for (group of groups(); track group.label) {
            @for (option of group.options; track option.value) {
              <option [value]="option.value">{{ option.label }}</option>
            }
          }
        </datalist>
      }
    </fieldset>
  `
		}]
	}],
	propDecorators: {
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: true
			}]
		}],
		groups: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groups",
				required: true
			}]
		}],
		ctrmListed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ctrmListed",
				required: false
			}]
		}],
		describedBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedBy",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		fieldChange: [{
			type: i0.Output,
			args: ["fieldChange"]
		}],
		removed: [{
			type: i0.Output,
			args: ["removed"]
		}]
	}
});
const PLACEHOLDER_PATTERN = /\{\{\s*([A-Za-z0-9_]+)\s*\}\}/g;
function templatePlaceholders(content) {
	const names = [];
	for (const match of (content ?? "").matchAll(PLACEHOLDER_PATTERN)) if (!names.includes(match[1])) names.push(match[1]);
	return names;
}
function mappingsOf(fields) {
	return Object.fromEntries(fields.map((entry) => [entry.placeholder, entry.field]));
}
function placeholderRows(content, mappings, suggest = () => null) {
	const inText = templatePlaceholders(content);
	const rows = inText.map((placeholder) => {
		if (Object.hasOwn(mappings, placeholder)) return {
			placeholder,
			field: mappings[placeholder],
			inText: true,
			suggested: false
		};
		const suggestion = suggest(placeholder);
		return {
			placeholder,
			field: suggestion ?? "",
			inText: true,
			suggested: suggestion !== null
		};
	});
	for (const [placeholder, field] of Object.entries(mappings)) if (!inText.includes(placeholder) && field !== "") rows.push({
		placeholder,
		field,
		inText: false,
		suggested: false
	});
	return rows;
}
function unmappedPlaceholders(rows) {
	return rows.filter((row) => row.inText && row.field.trim() === "").map((row) => row.placeholder);
}
function unmappedPlaceholdersMessage(placeholders) {
	return `These placeholders are in the template but not mapped to a field, so they would print blank: ${[...placeholders].sort(ordinal).join(", ")}.`;
}
function fieldsOf(rows) {
	return rows.filter((row) => row.field.trim() !== "").map((row) => ({
		placeholder: row.placeholder,
		field: row.field.trim()
	}));
}
function addendumFieldGroups(specialTypes) {
	const codes = specialTypes.map((code) => code.trim());
	const matched = FAMILY_B_ADDENDUM_FIELD_SETS.filter((set) => set.specialTypes.some((code) => codes.includes(code)));
	return (matched.length > 0 ? matched : FAMILY_B_ADDENDUM_FIELD_SETS).map((set) => ({
		label: `${set.title} fields (${set.specialTypes.join(", ")})`,
		options: set.fields.map((field) => ({
			value: field.cwsField,
			label: `${field.cwsField} · ${field.label}`
		}))
	}));
}
const SERVER_SUPPLIED_FIELD_GROUPS = [{
	label: "Customer master (filled in by the server)",
	fields: [
		{
			field: "customer.merchandisingName",
			label: "Seller name",
			optional: false,
			sample: "[Seller name]"
		},
		{
			field: "customer.merchandisingAddressLine1",
			label: "Address line 1",
			optional: false,
			sample: "[Address line 1]"
		},
		{
			field: "customer.merchandisingAddressLine2",
			label: "Address line 2",
			optional: true,
			sample: "[Address line 2]"
		},
		{
			field: "customer.merchandisingCity",
			label: "City",
			optional: false,
			sample: "[City]"
		},
		{
			field: "customer.merchandisingStateProvince",
			label: "State or province",
			optional: false,
			sample: "[ST]"
		},
		{
			field: "customer.merchandisingPostalCode",
			label: "Postal code",
			optional: false,
			sample: "[Postal code]"
		},
		{
			field: "customer.merchandisingCountry",
			label: "Country",
			optional: false,
			sample: "[Country]"
		},
		{
			field: "customer.merchandisingPhone",
			label: "Phone",
			optional: true,
			sample: "[Phone]"
		},
		{
			field: "customer.merchandisingCityStatePostal",
			label: "City, state and postal code, on one line",
			optional: false,
			sample: "[City], [ST] [Postal code]"
		}
	]
}, {
	label: "Generated (filled in by the server)",
	fields: [{
		field: "generated.addendumDate",
		label: "Addendum date, the day it is generated (Central time)",
		optional: false,
		sample: "12/15/2026"
	}]
}];
function serverSuppliedFieldOf(field) {
	return SERVER_SUPPLIED_FIELD_GROUPS.flatMap((group) => group.fields).find((candidate) => candidate.field === field) ?? null;
}
function serverFieldGroups() {
	return SERVER_SUPPLIED_FIELD_GROUPS.map((group) => ({
		label: group.label,
		options: group.fields.map((field) => ({
			value: field.field,
			label: `${field.field} · ${field.label}${field.optional ? " (optional: a blank drops its line)" : ""}`
		}))
	}));
}
function rewritten(document, field) {
	const entry = document.fields[field];
	return entry?.rewrittenOnWrite !== void 0 && entry.rewrittenOnWrite !== null;
}
function refusedOnTemplate(document, field) {
	if (rewritten(document, field)) return true;
	if (!field.endsWith("_description")) return false;
	const base = field.slice(0, -12);
	return rewritten(document, base) || rewritten(document, `${base}_code`);
}
function ctrmFieldGroup(document) {
	return {
		label: "CTRM fields",
		options: Object.keys(document.fields).filter((field) => !refusedOnTemplate(document, field)).sort(ordinal).map((field) => ({
			value: field,
			label: field
		}))
	};
}
function suggestedField(placeholder, groups) {
	const offered = new Set(groups.flatMap((group) => group.options.map((option) => option.value)));
	for (const candidate of [placeholder, `addendum_${placeholder}`]) if (offered.has(candidate)) return candidate;
	return null;
}
const SAMPLE_DATE = "2026-12-15";
function cwsFieldOf(field) {
	return FAMILY_B_ADDENDUM_FIELD_SETS.flatMap((set) => set.fields).find((candidate) => candidate.cwsField === field) ?? null;
}
function sampleValueFor(field, document) {
	const supplied = serverSuppliedFieldOf(field);
	if (supplied !== null) return supplied.sample;
	const cws = cwsFieldOf(field);
	if (cws !== null) return cws.kind === "date" ? SAMPLE_DATE : cws.kind === "price" ? "1.2500" : `[${cws.label}]`;
	const entry = document?.fields[field];
	switch (entry?.type) {
		case "date": return SAMPLE_DATE;
		case "number":
		case "integer": return (entry.scale ?? 0) > 0 ? `100.${"0".repeat(entry.scale)}` : "100";
		default: return `[${field}]`;
	}
}
function previewSegments(content, rows, document) {
	const fieldOf = new Map(rows.map((row) => [row.placeholder, row.field.trim()]));
	const segments = [];
	let last = 0;
	for (const match of content.matchAll(PLACEHOLDER_PATTERN)) {
		const index = match.index ?? 0;
		if (index > last) segments.push({
			kind: "text",
			text: content.slice(last, index)
		});
		const field = fieldOf.get(match[1]) ?? "";
		segments.push(field === "" ? {
			kind: "missing",
			text: `[${match[1]}: no field]`
		} : {
			kind: "value",
			text: sampleValueFor(field, document)
		});
		last = index + match[0].length;
	}
	if (last < content.length) segments.push({
		kind: "text",
		text: content.slice(last)
	});
	return segments;
}
function ordinal(left, right) {
	return left < right ? -1 : left > right ? 1 : 0;
}
const MAX_MATCHES = 8;
let nextId$1 = 0;
var AdminCodePickerComponent = class AdminCodePickerComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	name = input(null, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	codes = input([], ...ngDevMode ? [{ debugName: "codes" }] : /* istanbul ignore next */ []);
	options = input(null, ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	unknownMessage = input.required(...ngDevMode ? [{ debugName: "unknownMessage" }] : /* istanbul ignore next */ []);
	emptyMeaning = input(null, ...ngDevMode ? [{ debugName: "emptyMeaning" }] : /* istanbul ignore next */ []);
	note = input(null, ...ngDevMode ? [{ debugName: "note" }] : /* istanbul ignore next */ []);
	searchPlaceholder = input("Type a code or name", ...ngDevMode ? [{ debugName: "searchPlaceholder" }] : /* istanbul ignore next */ []);
	freePlaceholder = input(null, ...ngDevMode ? [{ debugName: "freePlaceholder" }] : /* istanbul ignore next */ []);
	describedBy = input(null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	invalid = input(false, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	codesChange = output();
	labelId = `cws-code-picker-${nextId$1}-label`;
	listId = `cws-code-picker-${nextId$1++}-list`;
	term = signal("", ...ngDevMode ? [{ debugName: "term" }] : /* istanbul ignore next */ []);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	active = signal(0, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	refusal = signal(null, ...ngDevMode ? [{ debugName: "refusal" }] : /* istanbul ignore next */ []);
	matches = computed(() => {
		const term = this.term().trim().toLowerCase();
		const picked = new Set(this.codes());
		return (this.options() ?? []).filter((option) => !picked.has(option.code)).filter((option) => term === "" || option.code.toLowerCase().includes(term) || option.label.toLowerCase().includes(term)).slice(0, MAX_MATCHES);
	}, ...ngDevMode ? [{ debugName: "matches" }] : /* istanbul ignore next */ []);
	activeId = computed(() => this.open() && this.matches().length > 0 ? this.optionId(this.active()) : null, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	optionId(index) {
		return `${this.listId}-${index}`;
	}
	known(code) {
		return this.options()?.some((option) => option.code === code) ?? true;
	}
	chipLabel(code) {
		const option = this.options()?.find((candidate) => candidate.code === code);
		return option === void 0 ? `${code} · not in the list` : option.label;
	}
	onInput(value) {
		this.term.set(value);
		this.open.set(true);
		this.active.set(0);
		this.refusal.set(null);
	}
	onKeydown(event) {
		const count = this.matches().length;
		switch (event.key) {
			case "ArrowDown":
				event.preventDefault();
				this.open.set(true);
				this.active.set(count === 0 ? 0 : (this.active() + 1) % count);
				break;
			case "ArrowUp":
				event.preventDefault();
				this.open.set(true);
				this.active.set(count === 0 ? 0 : (this.active() - 1 + count) % count);
				break;
			case "Home":
				if (this.open()) {
					event.preventDefault();
					this.active.set(0);
				}
				break;
			case "End":
				if (this.open()) {
					event.preventDefault();
					this.active.set(Math.max(0, count - 1));
				}
				break;
			case "Escape":
				this.open.set(false);
				break;
			case "Enter":
				event.preventDefault();
				this.commit();
				break;
			case "Backspace": if (this.term() === "" && this.codes().length > 0) this.remove(this.codes()[this.codes().length - 1]);
		}
	}
	commit() {
		const typed = this.term().trim();
		const exact = (this.options() ?? []).find((option) => option.code.toLowerCase() === typed.toLowerCase());
		if (exact !== void 0) {
			this.add(exact.code);
			return;
		}
		const highlighted = this.open() ? this.matches()[this.active()] : void 0;
		if (highlighted !== void 0) {
			this.add(highlighted.code);
			return;
		}
		if (typed !== "") this.refusal.set(this.unknownMessage()([typed]));
	}
	add(code) {
		if (!this.codes().includes(code)) this.codesChange.emit([...this.codes(), code]);
		this.term.set("");
		this.active.set(0);
		this.refusal.set(null);
	}
	remove(code) {
		this.codesChange.emit(this.codes().filter((candidate) => candidate !== code));
	}
	freeText = linkedSignal({
		...ngDevMode ? { debugName: "freeText" } : /* istanbul ignore next */ {},
		source: () => this.codes(),
		computation: (codes, previous) => previous !== void 0 && sameCodes(listOf(previous.value), codes) ? previous.value : codes.join(", ")
	});
	onFreeInput(value) {
		this.freeText.set(value);
		this.codesChange.emit(listOf(value));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AdminCodePickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AdminCodePickerComponent,
		isStandalone: true,
		selector: "cws-admin-code-picker",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			codes: {
				classPropertyName: "codes",
				publicName: "codes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			unknownMessage: {
				classPropertyName: "unknownMessage",
				publicName: "unknownMessage",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			emptyMeaning: {
				classPropertyName: "emptyMeaning",
				publicName: "emptyMeaning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			note: {
				classPropertyName: "note",
				publicName: "note",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			searchPlaceholder: {
				classPropertyName: "searchPlaceholder",
				publicName: "searchPlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			freePlaceholder: {
				classPropertyName: "freePlaceholder",
				publicName: "freePlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedBy: {
				classPropertyName: "describedBy",
				publicName: "describedBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { codesChange: "codesChange" },
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <span class="cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400" [id]="labelId">
      {{ label() }}
    </span>

    @if (options() === null) {
      <input
        class="scoular-form-input cws:mt-1 cws:w-full cws:font-mono"
        [attr.name]="name()"
        [attr.aria-labelledby]="labelId"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid()"
        [attr.placeholder]="freePlaceholder()"
        [value]="freeText()"
        [disabled]="disabled()"
        (input)="onFreeInput($any($event.target).value)"
      />
    } @else {
      @if (codes().length > 0) {
        <ul class="cws:mt-1 cws:flex cws:flex-wrap cws:gap-1" [attr.aria-label]="label() + ' picked'" data-testid="code-picker-chips">
          @for (code of codes(); track code) {
            <li
              class="cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:px-2 cws:py-0.5 cws:text-xs"
              [class.cws:border-slate-300]="known(code)"
              [class.cws:border-rose-400]="!known(code)"
            >
              <span>{{ chipLabel(code) }}</span>
              <button
                type="button"
                class="cws:text-slate-500 cws:hover:text-slate-900 cws:dark:hover:text-white"
                [attr.aria-label]="'Remove ' + code"
                [disabled]="disabled()"
                (click)="remove(code)"
              >
                ×
              </button>
            </li>
          }
        </ul>
      } @else if (emptyMeaning()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ emptyMeaning() }}</p>
      }

      <input
        class="scoular-form-input cws:mt-1 cws:w-full"
        type="search"
        role="combobox"
        aria-autocomplete="list"
        [attr.name]="name()"
        [attr.aria-labelledby]="labelId"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid() || refusal() !== null"
        [attr.aria-expanded]="open()"
        [attr.aria-controls]="listId"
        [attr.aria-activedescendant]="activeId()"
        [attr.placeholder]="searchPlaceholder()"
        [value]="term()"
        [disabled]="disabled()"
        (input)="onInput($any($event.target).value)"
        (keydown)="onKeydown($event)"
        (blur)="open.set(false)"
      />

      @if (open() && matches().length > 0) {
        <ul
          class="cws:mt-1 cws:max-h-60 cws:overflow-auto cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:text-xs cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800"
          role="listbox"
          [id]="listId"
          [attr.aria-label]="label() + ' matches'"
        >
          @for (option of matches(); track option.code; let index = $index) {
            <li
              role="option"
              class="cws:cursor-pointer cws:px-2 cws:py-1"
              [id]="optionId(index)"
              [attr.aria-selected]="index === active()"
              [class.cws:bg-slate-100]="index === active()"
              [class.cws:dark:bg-slate-700]="index === active()"
              (mousedown)="$event.preventDefault()"
              (click)="add(option.code)"
            >
              {{ option.label }}
            </li>
          }
        </ul>
      }

      @if (refusal(); as reason) {
        <p class="cws:mt-1 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300" role="alert" data-testid="code-picker-refusal">
          {{ reason }}
        </p>
      }

      @if (note()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="code-picker-note">{{ note() }}</p>
      }
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AdminCodePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-code-picker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: `
    <span class="cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400" [id]="labelId">
      {{ label() }}
    </span>

    @if (options() === null) {
      <input
        class="scoular-form-input cws:mt-1 cws:w-full cws:font-mono"
        [attr.name]="name()"
        [attr.aria-labelledby]="labelId"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid()"
        [attr.placeholder]="freePlaceholder()"
        [value]="freeText()"
        [disabled]="disabled()"
        (input)="onFreeInput($any($event.target).value)"
      />
    } @else {
      @if (codes().length > 0) {
        <ul class="cws:mt-1 cws:flex cws:flex-wrap cws:gap-1" [attr.aria-label]="label() + ' picked'" data-testid="code-picker-chips">
          @for (code of codes(); track code) {
            <li
              class="cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:px-2 cws:py-0.5 cws:text-xs"
              [class.cws:border-slate-300]="known(code)"
              [class.cws:border-rose-400]="!known(code)"
            >
              <span>{{ chipLabel(code) }}</span>
              <button
                type="button"
                class="cws:text-slate-500 cws:hover:text-slate-900 cws:dark:hover:text-white"
                [attr.aria-label]="'Remove ' + code"
                [disabled]="disabled()"
                (click)="remove(code)"
              >
                ×
              </button>
            </li>
          }
        </ul>
      } @else if (emptyMeaning()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ emptyMeaning() }}</p>
      }

      <input
        class="scoular-form-input cws:mt-1 cws:w-full"
        type="search"
        role="combobox"
        aria-autocomplete="list"
        [attr.name]="name()"
        [attr.aria-labelledby]="labelId"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid() || refusal() !== null"
        [attr.aria-expanded]="open()"
        [attr.aria-controls]="listId"
        [attr.aria-activedescendant]="activeId()"
        [attr.placeholder]="searchPlaceholder()"
        [value]="term()"
        [disabled]="disabled()"
        (input)="onInput($any($event.target).value)"
        (keydown)="onKeydown($event)"
        (blur)="open.set(false)"
      />

      @if (open() && matches().length > 0) {
        <ul
          class="cws:mt-1 cws:max-h-60 cws:overflow-auto cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:text-xs cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800"
          role="listbox"
          [id]="listId"
          [attr.aria-label]="label() + ' matches'"
        >
          @for (option of matches(); track option.code; let index = $index) {
            <li
              role="option"
              class="cws:cursor-pointer cws:px-2 cws:py-1"
              [id]="optionId(index)"
              [attr.aria-selected]="index === active()"
              [class.cws:bg-slate-100]="index === active()"
              [class.cws:dark:bg-slate-700]="index === active()"
              (mousedown)="$event.preventDefault()"
              (click)="add(option.code)"
            >
              {{ option.label }}
            </li>
          }
        </ul>
      }

      @if (refusal(); as reason) {
        <p class="cws:mt-1 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300" role="alert" data-testid="code-picker-refusal">
          {{ reason }}
        </p>
      }

      @if (note()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="code-picker-note">{{ note() }}</p>
      }
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		codes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "codes",
				required: false
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		unknownMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unknownMessage",
				required: true
			}]
		}],
		emptyMeaning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyMeaning",
				required: false
			}]
		}],
		note: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "note",
				required: false
			}]
		}],
		searchPlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "searchPlaceholder",
				required: false
			}]
		}],
		freePlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "freePlaceholder",
				required: false
			}]
		}],
		describedBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedBy",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		codesChange: [{
			type: i0.Output,
			args: ["codesChange"]
		}]
	}
});
function listOf(text) {
	return text.split(",").map((item) => item.trim()).filter((item) => item !== "");
}
function sameCodes(left, right) {
	return left.length === right.length && left.every((code, index) => code === right[index]);
}
var AdminTabsComponent = class AdminTabsComponent {
	views = input.required(...ngDevMode ? [{ debugName: "views" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	area = inject(ActivatedRoute).parent;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AdminTabsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AdminTabsComponent,
		isStandalone: true,
		selector: "cws-admin-tabs",
		inputs: {
			views: {
				classPropertyName: "views",
				publicName: "views",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <nav [attr.aria-label]="label()" class="cws:border-b cws:border-slate-200 cws:dark:border-slate-700">
      <ul class="cws:-mb-px cws:flex cws:gap-1 cws:overflow-x-auto">
        @for (view of views(); track view.path) {
          <li>
            <a
              class="cws:block cws:whitespace-nowrap cws:border-b-2 cws:border-transparent cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white cws:aria-[current=page]:border-scoular-blue cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:border-sky-400 cws:dark:aria-[current=page]:text-sky-400"
              [routerLink]="view.path === '' ? ['.'] : [view.path]"
              [relativeTo]="area"
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >{{ view.label }}</a
            >
          </li>
        }
      </ul>
    </nav>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}, {
			kind: "directive",
			type: RouterLinkActive,
			selector: "[routerLinkActive]",
			inputs: [
				"routerLinkActiveOptions",
				"ariaCurrentWhenActive",
				"routerLinkActive"
			],
			outputs: ["isActiveChange"],
			exportAs: ["routerLinkActive"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AdminTabsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-tabs",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [RouterLink, RouterLinkActive],
			host: { class: "cws:block" },
			template: `
    <nav [attr.aria-label]="label()" class="cws:border-b cws:border-slate-200 cws:dark:border-slate-700">
      <ul class="cws:-mb-px cws:flex cws:gap-1 cws:overflow-x-auto">
        @for (view of views(); track view.path) {
          <li>
            <a
              class="cws:block cws:whitespace-nowrap cws:border-b-2 cws:border-transparent cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white cws:aria-[current=page]:border-scoular-blue cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:border-sky-400 cws:dark:aria-[current=page]:text-sky-400"
              [routerLink]="view.path === '' ? ['.'] : [view.path]"
              [relativeTo]="area"
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >{{ view.label }}</a
            >
          </li>
        }
      </ul>
    </nav>
  `
		}]
	}],
	propDecorators: {
		views: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "views",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}]
	}
});
const TYPE_FIELDS = [
	"specialType",
	"displayName",
	"family"
];
const FAMILIES = ["A", "B"];
var AddendumTypesSectionComponent = class AddendumTypesSectionComponent {
	source = inject(ADDENDUM_TYPE_SOURCE, { optional: true });
	access = inject(AdminScope);
	destroyRef = inject(DestroyRef);
	families = FAMILIES;
	offered = this.source !== null;
	state = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	types = signal([], ...ngDevMode ? [{ debugName: "types" }] : /* istanbul ignore next */ []);
	editor = signal(null, ...ngDevMode ? [{ debugName: "editor" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	typeActions = computed(() => {
		const refusal = () => this.writesRefused() ?? (this.busy() ? "A type change is in progress" : false);
		return new Map(this.types().map((type) => {
			const actions = [{
				label: "Edit",
				run: (row) => this.startEdit(row),
				disabled: refusal
			}];
			if (type.available) actions.push({
				label: "Deactivate",
				run: (row) => this.deactivate(row),
				disabled: refusal
			});
			return [type.specialType, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "typeActions" }] : /* istanbul ignore next */ []);
	writesRefused = computed(() => this.access.knownNotAdmin() ? "Needs the Admin role" : null, ...ngDevMode ? [{ debugName: "writesRefused" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const state = this.state();
		return state.status === "failed" ? state : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	fieldErrors = signal({}, ...ngDevMode ? [{ debugName: "fieldErrors" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	reloadOffered = signal(false, ...ngDevMode ? [{ debugName: "reloadOffered" }] : /* istanbul ignore next */ []);
	constructor() {
		this.load();
	}
	load() {
		const source = this.source;
		if (source === null) return;
		this.state.set({ status: "loading" });
		source.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") this.types.set(answer.value);
			this.state.set(listStateOf$1(answer));
		});
	}
	reload() {
		this.clearOutcome();
		this.cancelEdit();
		this.load();
	}
	familyLabel(family) {
		return family === "A" ? "A (StoneX)" : "B (in-house)";
	}
	errorsFor(field) {
		return this.fieldErrors()[field] ?? [];
	}
	startCreate() {
		this.open({
			original: null,
			specialType: "",
			displayName: "",
			family: "B",
			available: true
		});
	}
	startEdit(type) {
		this.open({
			original: type,
			...typeDraftOf(type)
		});
	}
	cancelEdit() {
		this.editor.set(null);
		this.fieldErrors.set({});
	}
	clearOutcome() {
		this.outcome.set(null);
		this.reloadOffered.set(false);
	}
	save() {
		const editor = this.editor();
		const source = this.source;
		if (editor === null || source === null) return;
		const draft = {
			specialType: editor.original?.specialType ?? editor.specialType.trim(),
			displayName: editor.displayName.trim(),
			family: editor.family,
			available: editor.available
		};
		const local = {
			...draft.specialType === "" ? { specialType: ["A type needs its CTRM special type code."] } : {},
			...draft.displayName === "" ? { displayName: ["A type needs a display name."] } : {}
		};
		this.fieldErrors.set(local);
		this.clearOutcome();
		if (Object.keys(local).length > 0) {
			this.outcome.set(mutationRefused(`Type not saved. ${Object.values(local).flat().join(" ")}`));
			return;
		}
		this.run(editor.original === null ? source.create(draft) : source.update(editor.original, draft), `Type ${draft.specialType} ${editor.original === null ? "created" : "saved"}.`, () => this.editor.set(null));
	}
	deactivate(type) {
		const source = this.source;
		if (source !== null) this.run(source.update(type, {
			...typeDraftOf(type),
			available: false
		}), `Type ${type.specialType} deactivated.`);
	}
	open(editor) {
		this.editor.set(editor);
		this.fieldErrors.set({});
		this.clearOutcome();
	}
	run(request, success, onDone) {
		this.busy.set(true);
		this.clearOutcome();
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.busy.set(false);
			switch (answer.kind) {
				case "done":
					onDone?.();
					this.outcome.set(mutationSucceeded(success));
					this.load();
					break;
				case "unavailable":
					this.outcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "conflict":
					this.outcome.set(mutationFailed(answer));
					this.reloadOffered.set(true);
					break;
				case "failed": {
					const placed = {};
					const unplaced = [];
					for (const [key, reasons] of Object.entries(answer.fieldErrors ?? {})) if (TYPE_FIELDS.includes(key)) placed[key] = reasons;
					else unplaced.push(...reasons);
					this.fieldErrors.set(placed);
					this.outcome.set(mutationFailed({
						message: Object.keys(placed).length === 0 || unplaced.length === 0 ? answer.message : unplaced.join(" "),
						correlationId: answer.correlationId
					}));
					break;
				}
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AddendumTypesSectionComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AddendumTypesSectionComponent,
		isStandalone: true,
		selector: "cws-addendum-types-section",
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<!--\r\n  #676, #798: the addendum types. A template is offered on a record only for a type that is\r\n  available, so this is where an administrator sees why a picker is empty, and fixes it.\r\n-->\r\n@if (offered) {\r\n  <section class=\"cws:space-y-2\" aria-labelledby=\"addendum-types-heading\">\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n      <h3 id=\"addendum-types-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        Addendum types\r\n      </h3>\r\n      @if (state().status === 'loaded' && editor() === null) {\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary\"\r\n          [disabled]=\"busy() || writesRefused() !== null\"\r\n          [attr.title]=\"writesRefused()\"\r\n          (click)=\"startCreate()\"\r\n        >\r\n          New type\r\n        </button>\r\n      }\r\n    </div>\r\n\r\n    @if (writesRefused(); as reason) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-testid=\"types-admin-only\">\r\n        {{ reason }}. You can view addendum types; changing them is for an administrator.\r\n      </p>\r\n    }\r\n\r\n    <!--\r\n      #803: the last write's outcome, with the server's reference on a failure. A 409 is in the\r\n      server's words, offers Reload, and is never retried.\r\n    -->\r\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\r\n      @if (reloadOffered()) {\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\r\n      }\r\n    </cms-status-message>\r\n\r\n    @switch (state().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading types…</p>\r\n      }\r\n      @case ('unavailable') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"types-unavailable\">\r\n          Addendum types are not available yet.\r\n        </p>\r\n      }\r\n      @case ('failed') {\r\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"types-failed\">\r\n          The addendum types could not be read.\r\n          @if (failure()?.correlationId; as id) {\r\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n          }\r\n        </p>\r\n      }\r\n      @case ('loaded') {\r\n        <table class=\"cws:w-full cws:text-left cws:text-xs\" aria-label=\"Addendum types\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Code</th>\r\n              <th class=\"cws:py-1\">Display name</th>\r\n              <th class=\"cws:py-1\">Family</th>\r\n              <th class=\"cws:py-1\">Available</th>\r\n              <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"types-rows\">\r\n            @for (type of types(); track type.specialType) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ type.specialType }}</td>\r\n                <td class=\"cws:py-1\">{{ type.displayName }}</td>\r\n                <td class=\"cws:py-1\">{{ familyLabel(type.family) }}</td>\r\n                <td class=\"cws:py-1\">{{ type.available ? 'Yes' : 'No' }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <!-- #825: Edit and Deactivate behind the row's menu. No Delete, by ruling (2026-10-12). -->\r\n                  <cms-row-menu\r\n                    [row]=\"type\"\r\n                    [actions]=\"typeActions().get(type.specialType) ?? []\"\r\n                    [label]=\"'Actions for type ' + type.specialType\"\r\n                  />\r\n                </td>\r\n              </tr>\r\n            } @empty {\r\n              <tr>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\" colspan=\"5\" data-testid=\"types-empty\">\r\n                  No addendum types yet. No template can be offered on a contract until its special type is\r\n                  added here and marked available.\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n    }\r\n\r\n    @if (editor(); as draft) {\r\n      <form\r\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n        aria-label=\"Addendum type\"\r\n        (ngSubmit)=\"save()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n          @if (draft.original === null) { New type } @else { Edit type {{ draft.original.specialType }} }\r\n        </h4>\r\n\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-start cws:gap-3\">\r\n          <!-- Reasons sit outside each label and are tied to it by aria-describedby, as on the template form. -->\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Code</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-28 cws:font-mono\"\r\n                name=\"specialType\"\r\n                placeholder=\"MNC\"\r\n                [(ngModel)]=\"draft.specialType\"\r\n                [readonly]=\"draft.original !== null\"\r\n                [attr.aria-invalid]=\"errorsFor('specialType').length > 0\"\r\n                aria-describedby=\"addendum-type-specialType-hint addendum-type-specialType-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-type-specialType-hint\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              @if (draft.original === null) {\r\n                CTRM's special type code, not its description.\r\n              } @else {\r\n                The code cannot change once a type exists.\r\n              }\r\n            </span>\r\n            <span id=\"addendum-type-specialType-errors\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('specialType'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Display name</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-56\"\r\n                name=\"displayName\"\r\n                [(ngModel)]=\"draft.displayName\"\r\n                [attr.aria-invalid]=\"errorsFor('displayName').length > 0\"\r\n                aria-describedby=\"addendum-type-displayName-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-type-displayName-errors\" class=\"cws:block cws:max-w-56 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('displayName'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Family</span>\r\n              <select\r\n                class=\"scoular-form-input cws:mt-1 cws:w-36\"\r\n                name=\"family\"\r\n                [(ngModel)]=\"draft.family\"\r\n                [attr.aria-invalid]=\"errorsFor('family').length > 0\"\r\n                aria-describedby=\"addendum-type-family-errors\"\r\n              >\r\n                @for (family of families; track family) {\r\n                  <option [value]=\"family\">{{ familyLabel(family) }}</option>\r\n                }\r\n              </select>\r\n            </label>\r\n            <span id=\"addendum-type-family-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('family'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-6 cws:text-xs\">\r\n            <input type=\"checkbox\" name=\"available\" [(ngModel)]=\"draft.available\" />\r\n            Available (approved by Legal)\r\n          </label>\r\n        </div>\r\n\r\n        <div class=\"cws:flex cws:gap-2\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\r\n            {{ busy() ? 'Saving…' : 'Save type' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\r\n        </div>\r\n      </form>\r\n    }\r\n  </section>\r\n}\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AddendumTypesSectionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-addendum-types-section",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				RowMenuComponent,
				StatusMessageComponent
			],
			host: { class: "cws:block" },
			template: "<!--\r\n  #676, #798: the addendum types. A template is offered on a record only for a type that is\r\n  available, so this is where an administrator sees why a picker is empty, and fixes it.\r\n-->\r\n@if (offered) {\r\n  <section class=\"cws:space-y-2\" aria-labelledby=\"addendum-types-heading\">\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n      <h3 id=\"addendum-types-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        Addendum types\r\n      </h3>\r\n      @if (state().status === 'loaded' && editor() === null) {\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary\"\r\n          [disabled]=\"busy() || writesRefused() !== null\"\r\n          [attr.title]=\"writesRefused()\"\r\n          (click)=\"startCreate()\"\r\n        >\r\n          New type\r\n        </button>\r\n      }\r\n    </div>\r\n\r\n    @if (writesRefused(); as reason) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-testid=\"types-admin-only\">\r\n        {{ reason }}. You can view addendum types; changing them is for an administrator.\r\n      </p>\r\n    }\r\n\r\n    <!--\r\n      #803: the last write's outcome, with the server's reference on a failure. A 409 is in the\r\n      server's words, offers Reload, and is never retried.\r\n    -->\r\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\r\n      @if (reloadOffered()) {\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\r\n      }\r\n    </cms-status-message>\r\n\r\n    @switch (state().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading types…</p>\r\n      }\r\n      @case ('unavailable') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"types-unavailable\">\r\n          Addendum types are not available yet.\r\n        </p>\r\n      }\r\n      @case ('failed') {\r\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"types-failed\">\r\n          The addendum types could not be read.\r\n          @if (failure()?.correlationId; as id) {\r\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n          }\r\n        </p>\r\n      }\r\n      @case ('loaded') {\r\n        <table class=\"cws:w-full cws:text-left cws:text-xs\" aria-label=\"Addendum types\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Code</th>\r\n              <th class=\"cws:py-1\">Display name</th>\r\n              <th class=\"cws:py-1\">Family</th>\r\n              <th class=\"cws:py-1\">Available</th>\r\n              <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"types-rows\">\r\n            @for (type of types(); track type.specialType) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ type.specialType }}</td>\r\n                <td class=\"cws:py-1\">{{ type.displayName }}</td>\r\n                <td class=\"cws:py-1\">{{ familyLabel(type.family) }}</td>\r\n                <td class=\"cws:py-1\">{{ type.available ? 'Yes' : 'No' }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <!-- #825: Edit and Deactivate behind the row's menu. No Delete, by ruling (2026-10-12). -->\r\n                  <cms-row-menu\r\n                    [row]=\"type\"\r\n                    [actions]=\"typeActions().get(type.specialType) ?? []\"\r\n                    [label]=\"'Actions for type ' + type.specialType\"\r\n                  />\r\n                </td>\r\n              </tr>\r\n            } @empty {\r\n              <tr>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\" colspan=\"5\" data-testid=\"types-empty\">\r\n                  No addendum types yet. No template can be offered on a contract until its special type is\r\n                  added here and marked available.\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n    }\r\n\r\n    @if (editor(); as draft) {\r\n      <form\r\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n        aria-label=\"Addendum type\"\r\n        (ngSubmit)=\"save()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n          @if (draft.original === null) { New type } @else { Edit type {{ draft.original.specialType }} }\r\n        </h4>\r\n\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-start cws:gap-3\">\r\n          <!-- Reasons sit outside each label and are tied to it by aria-describedby, as on the template form. -->\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Code</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-28 cws:font-mono\"\r\n                name=\"specialType\"\r\n                placeholder=\"MNC\"\r\n                [(ngModel)]=\"draft.specialType\"\r\n                [readonly]=\"draft.original !== null\"\r\n                [attr.aria-invalid]=\"errorsFor('specialType').length > 0\"\r\n                aria-describedby=\"addendum-type-specialType-hint addendum-type-specialType-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-type-specialType-hint\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              @if (draft.original === null) {\r\n                CTRM's special type code, not its description.\r\n              } @else {\r\n                The code cannot change once a type exists.\r\n              }\r\n            </span>\r\n            <span id=\"addendum-type-specialType-errors\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('specialType'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Display name</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-56\"\r\n                name=\"displayName\"\r\n                [(ngModel)]=\"draft.displayName\"\r\n                [attr.aria-invalid]=\"errorsFor('displayName').length > 0\"\r\n                aria-describedby=\"addendum-type-displayName-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-type-displayName-errors\" class=\"cws:block cws:max-w-56 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('displayName'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Family</span>\r\n              <select\r\n                class=\"scoular-form-input cws:mt-1 cws:w-36\"\r\n                name=\"family\"\r\n                [(ngModel)]=\"draft.family\"\r\n                [attr.aria-invalid]=\"errorsFor('family').length > 0\"\r\n                aria-describedby=\"addendum-type-family-errors\"\r\n              >\r\n                @for (family of families; track family) {\r\n                  <option [value]=\"family\">{{ familyLabel(family) }}</option>\r\n                }\r\n              </select>\r\n            </label>\r\n            <span id=\"addendum-type-family-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('family'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-6 cws:text-xs\">\r\n            <input type=\"checkbox\" name=\"available\" [(ngModel)]=\"draft.available\" />\r\n            Available (approved by Legal)\r\n          </label>\r\n        </div>\r\n\r\n        <div class=\"cws:flex cws:gap-2\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\r\n            {{ busy() ? 'Saving…' : 'Save type' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\r\n        </div>\r\n      </form>\r\n    }\r\n  </section>\r\n}\r\n"
		}]
	}],
	ctorParameters: () => []
});
function listStateOf$1(answer) {
	switch (answer.kind) {
		case "done": return { status: "loaded" };
		case "unavailable": return { status: "unavailable" };
		default: return {
			status: "failed",
			message: answer.message,
			...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
		};
	}
}
const EDITOR_FIELDS = [
	"name",
	"specialTypes",
	"language",
	"tradeUnits",
	"contentFormat",
	"templateContent",
	"fields"
];
const CONTENT_FORMATS = [DEFAULT_ADDENDUM_CONTENT_FORMAT];
function unknownCodes(codes, options) {
	if (options === null) return [];
	const known = new Set(options.map((option) => option.code));
	return codes.filter((code) => !known.has(code));
}
function unknownTypesMessage(codes) {
	return `Not addendum types: ${codes.join(", ")}. Create the type first.`;
}
function unknownTradeUnitsMessage(codes) {
	return `Not CTRM locations, so the template would never be offered there: ${codes.join(", ")}.`;
}
const NOT_ONBOARDED_EXPLANATION = "Not onboarded: the trade unit has no form configuration in CWS yet. Contract saves there are refused, and an addendum is generated by a save, so this template is not used there until the trade unit is onboarded under Form configuration.";
function typeNotAvailableMessage(code) {
	return `${code} is not available, so no addendum is generated for it and this template is not offered for it.`;
}
var AddendumTemplatesPageComponent = class AddendumTemplatesPageComponent {
	view = input("all", {
		...ngDevMode ? { debugName: "view" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "all"
	});
	showTemplates = computed(() => this.view() !== "types", ...ngDevMode ? [{ debugName: "showTemplates" }] : /* istanbul ignore next */ []);
	showTypes = computed(() => this.view() !== "templates", ...ngDevMode ? [{ debugName: "showTypes" }] : /* istanbul ignore next */ []);
	routed = computed(() => this.view() !== "all", ...ngDevMode ? [{ debugName: "routed" }] : /* istanbul ignore next */ []);
	area = adminArea("addendums");
	source = inject(ADDENDUM_TEMPLATE_SOURCE, { optional: true });
	typeSource = inject(ADDENDUM_TYPE_SOURCE, { optional: true });
	constraintSource = inject(CONSTRAINT_SOURCE, { optional: true });
	access = inject(AdminScope);
	types = signal(null, ...ngDevMode ? [{ debugName: "types" }] : /* istanbul ignore next */ []);
	typeOptions = computed(() => this.types()?.map((type) => ({
		code: type.specialType,
		label: `${type.specialType} · ${type.displayName}` + (type.available ? " · approved by Legal" : " · not yet approved by Legal, so no addendum is generated for it")
	})) ?? null, ...ngDevMode ? [{ debugName: "typeOptions" }] : /* istanbul ignore next */ []);
	tradeUnitOptions = computed(() => {
		const locations = this.access.locations();
		if (locations === null) return null;
		const scope = this.access.scope();
		const onboarded = new Set(scope.onboarded);
		return [...locations].sort((left, right) => left.code.localeCompare(right.code)).map((location) => ({
			code: location.code,
			label: `${location.code}${location.name === null ? "" : ` · ${location.name}`}` + (scope.known ? onboarded.has(location.code) ? " · onboarded" : " · not onboarded" : "")
		}));
	}, ...ngDevMode ? [{ debugName: "tradeUnitOptions" }] : /* istanbul ignore next */ []);
	tradeUnitNote = computed(() => {
		const locations = this.access.locations();
		const notes = [this.access.locationOrigin() === "Simulated" && locations !== null ? `This environment reads CTRM's simulator, so only its ${locations.length} locations can be picked: ${locations.map((location) => location.code).sort().join(", ")}.` : null, locations !== null && this.access.scope().known ? NOT_ONBOARDED_EXPLANATION : null].filter((note) => note !== null);
		return notes.length === 0 ? null : notes.join(" ");
	}, ...ngDevMode ? [{ debugName: "tradeUnitNote" }] : /* istanbul ignore next */ []);
	unknownTypesMessage = unknownTypesMessage;
	unknownTradeUnitsMessage = unknownTradeUnitsMessage;
	typeNotAvailableMessage = typeNotAvailableMessage;
	writesRefused = computed(() => this.access.knownNotAdmin() ? "Needs the Admin role" : null, ...ngDevMode ? [{ debugName: "writesRefused" }] : /* istanbul ignore next */ []);
	confirm = injectConfirm();
	destroyRef = inject(DestroyRef);
	anchors = [
		ADDENDUM_SIGNATURE_ANCHOR,
		ADDENDUM_DATE_ANCHOR,
		ADDENDUM_INITIALS_ANCHOR
	];
	contentFormats = CONTENT_FORMATS;
	offered = this.source !== null;
	state = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	unavailableReason = computed(() => {
		const state = this.state();
		return state.status === "unavailable" ? state.reason : null;
	}, ...ngDevMode ? [{ debugName: "unavailableReason" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const state = this.state();
		return state.status === "failed" ? state : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	templates = signal([], ...ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []);
	editor = signal(null, ...ngDevMode ? [{ debugName: "editor" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	content = signal("", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	mappings = signal({}, ...ngDevMode ? [{ debugName: "mappings" }] : /* istanbul ignore next */ []);
	constraints = signal(null, ...ngDevMode ? [{ debugName: "constraints" }] : /* istanbul ignore next */ []);
	constraintsRequested = false;
	ctrmListed = computed(() => this.constraints() !== null, ...ngDevMode ? [{ debugName: "ctrmListed" }] : /* istanbul ignore next */ []);
	fieldGroups = computed(() => {
		const document = this.constraints();
		return [
			...addendumFieldGroups(this.editor()?.specialTypes ?? []),
			...serverFieldGroups(),
			...document === null ? [] : [ctrmFieldGroup(document)]
		];
	}, ...ngDevMode ? [{ debugName: "fieldGroups" }] : /* istanbul ignore next */ []);
	placeholderRows = computed(() => placeholderRows(this.content(), this.mappings(), (name) => suggestedField(name, this.fieldGroups())), ...ngDevMode ? [{ debugName: "placeholderRows" }] : /* istanbul ignore next */ []);
	unmapped = computed(() => unmappedPlaceholders(this.placeholderRows()), ...ngDevMode ? [{ debugName: "unmapped" }] : /* istanbul ignore next */ []);
	previewOpen = signal(false, ...ngDevMode ? [{ debugName: "previewOpen" }] : /* istanbul ignore next */ []);
	preview = computed(() => this.previewOpen() ? previewSegments(this.content(), this.placeholderRows(), this.constraints()) : [], ...ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []);
	initialsOptional = signal(false, ...ngDevMode ? [{ debugName: "initialsOptional" }] : /* istanbul ignore next */ []);
	anchorChecks = computed(() => this.anchors.map((anchor) => ({
		anchor,
		present: this.content().includes(anchor),
		required: !(this.initialsOptional() && anchor === ADDENDUM_INITIALS_ANCHOR)
	})), ...ngDevMode ? [{ debugName: "anchorChecks" }] : /* istanbul ignore next */ []);
	unavailableTypes = computed(() => {
		const picked = this.editor()?.specialTypes ?? [];
		return (this.types() ?? []).filter((type) => !type.available && picked.includes(type.specialType));
	}, ...ngDevMode ? [{ debugName: "unavailableTypes" }] : /* istanbul ignore next */ []);
	typeWritesOffered = this.typeSource !== null;
	templateActions = computed(() => {
		const refusal = () => this.writesRefused() ?? (this.busy() ? "A template change is in progress" : false);
		return new Map(this.templates().map((template) => {
			const actions = [{
				label: "Edit",
				run: (row) => this.startEdit(row),
				disabled: refusal
			}];
			if (template.active) actions.push({
				label: "Deactivate",
				run: (row) => this.deactivate(row),
				disabled: refusal
			});
			actions.push({
				label: "Delete",
				run: (row) => this.remove(row),
				disabled: refusal
			});
			return [template.id, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "templateActions" }] : /* istanbul ignore next */ []);
	anchorProblems = signal([], ...ngDevMode ? [{ debugName: "anchorProblems" }] : /* istanbul ignore next */ []);
	fieldErrors = signal({}, ...ngDevMode ? [{ debugName: "fieldErrors" }] : /* istanbul ignore next */ []);
	contentProblems = computed(() => [...this.anchorProblems(), ...this.fieldErrors().templateContent ?? []], ...ngDevMode ? [{ debugName: "contentProblems" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	reloadOffered = signal(false, ...ngDevMode ? [{ debugName: "reloadOffered" }] : /* istanbul ignore next */ []);
	constructor() {
		this.load();
	}
	loadTypes() {
		this.typeSource?.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => this.types.set(answer.kind === "done" ? answer.value : null));
	}
	loadConstraints() {
		const source = this.constraintSource;
		if (source === null || this.constraintsRequested) return;
		this.constraintsRequested = true;
		source.document().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (snapshot) => this.constraints.set(snapshot.document),
			error: () => {
				this.constraintsRequested = false;
				this.constraints.set(null);
			}
		});
	}
	load() {
		const source = this.source;
		if (source === null) return;
		this.state.set({ status: "loading" });
		source.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") this.templates.set(answer.value);
			this.state.set(listStateOf(answer));
		});
	}
	reload() {
		this.clearOutcome();
		this.cancelEdit();
		this.load();
	}
	errorsFor(field) {
		return this.fieldErrors()[field] ?? [];
	}
	startCreate() {
		this.open({
			id: null,
			version: null,
			rowVersion: null,
			name: "",
			specialTypes: [],
			language: DEFAULT_ADDENDUM_LANGUAGE,
			contentFormat: DEFAULT_ADDENDUM_CONTENT_FORMAT,
			tradeUnits: [],
			active: true
		}, "", {}, false);
	}
	startEdit(template) {
		this.open({
			id: template.id,
			version: template.version,
			rowVersion: template.rowVersion,
			name: template.name,
			specialTypes: [...template.specialTypes],
			language: template.language,
			contentFormat: template.contentFormat,
			tradeUnits: [...template.tradeUnits],
			active: template.active
		}, template.templateContent, mappingsOf(template.fields), template.initialsAnchorOptional === true);
	}
	cancelEdit() {
		this.editor.set(null);
		this.previewOpen.set(false);
		this.anchorProblems.set([]);
		this.fieldErrors.set({});
	}
	setField(change) {
		this.mappings.update((mappings) => ({
			...mappings,
			[change.placeholder]: change.field
		}));
	}
	removeMapping(placeholder) {
		this.mappings.update((mappings) => Object.fromEntries(Object.entries(mappings).filter(([key]) => key !== placeholder)));
	}
	togglePreview() {
		this.previewOpen.update((open) => !open);
	}
	makeAvailable(type) {
		const source = this.typeSource;
		if (source === null) return;
		this.confirm({
			title: `Make ${type.specialType} available?`,
			message: `Only when Legal has approved ${type.displayName}. Once it is available, its active templates are offered on contracts of that special type, and saving such a contract generates an addendum.`,
			confirmLabel: "Make available",
			cancelLabel: "Not yet"
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (!confirmed) return;
			this.busy.set(true);
			this.clearOutcome();
			source.update(type, {
				...typeDraftOf(type),
				available: true
			}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
				this.busy.set(false);
				this.loadTypes();
				if (answer.kind === "done") this.outcome.set(mutationSucceeded(`Type ${type.specialType} is now available.`));
				else this.outcome.set(mutationFailed(answer.kind === "unavailable" ? { message: answer.reason } : answer));
			});
		});
	}
	clearOutcome() {
		this.outcome.set(null);
		this.reloadOffered.set(false);
	}
	save() {
		const editor = this.editor();
		const source = this.source;
		if (editor === null || source === null) return;
		const templateContent = this.content();
		const initialsAnchorOptional = this.initialsOptional();
		const problems = addendumAnchorProblems(templateContent, initialsAnchorOptional);
		const specialTypes = editor.specialTypes;
		const rows = this.placeholderRows();
		const unmapped = unmappedPlaceholders(rows);
		const unknownTypes = unknownCodes(specialTypes, this.typeOptions());
		const unknownUnits = unknownCodes(editor.tradeUnits, this.tradeUnitOptions());
		const local = {
			...editor.name.trim() === "" ? { name: ["A template needs a name."] } : {},
			...specialTypes.length === 0 ? { specialTypes: ["A template serves at least one special type."] } : unknownTypes.length > 0 ? { specialTypes: [unknownTypesMessage(unknownTypes)] } : {},
			...unknownUnits.length > 0 ? { tradeUnits: [unknownTradeUnitsMessage(unknownUnits)] } : {},
			...unmapped.length > 0 ? { fields: [unmappedPlaceholdersMessage(unmapped)] } : {}
		};
		this.anchorProblems.set(problems);
		this.fieldErrors.set(local);
		this.clearOutcome();
		if (problems.length > 0 || Object.keys(local).length > 0) {
			this.outcome.set(mutationRefused("Template not saved. The reasons are beside the fields."));
			return;
		}
		const draft = {
			name: editor.name.trim(),
			specialTypes,
			language: editor.language.trim() === "" ? DEFAULT_ADDENDUM_LANGUAGE : editor.language.trim(),
			tradeUnits: editor.tradeUnits,
			templateContent,
			contentFormat: editor.contentFormat,
			fields: fieldsOf(rows),
			active: editor.active,
			initialsAnchorOptional
		};
		this.run(editor.id === null || editor.rowVersion === null ? source.create(draft) : source.update(editor.id, editor.rowVersion, draft), `Template "${draft.name}" ${editor.id === null ? "created" : "saved"}.`, () => this.cancelEdit());
	}
	deactivate(template) {
		const source = this.source;
		if (source !== null) this.run(source.deactivate(template), `Template "${template.name}" deactivated.`);
	}
	remove(template) {
		const source = this.source;
		if (source === null) return;
		this.confirm({
			title: "Delete this addendum template?",
			message: `"${template.name}" will be deleted and can no longer be used to generate an addendum. Deactivate it instead to keep it and its history.`,
			confirmLabel: "Delete template",
			cancelLabel: "Keep template",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) this.run(source.remove(template), `Template "${template.name}" deleted.`);
		});
	}
	tradeUnitsLabel(template) {
		return template.tradeUnits.length === 0 ? "All" : template.tradeUnits.join(", ");
	}
	setCodes(field, codes) {
		const editor = this.editor();
		if (editor !== null) this.editor.set({
			...editor,
			[field]: [...codes]
		});
	}
	open(editor, content, mappings, initialsAnchorOptional) {
		this.loadTypes();
		this.loadConstraints();
		this.editor.set(editor);
		this.content.set(content);
		this.mappings.set(mappings);
		this.initialsOptional.set(initialsAnchorOptional);
		this.previewOpen.set(false);
		this.anchorProblems.set([]);
		this.fieldErrors.set({});
		this.clearOutcome();
	}
	run(request, success, onDone) {
		this.busy.set(true);
		this.clearOutcome();
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.busy.set(false);
			switch (answer.kind) {
				case "done":
					onDone?.();
					this.outcome.set(mutationSucceeded(success));
					this.load();
					break;
				case "unavailable":
					this.outcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "conflict":
					this.outcome.set(mutationFailed(answer));
					this.reloadOffered.set(true);
					break;
				case "failed": {
					const placed = {};
					const unplaced = [];
					for (const [key, reasons] of Object.entries(answer.fieldErrors ?? {})) if (EDITOR_FIELDS.includes(key)) placed[key] = reasons;
					else unplaced.push(...reasons);
					this.fieldErrors.set(placed);
					this.outcome.set(mutationFailed({
						message: Object.keys(placed).length === 0 || unplaced.length === 0 ? answer.message : unplaced.join(" "),
						correlationId: answer.correlationId
					}));
					break;
				}
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AddendumTemplatesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AddendumTemplatesPageComponent,
		isStandalone: true,
		selector: "cws-addendum-templates-page",
		inputs: { view: {
			classPropertyName: "view",
			publicName: "view",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <!--\r\n    #825: the Addendums page of the Admin section, with Templates and Types as its tabs. Mounted on its\r\n    own (view \"all\") it shows both, types first, as the old single page did.\r\n  -->\r\n  <cms-page-header\r\n    title=\"Addendums\"\r\n    description=\"The documents generated for the in-house addendums (minimum price with a call, min/max and premium advance), and the addendum types a contract can carry.\"\r\n  >\r\n    @if (showTemplates() && offered && state().status === 'loaded' && editor() === null) {\r\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\" (click)=\"startCreate()\">\r\n        New template\r\n      </button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  @if (routed()) {\r\n    <cws-admin-tabs [views]=\"area.views\" label=\"Addendum views\" />\r\n  }\r\n\r\n  @if (writesRefused(); as reason) {\r\n    <!-- #696: the template writes are Admin-only on the server, so a settings holder reads them here. -->\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-templates-admin-only>\r\n      {{ reason }}. You can view templates; changing them is for an administrator.\r\n    </p>\r\n  }\r\n\r\n  @if (showTypes()) {\r\n    <!-- #676, #798: the addendum types, above the templates that serve them. Absent without a type source. -->\r\n    <cws-addendum-types-section />\r\n  }\r\n\r\n  @if (showTemplates()) {\r\n  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Templates</h3>\r\n\r\n  <!-- Kept visible: a template that breaks it is refused on save. -->\r\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n    Used exactly as Legal approved them. Every template must carry the signature, date and initials\r\n    anchors the signing service looks for; the initials anchor only when the text has an initials line.\r\n  </p>\r\n\r\n  <!--\r\n    #803: the last template write's outcome, with the server's reference on a failure. A 409 is the\r\n    row changed since it was read: in the server's words, with Reload, and never retried.\r\n  -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\r\n    @if (reloadOffered()) {\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\r\n    }\r\n  </cms-status-message>\r\n\r\n  @if (!offered) {\r\n    <!-- A host that embeds the admin screen without the template seam. Said, not left blank. -->\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-not-offered\">\r\n      Addendum templates are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (state().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading templates…</p>\r\n      }\r\n      @case ('unavailable') {\r\n        <!--\r\n          🔴 The routes are wired before the backend publishes them. A 404 lands here and says so; an\r\n          empty table would read as \"no templates exist\", which a missing route cannot claim.\r\n        -->\r\n        <div class=\"scoular-alert scoular-alert-info\" data-testid=\"templates-unavailable\">\r\n          <div class=\"scoular-alert-title\">Not available yet</div>\r\n          <div class=\"scoular-alert-description\">{{ unavailableReason() }}</div>\r\n        </div>\r\n      }\r\n      @case ('failed') {\r\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n          {{ failure()?.message }}\r\n          @if (failure()?.correlationId; as id) {\r\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n          }\r\n        </p>\r\n      }\r\n      @case ('loaded') {\r\n        @if (templates().length === 0) {\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-empty\">\r\n            No addendum templates yet.\r\n          </p>\r\n        } @else {\r\n          <table class=\"cws:w-full cws:text-left cws:text-xs\">\r\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n              <tr>\r\n                <th class=\"cws:py-1\">Name</th>\r\n                <th class=\"cws:py-1\">Special types</th>\r\n                <th class=\"cws:py-1\">Language</th>\r\n                <th class=\"cws:py-1\">Trade units</th>\r\n                <th class=\"cws:py-1\">Version</th>\r\n                <th class=\"cws:py-1\">Active</th>\r\n                <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\r\n              </tr>\r\n            </thead>\r\n            <tbody data-testid=\"templates-rows\">\r\n              @for (template of templates(); track template.id) {\r\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                  <td class=\"cws:py-1\">{{ template.name }}</td>\r\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.specialTypes.join(', ') }}</td>\r\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.language }}</td>\r\n                  <td class=\"cws:py-1\">{{ tradeUnitsLabel(template) }}</td>\r\n                  <td class=\"cws:py-1 cws:tabular-nums\">{{ template.version }}</td>\r\n                  <td class=\"cws:py-1\">{{ template.active ? 'Yes' : 'No' }}</td>\r\n                  <td class=\"cws:py-1 cws:text-right\">\r\n                    <!-- #825: Edit, Deactivate and Delete behind the row's menu. Delete still asks first. -->\r\n                    <cms-row-menu\r\n                      [row]=\"template\"\r\n                      [actions]=\"templateActions().get(template.id) ?? []\"\r\n                      [label]=\"'Actions for ' + template.name\"\r\n                    />\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        }\r\n      }\r\n    }\r\n\r\n    @if (editor(); as draft) {\r\n      <form\r\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n        aria-label=\"Addendum template\"\r\n        (ngSubmit)=\"save()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n          @if (draft.id === null) { New template } @else { Edit template, version {{ draft.version }} }\r\n        </h4>\r\n\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-start cws:gap-3\">\r\n          <!--\r\n            Each field's reasons sit OUTSIDE its label and are tied to it by aria-describedby: inside\r\n            the label they would become part of the field's accessible name.\r\n          -->\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Name</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-56\"\r\n                name=\"name\"\r\n                [(ngModel)]=\"draft.name\"\r\n                [attr.aria-invalid]=\"errorsFor('name').length > 0\"\r\n                aria-describedby=\"addendum-template-name-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-template-name-errors\" class=\"cws:block cws:max-w-56 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('name'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <!--\r\n            #814: picked from the addendum types, never typed. An unapproved type is still pickable, and\r\n            says so, because a template may be written before Legal approves the type.\r\n          -->\r\n          <div class=\"cws:w-72 cws:space-y-1\">\r\n            <cws-admin-code-picker\r\n              label=\"Special types\"\r\n              name=\"specialTypes\"\r\n              [codes]=\"draft.specialTypes\"\r\n              [options]=\"typeOptions()\"\r\n              [unknownMessage]=\"unknownTypesMessage\"\r\n              searchPlaceholder=\"Type a special type\"\r\n              freePlaceholder=\"MNC, MNP\"\r\n              describedBy=\"addendum-template-specialTypes-errors\"\r\n              [invalid]=\"errorsFor('specialTypes').length > 0\"\r\n              (codesChange)=\"setCodes('specialTypes', $event)\"\r\n            />\r\n            <span id=\"addendum-template-specialTypes-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('specialTypes'); track reason) { {{ reason }} }\r\n            </span>\r\n            <!--\r\n              #924: a picked type that is not available, said here with its fix, so the template can be\r\n              made usable without visiting the Types tab. Make available asks first: it is Legal's approval.\r\n            -->\r\n            @if (unavailableTypes().length > 0) {\r\n              <ul class=\"cws:space-y-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" data-testid=\"types-not-available\">\r\n                @for (type of unavailableTypes(); track type.specialType) {\r\n                  <li>\r\n                    {{ typeNotAvailableMessage(type.specialType) }}\r\n                    @if (typeWritesOffered) {\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn scoular-btn-secondary cws:mt-1\"\r\n                        [disabled]=\"busy() || writesRefused() !== null\"\r\n                        [attr.title]=\"writesRefused()\"\r\n                        (click)=\"makeAvailable(type)\"\r\n                      >\r\n                        Make {{ type.specialType }} available\r\n                      </button>\r\n                    }\r\n                  </li>\r\n                }\r\n              </ul>\r\n            }\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Language</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-24 cws:font-mono\"\r\n                name=\"language\"\r\n                [(ngModel)]=\"draft.language\"\r\n                [attr.aria-invalid]=\"errorsFor('language').length > 0\"\r\n                aria-describedby=\"addendum-template-language-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-template-language-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('language'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Content format</span>\r\n              <select\r\n                class=\"scoular-form-input cws:mt-1 cws:w-32\"\r\n                name=\"contentFormat\"\r\n                [(ngModel)]=\"draft.contentFormat\"\r\n                [attr.aria-invalid]=\"errorsFor('contentFormat').length > 0\"\r\n                aria-describedby=\"addendum-template-contentFormat-errors\"\r\n              >\r\n                @for (format of contentFormats; track format) {\r\n                  <option [value]=\"format\">{{ format }}</option>\r\n                }\r\n              </select>\r\n            </label>\r\n            <span id=\"addendum-template-contentFormat-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('contentFormat'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <!-- #814: picked from CTRM's locations, with typeahead: live CTRM has over a thousand. -->\r\n          <div class=\"cws:w-80 cws:space-y-1\">\r\n            <cws-admin-code-picker\r\n              label=\"Trade units\"\r\n              name=\"tradeUnits\"\r\n              [codes]=\"draft.tradeUnits\"\r\n              [options]=\"tradeUnitOptions()\"\r\n              [unknownMessage]=\"unknownTradeUnitsMessage\"\r\n              emptyMeaning=\"None picked: the template serves every trade unit.\"\r\n              [note]=\"tradeUnitNote()\"\r\n              searchPlaceholder=\"Type a location code or name\"\r\n              freePlaceholder=\"Blank for all, or 0210, 2087\"\r\n              describedBy=\"addendum-template-tradeUnits-errors\"\r\n              [invalid]=\"errorsFor('tradeUnits').length > 0\"\r\n              (codesChange)=\"setCodes('tradeUnits', $event)\"\r\n            />\r\n            <span id=\"addendum-template-tradeUnits-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('tradeUnits'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-6 cws:text-xs\">\r\n            <input type=\"checkbox\" name=\"active\" [(ngModel)]=\"draft.active\" />\r\n            Active\r\n          </label>\r\n        </div>\r\n\r\n        <label class=\"cws:block cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template content</span>\r\n          <textarea\r\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\r\n            rows=\"12\"\r\n            name=\"templateContent\"\r\n            [ngModel]=\"content()\"\r\n            (ngModelChange)=\"content.set($event)\"\r\n            [attr.aria-invalid]=\"contentProblems().length > 0\"\r\n            aria-describedby=\"addendum-template-anchors\"\r\n          ></textarea>\r\n        </label>\r\n\r\n        <!--\r\n          🔴 Beside the content field, because that is where the fix goes. Each reason names the\r\n          anchor to add, so an administrator pasting in Legal's text knows what is missing rather than\r\n          being told only that something is. A server refusal of the content lands here too.\r\n        -->\r\n        <div id=\"addendum-template-anchors\" class=\"cws:space-y-1 cws:text-xs\">\r\n          @if (contentProblems().length > 0) {\r\n            <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"anchor-problems\">\r\n              @for (problem of contentProblems(); track problem) {\r\n                <li>{{ problem }}</li>\r\n              }\r\n            </ul>\r\n          }\r\n          <!--\r\n            #924: each required anchor, ticked off as it is typed, so a missing one is seen while pasting\r\n            Legal's text rather than on Save. Save still refuses a missing one (above).\r\n          -->\r\n          <ul class=\"cws:flex cws:flex-wrap cws:gap-x-4 cws:gap-y-1\" aria-label=\"Required anchors\" data-testid=\"anchor-checklist\">\r\n            @for (check of anchorChecks(); track check.anchor) {\r\n              <li\r\n                [class.cws:text-emerald-700]=\"check.present\"\r\n                [class.cws:dark:text-emerald-300]=\"check.present\"\r\n                [class.cws:text-slate-500]=\"!check.present\"\r\n                [class.cws:dark:text-slate-400]=\"!check.present\"\r\n                [attr.data-present]=\"check.present\"\r\n                [attr.data-required]=\"check.required\"\r\n              >\r\n                <span aria-hidden=\"true\">{{ check.present ? '✓' : check.required ? '○' : '–' }}</span>\r\n                <code class=\"cws:font-mono\">{{ check.anchor }}</code>\r\n                @if (check.required) {\r\n                  <span class=\"cws:sr-only\">{{ check.present ? 'present' : 'missing' }}</span>\r\n                } @else {\r\n                  <span class=\"cws:ml-1\" data-testid=\"anchor-not-required\">(not required: this text has no initials line)</span>\r\n                }\r\n              </li>\r\n            }\r\n          </ul>\r\n          <!--\r\n            #1038: the template's initialsAnchorOptional. Only the initials anchor is waived, as on the\r\n            server; the signature and date anchors stay required.\r\n          -->\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-1\">\r\n            <input\r\n              type=\"checkbox\"\r\n              name=\"initialsAnchorOptional\"\r\n              [ngModel]=\"initialsOptional()\"\r\n              (ngModelChange)=\"initialsOptional.set($event)\"\r\n            />\r\n            This text has no initials line\r\n          </label>\r\n        </div>\r\n\r\n        <!-- #924: the placeholders, read from the content, each with a field picker. Replaces the free-text box. -->\r\n        <cws-addendum-placeholder-fields\r\n          [rows]=\"placeholderRows()\"\r\n          [groups]=\"fieldGroups()\"\r\n          [ctrmListed]=\"ctrmListed()\"\r\n          [invalid]=\"errorsFor('fields').length > 0 || unmapped().length > 0\"\r\n          describedBy=\"addendum-template-fields-errors\"\r\n          (fieldChange)=\"setField($event)\"\r\n          (removed)=\"removeMapping($event)\"\r\n        />\r\n        <ul id=\"addendum-template-fields-errors\" class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n          @for (reason of errorsFor('fields'); track reason) {\r\n            <li>{{ reason }}</li>\r\n          }\r\n        </ul>\r\n\r\n        @if (previewOpen()) {\r\n          <!--\r\n            #924: the draft's text with sample values, before anything is saved. The server previews a\r\n            SAVED template only, from a contract, as the PDF; this is the text that PDF would carry.\r\n          -->\r\n          <section class=\"cws:space-y-1\" aria-label=\"Template preview\" data-testid=\"template-preview\">\r\n            <h5 class=\"cws:text-xs cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview, with sample values</h5>\r\n            <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Sample values only: a text field shows its own name in brackets. The document is the PDF the\r\n              server lays out from this text; to see it, save the template and preview from a contract.\r\n            </p>\r\n            <pre class=\"cws:max-h-96 cws:overflow-auto cws:whitespace-pre-wrap cws:rounded cws:border cws:border-slate-200 cws:bg-slate-50 cws:p-3 cws:font-mono cws:text-xs cws:dark:border-slate-700 cws:dark:bg-slate-900\">@for (segment of preview(); track $index) {@switch (segment.kind) {@case ('value') {<mark class=\"cws:bg-sky-100 cws:dark:bg-sky-900\" data-testid=\"preview-value\">{{ segment.text }}</mark>}@case ('missing') {<mark class=\"cws:bg-rose-100 cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" data-testid=\"preview-missing\">{{ segment.text }}</mark>}@default {<span>{{ segment.text }}</span>}}}</pre>\r\n          </section>\r\n        }\r\n\r\n        <div class=\"cws:flex cws:gap-2\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\r\n            {{ busy() ? 'Saving…' : 'Save template' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [attr.aria-pressed]=\"previewOpen()\" (click)=\"togglePreview()\">\r\n            {{ previewOpen() ? 'Hide preview' : 'Preview' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\r\n        </div>\r\n      </form>\r\n    }\r\n  }\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AddendumPlaceholderFieldsComponent,
				selector: "cws-addendum-placeholder-fields",
				inputs: [
					"rows",
					"groups",
					"ctrmListed",
					"describedBy",
					"invalid",
					"disabled"
				],
				outputs: ["fieldChange", "removed"]
			},
			{
				kind: "component",
				type: AddendumTypesSectionComponent,
				selector: "cws-addendum-types-section"
			},
			{
				kind: "component",
				type: AdminCodePickerComponent,
				selector: "cws-admin-code-picker",
				inputs: [
					"label",
					"name",
					"codes",
					"options",
					"unknownMessage",
					"emptyMeaning",
					"note",
					"searchPlaceholder",
					"freePlaceholder",
					"describedBy",
					"invalid",
					"disabled"
				],
				outputs: ["codesChange"]
			},
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AddendumTemplatesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-addendum-templates-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AddendumPlaceholderFieldsComponent,
				AddendumTypesSectionComponent,
				AdminCodePickerComponent,
				AdminTabsComponent,
				FormsModule,
				PageHeaderComponent,
				RowMenuComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-4\">\r\n  <!--\r\n    #825: the Addendums page of the Admin section, with Templates and Types as its tabs. Mounted on its\r\n    own (view \"all\") it shows both, types first, as the old single page did.\r\n  -->\r\n  <cms-page-header\r\n    title=\"Addendums\"\r\n    description=\"The documents generated for the in-house addendums (minimum price with a call, min/max and premium advance), and the addendum types a contract can carry.\"\r\n  >\r\n    @if (showTemplates() && offered && state().status === 'loaded' && editor() === null) {\r\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\" (click)=\"startCreate()\">\r\n        New template\r\n      </button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  @if (routed()) {\r\n    <cws-admin-tabs [views]=\"area.views\" label=\"Addendum views\" />\r\n  }\r\n\r\n  @if (writesRefused(); as reason) {\r\n    <!-- #696: the template writes are Admin-only on the server, so a settings holder reads them here. -->\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-templates-admin-only>\r\n      {{ reason }}. You can view templates; changing them is for an administrator.\r\n    </p>\r\n  }\r\n\r\n  @if (showTypes()) {\r\n    <!-- #676, #798: the addendum types, above the templates that serve them. Absent without a type source. -->\r\n    <cws-addendum-types-section />\r\n  }\r\n\r\n  @if (showTemplates()) {\r\n  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Templates</h3>\r\n\r\n  <!-- Kept visible: a template that breaks it is refused on save. -->\r\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n    Used exactly as Legal approved them. Every template must carry the signature, date and initials\r\n    anchors the signing service looks for; the initials anchor only when the text has an initials line.\r\n  </p>\r\n\r\n  <!--\r\n    #803: the last template write's outcome, with the server's reference on a failure. A 409 is the\r\n    row changed since it was read: in the server's words, with Reload, and never retried.\r\n  -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\r\n    @if (reloadOffered()) {\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\r\n    }\r\n  </cms-status-message>\r\n\r\n  @if (!offered) {\r\n    <!-- A host that embeds the admin screen without the template seam. Said, not left blank. -->\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-not-offered\">\r\n      Addendum templates are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (state().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading templates…</p>\r\n      }\r\n      @case ('unavailable') {\r\n        <!--\r\n          🔴 The routes are wired before the backend publishes them. A 404 lands here and says so; an\r\n          empty table would read as \"no templates exist\", which a missing route cannot claim.\r\n        -->\r\n        <div class=\"scoular-alert scoular-alert-info\" data-testid=\"templates-unavailable\">\r\n          <div class=\"scoular-alert-title\">Not available yet</div>\r\n          <div class=\"scoular-alert-description\">{{ unavailableReason() }}</div>\r\n        </div>\r\n      }\r\n      @case ('failed') {\r\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n          {{ failure()?.message }}\r\n          @if (failure()?.correlationId; as id) {\r\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n          }\r\n        </p>\r\n      }\r\n      @case ('loaded') {\r\n        @if (templates().length === 0) {\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-empty\">\r\n            No addendum templates yet.\r\n          </p>\r\n        } @else {\r\n          <table class=\"cws:w-full cws:text-left cws:text-xs\">\r\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n              <tr>\r\n                <th class=\"cws:py-1\">Name</th>\r\n                <th class=\"cws:py-1\">Special types</th>\r\n                <th class=\"cws:py-1\">Language</th>\r\n                <th class=\"cws:py-1\">Trade units</th>\r\n                <th class=\"cws:py-1\">Version</th>\r\n                <th class=\"cws:py-1\">Active</th>\r\n                <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\r\n              </tr>\r\n            </thead>\r\n            <tbody data-testid=\"templates-rows\">\r\n              @for (template of templates(); track template.id) {\r\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                  <td class=\"cws:py-1\">{{ template.name }}</td>\r\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.specialTypes.join(', ') }}</td>\r\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.language }}</td>\r\n                  <td class=\"cws:py-1\">{{ tradeUnitsLabel(template) }}</td>\r\n                  <td class=\"cws:py-1 cws:tabular-nums\">{{ template.version }}</td>\r\n                  <td class=\"cws:py-1\">{{ template.active ? 'Yes' : 'No' }}</td>\r\n                  <td class=\"cws:py-1 cws:text-right\">\r\n                    <!-- #825: Edit, Deactivate and Delete behind the row's menu. Delete still asks first. -->\r\n                    <cms-row-menu\r\n                      [row]=\"template\"\r\n                      [actions]=\"templateActions().get(template.id) ?? []\"\r\n                      [label]=\"'Actions for ' + template.name\"\r\n                    />\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        }\r\n      }\r\n    }\r\n\r\n    @if (editor(); as draft) {\r\n      <form\r\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n        aria-label=\"Addendum template\"\r\n        (ngSubmit)=\"save()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n          @if (draft.id === null) { New template } @else { Edit template, version {{ draft.version }} }\r\n        </h4>\r\n\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-start cws:gap-3\">\r\n          <!--\r\n            Each field's reasons sit OUTSIDE its label and are tied to it by aria-describedby: inside\r\n            the label they would become part of the field's accessible name.\r\n          -->\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Name</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-56\"\r\n                name=\"name\"\r\n                [(ngModel)]=\"draft.name\"\r\n                [attr.aria-invalid]=\"errorsFor('name').length > 0\"\r\n                aria-describedby=\"addendum-template-name-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-template-name-errors\" class=\"cws:block cws:max-w-56 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('name'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <!--\r\n            #814: picked from the addendum types, never typed. An unapproved type is still pickable, and\r\n            says so, because a template may be written before Legal approves the type.\r\n          -->\r\n          <div class=\"cws:w-72 cws:space-y-1\">\r\n            <cws-admin-code-picker\r\n              label=\"Special types\"\r\n              name=\"specialTypes\"\r\n              [codes]=\"draft.specialTypes\"\r\n              [options]=\"typeOptions()\"\r\n              [unknownMessage]=\"unknownTypesMessage\"\r\n              searchPlaceholder=\"Type a special type\"\r\n              freePlaceholder=\"MNC, MNP\"\r\n              describedBy=\"addendum-template-specialTypes-errors\"\r\n              [invalid]=\"errorsFor('specialTypes').length > 0\"\r\n              (codesChange)=\"setCodes('specialTypes', $event)\"\r\n            />\r\n            <span id=\"addendum-template-specialTypes-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('specialTypes'); track reason) { {{ reason }} }\r\n            </span>\r\n            <!--\r\n              #924: a picked type that is not available, said here with its fix, so the template can be\r\n              made usable without visiting the Types tab. Make available asks first: it is Legal's approval.\r\n            -->\r\n            @if (unavailableTypes().length > 0) {\r\n              <ul class=\"cws:space-y-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" data-testid=\"types-not-available\">\r\n                @for (type of unavailableTypes(); track type.specialType) {\r\n                  <li>\r\n                    {{ typeNotAvailableMessage(type.specialType) }}\r\n                    @if (typeWritesOffered) {\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn scoular-btn-secondary cws:mt-1\"\r\n                        [disabled]=\"busy() || writesRefused() !== null\"\r\n                        [attr.title]=\"writesRefused()\"\r\n                        (click)=\"makeAvailable(type)\"\r\n                      >\r\n                        Make {{ type.specialType }} available\r\n                      </button>\r\n                    }\r\n                  </li>\r\n                }\r\n              </ul>\r\n            }\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Language</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-24 cws:font-mono\"\r\n                name=\"language\"\r\n                [(ngModel)]=\"draft.language\"\r\n                [attr.aria-invalid]=\"errorsFor('language').length > 0\"\r\n                aria-describedby=\"addendum-template-language-errors\"\r\n              />\r\n            </label>\r\n            <span id=\"addendum-template-language-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('language'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <div class=\"cws:space-y-1\">\r\n            <label class=\"cws:block cws:space-y-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Content format</span>\r\n              <select\r\n                class=\"scoular-form-input cws:mt-1 cws:w-32\"\r\n                name=\"contentFormat\"\r\n                [(ngModel)]=\"draft.contentFormat\"\r\n                [attr.aria-invalid]=\"errorsFor('contentFormat').length > 0\"\r\n                aria-describedby=\"addendum-template-contentFormat-errors\"\r\n              >\r\n                @for (format of contentFormats; track format) {\r\n                  <option [value]=\"format\">{{ format }}</option>\r\n                }\r\n              </select>\r\n            </label>\r\n            <span id=\"addendum-template-contentFormat-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('contentFormat'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <!-- #814: picked from CTRM's locations, with typeahead: live CTRM has over a thousand. -->\r\n          <div class=\"cws:w-80 cws:space-y-1\">\r\n            <cws-admin-code-picker\r\n              label=\"Trade units\"\r\n              name=\"tradeUnits\"\r\n              [codes]=\"draft.tradeUnits\"\r\n              [options]=\"tradeUnitOptions()\"\r\n              [unknownMessage]=\"unknownTradeUnitsMessage\"\r\n              emptyMeaning=\"None picked: the template serves every trade unit.\"\r\n              [note]=\"tradeUnitNote()\"\r\n              searchPlaceholder=\"Type a location code or name\"\r\n              freePlaceholder=\"Blank for all, or 0210, 2087\"\r\n              describedBy=\"addendum-template-tradeUnits-errors\"\r\n              [invalid]=\"errorsFor('tradeUnits').length > 0\"\r\n              (codesChange)=\"setCodes('tradeUnits', $event)\"\r\n            />\r\n            <span id=\"addendum-template-tradeUnits-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n              @for (reason of errorsFor('tradeUnits'); track reason) { {{ reason }} }\r\n            </span>\r\n          </div>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-6 cws:text-xs\">\r\n            <input type=\"checkbox\" name=\"active\" [(ngModel)]=\"draft.active\" />\r\n            Active\r\n          </label>\r\n        </div>\r\n\r\n        <label class=\"cws:block cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template content</span>\r\n          <textarea\r\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\r\n            rows=\"12\"\r\n            name=\"templateContent\"\r\n            [ngModel]=\"content()\"\r\n            (ngModelChange)=\"content.set($event)\"\r\n            [attr.aria-invalid]=\"contentProblems().length > 0\"\r\n            aria-describedby=\"addendum-template-anchors\"\r\n          ></textarea>\r\n        </label>\r\n\r\n        <!--\r\n          🔴 Beside the content field, because that is where the fix goes. Each reason names the\r\n          anchor to add, so an administrator pasting in Legal's text knows what is missing rather than\r\n          being told only that something is. A server refusal of the content lands here too.\r\n        -->\r\n        <div id=\"addendum-template-anchors\" class=\"cws:space-y-1 cws:text-xs\">\r\n          @if (contentProblems().length > 0) {\r\n            <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"anchor-problems\">\r\n              @for (problem of contentProblems(); track problem) {\r\n                <li>{{ problem }}</li>\r\n              }\r\n            </ul>\r\n          }\r\n          <!--\r\n            #924: each required anchor, ticked off as it is typed, so a missing one is seen while pasting\r\n            Legal's text rather than on Save. Save still refuses a missing one (above).\r\n          -->\r\n          <ul class=\"cws:flex cws:flex-wrap cws:gap-x-4 cws:gap-y-1\" aria-label=\"Required anchors\" data-testid=\"anchor-checklist\">\r\n            @for (check of anchorChecks(); track check.anchor) {\r\n              <li\r\n                [class.cws:text-emerald-700]=\"check.present\"\r\n                [class.cws:dark:text-emerald-300]=\"check.present\"\r\n                [class.cws:text-slate-500]=\"!check.present\"\r\n                [class.cws:dark:text-slate-400]=\"!check.present\"\r\n                [attr.data-present]=\"check.present\"\r\n                [attr.data-required]=\"check.required\"\r\n              >\r\n                <span aria-hidden=\"true\">{{ check.present ? '✓' : check.required ? '○' : '–' }}</span>\r\n                <code class=\"cws:font-mono\">{{ check.anchor }}</code>\r\n                @if (check.required) {\r\n                  <span class=\"cws:sr-only\">{{ check.present ? 'present' : 'missing' }}</span>\r\n                } @else {\r\n                  <span class=\"cws:ml-1\" data-testid=\"anchor-not-required\">(not required: this text has no initials line)</span>\r\n                }\r\n              </li>\r\n            }\r\n          </ul>\r\n          <!--\r\n            #1038: the template's initialsAnchorOptional. Only the initials anchor is waived, as on the\r\n            server; the signature and date anchors stay required.\r\n          -->\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-1\">\r\n            <input\r\n              type=\"checkbox\"\r\n              name=\"initialsAnchorOptional\"\r\n              [ngModel]=\"initialsOptional()\"\r\n              (ngModelChange)=\"initialsOptional.set($event)\"\r\n            />\r\n            This text has no initials line\r\n          </label>\r\n        </div>\r\n\r\n        <!-- #924: the placeholders, read from the content, each with a field picker. Replaces the free-text box. -->\r\n        <cws-addendum-placeholder-fields\r\n          [rows]=\"placeholderRows()\"\r\n          [groups]=\"fieldGroups()\"\r\n          [ctrmListed]=\"ctrmListed()\"\r\n          [invalid]=\"errorsFor('fields').length > 0 || unmapped().length > 0\"\r\n          describedBy=\"addendum-template-fields-errors\"\r\n          (fieldChange)=\"setField($event)\"\r\n          (removed)=\"removeMapping($event)\"\r\n        />\r\n        <ul id=\"addendum-template-fields-errors\" class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n          @for (reason of errorsFor('fields'); track reason) {\r\n            <li>{{ reason }}</li>\r\n          }\r\n        </ul>\r\n\r\n        @if (previewOpen()) {\r\n          <!--\r\n            #924: the draft's text with sample values, before anything is saved. The server previews a\r\n            SAVED template only, from a contract, as the PDF; this is the text that PDF would carry.\r\n          -->\r\n          <section class=\"cws:space-y-1\" aria-label=\"Template preview\" data-testid=\"template-preview\">\r\n            <h5 class=\"cws:text-xs cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview, with sample values</h5>\r\n            <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Sample values only: a text field shows its own name in brackets. The document is the PDF the\r\n              server lays out from this text; to see it, save the template and preview from a contract.\r\n            </p>\r\n            <pre class=\"cws:max-h-96 cws:overflow-auto cws:whitespace-pre-wrap cws:rounded cws:border cws:border-slate-200 cws:bg-slate-50 cws:p-3 cws:font-mono cws:text-xs cws:dark:border-slate-700 cws:dark:bg-slate-900\">@for (segment of preview(); track $index) {@switch (segment.kind) {@case ('value') {<mark class=\"cws:bg-sky-100 cws:dark:bg-sky-900\" data-testid=\"preview-value\">{{ segment.text }}</mark>}@case ('missing') {<mark class=\"cws:bg-rose-100 cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" data-testid=\"preview-missing\">{{ segment.text }}</mark>}@default {<span>{{ segment.text }}</span>}}}</pre>\r\n          </section>\r\n        }\r\n\r\n        <div class=\"cws:flex cws:gap-2\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\r\n            {{ busy() ? 'Saving…' : 'Save template' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [attr.aria-pressed]=\"previewOpen()\" (click)=\"togglePreview()\">\r\n            {{ previewOpen() ? 'Hide preview' : 'Preview' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\r\n        </div>\r\n      </form>\r\n    }\r\n  }\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { view: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "view",
			required: false
		}]
	}] }
});
function listStateOf(answer) {
	switch (answer.kind) {
		case "done": return { status: "loaded" };
		case "unavailable": return {
			status: "unavailable",
			reason: answer.reason
		};
		default: return {
			status: "failed",
			message: answer.message,
			...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
		};
	}
}
var AdminOverviewComponent = class AdminOverviewComponent {
	access = inject(AdminScope);
	areas = computed(() => ADMIN_AREAS.filter((area) => !area.adminOnly || !this.access.knownNotAdmin()), ...ngDevMode ? [{ debugName: "areas" }] : /* istanbul ignore next */ []);
	viewList(views) {
		return views.map((view) => view.label).join(" · ");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AdminOverviewComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AdminOverviewComponent,
		isStandalone: true,
		selector: "cws-admin-overview",
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <section class="cws:space-y-6">
      <cms-page-header
        title="Admin"
        description="Configuration for Contract Workspace: how contracts are entered, what each trade unit offers, addendums, and who may do what."
      />

      <ul class="cws:grid cws:gap-4 cws:md:grid-cols-2" aria-label="Admin areas">
        @for (area of areas(); track area.path) {
          <li class="scoular-card cws:flex cws:flex-col cws:gap-2 cws:p-4">
            <h3 class="cws:text-base cws:font-semibold">
              <a
                class="cws:text-scoular-blue cws:hover:underline cws:dark:text-sky-400"
                [routerLink]="[area.path]"
                >{{ area.title }}</a
              >
            </h3>
            <p class="cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">{{ area.summary }}</p>
            @if (area.views.length > 0) {
              <p class="cws:mt-auto cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                {{ viewList(area.views) }}
              </p>
            }
          </li>
        }
      </ul>

      <p class="cws:text-sm cws:text-slate-500 cws:dark:text-slate-400">
        Still to come: contract templates, and the agreed permission set that roles are built from.
      </p>
    </section>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: PageHeaderComponent,
			selector: "cms-page-header",
			inputs: ["title", "description"]
		}, {
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AdminOverviewComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-overview",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [PageHeaderComponent, RouterLink],
			host: { class: "cws:block" },
			template: `
    <section class="cws:space-y-6">
      <cms-page-header
        title="Admin"
        description="Configuration for Contract Workspace: how contracts are entered, what each trade unit offers, addendums, and who may do what."
      />

      <ul class="cws:grid cws:gap-4 cws:md:grid-cols-2" aria-label="Admin areas">
        @for (area of areas(); track area.path) {
          <li class="scoular-card cws:flex cws:flex-col cws:gap-2 cws:p-4">
            <h3 class="cws:text-base cws:font-semibold">
              <a
                class="cws:text-scoular-blue cws:hover:underline cws:dark:text-sky-400"
                [routerLink]="[area.path]"
                >{{ area.title }}</a
              >
            </h3>
            <p class="cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">{{ area.summary }}</p>
            @if (area.views.length > 0) {
              <p class="cws:mt-auto cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                {{ viewList(area.views) }}
              </p>
            }
          </li>
        }
      </ul>

      <p class="cws:text-sm cws:text-slate-500 cws:dark:text-slate-400">
        Still to come: contract templates, and the agreed permission set that roles are built from.
      </p>
    </section>
  `
		}]
	}]
});
let nextId = 0;
var AdminTradeUnitSelectComponent = class AdminTradeUnitSelectComponent {
	access = inject(AdminScope);
	id = `cws-admin-tu-${nextId++}`;
	label = input("Trade unit", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = input("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	allowAny = input(false, ...ngDevMode ? [{ debugName: "allowAny" }] : /* istanbul ignore next */ []);
	valueChange = output();
	filter = signal("", ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	mode = computed(() => {
		if (this.access.knownNotAdmin()) return "held";
		return this.access.locations() === null ? "free" : "all";
	}, ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	offerAny = computed(() => this.allowAny() && this.mode() === "all", ...ngDevMode ? [{ debugName: "offerAny" }] : /* istanbul ignore next */ []);
	options = computed(() => {
		const scope = this.access.scope();
		if (this.mode() === "held") return scope.tradeUnits.map((code) => {
			const name = this.access.nameOf(code);
			return {
				code,
				label: name === null ? code : `${code} · ${name}`
			};
		});
		const onboarded = new Set(scope.onboarded);
		return [...this.access.locations() ?? []].sort((left, right) => left.code.localeCompare(right.code)).map((location) => ({
			code: location.code,
			label: `${location.code}${location.name === null ? "" : ` · ${location.name}`}` + (scope.known ? onboarded.has(location.code) ? " · onboarded" : " · not onboarded" : "")
		}));
	}, ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	filtered = computed(() => {
		const term = this.filter().trim().toLowerCase();
		return term === "" ? this.options() : this.options().filter((option) => option.code === this.value() || option.label.toLowerCase().includes(term));
	}, ...ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: AdminTradeUnitSelectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: AdminTradeUnitSelectComponent,
		isStandalone: true,
		selector: "cws-admin-trade-unit-select",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowAny: {
				classPropertyName: "allowAny",
				publicName: "allowAny",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { valueChange: "valueChange" },
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <label class="cws:block cws:space-y-1" [attr.for]="id">
      <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">{{ label() }}</span>
    </label>

    @switch (mode()) {
      @case ('free') {
        <input
          [id]="id"
          class="scoular-form-input cws:mt-1 cws:w-full"
          [attr.placeholder]="allowAny() ? 'Any' : 'e.g. 2087'"
          [value]="value()"
          (input)="valueChange.emit($any($event.target).value)"
        />
      }
      @default {
        @if (mode() === 'all' && options().length > 12) {
          <!-- Narrows the list; it never becomes the value, so a typo cannot be submitted. -->
          <input
            class="scoular-form-input cws:mt-1 cws:w-full cws:text-xs"
            type="search"
            [attr.aria-label]="'Filter ' + label()"
            placeholder="Filter by code or name"
            [value]="filter()"
            (input)="filter.set($any($event.target).value)"
          />
        }
        <select
          [id]="id"
          class="scoular-form-input cws:mt-1 cws:w-full"
          [value]="value()"
          (change)="valueChange.emit($any($event.target).value)"
        >
          <option value="" [selected]="value() === ''" [disabled]="!offerAny()">
            {{ offerAny() ? 'Any trade unit (Admin only)' : 'Choose a trade unit' }}
          </option>
          @for (option of filtered(); track option.code) {
            <option [value]="option.code" [selected]="option.code === value()">{{ option.label }}</option>
          }
        </select>
        @if (mode() === 'held') {
          <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-held-note>
            The trade units where you manage settings.
          </p>
        }
      }
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: AdminTradeUnitSelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-trade-unit-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: `
    <label class="cws:block cws:space-y-1" [attr.for]="id">
      <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">{{ label() }}</span>
    </label>

    @switch (mode()) {
      @case ('free') {
        <input
          [id]="id"
          class="scoular-form-input cws:mt-1 cws:w-full"
          [attr.placeholder]="allowAny() ? 'Any' : 'e.g. 2087'"
          [value]="value()"
          (input)="valueChange.emit($any($event.target).value)"
        />
      }
      @default {
        @if (mode() === 'all' && options().length > 12) {
          <!-- Narrows the list; it never becomes the value, so a typo cannot be submitted. -->
          <input
            class="scoular-form-input cws:mt-1 cws:w-full cws:text-xs"
            type="search"
            [attr.aria-label]="'Filter ' + label()"
            placeholder="Filter by code or name"
            [value]="filter()"
            (input)="filter.set($any($event.target).value)"
          />
        }
        <select
          [id]="id"
          class="scoular-form-input cws:mt-1 cws:w-full"
          [value]="value()"
          (change)="valueChange.emit($any($event.target).value)"
        >
          <option value="" [selected]="value() === ''" [disabled]="!offerAny()">
            {{ offerAny() ? 'Any trade unit (Admin only)' : 'Choose a trade unit' }}
          </option>
          @for (option of filtered(); track option.code) {
            <option [value]="option.code" [selected]="option.code === value()">{{ option.label }}</option>
          }
        </select>
        @if (mode() === 'held') {
          <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-held-note>
            The trade units where you manage settings.
          </p>
        }
      }
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		allowAny: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowAny",
				required: false
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
function previewPresentation(componentName, registryLabel, presentation) {
	const layoutNote = CONTRACT_LAYOUT_FIELD_NOTES[componentName] ?? null;
	return {
		half: presentation?.halfWidth ?? CONTRACT_LAYOUT_HALF_FIELDS[componentName] === true,
		labelHidden: presentation?.labelHidden ?? CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS[componentName] === true,
		label: presentation?.label ?? registryLabel,
		description: presentation?.tooltipEnabled === false ? null : presentation?.tooltipDescription ?? layoutNote
	};
}
function withSetPresentationOnly(fields) {
	const out = {};
	for (const [name, behaviour] of Object.entries(fields)) {
		const { presentation, ...flags } = behaviour;
		const kept = Object.fromEntries(Object.entries(presentation ?? {}).filter(([, value]) => value !== void 0 && value !== null && !(typeof value === "string" && value.trim() === "")));
		out[name] = Object.keys(kept).length === 0 ? flags : {
			...flags,
			presentation: kept
		};
	}
	return out;
}
const COLLECTION_COPIES = {
	excludeFromCopy: false,
	excludeFromTemplateCopy: false
};
function collectionLabel(name) {
	const words = name.replace(/_/g, " ").trim();
	return words === "" ? name : words.charAt(0).toUpperCase() + words.slice(1);
}
function changedCollections(offered, current, baseline) {
	if (offered === void 0) return null;
	const changed = {};
	for (const [name, collection] of Object.entries(offered)) {
		const now = {
			...COLLECTION_COPIES,
			...current[name]
		};
		const was = {
			...COLLECTION_COPIES,
			...baseline[name]
		};
		if (collection.copyable && (now.excludeFromCopy !== was.excludeFromCopy || now.excludeFromTemplateCopy !== was.excludeFromTemplateCopy)) changed[name] = {
			excludeFromCopy: now.excludeFromCopy,
			excludeFromTemplateCopy: now.excludeFromTemplateCopy
		};
	}
	return Object.keys(changed).length === 0 ? null : changed;
}
const REMARK_TYPE_DEFAULT = {
	visible: true,
	required: false
};
function changedRemarkTypes(offered, current, baseline) {
	if (offered === void 0) return null;
	const changed = {};
	for (const { code } of offered) {
		const now = {
			...REMARK_TYPE_DEFAULT,
			...current[code]
		};
		const was = {
			...REMARK_TYPE_DEFAULT,
			...baseline[code]
		};
		if (now.visible !== was.visible || now.required !== was.required) changed[code] = {
			visible: now.visible,
			required: now.required
		};
	}
	return Object.keys(changed).length === 0 ? null : changed;
}
function isIsoDate(value) {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
	if (match === null) return false;
	const [year, month, day] = [
		Number(match[1]),
		Number(match[2]),
		Number(match[3])
	];
	const date = new Date(Date.UTC(year, month - 1, day));
	return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}
function localIsoToday() {
	const now = /* @__PURE__ */ new Date();
	return [
		now.getFullYear(),
		String(now.getMonth() + 1).padStart(2, "0"),
		String(now.getDate()).padStart(2, "0")
	].join("-");
}
var FormConfigEditorComponent = class FormConfigEditorComponent {
	source = inject(FORM_CONFIG_ADMIN_SOURCE);
	editing = input(null, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	saved = output();
	cancelled = output();
	contractTypeClass = "";
	locationCode = "";
	commodityCode = "";
	effectiveFrom = "";
	effectiveError = signal(null, ...ngDevMode ? [{ debugName: "effectiveError" }] : /* istanbul ignore next */ []);
	autoCalculationMode = "None";
	pendingContractsEnabled = false;
	everyTradeUnitPending = signal(false, ...ngDevMode ? [{ debugName: "everyTradeUnitPending" }] : /* istanbul ignore next */ []);
	setLocation(code) {
		this.locationCode = code;
		this.everyTradeUnitPending.set(false);
	}
	asksBeforeEveryTradeUnit() {
		if (this.locationCode.trim() !== "") return false;
		const editing = this.editing();
		return editing === null || editing.locationCode !== null;
	}
	homeGridColumns = signal(null, ...ngDevMode ? [{ debugName: "homeGridColumns" }] : /* istanbul ignore next */ []);
	columnsNotKept = signal(false, ...ngDevMode ? [{ debugName: "columnsNotKept" }] : /* istanbul ignore next */ []);
	lockedColumnKeys = [PINNED_GRID_COLUMN];
	allColumnKeys = CONTRACT_GRID_COLUMNS.map((column) => column.key);
	homeGridColumnFields = computed(() => {
		const headers = new Map(CONTRACT_GRID_COLUMNS.map((column) => [column.key, column.header]));
		return gridColumnChoices(this.allColumnKeys, null, this.homeGridColumns()).map((choice) => ({
			key: choice.key,
			header: headers.get(choice.key) ?? choice.key,
			included: choice.shown
		}));
	}, ...ngDevMode ? [{ debugName: "homeGridColumnFields" }] : /* istanbul ignore next */ []);
	onHomeGridColumnsChange(fields) {
		this.homeGridColumns.set(userGridColumnKeys(fields.map((f) => ({
			key: f.key,
			shown: f.included
		}))));
	}
	resetHomeGridColumns() {
		this.homeGridColumns.set(null);
	}
	collectionFlags = signal({}, ...ngDevMode ? [{ debugName: "collectionFlags" }] : /* istanbul ignore next */ []);
	collectionBaseline = signal({}, ...ngDevMode ? [{ debugName: "collectionBaseline" }] : /* istanbul ignore next */ []);
	collectionRows = computed(() => {
		const offered = this.registry()?.collections;
		if (offered === void 0) return null;
		const flags = this.collectionFlags();
		return Object.entries(offered).map(([name, collection]) => ({
			name,
			label: collectionLabel(name),
			copyable: collection.copyable,
			excludeFromCopy: flags[name]?.excludeFromCopy ?? false
		}));
	}, ...ngDevMode ? [{ debugName: "collectionRows" }] : /* istanbul ignore next */ []);
	setCollectionExcluded(name, excludeFromCopy) {
		if (this.registry()?.collections?.[name]?.copyable !== true) return;
		this.collectionFlags.update((all) => ({
			...all,
			[name]: {
				...COLLECTION_COPIES,
				...all[name],
				excludeFromCopy
			}
		}));
	}
	startCollectionsFrom(collections) {
		this.collectionFlags.set(collections ?? {});
		this.collectionBaseline.set(collections ?? {});
	}
	remarkFlags = signal({}, ...ngDevMode ? [{ debugName: "remarkFlags" }] : /* istanbul ignore next */ []);
	remarkBaseline = signal({}, ...ngDevMode ? [{ debugName: "remarkBaseline" }] : /* istanbul ignore next */ []);
	remarkRows = computed(() => {
		const offered = this.registry()?.remarkTypes;
		if (offered === void 0) return null;
		const flags = this.remarkFlags();
		return offered.map((type) => ({
			code: type.code,
			label: type.label,
			...REMARK_TYPE_DEFAULT,
			...flags[type.code]
		}));
	}, ...ngDevMode ? [{ debugName: "remarkRows" }] : /* istanbul ignore next */ []);
	setRemarkFlag(code, flag, value) {
		this.remarkFlags.update((all) => {
			const now = {
				...REMARK_TYPE_DEFAULT,
				...all[code]
			};
			if (flag === "visible" && !value && now.required) return all;
			const next = flag === "required" ? {
				...now,
				required: value,
				visible: value || now.visible
			} : {
				...now,
				visible: value
			};
			return {
				...all,
				[code]: next
			};
		});
	}
	startRemarksFrom(remarkTypes) {
		this.remarkFlags.set(remarkTypes ?? {});
		this.remarkBaseline.set(remarkTypes ?? {});
	}
	seedTradeUnit = "";
	seededFrom = signal(null, ...ngDevMode ? [{ debugName: "seededFrom" }] : /* istanbul ignore next */ []);
	seedNotice = signal(null, ...ngDevMode ? [{ debugName: "seedNotice" }] : /* istanbul ignore next */ []);
	baseSections = signal(null, ...ngDevMode ? [{ debugName: "baseSections" }] : /* istanbul ignore next */ []);
	startingPoint = 0;
	saving = signal(false, ...ngDevMode ? [{ debugName: "saving" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	filter = signal("", ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	registry = signal(null, ...ngDevMode ? [{ debugName: "registry" }] : /* istanbul ignore next */ []);
	behaviours = signal({}, ...ngDevMode ? [{ debugName: "behaviours" }] : /* istanbul ignore next */ []);
	tabs = signal([], ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	ready = computed(() => this.registry() !== null, ...ngDevMode ? [{ debugName: "ready" }] : /* istanbul ignore next */ []);
	isNew = computed(() => this.editing() === null, ...ngDevMode ? [{ debugName: "isNew" }] : /* istanbul ignore next */ []);
	ngOnInit() {
		this.source.registry().subscribe((state) => {
			if (state.status === "loaded") {
				this.registry.set(state.value);
				this.seed();
			} else if (state.status === "error") this.outcome.set(mutationFailed(state.error));
		});
	}
	editableTabs = computed(() => withSectionTabs(this.tabs(), this.editableSections(), this.registry()?.tabs ?? []), ...ngDevMode ? [{ debugName: "editableTabs" }] : /* istanbul ignore next */ []);
	sectionVisibility = signal({}, ...ngDevMode ? [{ debugName: "sectionVisibility" }] : /* istanbul ignore next */ []);
	toggleSection(sectionId, visible) {
		this.sectionVisibility.set({
			...this.sectionVisibility(),
			[sectionId]: visible
		});
	}
	sectionVisible(sectionId) {
		return this.sectionVisibility()[sectionId] ?? this.registry()?.sections.find((section) => section.id === sectionId)?.visible ?? true;
	}
	editableSections = computed(() => {
		const registry = this.registry();
		const visibility = this.sectionVisibility();
		const registrySections = registry?.sections ?? [];
		const base = this.baseSections();
		return (base === null ? registrySections : [...base, ...registrySections.filter((section) => !base.some((known) => known.id === section.id))]).map((section) => ({
			...section,
			visible: visibility[section.id] ?? section.visible
		}));
	}, ...ngDevMode ? [{ debugName: "editableSections" }] : /* istanbul ignore next */ []);
	emptyTabWarning = computed(() => {
		const emptied = emptiedTabs(this.editableTabs(), this.editableSections());
		return emptied.length === 0 ? null : emptied.map((tab) => tab.label).join(", ");
	}, ...ngDevMode ? [{ debugName: "emptyTabWarning" }] : /* istanbul ignore next */ []);
	sections = computed(() => {
		const registry = this.registry();
		if (registry === null) return [];
		const behaviours = this.behaviours();
		const needle = this.filter().trim().toLowerCase();
		return [...this.editableSections()].sort((left, right) => left.order - right.order).map((section) => ({
			id: section.id,
			label: section.label,
			tab: section.tab,
			fields: Object.entries(registry.fields).filter(([, field]) => field.section === section.id).filter(([componentName, field]) => needle === "" || componentName.toLowerCase().includes(needle) || field.label.toLowerCase().includes(needle) || field.ctrmField.toLowerCase().includes(needle)).map(([componentName, field]) => this.toEditorField(componentName, field, behaviours[componentName])).sort((left, right) => left.behaviour.order - right.behaviour.order)
		})).filter((section) => section.fields.length > 0);
	}, ...ngDevMode ? [{ debugName: "sections" }] : /* istanbul ignore next */ []);
	reorderBlockedReason = computed(() => this.filter().trim() === "" ? null : "Clear the search to reorder — moving a field while the list is filtered would place it against rows you cannot see.", ...ngDevMode ? [{ debugName: "reorderBlockedReason" }] : /* istanbul ignore next */ []);
	moveField(sectionId, componentName, delta) {
		const ordered = this.orderedIn(sectionId);
		if (ordered === null) return;
		const from = ordered.indexOf(componentName);
		const to = from + delta;
		if (from === -1 || to < 0 || to >= ordered.length) return;
		ordered.splice(to, 0, ...ordered.splice(from, 1));
		this.applyOrder(ordered, componentName);
	}
	placeField(sectionId, componentName, onto) {
		const ordered = this.orderedIn(sectionId);
		if (ordered === null) return;
		const from = ordered.indexOf(componentName);
		const to = ordered.indexOf(onto);
		if (from === -1 || to === -1 || from === to) return;
		ordered.splice(to, 0, ...ordered.splice(from, 1));
		this.applyOrder(ordered, componentName);
	}
	orderedIn(sectionId) {
		const registry = this.registry();
		if (this.reorderBlockedReason() !== null || registry === null) return null;
		const behaviours = this.behaviours();
		return Object.entries(registry.fields).filter(([, field]) => field.section === sectionId).map(([name, field]) => ({
			name,
			order: behaviours[name]?.order ?? field.order
		})).sort((left, right) => left.order - right.order).map((entry) => entry.name);
	}
	applyOrder(ordered, moved) {
		const behaviours = { ...this.behaviours() };
		ordered.forEach((name, index) => {
			const existing = behaviours[name];
			if (existing !== void 0) behaviours[name] = {
				...existing,
				order: index + 1
			};
		});
		this.behaviours.set(behaviours);
		this.movedField.set(moved);
	}
	draggingField = signal(null, ...ngDevMode ? [{ debugName: "draggingField" }] : /* istanbul ignore next */ []);
	dropField = signal(null, ...ngDevMode ? [{ debugName: "dropField" }] : /* istanbul ignore next */ []);
	dragSection = null;
	gesture = new PointerDragGesture({
		handleSelector: "[data-drag-field]",
		source: (handle) => rowRef(handle, "data-drag-field", "data-drag-section"),
		target: (x, y) => {
			const row = elementUnder(x, y, "[data-drop-field]");
			return row === null ? null : rowRef(row, "data-drop-field", "data-drop-section");
		},
		started: (source) => {
			this.dragSection = source.section;
			this.draggingField.set(source.field);
		},
		over: (target) => this.dropField.set(target !== null && target.section === this.dragSection && target.field !== this.draggingField() ? target.field : null),
		ended: () => {
			this.dragSection = null;
			this.draggingField.set(null);
			this.dropField.set(null);
		},
		dropped: (source, target) => {
			if (source.section === target.section) this.placeField(source.section, source.field, target.field);
		}
	});
	constructor() {
		inject(DestroyRef).onDestroy(() => this.gesture.cancel());
	}
	onRowPointerDown(event) {
		this.gesture.press(event);
	}
	movedField = signal(null, ...ngDevMode ? [{ debugName: "movedField" }] : /* istanbul ignore next */ []);
	requiredCount = computed(() => Object.values(this.behaviours()).filter((behaviour) => behaviour.required).length, ...ngDevMode ? [{ debugName: "requiredCount" }] : /* istanbul ignore next */ []);
	hiddenCount = computed(() => Object.values(this.behaviours()).filter((behaviour) => !behaviour.visible).length, ...ngDevMode ? [{ debugName: "hiddenCount" }] : /* istanbul ignore next */ []);
	setRequired(componentName, required) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				required,
				visible: required ? true : all[componentName].visible
			}
		}));
	}
	setVisible(componentName, visible) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				visible
			}
		}));
	}
	setFlag(componentName, flag, value) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				[flag]: value
			}
		}));
	}
	openPresentation = signal(null, ...ngDevMode ? [{ debugName: "openPresentation" }] : /* istanbul ignore next */ []);
	togglePresentation(componentName) {
		this.openPresentation.update((open) => open === componentName ? null : componentName);
	}
	previewOf(field) {
		return previewPresentation(field.componentName, field.label, field.behaviour.presentation);
	}
	layoutDefault(componentName) {
		return {
			half: CONTRACT_LAYOUT_HALF_FIELDS[componentName] === true,
			labelHidden: CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS[componentName] === true,
			note: CONTRACT_LAYOUT_FIELD_NOTES[componentName] ?? null
		};
	}
	setPresentation(componentName, key, value) {
		this.behaviours.update((all) => {
			const current = { ...all[componentName].presentation ?? {} };
			if (value === void 0 || typeof value === "string" && value.trim() === "") delete current[key];
			else current[key] = value;
			const { presentation: _old, ...flags } = all[componentName];
			return {
				...all,
				[componentName]: Object.keys(current).length === 0 ? flags : {
					...flags,
					presentation: current
				}
			};
		});
	}
	setPresentationFlag(componentName, key, choice) {
		this.setPresentation(componentName, key, choice === "" ? void 0 : choice === "true");
	}
	flagChoice(value) {
		return value === void 0 ? "" : String(value);
	}
	resetPresentation(componentName) {
		this.behaviours.update((all) => {
			const { presentation: _old, ...flags } = all[componentName];
			return {
				...all,
				[componentName]: flags
			};
		});
	}
	setTabVisible(id, visible) {
		this.tabs.set(this.editableTabs().map((tab) => tab.id === id ? {
			...tab,
			visible
		} : tab));
	}
	setTabLabel(id, label) {
		this.tabs.set(this.editableTabs().map((tab) => tab.id === id ? {
			...tab,
			label
		} : tab));
	}
	copyFromCurrent() {
		const ticket = ++this.startingPoint;
		this.seededFrom.set(null);
		this.baseSections.set(null);
		this.seedNotice.set(null);
		this.source.preview({
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			...this.locationCode !== "" ? { locationCode: this.locationCode } : {},
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {}
		}).subscribe((state) => {
			if (state.status !== "loaded" || ticket !== this.startingPoint) return;
			const next = { ...this.behaviours() };
			for (const section of state.value.config.sections) for (const field of section.fields) {
				const current = next[field.componentName];
				if (current !== void 0) next[field.componentName] = {
					...current,
					visible: field.behaviour.visible,
					required: field.behaviour.required,
					readOnly: field.behaviour.readOnly
				};
			}
			this.behaviours.set(next);
			this.tabs.set(state.value.config.tabs);
			this.baseSections.set(sectionsOf(state.value.config.sections, this.registry()?.sections ?? []));
			this.sectionVisibility.set(visibilityOf(this.baseSections() ?? []));
			this.autoCalculationMode = state.value.tradeUnitAttributes.autoCalculationMode;
			this.pendingContractsEnabled = state.value.tradeUnitAttributes.pendingContractsEnabled;
			this.homeGridColumns.set(state.value.tradeUnitAttributes.homeGridColumns ?? null);
			if (this.editing() === null) {
				this.startCollectionsFrom(state.value.config.collections);
				this.startRemarksFrom(state.value.config.remarkTypes);
			} else {
				this.collectionFlags.set(state.value.config.collections ?? {});
				this.remarkFlags.set(state.value.config.remarkTypes ?? {});
			}
		});
	}
	save(everyTradeUnitConfirmed = false) {
		const registry = this.registry();
		const effectiveFrom = this.effectiveFrom;
		if (effectiveFrom === null || !isIsoDate(effectiveFrom)) {
			this.effectiveError.set("An effective date is required — it is what decides when this row starts applying.");
			this.outcome.set(mutationRefused("The configuration was not saved. The reason is beside the effective date."));
			return;
		}
		if (registry === null) return;
		if (!everyTradeUnitConfirmed && this.asksBeforeEveryTradeUnit()) {
			this.everyTradeUnitPending.set(true);
			return;
		}
		this.everyTradeUnitPending.set(false);
		this.saving.set(true);
		this.outcome.set(null);
		const collections = changedCollections(registry.collections, this.collectionFlags(), this.collectionBaseline());
		const remarkTypes = changedRemarkTypes(registry.remarkTypes, this.remarkFlags(), this.remarkBaseline());
		const document = {
			schemaVersion: registry.schemaVersion,
			tabs: this.editableTabs(),
			sections: this.editableSections(),
			fields: withSetPresentationOnly(this.behaviours()),
			attributes: {
				autoCalculationMode: this.autoCalculationMode,
				pendingContractsEnabled: this.pendingContractsEnabled,
				...this.homeGridColumns() !== null ? { homeGridColumns: this.homeGridColumns() } : {}
			},
			...collections !== null ? { collections } : {},
			...remarkTypes !== null ? { remarkTypes } : {}
		};
		const submission = {
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			...this.locationCode !== "" ? { locationCode: this.locationCode } : {},
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {},
			effectiveFrom,
			config: document
		};
		const editing = this.editing();
		const seed = this.seededFrom();
		if (editing !== null) {
			this.submit(this.source.update(editing.id, editing.rowVersion, submission));
			return;
		}
		if (seed === null) {
			this.submit(this.source.create(submission));
			return;
		}
		this.source.get(seed.id).subscribe((state) => {
			if (state.status === "error") {
				this.saving.set(false);
				this.outcome.set(mutationFailed({
					message: `The configuration you seeded from (trade unit ${seed.tradeUnit}) could not be re-read, so this row was not created. Try again, or seed again.`,
					correlationId: state.error.correlationId
				}));
				return;
			}
			if (state.status !== "loaded") return;
			if (state.value.rowVersion !== seed.rowVersion || !state.value.isActive) {
				this.saving.set(false);
				this.outcome.set(mutationRefused(`The configuration for trade unit ${seed.tradeUnit} changed after you seeded from it, so this row was not created — it would have copied a version that no longer exists. Seed again to start from its current settings.`));
				return;
			}
			this.submit(this.source.create(submission));
		});
	}
	submit(request) {
		request.subscribe((state) => {
			if (state.status === "loaded") {
				this.saving.set(false);
				if (this.homeGridColumns() !== null && state.value.config?.attributes?.homeGridColumns === void 0) {
					this.columnsNotKept.set(true);
					return;
				}
				this.saved.emit();
			} else if (state.status === "error") {
				this.saving.set(false);
				this.outcome.set(mutationFailed({
					message: `The configuration was not saved.\n${state.error.message}`,
					correlationId: state.error.correlationId
				}));
			}
		});
	}
	seedFromTradeUnit() {
		const tradeUnit = this.seedTradeUnit.trim();
		this.seedNotice.set(null);
		if (tradeUnit === "") {
			this.seedNotice.set("Enter the trade unit to seed from.");
			return;
		}
		if (tradeUnit === this.locationCode.trim()) {
			this.seedNotice.set(`This row already applies to trade unit ${tradeUnit}. Pick a different trade unit to copy from.`);
			return;
		}
		const ticket = ++this.startingPoint;
		this.source.preview({
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			locationCode: tradeUnit,
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {}
		}).subscribe((resolved) => {
			if (ticket !== this.startingPoint) return;
			if (resolved.status === "error") {
				this.seedNotice.set(`Trade unit ${tradeUnit} could not be resolved: ${resolved.error.message}`);
				return;
			}
			if (resolved.status !== "loaded") return;
			const id = resolved.value.provenance.configId;
			if (id === null) {
				this.seedNotice.set(`Trade unit ${tradeUnit} has no configuration of its own — it resolves to the built-in default, which is where a new row already starts. Nothing was copied.`);
				return;
			}
			this.source.get(id).subscribe((row) => {
				if (ticket !== this.startingPoint) return;
				if (row.status === "error") this.seedNotice.set(`Trade unit ${tradeUnit}'s configuration could not be read: ${row.error.message}`);
				else if (row.status === "loaded") this.adoptSeed(tradeUnit, row.value);
			});
		});
	}
	adoptSeed(tradeUnit, detail) {
		const registry = this.registry();
		if (registry === null) return;
		this.tabs.set(detail.config.tabs);
		this.baseSections.set(detail.config.sections);
		this.sectionVisibility.set(visibilityOf(detail.config.sections));
		this.behaviours.set(this.completeFrom(registry, detail.config.fields));
		this.autoCalculationMode = detail.config.attributes.autoCalculationMode;
		this.pendingContractsEnabled = detail.config.attributes.pendingContractsEnabled;
		this.homeGridColumns.set(detail.config.attributes.homeGridColumns ?? null);
		this.collectionFlags.set(detail.config.collections ?? {});
		this.remarkFlags.set(detail.config.remarkTypes ?? {});
		this.seededFrom.set({
			id: detail.id,
			rowVersion: detail.rowVersion,
			tradeUnit,
			dimensionKey: detail.dimensionKey,
			version: detail.version
		});
	}
	cancel() {
		this.cancelled.emit();
	}
	seed() {
		const registry = this.registry();
		if (registry === null) return;
		const editing = this.editing();
		if (editing !== null) {
			this.contractTypeClass = editing.contractTypeClass ?? "";
			this.locationCode = editing.locationCode ?? "";
			this.commodityCode = editing.commodityCode ?? "";
			this.effectiveFrom = editing.effectiveFrom;
			this.autoCalculationMode = editing.config.attributes.autoCalculationMode;
			this.pendingContractsEnabled = editing.config.attributes.pendingContractsEnabled;
			this.homeGridColumns.set(editing.config.attributes.homeGridColumns ?? null);
			this.tabs.set(editing.config.tabs);
			this.baseSections.set(editing.config.sections);
			this.sectionVisibility.set(visibilityOf(editing.config.sections));
			this.startCollectionsFrom(editing.config.collections);
			this.startRemarksFrom(editing.config.remarkTypes);
			this.behaviours.set(this.completeFrom(registry, editing.config.fields));
			return;
		}
		this.effectiveFrom = localIsoToday();
		this.behaviours.set(this.completeFrom(registry, {}));
		this.tabs.set(registry.tabs);
		this.sectionVisibility.set(visibilityOf(registry.sections));
		this.copyFromCurrent();
	}
	completeFrom(registry, stored) {
		const all = {};
		const names = [...Object.keys(stored).filter((name) => name in registry.fields), ...Object.keys(registry.fields).filter((name) => !(name in stored))];
		for (const componentName of names) {
			const field = registry.fields[componentName];
			all[componentName] = stored[componentName] ?? {
				visible: true,
				required: field.systemRequired,
				readOnly: field.readOnly,
				borderWarning: false,
				excludeFromCopy: false,
				excludeFromTemplateCopy: false,
				section: field.section,
				order: field.order
			};
		}
		return all;
	}
	toEditorField(componentName, field, behaviour) {
		return {
			componentName,
			label: field.label,
			ctrmField: field.ctrmField,
			ctrmReadOnly: field.readOnly,
			locked: !field.configurable,
			behaviour: behaviour ?? {
				visible: true,
				required: field.systemRequired,
				readOnly: field.readOnly,
				borderWarning: false,
				excludeFromCopy: false,
				excludeFromTemplateCopy: false,
				section: field.section,
				order: field.order
			}
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: FormConfigEditorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: FormConfigEditorComponent,
		isStandalone: true,
		selector: "cms-form-config-editor",
		inputs: { editing: {
			classPropertyName: "editing",
			publicName: "editing",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		outputs: {
			saved: "saved",
			cancelled: "cancelled"
		},
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-5\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      {{ isNew() ? 'New configuration' : 'Edit configuration' }}\r\n    </h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      A row applies to every contract matching the dimensions below — leave one empty to mean\r\n      <em>any</em>. The most specific matching row wins <strong>whole</strong>: nothing is merged\r\n      from less specific rows, which is why this form starts from whatever currently applies.\r\n    </p>\r\n  </header>\r\n\r\n  <!-- #803: why the editor cannot go on, with the server's reference or why there is none. -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\r\n\r\n  @if (!ready()) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">\r\n      Loading the field registry…\r\n    </p>\r\n  } @else {\r\n    <!-- Dimensions -->\r\n    <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Applies to contract type\r\n          </span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorType\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"contractTypeClass\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          #696: a holder picks from the trade units they manage; \"any trade unit\" (a blank location) is\r\n          offered to an Admin only, because the server refuses it to everyone else (AdminRequired, #700).\r\n        -->\r\n        <cws-admin-trade-unit-select\r\n          label=\"Applies to trade unit\"\r\n          [allowAny]=\"true\"\r\n          [value]=\"locationCode\"\r\n          (valueChange)=\"setLocation($event)\"\r\n        />\r\n\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to commodity</span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorCommodity\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"commodityCode\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          🔴 The shared C3 control. See the pricing screen for why the native input went.\r\n\r\n          ⚠ The required marker and `aria-required` are the CONTROL's now. This label carried a\r\n          literal `*` in its text and no `aria-required` at all, so the field announced itself as\r\n          optional to a screen reader while looking required to everyone else.\r\n        -->\r\n        <cms-date-input\r\n          label=\"Effective from\"\r\n          controlId=\"editor-effective\"\r\n          [required]=\"true\"\r\n          name=\"editorEffective\"\r\n          [(ngModel)]=\"effectiveFrom\"\r\n          [errorMessage]=\"effectiveError()\"\r\n          (ngModelChange)=\"effectiveError.set(null)\"\r\n        />\r\n      </div>\r\n\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"copyFromCurrent()\">\r\n          Copy from what currently applies\r\n        </button>\r\n        <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Reloads the field settings below from the configuration in force for these dimensions —\r\n          do this after changing them.\r\n        </span>\r\n      </div>\r\n\r\n      <!--\r\n        F8.1 — seed from trade unit. New rows only: an existing row already has its own settings, and\r\n        overwriting them with another trade unit's is an edit, not a starting point.\r\n\r\n        ⚠ The source is re-read before the create and its rowVersion compared, so the status line\r\n        says so: an administrator who leaves the form open for an hour is told why the create was\r\n        refused, rather than discovering a clone of settings that were since changed.\r\n      -->\r\n      @if (isNew()) {\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Seed from trade unit</span>\r\n            <input\r\n              class=\"scoular-form-input cws:w-40\"\r\n              name=\"editorSeedFrom\"\r\n              placeholder=\"e.g. 4090\"\r\n              [(ngModel)]=\"seedTradeUnit\"\r\n            />\r\n          </label>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"seedFromTradeUnit()\">\r\n            Seed from this trade unit\r\n          </button>\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Copies that trade unit's configuration exactly — every field, section, tab and attribute —\r\n            as this row's starting point. The dimensions above stay this row's.\r\n          </span>\r\n        </div>\r\n\r\n        @if (seededFrom(); as seed) {\r\n          <p\r\n            role=\"status\"\r\n            class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-200\"\r\n          >\r\n            Seeded from trade unit {{ seed.tradeUnit }} — configuration row #{{ seed.id }}\r\n            ({{ seed.dimensionKey }}, version {{ seed.version }}). It is read again before this row\r\n            is created, and the create is refused if it has changed since.\r\n          </p>\r\n        }\r\n\r\n        @if (seedNotice(); as notice) {\r\n          <p\r\n            role=\"alert\"\r\n            class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n          >\r\n            {{ notice }}\r\n          </p>\r\n        }\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        A future effective date is allowed and is how a change is staged: the row sits dormant until\r\n        that date, then takes over from the one before it. Editing an old contract always applies\r\n        today's rules.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Trade unit attributes -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Trade unit behaviour</h4>\r\n\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Contract auto-calculation\r\n          </span>\r\n          <select\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorAutoCalc\"\r\n            [(ngModel)]=\"autoCalculationMode\"\r\n          >\r\n            <option value=\"None\">None — both Price and Basis stay editable</option>\r\n            <option value=\"Price\">Price — computed from its components and locked</option>\r\n            <option value=\"Basis\">Basis — computed from its components and locked</option>\r\n          </select>\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2\">\r\n          <input\r\n            type=\"checkbox\"\r\n            name=\"editorPending\"\r\n            [(ngModel)]=\"pendingContractsEnabled\"\r\n          />\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Pending contracts enabled\r\n          </span>\r\n        </label>\r\n      </div>\r\n\r\n      <!--\r\n        The home grid's columns (docs/02 §2.1, F4.1a, #748). Every column until a list is set; the\r\n        contract number cannot be taken off. Users narrow and reorder within this on their own grid.\r\n      -->\r\n      <div class=\"cws:space-y-2\" data-home-grid-columns>\r\n        <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Home grid columns\r\n            <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n              — {{ homeGridColumns() === null ? 'every column (no list set)' : 'this list, in this order' }}\r\n            </span>\r\n          </span>\r\n          <button\r\n            type=\"button\"\r\n            class=\"scoular-btn scoular-btn-secondary cws:text-xs\"\r\n            [disabled]=\"homeGridColumns() === null\"\r\n            (click)=\"resetHomeGridColumns()\"\r\n          >\r\n            Reset to all\r\n          </button>\r\n        </div>\r\n        <cms-export-fields\r\n          [fields]=\"homeGridColumnFields()\"\r\n          [lockedKeys]=\"lockedColumnKeys\"\r\n          noun=\"columns\"\r\n          listLabel=\"Home grid columns, in order\"\r\n          emptyMessage=\"Select at least one column.\"\r\n          (fieldsChange)=\"onHomeGridColumnsChange($event)\"\r\n        />\r\n      </div>\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <strong>None</strong> is the honest default for a trade unit nobody has configured — picking\r\n        Price or Basis makes the rule compute a value and lock the field, which looks like working\r\n        configuration if it was only a guess.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Tabs -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Tabs</h4>\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Which tabs this configuration shows, and what they are called. A hidden tab is not on the\r\n        screen at all. This is what replaces the legacy application's per-location tabs, which were\r\n        conditions written into its screen rather than configuration.\r\n      </p>\r\n\r\n      <div class=\"cws:space-y-2\">\r\n        @for (tab of editableTabs(); track tab.id) {\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"tab.visible\"\r\n                (change)=\"setTabVisible(tab.id, $any($event.target).checked)\"\r\n                [attr.aria-label]=\"'Show the ' + tab.label + ' tab'\"\r\n              />\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Show</span>\r\n            </label>\r\n\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              [value]=\"tab.label\"\r\n              (change)=\"setTabLabel(tab.id, $any($event.target).value)\"\r\n              [attr.aria-label]=\"'Label for the ' + tab.id + ' tab'\"\r\n            />\r\n\r\n            <code class=\"cws:text-xs cws:text-slate-400\">{{ tab.id }}</code>\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n    <!-- The field grid -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields</h4>\r\n\r\n        <div class=\"cws:flex cws:items-center cws:gap-3\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            {{ requiredCount() }} required · {{ hiddenCount() }} hidden\r\n          </span>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n            <span class=\"sr-only\">Filter fields</span>\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              name=\"editorFilter\"\r\n              placeholder=\"Filter fields…\"\r\n              [ngModel]=\"filter()\"\r\n              (ngModelChange)=\"filter.set($event)\"\r\n            />\r\n          </label>\r\n        </div>\r\n      </div>\r\n\r\n      <!--\r\n        Both states are stated where the administrator is working rather than discovered at save.\r\n        The reorder one explains a disabled control, which is the only honest way to disable\r\n        something; the empty-tab one reports a state this editor can now create and the record\r\n        screen does not resolve away.\r\n      -->\r\n      @if (reorderBlockedReason(); as reason) {\r\n        <p class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\">\r\n          {{ reason }}\r\n        </p>\r\n      }\r\n\r\n      @if (emptyTabWarning(); as emptied) {\r\n        <p\r\n          role=\"status\"\r\n          class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n        >\r\n          Every section is hidden on: {{ emptied }} — so the tab itself will not appear on the\r\n          record screen. Leave a section visible if you want the tab to stay.\r\n        </p>\r\n      }\r\n\r\n      @for (section of sections(); track section.id) {\r\n        <details class=\"cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\" [open]=\"filter() !== ''\">\r\n          <summary class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-sm cws:font-medium\">\r\n            {{ section.label }}\r\n            <span class=\"cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n              ({{ section.fields.length }} fields · {{ section.tab }} tab)\r\n            </span>\r\n          </summary>\r\n\r\n          <!--\r\n            F8.3 — section enablement, in the section's own header rather than on a separate screen,\r\n            because \"is this section on for this trade unit\" is the same question as \"what is in it\".\r\n\r\n            ⚠ The label is a real `<label>` wrapping the input, so the whole phrase is the hit target\r\n            and a screen reader announces the section name with the state. `stopPropagation` keeps a\r\n            click on it from toggling the `<details>` it sits inside — without it, turning a section\r\n            off would also collapse the rows you turned off.\r\n          -->\r\n          <div class=\"cws:border-b cws:border-slate-200 cws:px-3 cws:py-2 cws:dark:border-slate-700\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"sectionVisible(section.id)\"\r\n                (click)=\"$event.stopPropagation()\"\r\n                (change)=\"toggleSection(section.id, $any($event.target).checked)\"\r\n              />\r\n              <span>\r\n                Section visible on the {{ section.tab }} tab\r\n                @if (!sectionVisible(section.id)) {\r\n                  <span class=\"cws:ml-1 cws:text-amber-700 cws:dark:text-amber-400\">\r\n                    — hidden for this trade unit\r\n                  </span>\r\n                }\r\n              </span>\r\n            </label>\r\n          </div>\r\n\r\n          <div class=\"cws:overflow-x-auto\">\r\n            <table class=\"cws:w-full cws:text-sm\">\r\n              <caption class=\"sr-only\">{{ section.label }} field settings</caption>\r\n              <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n                <tr>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Order</th>\r\n                  <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Field</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Read-only</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Warn</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No copy</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No template</th>\r\n                </tr>\r\n              </thead>\r\n              <!--\r\n                🔴 `select-none` is REQUIRED on the CONTAINER of anything draggable — Known Issue 44:\r\n                a press inside a leftover text selection is taken by the browser as a selection drag,\r\n                announced with `pointercancel`, so the gesture works once per session and then\r\n                silently stops. jsdom cannot test it, so the class is the anchor (the spec reads it\r\n                off `data-drag-rows`) and the playground screenshot is the proof.\r\n\r\n                The press is bound here rather than per row: the shared gesture follows the pointer\r\n                on the window from there, and hit-tests the row under it (`data-drop-field`).\r\n              -->\r\n              <tbody data-drag-rows class=\"cws:select-none\" (pointerdown)=\"onRowPointerDown($event)\">\r\n                @for (field of section.fields; track field.componentName; let idx = $index) {\r\n                  <tr\r\n                    class=\"cws:select-none cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\"\r\n                    [class.cws:bg-slate-100]=\"draggingField() === field.componentName\"\r\n                    [class.cws:dark:bg-slate-800]=\"draggingField() === field.componentName\"\r\n                    [class.cws:border-t-2]=\"dropField() === field.componentName\"\r\n                    [class.cws:border-t-scoular-blue]=\"dropField() === field.componentName\"\r\n                    [attr.data-drop-field]=\"field.componentName\"\r\n                    [attr.data-drop-section]=\"section.id\"\r\n                    [attr.data-dragging]=\"draggingField() === field.componentName ? 'true' : null\"\r\n                    [attr.data-drop-here]=\"dropField() === field.componentName ? 'true' : null\"\r\n                  >\r\n                    <td class=\"cws:whitespace-nowrap cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        The drag grip (F8.1). `aria-hidden` with no tab stop: it is an affordance\r\n                        for the pointer, and the arrows beside it are the keyboard's route to the\r\n                        same move. Absent while the list is filtered, for the reason the arrows are\r\n                        disabled — see `reorderBlockedReason`.\r\n                      -->\r\n                      @if (reorderBlockedReason() === null) {\r\n                        <span\r\n                          aria-hidden=\"true\"\r\n                          title=\"Drag to reorder\"\r\n                          class=\"cws:mr-1 cws:inline-block cws:cursor-grab cws:touch-none cws:px-1 cws:text-slate-400\"\r\n                          [attr.data-drag-field]=\"field.componentName\"\r\n                          [attr.data-drag-section]=\"section.id\"\r\n                        >⠿</span>\r\n                      }\r\n                      <!--\r\n                        The keyboard path, and it is the primary one rather than a fallback: this\r\n                        grid is 111 rows and the people who configure it do so from a keyboard.\r\n                        Buttons rather than a numeric input, because \"one place up\" is the operation\r\n                        an administrator actually wants and a free-text order invites collisions.\r\n                      -->\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === 0 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' up'\"\r\n                        (click)=\"moveField(section.id, field.componentName, -1)\"\r\n                      >\r\n                        ↑\r\n                      </button>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === section.fields.length - 1 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' down'\"\r\n                        (click)=\"moveField(section.id, field.componentName, 1)\"\r\n                      >\r\n                        ↓\r\n                      </button>\r\n                    </td>\r\n                    <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                      {{ field.label }}\r\n                      <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ field.ctrmField }}</code>\r\n\r\n                      @if (field.locked) {\r\n                        <!--\r\n                          Shown locked rather than hidden. A field absent from this grid reads as\r\n                          \"not configurable in this version\"; a locked row with a reason reads as\r\n                          \"not yours to change\", which is what it is.\r\n                        -->\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n                          — system field: resolution keys on it\r\n                        </span>\r\n                      } @else if (field.ctrmReadOnly) {\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">\r\n                          — CTRM refuses this on a write, so it cannot be required\r\n                        </span>\r\n                      }\r\n                      <!-- #221: width, heading and description for this trade unit. -->\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:ml-1 cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [attr.aria-expanded]=\"openPresentation() === field.componentName\"\r\n                        [attr.aria-label]=\"field.label + ' presentation'\"\r\n                        (click)=\"togglePresentation(field.componentName)\"\r\n                      >\r\n                        Presentation{{ field.behaviour.presentation ? ' (set)' : '' }}\r\n                      </button>\r\n                    </th>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.visible\"\r\n                        [disabled]=\"field.locked || field.behaviour.required\"\r\n                        (change)=\"setVisible(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' visible'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        Disabled for a CTRM read-only field and for the drivers: requiring the\r\n                        first demands the impossible, and the second is already required and not\r\n                        the admin's to relax.\r\n                      -->\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.required\"\r\n                        [disabled]=\"field.locked || field.ctrmReadOnly\"\r\n                        (change)=\"setRequired(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' required'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.readOnly\"\r\n                        [disabled]=\"field.ctrmReadOnly\"\r\n                        (change)=\"setFlag(field.componentName, 'readOnly', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' read only'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.borderWarning\"\r\n                        (change)=\"setFlag(field.componentName, 'borderWarning', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' border warning'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from copy'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromTemplateCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromTemplateCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from template copy'\"\r\n                      />\r\n                    </td>\r\n                  </tr>\r\n                  @if (openPresentation() === field.componentName) {\r\n                    <!--\r\n                      #221: the five presentation settings. Each starts at \"the layout's\", which sends\r\n                      nothing, so a row saved without touching these stores no presentation at all.\r\n                      No drop-target attributes, so the drag gesture ignores this row.\r\n                    -->\r\n                    @let layout = layoutDefault(field.componentName);\r\n                    @let current = field.behaviour.presentation;\r\n                    @let preview = previewOf(field);\r\n                    <tr class=\"cws:bg-slate-50 cws:dark:bg-slate-900\" [attr.data-presentation-for]=\"field.componentName\">\r\n                      <td colspan=\"8\" class=\"cws:px-3 cws:py-3\">\r\n                        <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-[1fr_1fr]\">\r\n                          <div class=\"cws:grid cws:gap-2 cws:text-xs\">\r\n                            <!--\r\n                              An explicit label per control, not a wrapping one: a <label> around a\r\n                              <select> puts the selected option into the accessible name (\"Width\r\n                              Layout's (full)\"), which a screen reader then reads on every change.\r\n                            -->\r\n                            @let pid = 'presentation-' + field.componentName;\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-width'\">Width</label>\r\n                              <select\r\n                                class=\"scoular-form-select cws:mt-1\"\r\n                                [id]=\"pid + '-width'\"\r\n                                [value]=\"flagChoice(current?.halfWidth)\"\r\n                                (change)=\"setPresentationFlag(field.componentName, 'halfWidth', $any($event.target).value)\"\r\n                              >\r\n                                <option value=\"\">Layout's ({{ layout.half ? 'half' : 'full' }})</option>\r\n                                <option value=\"true\">Half width</option>\r\n                                <option value=\"false\">Full width</option>\r\n                              </select>\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-heading'\">Heading</label>\r\n                              <select\r\n                                class=\"scoular-form-select cws:mt-1\"\r\n                                [id]=\"pid + '-heading'\"\r\n                                [value]=\"flagChoice(current?.labelHidden)\"\r\n                                (change)=\"setPresentationFlag(field.componentName, 'labelHidden', $any($event.target).value)\"\r\n                              >\r\n                                <option value=\"\">Layout's ({{ layout.labelHidden ? 'hidden' : 'shown' }})</option>\r\n                                <option value=\"false\">Shown</option>\r\n                                <option value=\"true\">Hidden (still read by screen readers)</option>\r\n                              </select>\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-label'\">Heading text</label>\r\n                              <input\r\n                                class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n                                [id]=\"pid + '-label'\"\r\n                                [value]=\"current?.label ?? ''\"\r\n                                [placeholder]=\"field.label\"\r\n                                (change)=\"setPresentation(field.componentName, 'label', $any($event.target).value)\"\r\n                              />\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-tooltip'\">Description</label>\r\n                              <select\r\n                                class=\"scoular-form-select cws:mt-1\"\r\n                                [id]=\"pid + '-tooltip'\"\r\n                                [value]=\"flagChoice(current?.tooltipEnabled)\"\r\n                                (change)=\"setPresentationFlag(field.componentName, 'tooltipEnabled', $any($event.target).value)\"\r\n                              >\r\n                                <option value=\"\">Layout's ({{ layout.note === null ? 'none' : 'shown' }})</option>\r\n                                <option value=\"true\">Shown</option>\r\n                                <option value=\"false\">Hidden</option>\r\n                              </select>\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-description'\">Description text</label>\r\n                              <textarea\r\n                                class=\"scoular-form-textarea cws:mt-1 cws:w-full\"\r\n                                [id]=\"pid + '-description'\"\r\n                                rows=\"2\"\r\n                                [value]=\"current?.tooltipDescription ?? ''\"\r\n                                [placeholder]=\"layout.note ?? 'No description in the layout'\"\r\n                                (change)=\"setPresentation(field.componentName, 'tooltipDescription', $any($event.target).value)\"\r\n                              ></textarea>\r\n                            </div>\r\n                            <div>\r\n                              <button\r\n                                type=\"button\"\r\n                                class=\"scoular-btn scoular-btn-secondary\"\r\n                                [disabled]=\"current === undefined\"\r\n                                (click)=\"resetPresentation(field.componentName)\"\r\n                              >\r\n                                Reset to layout\r\n                              </button>\r\n                            </div>\r\n                          </div>\r\n\r\n                          <!-- The preview: how the heading, width and description will render. -->\r\n                          <div class=\"cws:text-xs\" [attr.data-presentation-preview]=\"field.componentName\">\r\n                            <p class=\"cws:font-medium\">Preview</p>\r\n                            <div class=\"cws:mt-1 cws:grid cws:grid-cols-2 cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-2 cws:dark:border-slate-600\">\r\n                              <div [class.cws:col-span-2]=\"!preview.half\" [class.cws:col-span-1]=\"preview.half\">\r\n                                @if (preview.labelHidden) {\r\n                                  <span class=\"sr-only\">{{ preview.label }}</span>\r\n                                  <span class=\"cws:italic cws:text-slate-400\" aria-hidden=\"true\">Heading hidden</span>\r\n                                } @else {\r\n                                  <span class=\"cws:font-medium\">{{ preview.label }}</span>\r\n                                }\r\n                                <span class=\"cws:mt-1 cws:block cws:h-8 cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:dark:bg-slate-800\"></span>\r\n                                @if (preview.description !== null) {\r\n                                  <span class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\">\r\n                                    {{ preview.half ? 'ⓘ ' : '' }}{{ preview.description }}\r\n                                  </span>\r\n                                }\r\n                              </div>\r\n                            </div>\r\n                            <p class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              {{ preview.half ? 'Half width' : 'Full width' }} ·\r\n                              heading {{ preview.labelHidden ? 'hidden' : 'shown' }} ·\r\n                              {{ preview.description === null ? 'no description' : (preview.half ? 'description in the ⓘ tooltip' : 'description under the field') }}\r\n                            </p>\r\n                          </div>\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  }\r\n                }\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </details>\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Ticking <strong>Required</strong> also ticks <strong>Visible</strong> and locks it — a field\r\n        somebody must fill in cannot be one they cannot see. The save enforces requiredness against\r\n        the contract as it will reach CTRM, so a field the user never touched still counts as filled\r\n        if CTRM already holds a value for it.\r\n      </p>\r\n    </div>\r\n\r\n    <!--\r\n      #1000: the collection copy flags (#959). Rendered only when the registry offers collections, so\r\n      a server without #959 shows nothing here rather than an error. Only Exclude from copy: the\r\n      template flag is stored but not shown until templates carry collections, and Visible, Required\r\n      and Read-only mean nothing for a whole collection (ruled 2026-10-20).\r\n    -->\r\n    @if (collectionRows(); as collections) {\r\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-collections-on-copy>\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Collections on copy</h4>\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Which of a contract's collections a copy leaves out, for this configuration. Every collection\r\n          is copied until it is excluded here.\r\n        </p>\r\n\r\n        <div class=\"cws:overflow-x-auto\">\r\n          <table class=\"cws:w-full cws:text-sm\">\r\n            <caption class=\"sr-only\">Collection copy settings</caption>\r\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n              <tr>\r\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Collection</th>\r\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Exclude from copy</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              @for (collection of collections; track collection.name) {\r\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-collection]=\"collection.name\">\r\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                    {{ collection.label }}\r\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ collection.name }}</code>\r\n                    @if (!collection.copyable) {\r\n                      <!-- Shown disabled with the reason, rather than hidden: the server refuses a set flag on it. -->\r\n                      <span\r\n                        class=\"cws:ml-1 cws:text-xs cws:text-slate-400\"\r\n                        [id]=\"'collection-not-copied-' + collection.name\"\r\n                      >\r\n                        — CTRM does not accept this on a write, so a copy never carries it.\r\n                      </span>\r\n                    }\r\n                  </th>\r\n                  <td class=\"cws:px-2 cws:py-1.5\">\r\n                    <input\r\n                      type=\"checkbox\"\r\n                      [checked]=\"collection.excludeFromCopy\"\r\n                      [disabled]=\"!collection.copyable\"\r\n                      (change)=\"setCollectionExcluded(collection.name, $any($event.target).checked)\"\r\n                      [attr.aria-label]=\"'Exclude the ' + collection.name + ' collection from copy'\"\r\n                      [attr.aria-describedby]=\"collection.copyable ? null : 'collection-not-copied-' + collection.name\"\r\n                    />\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    <!--\r\n      #1006 (ruled 2026-10-21, option (a)): one row per CTRM remark type, each with Visible and Required.\r\n      Rendered only when the registry offers remark types (#1022), so a server without it shows nothing\r\n      here rather than an error. Required ticks Visible and locks it, as it does for a field.\r\n    -->\r\n    @if (remarkRows(); as remarks) {\r\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-remark-types>\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Remarks</h4>\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Which remark types the record screen offers, and which must be filled in before a contract\r\n          can be saved. A hidden type's stored remark is kept: it is only not shown for editing.\r\n        </p>\r\n\r\n        <div class=\"cws:overflow-x-auto\">\r\n          <table class=\"cws:w-full cws:text-sm\">\r\n            <caption class=\"sr-only\">Remark type settings</caption>\r\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n              <tr>\r\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Remark type</th>\r\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\r\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              @for (remark of remarks; track remark.code) {\r\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-remark-type]=\"remark.code\">\r\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                    {{ remark.label }}\r\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ remark.code }}</code>\r\n                  </th>\r\n                  <td class=\"cws:px-2 cws:py-1.5\">\r\n                    <input\r\n                      type=\"checkbox\"\r\n                      [checked]=\"remark.visible\"\r\n                      [disabled]=\"remark.required\"\r\n                      (change)=\"setRemarkFlag(remark.code, 'visible', $any($event.target).checked)\"\r\n                      [attr.aria-label]=\"remark.label + ' remark visible'\"\r\n                    />\r\n                  </td>\r\n                  <td class=\"cws:px-2 cws:py-1.5\">\r\n                    <input\r\n                      type=\"checkbox\"\r\n                      [checked]=\"remark.required\"\r\n                      (change)=\"setRemarkFlag(remark.code, 'required', $any($event.target).checked)\"\r\n                      [attr.aria-label]=\"remark.label + ' remark required'\"\r\n                    />\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (columnsNotKept()) {\r\n      <!--\r\n        #748: the row WAS saved; only the column list was not kept. Saving again would repeat the\r\n        save, so the only action offered is to close, and the list has to wait for #747.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-columns-not-kept>\r\n        <div class=\"scoular-alert-title\">Saved, except the home grid columns</div>\r\n        <div class=\"scoular-alert-description\">\r\n          The rest of this configuration was saved. The server did not keep the column list, because it\r\n          cannot store one yet, so this trade unit's grid still shows every column.\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (everyTradeUnitPending()) {\r\n      <!--\r\n        #844: a row for every trade unit takes a second, deliberate click. The Dev walk made one by\r\n        mistake with a seed set, so the seed is named: seeding copies settings, it does not pick the\r\n        trade unit the row applies to.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-every-trade-unit>\r\n        <div class=\"scoular-alert-title\">This configuration applies to every trade unit</div>\r\n        <div class=\"scoular-alert-description cws:space-y-2\">\r\n          <p>\r\n            @if (seededFrom(); as seed) {\r\n              Its settings are copied from trade unit {{ seed.tradeUnit }}, but it applies to every trade unit.\r\n            }\r\n            \"Applies to trade unit\" is set to any trade unit, so from its effective date this row is used\r\n            for every trade unit that has no more specific row of its own. To configure one trade unit,\r\n            pick it under \"Applies to trade unit\".\r\n          </p>\r\n          <div class=\"cws:flex cws:flex-wrap cws:gap-3\">\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"saving()\" (click)=\"save(true)\">\r\n              {{ isNew() ? 'Create for every trade unit' : 'Save for every trade unit' }}\r\n            </button>\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"everyTradeUnitPending.set(false)\">\r\n              Go back\r\n            </button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n      @if (columnsNotKept()) {\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"saved.emit()\">\r\n          Close\r\n        </button>\r\n      }\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary\"\r\n        [class.cws:hidden]=\"columnsNotKept()\"\r\n        [disabled]=\"saving() || columnsNotKept()\"\r\n        (click)=\"save()\"\r\n      >\r\n        {{ saving() ? 'Saving…' : isNew() ? 'Create configuration' : 'Save changes' }}\r\n      </button>\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-secondary\"\r\n        (click)=\"cancel()\"\r\n      >\r\n        Cancel\r\n      </button>\r\n    </div>\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: DateInputComponent,
				selector: "cms-date-input",
				inputs: [
					"label",
					"controlId",
					"required",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: ExportFieldsComponent,
				selector: "cms-export-fields",
				inputs: [
					"fields",
					"lockedKeys",
					"noun",
					"listLabel",
					"emptyMessage"
				],
				outputs: ["fieldsChange"]
			},
			{
				kind: "component",
				type: AdminTradeUnitSelectComponent,
				selector: "cws-admin-trade-unit-select",
				inputs: [
					"label",
					"value",
					"allowAny"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: FormConfigEditorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-config-editor",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				DateInputComponent,
				ExportFieldsComponent,
				AdminTradeUnitSelectComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-5\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      {{ isNew() ? 'New configuration' : 'Edit configuration' }}\r\n    </h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      A row applies to every contract matching the dimensions below — leave one empty to mean\r\n      <em>any</em>. The most specific matching row wins <strong>whole</strong>: nothing is merged\r\n      from less specific rows, which is why this form starts from whatever currently applies.\r\n    </p>\r\n  </header>\r\n\r\n  <!-- #803: why the editor cannot go on, with the server's reference or why there is none. -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\r\n\r\n  @if (!ready()) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">\r\n      Loading the field registry…\r\n    </p>\r\n  } @else {\r\n    <!-- Dimensions -->\r\n    <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Applies to contract type\r\n          </span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorType\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"contractTypeClass\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          #696: a holder picks from the trade units they manage; \"any trade unit\" (a blank location) is\r\n          offered to an Admin only, because the server refuses it to everyone else (AdminRequired, #700).\r\n        -->\r\n        <cws-admin-trade-unit-select\r\n          label=\"Applies to trade unit\"\r\n          [allowAny]=\"true\"\r\n          [value]=\"locationCode\"\r\n          (valueChange)=\"setLocation($event)\"\r\n        />\r\n\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to commodity</span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorCommodity\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"commodityCode\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          🔴 The shared C3 control. See the pricing screen for why the native input went.\r\n\r\n          ⚠ The required marker and `aria-required` are the CONTROL's now. This label carried a\r\n          literal `*` in its text and no `aria-required` at all, so the field announced itself as\r\n          optional to a screen reader while looking required to everyone else.\r\n        -->\r\n        <cms-date-input\r\n          label=\"Effective from\"\r\n          controlId=\"editor-effective\"\r\n          [required]=\"true\"\r\n          name=\"editorEffective\"\r\n          [(ngModel)]=\"effectiveFrom\"\r\n          [errorMessage]=\"effectiveError()\"\r\n          (ngModelChange)=\"effectiveError.set(null)\"\r\n        />\r\n      </div>\r\n\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"copyFromCurrent()\">\r\n          Copy from what currently applies\r\n        </button>\r\n        <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Reloads the field settings below from the configuration in force for these dimensions —\r\n          do this after changing them.\r\n        </span>\r\n      </div>\r\n\r\n      <!--\r\n        F8.1 — seed from trade unit. New rows only: an existing row already has its own settings, and\r\n        overwriting them with another trade unit's is an edit, not a starting point.\r\n\r\n        ⚠ The source is re-read before the create and its rowVersion compared, so the status line\r\n        says so: an administrator who leaves the form open for an hour is told why the create was\r\n        refused, rather than discovering a clone of settings that were since changed.\r\n      -->\r\n      @if (isNew()) {\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Seed from trade unit</span>\r\n            <input\r\n              class=\"scoular-form-input cws:w-40\"\r\n              name=\"editorSeedFrom\"\r\n              placeholder=\"e.g. 4090\"\r\n              [(ngModel)]=\"seedTradeUnit\"\r\n            />\r\n          </label>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"seedFromTradeUnit()\">\r\n            Seed from this trade unit\r\n          </button>\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Copies that trade unit's configuration exactly — every field, section, tab and attribute —\r\n            as this row's starting point. The dimensions above stay this row's.\r\n          </span>\r\n        </div>\r\n\r\n        @if (seededFrom(); as seed) {\r\n          <p\r\n            role=\"status\"\r\n            class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-200\"\r\n          >\r\n            Seeded from trade unit {{ seed.tradeUnit }} — configuration row #{{ seed.id }}\r\n            ({{ seed.dimensionKey }}, version {{ seed.version }}). It is read again before this row\r\n            is created, and the create is refused if it has changed since.\r\n          </p>\r\n        }\r\n\r\n        @if (seedNotice(); as notice) {\r\n          <p\r\n            role=\"alert\"\r\n            class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n          >\r\n            {{ notice }}\r\n          </p>\r\n        }\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        A future effective date is allowed and is how a change is staged: the row sits dormant until\r\n        that date, then takes over from the one before it. Editing an old contract always applies\r\n        today's rules.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Trade unit attributes -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Trade unit behaviour</h4>\r\n\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Contract auto-calculation\r\n          </span>\r\n          <select\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorAutoCalc\"\r\n            [(ngModel)]=\"autoCalculationMode\"\r\n          >\r\n            <option value=\"None\">None — both Price and Basis stay editable</option>\r\n            <option value=\"Price\">Price — computed from its components and locked</option>\r\n            <option value=\"Basis\">Basis — computed from its components and locked</option>\r\n          </select>\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2\">\r\n          <input\r\n            type=\"checkbox\"\r\n            name=\"editorPending\"\r\n            [(ngModel)]=\"pendingContractsEnabled\"\r\n          />\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Pending contracts enabled\r\n          </span>\r\n        </label>\r\n      </div>\r\n\r\n      <!--\r\n        The home grid's columns (docs/02 §2.1, F4.1a, #748). Every column until a list is set; the\r\n        contract number cannot be taken off. Users narrow and reorder within this on their own grid.\r\n      -->\r\n      <div class=\"cws:space-y-2\" data-home-grid-columns>\r\n        <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Home grid columns\r\n            <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n              — {{ homeGridColumns() === null ? 'every column (no list set)' : 'this list, in this order' }}\r\n            </span>\r\n          </span>\r\n          <button\r\n            type=\"button\"\r\n            class=\"scoular-btn scoular-btn-secondary cws:text-xs\"\r\n            [disabled]=\"homeGridColumns() === null\"\r\n            (click)=\"resetHomeGridColumns()\"\r\n          >\r\n            Reset to all\r\n          </button>\r\n        </div>\r\n        <cms-export-fields\r\n          [fields]=\"homeGridColumnFields()\"\r\n          [lockedKeys]=\"lockedColumnKeys\"\r\n          noun=\"columns\"\r\n          listLabel=\"Home grid columns, in order\"\r\n          emptyMessage=\"Select at least one column.\"\r\n          (fieldsChange)=\"onHomeGridColumnsChange($event)\"\r\n        />\r\n      </div>\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <strong>None</strong> is the honest default for a trade unit nobody has configured — picking\r\n        Price or Basis makes the rule compute a value and lock the field, which looks like working\r\n        configuration if it was only a guess.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Tabs -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Tabs</h4>\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Which tabs this configuration shows, and what they are called. A hidden tab is not on the\r\n        screen at all. This is what replaces the legacy application's per-location tabs, which were\r\n        conditions written into its screen rather than configuration.\r\n      </p>\r\n\r\n      <div class=\"cws:space-y-2\">\r\n        @for (tab of editableTabs(); track tab.id) {\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"tab.visible\"\r\n                (change)=\"setTabVisible(tab.id, $any($event.target).checked)\"\r\n                [attr.aria-label]=\"'Show the ' + tab.label + ' tab'\"\r\n              />\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Show</span>\r\n            </label>\r\n\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              [value]=\"tab.label\"\r\n              (change)=\"setTabLabel(tab.id, $any($event.target).value)\"\r\n              [attr.aria-label]=\"'Label for the ' + tab.id + ' tab'\"\r\n            />\r\n\r\n            <code class=\"cws:text-xs cws:text-slate-400\">{{ tab.id }}</code>\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n    <!-- The field grid -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields</h4>\r\n\r\n        <div class=\"cws:flex cws:items-center cws:gap-3\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            {{ requiredCount() }} required · {{ hiddenCount() }} hidden\r\n          </span>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n            <span class=\"sr-only\">Filter fields</span>\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              name=\"editorFilter\"\r\n              placeholder=\"Filter fields…\"\r\n              [ngModel]=\"filter()\"\r\n              (ngModelChange)=\"filter.set($event)\"\r\n            />\r\n          </label>\r\n        </div>\r\n      </div>\r\n\r\n      <!--\r\n        Both states are stated where the administrator is working rather than discovered at save.\r\n        The reorder one explains a disabled control, which is the only honest way to disable\r\n        something; the empty-tab one reports a state this editor can now create and the record\r\n        screen does not resolve away.\r\n      -->\r\n      @if (reorderBlockedReason(); as reason) {\r\n        <p class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\">\r\n          {{ reason }}\r\n        </p>\r\n      }\r\n\r\n      @if (emptyTabWarning(); as emptied) {\r\n        <p\r\n          role=\"status\"\r\n          class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n        >\r\n          Every section is hidden on: {{ emptied }} — so the tab itself will not appear on the\r\n          record screen. Leave a section visible if you want the tab to stay.\r\n        </p>\r\n      }\r\n\r\n      @for (section of sections(); track section.id) {\r\n        <details class=\"cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\" [open]=\"filter() !== ''\">\r\n          <summary class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-sm cws:font-medium\">\r\n            {{ section.label }}\r\n            <span class=\"cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n              ({{ section.fields.length }} fields · {{ section.tab }} tab)\r\n            </span>\r\n          </summary>\r\n\r\n          <!--\r\n            F8.3 — section enablement, in the section's own header rather than on a separate screen,\r\n            because \"is this section on for this trade unit\" is the same question as \"what is in it\".\r\n\r\n            ⚠ The label is a real `<label>` wrapping the input, so the whole phrase is the hit target\r\n            and a screen reader announces the section name with the state. `stopPropagation` keeps a\r\n            click on it from toggling the `<details>` it sits inside — without it, turning a section\r\n            off would also collapse the rows you turned off.\r\n          -->\r\n          <div class=\"cws:border-b cws:border-slate-200 cws:px-3 cws:py-2 cws:dark:border-slate-700\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"sectionVisible(section.id)\"\r\n                (click)=\"$event.stopPropagation()\"\r\n                (change)=\"toggleSection(section.id, $any($event.target).checked)\"\r\n              />\r\n              <span>\r\n                Section visible on the {{ section.tab }} tab\r\n                @if (!sectionVisible(section.id)) {\r\n                  <span class=\"cws:ml-1 cws:text-amber-700 cws:dark:text-amber-400\">\r\n                    — hidden for this trade unit\r\n                  </span>\r\n                }\r\n              </span>\r\n            </label>\r\n          </div>\r\n\r\n          <div class=\"cws:overflow-x-auto\">\r\n            <table class=\"cws:w-full cws:text-sm\">\r\n              <caption class=\"sr-only\">{{ section.label }} field settings</caption>\r\n              <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n                <tr>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Order</th>\r\n                  <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Field</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Read-only</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Warn</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No copy</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No template</th>\r\n                </tr>\r\n              </thead>\r\n              <!--\r\n                🔴 `select-none` is REQUIRED on the CONTAINER of anything draggable — Known Issue 44:\r\n                a press inside a leftover text selection is taken by the browser as a selection drag,\r\n                announced with `pointercancel`, so the gesture works once per session and then\r\n                silently stops. jsdom cannot test it, so the class is the anchor (the spec reads it\r\n                off `data-drag-rows`) and the playground screenshot is the proof.\r\n\r\n                The press is bound here rather than per row: the shared gesture follows the pointer\r\n                on the window from there, and hit-tests the row under it (`data-drop-field`).\r\n              -->\r\n              <tbody data-drag-rows class=\"cws:select-none\" (pointerdown)=\"onRowPointerDown($event)\">\r\n                @for (field of section.fields; track field.componentName; let idx = $index) {\r\n                  <tr\r\n                    class=\"cws:select-none cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\"\r\n                    [class.cws:bg-slate-100]=\"draggingField() === field.componentName\"\r\n                    [class.cws:dark:bg-slate-800]=\"draggingField() === field.componentName\"\r\n                    [class.cws:border-t-2]=\"dropField() === field.componentName\"\r\n                    [class.cws:border-t-scoular-blue]=\"dropField() === field.componentName\"\r\n                    [attr.data-drop-field]=\"field.componentName\"\r\n                    [attr.data-drop-section]=\"section.id\"\r\n                    [attr.data-dragging]=\"draggingField() === field.componentName ? 'true' : null\"\r\n                    [attr.data-drop-here]=\"dropField() === field.componentName ? 'true' : null\"\r\n                  >\r\n                    <td class=\"cws:whitespace-nowrap cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        The drag grip (F8.1). `aria-hidden` with no tab stop: it is an affordance\r\n                        for the pointer, and the arrows beside it are the keyboard's route to the\r\n                        same move. Absent while the list is filtered, for the reason the arrows are\r\n                        disabled — see `reorderBlockedReason`.\r\n                      -->\r\n                      @if (reorderBlockedReason() === null) {\r\n                        <span\r\n                          aria-hidden=\"true\"\r\n                          title=\"Drag to reorder\"\r\n                          class=\"cws:mr-1 cws:inline-block cws:cursor-grab cws:touch-none cws:px-1 cws:text-slate-400\"\r\n                          [attr.data-drag-field]=\"field.componentName\"\r\n                          [attr.data-drag-section]=\"section.id\"\r\n                        >⠿</span>\r\n                      }\r\n                      <!--\r\n                        The keyboard path, and it is the primary one rather than a fallback: this\r\n                        grid is 111 rows and the people who configure it do so from a keyboard.\r\n                        Buttons rather than a numeric input, because \"one place up\" is the operation\r\n                        an administrator actually wants and a free-text order invites collisions.\r\n                      -->\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === 0 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' up'\"\r\n                        (click)=\"moveField(section.id, field.componentName, -1)\"\r\n                      >\r\n                        ↑\r\n                      </button>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === section.fields.length - 1 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' down'\"\r\n                        (click)=\"moveField(section.id, field.componentName, 1)\"\r\n                      >\r\n                        ↓\r\n                      </button>\r\n                    </td>\r\n                    <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                      {{ field.label }}\r\n                      <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ field.ctrmField }}</code>\r\n\r\n                      @if (field.locked) {\r\n                        <!--\r\n                          Shown locked rather than hidden. A field absent from this grid reads as\r\n                          \"not configurable in this version\"; a locked row with a reason reads as\r\n                          \"not yours to change\", which is what it is.\r\n                        -->\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n                          — system field: resolution keys on it\r\n                        </span>\r\n                      } @else if (field.ctrmReadOnly) {\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">\r\n                          — CTRM refuses this on a write, so it cannot be required\r\n                        </span>\r\n                      }\r\n                      <!-- #221: width, heading and description for this trade unit. -->\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:ml-1 cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [attr.aria-expanded]=\"openPresentation() === field.componentName\"\r\n                        [attr.aria-label]=\"field.label + ' presentation'\"\r\n                        (click)=\"togglePresentation(field.componentName)\"\r\n                      >\r\n                        Presentation{{ field.behaviour.presentation ? ' (set)' : '' }}\r\n                      </button>\r\n                    </th>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.visible\"\r\n                        [disabled]=\"field.locked || field.behaviour.required\"\r\n                        (change)=\"setVisible(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' visible'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        Disabled for a CTRM read-only field and for the drivers: requiring the\r\n                        first demands the impossible, and the second is already required and not\r\n                        the admin's to relax.\r\n                      -->\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.required\"\r\n                        [disabled]=\"field.locked || field.ctrmReadOnly\"\r\n                        (change)=\"setRequired(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' required'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.readOnly\"\r\n                        [disabled]=\"field.ctrmReadOnly\"\r\n                        (change)=\"setFlag(field.componentName, 'readOnly', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' read only'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.borderWarning\"\r\n                        (change)=\"setFlag(field.componentName, 'borderWarning', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' border warning'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from copy'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromTemplateCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromTemplateCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from template copy'\"\r\n                      />\r\n                    </td>\r\n                  </tr>\r\n                  @if (openPresentation() === field.componentName) {\r\n                    <!--\r\n                      #221: the five presentation settings. Each starts at \"the layout's\", which sends\r\n                      nothing, so a row saved without touching these stores no presentation at all.\r\n                      No drop-target attributes, so the drag gesture ignores this row.\r\n                    -->\r\n                    @let layout = layoutDefault(field.componentName);\r\n                    @let current = field.behaviour.presentation;\r\n                    @let preview = previewOf(field);\r\n                    <tr class=\"cws:bg-slate-50 cws:dark:bg-slate-900\" [attr.data-presentation-for]=\"field.componentName\">\r\n                      <td colspan=\"8\" class=\"cws:px-3 cws:py-3\">\r\n                        <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-[1fr_1fr]\">\r\n                          <div class=\"cws:grid cws:gap-2 cws:text-xs\">\r\n                            <!--\r\n                              An explicit label per control, not a wrapping one: a <label> around a\r\n                              <select> puts the selected option into the accessible name (\"Width\r\n                              Layout's (full)\"), which a screen reader then reads on every change.\r\n                            -->\r\n                            @let pid = 'presentation-' + field.componentName;\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-width'\">Width</label>\r\n                              <select\r\n                                class=\"scoular-form-select cws:mt-1\"\r\n                                [id]=\"pid + '-width'\"\r\n                                [value]=\"flagChoice(current?.halfWidth)\"\r\n                                (change)=\"setPresentationFlag(field.componentName, 'halfWidth', $any($event.target).value)\"\r\n                              >\r\n                                <option value=\"\">Layout's ({{ layout.half ? 'half' : 'full' }})</option>\r\n                                <option value=\"true\">Half width</option>\r\n                                <option value=\"false\">Full width</option>\r\n                              </select>\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-heading'\">Heading</label>\r\n                              <select\r\n                                class=\"scoular-form-select cws:mt-1\"\r\n                                [id]=\"pid + '-heading'\"\r\n                                [value]=\"flagChoice(current?.labelHidden)\"\r\n                                (change)=\"setPresentationFlag(field.componentName, 'labelHidden', $any($event.target).value)\"\r\n                              >\r\n                                <option value=\"\">Layout's ({{ layout.labelHidden ? 'hidden' : 'shown' }})</option>\r\n                                <option value=\"false\">Shown</option>\r\n                                <option value=\"true\">Hidden (still read by screen readers)</option>\r\n                              </select>\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-label'\">Heading text</label>\r\n                              <input\r\n                                class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n                                [id]=\"pid + '-label'\"\r\n                                [value]=\"current?.label ?? ''\"\r\n                                [placeholder]=\"field.label\"\r\n                                (change)=\"setPresentation(field.componentName, 'label', $any($event.target).value)\"\r\n                              />\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-tooltip'\">Description</label>\r\n                              <select\r\n                                class=\"scoular-form-select cws:mt-1\"\r\n                                [id]=\"pid + '-tooltip'\"\r\n                                [value]=\"flagChoice(current?.tooltipEnabled)\"\r\n                                (change)=\"setPresentationFlag(field.componentName, 'tooltipEnabled', $any($event.target).value)\"\r\n                              >\r\n                                <option value=\"\">Layout's ({{ layout.note === null ? 'none' : 'shown' }})</option>\r\n                                <option value=\"true\">Shown</option>\r\n                                <option value=\"false\">Hidden</option>\r\n                              </select>\r\n                            </div>\r\n                            <div>\r\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-description'\">Description text</label>\r\n                              <textarea\r\n                                class=\"scoular-form-textarea cws:mt-1 cws:w-full\"\r\n                                [id]=\"pid + '-description'\"\r\n                                rows=\"2\"\r\n                                [value]=\"current?.tooltipDescription ?? ''\"\r\n                                [placeholder]=\"layout.note ?? 'No description in the layout'\"\r\n                                (change)=\"setPresentation(field.componentName, 'tooltipDescription', $any($event.target).value)\"\r\n                              ></textarea>\r\n                            </div>\r\n                            <div>\r\n                              <button\r\n                                type=\"button\"\r\n                                class=\"scoular-btn scoular-btn-secondary\"\r\n                                [disabled]=\"current === undefined\"\r\n                                (click)=\"resetPresentation(field.componentName)\"\r\n                              >\r\n                                Reset to layout\r\n                              </button>\r\n                            </div>\r\n                          </div>\r\n\r\n                          <!-- The preview: how the heading, width and description will render. -->\r\n                          <div class=\"cws:text-xs\" [attr.data-presentation-preview]=\"field.componentName\">\r\n                            <p class=\"cws:font-medium\">Preview</p>\r\n                            <div class=\"cws:mt-1 cws:grid cws:grid-cols-2 cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-2 cws:dark:border-slate-600\">\r\n                              <div [class.cws:col-span-2]=\"!preview.half\" [class.cws:col-span-1]=\"preview.half\">\r\n                                @if (preview.labelHidden) {\r\n                                  <span class=\"sr-only\">{{ preview.label }}</span>\r\n                                  <span class=\"cws:italic cws:text-slate-400\" aria-hidden=\"true\">Heading hidden</span>\r\n                                } @else {\r\n                                  <span class=\"cws:font-medium\">{{ preview.label }}</span>\r\n                                }\r\n                                <span class=\"cws:mt-1 cws:block cws:h-8 cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:dark:bg-slate-800\"></span>\r\n                                @if (preview.description !== null) {\r\n                                  <span class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\">\r\n                                    {{ preview.half ? 'ⓘ ' : '' }}{{ preview.description }}\r\n                                  </span>\r\n                                }\r\n                              </div>\r\n                            </div>\r\n                            <p class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              {{ preview.half ? 'Half width' : 'Full width' }} ·\r\n                              heading {{ preview.labelHidden ? 'hidden' : 'shown' }} ·\r\n                              {{ preview.description === null ? 'no description' : (preview.half ? 'description in the ⓘ tooltip' : 'description under the field') }}\r\n                            </p>\r\n                          </div>\r\n                        </div>\r\n                      </td>\r\n                    </tr>\r\n                  }\r\n                }\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </details>\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Ticking <strong>Required</strong> also ticks <strong>Visible</strong> and locks it — a field\r\n        somebody must fill in cannot be one they cannot see. The save enforces requiredness against\r\n        the contract as it will reach CTRM, so a field the user never touched still counts as filled\r\n        if CTRM already holds a value for it.\r\n      </p>\r\n    </div>\r\n\r\n    <!--\r\n      #1000: the collection copy flags (#959). Rendered only when the registry offers collections, so\r\n      a server without #959 shows nothing here rather than an error. Only Exclude from copy: the\r\n      template flag is stored but not shown until templates carry collections, and Visible, Required\r\n      and Read-only mean nothing for a whole collection (ruled 2026-10-20).\r\n    -->\r\n    @if (collectionRows(); as collections) {\r\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-collections-on-copy>\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Collections on copy</h4>\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Which of a contract's collections a copy leaves out, for this configuration. Every collection\r\n          is copied until it is excluded here.\r\n        </p>\r\n\r\n        <div class=\"cws:overflow-x-auto\">\r\n          <table class=\"cws:w-full cws:text-sm\">\r\n            <caption class=\"sr-only\">Collection copy settings</caption>\r\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n              <tr>\r\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Collection</th>\r\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Exclude from copy</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              @for (collection of collections; track collection.name) {\r\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-collection]=\"collection.name\">\r\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                    {{ collection.label }}\r\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ collection.name }}</code>\r\n                    @if (!collection.copyable) {\r\n                      <!-- Shown disabled with the reason, rather than hidden: the server refuses a set flag on it. -->\r\n                      <span\r\n                        class=\"cws:ml-1 cws:text-xs cws:text-slate-400\"\r\n                        [id]=\"'collection-not-copied-' + collection.name\"\r\n                      >\r\n                        — CTRM does not accept this on a write, so a copy never carries it.\r\n                      </span>\r\n                    }\r\n                  </th>\r\n                  <td class=\"cws:px-2 cws:py-1.5\">\r\n                    <input\r\n                      type=\"checkbox\"\r\n                      [checked]=\"collection.excludeFromCopy\"\r\n                      [disabled]=\"!collection.copyable\"\r\n                      (change)=\"setCollectionExcluded(collection.name, $any($event.target).checked)\"\r\n                      [attr.aria-label]=\"'Exclude the ' + collection.name + ' collection from copy'\"\r\n                      [attr.aria-describedby]=\"collection.copyable ? null : 'collection-not-copied-' + collection.name\"\r\n                    />\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    <!--\r\n      #1006 (ruled 2026-10-21, option (a)): one row per CTRM remark type, each with Visible and Required.\r\n      Rendered only when the registry offers remark types (#1022), so a server without it shows nothing\r\n      here rather than an error. Required ticks Visible and locks it, as it does for a field.\r\n    -->\r\n    @if (remarkRows(); as remarks) {\r\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-remark-types>\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Remarks</h4>\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Which remark types the record screen offers, and which must be filled in before a contract\r\n          can be saved. A hidden type's stored remark is kept: it is only not shown for editing.\r\n        </p>\r\n\r\n        <div class=\"cws:overflow-x-auto\">\r\n          <table class=\"cws:w-full cws:text-sm\">\r\n            <caption class=\"sr-only\">Remark type settings</caption>\r\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n              <tr>\r\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Remark type</th>\r\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\r\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              @for (remark of remarks; track remark.code) {\r\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-remark-type]=\"remark.code\">\r\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                    {{ remark.label }}\r\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ remark.code }}</code>\r\n                  </th>\r\n                  <td class=\"cws:px-2 cws:py-1.5\">\r\n                    <input\r\n                      type=\"checkbox\"\r\n                      [checked]=\"remark.visible\"\r\n                      [disabled]=\"remark.required\"\r\n                      (change)=\"setRemarkFlag(remark.code, 'visible', $any($event.target).checked)\"\r\n                      [attr.aria-label]=\"remark.label + ' remark visible'\"\r\n                    />\r\n                  </td>\r\n                  <td class=\"cws:px-2 cws:py-1.5\">\r\n                    <input\r\n                      type=\"checkbox\"\r\n                      [checked]=\"remark.required\"\r\n                      (change)=\"setRemarkFlag(remark.code, 'required', $any($event.target).checked)\"\r\n                      [attr.aria-label]=\"remark.label + ' remark required'\"\r\n                    />\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (columnsNotKept()) {\r\n      <!--\r\n        #748: the row WAS saved; only the column list was not kept. Saving again would repeat the\r\n        save, so the only action offered is to close, and the list has to wait for #747.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-columns-not-kept>\r\n        <div class=\"scoular-alert-title\">Saved, except the home grid columns</div>\r\n        <div class=\"scoular-alert-description\">\r\n          The rest of this configuration was saved. The server did not keep the column list, because it\r\n          cannot store one yet, so this trade unit's grid still shows every column.\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (everyTradeUnitPending()) {\r\n      <!--\r\n        #844: a row for every trade unit takes a second, deliberate click. The Dev walk made one by\r\n        mistake with a seed set, so the seed is named: seeding copies settings, it does not pick the\r\n        trade unit the row applies to.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-every-trade-unit>\r\n        <div class=\"scoular-alert-title\">This configuration applies to every trade unit</div>\r\n        <div class=\"scoular-alert-description cws:space-y-2\">\r\n          <p>\r\n            @if (seededFrom(); as seed) {\r\n              Its settings are copied from trade unit {{ seed.tradeUnit }}, but it applies to every trade unit.\r\n            }\r\n            \"Applies to trade unit\" is set to any trade unit, so from its effective date this row is used\r\n            for every trade unit that has no more specific row of its own. To configure one trade unit,\r\n            pick it under \"Applies to trade unit\".\r\n          </p>\r\n          <div class=\"cws:flex cws:flex-wrap cws:gap-3\">\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"saving()\" (click)=\"save(true)\">\r\n              {{ isNew() ? 'Create for every trade unit' : 'Save for every trade unit' }}\r\n            </button>\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"everyTradeUnitPending.set(false)\">\r\n              Go back\r\n            </button>\r\n          </div>\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n      @if (columnsNotKept()) {\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"saved.emit()\">\r\n          Close\r\n        </button>\r\n      }\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary\"\r\n        [class.cws:hidden]=\"columnsNotKept()\"\r\n        [disabled]=\"saving() || columnsNotKept()\"\r\n        (click)=\"save()\"\r\n      >\r\n        {{ saving() ? 'Saving…' : isNew() ? 'Create configuration' : 'Save changes' }}\r\n      </button>\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-secondary\"\r\n        (click)=\"cancel()\"\r\n      >\r\n        Cancel\r\n      </button>\r\n    </div>\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		editing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editing",
				required: false
			}]
		}],
		saved: [{
			type: i0.Output,
			args: ["saved"]
		}],
		cancelled: [{
			type: i0.Output,
			args: ["cancelled"]
		}]
	}
});
function rowRef(element, fieldAttribute, sectionAttribute) {
	const field = element.getAttribute(fieldAttribute);
	const section = element.getAttribute(sectionAttribute);
	return field === null || section === null || field === "" || section === "" ? null : {
		field,
		section
	};
}
function visibilityOf(sections) {
	const map = {};
	for (const section of sections) map[section.id] = section.visible;
	return map;
}
function sectionsOf(resolved, layout) {
	return resolved.map((section, index) => ({
		id: section.componentName,
		label: section.label,
		tab: section.tab,
		order: layout.find((known) => known.id === section.componentName)?.order ?? index + 1,
		visible: section.visible
	}));
}
function withSectionTabs(tabs, sections, layoutTabs) {
	const missing = layoutTabs.filter((tab) => !tabs.some((known) => known.id === tab.id) && sections.some((section) => section.tab === tab.id));
	return missing.length === 0 ? tabs : [...tabs, ...missing];
}
var FormConfigAdminPageComponent = class FormConfigAdminPageComponent {
	source = inject(FORM_CONFIG_ADMIN_SOURCE);
	view = input("all", {
		...ngDevMode ? { debugName: "view" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "all"
	});
	showRows = computed(() => this.view() !== "preview", ...ngDevMode ? [{ debugName: "showRows" }] : /* istanbul ignore next */ []);
	showPreview = computed(() => this.view() !== "rows", ...ngDevMode ? [{ debugName: "showPreview" }] : /* istanbul ignore next */ []);
	routed = computed(() => this.view() !== "all", ...ngDevMode ? [{ debugName: "routed" }] : /* istanbul ignore next */ []);
	area = adminArea("form-configuration");
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	listState = signal(remoteLoading(), ...ngDevMode ? [{ debugName: "listState" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.value.rows : [];
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	storeOrigin = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.value.storeOrigin : null;
	}, ...ngDevMode ? [{ debugName: "storeOrigin" }] : /* istanbul ignore next */ []);
	notDurable = computed(() => this.storeOrigin() === "InMemory", ...ngDevMode ? [{ debugName: "notDurable" }] : /* istanbul ignore next */ []);
	previewType = "";
	previewLocation = "";
	previewCommodity = "";
	previewContract = "";
	previewState = signal(null, ...ngDevMode ? [{ debugName: "previewState" }] : /* istanbul ignore next */ []);
	preview = computed(() => {
		const state = this.previewState();
		return state !== null && state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []);
	previewProvenance = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return null;
		const { provenance } = resolved;
		if (provenance.configId === null) return "No configuration row matched. The form falls back to the built-in defaults generated from the field layout — correct and safe, but nothing an administrator has configured applies.";
		const matched = provenance.matchedDimensions.length === 0 ? "the global default row (no dimensions pinned)" : `matched on ${provenance.matchedDimensions.map(dimensionLabel).join(" and ")}`;
		return `Configuration #${provenance.configId}, version ${provenance.version}, ${matched}. Effective from ${provenance.effectiveFrom}, served from ${provenance.source}.`;
	}, ...ngDevMode ? [{ debugName: "previewProvenance" }] : /* istanbul ignore next */ []);
	previewRequired = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return [];
		return resolved.config.sections.flatMap((section) => section.fields.filter((field) => field.behaviour.required).map((field) => field.label));
	}, ...ngDevMode ? [{ debugName: "previewRequired" }] : /* istanbul ignore next */ []);
	previewHidden = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return [];
		return resolved.config.sections.flatMap((section) => section.fields.filter((field) => !field.behaviour.visible).map((field) => field.label));
	}, ...ngDevMode ? [{ debugName: "previewHidden" }] : /* istanbul ignore next */ []);
	previewTabs = computed(() => {
		const resolved = this.preview()?.config;
		return tabsAfterCascade(resolved?.tabs ?? [], resolved?.sections ?? []).map((tab) => tab.label);
	}, ...ngDevMode ? [{ debugName: "previewTabs" }] : /* istanbul ignore next */ []);
	auditRowId = signal(null, ...ngDevMode ? [{ debugName: "auditRowId" }] : /* istanbul ignore next */ []);
	auditState = signal(remoteLoading(), ...ngDevMode ? [{ debugName: "auditState" }] : /* istanbul ignore next */ []);
	auditError = computed(() => {
		const state = this.auditState();
		return state.status === "error" ? state.error.message : "";
	}, ...ngDevMode ? [{ debugName: "auditError" }] : /* istanbul ignore next */ []);
	auditPartial = computed(() => {
		const state = this.auditState();
		return state.status === "loaded" && state.value.partial === true;
	}, ...ngDevMode ? [{ debugName: "auditPartial" }] : /* istanbul ignore next */ []);
	auditEntries = computed(() => {
		const state = this.auditState();
		if (state.status !== "loaded") return [];
		const entries = state.value.entries;
		return entries.map((entry, index) => ({
			entry,
			isOldest: index === 0,
			changes: diffConfigDocuments(index === 0 ? null : parseSnapshot(entries[index - 1].configJsonSnapshot), parseSnapshot(entry.configJsonSnapshot) ?? EMPTY_DOCUMENT)
		})).reverse();
	}, ...ngDevMode ? [{ debugName: "auditEntries" }] : /* istanbul ignore next */ []);
	toggleAudit(row) {
		if (this.auditRowId() === row.id) {
			this.auditRowId.set(null);
			return;
		}
		this.auditRowId.set(row.id);
		this.auditState.set(remoteLoading());
		this.source.auditTrail(row.id).subscribe((state) => this.auditState.set(state));
	}
	editorState = signal("closed", ...ngDevMode ? [{ debugName: "editorState" }] : /* istanbul ignore next */ []);
	editorOpen = computed(() => this.editorState() !== "closed", ...ngDevMode ? [{ debugName: "editorOpen" }] : /* istanbul ignore next */ []);
	editingRow = computed(() => {
		const state = this.editorState();
		return state === "closed" || state === "new" ? null : state;
	}, ...ngDevMode ? [{ debugName: "editingRow" }] : /* istanbul ignore next */ []);
	loadingEditor = signal(false, ...ngDevMode ? [{ debugName: "loadingEditor" }] : /* istanbul ignore next */ []);
	rowActions = computed(() => {
		const open = this.auditRowId();
		return new Map(this.rows().map((row) => {
			const actions = [];
			if (row.isActive) actions.push({
				label: "Edit",
				run: (target) => this.edit(target),
				disabled: () => this.loadingEditor() ? "Opening a row" : false
			}, {
				label: "Deactivate",
				run: (target) => this.deactivate(target)
			});
			actions.push({
				label: open === row.id ? "Hide history" : "History",
				run: (target) => this.toggleAudit(target)
			});
			return [row.id, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "rowActions" }] : /* istanbul ignore next */ []);
	startNew() {
		this.editorState.set("new");
	}
	edit(row) {
		this.loadingEditor.set(true);
		this.source.get(row.id).subscribe((state) => {
			if (state.status === "loaded") {
				this.loadingEditor.set(false);
				this.editorState.set(state.value);
			} else if (state.status === "error") {
				this.loadingEditor.set(false);
				this.listState.set(state);
			}
		});
	}
	closeEditor() {
		this.editorState.set("closed");
	}
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	onSaved() {
		this.outcome.set(mutationSucceeded("Configuration saved. The list below is read again from the server."));
		this.editorState.set("closed");
		this.previewState.set(null);
		this.reload();
	}
	constructor() {
		this.reload();
	}
	reload() {
		this.attempt.update((attempt) => attempt + 1);
		this.source.list().subscribe((state) => this.listState.set(state));
	}
	runPreview() {
		this.previewState.set(remoteLoading());
		this.source.preview({
			...this.previewContract !== "" ? { contractNumber: this.previewContract } : {},
			...this.previewContract === "" ? {
				...this.previewType !== "" ? { contractTypeClass: this.previewType } : {},
				...this.previewLocation !== "" ? { locationCode: this.previewLocation } : {},
				...this.previewCommodity !== "" ? { commodityCode: this.previewCommodity } : {}
			} : {}
		}).subscribe((state) => this.previewState.set(state));
	}
	deactivate(row) {
		this.outcome.set(null);
		this.source.deactivate(row.id, row.rowVersion).subscribe((state) => {
			if (state.status === "loaded") {
				this.outcome.set(mutationSucceeded(`Configuration ${row.id} deactivated.`));
				this.reload();
				return;
			}
			if (state.status === "error") this.outcome.set(mutationFailed(state.error));
		});
	}
	dimension(value) {
		return value === null || value === "" ? "Any" : value;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: FormConfigAdminPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: FormConfigAdminPageComponent,
		isStandalone: true,
		selector: "cms-form-config-admin-page",
		inputs: { view: {
			classPropertyName: "view",
			publicName: "view",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		ngImport: i0,
		template: "<section class=\"cws:space-y-6\">\r\n  <!--\r\n    #825: the title, one sentence, and the page's primary action. The rules that used to follow in the\r\n    description, and the soft-delete note under the table, are behind \"How configuration resolves\":\r\n    they explain the page rather than change a decision on it.\r\n  -->\r\n  <cms-page-header\r\n    title=\"Form configuration\"\r\n    description=\"Which fields the contract record shows and requires, and which tabs it has, per contract type, trade unit and commodity.\"\r\n  >\r\n    @if (showRows() && !editorOpen()) {\r\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"startNew()\">\r\n        New configuration\r\n      </button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  <details class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n    <summary class=\"cws:cursor-pointer cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\r\n      How configuration resolves\r\n    </summary>\r\n    <div class=\"cws:mt-2 cws:space-y-2\">\r\n      <p>\r\n        The most specific match wins, and the whole configuration applies, with no merging between rows.\r\n        A blank dimension means <em>any</em>.\r\n      </p>\r\n      <p>\r\n        Deactivating is a soft delete: the row stops resolving and frees its dimensions for a replacement,\r\n        and every change is kept in the configuration audit trail with who made it.\r\n      </p>\r\n    </div>\r\n  </details>\r\n\r\n  @if (routed()) {\r\n    <cws-admin-tabs [views]=\"area.views\" label=\"Form configuration views\" />\r\n  }\r\n\r\n  @if (notDurable()) {\r\n    <!--\r\n      Said out loud rather than assumed. No deployed environment has a configuration database\r\n      connection string yet, so the honest answer is usually \"in memory\" — and an admin whose saved\r\n      configuration vanishes on the next restart, without having been told, is owed an explanation\r\n      nobody can give them afterwards.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Configuration is not being stored durably</div>\r\n      <div class=\"scoular-alert-description\">\r\n        This environment has no configuration database configured, so rows are held in memory and are\r\n        lost when the application restarts. Resolution, validation and the audit trail all behave\r\n        exactly as they will against a database — only the persistence is missing.\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  @if (editorOpen()) {\r\n    <!--\r\n      The editor replaces the page body while it is open, rather than sitting below the list.\r\n\r\n      A form this long beneath a table means the admin loses track of which row they are changing —\r\n      and the preview tool above it would be showing a resolution that predates their unsaved edits,\r\n      which is worse than showing nothing.\r\n    -->\r\n    <cms-form-config-editor\r\n      [editing]=\"editingRow()\"\r\n      (saved)=\"onSaved()\"\r\n      (cancelled)=\"closeEditor()\"\r\n    />\r\n  } @else {\r\n\r\n  <!--\r\n    🔑 THE PREVIEW TOOL — first on the page, ahead of the list, on purpose.\r\n\r\n    The question an admin actually arrives with is \"given a contract like THIS, what will the form\r\n    do?\", and the ranking rules are hard to hold in your head once a dozen rows exist. The list\r\n    answers \"what rows are there\"; this answers the question.\r\n\r\n    It calls the same `resolve` endpoint the record screen calls, so it cannot disagree with\r\n    production — a preview with its own copy of the ranking rules would be a second answer to\r\n    \"which configuration wins\".\r\n  -->\r\n  @if (showPreview()) {\r\n  <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n    <div class=\"cws:space-y-1\">\r\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview a resolution</h3>\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Which configuration a contract like this gets. Leave a box empty to mean <em>any</em>.\r\n      </p>\r\n      <details class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <summary class=\"cws:cursor-pointer\">Why give a contract number?</summary>\r\n        <p class=\"cws:mt-1\">\r\n          The server derives all three dimensions from the contract itself, which is the only way to get\r\n          the contract type right: CTRM derives it and does not accept it on a write.\r\n        </p>\r\n      </details>\r\n    </div>\r\n\r\n    <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type class</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewType\"\r\n          placeholder=\"e.g. BCO - English\"\r\n          [(ngModel)]=\"previewType\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Trade unit</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewLocation\"\r\n          placeholder=\"e.g. 0210\"\r\n          [(ngModel)]=\"previewLocation\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewCommodity\"\r\n          placeholder=\"e.g. YC\"\r\n          [(ngModel)]=\"previewCommodity\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n          Or a contract number\r\n        </span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewContract\"\r\n          placeholder=\"e.g. SC1240000\"\r\n          [(ngModel)]=\"previewContract\"\r\n        />\r\n      </label>\r\n    </div>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"runPreview()\">\r\n      Resolve\r\n    </button>\r\n\r\n    @if (previewProvenance() !== null) {\r\n      <div class=\"cws:space-y-3 cws:border-t cws:border-slate-200 cws:pt-4 cws:dark:border-slate-700\">\r\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\" data-testid=\"preview-provenance\">\r\n          {{ previewProvenance() }}\r\n        </p>\r\n\r\n        <dl class=\"cws:grid cws:gap-3 cws:text-sm cws:sm:grid-cols-3\">\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Tabs</dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-tabs\">\r\n              {{ previewTabs().length > 0 ? previewTabs().join(', ') : '—' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Required fields ({{ previewRequired().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-required\">\r\n              {{ previewRequired().length > 0 ? previewRequired().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Hidden fields ({{ previewHidden().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-hidden\">\r\n              {{ previewHidden().length > 0 ? previewHidden().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n        </dl>\r\n\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Auto-calculation: {{ preview()?.tradeUnitAttributes.autoCalculationMode }} · Pending\r\n          contracts:\r\n          {{ preview()?.tradeUnitAttributes.pendingContractsEnabled ? 'enabled' : 'disabled' }}\r\n        </p>\r\n      </div>\r\n    }\r\n  </div>\r\n  }\r\n\r\n  @if (showRows()) {\r\n  <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Configuration rows</h3>\r\n\r\n  <!-- #803: the last save or deactivate, with the server's reference on a failure. -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\r\n  </cms-status-message>\r\n\r\n  <cms-async-container\r\n    [data]=\"listState()\"\r\n    [empty]=\"rows().length === 0\"\r\n    emptyMessage=\"No configuration rows exist yet, so every contract resolves to the built-in defaults generated from the field layout.\"\r\n    loadingLabel=\"Loading form configuration\"\r\n    (retry)=\"reload()\"\r\n  >\r\n    <div class=\"scoular-card cws:overflow-x-auto\">\r\n      <table class=\"cws:w-full cws:text-sm\">\r\n        <caption class=\"sr-only\">Form configuration rows</caption>\r\n        <thead class=\"cws:border-b cws:border-slate-200 cws:text-left cws:dark:border-slate-700\">\r\n          <tr>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Contract type</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Trade unit</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Commodity</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Effective from</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Version</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Status</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Last changed</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">\r\n              <span class=\"sr-only\">Actions</span>\r\n            </th>\r\n          </tr>\r\n        </thead>\r\n        <tbody>\r\n          @for (row of rows(); track row.id) {\r\n            <tr class=\"cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\">\r\n              <!--\r\n                `Any` rather than a blank cell. A null dimension means \"this row applies to every\r\n                contract type\", and an empty cell reads as missing data — the opposite of what it says.\r\n              -->\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.contractTypeClass) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.locationCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.commodityCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.effectiveFrom }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.version }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                @if (row.isActive) {\r\n                  <span class=\"cws:text-emerald-700 cws:dark:text-emerald-400\">Active</span>\r\n                } @else {\r\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Deactivated</span>\r\n                }\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                {{ row.modifiedByUpn }}\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:text-right\">\r\n                <!--\r\n                  #825: Edit, Deactivate and History behind the row's menu (they were three inline\r\n                  buttons). History is on deactivated rows too (F8.6): the audit outlives its subject.\r\n                -->\r\n                <cms-row-menu\r\n                  [row]=\"row\"\r\n                  [actions]=\"rowActions().get(row.id) ?? []\"\r\n                  [label]=\"'Actions for configuration ' + row.id\"\r\n                />\r\n              </td>\r\n            </tr>\r\n\r\n            @if (auditRowId() === row.id) {\r\n              <tr>\r\n                <!-- All eight columns. It said 7, leaving the actions column of the row beside it. -->\r\n                <td colspan=\"8\" class=\"cws:bg-slate-50 cws:px-3 cws:py-3 cws:dark:bg-slate-900/40\">\r\n                  @switch (auditState().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading history…</p>\r\n                    }\r\n                    @case ('error') {\r\n                      <p class=\"cws:text-xs cws:text-rose-700 cws:dark:text-rose-400\" role=\"alert\">\r\n                        {{ auditError() }}\r\n                      </p>\r\n                    }\r\n                    @default {\r\n                      <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        Newest first. Each entry lists what changed against the entry before it —\r\n                        the stored snapshots are full documents, so this is derived, not a second\r\n                        record.\r\n                      </p>\r\n\r\n                      @if (auditPartial()) {\r\n                        <!-- #700: entries from trade units this account does not manage are left out, so the\r\n                             oldest entry shown changed something the screen does not show. -->\r\n                        <p class=\"cws:mb-2 cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-900 cws:dark:bg-amber-950 cws:dark:text-amber-200\" role=\"note\" data-audit-partial>\r\n                          Scoped to your trade units: some earlier history is not shown, because it was made while\r\n                          this row belonged to a trade unit you do not manage.\r\n                        </p>\r\n                      }\r\n\r\n                      @for (item of auditEntries(); track item.entry.auditId) {\r\n                        <details class=\"cws:mb-1 cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\r\n                          <summary\r\n                            class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-xs\"\r\n                            [attr.data-testid]=\"'audit-summary-' + item.entry.auditId\"\r\n                          >\r\n                            <span class=\"cws:font-medium\">{{ item.entry.changeType }}</span>\r\n                            · v{{ item.entry.version }}\r\n                            · {{ item.entry.timestampUtc }}\r\n                            · {{ item.entry.actorUpn }}\r\n                            <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              @if (item.isOldest) {\r\n                                — the oldest entry held; nothing before it to compare\r\n                              } @else if (item.changes.length === 0) {\r\n                                — no field changed\r\n                              } @else {\r\n                                — {{ item.changes.length }}\r\n                                {{ item.changes.length === 1 ? 'change' : 'changes' }}\r\n                              }\r\n                            </span>\r\n                          </summary>\r\n\r\n                          @if (item.changes.length > 0) {\r\n                            <ul\r\n                              class=\"cws:space-y-1 cws:px-4 cws:pb-3 cws:pt-1 cws:text-xs\"\r\n                              [attr.data-testid]=\"'audit-changes-' + item.entry.auditId\"\r\n                            >\r\n                              @for (change of item.changes; track change.scope + change.subject + change.property) {\r\n                                <li>\r\n                                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">{{ change.scope }}</span>\r\n                                  <span class=\"cws:font-medium\">{{ change.subject }}</span>\r\n                                  @if (change.property !== '') {\r\n                                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">·{{ change.property }}</span>\r\n                                  }\r\n                                  @if (change.before !== '' && change.after !== '') {\r\n                                    : {{ change.before }} → {{ change.after }}\r\n                                  }\r\n                                </li>\r\n                              }\r\n                            </ul>\r\n                          }\r\n                        </details>\r\n                      } @empty {\r\n                        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          No history recorded for this row.\r\n                        </p>\r\n                      }\r\n                    }\r\n                  }\r\n                </td>\r\n              </tr>\r\n            }\r\n          }\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n  </cms-async-container>\r\n  }\r\n\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: FormConfigEditorComponent,
				selector: "cms-form-config-editor",
				inputs: ["editing"],
				outputs: ["saved", "cancelled"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: FormConfigAdminPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-config-admin-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AdminTabsComponent,
				AsyncContainerComponent,
				FormsModule,
				FormConfigEditorComponent,
				PageHeaderComponent,
				RowMenuComponent,
				StatusMessageComponent
			],
			template: "<section class=\"cws:space-y-6\">\r\n  <!--\r\n    #825: the title, one sentence, and the page's primary action. The rules that used to follow in the\r\n    description, and the soft-delete note under the table, are behind \"How configuration resolves\":\r\n    they explain the page rather than change a decision on it.\r\n  -->\r\n  <cms-page-header\r\n    title=\"Form configuration\"\r\n    description=\"Which fields the contract record shows and requires, and which tabs it has, per contract type, trade unit and commodity.\"\r\n  >\r\n    @if (showRows() && !editorOpen()) {\r\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"startNew()\">\r\n        New configuration\r\n      </button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  <details class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n    <summary class=\"cws:cursor-pointer cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\r\n      How configuration resolves\r\n    </summary>\r\n    <div class=\"cws:mt-2 cws:space-y-2\">\r\n      <p>\r\n        The most specific match wins, and the whole configuration applies, with no merging between rows.\r\n        A blank dimension means <em>any</em>.\r\n      </p>\r\n      <p>\r\n        Deactivating is a soft delete: the row stops resolving and frees its dimensions for a replacement,\r\n        and every change is kept in the configuration audit trail with who made it.\r\n      </p>\r\n    </div>\r\n  </details>\r\n\r\n  @if (routed()) {\r\n    <cws-admin-tabs [views]=\"area.views\" label=\"Form configuration views\" />\r\n  }\r\n\r\n  @if (notDurable()) {\r\n    <!--\r\n      Said out loud rather than assumed. No deployed environment has a configuration database\r\n      connection string yet, so the honest answer is usually \"in memory\" — and an admin whose saved\r\n      configuration vanishes on the next restart, without having been told, is owed an explanation\r\n      nobody can give them afterwards.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Configuration is not being stored durably</div>\r\n      <div class=\"scoular-alert-description\">\r\n        This environment has no configuration database configured, so rows are held in memory and are\r\n        lost when the application restarts. Resolution, validation and the audit trail all behave\r\n        exactly as they will against a database — only the persistence is missing.\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  @if (editorOpen()) {\r\n    <!--\r\n      The editor replaces the page body while it is open, rather than sitting below the list.\r\n\r\n      A form this long beneath a table means the admin loses track of which row they are changing —\r\n      and the preview tool above it would be showing a resolution that predates their unsaved edits,\r\n      which is worse than showing nothing.\r\n    -->\r\n    <cms-form-config-editor\r\n      [editing]=\"editingRow()\"\r\n      (saved)=\"onSaved()\"\r\n      (cancelled)=\"closeEditor()\"\r\n    />\r\n  } @else {\r\n\r\n  <!--\r\n    🔑 THE PREVIEW TOOL — first on the page, ahead of the list, on purpose.\r\n\r\n    The question an admin actually arrives with is \"given a contract like THIS, what will the form\r\n    do?\", and the ranking rules are hard to hold in your head once a dozen rows exist. The list\r\n    answers \"what rows are there\"; this answers the question.\r\n\r\n    It calls the same `resolve` endpoint the record screen calls, so it cannot disagree with\r\n    production — a preview with its own copy of the ranking rules would be a second answer to\r\n    \"which configuration wins\".\r\n  -->\r\n  @if (showPreview()) {\r\n  <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n    <div class=\"cws:space-y-1\">\r\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview a resolution</h3>\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Which configuration a contract like this gets. Leave a box empty to mean <em>any</em>.\r\n      </p>\r\n      <details class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <summary class=\"cws:cursor-pointer\">Why give a contract number?</summary>\r\n        <p class=\"cws:mt-1\">\r\n          The server derives all three dimensions from the contract itself, which is the only way to get\r\n          the contract type right: CTRM derives it and does not accept it on a write.\r\n        </p>\r\n      </details>\r\n    </div>\r\n\r\n    <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type class</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewType\"\r\n          placeholder=\"e.g. BCO - English\"\r\n          [(ngModel)]=\"previewType\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Trade unit</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewLocation\"\r\n          placeholder=\"e.g. 0210\"\r\n          [(ngModel)]=\"previewLocation\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewCommodity\"\r\n          placeholder=\"e.g. YC\"\r\n          [(ngModel)]=\"previewCommodity\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n          Or a contract number\r\n        </span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewContract\"\r\n          placeholder=\"e.g. SC1240000\"\r\n          [(ngModel)]=\"previewContract\"\r\n        />\r\n      </label>\r\n    </div>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"runPreview()\">\r\n      Resolve\r\n    </button>\r\n\r\n    @if (previewProvenance() !== null) {\r\n      <div class=\"cws:space-y-3 cws:border-t cws:border-slate-200 cws:pt-4 cws:dark:border-slate-700\">\r\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\" data-testid=\"preview-provenance\">\r\n          {{ previewProvenance() }}\r\n        </p>\r\n\r\n        <dl class=\"cws:grid cws:gap-3 cws:text-sm cws:sm:grid-cols-3\">\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Tabs</dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-tabs\">\r\n              {{ previewTabs().length > 0 ? previewTabs().join(', ') : '—' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Required fields ({{ previewRequired().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-required\">\r\n              {{ previewRequired().length > 0 ? previewRequired().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Hidden fields ({{ previewHidden().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-hidden\">\r\n              {{ previewHidden().length > 0 ? previewHidden().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n        </dl>\r\n\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Auto-calculation: {{ preview()?.tradeUnitAttributes.autoCalculationMode }} · Pending\r\n          contracts:\r\n          {{ preview()?.tradeUnitAttributes.pendingContractsEnabled ? 'enabled' : 'disabled' }}\r\n        </p>\r\n      </div>\r\n    }\r\n  </div>\r\n  }\r\n\r\n  @if (showRows()) {\r\n  <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Configuration rows</h3>\r\n\r\n  <!-- #803: the last save or deactivate, with the server's reference on a failure. -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\r\n  </cms-status-message>\r\n\r\n  <cms-async-container\r\n    [data]=\"listState()\"\r\n    [empty]=\"rows().length === 0\"\r\n    emptyMessage=\"No configuration rows exist yet, so every contract resolves to the built-in defaults generated from the field layout.\"\r\n    loadingLabel=\"Loading form configuration\"\r\n    (retry)=\"reload()\"\r\n  >\r\n    <div class=\"scoular-card cws:overflow-x-auto\">\r\n      <table class=\"cws:w-full cws:text-sm\">\r\n        <caption class=\"sr-only\">Form configuration rows</caption>\r\n        <thead class=\"cws:border-b cws:border-slate-200 cws:text-left cws:dark:border-slate-700\">\r\n          <tr>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Contract type</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Trade unit</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Commodity</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Effective from</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Version</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Status</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Last changed</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">\r\n              <span class=\"sr-only\">Actions</span>\r\n            </th>\r\n          </tr>\r\n        </thead>\r\n        <tbody>\r\n          @for (row of rows(); track row.id) {\r\n            <tr class=\"cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\">\r\n              <!--\r\n                `Any` rather than a blank cell. A null dimension means \"this row applies to every\r\n                contract type\", and an empty cell reads as missing data — the opposite of what it says.\r\n              -->\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.contractTypeClass) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.locationCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.commodityCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.effectiveFrom }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.version }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                @if (row.isActive) {\r\n                  <span class=\"cws:text-emerald-700 cws:dark:text-emerald-400\">Active</span>\r\n                } @else {\r\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Deactivated</span>\r\n                }\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                {{ row.modifiedByUpn }}\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:text-right\">\r\n                <!--\r\n                  #825: Edit, Deactivate and History behind the row's menu (they were three inline\r\n                  buttons). History is on deactivated rows too (F8.6): the audit outlives its subject.\r\n                -->\r\n                <cms-row-menu\r\n                  [row]=\"row\"\r\n                  [actions]=\"rowActions().get(row.id) ?? []\"\r\n                  [label]=\"'Actions for configuration ' + row.id\"\r\n                />\r\n              </td>\r\n            </tr>\r\n\r\n            @if (auditRowId() === row.id) {\r\n              <tr>\r\n                <!-- All eight columns. It said 7, leaving the actions column of the row beside it. -->\r\n                <td colspan=\"8\" class=\"cws:bg-slate-50 cws:px-3 cws:py-3 cws:dark:bg-slate-900/40\">\r\n                  @switch (auditState().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading history…</p>\r\n                    }\r\n                    @case ('error') {\r\n                      <p class=\"cws:text-xs cws:text-rose-700 cws:dark:text-rose-400\" role=\"alert\">\r\n                        {{ auditError() }}\r\n                      </p>\r\n                    }\r\n                    @default {\r\n                      <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        Newest first. Each entry lists what changed against the entry before it —\r\n                        the stored snapshots are full documents, so this is derived, not a second\r\n                        record.\r\n                      </p>\r\n\r\n                      @if (auditPartial()) {\r\n                        <!-- #700: entries from trade units this account does not manage are left out, so the\r\n                             oldest entry shown changed something the screen does not show. -->\r\n                        <p class=\"cws:mb-2 cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-900 cws:dark:bg-amber-950 cws:dark:text-amber-200\" role=\"note\" data-audit-partial>\r\n                          Scoped to your trade units: some earlier history is not shown, because it was made while\r\n                          this row belonged to a trade unit you do not manage.\r\n                        </p>\r\n                      }\r\n\r\n                      @for (item of auditEntries(); track item.entry.auditId) {\r\n                        <details class=\"cws:mb-1 cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\r\n                          <summary\r\n                            class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-xs\"\r\n                            [attr.data-testid]=\"'audit-summary-' + item.entry.auditId\"\r\n                          >\r\n                            <span class=\"cws:font-medium\">{{ item.entry.changeType }}</span>\r\n                            · v{{ item.entry.version }}\r\n                            · {{ item.entry.timestampUtc }}\r\n                            · {{ item.entry.actorUpn }}\r\n                            <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              @if (item.isOldest) {\r\n                                — the oldest entry held; nothing before it to compare\r\n                              } @else if (item.changes.length === 0) {\r\n                                — no field changed\r\n                              } @else {\r\n                                — {{ item.changes.length }}\r\n                                {{ item.changes.length === 1 ? 'change' : 'changes' }}\r\n                              }\r\n                            </span>\r\n                          </summary>\r\n\r\n                          @if (item.changes.length > 0) {\r\n                            <ul\r\n                              class=\"cws:space-y-1 cws:px-4 cws:pb-3 cws:pt-1 cws:text-xs\"\r\n                              [attr.data-testid]=\"'audit-changes-' + item.entry.auditId\"\r\n                            >\r\n                              @for (change of item.changes; track change.scope + change.subject + change.property) {\r\n                                <li>\r\n                                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">{{ change.scope }}</span>\r\n                                  <span class=\"cws:font-medium\">{{ change.subject }}</span>\r\n                                  @if (change.property !== '') {\r\n                                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">·{{ change.property }}</span>\r\n                                  }\r\n                                  @if (change.before !== '' && change.after !== '') {\r\n                                    : {{ change.before }} → {{ change.after }}\r\n                                  }\r\n                                </li>\r\n                              }\r\n                            </ul>\r\n                          }\r\n                        </details>\r\n                      } @empty {\r\n                        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          No history recorded for this row.\r\n                        </p>\r\n                      }\r\n                    }\r\n                  }\r\n                </td>\r\n              </tr>\r\n            }\r\n          }\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n  </cms-async-container>\r\n  }\r\n\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { view: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "view",
			required: false
		}]
	}] }
});
function dimensionLabel(dimension) {
	switch (dimension) {
		case "contractTypeClass": return "contract type";
		case "locationCode": return "location";
		case "commodityCode": return "commodity";
		default: return dimension;
	}
}
const EMPTY_DOCUMENT = {
	schemaVersion: 0,
	tabs: [],
	sections: [],
	fields: {},
	attributes: {
		autoCalculationMode: "",
		pendingContractsEnabled: false
	}
};
function parseSnapshot(json) {
	try {
		return JSON.parse(json);
	} catch {
		return null;
	}
}
var RolesPageComponent = class RolesPageComponent {
	view = input("all", {
		...ngDevMode ? { debugName: "view" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "all"
	});
	showPermissions = computed(() => this.view() === "all" || this.view() === "permissions", ...ngDevMode ? [{ debugName: "showPermissions" }] : /* istanbul ignore next */ []);
	showRoles = computed(() => this.view() === "all" || this.view() === "roles", ...ngDevMode ? [{ debugName: "showRoles" }] : /* istanbul ignore next */ []);
	showAssignments = computed(() => this.view() === "all" || this.view() === "assignments", ...ngDevMode ? [{ debugName: "showAssignments" }] : /* istanbul ignore next */ []);
	routed = computed(() => this.view() !== "all", ...ngDevMode ? [{ debugName: "routed" }] : /* istanbul ignore next */ []);
	area = adminArea("roles");
	access = inject(AdminScope, { optional: true });
	refused = computed(() => this.access?.knownNotAdmin() ?? false, ...ngDevMode ? [{ debugName: "refused" }] : /* istanbul ignore next */ []);
	roleActions = computed(() => {
		const busy = this.roleBusy();
		return new Map(this.roleRows().map((role) => {
			const refusal = () => this.systemReason(role) ?? (busy ? "A role change is in progress" : false);
			const actions = [{
				label: "Edit",
				run: (row) => this.editRole(row),
				disabled: refusal
			}, {
				label: "Delete",
				run: (row) => this.deleteRole(row),
				disabled: refusal
			}];
			return [role.id, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "roleActions" }] : /* istanbul ignore next */ []);
	assignmentKey(row) {
		return `${row.userObjectId}|${row.roleId}|${row.tradeUnit}`;
	}
	assignmentActions = computed(() => {
		const refusal = () => this.assignmentBusy() ? "An assignment change is in progress" : false;
		return new Map(this.assignments().map((assignment) => {
			const actions = [];
			if (!assignment.isDefault) actions.push({
				label: "Make default",
				run: (row) => this.setDefault(row),
				disabled: refusal
			});
			actions.push({
				label: "Revoke",
				run: (row) => this.revoke(row),
				disabled: refusal
			});
			return [this.assignmentKey(assignment), actions];
		}));
	}, ...ngDevMode ? [{ debugName: "assignmentActions" }] : /* istanbul ignore next */ []);
	catalogSource = inject(PERMISSION_CATALOG_SOURCE, { optional: true }) ?? new SamplePermissionCatalogSource();
	source = inject(ROLE_ADMIN_SOURCE, { optional: true });
	confirm = injectConfirm();
	destroyRef = inject(DestroyRef);
	answer = toSignal(this.catalogSource.get());
	catalog = computed(() => {
		const answer = this.answer();
		return answer?.status === "loaded" ? answer.value : null;
	}, ...ngDevMode ? [{ debugName: "catalog" }] : /* istanbul ignore next */ []);
	permissions = computed(() => this.catalog()?.entries ?? [], ...ngDevMode ? [{ debugName: "permissions" }] : /* istanbul ignore next */ []);
	isBuiltInCopy = computed(() => this.catalog()?.origin === SIMULATED_PERMISSION_CATALOG.origin, ...ngDevMode ? [{ debugName: "isBuiltInCopy" }] : /* istanbul ignore next */ []);
	offered = this.source !== null;
	rolesState = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "rolesState" }] : /* istanbul ignore next */ []);
	roleRows = signal([], ...ngDevMode ? [{ debugName: "roleRows" }] : /* istanbul ignore next */ []);
	storeOrigin = signal(null, ...ngDevMode ? [{ debugName: "storeOrigin" }] : /* istanbul ignore next */ []);
	roleEditor = signal(null, ...ngDevMode ? [{ debugName: "roleEditor" }] : /* istanbul ignore next */ []);
	roleBusy = signal(false, ...ngDevMode ? [{ debugName: "roleBusy" }] : /* istanbul ignore next */ []);
	roleOutcome = signal(null, ...ngDevMode ? [{ debugName: "roleOutcome" }] : /* istanbul ignore next */ []);
	roleFieldErrors = signal({}, ...ngDevMode ? [{ debugName: "roleFieldErrors" }] : /* istanbul ignore next */ []);
	rolesProblem = computed(() => {
		const state = this.rolesState();
		return state.status === "unavailable" || state.status === "failed" ? state.message : null;
	}, ...ngDevMode ? [{ debugName: "rolesProblem" }] : /* istanbul ignore next */ []);
	parentChoices = computed(() => {
		const editing = this.roleEditor()?.role?.id;
		return this.roleRows().filter((role) => role.id !== editing);
	}, ...ngDevMode ? [{ debugName: "parentChoices" }] : /* istanbul ignore next */ []);
	filter = {
		tradeUnit: "",
		userObjectId: ""
	};
	assignmentsState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "assignmentsState" }] : /* istanbul ignore next */ []);
	assignments = signal([], ...ngDevMode ? [{ debugName: "assignments" }] : /* istanbul ignore next */ []);
	assignmentBusy = signal(false, ...ngDevMode ? [{ debugName: "assignmentBusy" }] : /* istanbul ignore next */ []);
	assignmentOutcome = signal(null, ...ngDevMode ? [{ debugName: "assignmentOutcome" }] : /* istanbul ignore next */ []);
	assignmentFieldErrors = signal({}, ...ngDevMode ? [{ debugName: "assignmentFieldErrors" }] : /* istanbul ignore next */ []);
	filterError = signal(null, ...ngDevMode ? [{ debugName: "filterError" }] : /* istanbul ignore next */ []);
	assignment = emptyAssignment();
	shownFilter = null;
	assignmentsProblem = computed(() => {
		const state = this.assignmentsState();
		return state.status === "unavailable" || state.status === "failed" ? state.message : null;
	}, ...ngDevMode ? [{ debugName: "assignmentsProblem" }] : /* istanbul ignore next */ []);
	constructor() {
		this.loadRoles();
	}
	permissionName(key) {
		return this.permissions().find((permission) => permission.key === key)?.name ?? key;
	}
	roleName(id) {
		return id === null ? "" : this.roleRows().find((role) => role.id === id)?.displayName ?? id;
	}
	systemReason(role) {
		return role.isSystem ? "The built-in Administrator role cannot be changed or deleted." : null;
	}
	loadRoles() {
		const source = this.source;
		if (source === null) return;
		this.rolesState.set({ status: "loading" });
		source.listRoles().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			switch (answer.kind) {
				case "done":
					this.roleRows.set(answer.value.rows);
					this.storeOrigin.set(answer.value.storeOrigin);
					this.rolesState.set({ status: "loaded" });
					break;
				case "unavailable":
					this.rolesState.set({
						status: "unavailable",
						message: answer.reason
					});
					break;
				default: this.rolesState.set({
					status: "failed",
					message: answer.message
				});
			}
		});
	}
	newRole() {
		this.openRole({
			role: null,
			name: "",
			displayName: "",
			description: "",
			parentRoleId: null,
			permissionKeys: []
		});
	}
	editRole(role) {
		if (role.isSystem) return;
		this.openRole({
			role,
			name: role.name,
			displayName: role.displayName,
			description: role.description,
			parentRoleId: role.parentRoleId,
			permissionKeys: [...role.permissionKeys]
		});
	}
	cancelRole() {
		this.roleEditor.set(null);
		this.roleFieldErrors.set({});
		this.roleOutcome.set(null);
	}
	hasPermission(editor, key) {
		return editor.permissionKeys.includes(key);
	}
	togglePermission(editor, key, granted) {
		editor.permissionKeys = granted ? [.../* @__PURE__ */ new Set([...editor.permissionKeys, key])] : editor.permissionKeys.filter((candidate) => candidate !== key);
	}
	saveRole() {
		const source = this.source;
		const editor = this.roleEditor();
		if (source === null || editor === null) return;
		const shared = {
			displayName: editor.displayName.trim(),
			description: editor.description.trim(),
			parentRoleId: editor.parentRoleId || null,
			permissionKeys: [...editor.permissionKeys]
		};
		const request = editor.role === null ? source.createRole({
			name: editor.name.trim(),
			...shared
		}) : source.updateRole(editor.role, shared);
		const label = shared.displayName || (editor.role === null ? editor.name.trim() : editor.role.displayName);
		this.runRole(request, `Role "${label}" ${editor.role === null ? "created" : "saved"}.`, () => this.roleEditor.set(null));
	}
	deleteRole(role) {
		const source = this.source;
		if (source === null || role.isSystem) return;
		this.confirm({
			title: "Delete this role?",
			message: `"${role.displayName}" will be deleted. The server refuses if anyone holds it or another role inherits from it.`,
			confirmLabel: "Delete role",
			cancelLabel: "Keep role",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) this.runRole(source.deleteRole(role), `Role "${role.displayName}" deleted.`);
		});
	}
	openRole(editor) {
		this.roleEditor.set(editor);
		this.roleFieldErrors.set({});
		this.roleOutcome.set(null);
	}
	runRole(request, success, onDone) {
		this.roleBusy.set(true);
		this.roleOutcome.set(null);
		this.roleFieldErrors.set({});
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.roleBusy.set(false);
			switch (answer.kind) {
				case "done":
					onDone?.();
					this.roleOutcome.set(mutationSucceeded(success));
					this.loadRoles();
					break;
				case "unavailable":
					this.roleOutcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "refused":
					this.roleOutcome.set(mutationFailed(answer));
					break;
				case "failed":
					this.roleFieldErrors.set(answer.fieldErrors ?? {});
					this.roleOutcome.set(mutationFailed(answer));
			}
		});
	}
	loadAssignments() {
		const source = this.source;
		if (source === null) return;
		const filter = {
			tradeUnit: this.filter.tradeUnit.trim(),
			userObjectId: this.filter.userObjectId.trim()
		};
		this.filterError.set(null);
		if (filter.userObjectId !== "" && !isEntraObjectId(filter.userObjectId)) {
			this.filterError.set(OBJECT_ID_REFUSAL);
			return;
		}
		this.assignmentsState.set({ status: "loading" });
		source.listAssignments(filter).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			switch (answer.kind) {
				case "done":
					this.shownFilter = filter;
					this.assignments.set(answer.value.rows);
					this.assignmentsState.set({ status: "loaded" });
					break;
				case "unavailable":
					this.assignmentsState.set({
						status: "unavailable",
						message: answer.reason
					});
					break;
				default: this.assignmentsState.set({
					status: "failed",
					message: answer.message
				});
			}
		});
	}
	assign() {
		const source = this.source;
		const form = this.assignment;
		if (source === null) return;
		if (!isEntraObjectId(form.userObjectId)) {
			this.assignmentFieldErrors.set({ userObjectId: [OBJECT_ID_REFUSAL] });
			this.assignmentOutcome.set(mutationRefused(`Not assigned. ${OBJECT_ID_REFUSAL}`));
			return;
		}
		this.runAssignment(source.assign({
			userObjectId: form.userObjectId.trim(),
			userUpn: form.userUpn.trim(),
			roleId: form.roleId,
			tradeUnit: form.tradeUnit.trim(),
			expiresAtUtc: form.expiresOn ? `${form.expiresOn}T00:00:00Z` : null,
			isDefault: form.isDefault
		}), form.userObjectId.trim(), `Role assigned to ${form.userUpn.trim() || form.userObjectId.trim()} in ${form.tradeUnit.trim()}.`, () => Object.assign(this.assignment, emptyAssignment()));
	}
	setDefault(row) {
		const source = this.source;
		if (source !== null) this.runAssignment(source.setDefault(row.userObjectId, row.tradeUnit), row.userObjectId, `${row.tradeUnit} is now the default trade unit for ${row.userUpn}.`);
	}
	revoke(row) {
		const source = this.source;
		if (source === null) return;
		this.confirm({
			title: "Revoke this role?",
			message: `${row.userUpn} will no longer hold "${row.roleDisplayName}" in ${row.tradeUnit}.` + (row.isDefault ? " It is their default trade unit, so the server moves the default." : ""),
			confirmLabel: "Revoke",
			cancelLabel: "Keep it",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) this.runAssignment(source.revoke(row), row.userObjectId, `"${row.roleDisplayName}" revoked from ${row.userUpn} in ${row.tradeUnit}.`);
		});
	}
	runAssignment(request, userObjectId, success, onDone) {
		this.assignmentBusy.set(true);
		this.assignmentOutcome.set(null);
		this.assignmentFieldErrors.set({});
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.assignmentBusy.set(false);
			switch (answer.kind) {
				case "done": {
					const user = userObjectId.toLowerCase();
					const kept = this.shownFilter?.tradeUnit ? answer.value.filter((row) => row.tradeUnit === this.shownFilter?.tradeUnit) : answer.value;
					this.assignments.set([...this.assignments().filter((row) => row.userObjectId.toLowerCase() !== user), ...kept]);
					this.assignmentsState.set({ status: "loaded" });
					onDone?.();
					this.assignmentOutcome.set(mutationSucceeded(success));
					break;
				}
				case "unavailable":
					this.assignmentOutcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "refused":
					this.assignmentOutcome.set(mutationFailed(answer));
					break;
				case "failed":
					this.assignmentFieldErrors.set(answer.fieldErrors ?? {});
					this.assignmentOutcome.set(mutationFailed(answer));
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: RolesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: RolesPageComponent,
		isStandalone: true,
		selector: "cws-roles-page",
		inputs: { view: {
			classPropertyName: "view",
			publicName: "view",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <!-- #825: the Roles and permissions page of the Admin section, with its three tabs. -->\r\n  <cms-page-header\r\n    title=\"Roles and permissions\"\r\n    description=\"Permissions are grouped into named roles and held per trade unit, rather than ticked per person.\"\r\n  >\r\n    @if (!refused() && showRoles() && offered && rolesState().status === 'loaded' && roleEditor() === null) {\r\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"newRole()\">New role</button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  @if (routed()) {\r\n    <cws-admin-tabs [views]=\"area.views\" label=\"Roles and permissions views\" />\r\n  }\r\n\r\n  @if (refused()) {\r\n    <!--\r\n      #696, #825: role administration is Admin-only by design, and the navigation already leaves it out\r\n      for an account KNOWN not to hold Admin. This is the bookmark and the pasted URL: the reason, not\r\n      the panel. The server refuses the calls either way.\r\n    -->\r\n    <p class=\"scoular-alert scoular-alert-info\" role=\"note\" data-testid=\"roles-refused\">\r\n      Role administration needs the Admin role on this application.\r\n    </p>\r\n  } @else {\r\n\r\n  <!--\r\n    🔴 THE CONTROL. Not decoration, and not removable without the ruling it names.\r\n\r\n    The stopgap contract-writer policy has already been read TWICE as though this matrix were\r\n    built. Seven tidy checkboxes are the most convincing possible version of that mistake, so the\r\n    screen states what it is above the content -- every load, not once per session.\r\n  -->\r\n  <div\r\n    class=\"cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:dark:border-amber-800 cws:dark:bg-amber-950\"\r\n    role=\"note\"\r\n    data-testid=\"provisional-banner\"\r\n  >\r\n    <p class=\"cws:text-sm cws:font-semibold cws:text-amber-900 cws:dark:text-amber-200\">\r\n      Provisional — this permission set is not agreed yet\r\n    </p>\r\n    <!--\r\n      ⚠ No issue number in this sentence, deliberately, and the tracking reference lives in the\r\n      component's doc comment instead. `user-facing-copy.spec.ts` refuses internal identifiers in\r\n      user-visible copy and it is right to: an administrator cannot open an issue, so \"#138\" tells\r\n      them a decision exists and gives them no way to reach it. What they CAN act on is the shape\r\n      of the caveat, which is what this says.\r\n    -->\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n      The seven permissions below are believed correct but are awaiting a business decision. That\r\n      decision may change which roles hold which permissions, or the granularity itself — so treat\r\n      anything configured here as a draft, and do not rely on it to describe who can do what today.\r\n      Enforcement across the application is not wired to these rows yet.\r\n    </p>\r\n  </div>\r\n\r\n  @if (showPermissions()) {\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <!-- \"permissions\", not \"seven\": the list is the server's now (#401), and #138 may change the count. -->\r\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">The provisional permissions</h3>\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Each gates the actions named beside it, for the trade unit the role is held on.\r\n    </p>\r\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      <summary class=\"cws:cursor-pointer\">What is not gated</summary>\r\n      <p class=\"cws:mt-1\">\r\n        An administrator flag overrides all of them. Reading a contract is deliberately not gated: any\r\n        assigned user may read any contract, and the form goes read-only rather than invisible.\r\n      </p>\r\n    </details>\r\n\r\n    @if (isBuiltInCopy()) {\r\n      <!--\r\n        #401: the server's list could not be read, so the application's own copy is shown. Said, so\r\n        the copy is never mistaken for the server's answer.\r\n      -->\r\n      <p\r\n        class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\"\r\n        role=\"status\"\r\n        data-testid=\"catalog-origin\"\r\n      >\r\n        Shown from the application's built-in copy: the server's list could not be read just now.\r\n      </p>\r\n    }\r\n\r\n    <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n      <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <tr>\r\n          <th class=\"cws:py-1\">Permission</th>\r\n          <th class=\"cws:py-1\">Stored as</th>\r\n          <th class=\"cws:py-1\">Gates</th>\r\n        </tr>\r\n      </thead>\r\n      <tbody data-testid=\"permission-rows\">\r\n        @for (permission of permissions(); track permission.key) {\r\n          <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n            <td class=\"cws:py-1 cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ permission.name }}</td>\r\n            <td class=\"cws:py-1 cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</td>\r\n            <td class=\"cws:py-1\">{{ permission.description }}</td>\r\n          </tr>\r\n        }\r\n      </tbody>\r\n    </table>\r\n  </div>\r\n  }\r\n\r\n  @if (showRoles()) {\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Roles</h3>\r\n    <!--\r\n      ⚠ 01 §5 rules the role list a workshop item that \"must not be invented here\", so the client\r\n      seeds none. An administrator creates them. Behind a disclosure since #825: it explains a short\r\n      list rather than changing what anyone does here.\r\n    -->\r\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      <summary class=\"cws:cursor-pointer\">Why only the built-in Administrator?</summary>\r\n      <p class=\"cws:mt-1\" data-testid=\"catalog-empty\">\r\n        None are shipped by default beyond the built-in Administrator. The role names the business is\r\n        considering — Trader, Merchandiser Assistant, Approver, Accounting &amp; Control, CWS\r\n        Administrator — are a workshop decision, so they are not pre-created here. The schema is\r\n        ready: a role is a row, and adding one needs no deployment.\r\n      </p>\r\n    </details>\r\n\r\n    @if (!offered) {\r\n      <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"roles-not-offered\">\r\n        Role administration is not offered here.\r\n      </p>\r\n    } @else {\r\n      @if (storeOrigin() === 'InMemory') {\r\n        <!-- The server is running without its database: rows are lost on restart. -->\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" role=\"status\" data-testid=\"roles-not-durable\">\r\n          These roles and assignments are held in memory on the server and are lost when it restarts.\r\n        </p>\r\n      }\r\n\r\n      @if (rolesProblem(); as problem) {\r\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"roles-problem\">\r\n          <div class=\"scoular-alert-description\">\r\n            {{ problem }}\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Try again</button>\r\n          </div>\r\n        </div>\r\n      }\r\n\r\n      <!--\r\n        #803: the last role write. A failure is the server's sentence as-is (a stale version, the\r\n        built-in role, a held or inherited role), with its reference and a Reload.\r\n      -->\r\n      <div class=\"cws:mt-2\" data-testid=\"role-notice\">\r\n        <cms-status-message [outcome]=\"roleOutcome()\" (dismissed)=\"roleOutcome.set(null)\">\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Reload</button>\r\n        </cms-status-message>\r\n      </div>\r\n\r\n      @if (roleEditor(); as editor) {\r\n        <form\r\n          class=\"cws:mt-3 cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n          data-testid=\"role-editor\"\r\n          (ngSubmit)=\"saveRole()\"\r\n        >\r\n          <h4 class=\"cws:text-sm cws:font-semibold\">{{ editor.role === null ? 'New role' : 'Edit ' + editor.role.displayName }}</h4>\r\n          <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-2\">\r\n            <label class=\"cws:block cws:text-xs\">\r\n              <span class=\"cws:font-medium\">Name</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n                name=\"name\"\r\n                [(ngModel)]=\"editor.name\"\r\n                [disabled]=\"editor.role !== null\"\r\n                aria-describedby=\"role-name-hint role-name-errors\"\r\n              />\r\n            </label>\r\n            <label class=\"cws:block cws:text-xs\">\r\n              <span class=\"cws:font-medium\">Display name</span>\r\n              <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"displayName\" [(ngModel)]=\"editor.displayName\" aria-describedby=\"role-displayName-errors\" />\r\n            </label>\r\n          </div>\r\n          <p id=\"role-name-hint\" class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            A PascalCase identifier, such as ContractWriter. It cannot be changed after the role is created.\r\n          </p>\r\n          @for (field of ['name', 'displayName', 'description', 'parentRoleId', 'permissionKeys']; track field) {\r\n            @if (roleFieldErrors()[field]; as reasons) {\r\n              <p [id]=\"'role-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700\" role=\"alert\">{{ reasons.join(' ') }}</p>\r\n            }\r\n          }\r\n          <label class=\"cws:block cws:text-xs\">\r\n            <span class=\"cws:font-medium\">Description</span>\r\n            <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"description\" [(ngModel)]=\"editor.description\" />\r\n          </label>\r\n          <label class=\"cws:block cws:text-xs\">\r\n            <span class=\"cws:font-medium\">Inherits from</span>\r\n            <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"parentRoleId\" [(ngModel)]=\"editor.parentRoleId\">\r\n              <option [ngValue]=\"null\">Nothing</option>\r\n              @for (choice of parentChoices(); track choice.id) {\r\n                <option [ngValue]=\"choice.id\">{{ choice.displayName }}</option>\r\n              }\r\n            </select>\r\n          </label>\r\n          <fieldset class=\"cws:text-xs\">\r\n            <legend class=\"cws:font-medium\">Permissions</legend>\r\n            <!-- The whole set goes back on save: the server replaces it, it does not merge. -->\r\n            @for (permission of permissions(); track permission.key) {\r\n              <label class=\"cws:mt-1 cws:flex cws:items-center cws:gap-2\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [name]=\"'permission-' + permission.key\"\r\n                  [checked]=\"hasPermission(editor, permission.key)\"\r\n                  (change)=\"togglePermission(editor, permission.key, $any($event.target).checked)\"\r\n                />\r\n                <span>{{ permission.name }}</span>\r\n                <span class=\"cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</span>\r\n              </label>\r\n            }\r\n          </fieldset>\r\n          <div class=\"cws:flex cws:gap-2\">\r\n            <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"roleBusy()\">\r\n              {{ editor.role === null ? 'Create role' : 'Save role' }}\r\n            </button>\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelRole()\">Cancel</button>\r\n          </div>\r\n        </form>\r\n      }\r\n\r\n      @if (rolesState().status === 'loading') {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading roles…</p>\r\n      }\r\n\r\n      @if (rolesState().status === 'loaded') {\r\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Role</th>\r\n              <th class=\"cws:py-1\">Permissions</th>\r\n              <th class=\"cws:py-1\">Inherits from</th>\r\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"role-rows\">\r\n            @for (role of roleRows(); track role.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:align-top cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">\r\n                  <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ role.displayName }}</span>\r\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ role.name }}</span>\r\n                  @if (role.isSystem) {\r\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Built in</span>\r\n                  }\r\n                </td>\r\n                <td class=\"cws:py-1\">\r\n                  @for (key of role.permissionKeys; track key; let last = $last) {\r\n                    {{ permissionName(key) }}{{ last ? '' : ', ' }}\r\n                  } @empty {\r\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">None</span>\r\n                  }\r\n                </td>\r\n                <td class=\"cws:py-1\">{{ roleName(role.parentRoleId) }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <!-- #825: Edit and Delete behind the row's menu. Delete still asks first. -->\r\n                  <cms-row-menu [row]=\"role\" [actions]=\"roleActions().get(role.id) ?? []\" [label]=\"'Actions for ' + role.displayName\" />\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n    }\r\n  </div>\r\n  }\r\n\r\n  @if (offered && showAssignments()) {\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Who holds which role</h3>\r\n      <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        A role is held per trade unit, and each user has exactly one default trade unit. Users are\r\n        identified by their Entra object id; their email address is shown for reading only.\r\n      </p>\r\n\r\n      <form class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-3\" data-testid=\"assignment-filter\" (ngSubmit)=\"loadAssignments()\">\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Trade unit</span>\r\n          <input class=\"scoular-form-input cws:mt-1\" name=\"filterTradeUnit\" [(ngModel)]=\"filter.tradeUnit\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:block cws:font-medium\">User object id</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-96\" name=\"filterUserObjectId\" [(ngModel)]=\"filter.userObjectId\" aria-describedby=\"filter-error\" />\r\n        </label>\r\n        <button type=\"submit\" class=\"scoular-btn scoular-btn-secondary\">Show assignments</button>\r\n      </form>\r\n      @if (filterError(); as error) {\r\n        <p id=\"filter-error\" class=\"cws:mt-1 cws:text-xs cws:text-red-700\" role=\"alert\">{{ error }}</p>\r\n      }\r\n\r\n      @if (assignmentsProblem(); as problem) {\r\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"assignments-problem\">\r\n          <div class=\"scoular-alert-description\">{{ problem }}</div>\r\n        </div>\r\n      }\r\n\r\n      <!-- #803: the last assignment write. A failure is the server's sentence as-is, with its reference. -->\r\n      <div class=\"cws:mt-2\" data-testid=\"assignment-notice\">\r\n        <cms-status-message [outcome]=\"assignmentOutcome()\" (dismissed)=\"assignmentOutcome.set(null)\" />\r\n      </div>\r\n\r\n      @if (assignmentsState().status === 'loading') {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading assignments…</p>\r\n      }\r\n\r\n      @if (assignmentsState().status === 'loaded') {\r\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">User</th>\r\n              <th class=\"cws:py-1\">Role</th>\r\n              <th class=\"cws:py-1\">Trade unit</th>\r\n              <th class=\"cws:py-1\">Expires</th>\r\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"assignment-rows\">\r\n            @for (row of assignments(); track row.userObjectId + row.roleId + row.tradeUnit) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">\r\n                  {{ row.userUpn }}\r\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ row.userObjectId }}</span>\r\n                </td>\r\n                <td class=\"cws:py-1\">{{ row.roleDisplayName }}</td>\r\n                <td class=\"cws:py-1\">\r\n                  {{ row.tradeUnit }}\r\n                  @if (row.isDefault) {\r\n                    <span class=\"cws:ml-1 cws:font-semibold\" data-testid=\"default-marker\">Default</span>\r\n                  }\r\n                </td>\r\n                <td class=\"cws:py-1\">{{ row.expiresAtUtc ? (row.isExpired ? 'Expired ' : '') + row.expiresAtUtc.slice(0, 10) : 'Never' }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <!-- #825: Make default and Revoke behind the row's menu. Revoke still asks first. -->\r\n                  <cms-row-menu\r\n                    [row]=\"row\"\r\n                    [actions]=\"assignmentActions().get(assignmentKey(row)) ?? []\"\r\n                    [label]=\"'Actions for ' + row.roleDisplayName + ' in ' + row.tradeUnit + ' for ' + row.userUpn\"\r\n                  />\r\n                </td>\r\n              </tr>\r\n            } @empty {\r\n              <tr><td colspan=\"5\" class=\"cws:py-2 cws:text-slate-500 cws:dark:text-slate-400\">No assignments match.</td></tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <form\r\n        class=\"cws:mt-4 cws:grid cws:gap-3 cws:border-t cws:border-slate-100 cws:pt-3 cws:md:grid-cols-3 cws:dark:border-slate-800\"\r\n        data-testid=\"assignment-form\"\r\n        (ngSubmit)=\"assign()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:md:col-span-3\">Assign a role</h4>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">User object id</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"userObjectId\" [(ngModel)]=\"assignment.userObjectId\" aria-describedby=\"assign-userObjectId-errors\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">User email (for display)</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"userUpn\" [(ngModel)]=\"assignment.userUpn\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Role</span>\r\n          <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"roleId\" [(ngModel)]=\"assignment.roleId\">\r\n            <option value=\"\">Choose…</option>\r\n            @for (role of roleRows(); track role.id) {\r\n              <option [value]=\"role.id\">{{ role.displayName }}</option>\r\n            }\r\n          </select>\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Trade unit</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"tradeUnit\" [(ngModel)]=\"assignment.tradeUnit\" aria-describedby=\"assign-tradeUnit-errors\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Expires on (optional)</span>\r\n          <input type=\"date\" class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"expiresOn\" [(ngModel)]=\"assignment.expiresOn\" />\r\n        </label>\r\n        <label class=\"cws:flex cws:items-center cws:gap-2 cws:self-end cws:text-xs\">\r\n          <input type=\"checkbox\" name=\"isDefault\" [(ngModel)]=\"assignment.isDefault\" />\r\n          <span>Make this their default trade unit</span>\r\n        </label>\r\n        @for (field of ['userObjectId', 'userUpn', 'roleId', 'tradeUnit', 'expiresAtUtc']; track field) {\r\n          @if (assignmentFieldErrors()[field]; as reasons) {\r\n            <p [id]=\"'assign-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700 cws:md:col-span-3\" role=\"alert\" [attr.data-testid]=\"'assign-error-' + field\">{{ reasons.join(' ') }}</p>\r\n          }\r\n        }\r\n        <div class=\"cws:md:col-span-3\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"assignmentBusy()\">Assign role</button>\r\n        </div>\r\n      </form>\r\n    </div>\r\n  }\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: RolesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-roles-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AdminTabsComponent,
				FormsModule,
				PageHeaderComponent,
				RowMenuComponent,
				StatusMessageComponent
			],
			template: "<section class=\"cws:space-y-4\">\r\n  <!-- #825: the Roles and permissions page of the Admin section, with its three tabs. -->\r\n  <cms-page-header\r\n    title=\"Roles and permissions\"\r\n    description=\"Permissions are grouped into named roles and held per trade unit, rather than ticked per person.\"\r\n  >\r\n    @if (!refused() && showRoles() && offered && rolesState().status === 'loaded' && roleEditor() === null) {\r\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"newRole()\">New role</button>\r\n    }\r\n  </cms-page-header>\r\n\r\n  @if (routed()) {\r\n    <cws-admin-tabs [views]=\"area.views\" label=\"Roles and permissions views\" />\r\n  }\r\n\r\n  @if (refused()) {\r\n    <!--\r\n      #696, #825: role administration is Admin-only by design, and the navigation already leaves it out\r\n      for an account KNOWN not to hold Admin. This is the bookmark and the pasted URL: the reason, not\r\n      the panel. The server refuses the calls either way.\r\n    -->\r\n    <p class=\"scoular-alert scoular-alert-info\" role=\"note\" data-testid=\"roles-refused\">\r\n      Role administration needs the Admin role on this application.\r\n    </p>\r\n  } @else {\r\n\r\n  <!--\r\n    🔴 THE CONTROL. Not decoration, and not removable without the ruling it names.\r\n\r\n    The stopgap contract-writer policy has already been read TWICE as though this matrix were\r\n    built. Seven tidy checkboxes are the most convincing possible version of that mistake, so the\r\n    screen states what it is above the content -- every load, not once per session.\r\n  -->\r\n  <div\r\n    class=\"cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:dark:border-amber-800 cws:dark:bg-amber-950\"\r\n    role=\"note\"\r\n    data-testid=\"provisional-banner\"\r\n  >\r\n    <p class=\"cws:text-sm cws:font-semibold cws:text-amber-900 cws:dark:text-amber-200\">\r\n      Provisional — this permission set is not agreed yet\r\n    </p>\r\n    <!--\r\n      ⚠ No issue number in this sentence, deliberately, and the tracking reference lives in the\r\n      component's doc comment instead. `user-facing-copy.spec.ts` refuses internal identifiers in\r\n      user-visible copy and it is right to: an administrator cannot open an issue, so \"#138\" tells\r\n      them a decision exists and gives them no way to reach it. What they CAN act on is the shape\r\n      of the caveat, which is what this says.\r\n    -->\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n      The seven permissions below are believed correct but are awaiting a business decision. That\r\n      decision may change which roles hold which permissions, or the granularity itself — so treat\r\n      anything configured here as a draft, and do not rely on it to describe who can do what today.\r\n      Enforcement across the application is not wired to these rows yet.\r\n    </p>\r\n  </div>\r\n\r\n  @if (showPermissions()) {\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <!-- \"permissions\", not \"seven\": the list is the server's now (#401), and #138 may change the count. -->\r\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">The provisional permissions</h3>\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Each gates the actions named beside it, for the trade unit the role is held on.\r\n    </p>\r\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      <summary class=\"cws:cursor-pointer\">What is not gated</summary>\r\n      <p class=\"cws:mt-1\">\r\n        An administrator flag overrides all of them. Reading a contract is deliberately not gated: any\r\n        assigned user may read any contract, and the form goes read-only rather than invisible.\r\n      </p>\r\n    </details>\r\n\r\n    @if (isBuiltInCopy()) {\r\n      <!--\r\n        #401: the server's list could not be read, so the application's own copy is shown. Said, so\r\n        the copy is never mistaken for the server's answer.\r\n      -->\r\n      <p\r\n        class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\"\r\n        role=\"status\"\r\n        data-testid=\"catalog-origin\"\r\n      >\r\n        Shown from the application's built-in copy: the server's list could not be read just now.\r\n      </p>\r\n    }\r\n\r\n    <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n      <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <tr>\r\n          <th class=\"cws:py-1\">Permission</th>\r\n          <th class=\"cws:py-1\">Stored as</th>\r\n          <th class=\"cws:py-1\">Gates</th>\r\n        </tr>\r\n      </thead>\r\n      <tbody data-testid=\"permission-rows\">\r\n        @for (permission of permissions(); track permission.key) {\r\n          <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n            <td class=\"cws:py-1 cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ permission.name }}</td>\r\n            <td class=\"cws:py-1 cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</td>\r\n            <td class=\"cws:py-1\">{{ permission.description }}</td>\r\n          </tr>\r\n        }\r\n      </tbody>\r\n    </table>\r\n  </div>\r\n  }\r\n\r\n  @if (showRoles()) {\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Roles</h3>\r\n    <!--\r\n      ⚠ 01 §5 rules the role list a workshop item that \"must not be invented here\", so the client\r\n      seeds none. An administrator creates them. Behind a disclosure since #825: it explains a short\r\n      list rather than changing what anyone does here.\r\n    -->\r\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      <summary class=\"cws:cursor-pointer\">Why only the built-in Administrator?</summary>\r\n      <p class=\"cws:mt-1\" data-testid=\"catalog-empty\">\r\n        None are shipped by default beyond the built-in Administrator. The role names the business is\r\n        considering — Trader, Merchandiser Assistant, Approver, Accounting &amp; Control, CWS\r\n        Administrator — are a workshop decision, so they are not pre-created here. The schema is\r\n        ready: a role is a row, and adding one needs no deployment.\r\n      </p>\r\n    </details>\r\n\r\n    @if (!offered) {\r\n      <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"roles-not-offered\">\r\n        Role administration is not offered here.\r\n      </p>\r\n    } @else {\r\n      @if (storeOrigin() === 'InMemory') {\r\n        <!-- The server is running without its database: rows are lost on restart. -->\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" role=\"status\" data-testid=\"roles-not-durable\">\r\n          These roles and assignments are held in memory on the server and are lost when it restarts.\r\n        </p>\r\n      }\r\n\r\n      @if (rolesProblem(); as problem) {\r\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"roles-problem\">\r\n          <div class=\"scoular-alert-description\">\r\n            {{ problem }}\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Try again</button>\r\n          </div>\r\n        </div>\r\n      }\r\n\r\n      <!--\r\n        #803: the last role write. A failure is the server's sentence as-is (a stale version, the\r\n        built-in role, a held or inherited role), with its reference and a Reload.\r\n      -->\r\n      <div class=\"cws:mt-2\" data-testid=\"role-notice\">\r\n        <cms-status-message [outcome]=\"roleOutcome()\" (dismissed)=\"roleOutcome.set(null)\">\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Reload</button>\r\n        </cms-status-message>\r\n      </div>\r\n\r\n      @if (roleEditor(); as editor) {\r\n        <form\r\n          class=\"cws:mt-3 cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n          data-testid=\"role-editor\"\r\n          (ngSubmit)=\"saveRole()\"\r\n        >\r\n          <h4 class=\"cws:text-sm cws:font-semibold\">{{ editor.role === null ? 'New role' : 'Edit ' + editor.role.displayName }}</h4>\r\n          <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-2\">\r\n            <label class=\"cws:block cws:text-xs\">\r\n              <span class=\"cws:font-medium\">Name</span>\r\n              <input\r\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n                name=\"name\"\r\n                [(ngModel)]=\"editor.name\"\r\n                [disabled]=\"editor.role !== null\"\r\n                aria-describedby=\"role-name-hint role-name-errors\"\r\n              />\r\n            </label>\r\n            <label class=\"cws:block cws:text-xs\">\r\n              <span class=\"cws:font-medium\">Display name</span>\r\n              <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"displayName\" [(ngModel)]=\"editor.displayName\" aria-describedby=\"role-displayName-errors\" />\r\n            </label>\r\n          </div>\r\n          <p id=\"role-name-hint\" class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            A PascalCase identifier, such as ContractWriter. It cannot be changed after the role is created.\r\n          </p>\r\n          @for (field of ['name', 'displayName', 'description', 'parentRoleId', 'permissionKeys']; track field) {\r\n            @if (roleFieldErrors()[field]; as reasons) {\r\n              <p [id]=\"'role-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700\" role=\"alert\">{{ reasons.join(' ') }}</p>\r\n            }\r\n          }\r\n          <label class=\"cws:block cws:text-xs\">\r\n            <span class=\"cws:font-medium\">Description</span>\r\n            <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"description\" [(ngModel)]=\"editor.description\" />\r\n          </label>\r\n          <label class=\"cws:block cws:text-xs\">\r\n            <span class=\"cws:font-medium\">Inherits from</span>\r\n            <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"parentRoleId\" [(ngModel)]=\"editor.parentRoleId\">\r\n              <option [ngValue]=\"null\">Nothing</option>\r\n              @for (choice of parentChoices(); track choice.id) {\r\n                <option [ngValue]=\"choice.id\">{{ choice.displayName }}</option>\r\n              }\r\n            </select>\r\n          </label>\r\n          <fieldset class=\"cws:text-xs\">\r\n            <legend class=\"cws:font-medium\">Permissions</legend>\r\n            <!-- The whole set goes back on save: the server replaces it, it does not merge. -->\r\n            @for (permission of permissions(); track permission.key) {\r\n              <label class=\"cws:mt-1 cws:flex cws:items-center cws:gap-2\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [name]=\"'permission-' + permission.key\"\r\n                  [checked]=\"hasPermission(editor, permission.key)\"\r\n                  (change)=\"togglePermission(editor, permission.key, $any($event.target).checked)\"\r\n                />\r\n                <span>{{ permission.name }}</span>\r\n                <span class=\"cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</span>\r\n              </label>\r\n            }\r\n          </fieldset>\r\n          <div class=\"cws:flex cws:gap-2\">\r\n            <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"roleBusy()\">\r\n              {{ editor.role === null ? 'Create role' : 'Save role' }}\r\n            </button>\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelRole()\">Cancel</button>\r\n          </div>\r\n        </form>\r\n      }\r\n\r\n      @if (rolesState().status === 'loading') {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading roles…</p>\r\n      }\r\n\r\n      @if (rolesState().status === 'loaded') {\r\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Role</th>\r\n              <th class=\"cws:py-1\">Permissions</th>\r\n              <th class=\"cws:py-1\">Inherits from</th>\r\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"role-rows\">\r\n            @for (role of roleRows(); track role.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:align-top cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">\r\n                  <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ role.displayName }}</span>\r\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ role.name }}</span>\r\n                  @if (role.isSystem) {\r\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Built in</span>\r\n                  }\r\n                </td>\r\n                <td class=\"cws:py-1\">\r\n                  @for (key of role.permissionKeys; track key; let last = $last) {\r\n                    {{ permissionName(key) }}{{ last ? '' : ', ' }}\r\n                  } @empty {\r\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">None</span>\r\n                  }\r\n                </td>\r\n                <td class=\"cws:py-1\">{{ roleName(role.parentRoleId) }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <!-- #825: Edit and Delete behind the row's menu. Delete still asks first. -->\r\n                  <cms-row-menu [row]=\"role\" [actions]=\"roleActions().get(role.id) ?? []\" [label]=\"'Actions for ' + role.displayName\" />\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n    }\r\n  </div>\r\n  }\r\n\r\n  @if (offered && showAssignments()) {\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Who holds which role</h3>\r\n      <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        A role is held per trade unit, and each user has exactly one default trade unit. Users are\r\n        identified by their Entra object id; their email address is shown for reading only.\r\n      </p>\r\n\r\n      <form class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-3\" data-testid=\"assignment-filter\" (ngSubmit)=\"loadAssignments()\">\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Trade unit</span>\r\n          <input class=\"scoular-form-input cws:mt-1\" name=\"filterTradeUnit\" [(ngModel)]=\"filter.tradeUnit\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:block cws:font-medium\">User object id</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-96\" name=\"filterUserObjectId\" [(ngModel)]=\"filter.userObjectId\" aria-describedby=\"filter-error\" />\r\n        </label>\r\n        <button type=\"submit\" class=\"scoular-btn scoular-btn-secondary\">Show assignments</button>\r\n      </form>\r\n      @if (filterError(); as error) {\r\n        <p id=\"filter-error\" class=\"cws:mt-1 cws:text-xs cws:text-red-700\" role=\"alert\">{{ error }}</p>\r\n      }\r\n\r\n      @if (assignmentsProblem(); as problem) {\r\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"assignments-problem\">\r\n          <div class=\"scoular-alert-description\">{{ problem }}</div>\r\n        </div>\r\n      }\r\n\r\n      <!-- #803: the last assignment write. A failure is the server's sentence as-is, with its reference. -->\r\n      <div class=\"cws:mt-2\" data-testid=\"assignment-notice\">\r\n        <cms-status-message [outcome]=\"assignmentOutcome()\" (dismissed)=\"assignmentOutcome.set(null)\" />\r\n      </div>\r\n\r\n      @if (assignmentsState().status === 'loading') {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading assignments…</p>\r\n      }\r\n\r\n      @if (assignmentsState().status === 'loaded') {\r\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">User</th>\r\n              <th class=\"cws:py-1\">Role</th>\r\n              <th class=\"cws:py-1\">Trade unit</th>\r\n              <th class=\"cws:py-1\">Expires</th>\r\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"assignment-rows\">\r\n            @for (row of assignments(); track row.userObjectId + row.roleId + row.tradeUnit) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">\r\n                  {{ row.userUpn }}\r\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ row.userObjectId }}</span>\r\n                </td>\r\n                <td class=\"cws:py-1\">{{ row.roleDisplayName }}</td>\r\n                <td class=\"cws:py-1\">\r\n                  {{ row.tradeUnit }}\r\n                  @if (row.isDefault) {\r\n                    <span class=\"cws:ml-1 cws:font-semibold\" data-testid=\"default-marker\">Default</span>\r\n                  }\r\n                </td>\r\n                <td class=\"cws:py-1\">{{ row.expiresAtUtc ? (row.isExpired ? 'Expired ' : '') + row.expiresAtUtc.slice(0, 10) : 'Never' }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <!-- #825: Make default and Revoke behind the row's menu. Revoke still asks first. -->\r\n                  <cms-row-menu\r\n                    [row]=\"row\"\r\n                    [actions]=\"assignmentActions().get(assignmentKey(row)) ?? []\"\r\n                    [label]=\"'Actions for ' + row.roleDisplayName + ' in ' + row.tradeUnit + ' for ' + row.userUpn\"\r\n                  />\r\n                </td>\r\n              </tr>\r\n            } @empty {\r\n              <tr><td colspan=\"5\" class=\"cws:py-2 cws:text-slate-500 cws:dark:text-slate-400\">No assignments match.</td></tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <form\r\n        class=\"cws:mt-4 cws:grid cws:gap-3 cws:border-t cws:border-slate-100 cws:pt-3 cws:md:grid-cols-3 cws:dark:border-slate-800\"\r\n        data-testid=\"assignment-form\"\r\n        (ngSubmit)=\"assign()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:md:col-span-3\">Assign a role</h4>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">User object id</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"userObjectId\" [(ngModel)]=\"assignment.userObjectId\" aria-describedby=\"assign-userObjectId-errors\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">User email (for display)</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"userUpn\" [(ngModel)]=\"assignment.userUpn\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Role</span>\r\n          <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"roleId\" [(ngModel)]=\"assignment.roleId\">\r\n            <option value=\"\">Choose…</option>\r\n            @for (role of roleRows(); track role.id) {\r\n              <option [value]=\"role.id\">{{ role.displayName }}</option>\r\n            }\r\n          </select>\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Trade unit</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"tradeUnit\" [(ngModel)]=\"assignment.tradeUnit\" aria-describedby=\"assign-tradeUnit-errors\" />\r\n        </label>\r\n        <label class=\"cws:block cws:text-xs\">\r\n          <span class=\"cws:font-medium\">Expires on (optional)</span>\r\n          <input type=\"date\" class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"expiresOn\" [(ngModel)]=\"assignment.expiresOn\" />\r\n        </label>\r\n        <label class=\"cws:flex cws:items-center cws:gap-2 cws:self-end cws:text-xs\">\r\n          <input type=\"checkbox\" name=\"isDefault\" [(ngModel)]=\"assignment.isDefault\" />\r\n          <span>Make this their default trade unit</span>\r\n        </label>\r\n        @for (field of ['userObjectId', 'userUpn', 'roleId', 'tradeUnit', 'expiresAtUtc']; track field) {\r\n          @if (assignmentFieldErrors()[field]; as reasons) {\r\n            <p [id]=\"'assign-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700 cws:md:col-span-3\" role=\"alert\" [attr.data-testid]=\"'assign-error-' + field\">{{ reasons.join(' ') }}</p>\r\n          }\r\n        }\r\n        <div class=\"cws:md:col-span-3\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"assignmentBusy()\">Assign role</button>\r\n        </div>\r\n      </form>\r\n    </div>\r\n  }\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { view: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "view",
			required: false
		}]
	}] }
});
function emptyAssignment() {
	return {
		userObjectId: "",
		userUpn: "",
		roleId: "",
		tradeUnit: "",
		expiresOn: "",
		isDefault: false
	};
}
var TradeUnitValuesPageComponent = class TradeUnitValuesPageComponent {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	tradeUnit = signal("", ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	values = signal([], ...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	months = signal([], ...ngDevMode ? [{ debugName: "months" }] : /* istanbul ignore next */ []);
	loaded = signal(false, ...ngDevMode ? [{ debugName: "loaded" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	error = signal(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	refusal = signal(null, ...ngDevMode ? [{ debugName: "refusal" }] : /* istanbul ignore next */ []);
	monthError = computed(() => this.refusal()?.fieldErrors["marketMonth"]?.join(" ") ?? null, ...ngDevMode ? [{ debugName: "monthError" }] : /* istanbul ignore next */ []);
	componentName = "";
	value = "";
	include = true;
	commodity = "";
	marketMonth = "";
	hasTradeUnit = computed(() => this.tradeUnit().trim() !== "", ...ngDevMode ? [{ debugName: "hasTradeUnit" }] : /* istanbul ignore next */ []);
	refuse(reason) {
		const refusal = adminRefusalOf(reason);
		this.refusal.set(refusal);
		this.error.set(refusal.message);
	}
	load() {
		const unit = this.tradeUnit().trim();
		if (unit === "") return;
		this.busy.set(true);
		this.error.set(null);
		this.refusal.set(null);
		Promise.all([this.get("values", unit), this.get("market-months", unit)]).then(([values, months]) => {
			this.values.set(values);
			this.months.set(months);
			this.loaded.set(true);
		}).catch((reason) => this.refuse(reason)).finally(() => this.busy.set(false));
	}
	addValue() {
		const unit = this.tradeUnit().trim();
		if (unit === "" || this.componentName.trim() === "" || this.value.trim() === "") {
			this.outcome.set(mutationRefused("Trade unit, component and value are all required."));
			return;
		}
		const added = `${this.value.trim()} ${this.include ? "offered" : "withheld"} for ${this.componentName.trim()} at ${unit}.`;
		this.send("PUT", "values", added, {
			tradeUnit: unit,
			componentName: this.componentName.trim(),
			value: this.value.trim(),
			include: this.include
		}).then((ok) => {
			if (ok) {
				this.value = "";
				this.load();
			}
		});
	}
	removeValue(row) {
		this.send("DELETE", `values/${row.id}`, `${row.value} removed from ${row.componentName}.`).then((ok) => ok && this.load());
	}
	addMonth() {
		const unit = this.tradeUnit().trim();
		if (unit === "" || this.commodity.trim() === "" || this.marketMonth.trim() === "") {
			this.outcome.set(mutationRefused("Trade unit, commodity and month are all required."));
			return;
		}
		const month = `Month ${this.marketMonth.trim()} added for ${this.commodity.trim()} at ${unit}.`;
		this.send("POST", "market-months", month, {
			tradeUnit: unit,
			commodity: this.commodity.trim(),
			marketMonth: this.marketMonth.trim()
		}).then((ok) => {
			if (ok) {
				this.marketMonth = "";
				this.load();
			}
		});
	}
	removeMonth(row) {
		this.send("DELETE", `market-months/${row.id}`, `Month ${row.marketMonth} removed from ${row.commodity}.`).then((ok) => ok && this.load());
	}
	async get(set, tradeUnit) {
		return (await this.request("GET", `${set}?tradeUnit=${encodeURIComponent(tradeUnit)}`))?.rows ?? [];
	}
	async send(method, path, success, body) {
		this.busy.set(true);
		this.error.set(null);
		this.refusal.set(null);
		this.outcome.set(null);
		try {
			await this.request(method, path, body);
			this.outcome.set(mutationSucceeded(success));
			return true;
		} catch (reason) {
			const refusal = adminRefusalOf(reason);
			this.refusal.set(refusal);
			this.outcome.set(mutationFailed(refusal));
			return false;
		} finally {
			this.busy.set(false);
		}
	}
	request(method, path, body) {
		return new Promise((resolve, reject) => {
			this.http.request(method, `${this.baseUrl}/trade-unit-values/${path}`, { body }).subscribe({
				next: (value) => resolve(value),
				error: reject,
				complete: () => resolve(void 0)
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: TradeUnitValuesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: TradeUnitValuesPageComponent,
		isStandalone: true,
		selector: "cws-trade-unit-values-page",
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <!-- #825: a page of its own in the Admin section; its primary action is Load, beside the picker. -->\r\n  <cms-page-header\r\n    title=\"Trade unit values\"\r\n    description=\"What a trade unit offers: the allowed values per field, and the market months per commodity, on its contracts.\"\r\n  />\r\n\r\n  <!--\r\n    Kept visible: it decides what an administrator tries here. CTRM refuses a value it did not offer,\r\n    so a month or code added here would fail on save with nothing on the screen able to explain why.\r\n  -->\r\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n    This can only take options away, never add them: CTRM refuses a value it did not offer.\r\n  </p>\r\n\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n    <!-- #696: the holder's own trade units, or every location for an Admin. No free text where a list exists. -->\r\n    <cws-admin-trade-unit-select\r\n      class=\"cws:w-72\"\r\n      label=\"Trade unit\"\r\n      [value]=\"tradeUnit()\"\r\n      (valueChange)=\"tradeUnit.set($event)\"\r\n    />\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-primary\"\r\n      [disabled]=\"!hasTradeUnit() || busy()\"\r\n      (click)=\"load()\"\r\n    >\r\n      {{ busy() ? 'Working…' : 'Load' }}\r\n    </button>\r\n  </div>\r\n\r\n  @if (error(); as message) {\r\n    <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n      {{ message }}\r\n    </p>\r\n  }\r\n\r\n  <!-- #803: the last write's outcome, with the server's reference on a refusal. -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\r\n\r\n  @if (loaded()) {\r\n    <!-- F8.2 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Allowed values</h3>\r\n\r\n      @if (values().length === 0) {\r\n        <!--\r\n          🔴 The counter-intuitive state, said in words. An empty allow-list screen normally means\r\n          \"nothing is permitted\"; here it means the opposite, and an administrator who assumed the\r\n          usual reading would key in every value by hand to \"fix\" a trade unit that is already\r\n          working correctly.\r\n        -->\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"values-empty\">\r\n          Nothing configured, so every value CTRM offers is available on this trade unit. Adding a\r\n          row here starts an allow-list and everything not on it stops being offered.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Field</th>\r\n              <th class=\"cws:py-1\">Value</th>\r\n              <th class=\"cws:py-1\">Offered</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"values-rows\">\r\n            @for (row of values(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">{{ row.componentName }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.value }}</td>\r\n                <td class=\"cws:py-1\">{{ row.include ? 'Yes' : 'No — excluded' }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.value + ' from ' + row.componentName\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeValue(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Field</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-56\" [(ngModel)]=\"componentName\" name=\"componentName\"\r\n                 placeholder=\"e.g. PriceTypeCode\" />\r\n        </label>\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Value</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"value\" name=\"value\" placeholder=\"e.g. P\" />\r\n        </label>\r\n        <label class=\"cws:flex cws:items-center cws:gap-2 cws:pb-2 cws:text-xs\">\r\n          <input type=\"checkbox\" [(ngModel)]=\"include\" name=\"include\" />\r\n          Offered\r\n        </label>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addValue()\">\r\n          Add value\r\n        </button>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- F8.5 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Market months</h3>\r\n\r\n      @if (months().length === 0) {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"months-empty\">\r\n          Nothing configured, so every month CTRM returns for a commodity is offered. Adding a row\r\n          narrows the list to what is listed here for that commodity.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Commodity</th>\r\n              <th class=\"cws:py-1\">Month</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"months-rows\">\r\n            @for (row of months(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.commodity }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.marketMonth }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.marketMonth + ' from ' + row.commodity\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeMonth(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"commodity\" name=\"commodity\" placeholder=\"e.g. YC\" />\r\n        </label>\r\n        <!-- CTRM's months are one letter with no year (#695): Z is December. -->\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Month</span>\r\n          <input\r\n            class=\"scoular-form-input cws:mt-1 cws:w-32\"\r\n            [(ngModel)]=\"marketMonth\"\r\n            name=\"marketMonth\"\r\n            placeholder=\"e.g. Z\"\r\n            [attr.aria-invalid]=\"monthError() !== null ? 'true' : null\"\r\n            [attr.aria-describedby]=\"monthError() !== null ? 'tu-month-error' : null\"\r\n          />\r\n        </label>\r\n        @if (monthError(); as reason) {\r\n          <!-- #696: the server names what CTRM does offer, so the reason sits by the field, outside its label. -->\r\n          <span id=\"tu-month-error\" class=\"cws:block cws:max-w-md cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n            {{ reason }}\r\n          </span>\r\n        }\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addMonth()\">\r\n          Add month\r\n        </button>\r\n      </div>\r\n    </div>\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: AdminTradeUnitSelectComponent,
				selector: "cws-admin-trade-unit-select",
				inputs: [
					"label",
					"value",
					"allowAny"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: TradeUnitValuesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-trade-unit-values-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				AdminTradeUnitSelectComponent,
				PageHeaderComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-4\">\r\n  <!-- #825: a page of its own in the Admin section; its primary action is Load, beside the picker. -->\r\n  <cms-page-header\r\n    title=\"Trade unit values\"\r\n    description=\"What a trade unit offers: the allowed values per field, and the market months per commodity, on its contracts.\"\r\n  />\r\n\r\n  <!--\r\n    Kept visible: it decides what an administrator tries here. CTRM refuses a value it did not offer,\r\n    so a month or code added here would fail on save with nothing on the screen able to explain why.\r\n  -->\r\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n    This can only take options away, never add them: CTRM refuses a value it did not offer.\r\n  </p>\r\n\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n    <!-- #696: the holder's own trade units, or every location for an Admin. No free text where a list exists. -->\r\n    <cws-admin-trade-unit-select\r\n      class=\"cws:w-72\"\r\n      label=\"Trade unit\"\r\n      [value]=\"tradeUnit()\"\r\n      (valueChange)=\"tradeUnit.set($event)\"\r\n    />\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-primary\"\r\n      [disabled]=\"!hasTradeUnit() || busy()\"\r\n      (click)=\"load()\"\r\n    >\r\n      {{ busy() ? 'Working…' : 'Load' }}\r\n    </button>\r\n  </div>\r\n\r\n  @if (error(); as message) {\r\n    <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n      {{ message }}\r\n    </p>\r\n  }\r\n\r\n  <!-- #803: the last write's outcome, with the server's reference on a refusal. -->\r\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\r\n\r\n  @if (loaded()) {\r\n    <!-- F8.2 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Allowed values</h3>\r\n\r\n      @if (values().length === 0) {\r\n        <!--\r\n          🔴 The counter-intuitive state, said in words. An empty allow-list screen normally means\r\n          \"nothing is permitted\"; here it means the opposite, and an administrator who assumed the\r\n          usual reading would key in every value by hand to \"fix\" a trade unit that is already\r\n          working correctly.\r\n        -->\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"values-empty\">\r\n          Nothing configured, so every value CTRM offers is available on this trade unit. Adding a\r\n          row here starts an allow-list and everything not on it stops being offered.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Field</th>\r\n              <th class=\"cws:py-1\">Value</th>\r\n              <th class=\"cws:py-1\">Offered</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"values-rows\">\r\n            @for (row of values(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">{{ row.componentName }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.value }}</td>\r\n                <td class=\"cws:py-1\">{{ row.include ? 'Yes' : 'No — excluded' }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.value + ' from ' + row.componentName\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeValue(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Field</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-56\" [(ngModel)]=\"componentName\" name=\"componentName\"\r\n                 placeholder=\"e.g. PriceTypeCode\" />\r\n        </label>\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Value</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"value\" name=\"value\" placeholder=\"e.g. P\" />\r\n        </label>\r\n        <label class=\"cws:flex cws:items-center cws:gap-2 cws:pb-2 cws:text-xs\">\r\n          <input type=\"checkbox\" [(ngModel)]=\"include\" name=\"include\" />\r\n          Offered\r\n        </label>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addValue()\">\r\n          Add value\r\n        </button>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- F8.5 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Market months</h3>\r\n\r\n      @if (months().length === 0) {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"months-empty\">\r\n          Nothing configured, so every month CTRM returns for a commodity is offered. Adding a row\r\n          narrows the list to what is listed here for that commodity.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Commodity</th>\r\n              <th class=\"cws:py-1\">Month</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"months-rows\">\r\n            @for (row of months(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.commodity }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.marketMonth }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.marketMonth + ' from ' + row.commodity\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeMonth(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"commodity\" name=\"commodity\" placeholder=\"e.g. YC\" />\r\n        </label>\r\n        <!-- CTRM's months are one letter with no year (#695): Z is December. -->\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Month</span>\r\n          <input\r\n            class=\"scoular-form-input cws:mt-1 cws:w-32\"\r\n            [(ngModel)]=\"marketMonth\"\r\n            name=\"marketMonth\"\r\n            placeholder=\"e.g. Z\"\r\n            [attr.aria-invalid]=\"monthError() !== null ? 'true' : null\"\r\n            [attr.aria-describedby]=\"monthError() !== null ? 'tu-month-error' : null\"\r\n          />\r\n        </label>\r\n        @if (monthError(); as reason) {\r\n          <!-- #696: the server names what CTRM does offer, so the reason sits by the field, outside its label. -->\r\n          <span id=\"tu-month-error\" class=\"cws:block cws:max-w-md cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\r\n            {{ reason }}\r\n          </span>\r\n        }\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addMonth()\">\r\n          Add month\r\n        </button>\r\n      </div>\r\n    </div>\r\n  }\r\n</section>\r\n"
		}]
	}]
});
function adminRoutes() {
	return [
		{
			path: "",
			pathMatch: "full",
			title: "Admin",
			component: AdminOverviewComponent
		},
		{
			path: "form-configuration",
			title: "Form configuration",
			children: [{
				path: "",
				component: FormConfigAdminPageComponent,
				data: { view: "rows" }
			}, {
				path: "preview",
				component: FormConfigAdminPageComponent,
				data: { view: "preview" }
			}]
		},
		{
			path: "trade-unit-values",
			title: "Trade unit values",
			component: TradeUnitValuesPageComponent
		},
		{
			path: "addendums",
			title: "Addendums",
			children: [{
				path: "",
				component: AddendumTemplatesPageComponent,
				data: { view: "templates" }
			}, {
				path: "types",
				component: AddendumTemplatesPageComponent,
				data: { view: "types" }
			}]
		},
		{
			path: "roles",
			title: "Roles and permissions",
			children: [
				{
					path: "",
					component: RolesPageComponent,
					data: { view: "roles" }
				},
				{
					path: "assignments",
					component: RolesPageComponent,
					data: { view: "assignments" }
				},
				{
					path: "permissions",
					component: RolesPageComponent,
					data: { view: "permissions" }
				}
			]
		},
		{
			path: "**",
			redirectTo: ""
		}
	];
}
export { ADMIN_AREAS, AddendumTemplatesPageComponent, AdminPageComponent, FormConfigAdminPageComponent, FormConfigEditorComponent, NOT_ONBOARDED_EXPLANATION, RolesPageComponent, adminArea, adminRoutes, previewPresentation, typeNotAvailableMessage, unknownTradeUnitsMessage, unknownTypesMessage, withSetPresentationOnly };

//# sourceMappingURL=cws-features-admin.mjs.map
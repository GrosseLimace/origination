import * as i0 from "@angular/core";
import { OnInit } from "@angular/core";
import { AddendumFamily, AddendumTemplate, ConfigFieldBehaviour, ConfigTab, FormConfigAuditTrail, FormConfigDetail, FormConfigListResponse, FormConfigPreview, FormConfigRow } from "@cws/domain-contracts";
import { RemoteData, RemoteError } from "@cws/shared-ui";
/**
 * **Admin** (E5) — form configuration is built; the rest is not.
 *
 * The page used to be a placeholder saying so for everything. Form configuration (ADR-17) now has a
 * real screen, so this hosts it and keeps naming what is still absent: permissions, templates and
 * the trade-unit onboarding of E8. A nav entry leading nowhere reads as a broken application, and
 * so does a page that quietly stops mentioning the things it does not do yet.
 */
export declare class AdminPageComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<AdminPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AdminPageComponent, "cms-admin-page", never, {}, {}, never, never, true, never>;
}
/** What the list is doing. `unavailable` is the routes not being published yet, which is normal. */
type ListState = {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
} | {
  readonly status: 'unavailable';
  readonly reason: string;
} | {
  readonly status: 'failed';
  readonly message: string;
  readonly correlationId?: string;
};
/** The editor's working copy. Plain fields, `ngModel`-bound and read only on Save. */
interface TemplateEditor {
  id: number | null;
  version: number | null;
  name: string;
  family: AddendumFamily;
  tradeUnits: string;
  templateContent: string;
  fieldMapJson: string;
  active: boolean;
}
/**
 * **Addendum templates (F10.3b).** List, create, edit, deactivate and delete, with the version shown.
 *
 * ### 🔴 Save is refused HERE, before any request, when the anchors are wrong
 *
 * Legal requires a separate signature anchor and initials anchor on every template, and the signing
 * matcher refuses the `sig10__es_` form. A template that reached the server without them would be
 * refused there at best, and at worst stored and used, producing a document nobody can sign where
 * Legal requires. So the rule runs on Save and its reasons sit beside the content field, where the
 * administrator is looking when they paste in the approved text.
 *
 * ### ⚠ The routes are not published yet
 *
 * The shell wires the HTTP source now, and a `404` renders as *not available yet* rather than as an
 * error or an empty table. An empty table would read as "there are no templates", which is a claim a
 * missing route cannot support.
 *
 * ⚠ **Deactivate and Delete are different on purpose.** Deactivating keeps the template and its
 * version history and stops it being offered on a record; deleting removes it, so it asks first.
 */
export declare class AddendumTemplatesPageComponent {
  private readonly source;
  private readonly confirm;
  private readonly destroyRef;
  /** The three anchors, for the editor's help text. From the domain library, never retyped. */
  protected readonly anchors: string[];
  protected readonly offered: boolean;
  protected readonly state: import("@angular/core").WritableSignal<ListState>;
  protected readonly unavailableReason: import("@angular/core").Signal<string | null>;
  protected readonly failure: import("@angular/core").Signal<{
    readonly status: "failed";
    readonly message: string;
    readonly correlationId?: string;
  } | null>;
  protected readonly templates: import("@angular/core").WritableSignal<readonly AddendumTemplate[]>;
  protected readonly editor: import("@angular/core").WritableSignal<TemplateEditor | null>;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  /** Why the editor's content would be refused. Shown beside the content field. */
  protected readonly anchorProblems: import("@angular/core").WritableSignal<readonly string[]>;
  /** A refusal that addresses no single field: a blank name, or the server saying no. */
  protected readonly actionError: import("@angular/core").WritableSignal<string | null>;
  constructor();
  protected load(): void;
  protected startCreate(): void;
  protected startEdit(template: AddendumTemplate): void;
  protected cancelEdit(): void;
  /**
   * Validates, then sends. 🔴 **Nothing is sent while the anchors are wrong** — the refusal is the
   * point, so it returns before the source is touched.
   */
  protected save(): void;
  protected deactivate(template: AddendumTemplate): void;
  /** Deletes after asking. The confirmation names the template, so the answer is not a guess. */
  protected remove(template: AddendumTemplate): void;
  protected tradeUnitsLabel(template: AddendumTemplate): string;
  private open;
  /** Sends one write, then re-reads the list: the server's version number is the one shown. */
  private run;
  static ɵfac: i0.ɵɵFactoryDeclaration<AddendumTemplatesPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AddendumTemplatesPageComponent, "cws-addendum-templates-page", never, {}, {}, never, never, true, never>;
}
/**
 * **Form configuration administration** (ADR-17, implementation brief §10.5).
 *
 * Two halves, and the second is the valuable one.
 *
 * ### The list
 *
 * Every configuration row including inactive ones, with its dimensions rendered as *Any* where they
 * are null — because a blank cell in a dimension column reads as missing data when it actually means
 * "this row applies to everything". Deactivating is soft and sends the row's `rowVersion`, so a
 * concurrent edit is a message rather than a silent overwrite.
 *
 * ### 🔑 The preview tool, and why it is not optional
 *
 * Pick any combination of dimensions and see **which row wins and why**. The resolution rules are
 * match-count-first with a significance tie-break over up to three dimensions and an effective date
 * (brief §6) — which is simple to state and genuinely hard to hold in your head once a dozen rows
 * exist. Without a preview, an admin's only way to check their work is to open a real contract and
 * infer the answer from the fields, and the answer they most need is for a combination no contract
 * they have to hand happens to be.
 *
 * It calls the **same** `resolve` endpoint the record screen calls, deliberately: a preview with its
 * own copy of the ranking rules would be a second answer to "which configuration wins", and the one
 * place an admin looks to check their work is the last place that should be able to disagree with
 * production.
 *
 * ### What this screen does NOT do yet
 *
 * There is no editor here. Creating and updating rows are `POST`/`PUT` on the same API and the
 * validation is already server-side with RFC 7807 errors — the missing piece is a field-by-field
 * grid with Required auto-checking Visible and non-configurable rows locked, which is real UI work
 * and is stated as absent rather than half-built. Read-and-preview is what makes the configuration
 * already in the database *legible*, which is the part nothing else provides.
 */
export declare class FormConfigAdminPageComponent {
  private readonly source;
  /** Bumped after a deactivate, and by Retry, so the list genuinely re-reads. */
  private readonly attempt;
  protected readonly listState: import("@angular/core").WritableSignal<RemoteData<FormConfigListResponse>>;
  protected readonly rows: import("@angular/core").Signal<readonly FormConfigRow[]>;
  /**
   * Whether the rows came from a durable store.
   *
   * Said out loud for the same reason the grid names its data origin: no deployed environment has a
   * connection string today, so the honest answer is usually "in memory, gone on restart" — and an
   * admin who saves a configuration that vanishes on the next deploy without being told is owed an
   * explanation nobody can give them afterwards.
   */
  protected readonly storeOrigin: import("@angular/core").Signal<string | null>;
  protected readonly notDurable: import("@angular/core").Signal<boolean>;
  protected previewType: string;
  protected previewLocation: string;
  protected previewCommodity: string;
  protected previewContract: string;
  protected readonly previewState: import("@angular/core").WritableSignal<RemoteData<FormConfigPreview> | null>;
  /** What the preview resolved to, or null before anything has been previewed. */
  protected readonly preview: import("@angular/core").Signal<FormConfigPreview | null>;
  /**
   * The provenance sentence — the answer the tool exists to give.
   *
   * Says which dimensions matched rather than only the rank number: "rank 4" is meaningless to
   * anybody who has not read §6, and "matched this location and this commodity" is the same fact in
   * a form that needs no reference.
   */
  protected readonly previewProvenance: import("@angular/core").Signal<string | null>;
  /** Required fields in the resolved configuration, which is what an admin most often checks. */
  protected readonly previewRequired: import("@angular/core").Signal<readonly string[]>;
  /** Fields the resolved configuration hides — the other half of "what did I actually change?". */
  protected readonly previewHidden: import("@angular/core").Signal<readonly string[]>;
  /**
   * The tabs the preview reports.
   *
   * 🔴 **Runs the same cascade the record screen runs** (F8.3, ruled 2026-09-24): a tab whose every
   * section is hidden is dropped here too. This filtered on `tab.visible` alone, which made the
   * preview *confidently wrong* — it promised a tab the record screen was about to drop, and a
   * preview that disagrees with the thing it previews is worse than no preview.
   */
  protected readonly previewTabs: import("@angular/core").Signal<readonly string[]>;
  /**
   * Which row's history is open, or `null`. One at a time: the trail is fetched on demand rather
   * than with the list, because a list of 50 rows would otherwise pull 50 full document histories
   * to render 50 collapsed summaries nobody has opened.
   */
  protected readonly auditRowId: import("@angular/core").WritableSignal<number | null>;
  protected readonly auditState: import("@angular/core").WritableSignal<RemoteData<FormConfigAuditTrail>>;
  /**
   * The failure message, or empty.
   *
   * A computed rather than two `auditState()` reads in the template: narrowing does not survive
   * between two calls of the same signal, so the template form does not compile — and the shape
   * that would have compiled (`$any`) would have suppressed the check rather than satisfied it.
   */
  protected readonly auditError: import("@angular/core").Signal<string>;
  /**
   * The trail as the screen renders it: newest first, each entry paired with the diff against its
   * predecessor.
   *
   * 🔴 **The pairing happens BEFORE the reversal, and the order of those two steps is the whole
   * correctness of this screen.** The server serves oldest-first because the *before* of entry
   * *n* is entry *n−1*; reversing first and then pairing would diff every entry against its
   * successor and report every change backwards, with nothing to say so.
   */
  protected readonly auditEntries: import("@angular/core").Signal<{
    entry: import("@cws/domain-contracts").FormConfigAuditEntry;
    isOldest: boolean;
    changes: readonly import("@cws/domain-contracts").ConfigChange[];
  }[]>;
  protected toggleAudit(row: FormConfigRow): void;
  /**
   * What the editor is open on: `null` closed, `'new'` creating, or the row being edited.
   *
   * A loaded row rather than an id, because the editor needs the row's full document *and* its
   * `rowVersion` — and fetching them here keeps the concurrency token on the same read the admin
   * is looking at, which is what makes the 409 mean "someone changed it since you opened it".
   */
  protected readonly editorState: import("@angular/core").WritableSignal<FormConfigDetail | "closed" | "new">;
  protected readonly editorOpen: import("@angular/core").Signal<boolean>;
  protected readonly editingRow: import("@angular/core").Signal<FormConfigDetail | null>;
  protected readonly loadingEditor: import("@angular/core").WritableSignal<boolean>;
  protected startNew(): void;
  protected edit(row: FormConfigRow): void;
  protected closeEditor(): void;
  /** After a save: close, reload the list, and drop any stale preview. */
  protected onSaved(): void;
  constructor();
  protected reload(): void;
  protected runPreview(): void;
  /** Deactivates a row and reloads, so the list cannot show a row that is no longer active. */
  protected deactivate(row: FormConfigRow): void;
  /** `Any` rather than a blank cell — a null dimension means "applies to everything". */
  protected dimension(value: string | null): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormConfigAdminPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormConfigAdminPageComponent, "cms-form-config-admin-page", never, {}, {}, never, never, true, never>;
}
/** One editable field row, joined from the registry and the document being edited. */
interface EditorField {
  readonly componentName: string;
  readonly label: string;
  readonly ctrmField: string;
  /** CTRM refuses this on a write — it can never be required, and the row says why. */
  readonly ctrmReadOnly: boolean;
  /** A driver or the contract number: visibility and requiredness are not the admin's to change. */
  readonly locked: boolean;
  readonly behaviour: ConfigFieldBehaviour;
}
/** Fields grouped as the layout groups them, so the grid reads like the screen it configures. */
interface EditorSection {
  readonly id: string;
  readonly label: string;
  readonly tab: string;
  readonly fields: readonly EditorField[];
}
/**
 * **The form-configuration editor** — what turns ADR-17 from an engine into something an
 * administrator can use.
 *
 * ### What it is for
 *
 * Everything else in this feature reads: the list says what rows exist, the preview says which one
 * wins. Neither lets anybody *change* what a contract form does. This does, and until it existed
 * the only way to author a configuration row was a raw authenticated API call.
 *
 * ### The three rules it enforces in the UI, and why each is here rather than only server-side
 *
 * The server validates all of §5.1 and refuses a bad document with reasons — that is the
 * authority and this component does not duplicate it. What it does is stop an administrator
 * *composing* a document the server will refuse, because a save that bounces is a worse experience
 * than a control that will not let you do the wrong thing:
 *
 * 1. **Required auto-checks Visible and locks it** (rule 2). A field the user must fill cannot be
 *    one they cannot see, so ticking Required ticks Visible and disables it — the relationship is
 *    visible in the control rather than discovered at save.
 * 2. **A CTRM read-only field cannot be Required** (rule 4). `upsertContract` refuses those fields
 *    outright, so requiring one would demand something the user is unable to supply. The checkbox
 *    is disabled and the row says which CTRM field refuses it.
 * 3. **Driver fields and the contract number are locked** (rule 3 / D9). Hiding the field
 *    resolution keys on would make the configuration unreachable from the screen that needs it.
 *
 * ### 🔑 "Copy from what currently resolves" is the default, not a convenience
 *
 * A new row starts from **whatever configuration currently applies to the dimensions being
 * entered** — which is what the admin is about to specialise. Starting from blank would mean
 * every new row began by hiding all 111 fields, and starting from the seed would silently discard
 * whatever a less specific row already established. Whole-config-wins (D5) makes this load-bearing
 * rather than nice: the row being written replaces its parent entirely, so it has to *begin* as
 * its parent or the difference is invisible to the person making it.
 */
export declare class FormConfigEditorComponent implements OnInit {
  private readonly source;
  /** The row to edit, or `null` to create a new one. */
  readonly editing: import("@angular/core").InputSignal<FormConfigDetail | null>;
  /** Raised after a successful save, so the list reloads and the editor closes. */
  readonly saved: import("@angular/core").OutputEmitterRef<void>;
  /** Raised on Cancel. */
  readonly cancelled: import("@angular/core").OutputEmitterRef<void>;
  protected contractTypeClass: string;
  protected locationCode: string;
  protected commodityCode: string;
  protected effectiveFrom: string;
  protected autoCalculationMode: string;
  protected pendingContractsEnabled: boolean;
  /** The trade unit typed into the seed box. */
  protected seedTradeUnit: string;
  /**
   * The row this new configuration was seeded from, or `null` when it was not.
   *
   * 🔴 **Carries the source's `rowVersion`, and that is the point of keeping it.** `POST
   * /form-configurations` does not evaluate `If-Match` — it has no source to be stale against — so
   * the guard against cloning a source that changed after it was copied lives here: {@link save}
   * reads the source again and compares this token, the same opaque value `If-Match` carries on an
   * update, before it creates anything.
   */
  protected readonly seededFrom: import("@angular/core").WritableSignal<{
    readonly id: number;
    readonly rowVersion: string;
    readonly tradeUnit: string;
    readonly dimensionKey: string;
    readonly version: number;
  } | null>;
  /** Why a seed was refused, or `null`. Not {@link error}: nothing was saved or failed to save. */
  protected readonly seedNotice: import("@angular/core").WritableSignal<string | null>;
  /**
   * The seeded row's own sections, so the copy keeps them exactly.
   *
   * ⚠ Only set by a seed. Editing an existing row and a plain new row keep the registry's sections
   * with this row's visibility — the behaviour they had before seeding existed.
   */
  private readonly baseSections;
  /**
   * Which starting point is current. Every load of one — the open-time resolve, "Copy from what
   * currently applies", a seed — takes the next number, and an answer is adopted only if its number
   * is still current.
   *
   * 🔴 **Without it a slow resolve overwrites a seed.** A new row resolves as it opens; over HTTP
   * that answer can land after the administrator has seeded, and adopting it would replace the
   * seeded settings with the parent's while the screen still said "Seeded from trade unit …".
   */
  private startingPoint;
  protected readonly saving: import("@angular/core").WritableSignal<boolean>;
  protected readonly error: import("@angular/core").WritableSignal<RemoteError | null>;
  /**
   * Field search, because 111 rows across 11 sections is not a list you scroll.
   *
   * 🔴 **A signal, and it was a plain property until 2026-09-23 — which meant the search had never
   * worked.** `sections()` is a `computed` reading this; a computed over a non-signal caches on
   * first evaluation and is never invalidated, so typing re-ran change detection, the template
   * called `sections()`, and got the same cached list back every time. The box accepted input and
   * filtered nothing.
   *
   * ⚠ **Nothing caught it because nothing tested it** — the screen looks completely normal, since a
   * filter that matches everything and a filter that is ignored render identically. It surfaced only
   * when the reorder guard needed to react to the same field and its banner would not appear.
   *
   * ⚠ Bound as `[ngModel]` + `(ngModelChange)` rather than the banana-in-a-box: `[(ngModel)]` writes
   * through to the property, which would replace the signal with a string.
   */
  protected readonly filter: import("@angular/core").WritableSignal<string>;
  private readonly registry;
  private readonly behaviours;
  private readonly tabs;
  protected readonly ready: import("@angular/core").Signal<boolean>;
  protected readonly isNew: import("@angular/core").Signal<boolean>;
  /**
   * 🔴 The registry fetch is here and NOT in the constructor, and that is a correctness fix
   * rather than a style preference.
   *
   * Signal inputs are not populated during construction. With an HTTP registry the response always
   * arrives after the input is set, so seeding from the constructor LOOKED correct — but a
   * synchronous source (a test stub, or a cached response) seeded before {@link editing} existed,
   * so the editor silently opened a blank NEW row while claiming to edit an existing one. That is
   * the same shape as the 2026-09-01 defect where synchronous mocks could not express a real
   * ordering race; here the mock exposed it instead.
   */
  ngOnInit(): void;
  /**
   * The editable tab list.
   *
   * Tabs are configuration (D7) — this is what replaces the legacy app's per-location BIO/FOG tabs,
   * which were `If(location = 4090)` conditionals in a template. Label and visibility are editable;
   * the id is not, because sections reference it.
   */
  protected readonly editableTabs: import("@angular/core").Signal<readonly ConfigTab[]>;
  /**
   * Section enablement per trade unit (F8.3).
   *
   * 🔴 **Held as editable state, where `save()` used to submit `registry.sections` verbatim.** That
   * pass-through is why nothing could turn a section off: the document has carried
   * `sections[].visible` since ADR-17 and the resolve projection has always emitted it, so the
   * storage and the consumer were both ready and only the editor was writing the seed's answer back
   * over the administrator's.
   *
   * ⚠ **A hidden section does NOT hide its tab, and that is the current behaviour rather than a
   * decision this makes.** The record screen filters tabs on `tab.visible` alone, so hiding every
   * section on a tab leaves the tab present and empty. {@link emptyTabWarning} surfaces that state
   * instead of pretending it cannot happen — see its own note.
   */
  protected readonly sectionVisibility: import("@angular/core").WritableSignal<Readonly<Record<string, boolean>>>;
  /** Toggles one section on or off for this configuration row. */
  protected toggleSection(sectionId: string, visible: boolean): void;
  /**
   * Whether a section is on, for the template.
   *
   * Reads the registry's own default when this row has said nothing, so a section added to the
   * layout after the row was written shows its layout state rather than defaulting to hidden.
   */
  protected sectionVisible(sectionId: string): boolean;
  /** The sections as they will be stored — the registry's, carrying this row's visibility. */
  protected readonly editableSections: import("@angular/core").Signal<{
    visible: boolean;
    id: string;
    label: string;
    tab: string;
    order: number;
  }[]>;
  /**
   * Tabs left with no visible section, named.
   *
   * ✅ **RULED 2026-09-24 (JFrisbie): it cascades.** The record screen and the preview tool both
   * drop an emptied tab now, so this is no longer a warning standing in for a decision — it tells
   * the administrator what *will* happen, at the moment they cause it.
   *
   * 🔑 **The predicate is {@link emptiedTabs}, shared with both of them rather than copied.** That
   * is what makes this message and the record screen's behaviour the same statement: a warning
   * computed from its own second copy of the rule could say "Shipping will be hidden" about a tab
   * the record screen kept, and nothing would report the disagreement. The Remarks guard lives
   * there too.
   */
  protected readonly emptyTabWarning: import("@angular/core").Signal<string | null>;
  /** The field grid, grouped by section and narrowed by the search box. */
  protected readonly sections: import("@angular/core").Signal<readonly EditorSection[]>;
  /**
   * Why reorder is unavailable right now, or `null` when it is available.
   *
   * 🔴 **Reorder is refused while the search box has content, and that is a correctness guard rather
   * than caution.** The grid shows a *filtered* section; "move up" against a filtered list either
   * swaps with the row above on screen — which is not the row above in the document — or silently
   * jumps the field past rows the administrator cannot see. Both write an order nobody chose.
   *
   * Refusing with a stated reason is the honest third option, and it is cheap to satisfy: clear the
   * search and the buttons come back.
   */
  protected readonly reorderBlockedReason: import("@angular/core").Signal<"Clear the search to reorder — moving a field while the list is filtered would place it against rows you cannot see." | null>;
  /**
   * Moves a field one place within its section — **the keyboard path**.
   *
   * Renumbering and the full-membership rule live in {@link applyOrder} and {@link orderedIn}, shared
   * with the drag ({@link placeField}), so the two gestures cannot disagree about what a move writes.
   */
  protected moveField(sectionId: string, componentName: string, delta: -1 | 1): void;
  /**
   * Moves a field to the position of another in the same section — **the drag** (F8.1).
   *
   * 🔑 **The same persistence path as the arrows, on purpose.** It computes a new sequence and hands
   * it to {@link applyOrder}, which is the one place a section is renumbered; the arrows do exactly
   * the same. So a drag and the equivalent key presses produce the same document, the save goes
   * through the same `If-Match` update, and there is no second renumbering rule to drift.
   *
   * The semantics are the export field picker's: the dragged field takes the target row's index, so
   * dropping on the last row makes it last and dropping on the first makes it first.
   */
  protected placeField(sectionId: string, componentName: string, onto: string): void;
  /**
   * A section's FULL membership in its current order, or `null` when reorder is unavailable.
   *
   * ⚠ Full membership, not the rendered rows. They are the same list while
   * {@link reorderBlockedReason} is null, which is the only time this answers, but taking the full
   * list means a future caller cannot reintroduce the filtered-reorder bug by accident.
   */
  private orderedIn;
  /**
   * Writes a section's new sequence, renumbered contiguously from 1.
   *
   * ⚠ **Renumbers the whole section rather than swapping two numbers.** The seed's orders are not
   * guaranteed dense or unique — they are the layout's, and nothing has ever required them to be —
   * so a swap can be a no-op between two fields that share a number, which reads on screen as the
   * control doing nothing. Renumbering from the resulting sequence makes the write describe exactly
   * what the grid shows.
   */
  private applyOrder;
  /** The field being dragged, so its row can show it. */
  protected readonly draggingField: import("@angular/core").WritableSignal<string | null>;
  /** The row the dragged field would land on, or `null` when the pointer is over no valid target. */
  protected readonly dropField: import("@angular/core").WritableSignal<string | null>;
  /** The section the drag began in; a drop is only valid inside it. */
  private dragSection;
  /**
   * **The drag, through the shared gesture** — never a copy of it (Known Issue 44).
   *
   * `PointerDragGesture` is the filter chip row's pointer implementation, extracted into shared-ui:
   * pointer events rather than HTML5 drag-and-drop, window listeners only while a press is followed,
   * and every way out (release, `pointercancel`, Escape, losing the window) ending it. What is here
   * is only what is specific to these rows — the grip names a field, a row names a drop — and the
   * rows' container carries `select-none`, which the gesture cannot apply for us.
   *
   * ⚠ The grip is only rendered while {@link reorderBlockedReason} is null, so a filtered list offers
   * nothing to press; {@link placeField} checks again regardless.
   */
  private readonly gesture;
  constructor();
  /** Bound on the rows' container, so it sees a press on any grip. */
  protected onRowPointerDown(event: PointerEvent): void;
  /**
   * The field that moved last, so the row can announce itself and keep focus.
   *
   * Without it a keyboard user presses the button, the list re-sorts under them, and focus lands
   * wherever the DOM happens to put it — which on a 111-row grid means losing your place entirely.
   */
  protected readonly movedField: import("@angular/core").WritableSignal<string | null>;
  /** Counts for the summary line, so an admin can see what they have done at a glance. */
  protected readonly requiredCount: import("@angular/core").Signal<number>;
  protected readonly hiddenCount: import("@angular/core").Signal<number>;
  /**
   * Ticks Required, and ticks Visible with it.
   *
   * Rule 2 made visible in the control rather than discovered at save: the server rejects
   * `required: true, visible: false` rather than silently fixing it, precisely so a document
   * always says what its author meant — which only works if the author cannot express the
   * contradiction.
   */
  protected setRequired(componentName: string, required: boolean): void;
  protected setVisible(componentName: string, visible: boolean): void;
  protected setFlag(componentName: string, flag: 'readOnly' | 'borderWarning' | 'excludeFromCopy' | 'excludeFromTemplateCopy', value: boolean): void;
  protected setTabVisible(id: string, visible: boolean): void;
  protected setTabLabel(id: string, label: string): void;
  /**
   * Loads whatever currently resolves for the dimensions typed in, as the starting point.
   *
   * Offered as a button as well as on open, because the dimensions can change after the editor is
   * open and the sensible starting point changes with them.
   */
  protected copyFromCurrent(): void;
  protected save(): void;
  /** Follows a create or update to its end. */
  private submit;
  /**
   * **Seeds this new row from another trade unit's configuration** (F8.1).
   *
   * Two reads, and both are needed. The resolve endpoint answers *which* row wins for the source
   * trade unit — the same answer the record screen gets, so "that trade unit's configuration" means
   * what its users actually see. Then that row is read whole, because the resolve payload carries
   * only visible/required/read-only per field and no order: seeding from it would silently reset the
   * other three flags and the whole field order.
   *
   * The type and commodity typed for the new row are kept for the source's resolve, so seeding a
   * CORN row copies the source's CORN configuration rather than its all-commodities one.
   */
  protected seedFromTradeUnit(): void;
  /**
   * Takes a stored row's document as this row's starting point, wholesale.
   *
   * 🔴 **Nothing is re-derived.** Tabs, sections, fields (in the source's own key order) and
   * attributes are the source's, so the document saved is byte-identical to the source's except the
   * dimensions it is saved under. Registry fields the source predates are completed at their
   * defaults, the same rule every stored row gets on read (§5.1 rule 7).
   */
  private adoptSeed;
  protected cancel(): void;
  /** Seeds the form: an existing row's own document, or the current resolution for a new one. */
  private seed;
  private completeFrom;
  private toEditorField;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormConfigEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormConfigEditorComponent, "cms-form-config-editor", never, {
    "editing": {
      "alias": "editing";
      "required": false;
      "isSignal": true;
    };
  }, {
    "saved": "saved";
    "cancelled": "cancelled";
  }, never, never, true, never>;
}
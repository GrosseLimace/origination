import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, computed, inject, input, output, signal } from "@angular/core";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import * as i1 from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { ADDENDUM_DATE_ANCHOR, ADDENDUM_INITIALS_ANCHOR, ADDENDUM_SIGNATURE_ANCHOR, ADDENDUM_TEMPLATE_SOURCE, CONTRACTS_API_URL, FORM_CONFIG_ADMIN_SOURCE, addendumAnchorProblems, diffConfigDocuments, emptiedTabs, tabsAfterCascade } from "@cws/domain-contracts";
import { AsyncContainerComponent, DateInputComponent, PageHeaderComponent, PointerDragGesture, elementUnder, injectConfirm, remoteLoading } from "@cws/shared-ui";
import { HttpClient } from "@angular/common/http";
var AddendumTemplatesPageComponent = class AddendumTemplatesPageComponent {
	source = inject(ADDENDUM_TEMPLATE_SOURCE, { optional: true });
	confirm = injectConfirm();
	destroyRef = inject(DestroyRef);
	anchors = [
		ADDENDUM_SIGNATURE_ANCHOR,
		ADDENDUM_DATE_ANCHOR,
		ADDENDUM_INITIALS_ANCHOR
	];
	offered = this.source !== null;
	state = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	unavailableReason = computed(() => {
		const state = this.state();
		return state.status === "unavailable" ? state.reason : null;
	}, ...ngDevMode ? [{ debugName: "unavailableReason" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const state = this.state();
		return state.status === "failed" ? state : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	templates = signal([], ...ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []);
	editor = signal(null, ...ngDevMode ? [{ debugName: "editor" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	anchorProblems = signal([], ...ngDevMode ? [{ debugName: "anchorProblems" }] : /* istanbul ignore next */ []);
	actionError = signal(null, ...ngDevMode ? [{ debugName: "actionError" }] : /* istanbul ignore next */ []);
	constructor() {
		this.load();
	}
	load() {
		const source = this.source;
		if (source === null) return;
		this.state.set({ status: "loading" });
		source.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") {
				this.templates.set(answer.value);
				this.state.set({ status: "loaded" });
			} else if (answer.kind === "unavailable") this.state.set({
				status: "unavailable",
				reason: answer.reason
			});
			else this.state.set({
				status: "failed",
				message: answer.message,
				...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
			});
		});
	}
	startCreate() {
		this.open({
			id: null,
			version: null,
			name: "",
			family: "B",
			tradeUnits: "",
			templateContent: "",
			fieldMapJson: "{}",
			active: true
		});
	}
	startEdit(template) {
		this.open({
			id: template.id,
			version: template.version,
			name: template.name,
			family: template.family,
			tradeUnits: template.tradeUnits.join(", "),
			templateContent: template.templateContent,
			fieldMapJson: template.fieldMapJson,
			active: template.active
		});
	}
	cancelEdit() {
		this.editor.set(null);
		this.anchorProblems.set([]);
		this.actionError.set(null);
	}
	save() {
		const editor = this.editor();
		const source = this.source;
		if (editor === null || source === null) return;
		const problems = addendumAnchorProblems(editor.templateContent);
		this.anchorProblems.set(problems);
		this.actionError.set(editor.name.trim() === "" ? "A template needs a name." : null);
		if (problems.length > 0 || editor.name.trim() === "") return;
		const draft = {
			name: editor.name.trim(),
			family: editor.family,
			tradeUnits: editor.tradeUnits.split(",").map((unit) => unit.trim()).filter((unit) => unit !== ""),
			templateContent: editor.templateContent,
			fieldMapJson: editor.fieldMapJson,
			active: editor.active
		};
		this.run(editor.id === null ? source.create(draft) : source.update(editor.id, draft), () => this.editor.set(null));
	}
	deactivate(template) {
		const source = this.source;
		if (source !== null) this.run(source.deactivate(template));
	}
	remove(template) {
		const source = this.source;
		if (source === null) return;
		this.confirm({
			title: "Delete this addendum template?",
			message: `"${template.name}" will be deleted and can no longer be used to generate an addendum. Deactivate it instead to keep it and its history.`,
			confirmLabel: "Delete template",
			cancelLabel: "Keep template",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) this.run(source.remove(template.id));
		});
	}
	tradeUnitsLabel(template) {
		return template.tradeUnits.length === 0 ? "All" : template.tradeUnits.join(", ");
	}
	open(editor) {
		this.editor.set(editor);
		this.anchorProblems.set([]);
		this.actionError.set(null);
	}
	run(request, onDone) {
		this.busy.set(true);
		this.actionError.set(null);
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.busy.set(false);
			if (answer.kind === "done") {
				onDone?.();
				this.load();
			} else if (answer.kind === "unavailable") this.actionError.set(answer.reason);
			else this.actionError.set(answer.message);
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AddendumTemplatesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: AddendumTemplatesPageComponent,
		isStandalone: true,
		selector: "cws-addendum-templates-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\" aria-labelledby=\"addendum-templates-heading\">\r\n  <header class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n    <div class=\"cws:space-y-1\">\r\n      <h3 id=\"addendum-templates-heading\" class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        Addendum templates\r\n      </h3>\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        The documents generated for the in-house addendums: minimum price with a call, min/max and\r\n        premium advance. Templates are used exactly as Legal approved them, and every one must carry\r\n        the signature, date and initials anchors the signing service looks for.\r\n      </p>\r\n    </div>\r\n    @if (offered && state().status === 'loaded' && editor() === null) {\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy()\" (click)=\"startCreate()\">\r\n        New template\r\n      </button>\r\n    }\r\n  </header>\r\n\r\n  @if (!offered) {\r\n    <!-- A host that embeds the admin screen without the template seam. Said, not left blank. -->\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-not-offered\">\r\n      Addendum templates are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (state().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading templates…</p>\r\n      }\r\n      @case ('unavailable') {\r\n        <!--\r\n          🔴 The routes are wired before the backend publishes them. A 404 lands here and says so; an\r\n          empty table would read as \"no templates exist\", which a missing route cannot claim.\r\n        -->\r\n        <div class=\"scoular-alert scoular-alert-info\" data-testid=\"templates-unavailable\">\r\n          <div class=\"scoular-alert-title\">Not available yet</div>\r\n          <div class=\"scoular-alert-description\">{{ unavailableReason() }}</div>\r\n        </div>\r\n      }\r\n      @case ('failed') {\r\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n          {{ failure()?.message }}\r\n          @if (failure()?.correlationId; as id) {\r\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n          }\r\n        </p>\r\n      }\r\n      @case ('loaded') {\r\n        @if (templates().length === 0) {\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-empty\">\r\n            No addendum templates yet.\r\n          </p>\r\n        } @else {\r\n          <table class=\"cws:w-full cws:text-left cws:text-xs\">\r\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n              <tr>\r\n                <th class=\"cws:py-1\">Name</th>\r\n                <th class=\"cws:py-1\">Family</th>\r\n                <th class=\"cws:py-1\">Trade units</th>\r\n                <th class=\"cws:py-1\">Version</th>\r\n                <th class=\"cws:py-1\">Active</th>\r\n                <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\r\n              </tr>\r\n            </thead>\r\n            <tbody data-testid=\"templates-rows\">\r\n              @for (template of templates(); track template.id) {\r\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                  <td class=\"cws:py-1\">{{ template.name }}</td>\r\n                  <td class=\"cws:py-1\">{{ template.family }}</td>\r\n                  <td class=\"cws:py-1\">{{ tradeUnitsLabel(template) }}</td>\r\n                  <td class=\"cws:py-1 cws:tabular-nums\">{{ template.version }}</td>\r\n                  <td class=\"cws:py-1\">{{ template.active ? 'Yes' : 'No' }}</td>\r\n                  <td class=\"cws:py-1\">\r\n                    <div class=\"cws:flex cws:justify-end cws:gap-2\">\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn scoular-btn-secondary\"\r\n                        [attr.aria-label]=\"'Edit ' + template.name\"\r\n                        [disabled]=\"busy()\"\r\n                        (click)=\"startEdit(template)\"\r\n                      >\r\n                        Edit\r\n                      </button>\r\n                      @if (template.active) {\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-secondary\"\r\n                          [attr.aria-label]=\"'Deactivate ' + template.name\"\r\n                          [disabled]=\"busy()\"\r\n                          (click)=\"deactivate(template)\"\r\n                        >\r\n                          Deactivate\r\n                        </button>\r\n                      }\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn scoular-btn-danger\"\r\n                        [attr.aria-label]=\"'Delete ' + template.name\"\r\n                        [disabled]=\"busy()\"\r\n                        (click)=\"remove(template)\"\r\n                      >\r\n                        Delete\r\n                      </button>\r\n                    </div>\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        }\r\n      }\r\n    }\r\n\r\n    @if (editor(); as draft) {\r\n      <form\r\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n        aria-label=\"Addendum template\"\r\n        (ngSubmit)=\"save()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n          @if (draft.id === null) { New template } @else { Edit template, version {{ draft.version }} }\r\n        </h4>\r\n\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Name</span>\r\n            <input class=\"scoular-form-input cws:mt-1 cws:w-56\" name=\"name\" [(ngModel)]=\"draft.name\" />\r\n          </label>\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Family</span>\r\n            <select class=\"scoular-form-input cws:mt-1 cws:w-40\" name=\"family\" [(ngModel)]=\"draft.family\">\r\n              <option value=\"B\">B (in-house)</option>\r\n              <option value=\"A\">A (StoneX)</option>\r\n            </select>\r\n          </label>\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Trade units</span>\r\n            <input\r\n              class=\"scoular-form-input cws:mt-1 cws:w-40\"\r\n              name=\"tradeUnits\"\r\n              placeholder=\"Blank for all, or 0210, 2087\"\r\n              [(ngModel)]=\"draft.tradeUnits\"\r\n            />\r\n          </label>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pb-2 cws:text-xs\">\r\n            <input type=\"checkbox\" name=\"active\" [(ngModel)]=\"draft.active\" />\r\n            Active\r\n          </label>\r\n        </div>\r\n\r\n        <label class=\"cws:block cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template content</span>\r\n          <textarea\r\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\r\n            rows=\"12\"\r\n            name=\"templateContent\"\r\n            [(ngModel)]=\"draft.templateContent\"\r\n            [attr.aria-invalid]=\"anchorProblems().length > 0\"\r\n            aria-describedby=\"addendum-template-anchors\"\r\n          ></textarea>\r\n        </label>\r\n\r\n        <!--\r\n          🔴 Beside the content field, because that is where the fix goes. Each reason names the\r\n          anchor to add, so an administrator pasting in Legal's text knows what is missing rather than\r\n          being told only that something is.\r\n        -->\r\n        <div id=\"addendum-template-anchors\" class=\"cws:space-y-1 cws:text-xs\">\r\n          @if (anchorProblems().length > 0) {\r\n            <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"anchor-problems\">\r\n              @for (problem of anchorProblems(); track problem) {\r\n                <li>{{ problem }}</li>\r\n              }\r\n            </ul>\r\n          } @else {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Required anchors:\r\n              @for (anchor of anchors; track anchor; let last = $last) {\r\n                <code class=\"cws:font-mono\">{{ anchor }}</code>@if (!last) {, }\r\n              }\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        <label class=\"cws:block cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Field map (JSON)</span>\r\n          <textarea\r\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\r\n            rows=\"4\"\r\n            name=\"fieldMapJson\"\r\n            [(ngModel)]=\"draft.fieldMapJson\"\r\n          ></textarea>\r\n        </label>\r\n\r\n        @if (actionError(); as message) {\r\n          <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n            {{ message }}\r\n          </p>\r\n        }\r\n\r\n        <div class=\"cws:flex cws:gap-2\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy()\">\r\n            {{ busy() ? 'Saving…' : 'Save template' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\r\n        </div>\r\n      </form>\r\n    } @else if (actionError(); as message) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ message }}\r\n      </p>\r\n    }\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: AddendumTemplatesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-addendum-templates-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormsModule],
			template: "<section class=\"cws:space-y-4\" aria-labelledby=\"addendum-templates-heading\">\r\n  <header class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n    <div class=\"cws:space-y-1\">\r\n      <h3 id=\"addendum-templates-heading\" class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n        Addendum templates\r\n      </h3>\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        The documents generated for the in-house addendums: minimum price with a call, min/max and\r\n        premium advance. Templates are used exactly as Legal approved them, and every one must carry\r\n        the signature, date and initials anchors the signing service looks for.\r\n      </p>\r\n    </div>\r\n    @if (offered && state().status === 'loaded' && editor() === null) {\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy()\" (click)=\"startCreate()\">\r\n        New template\r\n      </button>\r\n    }\r\n  </header>\r\n\r\n  @if (!offered) {\r\n    <!-- A host that embeds the admin screen without the template seam. Said, not left blank. -->\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-not-offered\">\r\n      Addendum templates are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (state().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading templates…</p>\r\n      }\r\n      @case ('unavailable') {\r\n        <!--\r\n          🔴 The routes are wired before the backend publishes them. A 404 lands here and says so; an\r\n          empty table would read as \"no templates exist\", which a missing route cannot claim.\r\n        -->\r\n        <div class=\"scoular-alert scoular-alert-info\" data-testid=\"templates-unavailable\">\r\n          <div class=\"scoular-alert-title\">Not available yet</div>\r\n          <div class=\"scoular-alert-description\">{{ unavailableReason() }}</div>\r\n        </div>\r\n      }\r\n      @case ('failed') {\r\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n          {{ failure()?.message }}\r\n          @if (failure()?.correlationId; as id) {\r\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n          }\r\n        </p>\r\n      }\r\n      @case ('loaded') {\r\n        @if (templates().length === 0) {\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-empty\">\r\n            No addendum templates yet.\r\n          </p>\r\n        } @else {\r\n          <table class=\"cws:w-full cws:text-left cws:text-xs\">\r\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n              <tr>\r\n                <th class=\"cws:py-1\">Name</th>\r\n                <th class=\"cws:py-1\">Family</th>\r\n                <th class=\"cws:py-1\">Trade units</th>\r\n                <th class=\"cws:py-1\">Version</th>\r\n                <th class=\"cws:py-1\">Active</th>\r\n                <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\r\n              </tr>\r\n            </thead>\r\n            <tbody data-testid=\"templates-rows\">\r\n              @for (template of templates(); track template.id) {\r\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                  <td class=\"cws:py-1\">{{ template.name }}</td>\r\n                  <td class=\"cws:py-1\">{{ template.family }}</td>\r\n                  <td class=\"cws:py-1\">{{ tradeUnitsLabel(template) }}</td>\r\n                  <td class=\"cws:py-1 cws:tabular-nums\">{{ template.version }}</td>\r\n                  <td class=\"cws:py-1\">{{ template.active ? 'Yes' : 'No' }}</td>\r\n                  <td class=\"cws:py-1\">\r\n                    <div class=\"cws:flex cws:justify-end cws:gap-2\">\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn scoular-btn-secondary\"\r\n                        [attr.aria-label]=\"'Edit ' + template.name\"\r\n                        [disabled]=\"busy()\"\r\n                        (click)=\"startEdit(template)\"\r\n                      >\r\n                        Edit\r\n                      </button>\r\n                      @if (template.active) {\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-secondary\"\r\n                          [attr.aria-label]=\"'Deactivate ' + template.name\"\r\n                          [disabled]=\"busy()\"\r\n                          (click)=\"deactivate(template)\"\r\n                        >\r\n                          Deactivate\r\n                        </button>\r\n                      }\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn scoular-btn-danger\"\r\n                        [attr.aria-label]=\"'Delete ' + template.name\"\r\n                        [disabled]=\"busy()\"\r\n                        (click)=\"remove(template)\"\r\n                      >\r\n                        Delete\r\n                      </button>\r\n                    </div>\r\n                  </td>\r\n                </tr>\r\n              }\r\n            </tbody>\r\n          </table>\r\n        }\r\n      }\r\n    }\r\n\r\n    @if (editor(); as draft) {\r\n      <form\r\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\r\n        aria-label=\"Addendum template\"\r\n        (ngSubmit)=\"save()\"\r\n      >\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n          @if (draft.id === null) { New template } @else { Edit template, version {{ draft.version }} }\r\n        </h4>\r\n\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Name</span>\r\n            <input class=\"scoular-form-input cws:mt-1 cws:w-56\" name=\"name\" [(ngModel)]=\"draft.name\" />\r\n          </label>\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Family</span>\r\n            <select class=\"scoular-form-input cws:mt-1 cws:w-40\" name=\"family\" [(ngModel)]=\"draft.family\">\r\n              <option value=\"B\">B (in-house)</option>\r\n              <option value=\"A\">A (StoneX)</option>\r\n            </select>\r\n          </label>\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Trade units</span>\r\n            <input\r\n              class=\"scoular-form-input cws:mt-1 cws:w-40\"\r\n              name=\"tradeUnits\"\r\n              placeholder=\"Blank for all, or 0210, 2087\"\r\n              [(ngModel)]=\"draft.tradeUnits\"\r\n            />\r\n          </label>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pb-2 cws:text-xs\">\r\n            <input type=\"checkbox\" name=\"active\" [(ngModel)]=\"draft.active\" />\r\n            Active\r\n          </label>\r\n        </div>\r\n\r\n        <label class=\"cws:block cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template content</span>\r\n          <textarea\r\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\r\n            rows=\"12\"\r\n            name=\"templateContent\"\r\n            [(ngModel)]=\"draft.templateContent\"\r\n            [attr.aria-invalid]=\"anchorProblems().length > 0\"\r\n            aria-describedby=\"addendum-template-anchors\"\r\n          ></textarea>\r\n        </label>\r\n\r\n        <!--\r\n          🔴 Beside the content field, because that is where the fix goes. Each reason names the\r\n          anchor to add, so an administrator pasting in Legal's text knows what is missing rather than\r\n          being told only that something is.\r\n        -->\r\n        <div id=\"addendum-template-anchors\" class=\"cws:space-y-1 cws:text-xs\">\r\n          @if (anchorProblems().length > 0) {\r\n            <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"anchor-problems\">\r\n              @for (problem of anchorProblems(); track problem) {\r\n                <li>{{ problem }}</li>\r\n              }\r\n            </ul>\r\n          } @else {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Required anchors:\r\n              @for (anchor of anchors; track anchor; let last = $last) {\r\n                <code class=\"cws:font-mono\">{{ anchor }}</code>@if (!last) {, }\r\n              }\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        <label class=\"cws:block cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Field map (JSON)</span>\r\n          <textarea\r\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\r\n            rows=\"4\"\r\n            name=\"fieldMapJson\"\r\n            [(ngModel)]=\"draft.fieldMapJson\"\r\n          ></textarea>\r\n        </label>\r\n\r\n        @if (actionError(); as message) {\r\n          <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n            {{ message }}\r\n          </p>\r\n        }\r\n\r\n        <div class=\"cws:flex cws:gap-2\">\r\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy()\">\r\n            {{ busy() ? 'Saving…' : 'Save template' }}\r\n          </button>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\r\n        </div>\r\n      </form>\r\n    } @else if (actionError(); as message) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ message }}\r\n      </p>\r\n    }\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => []
});
var FormConfigEditorComponent = class FormConfigEditorComponent {
	source = inject(FORM_CONFIG_ADMIN_SOURCE);
	editing = input(null, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	saved = output();
	cancelled = output();
	contractTypeClass = "";
	locationCode = "";
	commodityCode = "";
	effectiveFrom = "";
	autoCalculationMode = "None";
	pendingContractsEnabled = false;
	seedTradeUnit = "";
	seededFrom = signal(null, ...ngDevMode ? [{ debugName: "seededFrom" }] : /* istanbul ignore next */ []);
	seedNotice = signal(null, ...ngDevMode ? [{ debugName: "seedNotice" }] : /* istanbul ignore next */ []);
	baseSections = signal(null, ...ngDevMode ? [{ debugName: "baseSections" }] : /* istanbul ignore next */ []);
	startingPoint = 0;
	saving = signal(false, ...ngDevMode ? [{ debugName: "saving" }] : /* istanbul ignore next */ []);
	error = signal(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	filter = signal("", ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	registry = signal(null, ...ngDevMode ? [{ debugName: "registry" }] : /* istanbul ignore next */ []);
	behaviours = signal({}, ...ngDevMode ? [{ debugName: "behaviours" }] : /* istanbul ignore next */ []);
	tabs = signal([], ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	ready = computed(() => this.registry() !== null, ...ngDevMode ? [{ debugName: "ready" }] : /* istanbul ignore next */ []);
	isNew = computed(() => this.editing() === null, ...ngDevMode ? [{ debugName: "isNew" }] : /* istanbul ignore next */ []);
	ngOnInit() {
		this.source.registry().subscribe((state) => {
			if (state.status === "loaded") {
				this.registry.set(state.value);
				this.seed();
			} else if (state.status === "error") this.error.set(state.error);
		});
	}
	editableTabs = computed(() => this.tabs(), ...ngDevMode ? [{ debugName: "editableTabs" }] : /* istanbul ignore next */ []);
	sectionVisibility = signal({}, ...ngDevMode ? [{ debugName: "sectionVisibility" }] : /* istanbul ignore next */ []);
	toggleSection(sectionId, visible) {
		this.sectionVisibility.set({
			...this.sectionVisibility(),
			[sectionId]: visible
		});
	}
	sectionVisible(sectionId) {
		return this.sectionVisibility()[sectionId] ?? this.registry()?.sections.find((section) => section.id === sectionId)?.visible ?? true;
	}
	editableSections = computed(() => {
		const registry = this.registry();
		const visibility = this.sectionVisibility();
		const registrySections = registry?.sections ?? [];
		const base = this.baseSections();
		return (base === null ? registrySections : [...base, ...registrySections.filter((section) => !base.some((known) => known.id === section.id))]).map((section) => ({
			...section,
			visible: visibility[section.id] ?? section.visible
		}));
	}, ...ngDevMode ? [{ debugName: "editableSections" }] : /* istanbul ignore next */ []);
	emptyTabWarning = computed(() => {
		const emptied = emptiedTabs(this.tabs(), this.editableSections());
		return emptied.length === 0 ? null : emptied.map((tab) => tab.label).join(", ");
	}, ...ngDevMode ? [{ debugName: "emptyTabWarning" }] : /* istanbul ignore next */ []);
	sections = computed(() => {
		const registry = this.registry();
		if (registry === null) return [];
		const behaviours = this.behaviours();
		const needle = this.filter().trim().toLowerCase();
		return [...registry.sections].sort((left, right) => left.order - right.order).map((section) => ({
			id: section.id,
			label: section.label,
			tab: section.tab,
			fields: Object.entries(registry.fields).filter(([, field]) => field.section === section.id).filter(([componentName, field]) => needle === "" || componentName.toLowerCase().includes(needle) || field.label.toLowerCase().includes(needle) || field.ctrmField.toLowerCase().includes(needle)).map(([componentName, field]) => this.toEditorField(componentName, field, behaviours[componentName])).sort((left, right) => left.behaviour.order - right.behaviour.order)
		})).filter((section) => section.fields.length > 0);
	}, ...ngDevMode ? [{ debugName: "sections" }] : /* istanbul ignore next */ []);
	reorderBlockedReason = computed(() => this.filter().trim() === "" ? null : "Clear the search to reorder — moving a field while the list is filtered would place it against rows you cannot see.", ...ngDevMode ? [{ debugName: "reorderBlockedReason" }] : /* istanbul ignore next */ []);
	moveField(sectionId, componentName, delta) {
		const ordered = this.orderedIn(sectionId);
		if (ordered === null) return;
		const from = ordered.indexOf(componentName);
		const to = from + delta;
		if (from === -1 || to < 0 || to >= ordered.length) return;
		ordered.splice(to, 0, ...ordered.splice(from, 1));
		this.applyOrder(ordered, componentName);
	}
	placeField(sectionId, componentName, onto) {
		const ordered = this.orderedIn(sectionId);
		if (ordered === null) return;
		const from = ordered.indexOf(componentName);
		const to = ordered.indexOf(onto);
		if (from === -1 || to === -1 || from === to) return;
		ordered.splice(to, 0, ...ordered.splice(from, 1));
		this.applyOrder(ordered, componentName);
	}
	orderedIn(sectionId) {
		const registry = this.registry();
		if (this.reorderBlockedReason() !== null || registry === null) return null;
		const behaviours = this.behaviours();
		return Object.entries(registry.fields).filter(([, field]) => field.section === sectionId).map(([name, field]) => ({
			name,
			order: behaviours[name]?.order ?? field.order
		})).sort((left, right) => left.order - right.order).map((entry) => entry.name);
	}
	applyOrder(ordered, moved) {
		const behaviours = { ...this.behaviours() };
		ordered.forEach((name, index) => {
			const existing = behaviours[name];
			if (existing !== void 0) behaviours[name] = {
				...existing,
				order: index + 1
			};
		});
		this.behaviours.set(behaviours);
		this.movedField.set(moved);
	}
	draggingField = signal(null, ...ngDevMode ? [{ debugName: "draggingField" }] : /* istanbul ignore next */ []);
	dropField = signal(null, ...ngDevMode ? [{ debugName: "dropField" }] : /* istanbul ignore next */ []);
	dragSection = null;
	gesture = new PointerDragGesture({
		handleSelector: "[data-drag-field]",
		source: (handle) => rowRef(handle, "data-drag-field", "data-drag-section"),
		target: (x, y) => {
			const row = elementUnder(x, y, "[data-drop-field]");
			return row === null ? null : rowRef(row, "data-drop-field", "data-drop-section");
		},
		started: (source) => {
			this.dragSection = source.section;
			this.draggingField.set(source.field);
		},
		over: (target) => this.dropField.set(target !== null && target.section === this.dragSection && target.field !== this.draggingField() ? target.field : null),
		ended: () => {
			this.dragSection = null;
			this.draggingField.set(null);
			this.dropField.set(null);
		},
		dropped: (source, target) => {
			if (source.section === target.section) this.placeField(source.section, source.field, target.field);
		}
	});
	constructor() {
		inject(DestroyRef).onDestroy(() => this.gesture.cancel());
	}
	onRowPointerDown(event) {
		this.gesture.press(event);
	}
	movedField = signal(null, ...ngDevMode ? [{ debugName: "movedField" }] : /* istanbul ignore next */ []);
	requiredCount = computed(() => Object.values(this.behaviours()).filter((behaviour) => behaviour.required).length, ...ngDevMode ? [{ debugName: "requiredCount" }] : /* istanbul ignore next */ []);
	hiddenCount = computed(() => Object.values(this.behaviours()).filter((behaviour) => !behaviour.visible).length, ...ngDevMode ? [{ debugName: "hiddenCount" }] : /* istanbul ignore next */ []);
	setRequired(componentName, required) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				required,
				visible: required ? true : all[componentName].visible
			}
		}));
	}
	setVisible(componentName, visible) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				visible
			}
		}));
	}
	setFlag(componentName, flag, value) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				[flag]: value
			}
		}));
	}
	setTabVisible(id, visible) {
		this.tabs.update((all) => all.map((tab) => tab.id === id ? {
			...tab,
			visible
		} : tab));
	}
	setTabLabel(id, label) {
		this.tabs.update((all) => all.map((tab) => tab.id === id ? {
			...tab,
			label
		} : tab));
	}
	copyFromCurrent() {
		const ticket = ++this.startingPoint;
		this.seededFrom.set(null);
		this.baseSections.set(null);
		this.seedNotice.set(null);
		this.source.preview({
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			...this.locationCode !== "" ? { locationCode: this.locationCode } : {},
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {}
		}).subscribe((state) => {
			if (state.status !== "loaded" || ticket !== this.startingPoint) return;
			const next = { ...this.behaviours() };
			for (const section of state.value.config.sections) for (const field of section.fields) {
				const current = next[field.componentName];
				if (current !== void 0) next[field.componentName] = {
					...current,
					visible: field.behaviour.visible,
					required: field.behaviour.required,
					readOnly: field.behaviour.readOnly
				};
			}
			this.behaviours.set(next);
			this.tabs.set(state.value.config.tabs);
			this.autoCalculationMode = state.value.tradeUnitAttributes.autoCalculationMode;
			this.pendingContractsEnabled = state.value.tradeUnitAttributes.pendingContractsEnabled;
		});
	}
	save() {
		const registry = this.registry();
		if (registry === null || this.effectiveFrom === "") {
			this.error.set({ message: "An effective date is required — it is what decides when this row starts applying." });
			return;
		}
		this.saving.set(true);
		this.error.set(null);
		const document = {
			schemaVersion: registry.schemaVersion,
			tabs: this.tabs(),
			sections: this.editableSections(),
			fields: this.behaviours(),
			attributes: {
				autoCalculationMode: this.autoCalculationMode,
				pendingContractsEnabled: this.pendingContractsEnabled
			}
		};
		const submission = {
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			...this.locationCode !== "" ? { locationCode: this.locationCode } : {},
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {},
			effectiveFrom: this.effectiveFrom,
			config: document
		};
		const editing = this.editing();
		const seed = this.seededFrom();
		if (editing !== null) {
			this.submit(this.source.update(editing.id, editing.rowVersion, submission));
			return;
		}
		if (seed === null) {
			this.submit(this.source.create(submission));
			return;
		}
		this.source.get(seed.id).subscribe((state) => {
			if (state.status === "error") {
				this.saving.set(false);
				this.error.set({
					message: `The configuration you seeded from (trade unit ${seed.tradeUnit}) could not be re-read, so this row was not created. Try again, or seed again.`,
					correlationId: state.error.correlationId
				});
				return;
			}
			if (state.status !== "loaded") return;
			if (state.value.rowVersion !== seed.rowVersion || !state.value.isActive) {
				this.saving.set(false);
				this.error.set({ message: `The configuration for trade unit ${seed.tradeUnit} changed after you seeded from it, so this row was not created — it would have copied a version that no longer exists. Seed again to start from its current settings.` });
				return;
			}
			this.submit(this.source.create(submission));
		});
	}
	submit(request) {
		request.subscribe((state) => {
			if (state.status === "loaded") {
				this.saving.set(false);
				this.saved.emit();
			} else if (state.status === "error") {
				this.saving.set(false);
				this.error.set(state.error);
			}
		});
	}
	seedFromTradeUnit() {
		const tradeUnit = this.seedTradeUnit.trim();
		this.seedNotice.set(null);
		if (tradeUnit === "") {
			this.seedNotice.set("Enter the trade unit to seed from.");
			return;
		}
		if (tradeUnit === this.locationCode.trim()) {
			this.seedNotice.set(`This row applies to trade unit ${tradeUnit}. Seed from another trade unit — copying a trade unit onto itself changes nothing.`);
			return;
		}
		const ticket = ++this.startingPoint;
		this.source.preview({
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			locationCode: tradeUnit,
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {}
		}).subscribe((resolved) => {
			if (ticket !== this.startingPoint) return;
			if (resolved.status === "error") {
				this.seedNotice.set(`Trade unit ${tradeUnit} could not be resolved: ${resolved.error.message}`);
				return;
			}
			if (resolved.status !== "loaded") return;
			const id = resolved.value.provenance.configId;
			if (id === null) {
				this.seedNotice.set(`Trade unit ${tradeUnit} has no configuration of its own — it resolves to the built-in default, which is where a new row already starts. Nothing was copied.`);
				return;
			}
			this.source.get(id).subscribe((row) => {
				if (ticket !== this.startingPoint) return;
				if (row.status === "error") this.seedNotice.set(`Trade unit ${tradeUnit}'s configuration could not be read: ${row.error.message}`);
				else if (row.status === "loaded") this.adoptSeed(tradeUnit, row.value);
			});
		});
	}
	adoptSeed(tradeUnit, detail) {
		const registry = this.registry();
		if (registry === null) return;
		this.tabs.set(detail.config.tabs);
		this.baseSections.set(detail.config.sections);
		this.sectionVisibility.set(visibilityOf(detail.config.sections));
		this.behaviours.set(this.completeFrom(registry, detail.config.fields));
		this.autoCalculationMode = detail.config.attributes.autoCalculationMode;
		this.pendingContractsEnabled = detail.config.attributes.pendingContractsEnabled;
		this.seededFrom.set({
			id: detail.id,
			rowVersion: detail.rowVersion,
			tradeUnit,
			dimensionKey: detail.dimensionKey,
			version: detail.version
		});
	}
	cancel() {
		this.cancelled.emit();
	}
	seed() {
		const registry = this.registry();
		if (registry === null) return;
		const editing = this.editing();
		if (editing !== null) {
			this.contractTypeClass = editing.contractTypeClass ?? "";
			this.locationCode = editing.locationCode ?? "";
			this.commodityCode = editing.commodityCode ?? "";
			this.effectiveFrom = editing.effectiveFrom;
			this.autoCalculationMode = editing.config.attributes.autoCalculationMode;
			this.pendingContractsEnabled = editing.config.attributes.pendingContractsEnabled;
			this.tabs.set(editing.config.tabs);
			this.sectionVisibility.set(visibilityOf(editing.config.sections));
			this.behaviours.set(this.completeFrom(registry, editing.config.fields));
			return;
		}
		this.behaviours.set(this.completeFrom(registry, {}));
		this.tabs.set(registry.tabs);
		this.sectionVisibility.set(visibilityOf(registry.sections));
		this.copyFromCurrent();
	}
	completeFrom(registry, stored) {
		const all = {};
		const names = [...Object.keys(stored).filter((name) => name in registry.fields), ...Object.keys(registry.fields).filter((name) => !(name in stored))];
		for (const componentName of names) {
			const field = registry.fields[componentName];
			all[componentName] = stored[componentName] ?? {
				visible: true,
				required: field.systemRequired,
				readOnly: field.readOnly,
				borderWarning: false,
				excludeFromCopy: false,
				excludeFromTemplateCopy: false,
				section: field.section,
				order: field.order
			};
		}
		return all;
	}
	toEditorField(componentName, field, behaviour) {
		return {
			componentName,
			label: field.label,
			ctrmField: field.ctrmField,
			ctrmReadOnly: field.readOnly,
			locked: !field.configurable,
			behaviour: behaviour ?? {
				visible: true,
				required: field.systemRequired,
				readOnly: field.readOnly,
				borderWarning: false,
				excludeFromCopy: false,
				excludeFromTemplateCopy: false,
				section: field.section,
				order: field.order
			}
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FormConfigEditorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: FormConfigEditorComponent,
		isStandalone: true,
		selector: "cms-form-config-editor",
		inputs: { editing: {
			classPropertyName: "editing",
			publicName: "editing",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		outputs: {
			saved: "saved",
			cancelled: "cancelled"
		},
		ngImport: i0,
		template: "<section class=\"cws:space-y-5\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      {{ isNew() ? 'New configuration' : 'Edit configuration' }}\r\n    </h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      A row applies to every contract matching the dimensions below — leave one empty to mean\r\n      <em>any</em>. The most specific matching row wins <strong>whole</strong>: nothing is merged\r\n      from less specific rows, which is why this form starts from whatever currently applies.\r\n    </p>\r\n  </header>\r\n\r\n  @if (error() !== null) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-title\">The configuration was not saved</div>\r\n      <div class=\"scoular-alert-description cws:whitespace-pre-line\">{{ error()?.message }}</div>\r\n      @if (error()?.correlationId) {\r\n        <div class=\"scoular-alert-description cws:text-xs\">\r\n          Reference: {{ error()?.correlationId }}\r\n        </div>\r\n      }\r\n    </div>\r\n  }\r\n\r\n  @if (!ready()) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">\r\n      Loading the field registry…\r\n    </p>\r\n  } @else {\r\n    <!-- Dimensions -->\r\n    <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Applies to contract type\r\n          </span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorType\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"contractTypeClass\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to trade unit</span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorLocation\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"locationCode\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to commodity</span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorCommodity\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"commodityCode\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          🔴 The shared C3 control. See the pricing screen for why the native input went.\r\n\r\n          ⚠ The required marker and `aria-required` are the CONTROL's now. This label carried a\r\n          literal `*` in its text and no `aria-required` at all, so the field announced itself as\r\n          optional to a screen reader while looking required to everyone else.\r\n        -->\r\n        <cms-date-input\r\n          label=\"Effective from\"\r\n          controlId=\"editor-effective\"\r\n          [required]=\"true\"\r\n          name=\"editorEffective\"\r\n          [(ngModel)]=\"effectiveFrom\"\r\n        />\r\n      </div>\r\n\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"copyFromCurrent()\">\r\n          Copy from what currently applies\r\n        </button>\r\n        <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Reloads the field settings below from the configuration in force for these dimensions —\r\n          do this after changing them.\r\n        </span>\r\n      </div>\r\n\r\n      <!--\r\n        F8.1 — seed from trade unit. New rows only: an existing row already has its own settings, and\r\n        overwriting them with another trade unit's is an edit, not a starting point.\r\n\r\n        ⚠ The source is re-read before the create and its rowVersion compared, so the status line\r\n        says so: an administrator who leaves the form open for an hour is told why the create was\r\n        refused, rather than discovering a clone of settings that were since changed.\r\n      -->\r\n      @if (isNew()) {\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Seed from trade unit</span>\r\n            <input\r\n              class=\"scoular-form-input cws:w-40\"\r\n              name=\"editorSeedFrom\"\r\n              placeholder=\"e.g. 4090\"\r\n              [(ngModel)]=\"seedTradeUnit\"\r\n            />\r\n          </label>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"seedFromTradeUnit()\">\r\n            Seed from this trade unit\r\n          </button>\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Copies that trade unit's configuration exactly — every field, section, tab and attribute —\r\n            as this row's starting point. The dimensions above stay this row's.\r\n          </span>\r\n        </div>\r\n\r\n        @if (seededFrom(); as seed) {\r\n          <p\r\n            role=\"status\"\r\n            class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-200\"\r\n          >\r\n            Seeded from trade unit {{ seed.tradeUnit }} — configuration row #{{ seed.id }}\r\n            ({{ seed.dimensionKey }}, version {{ seed.version }}). It is read again before this row\r\n            is created, and the create is refused if it has changed since.\r\n          </p>\r\n        }\r\n\r\n        @if (seedNotice(); as notice) {\r\n          <p\r\n            role=\"alert\"\r\n            class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n          >\r\n            {{ notice }}\r\n          </p>\r\n        }\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        A future effective date is allowed and is how a change is staged: the row sits dormant until\r\n        that date, then takes over from the one before it. Editing an old contract always applies\r\n        today's rules.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Trade unit attributes -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Trade unit behaviour</h4>\r\n\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Contract auto-calculation\r\n          </span>\r\n          <select\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorAutoCalc\"\r\n            [(ngModel)]=\"autoCalculationMode\"\r\n          >\r\n            <option value=\"None\">None — both Price and Basis stay editable</option>\r\n            <option value=\"Price\">Price — computed from its components and locked</option>\r\n            <option value=\"Basis\">Basis — computed from its components and locked</option>\r\n          </select>\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2\">\r\n          <input\r\n            type=\"checkbox\"\r\n            name=\"editorPending\"\r\n            [(ngModel)]=\"pendingContractsEnabled\"\r\n          />\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Pending contracts enabled\r\n          </span>\r\n        </label>\r\n      </div>\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <strong>None</strong> is the honest default for a trade unit nobody has configured — picking\r\n        Price or Basis makes the rule compute a value and lock the field, which looks like working\r\n        configuration if it was only a guess.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Tabs -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Tabs</h4>\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Which tabs this configuration shows, and what they are called. A hidden tab is not on the\r\n        screen at all. This is what replaces the legacy application's per-location tabs, which were\r\n        conditions written into its screen rather than configuration.\r\n      </p>\r\n\r\n      <div class=\"cws:space-y-2\">\r\n        @for (tab of editableTabs(); track tab.id) {\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"tab.visible\"\r\n                (change)=\"setTabVisible(tab.id, $any($event.target).checked)\"\r\n                [attr.aria-label]=\"'Show the ' + tab.label + ' tab'\"\r\n              />\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Show</span>\r\n            </label>\r\n\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              [value]=\"tab.label\"\r\n              (change)=\"setTabLabel(tab.id, $any($event.target).value)\"\r\n              [attr.aria-label]=\"'Label for the ' + tab.id + ' tab'\"\r\n            />\r\n\r\n            <code class=\"cws:text-xs cws:text-slate-400\">{{ tab.id }}</code>\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n    <!-- The field grid -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields</h4>\r\n\r\n        <div class=\"cws:flex cws:items-center cws:gap-3\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            {{ requiredCount() }} required · {{ hiddenCount() }} hidden\r\n          </span>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n            <span class=\"sr-only\">Filter fields</span>\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              name=\"editorFilter\"\r\n              placeholder=\"Filter fields…\"\r\n              [ngModel]=\"filter()\"\r\n              (ngModelChange)=\"filter.set($event)\"\r\n            />\r\n          </label>\r\n        </div>\r\n      </div>\r\n\r\n      <!--\r\n        Both states are stated where the administrator is working rather than discovered at save.\r\n        The reorder one explains a disabled control, which is the only honest way to disable\r\n        something; the empty-tab one reports a state this editor can now create and the record\r\n        screen does not resolve away.\r\n      -->\r\n      @if (reorderBlockedReason(); as reason) {\r\n        <p class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\">\r\n          {{ reason }}\r\n        </p>\r\n      }\r\n\r\n      @if (emptyTabWarning(); as emptied) {\r\n        <p\r\n          role=\"status\"\r\n          class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n        >\r\n          Every section is hidden on: {{ emptied }} — so the tab itself will not appear on the\r\n          record screen. Leave a section visible if you want the tab to stay.\r\n        </p>\r\n      }\r\n\r\n      @for (section of sections(); track section.id) {\r\n        <details class=\"cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\" [open]=\"filter() !== ''\">\r\n          <summary class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-sm cws:font-medium\">\r\n            {{ section.label }}\r\n            <span class=\"cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n              ({{ section.fields.length }} fields · {{ section.tab }} tab)\r\n            </span>\r\n          </summary>\r\n\r\n          <!--\r\n            F8.3 — section enablement, in the section's own header rather than on a separate screen,\r\n            because \"is this section on for this trade unit\" is the same question as \"what is in it\".\r\n\r\n            ⚠ The label is a real `<label>` wrapping the input, so the whole phrase is the hit target\r\n            and a screen reader announces the section name with the state. `stopPropagation` keeps a\r\n            click on it from toggling the `<details>` it sits inside — without it, turning a section\r\n            off would also collapse the rows you turned off.\r\n          -->\r\n          <div class=\"cws:border-b cws:border-slate-200 cws:px-3 cws:py-2 cws:dark:border-slate-700\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"sectionVisible(section.id)\"\r\n                (click)=\"$event.stopPropagation()\"\r\n                (change)=\"toggleSection(section.id, $any($event.target).checked)\"\r\n              />\r\n              <span>\r\n                Section visible on the {{ section.tab }} tab\r\n                @if (!sectionVisible(section.id)) {\r\n                  <span class=\"cws:ml-1 cws:text-amber-700 cws:dark:text-amber-400\">\r\n                    — hidden for this trade unit\r\n                  </span>\r\n                }\r\n              </span>\r\n            </label>\r\n          </div>\r\n\r\n          <div class=\"cws:overflow-x-auto\">\r\n            <table class=\"cws:w-full cws:text-sm\">\r\n              <caption class=\"sr-only\">{{ section.label }} field settings</caption>\r\n              <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n                <tr>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Order</th>\r\n                  <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Field</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Read-only</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Warn</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No copy</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No template</th>\r\n                </tr>\r\n              </thead>\r\n              <!--\r\n                🔴 `select-none` is REQUIRED on the CONTAINER of anything draggable — Known Issue 44:\r\n                a press inside a leftover text selection is taken by the browser as a selection drag,\r\n                announced with `pointercancel`, so the gesture works once per session and then\r\n                silently stops. jsdom cannot test it, so the class is the anchor (the spec reads it\r\n                off `data-drag-rows`) and the playground screenshot is the proof.\r\n\r\n                The press is bound here rather than per row: the shared gesture follows the pointer\r\n                on the window from there, and hit-tests the row under it (`data-drop-field`).\r\n              -->\r\n              <tbody data-drag-rows class=\"cws:select-none\" (pointerdown)=\"onRowPointerDown($event)\">\r\n                @for (field of section.fields; track field.componentName; let idx = $index) {\r\n                  <tr\r\n                    class=\"cws:select-none cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\"\r\n                    [class.cws:bg-slate-100]=\"draggingField() === field.componentName\"\r\n                    [class.cws:dark:bg-slate-800]=\"draggingField() === field.componentName\"\r\n                    [class.cws:border-t-2]=\"dropField() === field.componentName\"\r\n                    [class.cws:border-t-scoular-blue]=\"dropField() === field.componentName\"\r\n                    [attr.data-drop-field]=\"field.componentName\"\r\n                    [attr.data-drop-section]=\"section.id\"\r\n                    [attr.data-dragging]=\"draggingField() === field.componentName ? 'true' : null\"\r\n                    [attr.data-drop-here]=\"dropField() === field.componentName ? 'true' : null\"\r\n                  >\r\n                    <td class=\"cws:whitespace-nowrap cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        The drag grip (F8.1). `aria-hidden` with no tab stop: it is an affordance\r\n                        for the pointer, and the arrows beside it are the keyboard's route to the\r\n                        same move. Absent while the list is filtered, for the reason the arrows are\r\n                        disabled — see `reorderBlockedReason`.\r\n                      -->\r\n                      @if (reorderBlockedReason() === null) {\r\n                        <span\r\n                          aria-hidden=\"true\"\r\n                          title=\"Drag to reorder\"\r\n                          class=\"cws:mr-1 cws:inline-block cws:cursor-grab cws:touch-none cws:px-1 cws:text-slate-400\"\r\n                          [attr.data-drag-field]=\"field.componentName\"\r\n                          [attr.data-drag-section]=\"section.id\"\r\n                        >⠿</span>\r\n                      }\r\n                      <!--\r\n                        The keyboard path, and it is the primary one rather than a fallback: this\r\n                        grid is 111 rows and the people who configure it do so from a keyboard.\r\n                        Buttons rather than a numeric input, because \"one place up\" is the operation\r\n                        an administrator actually wants and a free-text order invites collisions.\r\n                      -->\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === 0 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' up'\"\r\n                        (click)=\"moveField(section.id, field.componentName, -1)\"\r\n                      >\r\n                        ↑\r\n                      </button>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === section.fields.length - 1 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' down'\"\r\n                        (click)=\"moveField(section.id, field.componentName, 1)\"\r\n                      >\r\n                        ↓\r\n                      </button>\r\n                    </td>\r\n                    <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                      {{ field.label }}\r\n                      <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ field.ctrmField }}</code>\r\n\r\n                      @if (field.locked) {\r\n                        <!--\r\n                          Shown locked rather than hidden. A field absent from this grid reads as\r\n                          \"not configurable in this version\"; a locked row with a reason reads as\r\n                          \"not yours to change\", which is what it is.\r\n                        -->\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n                          — system field: resolution keys on it\r\n                        </span>\r\n                      } @else if (field.ctrmReadOnly) {\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">\r\n                          — CTRM refuses this on a write, so it cannot be required\r\n                        </span>\r\n                      }\r\n                    </th>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.visible\"\r\n                        [disabled]=\"field.locked || field.behaviour.required\"\r\n                        (change)=\"setVisible(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' visible'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        Disabled for a CTRM read-only field and for the drivers: requiring the\r\n                        first demands the impossible, and the second is already required and not\r\n                        the admin's to relax.\r\n                      -->\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.required\"\r\n                        [disabled]=\"field.locked || field.ctrmReadOnly\"\r\n                        (change)=\"setRequired(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' required'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.readOnly\"\r\n                        [disabled]=\"field.ctrmReadOnly\"\r\n                        (change)=\"setFlag(field.componentName, 'readOnly', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' read only'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.borderWarning\"\r\n                        (change)=\"setFlag(field.componentName, 'borderWarning', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' border warning'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from copy'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromTemplateCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromTemplateCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from template copy'\"\r\n                      />\r\n                    </td>\r\n                  </tr>\r\n                }\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </details>\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Ticking <strong>Required</strong> also ticks <strong>Visible</strong> and locks it — a field\r\n        somebody must fill in cannot be one they cannot see. The save enforces requiredness against\r\n        the contract as it will reach CTRM, so a field the user never touched still counts as filled\r\n        if CTRM already holds a value for it.\r\n      </p>\r\n    </div>\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary\"\r\n        [disabled]=\"saving()\"\r\n        (click)=\"save()\"\r\n      >\r\n        {{ saving() ? 'Saving…' : isNew() ? 'Create configuration' : 'Save changes' }}\r\n      </button>\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-secondary\"\r\n        (click)=\"cancel()\"\r\n      >\r\n        Cancel\r\n      </button>\r\n    </div>\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: DateInputComponent,
				selector: "cms-date-input",
				inputs: [
					"label",
					"controlId",
					"required",
					"readOnly",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: FormConfigEditorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-config-editor",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormsModule, DateInputComponent],
			template: "<section class=\"cws:space-y-5\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      {{ isNew() ? 'New configuration' : 'Edit configuration' }}\r\n    </h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      A row applies to every contract matching the dimensions below — leave one empty to mean\r\n      <em>any</em>. The most specific matching row wins <strong>whole</strong>: nothing is merged\r\n      from less specific rows, which is why this form starts from whatever currently applies.\r\n    </p>\r\n  </header>\r\n\r\n  @if (error() !== null) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-title\">The configuration was not saved</div>\r\n      <div class=\"scoular-alert-description cws:whitespace-pre-line\">{{ error()?.message }}</div>\r\n      @if (error()?.correlationId) {\r\n        <div class=\"scoular-alert-description cws:text-xs\">\r\n          Reference: {{ error()?.correlationId }}\r\n        </div>\r\n      }\r\n    </div>\r\n  }\r\n\r\n  @if (!ready()) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">\r\n      Loading the field registry…\r\n    </p>\r\n  } @else {\r\n    <!-- Dimensions -->\r\n    <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Applies to contract type\r\n          </span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorType\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"contractTypeClass\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to trade unit</span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorLocation\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"locationCode\"\r\n          />\r\n        </label>\r\n\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to commodity</span>\r\n          <input\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorCommodity\"\r\n            placeholder=\"Any\"\r\n            [(ngModel)]=\"commodityCode\"\r\n          />\r\n        </label>\r\n\r\n        <!--\r\n          🔴 The shared C3 control. See the pricing screen for why the native input went.\r\n\r\n          ⚠ The required marker and `aria-required` are the CONTROL's now. This label carried a\r\n          literal `*` in its text and no `aria-required` at all, so the field announced itself as\r\n          optional to a screen reader while looking required to everyone else.\r\n        -->\r\n        <cms-date-input\r\n          label=\"Effective from\"\r\n          controlId=\"editor-effective\"\r\n          [required]=\"true\"\r\n          name=\"editorEffective\"\r\n          [(ngModel)]=\"effectiveFrom\"\r\n        />\r\n      </div>\r\n\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"copyFromCurrent()\">\r\n          Copy from what currently applies\r\n        </button>\r\n        <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Reloads the field settings below from the configuration in force for these dimensions —\r\n          do this after changing them.\r\n        </span>\r\n      </div>\r\n\r\n      <!--\r\n        F8.1 — seed from trade unit. New rows only: an existing row already has its own settings, and\r\n        overwriting them with another trade unit's is an edit, not a starting point.\r\n\r\n        ⚠ The source is re-read before the create and its rowVersion compared, so the status line\r\n        says so: an administrator who leaves the form open for an hour is told why the create was\r\n        refused, rather than discovering a clone of settings that were since changed.\r\n      -->\r\n      @if (isNew()) {\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n          <label class=\"cws:space-y-1\">\r\n            <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Seed from trade unit</span>\r\n            <input\r\n              class=\"scoular-form-input cws:w-40\"\r\n              name=\"editorSeedFrom\"\r\n              placeholder=\"e.g. 4090\"\r\n              [(ngModel)]=\"seedTradeUnit\"\r\n            />\r\n          </label>\r\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"seedFromTradeUnit()\">\r\n            Seed from this trade unit\r\n          </button>\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Copies that trade unit's configuration exactly — every field, section, tab and attribute —\r\n            as this row's starting point. The dimensions above stay this row's.\r\n          </span>\r\n        </div>\r\n\r\n        @if (seededFrom(); as seed) {\r\n          <p\r\n            role=\"status\"\r\n            class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-200\"\r\n          >\r\n            Seeded from trade unit {{ seed.tradeUnit }} — configuration row #{{ seed.id }}\r\n            ({{ seed.dimensionKey }}, version {{ seed.version }}). It is read again before this row\r\n            is created, and the create is refused if it has changed since.\r\n          </p>\r\n        }\r\n\r\n        @if (seedNotice(); as notice) {\r\n          <p\r\n            role=\"alert\"\r\n            class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n          >\r\n            {{ notice }}\r\n          </p>\r\n        }\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        A future effective date is allowed and is how a change is staged: the row sits dormant until\r\n        that date, then takes over from the one before it. Editing an old contract always applies\r\n        today's rules.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Trade unit attributes -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Trade unit behaviour</h4>\r\n\r\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Contract auto-calculation\r\n          </span>\r\n          <select\r\n            class=\"scoular-form-input cws:w-full\"\r\n            name=\"editorAutoCalc\"\r\n            [(ngModel)]=\"autoCalculationMode\"\r\n          >\r\n            <option value=\"None\">None — both Price and Basis stay editable</option>\r\n            <option value=\"Price\">Price — computed from its components and locked</option>\r\n            <option value=\"Basis\">Basis — computed from its components and locked</option>\r\n          </select>\r\n        </label>\r\n\r\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2\">\r\n          <input\r\n            type=\"checkbox\"\r\n            name=\"editorPending\"\r\n            [(ngModel)]=\"pendingContractsEnabled\"\r\n          />\r\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n            Pending contracts enabled\r\n          </span>\r\n        </label>\r\n      </div>\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <strong>None</strong> is the honest default for a trade unit nobody has configured — picking\r\n        Price or Basis makes the rule compute a value and lock the field, which looks like working\r\n        configuration if it was only a guess.\r\n      </p>\r\n    </div>\r\n\r\n    <!-- Tabs -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Tabs</h4>\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Which tabs this configuration shows, and what they are called. A hidden tab is not on the\r\n        screen at all. This is what replaces the legacy application's per-location tabs, which were\r\n        conditions written into its screen rather than configuration.\r\n      </p>\r\n\r\n      <div class=\"cws:space-y-2\">\r\n        @for (tab of editableTabs(); track tab.id) {\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"tab.visible\"\r\n                (change)=\"setTabVisible(tab.id, $any($event.target).checked)\"\r\n                [attr.aria-label]=\"'Show the ' + tab.label + ' tab'\"\r\n              />\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Show</span>\r\n            </label>\r\n\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              [value]=\"tab.label\"\r\n              (change)=\"setTabLabel(tab.id, $any($event.target).value)\"\r\n              [attr.aria-label]=\"'Label for the ' + tab.id + ' tab'\"\r\n            />\r\n\r\n            <code class=\"cws:text-xs cws:text-slate-400\">{{ tab.id }}</code>\r\n          </div>\r\n        }\r\n      </div>\r\n    </div>\r\n\r\n    <!-- The field grid -->\r\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\r\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields</h4>\r\n\r\n        <div class=\"cws:flex cws:items-center cws:gap-3\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n            {{ requiredCount() }} required · {{ hiddenCount() }} hidden\r\n          </span>\r\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n            <span class=\"sr-only\">Filter fields</span>\r\n            <input\r\n              class=\"scoular-form-input\"\r\n              name=\"editorFilter\"\r\n              placeholder=\"Filter fields…\"\r\n              [ngModel]=\"filter()\"\r\n              (ngModelChange)=\"filter.set($event)\"\r\n            />\r\n          </label>\r\n        </div>\r\n      </div>\r\n\r\n      <!--\r\n        Both states are stated where the administrator is working rather than discovered at save.\r\n        The reorder one explains a disabled control, which is the only honest way to disable\r\n        something; the empty-tab one reports a state this editor can now create and the record\r\n        screen does not resolve away.\r\n      -->\r\n      @if (reorderBlockedReason(); as reason) {\r\n        <p class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\">\r\n          {{ reason }}\r\n        </p>\r\n      }\r\n\r\n      @if (emptyTabWarning(); as emptied) {\r\n        <p\r\n          role=\"status\"\r\n          class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n        >\r\n          Every section is hidden on: {{ emptied }} — so the tab itself will not appear on the\r\n          record screen. Leave a section visible if you want the tab to stay.\r\n        </p>\r\n      }\r\n\r\n      @for (section of sections(); track section.id) {\r\n        <details class=\"cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\" [open]=\"filter() !== ''\">\r\n          <summary class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-sm cws:font-medium\">\r\n            {{ section.label }}\r\n            <span class=\"cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n              ({{ section.fields.length }} fields · {{ section.tab }} tab)\r\n            </span>\r\n          </summary>\r\n\r\n          <!--\r\n            F8.3 — section enablement, in the section's own header rather than on a separate screen,\r\n            because \"is this section on for this trade unit\" is the same question as \"what is in it\".\r\n\r\n            ⚠ The label is a real `<label>` wrapping the input, so the whole phrase is the hit target\r\n            and a screen reader announces the section name with the state. `stopPropagation` keeps a\r\n            click on it from toggling the `<details>` it sits inside — without it, turning a section\r\n            off would also collapse the rows you turned off.\r\n          -->\r\n          <div class=\"cws:border-b cws:border-slate-200 cws:px-3 cws:py-2 cws:dark:border-slate-700\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\r\n              <input\r\n                type=\"checkbox\"\r\n                [checked]=\"sectionVisible(section.id)\"\r\n                (click)=\"$event.stopPropagation()\"\r\n                (change)=\"toggleSection(section.id, $any($event.target).checked)\"\r\n              />\r\n              <span>\r\n                Section visible on the {{ section.tab }} tab\r\n                @if (!sectionVisible(section.id)) {\r\n                  <span class=\"cws:ml-1 cws:text-amber-700 cws:dark:text-amber-400\">\r\n                    — hidden for this trade unit\r\n                  </span>\r\n                }\r\n              </span>\r\n            </label>\r\n          </div>\r\n\r\n          <div class=\"cws:overflow-x-auto\">\r\n            <table class=\"cws:w-full cws:text-sm\">\r\n              <caption class=\"sr-only\">{{ section.label }} field settings</caption>\r\n              <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\r\n                <tr>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Order</th>\r\n                  <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Field</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Read-only</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Warn</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No copy</th>\r\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No template</th>\r\n                </tr>\r\n              </thead>\r\n              <!--\r\n                🔴 `select-none` is REQUIRED on the CONTAINER of anything draggable — Known Issue 44:\r\n                a press inside a leftover text selection is taken by the browser as a selection drag,\r\n                announced with `pointercancel`, so the gesture works once per session and then\r\n                silently stops. jsdom cannot test it, so the class is the anchor (the spec reads it\r\n                off `data-drag-rows`) and the playground screenshot is the proof.\r\n\r\n                The press is bound here rather than per row: the shared gesture follows the pointer\r\n                on the window from there, and hit-tests the row under it (`data-drop-field`).\r\n              -->\r\n              <tbody data-drag-rows class=\"cws:select-none\" (pointerdown)=\"onRowPointerDown($event)\">\r\n                @for (field of section.fields; track field.componentName; let idx = $index) {\r\n                  <tr\r\n                    class=\"cws:select-none cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\"\r\n                    [class.cws:bg-slate-100]=\"draggingField() === field.componentName\"\r\n                    [class.cws:dark:bg-slate-800]=\"draggingField() === field.componentName\"\r\n                    [class.cws:border-t-2]=\"dropField() === field.componentName\"\r\n                    [class.cws:border-t-scoular-blue]=\"dropField() === field.componentName\"\r\n                    [attr.data-drop-field]=\"field.componentName\"\r\n                    [attr.data-drop-section]=\"section.id\"\r\n                    [attr.data-dragging]=\"draggingField() === field.componentName ? 'true' : null\"\r\n                    [attr.data-drop-here]=\"dropField() === field.componentName ? 'true' : null\"\r\n                  >\r\n                    <td class=\"cws:whitespace-nowrap cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        The drag grip (F8.1). `aria-hidden` with no tab stop: it is an affordance\r\n                        for the pointer, and the arrows beside it are the keyboard's route to the\r\n                        same move. Absent while the list is filtered, for the reason the arrows are\r\n                        disabled — see `reorderBlockedReason`.\r\n                      -->\r\n                      @if (reorderBlockedReason() === null) {\r\n                        <span\r\n                          aria-hidden=\"true\"\r\n                          title=\"Drag to reorder\"\r\n                          class=\"cws:mr-1 cws:inline-block cws:cursor-grab cws:touch-none cws:px-1 cws:text-slate-400\"\r\n                          [attr.data-drag-field]=\"field.componentName\"\r\n                          [attr.data-drag-section]=\"section.id\"\r\n                        >⠿</span>\r\n                      }\r\n                      <!--\r\n                        The keyboard path, and it is the primary one rather than a fallback: this\r\n                        grid is 111 rows and the people who configure it do so from a keyboard.\r\n                        Buttons rather than a numeric input, because \"one place up\" is the operation\r\n                        an administrator actually wants and a free-text order invites collisions.\r\n                      -->\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === 0 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' up'\"\r\n                        (click)=\"moveField(section.id, field.componentName, -1)\"\r\n                      >\r\n                        ↑\r\n                      </button>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\r\n                        [disabled]=\"idx === section.fields.length - 1 || reorderBlockedReason() !== null\"\r\n                        [attr.aria-label]=\"'Move ' + field.label + ' down'\"\r\n                        (click)=\"moveField(section.id, field.componentName, 1)\"\r\n                      >\r\n                        ↓\r\n                      </button>\r\n                    </td>\r\n                    <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\r\n                      {{ field.label }}\r\n                      <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ field.ctrmField }}</code>\r\n\r\n                      @if (field.locked) {\r\n                        <!--\r\n                          Shown locked rather than hidden. A field absent from this grid reads as\r\n                          \"not configurable in this version\"; a locked row with a reason reads as\r\n                          \"not yours to change\", which is what it is.\r\n                        -->\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n                          — system field: resolution keys on it\r\n                        </span>\r\n                      } @else if (field.ctrmReadOnly) {\r\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">\r\n                          — CTRM refuses this on a write, so it cannot be required\r\n                        </span>\r\n                      }\r\n                    </th>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.visible\"\r\n                        [disabled]=\"field.locked || field.behaviour.required\"\r\n                        (change)=\"setVisible(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' visible'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <!--\r\n                        Disabled for a CTRM read-only field and for the drivers: requiring the\r\n                        first demands the impossible, and the second is already required and not\r\n                        the admin's to relax.\r\n                      -->\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.required\"\r\n                        [disabled]=\"field.locked || field.ctrmReadOnly\"\r\n                        (change)=\"setRequired(field.componentName, $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' required'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.readOnly\"\r\n                        [disabled]=\"field.ctrmReadOnly\"\r\n                        (change)=\"setFlag(field.componentName, 'readOnly', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' read only'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.borderWarning\"\r\n                        (change)=\"setFlag(field.componentName, 'borderWarning', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' border warning'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from copy'\"\r\n                      />\r\n                    </td>\r\n\r\n                    <td class=\"cws:px-2 cws:py-1.5\">\r\n                      <input\r\n                        type=\"checkbox\"\r\n                        [checked]=\"field.behaviour.excludeFromTemplateCopy\"\r\n                        (change)=\"setFlag(field.componentName, 'excludeFromTemplateCopy', $any($event.target).checked)\"\r\n                        [attr.aria-label]=\"field.label + ' exclude from template copy'\"\r\n                      />\r\n                    </td>\r\n                  </tr>\r\n                }\r\n              </tbody>\r\n            </table>\r\n          </div>\r\n        </details>\r\n      }\r\n\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Ticking <strong>Required</strong> also ticks <strong>Visible</strong> and locks it — a field\r\n        somebody must fill in cannot be one they cannot see. The save enforces requiredness against\r\n        the contract as it will reach CTRM, so a field the user never touched still counts as filled\r\n        if CTRM already holds a value for it.\r\n      </p>\r\n    </div>\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary\"\r\n        [disabled]=\"saving()\"\r\n        (click)=\"save()\"\r\n      >\r\n        {{ saving() ? 'Saving…' : isNew() ? 'Create configuration' : 'Save changes' }}\r\n      </button>\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-secondary\"\r\n        (click)=\"cancel()\"\r\n      >\r\n        Cancel\r\n      </button>\r\n    </div>\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		editing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editing",
				required: false
			}]
		}],
		saved: [{
			type: i0.Output,
			args: ["saved"]
		}],
		cancelled: [{
			type: i0.Output,
			args: ["cancelled"]
		}]
	}
});
function rowRef(element, fieldAttribute, sectionAttribute) {
	const field = element.getAttribute(fieldAttribute);
	const section = element.getAttribute(sectionAttribute);
	return field === null || section === null || field === "" || section === "" ? null : {
		field,
		section
	};
}
function visibilityOf(sections) {
	const map = {};
	for (const section of sections) map[section.id] = section.visible;
	return map;
}
var FormConfigAdminPageComponent = class FormConfigAdminPageComponent {
	source = inject(FORM_CONFIG_ADMIN_SOURCE);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	listState = signal(remoteLoading(), ...ngDevMode ? [{ debugName: "listState" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.value.rows : [];
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	storeOrigin = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.value.storeOrigin : null;
	}, ...ngDevMode ? [{ debugName: "storeOrigin" }] : /* istanbul ignore next */ []);
	notDurable = computed(() => this.storeOrigin() === "InMemory", ...ngDevMode ? [{ debugName: "notDurable" }] : /* istanbul ignore next */ []);
	previewType = "";
	previewLocation = "";
	previewCommodity = "";
	previewContract = "";
	previewState = signal(null, ...ngDevMode ? [{ debugName: "previewState" }] : /* istanbul ignore next */ []);
	preview = computed(() => {
		const state = this.previewState();
		return state !== null && state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []);
	previewProvenance = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return null;
		const { provenance } = resolved;
		if (provenance.configId === null) return "No configuration row matched. The form falls back to the built-in defaults generated from the field layout — correct and safe, but nothing an administrator has configured applies.";
		const matched = provenance.matchedDimensions.length === 0 ? "the global default row (no dimensions pinned)" : `matched on ${provenance.matchedDimensions.map(dimensionLabel).join(" and ")}`;
		return `Configuration #${provenance.configId}, version ${provenance.version}, ${matched}. Effective from ${provenance.effectiveFrom}, served from ${provenance.source}.`;
	}, ...ngDevMode ? [{ debugName: "previewProvenance" }] : /* istanbul ignore next */ []);
	previewRequired = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return [];
		return resolved.config.sections.flatMap((section) => section.fields.filter((field) => field.behaviour.required).map((field) => field.label));
	}, ...ngDevMode ? [{ debugName: "previewRequired" }] : /* istanbul ignore next */ []);
	previewHidden = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return [];
		return resolved.config.sections.flatMap((section) => section.fields.filter((field) => !field.behaviour.visible).map((field) => field.label));
	}, ...ngDevMode ? [{ debugName: "previewHidden" }] : /* istanbul ignore next */ []);
	previewTabs = computed(() => {
		const resolved = this.preview()?.config;
		return tabsAfterCascade(resolved?.tabs ?? [], resolved?.sections ?? []).map((tab) => tab.label);
	}, ...ngDevMode ? [{ debugName: "previewTabs" }] : /* istanbul ignore next */ []);
	auditRowId = signal(null, ...ngDevMode ? [{ debugName: "auditRowId" }] : /* istanbul ignore next */ []);
	auditState = signal(remoteLoading(), ...ngDevMode ? [{ debugName: "auditState" }] : /* istanbul ignore next */ []);
	auditError = computed(() => {
		const state = this.auditState();
		return state.status === "error" ? state.error.message : "";
	}, ...ngDevMode ? [{ debugName: "auditError" }] : /* istanbul ignore next */ []);
	auditEntries = computed(() => {
		const state = this.auditState();
		if (state.status !== "loaded") return [];
		const entries = state.value.entries;
		return entries.map((entry, index) => ({
			entry,
			isOldest: index === 0,
			changes: diffConfigDocuments(index === 0 ? null : parseSnapshot(entries[index - 1].configJsonSnapshot), parseSnapshot(entry.configJsonSnapshot) ?? EMPTY_DOCUMENT)
		})).reverse();
	}, ...ngDevMode ? [{ debugName: "auditEntries" }] : /* istanbul ignore next */ []);
	toggleAudit(row) {
		if (this.auditRowId() === row.id) {
			this.auditRowId.set(null);
			return;
		}
		this.auditRowId.set(row.id);
		this.auditState.set(remoteLoading());
		this.source.auditTrail(row.id).subscribe((state) => this.auditState.set(state));
	}
	editorState = signal("closed", ...ngDevMode ? [{ debugName: "editorState" }] : /* istanbul ignore next */ []);
	editorOpen = computed(() => this.editorState() !== "closed", ...ngDevMode ? [{ debugName: "editorOpen" }] : /* istanbul ignore next */ []);
	editingRow = computed(() => {
		const state = this.editorState();
		return state === "closed" || state === "new" ? null : state;
	}, ...ngDevMode ? [{ debugName: "editingRow" }] : /* istanbul ignore next */ []);
	loadingEditor = signal(false, ...ngDevMode ? [{ debugName: "loadingEditor" }] : /* istanbul ignore next */ []);
	startNew() {
		this.editorState.set("new");
	}
	edit(row) {
		this.loadingEditor.set(true);
		this.source.get(row.id).subscribe((state) => {
			if (state.status === "loaded") {
				this.loadingEditor.set(false);
				this.editorState.set(state.value);
			} else if (state.status === "error") {
				this.loadingEditor.set(false);
				this.listState.set(state);
			}
		});
	}
	closeEditor() {
		this.editorState.set("closed");
	}
	onSaved() {
		this.editorState.set("closed");
		this.previewState.set(null);
		this.reload();
	}
	constructor() {
		this.reload();
	}
	reload() {
		this.attempt.update((attempt) => attempt + 1);
		this.source.list().subscribe((state) => this.listState.set(state));
	}
	runPreview() {
		this.previewState.set(remoteLoading());
		this.source.preview({
			...this.previewContract !== "" ? { contractNumber: this.previewContract } : {},
			...this.previewContract === "" ? {
				...this.previewType !== "" ? { contractTypeClass: this.previewType } : {},
				...this.previewLocation !== "" ? { locationCode: this.previewLocation } : {},
				...this.previewCommodity !== "" ? { commodityCode: this.previewCommodity } : {}
			} : {}
		}).subscribe((state) => this.previewState.set(state));
	}
	deactivate(row) {
		this.source.deactivate(row.id, row.rowVersion).subscribe((state) => {
			if (state.status === "loaded") {
				this.reload();
				return;
			}
			if (state.status === "error") this.listState.set(state);
		});
	}
	dimension(value) {
		return value === null || value === "" ? "Any" : value;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FormConfigAdminPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: FormConfigAdminPageComponent,
		isStandalone: true,
		selector: "cms-form-config-admin-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-6\">\r\n  <cms-page-header\r\n    title=\"Form configuration\"\r\n    description=\"Which fields the contract record screen shows, which it requires, and which tabs exist, resolved per contract type, trade unit and commodity. Most specific match wins; the whole configuration applies, with no merging between rows.\"\r\n  />\r\n\r\n  @if (notDurable()) {\r\n    <!--\r\n      Said out loud rather than assumed. No deployed environment has a configuration database\r\n      connection string yet, so the honest answer is usually \"in memory\" — and an admin whose saved\r\n      configuration vanishes on the next restart, without having been told, is owed an explanation\r\n      nobody can give them afterwards.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Configuration is not being stored durably</div>\r\n      <div class=\"scoular-alert-description\">\r\n        This environment has no configuration database configured, so rows are held in memory and are\r\n        lost when the application restarts. Resolution, validation and the audit trail all behave\r\n        exactly as they will against a database — only the persistence is missing.\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  @if (editorOpen()) {\r\n    <!--\r\n      The editor replaces the page body while it is open, rather than sitting below the list.\r\n\r\n      A form this long beneath a table means the admin loses track of which row they are changing —\r\n      and the preview tool above it would be showing a resolution that predates their unsaved edits,\r\n      which is worse than showing nothing.\r\n    -->\r\n    <cms-form-config-editor\r\n      [editing]=\"editingRow()\"\r\n      (saved)=\"onSaved()\"\r\n      (cancelled)=\"closeEditor()\"\r\n    />\r\n  } @else {\r\n\r\n  <!--\r\n    🔑 THE PREVIEW TOOL — first on the page, ahead of the list, on purpose.\r\n\r\n    The question an admin actually arrives with is \"given a contract like THIS, what will the form\r\n    do?\", and the ranking rules are hard to hold in your head once a dozen rows exist. The list\r\n    answers \"what rows are there\"; this answers the question.\r\n\r\n    It calls the same `resolve` endpoint the record screen calls, so it cannot disagree with\r\n    production — a preview with its own copy of the ranking rules would be a second answer to\r\n    \"which configuration wins\".\r\n  -->\r\n  <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n    <div class=\"cws:space-y-1\">\r\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview a resolution</h3>\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Enter any combination — leave a box empty to mean <em>any</em>. Or give a contract number and\r\n        the server derives all three dimensions from the contract itself, which is the only way to\r\n        get the contract type right (CTRM derives it and does not accept it on a write).\r\n      </p>\r\n    </div>\r\n\r\n    <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type class</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewType\"\r\n          placeholder=\"e.g. BCO - English\"\r\n          [(ngModel)]=\"previewType\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Trade unit</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewLocation\"\r\n          placeholder=\"e.g. 0210\"\r\n          [(ngModel)]=\"previewLocation\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewCommodity\"\r\n          placeholder=\"e.g. YC\"\r\n          [(ngModel)]=\"previewCommodity\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n          Or a contract number\r\n        </span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewContract\"\r\n          placeholder=\"e.g. SC1240000\"\r\n          [(ngModel)]=\"previewContract\"\r\n        />\r\n      </label>\r\n    </div>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"runPreview()\">\r\n      Resolve\r\n    </button>\r\n\r\n    @if (previewProvenance() !== null) {\r\n      <div class=\"cws:space-y-3 cws:border-t cws:border-slate-200 cws:pt-4 cws:dark:border-slate-700\">\r\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\" data-testid=\"preview-provenance\">\r\n          {{ previewProvenance() }}\r\n        </p>\r\n\r\n        <dl class=\"cws:grid cws:gap-3 cws:text-sm cws:sm:grid-cols-3\">\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Tabs</dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-tabs\">\r\n              {{ previewTabs().length > 0 ? previewTabs().join(', ') : '—' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Required fields ({{ previewRequired().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-required\">\r\n              {{ previewRequired().length > 0 ? previewRequired().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Hidden fields ({{ previewHidden().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-hidden\">\r\n              {{ previewHidden().length > 0 ? previewHidden().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n        </dl>\r\n\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Auto-calculation: {{ preview()?.tradeUnitAttributes.autoCalculationMode }} · Pending\r\n          contracts:\r\n          {{ preview()?.tradeUnitAttributes.pendingContractsEnabled ? 'enabled' : 'disabled' }}\r\n        </p>\r\n      </div>\r\n    }\r\n  </div>\r\n\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Configuration rows</h3>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"startNew()\">\r\n      New configuration\r\n    </button>\r\n  </div>\r\n\r\n  <cms-async-container\r\n    [data]=\"listState()\"\r\n    [empty]=\"rows().length === 0\"\r\n    emptyMessage=\"No configuration rows exist yet, so every contract resolves to the built-in defaults generated from the field layout.\"\r\n    loadingLabel=\"Loading form configuration\"\r\n    (retry)=\"reload()\"\r\n  >\r\n    <div class=\"scoular-card cws:overflow-x-auto\">\r\n      <table class=\"cws:w-full cws:text-sm\">\r\n        <caption class=\"sr-only\">Form configuration rows</caption>\r\n        <thead class=\"cws:border-b cws:border-slate-200 cws:text-left cws:dark:border-slate-700\">\r\n          <tr>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Contract type</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Trade unit</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Commodity</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Effective from</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Version</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Status</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Last changed</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">\r\n              <span class=\"sr-only\">Actions</span>\r\n            </th>\r\n          </tr>\r\n        </thead>\r\n        <tbody>\r\n          @for (row of rows(); track row.id) {\r\n            <tr class=\"cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\">\r\n              <!--\r\n                `Any` rather than a blank cell. A null dimension means \"this row applies to every\r\n                contract type\", and an empty cell reads as missing data — the opposite of what it says.\r\n              -->\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.contractTypeClass) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.locationCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.commodityCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.effectiveFrom }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.version }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                @if (row.isActive) {\r\n                  <span class=\"cws:text-emerald-700 cws:dark:text-emerald-400\">Active</span>\r\n                } @else {\r\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Deactivated</span>\r\n                }\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                {{ row.modifiedByUpn }}\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:text-right\">\r\n                @if (row.isActive) {\r\n                  <span class=\"cws:inline-flex cws:gap-2\">\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"loadingEditor()\"\r\n                      (click)=\"edit(row)\"\r\n                    >\r\n                      Edit\r\n                    </button>\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      (click)=\"deactivate(row)\"\r\n                    >\r\n                      Deactivate\r\n                    </button>\r\n                  </span>\r\n                }\r\n                <!--\r\n                  F8.6. Offered on deactivated rows too, deliberately: the audit outlives its\r\n                  subject, and the history of a row someone turned off is exactly what an auditor\r\n                  came to read.\r\n                -->\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary cws:ml-2\"\r\n                  [attr.aria-expanded]=\"auditRowId() === row.id\"\r\n                  (click)=\"toggleAudit(row)\"\r\n                >\r\n                  {{ auditRowId() === row.id ? 'Hide history' : 'History' }}\r\n                </button>\r\n              </td>\r\n            </tr>\r\n\r\n            @if (auditRowId() === row.id) {\r\n              <tr>\r\n                <td colspan=\"7\" class=\"cws:bg-slate-50 cws:px-3 cws:py-3 cws:dark:bg-slate-900/40\">\r\n                  @switch (auditState().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading history…</p>\r\n                    }\r\n                    @case ('error') {\r\n                      <p class=\"cws:text-xs cws:text-rose-700 cws:dark:text-rose-400\" role=\"alert\">\r\n                        {{ auditError() }}\r\n                      </p>\r\n                    }\r\n                    @default {\r\n                      <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        Newest first. Each entry lists what changed against the entry before it —\r\n                        the stored snapshots are full documents, so this is derived, not a second\r\n                        record.\r\n                      </p>\r\n\r\n                      @for (item of auditEntries(); track item.entry.auditId) {\r\n                        <details class=\"cws:mb-1 cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\r\n                          <summary\r\n                            class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-xs\"\r\n                            [attr.data-testid]=\"'audit-summary-' + item.entry.auditId\"\r\n                          >\r\n                            <span class=\"cws:font-medium\">{{ item.entry.changeType }}</span>\r\n                            · v{{ item.entry.version }}\r\n                            · {{ item.entry.timestampUtc }}\r\n                            · {{ item.entry.actorUpn }}\r\n                            <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              @if (item.isOldest) {\r\n                                — the oldest entry held; nothing before it to compare\r\n                              } @else if (item.changes.length === 0) {\r\n                                — no field changed\r\n                              } @else {\r\n                                — {{ item.changes.length }}\r\n                                {{ item.changes.length === 1 ? 'change' : 'changes' }}\r\n                              }\r\n                            </span>\r\n                          </summary>\r\n\r\n                          @if (item.changes.length > 0) {\r\n                            <ul\r\n                              class=\"cws:space-y-1 cws:px-4 cws:pb-3 cws:pt-1 cws:text-xs\"\r\n                              [attr.data-testid]=\"'audit-changes-' + item.entry.auditId\"\r\n                            >\r\n                              @for (change of item.changes; track change.scope + change.subject + change.property) {\r\n                                <li>\r\n                                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">{{ change.scope }}</span>\r\n                                  <span class=\"cws:font-medium\">{{ change.subject }}</span>\r\n                                  @if (change.property !== '') {\r\n                                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">·{{ change.property }}</span>\r\n                                  }\r\n                                  @if (change.before !== '' && change.after !== '') {\r\n                                    : {{ change.before }} → {{ change.after }}\r\n                                  }\r\n                                </li>\r\n                              }\r\n                            </ul>\r\n                          }\r\n                        </details>\r\n                      } @empty {\r\n                        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          No history recorded for this row.\r\n                        </p>\r\n                      }\r\n                    }\r\n                  }\r\n                </td>\r\n              </tr>\r\n            }\r\n          }\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n\r\n    <p class=\"cws:mt-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Deactivating is a soft delete: the row stops resolving and frees its dimensions for a\r\n      replacement, and every change is kept in the configuration audit trail with who made it.\r\n    </p>\r\n  </cms-async-container>\r\n\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: FormConfigEditorComponent,
				selector: "cms-form-config-editor",
				inputs: ["editing"],
				outputs: ["saved", "cancelled"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: FormConfigAdminPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-config-admin-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				FormsModule,
				FormConfigEditorComponent,
				PageHeaderComponent
			],
			template: "<section class=\"cws:space-y-6\">\r\n  <cms-page-header\r\n    title=\"Form configuration\"\r\n    description=\"Which fields the contract record screen shows, which it requires, and which tabs exist, resolved per contract type, trade unit and commodity. Most specific match wins; the whole configuration applies, with no merging between rows.\"\r\n  />\r\n\r\n  @if (notDurable()) {\r\n    <!--\r\n      Said out loud rather than assumed. No deployed environment has a configuration database\r\n      connection string yet, so the honest answer is usually \"in memory\" — and an admin whose saved\r\n      configuration vanishes on the next restart, without having been told, is owed an explanation\r\n      nobody can give them afterwards.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Configuration is not being stored durably</div>\r\n      <div class=\"scoular-alert-description\">\r\n        This environment has no configuration database configured, so rows are held in memory and are\r\n        lost when the application restarts. Resolution, validation and the audit trail all behave\r\n        exactly as they will against a database — only the persistence is missing.\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  @if (editorOpen()) {\r\n    <!--\r\n      The editor replaces the page body while it is open, rather than sitting below the list.\r\n\r\n      A form this long beneath a table means the admin loses track of which row they are changing —\r\n      and the preview tool above it would be showing a resolution that predates their unsaved edits,\r\n      which is worse than showing nothing.\r\n    -->\r\n    <cms-form-config-editor\r\n      [editing]=\"editingRow()\"\r\n      (saved)=\"onSaved()\"\r\n      (cancelled)=\"closeEditor()\"\r\n    />\r\n  } @else {\r\n\r\n  <!--\r\n    🔑 THE PREVIEW TOOL — first on the page, ahead of the list, on purpose.\r\n\r\n    The question an admin actually arrives with is \"given a contract like THIS, what will the form\r\n    do?\", and the ranking rules are hard to hold in your head once a dozen rows exist. The list\r\n    answers \"what rows are there\"; this answers the question.\r\n\r\n    It calls the same `resolve` endpoint the record screen calls, so it cannot disagree with\r\n    production — a preview with its own copy of the ranking rules would be a second answer to\r\n    \"which configuration wins\".\r\n  -->\r\n  <div class=\"scoular-card cws:space-y-4 cws:p-4\">\r\n    <div class=\"cws:space-y-1\">\r\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview a resolution</h3>\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Enter any combination — leave a box empty to mean <em>any</em>. Or give a contract number and\r\n        the server derives all three dimensions from the contract itself, which is the only way to\r\n        get the contract type right (CTRM derives it and does not accept it on a write).\r\n      </p>\r\n    </div>\r\n\r\n    <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type class</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewType\"\r\n          placeholder=\"e.g. BCO - English\"\r\n          [(ngModel)]=\"previewType\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Trade unit</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewLocation\"\r\n          placeholder=\"e.g. 0210\"\r\n          [(ngModel)]=\"previewLocation\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewCommodity\"\r\n          placeholder=\"e.g. YC\"\r\n          [(ngModel)]=\"previewCommodity\"\r\n        />\r\n      </label>\r\n\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n          Or a contract number\r\n        </span>\r\n        <input\r\n          class=\"scoular-form-input cws:w-full\"\r\n          name=\"previewContract\"\r\n          placeholder=\"e.g. SC1240000\"\r\n          [(ngModel)]=\"previewContract\"\r\n        />\r\n      </label>\r\n    </div>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"runPreview()\">\r\n      Resolve\r\n    </button>\r\n\r\n    @if (previewProvenance() !== null) {\r\n      <div class=\"cws:space-y-3 cws:border-t cws:border-slate-200 cws:pt-4 cws:dark:border-slate-700\">\r\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\" data-testid=\"preview-provenance\">\r\n          {{ previewProvenance() }}\r\n        </p>\r\n\r\n        <dl class=\"cws:grid cws:gap-3 cws:text-sm cws:sm:grid-cols-3\">\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Tabs</dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-tabs\">\r\n              {{ previewTabs().length > 0 ? previewTabs().join(', ') : '—' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Required fields ({{ previewRequired().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-required\">\r\n              {{ previewRequired().length > 0 ? previewRequired().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n\r\n          <div>\r\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Hidden fields ({{ previewHidden().length }})\r\n            </dt>\r\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-hidden\">\r\n              {{ previewHidden().length > 0 ? previewHidden().join(', ') : 'None' }}\r\n            </dd>\r\n          </div>\r\n        </dl>\r\n\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Auto-calculation: {{ preview()?.tradeUnitAttributes.autoCalculationMode }} · Pending\r\n          contracts:\r\n          {{ preview()?.tradeUnitAttributes.pendingContractsEnabled ? 'enabled' : 'disabled' }}\r\n        </p>\r\n      </div>\r\n    }\r\n  </div>\r\n\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Configuration rows</h3>\r\n\r\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"startNew()\">\r\n      New configuration\r\n    </button>\r\n  </div>\r\n\r\n  <cms-async-container\r\n    [data]=\"listState()\"\r\n    [empty]=\"rows().length === 0\"\r\n    emptyMessage=\"No configuration rows exist yet, so every contract resolves to the built-in defaults generated from the field layout.\"\r\n    loadingLabel=\"Loading form configuration\"\r\n    (retry)=\"reload()\"\r\n  >\r\n    <div class=\"scoular-card cws:overflow-x-auto\">\r\n      <table class=\"cws:w-full cws:text-sm\">\r\n        <caption class=\"sr-only\">Form configuration rows</caption>\r\n        <thead class=\"cws:border-b cws:border-slate-200 cws:text-left cws:dark:border-slate-700\">\r\n          <tr>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Contract type</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Trade unit</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Commodity</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Effective from</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Version</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Status</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Last changed</th>\r\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">\r\n              <span class=\"sr-only\">Actions</span>\r\n            </th>\r\n          </tr>\r\n        </thead>\r\n        <tbody>\r\n          @for (row of rows(); track row.id) {\r\n            <tr class=\"cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\">\r\n              <!--\r\n                `Any` rather than a blank cell. A null dimension means \"this row applies to every\r\n                contract type\", and an empty cell reads as missing data — the opposite of what it says.\r\n              -->\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.contractTypeClass) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.locationCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.commodityCode) }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.effectiveFrom }}</td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.version }}</td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                @if (row.isActive) {\r\n                  <span class=\"cws:text-emerald-700 cws:dark:text-emerald-400\">Active</span>\r\n                } @else {\r\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Deactivated</span>\r\n                }\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2\">\r\n                {{ row.modifiedByUpn }}\r\n              </td>\r\n              <td class=\"cws:px-3 cws:py-2 cws:text-right\">\r\n                @if (row.isActive) {\r\n                  <span class=\"cws:inline-flex cws:gap-2\">\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"loadingEditor()\"\r\n                      (click)=\"edit(row)\"\r\n                    >\r\n                      Edit\r\n                    </button>\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      (click)=\"deactivate(row)\"\r\n                    >\r\n                      Deactivate\r\n                    </button>\r\n                  </span>\r\n                }\r\n                <!--\r\n                  F8.6. Offered on deactivated rows too, deliberately: the audit outlives its\r\n                  subject, and the history of a row someone turned off is exactly what an auditor\r\n                  came to read.\r\n                -->\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary cws:ml-2\"\r\n                  [attr.aria-expanded]=\"auditRowId() === row.id\"\r\n                  (click)=\"toggleAudit(row)\"\r\n                >\r\n                  {{ auditRowId() === row.id ? 'Hide history' : 'History' }}\r\n                </button>\r\n              </td>\r\n            </tr>\r\n\r\n            @if (auditRowId() === row.id) {\r\n              <tr>\r\n                <td colspan=\"7\" class=\"cws:bg-slate-50 cws:px-3 cws:py-3 cws:dark:bg-slate-900/40\">\r\n                  @switch (auditState().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading history…</p>\r\n                    }\r\n                    @case ('error') {\r\n                      <p class=\"cws:text-xs cws:text-rose-700 cws:dark:text-rose-400\" role=\"alert\">\r\n                        {{ auditError() }}\r\n                      </p>\r\n                    }\r\n                    @default {\r\n                      <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        Newest first. Each entry lists what changed against the entry before it —\r\n                        the stored snapshots are full documents, so this is derived, not a second\r\n                        record.\r\n                      </p>\r\n\r\n                      @for (item of auditEntries(); track item.entry.auditId) {\r\n                        <details class=\"cws:mb-1 cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\r\n                          <summary\r\n                            class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-xs\"\r\n                            [attr.data-testid]=\"'audit-summary-' + item.entry.auditId\"\r\n                          >\r\n                            <span class=\"cws:font-medium\">{{ item.entry.changeType }}</span>\r\n                            · v{{ item.entry.version }}\r\n                            · {{ item.entry.timestampUtc }}\r\n                            · {{ item.entry.actorUpn }}\r\n                            <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n                              @if (item.isOldest) {\r\n                                — the oldest entry held; nothing before it to compare\r\n                              } @else if (item.changes.length === 0) {\r\n                                — no field changed\r\n                              } @else {\r\n                                — {{ item.changes.length }}\r\n                                {{ item.changes.length === 1 ? 'change' : 'changes' }}\r\n                              }\r\n                            </span>\r\n                          </summary>\r\n\r\n                          @if (item.changes.length > 0) {\r\n                            <ul\r\n                              class=\"cws:space-y-1 cws:px-4 cws:pb-3 cws:pt-1 cws:text-xs\"\r\n                              [attr.data-testid]=\"'audit-changes-' + item.entry.auditId\"\r\n                            >\r\n                              @for (change of item.changes; track change.scope + change.subject + change.property) {\r\n                                <li>\r\n                                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">{{ change.scope }}</span>\r\n                                  <span class=\"cws:font-medium\">{{ change.subject }}</span>\r\n                                  @if (change.property !== '') {\r\n                                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">·{{ change.property }}</span>\r\n                                  }\r\n                                  @if (change.before !== '' && change.after !== '') {\r\n                                    : {{ change.before }} → {{ change.after }}\r\n                                  }\r\n                                </li>\r\n                              }\r\n                            </ul>\r\n                          }\r\n                        </details>\r\n                      } @empty {\r\n                        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          No history recorded for this row.\r\n                        </p>\r\n                      }\r\n                    }\r\n                  }\r\n                </td>\r\n              </tr>\r\n            }\r\n          }\r\n        </tbody>\r\n      </table>\r\n    </div>\r\n\r\n    <p class=\"cws:mt-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Deactivating is a soft delete: the row stops resolving and frees its dimensions for a\r\n      replacement, and every change is kept in the configuration audit trail with who made it.\r\n    </p>\r\n  </cms-async-container>\r\n\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => []
});
function dimensionLabel(dimension) {
	switch (dimension) {
		case "contractTypeClass": return "contract type";
		case "locationCode": return "location";
		case "commodityCode": return "commodity";
		default: return dimension;
	}
}
const EMPTY_DOCUMENT = {
	schemaVersion: 0,
	tabs: [],
	sections: [],
	fields: {},
	attributes: {
		autoCalculationMode: "",
		pendingContractsEnabled: false
	}
};
function parseSnapshot(json) {
	try {
		return JSON.parse(json);
	} catch {
		return null;
	}
}
var RolesPageComponent = class RolesPageComponent {
	permissions = PROVISIONAL_PERMISSIONS;
	acknowledged = signal(false, ...ngDevMode ? [{ debugName: "acknowledged" }] : /* istanbul ignore next */ []);
	acknowledge() {
		this.acknowledged.set(true);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RolesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RolesPageComponent,
		isStandalone: true,
		selector: "cws-roles-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Roles and permissions</h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Permissions are grouped into named roles and held per trade unit, rather than ticked per\r\n      person. A new role is a row, so the list of roles can be settled without a code change.\r\n    </p>\r\n  </header>\r\n\r\n  <!--\r\n    🔴 THE CONTROL. Not decoration, and not removable without the ruling it names.\r\n\r\n    The stopgap contract-writer policy has already been read TWICE as though this matrix were\r\n    built. Seven tidy checkboxes are the most convincing possible version of that mistake, so the\r\n    screen states what it is above the content -- every load, not once per session.\r\n  -->\r\n  <div\r\n    class=\"cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:dark:border-amber-800 cws:dark:bg-amber-950\"\r\n    role=\"note\"\r\n    data-testid=\"provisional-banner\"\r\n  >\r\n    <p class=\"cws:text-sm cws:font-semibold cws:text-amber-900 cws:dark:text-amber-200\">\r\n      Provisional — this permission set is not agreed yet\r\n    </p>\r\n    <!--\r\n      ⚠ No issue number in this sentence, deliberately, and the tracking reference lives in the\r\n      component's doc comment instead. `user-facing-copy.spec.ts` refuses internal identifiers in\r\n      user-visible copy and it is right to: an administrator cannot open an issue, so \"#138\" tells\r\n      them a decision exists and gives them no way to reach it. What they CAN act on is the shape\r\n      of the caveat, which is what this says.\r\n    -->\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n      The seven permissions below are believed correct but are awaiting a business decision. That\r\n      decision may change which roles hold which permissions, or the granularity itself — so treat\r\n      anything configured here as a draft, and do not rely on it to describe who can do what today.\r\n      Enforcement across the application is not wired to these rows yet.\r\n    </p>\r\n  </div>\r\n\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">The provisional seven</h4>\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Each gates the actions named beside it, for the trade unit the role is held on. An\r\n      administrator flag overrides all of them. Reading a contract is deliberately not gated:\r\n      any assigned user may read any contract, and the form goes read-only rather than invisible.\r\n    </p>\r\n\r\n    <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n      <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <tr>\r\n          <th class=\"cws:py-1\">Permission</th>\r\n          <th class=\"cws:py-1\">Stored as</th>\r\n          <th class=\"cws:py-1\">Gates</th>\r\n        </tr>\r\n      </thead>\r\n      <tbody data-testid=\"permission-rows\">\r\n        @for (permission of permissions; track permission.key) {\r\n          <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n            <td class=\"cws:py-1 cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ permission.name }}</td>\r\n            <td class=\"cws:py-1 cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</td>\r\n            <td class=\"cws:py-1\">{{ permission.description }}</td>\r\n          </tr>\r\n        }\r\n      </tbody>\r\n    </table>\r\n  </div>\r\n\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Role catalog</h4>\r\n    <!--\r\n      ⚠ Deliberately empty and deliberately explained. 01 §5 rules the role list a workshop item\r\n      that \"must not be invented here\", so seeding a guessed catalog would be answering the\r\n      question the workshop exists to answer. The screen says why it is empty rather than looking\r\n      unfinished.\r\n    -->\r\n    <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"catalog-empty\">\r\n      No roles are defined, and none are shipped by default. The role names the business is\r\n      considering — Trader, Merchandiser Assistant, Approver, Accounting &amp; Control, CWS\r\n      Administrator — are a workshop decision, so they are not pre-created here. The schema is\r\n      ready: a role is a row, and adding one needs no deployment.\r\n    </p>\r\n  </div>\r\n</section>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RolesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-roles-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<section class=\"cws:space-y-4\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Roles and permissions</h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Permissions are grouped into named roles and held per trade unit, rather than ticked per\r\n      person. A new role is a row, so the list of roles can be settled without a code change.\r\n    </p>\r\n  </header>\r\n\r\n  <!--\r\n    🔴 THE CONTROL. Not decoration, and not removable without the ruling it names.\r\n\r\n    The stopgap contract-writer policy has already been read TWICE as though this matrix were\r\n    built. Seven tidy checkboxes are the most convincing possible version of that mistake, so the\r\n    screen states what it is above the content -- every load, not once per session.\r\n  -->\r\n  <div\r\n    class=\"cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:dark:border-amber-800 cws:dark:bg-amber-950\"\r\n    role=\"note\"\r\n    data-testid=\"provisional-banner\"\r\n  >\r\n    <p class=\"cws:text-sm cws:font-semibold cws:text-amber-900 cws:dark:text-amber-200\">\r\n      Provisional — this permission set is not agreed yet\r\n    </p>\r\n    <!--\r\n      ⚠ No issue number in this sentence, deliberately, and the tracking reference lives in the\r\n      component's doc comment instead. `user-facing-copy.spec.ts` refuses internal identifiers in\r\n      user-visible copy and it is right to: an administrator cannot open an issue, so \"#138\" tells\r\n      them a decision exists and gives them no way to reach it. What they CAN act on is the shape\r\n      of the caveat, which is what this says.\r\n    -->\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\r\n      The seven permissions below are believed correct but are awaiting a business decision. That\r\n      decision may change which roles hold which permissions, or the granularity itself — so treat\r\n      anything configured here as a draft, and do not rely on it to describe who can do what today.\r\n      Enforcement across the application is not wired to these rows yet.\r\n    </p>\r\n  </div>\r\n\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">The provisional seven</h4>\r\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Each gates the actions named beside it, for the trade unit the role is held on. An\r\n      administrator flag overrides all of them. Reading a contract is deliberately not gated:\r\n      any assigned user may read any contract, and the form goes read-only rather than invisible.\r\n    </p>\r\n\r\n    <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\r\n      <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n        <tr>\r\n          <th class=\"cws:py-1\">Permission</th>\r\n          <th class=\"cws:py-1\">Stored as</th>\r\n          <th class=\"cws:py-1\">Gates</th>\r\n        </tr>\r\n      </thead>\r\n      <tbody data-testid=\"permission-rows\">\r\n        @for (permission of permissions; track permission.key) {\r\n          <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n            <td class=\"cws:py-1 cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ permission.name }}</td>\r\n            <td class=\"cws:py-1 cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</td>\r\n            <td class=\"cws:py-1\">{{ permission.description }}</td>\r\n          </tr>\r\n        }\r\n      </tbody>\r\n    </table>\r\n  </div>\r\n\r\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n    <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Role catalog</h4>\r\n    <!--\r\n      ⚠ Deliberately empty and deliberately explained. 01 §5 rules the role list a workshop item\r\n      that \"must not be invented here\", so seeding a guessed catalog would be answering the\r\n      question the workshop exists to answer. The screen says why it is empty rather than looking\r\n      unfinished.\r\n    -->\r\n    <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"catalog-empty\">\r\n      No roles are defined, and none are shipped by default. The role names the business is\r\n      considering — Trader, Merchandiser Assistant, Approver, Accounting &amp; Control, CWS\r\n      Administrator — are a workshop decision, so they are not pre-created here. The schema is\r\n      ready: a role is a row, and adding one needs no deployment.\r\n    </p>\r\n  </div>\r\n</section>\r\n"
		}]
	}]
});
const PROVISIONAL_PERMISSIONS = [
	{
		key: "contracts:update",
		name: "Create & edit contracts",
		description: "Create, edit and copy contracts; close and reopen; delete pending; save."
	},
	{
		key: "broker-confirmations:update",
		name: "Save broker confirmations",
		description: "The broker-confirmation save path."
	},
	{
		key: "contracts:approve",
		name: "Approve contracts",
		description: "Contract approval queue; approve and reject."
	},
	{
		key: "prices:update",
		name: "Edit prices",
		description: "Pricing screens; create, edit and delete price sequences."
	},
	{
		key: "prices:approve",
		name: "Approve prices",
		description: "Pricing approval queue; approve prices. CTRM's approver type still applies."
	},
	{
		key: "templates:manage",
		name: "Manage templates",
		description: "Create and edit templates, and Save As Template."
	},
	{
		key: "settings:manage",
		name: "Administer the application",
		description: "Admin module access."
	}
];
var TradeUnitValuesPageComponent = class TradeUnitValuesPageComponent {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	tradeUnit = signal("", ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	values = signal([], ...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	months = signal([], ...ngDevMode ? [{ debugName: "months" }] : /* istanbul ignore next */ []);
	loaded = signal(false, ...ngDevMode ? [{ debugName: "loaded" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	error = signal(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	componentName = "";
	value = "";
	include = true;
	commodity = "";
	marketMonth = "";
	hasTradeUnit = computed(() => this.tradeUnit().trim() !== "", ...ngDevMode ? [{ debugName: "hasTradeUnit" }] : /* istanbul ignore next */ []);
	load() {
		const unit = this.tradeUnit().trim();
		if (unit === "") return;
		this.busy.set(true);
		this.error.set(null);
		Promise.all([this.get("values", unit), this.get("market-months", unit)]).then(([values, months]) => {
			this.values.set(values);
			this.months.set(months);
			this.loaded.set(true);
		}).catch((reason) => this.error.set(describe(reason))).finally(() => this.busy.set(false));
	}
	addValue() {
		const unit = this.tradeUnit().trim();
		if (unit === "" || this.componentName.trim() === "" || this.value.trim() === "") {
			this.error.set("Trade unit, component and value are all required.");
			return;
		}
		this.send("PUT", "values", {
			tradeUnit: unit,
			componentName: this.componentName.trim(),
			value: this.value.trim(),
			include: this.include
		}).then(() => {
			this.value = "";
			this.load();
		});
	}
	removeValue(row) {
		this.send("DELETE", `values/${row.id}`).then(() => this.load());
	}
	addMonth() {
		const unit = this.tradeUnit().trim();
		if (unit === "" || this.commodity.trim() === "" || this.marketMonth.trim() === "") {
			this.error.set("Trade unit, commodity and month are all required.");
			return;
		}
		this.send("POST", "market-months", {
			tradeUnit: unit,
			commodity: this.commodity.trim(),
			marketMonth: this.marketMonth.trim()
		}).then(() => {
			this.marketMonth = "";
			this.load();
		});
	}
	removeMonth(row) {
		this.send("DELETE", `market-months/${row.id}`).then(() => this.load());
	}
	async get(set, tradeUnit) {
		return (await this.request("GET", `${set}?tradeUnit=${encodeURIComponent(tradeUnit)}`))?.rows ?? [];
	}
	async send(method, path, body) {
		this.busy.set(true);
		this.error.set(null);
		try {
			await this.request(method, path, body);
		} catch (reason) {
			this.error.set(describe(reason));
		} finally {
			this.busy.set(false);
		}
	}
	request(method, path, body) {
		return new Promise((resolve, reject) => {
			this.http.request(method, `${this.baseUrl}/trade-unit-values/${path}`, { body }).subscribe({
				next: (value) => resolve(value),
				error: reject,
				complete: () => resolve(void 0)
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: TradeUnitValuesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: TradeUnitValuesPageComponent,
		isStandalone: true,
		selector: "cws-trade-unit-values-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">What a trade unit offers</h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Narrows the values CTRM already offers on this trade unit's contracts — allowed values per\r\n      field, and market months per commodity. It can only take options away, never add them: CTRM\r\n      refuses a value it did not offer, so a month or code added here would fail on save with\r\n      nothing on the screen able to explain why.\r\n    </p>\r\n  </header>\r\n\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n    <label class=\"cws:space-y-1\">\r\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Trade unit</span>\r\n      <input\r\n        class=\"scoular-form-input cws:mt-1 cws:w-40\"\r\n        placeholder=\"e.g. 2087\"\r\n        [ngModel]=\"tradeUnit()\"\r\n        (ngModelChange)=\"tradeUnit.set($event)\"\r\n        name=\"tradeUnit\"\r\n      />\r\n    </label>\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-primary\"\r\n      [disabled]=\"!hasTradeUnit() || busy()\"\r\n      (click)=\"load()\"\r\n    >\r\n      {{ busy() ? 'Working…' : 'Load' }}\r\n    </button>\r\n  </div>\r\n\r\n  @if (error(); as message) {\r\n    <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n      {{ message }}\r\n    </p>\r\n  }\r\n\r\n  @if (loaded()) {\r\n    <!-- F8.2 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Allowed values</h4>\r\n\r\n      @if (values().length === 0) {\r\n        <!--\r\n          🔴 The counter-intuitive state, said in words. An empty allow-list screen normally means\r\n          \"nothing is permitted\"; here it means the opposite, and an administrator who assumed the\r\n          usual reading would key in every value by hand to \"fix\" a trade unit that is already\r\n          working correctly.\r\n        -->\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"values-empty\">\r\n          Nothing configured, so every value CTRM offers is available on this trade unit. Adding a\r\n          row here starts an allow-list and everything not on it stops being offered.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Field</th>\r\n              <th class=\"cws:py-1\">Value</th>\r\n              <th class=\"cws:py-1\">Offered</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"values-rows\">\r\n            @for (row of values(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">{{ row.componentName }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.value }}</td>\r\n                <td class=\"cws:py-1\">{{ row.include ? 'Yes' : 'No — excluded' }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.value + ' from ' + row.componentName\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeValue(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Field</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-56\" [(ngModel)]=\"componentName\" name=\"componentName\"\r\n                 placeholder=\"e.g. PriceTypeCode\" />\r\n        </label>\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Value</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"value\" name=\"value\" placeholder=\"e.g. P\" />\r\n        </label>\r\n        <label class=\"cws:flex cws:items-center cws:gap-2 cws:pb-2 cws:text-xs\">\r\n          <input type=\"checkbox\" [(ngModel)]=\"include\" name=\"include\" />\r\n          Offered\r\n        </label>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addValue()\">\r\n          Add value\r\n        </button>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- F8.5 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Market months</h4>\r\n\r\n      @if (months().length === 0) {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"months-empty\">\r\n          Nothing configured, so every month CTRM returns for a commodity is offered. Adding a row\r\n          narrows the list to what is listed here for that commodity.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Commodity</th>\r\n              <th class=\"cws:py-1\">Month</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"months-rows\">\r\n            @for (row of months(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.commodity }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.marketMonth }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.marketMonth + ' from ' + row.commodity\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeMonth(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"commodity\" name=\"commodity\" placeholder=\"e.g. YC\" />\r\n        </label>\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Month</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"marketMonth\" name=\"marketMonth\" placeholder=\"e.g. Z26\" />\r\n        </label>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addMonth()\">\r\n          Add month\r\n        </button>\r\n      </div>\r\n    </div>\r\n  }\r\n</section>\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: TradeUnitValuesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-trade-unit-values-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormsModule],
			template: "<section class=\"cws:space-y-4\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">What a trade unit offers</h3>\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n      Narrows the values CTRM already offers on this trade unit's contracts — allowed values per\r\n      field, and market months per commodity. It can only take options away, never add them: CTRM\r\n      refuses a value it did not offer, so a month or code added here would fail on save with\r\n      nothing on the screen able to explain why.\r\n    </p>\r\n  </header>\r\n\r\n  <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n    <label class=\"cws:space-y-1\">\r\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Trade unit</span>\r\n      <input\r\n        class=\"scoular-form-input cws:mt-1 cws:w-40\"\r\n        placeholder=\"e.g. 2087\"\r\n        [ngModel]=\"tradeUnit()\"\r\n        (ngModelChange)=\"tradeUnit.set($event)\"\r\n        name=\"tradeUnit\"\r\n      />\r\n    </label>\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-primary\"\r\n      [disabled]=\"!hasTradeUnit() || busy()\"\r\n      (click)=\"load()\"\r\n    >\r\n      {{ busy() ? 'Working…' : 'Load' }}\r\n    </button>\r\n  </div>\r\n\r\n  @if (error(); as message) {\r\n    <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n      {{ message }}\r\n    </p>\r\n  }\r\n\r\n  @if (loaded()) {\r\n    <!-- F8.2 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Allowed values</h4>\r\n\r\n      @if (values().length === 0) {\r\n        <!--\r\n          🔴 The counter-intuitive state, said in words. An empty allow-list screen normally means\r\n          \"nothing is permitted\"; here it means the opposite, and an administrator who assumed the\r\n          usual reading would key in every value by hand to \"fix\" a trade unit that is already\r\n          working correctly.\r\n        -->\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"values-empty\">\r\n          Nothing configured, so every value CTRM offers is available on this trade unit. Adding a\r\n          row here starts an allow-list and everything not on it stops being offered.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Field</th>\r\n              <th class=\"cws:py-1\">Value</th>\r\n              <th class=\"cws:py-1\">Offered</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"values-rows\">\r\n            @for (row of values(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1\">{{ row.componentName }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.value }}</td>\r\n                <td class=\"cws:py-1\">{{ row.include ? 'Yes' : 'No — excluded' }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.value + ' from ' + row.componentName\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeValue(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Field</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-56\" [(ngModel)]=\"componentName\" name=\"componentName\"\r\n                 placeholder=\"e.g. PriceTypeCode\" />\r\n        </label>\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Value</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"value\" name=\"value\" placeholder=\"e.g. P\" />\r\n        </label>\r\n        <label class=\"cws:flex cws:items-center cws:gap-2 cws:pb-2 cws:text-xs\">\r\n          <input type=\"checkbox\" [(ngModel)]=\"include\" name=\"include\" />\r\n          Offered\r\n        </label>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addValue()\">\r\n          Add value\r\n        </button>\r\n      </div>\r\n    </div>\r\n\r\n    <!-- F8.5 -->\r\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\r\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Market months</h4>\r\n\r\n      @if (months().length === 0) {\r\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"months-empty\">\r\n          Nothing configured, so every month CTRM returns for a commodity is offered. Adding a row\r\n          narrows the list to what is listed here for that commodity.\r\n        </p>\r\n      } @else {\r\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\r\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n            <tr>\r\n              <th class=\"cws:py-1\">Commodity</th>\r\n              <th class=\"cws:py-1\">Month</th>\r\n              <th class=\"cws:py-1\">Last changed</th>\r\n              <th class=\"cws:py-1\"></th>\r\n            </tr>\r\n          </thead>\r\n          <tbody data-testid=\"months-rows\">\r\n            @for (row of months(); track row.id) {\r\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.commodity }}</td>\r\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.marketMonth }}</td>\r\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\r\n                <td class=\"cws:py-1 cws:text-right\">\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    [attr.aria-label]=\"'Remove ' + row.marketMonth + ' from ' + row.commodity\"\r\n                    [disabled]=\"busy()\"\r\n                    (click)=\"removeMonth(row)\"\r\n                  >\r\n                    Remove\r\n                  </button>\r\n                </td>\r\n              </tr>\r\n            }\r\n          </tbody>\r\n        </table>\r\n      }\r\n\r\n      <div class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-2\">\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"commodity\" name=\"commodity\" placeholder=\"e.g. YC\" />\r\n        </label>\r\n        <label class=\"cws:space-y-1\">\r\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Month</span>\r\n          <input class=\"scoular-form-input cws:mt-1 cws:w-32\" [(ngModel)]=\"marketMonth\" name=\"marketMonth\" placeholder=\"e.g. Z26\" />\r\n        </label>\r\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addMonth()\">\r\n          Add month\r\n        </button>\r\n      </div>\r\n    </div>\r\n  }\r\n</section>\r\n"
		}]
	}]
});
function describe(reason) {
	const status = reason?.status;
	if (status === 403) return "This account does not hold the Admin role, so it cannot change what a trade unit offers.";
	if (status === 400) return "All three key parts are required and none may be blank.";
	return "The configuration service could not be reached.";
}
var AdminPageComponent = class AdminPageComponent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AdminPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: AdminPageComponent,
		isStandalone: true,
		selector: "cms-admin-page",
		ngImport: i0,
		template: `
    <!--
      ⚠ No heading of its own. This screen renders one child that carries its own page header, so
      an "Admin" h2 here put TWO h2s on one page -- the second describing the whole screen and the
      first describing nothing under it.
    -->
    <section class="cws:space-y-6">
      <cms-form-config-admin-page />

      <!-- F8.2 / F8.5. Under form configuration rather than beside it: what a trade unit OFFERS is
           only meaningful once its fields are configured, and an administrator arriving to onboard
           a trade unit works down the page in that order. -->
      <div class="cws:border-t cws:border-slate-200 cws:pt-6 cws:dark:border-slate-700">
        <cws-trade-unit-values-page />
      </div>

      <!-- F10.3b. After what a trade unit offers and before roles: it is settled data an
           administrator maintains, and roles stays last for the reason given below. -->
      <div class="cws:border-t cws:border-slate-200 cws:pt-6 cws:dark:border-slate-700">
        <cws-addendum-templates-page />
      </div>

      <!-- F8.4. Last on the page on purpose: it is the one section whose content is not agreed, and
           its own banner says so. Putting a provisional section above two settled ones would make
           the settled ones read as provisional too. -->
      <div class="cws:border-t cws:border-slate-200 cws:pt-6 cws:dark:border-slate-700">
        <cws-roles-page />
      </div>

      <!-- The scope of what is still to come is docs/02 §7, epics E5 and E8. Named here rather than
           in the sentence below: an administrator has no access to the requirements set, so a
           document-and-section citation on screen is an unresolvable reference. -->
      <p class="cws:border-t cws:border-slate-200 cws:pt-4 cws:text-sm cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400">
        Still to come: contract templates, and assigning users to roles once the permission set is
        agreed.
      </p>
    </section>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: AddendumTemplatesPageComponent,
				selector: "cws-addendum-templates-page"
			},
			{
				kind: "component",
				type: FormConfigAdminPageComponent,
				selector: "cms-form-config-admin-page"
			},
			{
				kind: "component",
				type: RolesPageComponent,
				selector: "cws-roles-page"
			},
			{
				kind: "component",
				type: TradeUnitValuesPageComponent,
				selector: "cws-trade-unit-values-page"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: AdminPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-admin-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AddendumTemplatesPageComponent,
				FormConfigAdminPageComponent,
				RolesPageComponent,
				TradeUnitValuesPageComponent
			],
			template: `
    <!--
      ⚠ No heading of its own. This screen renders one child that carries its own page header, so
      an "Admin" h2 here put TWO h2s on one page -- the second describing the whole screen and the
      first describing nothing under it.
    -->
    <section class="cws:space-y-6">
      <cms-form-config-admin-page />

      <!-- F8.2 / F8.5. Under form configuration rather than beside it: what a trade unit OFFERS is
           only meaningful once its fields are configured, and an administrator arriving to onboard
           a trade unit works down the page in that order. -->
      <div class="cws:border-t cws:border-slate-200 cws:pt-6 cws:dark:border-slate-700">
        <cws-trade-unit-values-page />
      </div>

      <!-- F10.3b. After what a trade unit offers and before roles: it is settled data an
           administrator maintains, and roles stays last for the reason given below. -->
      <div class="cws:border-t cws:border-slate-200 cws:pt-6 cws:dark:border-slate-700">
        <cws-addendum-templates-page />
      </div>

      <!-- F8.4. Last on the page on purpose: it is the one section whose content is not agreed, and
           its own banner says so. Putting a provisional section above two settled ones would make
           the settled ones read as provisional too. -->
      <div class="cws:border-t cws:border-slate-200 cws:pt-6 cws:dark:border-slate-700">
        <cws-roles-page />
      </div>

      <!-- The scope of what is still to come is docs/02 §7, epics E5 and E8. Named here rather than
           in the sentence below: an administrator has no access to the requirements set, so a
           document-and-section citation on screen is an unresolvable reference. -->
      <p class="cws:border-t cws:border-slate-200 cws:pt-4 cws:text-sm cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400">
        Still to come: contract templates, and assigning users to roles once the permission set is
        agreed.
      </p>
    </section>
  `
		}]
	}]
});
export { AddendumTemplatesPageComponent, AdminPageComponent, FormConfigAdminPageComponent, FormConfigEditorComponent };

//# sourceMappingURL=cws-features-admin.mjs.map
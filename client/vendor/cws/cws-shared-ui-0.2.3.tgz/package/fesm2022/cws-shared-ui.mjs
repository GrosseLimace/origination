import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, HostListener, Injectable, InjectionToken, afterRenderEffect, computed, effect, forwardRef, inject, input, isDevMode, linkedSignal, output, signal, viewChild } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { Subject, debounceTime, map, of, switchMap } from "rxjs";
import { CdkTrapFocus } from "@angular/cdk/a11y";
import { CdkConnectedOverlay, CdkOverlayOrigin, Overlay } from "@angular/cdk/overlay";
import { addDays, addMonths, dayOfWeek, formatDisplayDate, fromIsoDate, isRealDate, parseShipPeriodDate, toIsoDate } from "@cws/shared-utils";
import { NgComponentOutlet } from "@angular/common";
import { CdkMenu, CdkMenuItem, CdkMenuTrigger } from "@angular/cdk/menu";
import { DIALOG_DATA, Dialog, DialogRef } from "@angular/cdk/dialog";
import { RouterLink } from "@angular/router";
const remoteIdle = () => ({ status: "idle" });
const remoteLoading = () => ({ status: "loading" });
const remoteLoaded = (value) => ({
	status: "loaded",
	value
});
const remoteError = (error) => ({
	status: "error",
	error
});
function remoteValue(data) {
	return data.status === "loaded" ? data.value : null;
}
var AsyncContainerComponent = class AsyncContainerComponent {
	data = input.required(...ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []);
	empty = input(false, ...ngDevMode ? [{ debugName: "empty" }] : /* istanbul ignore next */ []);
	emptyMessage = input("No results.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	loadingLabel = input("Loading", ...ngDevMode ? [{ debugName: "loadingLabel" }] : /* istanbul ignore next */ []);
	retry = output();
	isLoading = computed(() => {
		const status = this.data().status;
		return status === "loading" || status === "idle";
	}, ...ngDevMode ? [{ debugName: "isLoading" }] : /* istanbul ignore next */ []);
	error = computed(() => {
		const data = this.data();
		return data.status === "error" ? data.error : null;
	}, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	showContent = computed(() => this.data().status === "loaded" && !this.empty(), ...ngDevMode ? [{ debugName: "showContent" }] : /* istanbul ignore next */ []);
	showEmpty = computed(() => this.data().status === "loaded" && this.empty(), ...ngDevMode ? [{ debugName: "showEmpty" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AsyncContainerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AsyncContainerComponent,
		isStandalone: true,
		selector: "cms-async-container",
		inputs: {
			data: {
				classPropertyName: "data",
				publicName: "data",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			empty: {
				classPropertyName: "empty",
				publicName: "empty",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyMessage: {
				classPropertyName: "emptyMessage",
				publicName: "emptyMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loadingLabel: {
				classPropertyName: "loadingLabel",
				publicName: "loadingLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { retry: "retry" },
		ngImport: i0,
		template: "@if (isLoading()) {\n  <!--\n    role=\"status\" + aria-live announces the state change without stealing focus. The visual\n    spinner is aria-hidden so a screen reader gets the label once, not twice.\n  -->\n  <div\n    class=\"cws:flex cws:min-h-[50vh] cws:items-center cws:justify-center cws:gap-3\"\n    role=\"status\"\n    aria-live=\"polite\"\n  >\n    <span class=\"scoular-spinner\" aria-hidden=\"true\"></span>\n    <span class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ loadingLabel() }}</span>\n  </div>\n} @else if (error(); as remoteError) {\n  <!--\n    Centred in the content area rather than a full-width banner across the top (JFrisbie, 2026-08-31).\n\n    A failed load leaves the whole region empty, so the message belongs where the missing content would\n    have been — not pinned to the top edge with an acre of blank space under it, which is what the\n    screenshot showed. `min-h-[50vh]` is what makes \"centred\" mean centred *on the screen*: with the\n    page header and controls above it, the block lands near the middle of a typical viewport. Viewport\n    units rather than a fixed height so it holds on a laptop and on an ultrawide.\n\n    ⚠ **The loading state above carries the same `min-h-[50vh]`, and that is not incidental.** Without\n    it the spinner sits near the top and the error then appears halfway down — a jump on every failed\n    load, introduced by this change rather than pre-existing. The two states have to occupy the same\n    box.\n\n    role=\"alert\" is kept — a failure is assertive; the user has to know the region did not load.\n  -->\n  <div\n    class=\"cws:flex cws:min-h-[50vh] cws:flex-col cws:items-center cws:justify-center cws:gap-4 cws:px-4 cws:text-center\"\n    role=\"alert\"\n  >\n    <div class=\"cws:space-y-1\">\n      <!--\n        The design system's own error text colour, on the page background rather than on a tinted\n        alert fill. 4.5:1 against white — it clears AA, and only just, so do not lighten it.\n      -->\n      <p class=\"cws:text-sm cws:font-medium cws:text-scoular-red-dark cws:dark:text-scoular-red\">\n        {{ remoteError.message }}\n      </p>\n      @if (remoteError.correlationId) {\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Reference: <span class=\"cws:font-mono\">{{ remoteError.correlationId }}</span>\n        </p>\n      }\n    </div>\n\n    <!--\n      The same classes as the grid's \"Add Contract\", `border border-transparent` included — retrying is\n      the one thing to do from this screen, so it gets the primary treatment rather than the muted\n      secondary/small pairing it had.\n    -->\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n      (click)=\"retry.emit()\"\n    >\n      Retry\n    </button>\n  </div>\n} @else if (showEmpty()) {\n  <div class=\"cws:py-8 cws:text-center\">\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ emptyMessage() }}</p>\n    <!-- Primary action for the empty state, e.g. \"Clear filters\" (02a §5). -->\n    <div class=\"cws:mt-3\"><ng-content select=\"[cmsEmptyAction]\" /></div>\n  </div>\n} @else if (showContent()) {\n  <ng-content />\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AsyncContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-async-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "@if (isLoading()) {\n  <!--\n    role=\"status\" + aria-live announces the state change without stealing focus. The visual\n    spinner is aria-hidden so a screen reader gets the label once, not twice.\n  -->\n  <div\n    class=\"cws:flex cws:min-h-[50vh] cws:items-center cws:justify-center cws:gap-3\"\n    role=\"status\"\n    aria-live=\"polite\"\n  >\n    <span class=\"scoular-spinner\" aria-hidden=\"true\"></span>\n    <span class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ loadingLabel() }}</span>\n  </div>\n} @else if (error(); as remoteError) {\n  <!--\n    Centred in the content area rather than a full-width banner across the top (JFrisbie, 2026-08-31).\n\n    A failed load leaves the whole region empty, so the message belongs where the missing content would\n    have been — not pinned to the top edge with an acre of blank space under it, which is what the\n    screenshot showed. `min-h-[50vh]` is what makes \"centred\" mean centred *on the screen*: with the\n    page header and controls above it, the block lands near the middle of a typical viewport. Viewport\n    units rather than a fixed height so it holds on a laptop and on an ultrawide.\n\n    ⚠ **The loading state above carries the same `min-h-[50vh]`, and that is not incidental.** Without\n    it the spinner sits near the top and the error then appears halfway down — a jump on every failed\n    load, introduced by this change rather than pre-existing. The two states have to occupy the same\n    box.\n\n    role=\"alert\" is kept — a failure is assertive; the user has to know the region did not load.\n  -->\n  <div\n    class=\"cws:flex cws:min-h-[50vh] cws:flex-col cws:items-center cws:justify-center cws:gap-4 cws:px-4 cws:text-center\"\n    role=\"alert\"\n  >\n    <div class=\"cws:space-y-1\">\n      <!--\n        The design system's own error text colour, on the page background rather than on a tinted\n        alert fill. 4.5:1 against white — it clears AA, and only just, so do not lighten it.\n      -->\n      <p class=\"cws:text-sm cws:font-medium cws:text-scoular-red-dark cws:dark:text-scoular-red\">\n        {{ remoteError.message }}\n      </p>\n      @if (remoteError.correlationId) {\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Reference: <span class=\"cws:font-mono\">{{ remoteError.correlationId }}</span>\n        </p>\n      }\n    </div>\n\n    <!--\n      The same classes as the grid's \"Add Contract\", `border border-transparent` included — retrying is\n      the one thing to do from this screen, so it gets the primary treatment rather than the muted\n      secondary/small pairing it had.\n    -->\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n      (click)=\"retry.emit()\"\n    >\n      Retry\n    </button>\n  </div>\n} @else if (showEmpty()) {\n  <div class=\"cws:py-8 cws:text-center\">\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ emptyMessage() }}</p>\n    <!-- Primary action for the empty state, e.g. \"Clear filters\" (02a §5). -->\n    <div class=\"cws:mt-3\"><ng-content select=\"[cmsEmptyAction]\" /></div>\n  </div>\n} @else if (showContent()) {\n  <ng-content />\n}\n"
		}]
	}],
	propDecorators: {
		data: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "data",
				required: true
			}]
		}],
		empty: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "empty",
				required: false
			}]
		}],
		emptyMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyMessage",
				required: false
			}]
		}],
		loadingLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loadingLabel",
				required: false
			}]
		}],
		retry: [{
			type: i0.Output,
			args: ["retry"]
		}]
	}
});
const NO_REFERENCE_RETURNED = "No reference: the server did not return one.";
const NO_REFERENCE_NOT_SENT = "No reference: nothing was sent to the server.";
var ReferenceLineComponent = class ReferenceLineComponent {
	correlationId = input(null, ...ngDevMode ? [{ debugName: "correlationId" }] : /* istanbul ignore next */ []);
	sent = input(true, ...ngDevMode ? [{ debugName: "sent" }] : /* istanbul ignore next */ []);
	note = computed(() => this.sent() ? NO_REFERENCE_RETURNED : NO_REFERENCE_NOT_SENT, ...ngDevMode ? [{ debugName: "note" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ReferenceLineComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ReferenceLineComponent,
		isStandalone: true,
		selector: "cms-reference-line",
		inputs: {
			correlationId: {
				classPropertyName: "correlationId",
				publicName: "correlationId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sent: {
				classPropertyName: "sent",
				publicName: "sent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <p class="cws:text-xs" data-testid="status-reference">
      @if (correlationId(); as id) {
        Reference: <span class="cws:font-mono">{{ id }}</span>
      } @else {
        {{ note() }}
      }
    </p>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ReferenceLineComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-reference-line",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <p class="cws:text-xs" data-testid="status-reference">
      @if (correlationId(); as id) {
        Reference: <span class="cws:font-mono">{{ id }}</span>
      } @else {
        {{ note() }}
      }
    </p>
  `
		}]
	}],
	propDecorators: {
		correlationId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "correlationId",
				required: false
			}]
		}],
		sent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sent",
				required: false
			}]
		}]
	}
});
function mutationSucceeded(message, options) {
	return options?.stays === true ? {
		kind: "success",
		message,
		stays: true
	} : {
		kind: "success",
		message
	};
}
function mutationFailed(error) {
	return {
		kind: "failure",
		message: error.message,
		sent: true,
		correlationId: error.correlationId ?? null
	};
}
function mutationRefused(message) {
	return {
		kind: "failure",
		message,
		sent: false
	};
}
function correlationIdOf(error) {
	const body = error?.error;
	const traceId = typeof body === "object" && body !== null ? body.traceId : void 0;
	return typeof traceId === "string" && traceId.trim() !== "" ? traceId : null;
}
const STATUS_MESSAGE_DISMISS_MS = 6e3;
var StatusMessageComponent = class StatusMessageComponent {
	outcome = input(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	dismissMs = input(STATUS_MESSAGE_DISMISS_MS, ...ngDevMode ? [{ debugName: "dismissMs" }] : /* istanbul ignore next */ []);
	dismissed = output();
	constructor() {
		const destroyRef = inject(DestroyRef);
		let timer;
		destroyRef.onDestroy(() => clearTimeout(timer));
		effect(() => {
			const outcome = this.outcome();
			const delay = this.dismissMs();
			clearTimeout(timer);
			if (outcome?.kind === "success" && outcome.stays !== true) timer = setTimeout(() => this.dismissed.emit(), delay);
		});
	}
	dismiss() {
		this.dismissed.emit();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StatusMessageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: StatusMessageComponent,
		isStandalone: true,
		selector: "cms-status-message",
		inputs: {
			outcome: {
				classPropertyName: "outcome",
				publicName: "outcome",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dismissMs: {
				classPropertyName: "dismissMs",
				publicName: "dismissMs",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { dismissed: "dismissed" },
		ngImport: i0,
		template: "<!--\n  #803: one shape for a mutation's outcome. Success is a polite status that dismisses itself;\n  failure is an alert that stays, and always ends with a reference line.\n-->\n@if (outcome(); as current) {\n  @if (current.kind === 'success') {\n    <div class=\"scoular-alert scoular-alert-success cws:flex cws:items-start cws:gap-3\" role=\"status\" data-testid=\"status-success\">\n      <div class=\"scoular-alert-description cws:flex-1\">{{ current.message }}</div>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"dismiss()\">Dismiss</button>\n    </div>\n  } @else {\n    <div class=\"scoular-alert scoular-alert-error cws:flex cws:items-start cws:gap-3\" role=\"alert\" data-testid=\"status-failure\">\n      <div class=\"scoular-alert-description cws:flex-1 cws:space-y-1\">\n        <p class=\"cws:whitespace-pre-line\">{{ current.message }}</p>\n        <cms-reference-line [correlationId]=\"current.sent ? current.correlationId : null\" [sent]=\"current.sent\" />\n        <!-- A screen's own action for this failure, such as Reload after a 409. -->\n        <ng-content />\n      </div>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"dismiss()\">Dismiss</button>\n    </div>\n  }\n}\n",
		dependencies: [{
			kind: "component",
			type: ReferenceLineComponent,
			selector: "cms-reference-line",
			inputs: ["correlationId", "sent"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StatusMessageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-status-message",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ReferenceLineComponent],
			template: "<!--\n  #803: one shape for a mutation's outcome. Success is a polite status that dismisses itself;\n  failure is an alert that stays, and always ends with a reference line.\n-->\n@if (outcome(); as current) {\n  @if (current.kind === 'success') {\n    <div class=\"scoular-alert scoular-alert-success cws:flex cws:items-start cws:gap-3\" role=\"status\" data-testid=\"status-success\">\n      <div class=\"scoular-alert-description cws:flex-1\">{{ current.message }}</div>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"dismiss()\">Dismiss</button>\n    </div>\n  } @else {\n    <div class=\"scoular-alert scoular-alert-error cws:flex cws:items-start cws:gap-3\" role=\"alert\" data-testid=\"status-failure\">\n      <div class=\"scoular-alert-description cws:flex-1 cws:space-y-1\">\n        <p class=\"cws:whitespace-pre-line\">{{ current.message }}</p>\n        <cms-reference-line [correlationId]=\"current.sent ? current.correlationId : null\" [sent]=\"current.sent\" />\n        <!-- A screen's own action for this failure, such as Reload after a 409. -->\n        <ng-content />\n      </div>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"dismiss()\">Dismiss</button>\n    </div>\n  }\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		outcome: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "outcome",
				required: false
			}]
		}],
		dismissMs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dismissMs",
				required: false
			}]
		}],
		dismissed: [{
			type: i0.Output,
			args: ["dismissed"]
		}]
	}
});
var StorageRefusals = class StorageRefusals {
	refused = signal([], ...ngDevMode ? [{ debugName: "refused" }] : /* istanbul ignore next */ []);
	showing = signal(false, ...ngDevMode ? [{ debugName: "showing" }] : /* istanbul ignore next */ []);
	notice = computed(() => {
		const refused = this.refused();
		return this.showing() && refused.length > 0 ? mutationRefused(sentence(refused)) : null;
	}, ...ngDevMode ? [{ debugName: "notice" }] : /* istanbul ignore next */ []);
	report(store) {
		if (this.refused().includes(store)) return;
		this.refused.update((refused) => [...refused, store]);
		this.showing.set(true);
	}
	dismiss() {
		this.showing.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StorageRefusals,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StorageRefusals,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StorageRefusals,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
function sentence(refused) {
	const names = refused.map((store) => `your ${store}`).join(" and ");
	return `${names.charAt(0).toUpperCase() + names.slice(1)} will not be remembered after this session: the browser refused to store ${refused.length === 1 ? "it" : "them"}.`;
}
var HelpTipComponent = class HelpTipComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	tipId = input.required(...ngDevMode ? [{ debugName: "tipId" }] : /* istanbul ignore next */ []);
	entries = input.required(...ngDevMode ? [{ debugName: "entries" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HelpTipComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: HelpTipComponent,
		isStandalone: true,
		selector: "cms-help-tip",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			tipId: {
				classPropertyName: "tipId",
				publicName: "tipId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:group cws:relative cws:inline-flex cws:shrink-0 cws:self-center cws:leading-none" },
		ngImport: i0,
		template: `
    <button
      type="button"
      class="cws:flex cws:size-4 cws:items-center cws:justify-center cws:rounded-full cws:border cws:border-slate-300 cws:text-[10px] cws:font-semibold cws:text-slate-500 cws:hover:border-slate-400 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-400 cws:dark:hover:border-slate-500 cws:dark:hover:text-slate-200"
      [attr.aria-label]="'About ' + label()"
      [attr.aria-describedby]="tipId()"
      data-field-help
    >
      i
    </button>

    <span
      role="tooltip"
      [id]="tipId()"
      class="cws:pointer-events-none cws:absolute cws:top-full cws:left-0 cws:z-60 cws:mt-1.5 cws:hidden cws:w-72 cws:space-y-1.5 cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:p-2 cws:text-xs cws:leading-snug cws:font-normal cws:text-slate-600 cws:shadow-lg cws:group-focus-within:block cws:group-hover:block cws:dark:border-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300"
    >
      @for (entry of entries(); track $index) {
        <span class="cws:block">
          @if (entry.heading) {
            <span class="cws:block cws:font-medium cws:text-slate-700 cws:dark:text-slate-200">{{ entry.heading }}</span>
          }
          @if (entry.source) {
            <span class="cws:block cws:font-mono cws:text-[10px] cws:text-slate-500 cws:dark:text-slate-400">{{
              entry.source
            }}</span>
          }
          {{ entry.text }}
        </span>
      }
    </span>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HelpTipComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-help-tip",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:group cws:relative cws:inline-flex cws:shrink-0 cws:self-center cws:leading-none" },
			template: `
    <button
      type="button"
      class="cws:flex cws:size-4 cws:items-center cws:justify-center cws:rounded-full cws:border cws:border-slate-300 cws:text-[10px] cws:font-semibold cws:text-slate-500 cws:hover:border-slate-400 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-400 cws:dark:hover:border-slate-500 cws:dark:hover:text-slate-200"
      [attr.aria-label]="'About ' + label()"
      [attr.aria-describedby]="tipId()"
      data-field-help
    >
      i
    </button>

    <span
      role="tooltip"
      [id]="tipId()"
      class="cws:pointer-events-none cws:absolute cws:top-full cws:left-0 cws:z-60 cws:mt-1.5 cws:hidden cws:w-72 cws:space-y-1.5 cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:p-2 cws:text-xs cws:leading-snug cws:font-normal cws:text-slate-600 cws:shadow-lg cws:group-focus-within:block cws:group-hover:block cws:dark:border-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300"
    >
      @for (entry of entries(); track $index) {
        <span class="cws:block">
          @if (entry.heading) {
            <span class="cws:block cws:font-medium cws:text-slate-700 cws:dark:text-slate-200">{{ entry.heading }}</span>
          }
          @if (entry.source) {
            <span class="cws:block cws:font-mono cws:text-[10px] cws:text-slate-500 cws:dark:text-slate-400">{{
              entry.source
            }}</span>
          }
          {{ entry.text }}
        </span>
      }
    </span>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		tipId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tipId",
				required: true
			}]
		}],
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: true
			}]
		}]
	}
});
const READ_ONLY_SURFACE_CLASS = "cws:border-transparent cws:bg-slate-100 cws:text-slate-900 cws:dark:bg-slate-900/60 cws:dark:text-slate-100";
const PLAIN_VALUE_CLASS = "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
const READ_ONLY_FOCUS_CLASS = "cws:ring-0! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
const EMPTY_VALUE_TEXT = "—";
var FieldComponent = class FieldComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	hint = input(null, ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	labelFor = input(true, ...ngDevMode ? [{ debugName: "labelFor" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldComponent,
		isStandalone: true,
		selector: "cms-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelFor: {
				classPropertyName: "labelFor",
				publicName: "labelFor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<!--\n  One field: label row, the control (or, in `display`, its value on a quiet surface), and the one\n  error-or-hint line. The label row is the same in every mode, so a field reads the same whether it is\n  being viewed or edited; only the surface under it changes.\n-->\n<div class=\"scoular-form-group\">\n  <!--\n    🔴 When the heading is hidden the row KEEPS its height (`min-h-5`), and that is the whole point.\n\n    `sr-only` positions absolutely, so putting it on the ROW collapsed 20px of label space and lifted\n    the input 28px above its neighbours — measured at 90px against 118px for every labelled field in\n    the same grid row. Reserving the space keeps a grouped field aligned with the rest of the row\n    while showing no heading of its own. A compound group draws its one heading over these rows.\n\n    ⚠ The row is `flex justify-between` even when nothing is projected into the aside slot. That is\n    not decoration: it is what lets a control add a counter later without the label moving, and with\n    an empty slot it lays out identically to a bare label (measured across all six controls).\n  -->\n  <div class=\"cws:flex cws:items-baseline cws:justify-between cws:gap-3\" [class.cws:min-h-5]=\"hideLabel()\">\n    <!--\n      The heading and its \"i\" share one flex group, so the icon follows the label's text however long\n      it is, and stays visible when the label truncates (`shrink-0` on the icon, `min-w-0` on the label).\n    -->\n    <span class=\"cws:flex cws:min-w-0 cws:items-center cws:gap-1.5\">\n      @if (labelFor() && !display()) {\n        <label\n          class=\"scoular-form-label cws:min-w-0\"\n          [class.sr-only]=\"hideLabel()\"\n          [for]=\"controlId()\"\n          [title]=\"label()\"\n        >\n          <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\n            <span class=\"truncate\">{{ label() }}</span>\n            @if (required()) {\n              <span class=\"cws:shrink-0 cws:text-red-700\" aria-hidden=\"true\">*</span>\n            }\n          </span>\n        </label>\n      } @else {\n        <!--\n          A plain <span>, not <label for>, where the thing named is not a labelable element: the toggle's\n          `role=\"switch\"` button, and a displayed value's `<output>`. Each takes `aria-labelledby`\n          against this id instead.\n        -->\n        <span\n          class=\"scoular-form-label cws:min-w-0\"\n          [class.sr-only]=\"hideLabel()\"\n          [id]=\"controlId() + '-label'\"\n          [title]=\"label()\"\n        >\n          <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\n            <span class=\"truncate\">{{ label() }}</span>\n            @if (required()) {\n              <span class=\"cws:shrink-0 cws:text-red-700\" aria-hidden=\"true\">*</span>\n            }\n          </span>\n        </span>\n      }\n\n      @if (help(); as tip) {\n        <!--\n          The field's description, on request (2026-10-13), instead of printed under every control,\n          which made rows of unequal height and buried the values in grey text.\n        -->\n        <cms-help-tip\n          [label]=\"label()\"\n          [tipId]=\"controlId() + '-help'\"\n          [entries]=\"[{ source: tip.source ?? null, text: tip.text }]\"\n        />\n      }\n    </span>\n\n    @if (marker(); as text) {\n      <!-- A quiet status word: \"Set by CTRM\" on a value nobody types here. Never a badge. -->\n      <span class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:text-slate-500 cws:dark:text-slate-400\" data-field-marker>{{\n        text\n      }}</span>\n    }\n\n    <!-- The character counter, and anything else that belongs on the label's line. -->\n    <ng-content select=\"[cmsFieldAside]\" />\n  </div>\n\n  <!-- The control itself. -->\n  <ng-content />\n\n  <!--\n    🔴 Error and hint are mutually exclusive, and the ids are load-bearing: every control's\n    `describedBy()` points at `<controlId>-error` or `<controlId>-hint`, so these must be rendered\n    here with exactly those ids or the association silently breaks — which is invisible to everyone\n    except a screen-reader user.\n  -->\n  @if (errorMessage(); as message) {\n    <p class=\"scoular-form-error\" [id]=\"controlId() + '-error'\">{{ message }}</p>\n  } @else if (hint(); as text) {\n    <p class=\"scoular-form-helper\" [id]=\"controlId() + '-hint'\">{{ text }}</p>\n  }\n</div>\n",
		dependencies: [{
			kind: "component",
			type: HelpTipComponent,
			selector: "cms-help-tip",
			inputs: [
				"label",
				"tipId",
				"entries"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			imports: [HelpTipComponent],
			template: "<!--\n  One field: label row, the control (or, in `display`, its value on a quiet surface), and the one\n  error-or-hint line. The label row is the same in every mode, so a field reads the same whether it is\n  being viewed or edited; only the surface under it changes.\n-->\n<div class=\"scoular-form-group\">\n  <!--\n    🔴 When the heading is hidden the row KEEPS its height (`min-h-5`), and that is the whole point.\n\n    `sr-only` positions absolutely, so putting it on the ROW collapsed 20px of label space and lifted\n    the input 28px above its neighbours — measured at 90px against 118px for every labelled field in\n    the same grid row. Reserving the space keeps a grouped field aligned with the rest of the row\n    while showing no heading of its own. A compound group draws its one heading over these rows.\n\n    ⚠ The row is `flex justify-between` even when nothing is projected into the aside slot. That is\n    not decoration: it is what lets a control add a counter later without the label moving, and with\n    an empty slot it lays out identically to a bare label (measured across all six controls).\n  -->\n  <div class=\"cws:flex cws:items-baseline cws:justify-between cws:gap-3\" [class.cws:min-h-5]=\"hideLabel()\">\n    <!--\n      The heading and its \"i\" share one flex group, so the icon follows the label's text however long\n      it is, and stays visible when the label truncates (`shrink-0` on the icon, `min-w-0` on the label).\n    -->\n    <span class=\"cws:flex cws:min-w-0 cws:items-center cws:gap-1.5\">\n      @if (labelFor() && !display()) {\n        <label\n          class=\"scoular-form-label cws:min-w-0\"\n          [class.sr-only]=\"hideLabel()\"\n          [for]=\"controlId()\"\n          [title]=\"label()\"\n        >\n          <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\n            <span class=\"truncate\">{{ label() }}</span>\n            @if (required()) {\n              <span class=\"cws:shrink-0 cws:text-red-700\" aria-hidden=\"true\">*</span>\n            }\n          </span>\n        </label>\n      } @else {\n        <!--\n          A plain <span>, not <label for>, where the thing named is not a labelable element: the toggle's\n          `role=\"switch\"` button, and a displayed value's `<output>`. Each takes `aria-labelledby`\n          against this id instead.\n        -->\n        <span\n          class=\"scoular-form-label cws:min-w-0\"\n          [class.sr-only]=\"hideLabel()\"\n          [id]=\"controlId() + '-label'\"\n          [title]=\"label()\"\n        >\n          <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\n            <span class=\"truncate\">{{ label() }}</span>\n            @if (required()) {\n              <span class=\"cws:shrink-0 cws:text-red-700\" aria-hidden=\"true\">*</span>\n            }\n          </span>\n        </span>\n      }\n\n      @if (help(); as tip) {\n        <!--\n          The field's description, on request (2026-10-13), instead of printed under every control,\n          which made rows of unequal height and buried the values in grey text.\n        -->\n        <cms-help-tip\n          [label]=\"label()\"\n          [tipId]=\"controlId() + '-help'\"\n          [entries]=\"[{ source: tip.source ?? null, text: tip.text }]\"\n        />\n      }\n    </span>\n\n    @if (marker(); as text) {\n      <!-- A quiet status word: \"Set by CTRM\" on a value nobody types here. Never a badge. -->\n      <span class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:text-slate-500 cws:dark:text-slate-400\" data-field-marker>{{\n        text\n      }}</span>\n    }\n\n    <!-- The character counter, and anything else that belongs on the label's line. -->\n    <ng-content select=\"[cmsFieldAside]\" />\n  </div>\n\n  <!-- The control itself. -->\n  <ng-content />\n\n  <!--\n    🔴 Error and hint are mutually exclusive, and the ids are load-bearing: every control's\n    `describedBy()` points at `<controlId>-error` or `<controlId>-hint`, so these must be rendered\n    here with exactly those ids or the association silently breaks — which is invisible to everyone\n    except a screen-reader user.\n  -->\n  @if (errorMessage(); as message) {\n    <p class=\"scoular-form-error\" [id]=\"controlId() + '-error'\">{{ message }}</p>\n  } @else if (hint(); as text) {\n    <p class=\"scoular-form-helper\" [id]=\"controlId() + '-hint'\">{{ text }}</p>\n  }\n</div>\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		labelFor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelFor",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}]
	}
});
var FieldValueComponent = class FieldValueComponent {
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	text = input(null, ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	multiline = input(false, ...ngDevMode ? [{ debugName: "multiline" }] : /* istanbul ignore next */ []);
	surfaceClass = READ_ONLY_SURFACE_CLASS;
	empty = computed(() => {
		const text = this.text();
		return text === null || text === void 0 || String(text).trim() === "";
	}, ...ngDevMode ? [{ debugName: "empty" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldValueComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldValueComponent,
		isStandalone: true,
		selector: "cms-field-value",
		inputs: {
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			multiline: {
				classPropertyName: "multiline",
				publicName: "multiline",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block cws:min-w-0" },
		ngImport: i0,
		template: `
    <output
      [id]="controlId()"
      aria-live="off"
      tabindex="0"
      [attr.aria-labelledby]="controlId() + '-label'"
      data-field-value
      [attr.data-empty]="empty() ? '' : null"
      [class]="surfaceClass"
      class="cws:block cws:min-h-[38px] cws:min-w-0 cws:rounded-lg cws:border cws:px-4 cws:py-2 cws:text-sm cws:leading-5 cws:break-words cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue"
      [class.cws:whitespace-pre-wrap]="multiline()"
    >@if (empty()) {<span class="cws:text-slate-400 cws:dark:text-slate-500" aria-hidden="true">—</span><span class="sr-only">Not set</span>} @else {{{ text() }}}</output>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldValueComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-field-value",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block cws:min-w-0" },
			template: `
    <output
      [id]="controlId()"
      aria-live="off"
      tabindex="0"
      [attr.aria-labelledby]="controlId() + '-label'"
      data-field-value
      [attr.data-empty]="empty() ? '' : null"
      [class]="surfaceClass"
      class="cws:block cws:min-h-[38px] cws:min-w-0 cws:rounded-lg cws:border cws:px-4 cws:py-2 cws:text-sm cws:leading-5 cws:break-words cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue"
      [class.cws:whitespace-pre-wrap]="multiline()"
    >@if (empty()) {<span class="cws:text-slate-400 cws:dark:text-slate-500" aria-hidden="true">—</span><span class="sr-only">Not set</span>} @else {{{ text() }}}</output>
  `
		}]
	}],
	propDecorators: {
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: false
			}]
		}],
		multiline: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multiline",
				required: false
			}]
		}]
	}
});
var QuantityInputComponent = class QuantityInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	unitOfMeasure = input(null, ...ngDevMode ? [{ debugName: "unitOfMeasure" }] : /* istanbul ignore next */ []);
	decimalPlaces = input(2, ...ngDevMode ? [{ debugName: "decimalPlaces" }] : /* istanbul ignore next */ []);
	allowNegative = input(false, ...ngDevMode ? [{ debugName: "allowNegative" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	requiredMarker = input(false, ...ngDevMode ? [{ debugName: "requiredMarker" }] : /* istanbul ignore next */ []);
	showsRequired = computed(() => this.required() || this.requiredMarker(), ...ngDevMode ? [{ debugName: "showsRequired" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	plain = input(false, ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	displayText = computed(() => this.displayValue(), ...ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []);
	surfaceClass = computed(() => {
		if (this.plain()) return PLAIN_VALUE_CLASS;
		return this.readOnly() ? READ_ONLY_FOCUS_CLASS : "";
	}, ...ngDevMode ? [{ debugName: "surfaceClass" }] : /* istanbul ignore next */ []);
	emptyText = "—";
	skipTab = input(false, ...ngDevMode ? [{ debugName: "skipTab" }] : /* istanbul ignore next */ []);
	formula = input(null, ...ngDevMode ? [{ debugName: "formula" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	tone = input(null, ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	describedByExtra = input(null, ...ngDevMode ? [{ debugName: "describedByExtra" }] : /* istanbul ignore next */ []);
	invalid = computed(() => this.errorMessage() !== null || this.tone() === "invalid", ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	focused = signal(false, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	value = signal(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	editingText = signal(null, ...ngDevMode ? [{ debugName: "editingText" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		const ids = [];
		if (this.errorMessage()) ids.push(`${this.controlId()}-error`);
		if (this.formula() || this.warningText()) ids.push(`${this.controlId()}-hint`);
		const extra = this.describedByExtra();
		if (extra !== null) ids.push(extra);
		return ids.length > 0 ? ids.join(" ") : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	hint = computed(() => this.formula() ?? this.warningText(), ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	displayValue = computed(() => {
		if (this.focused() && !this.readOnly()) {
			const editing = this.editingText();
			if (editing !== null) return editing;
			const current = this.value();
			return current === null ? "" : String(current);
		}
		return this.format(this.value());
	}, ...ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "number" && Number.isFinite(value) ? value : null);
		this.editingText.set(null);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onFocus() {
		this.focused.set(true);
		this.editingText.set(null);
	}
	onInput(event) {
		const element = event.target;
		const raw = element.value;
		const cleaned = this.sanitize(raw);
		if (cleaned !== raw) {
			const caret = element.selectionStart ?? raw.length;
			const removedBeforeCaret = caret - this.sanitize(raw.slice(0, caret)).length;
			element.value = cleaned;
			const restored = Math.max(0, caret - removedBeforeCaret);
			element.setSelectionRange(restored, restored);
		}
		this.editingText.set(cleaned);
		this.onChange(this.parse(cleaned));
	}
	sanitize(raw) {
		const allowed = this.allowNegative() ? /[^0-9.,\s-]/g : /[^0-9.,\s]/g;
		const stripped = raw.replace(allowed, "");
		const negative = this.allowNegative() && stripped.startsWith("-");
		const digits = (negative ? stripped.slice(1) : stripped).replace(/-/g, "");
		const firstPoint = digits.indexOf(".");
		const single = firstPoint === -1 ? digits : digits.slice(0, firstPoint + 1) + digits.slice(firstPoint + 1).replace(/\./g, "");
		return negative ? `-${single}` : single;
	}
	onBlur() {
		this.focused.set(false);
		const editing = this.editingText();
		if (editing !== null) {
			this.value.set(this.parse(editing));
			this.editingText.set(null);
		}
		this.onTouched();
	}
	parse(raw) {
		const cleaned = raw.replace(/[,\s]/g, "");
		if (cleaned === "" || cleaned === "-") return null;
		const parsed = Number(cleaned);
		if (!Number.isFinite(parsed)) return null;
		return !this.allowNegative() && parsed < 0 ? Math.abs(parsed) : parsed;
	}
	format(value) {
		if (value === null) return "";
		return value.toLocaleString("en-US", {
			minimumFractionDigits: this.decimalPlaces(),
			maximumFractionDigits: this.decimalPlaces()
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: QuantityInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: QuantityInputComponent,
		isStandalone: true,
		selector: "cms-quantity-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			unitOfMeasure: {
				classPropertyName: "unitOfMeasure",
				publicName: "unitOfMeasure",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimalPlaces: {
				classPropertyName: "decimalPlaces",
				publicName: "decimalPlaces",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowNegative: {
				classPropertyName: "allowNegative",
				publicName: "allowNegative",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			requiredMarker: {
				classPropertyName: "requiredMarker",
				publicName: "requiredMarker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plain: {
				classPropertyName: "plain",
				publicName: "plain",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skipTab: {
				classPropertyName: "skipTab",
				publicName: "skipTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formula: {
				classPropertyName: "formula",
				publicName: "formula",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedByExtra: {
				classPropertyName: "describedByExtra",
				publicName: "describedByExtra",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => QuantityInputComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"hint()\"\n>\n\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <div class=\"cws:relative\">\n    <!--\n      inputmode=\"decimal\" raises the numeric keypad on touch without the spinner buttons and\n      silent value-clamping that type=\"number\" brings. Values are parsed explicitly anyway.\n      Right-aligned per C4; padded on the right when a UM suffix is rendered inside the control.\n\n      ⚠ Except as a `plain` value: there the number sits under its label like every other value. C4's\n      right alignment is for typing into a box, and with no box a right-aligned figure floats away from\n      the label that names it.\n    -->\n    <input\n      class=\"scoular-form-input\"\n      [class]=\"surfaceClass()\"\n      [attr.placeholder]=\"plain() ? emptyText : null\"\n      [class.cws:text-right]=\"!plain()\"\n      [class.error]=\"invalid()\"\n      [class.cws:border-scoular-yellow]=\"borderWarning() && !invalid()\"\n      [class.cws:border-scoular-green]=\"tone() === 'valid' && !invalid()\"\n      [attr.data-tone]=\"tone()\"\n      [class.cws:pr-12]=\"unitOfMeasure() !== null\"\n      [id]=\"controlId()\"\n      type=\"text\"\n      inputmode=\"decimal\"\n      autocomplete=\"off\"\n      [value]=\"displayValue()\"\n      [readOnly]=\"readOnly()\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [disabled]=\"disabled()\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"invalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"hint()\"\n      (focus)=\"onFocus()\"\n      (input)=\"onInput($event)\"\n      (blur)=\"onBlur()\"\n    />\n\n    @if (unitOfMeasure(); as unit) {\n      <!-- Decorative: the unit is already part of the label's meaning, so it is not announced twice. -->\n      <span\n        class=\"cws:pointer-events-none cws:absolute cws:inset-y-0 cws:right-3 cws:flex cws:items-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\n        aria-hidden=\"true\"\n        >{{ unit }}</span\n      >\n    }\n  </div>\n  }\n</cms-field>\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor",
				"help",
				"marker",
				"display"
			]
		}, {
			kind: "component",
			type: FieldValueComponent,
			selector: "cms-field-value",
			inputs: [
				"controlId",
				"text",
				"multiline"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: QuantityInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-quantity-input",
			imports: [FieldComponent, FieldValueComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => QuantityInputComponent),
				multi: true
			}],
			template: "<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"hint()\"\n>\n\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <div class=\"cws:relative\">\n    <!--\n      inputmode=\"decimal\" raises the numeric keypad on touch without the spinner buttons and\n      silent value-clamping that type=\"number\" brings. Values are parsed explicitly anyway.\n      Right-aligned per C4; padded on the right when a UM suffix is rendered inside the control.\n\n      ⚠ Except as a `plain` value: there the number sits under its label like every other value. C4's\n      right alignment is for typing into a box, and with no box a right-aligned figure floats away from\n      the label that names it.\n    -->\n    <input\n      class=\"scoular-form-input\"\n      [class]=\"surfaceClass()\"\n      [attr.placeholder]=\"plain() ? emptyText : null\"\n      [class.cws:text-right]=\"!plain()\"\n      [class.error]=\"invalid()\"\n      [class.cws:border-scoular-yellow]=\"borderWarning() && !invalid()\"\n      [class.cws:border-scoular-green]=\"tone() === 'valid' && !invalid()\"\n      [attr.data-tone]=\"tone()\"\n      [class.cws:pr-12]=\"unitOfMeasure() !== null\"\n      [id]=\"controlId()\"\n      type=\"text\"\n      inputmode=\"decimal\"\n      autocomplete=\"off\"\n      [value]=\"displayValue()\"\n      [readOnly]=\"readOnly()\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [disabled]=\"disabled()\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"invalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"hint()\"\n      (focus)=\"onFocus()\"\n      (input)=\"onInput($event)\"\n      (blur)=\"onBlur()\"\n    />\n\n    @if (unitOfMeasure(); as unit) {\n      <!-- Decorative: the unit is already part of the label's meaning, so it is not announced twice. -->\n      <span\n        class=\"cws:pointer-events-none cws:absolute cws:inset-y-0 cws:right-3 cws:flex cws:items-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\n        aria-hidden=\"true\"\n        >{{ unit }}</span\n      >\n    }\n  </div>\n  }\n</cms-field>\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		unitOfMeasure: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unitOfMeasure",
				required: false
			}]
		}],
		decimalPlaces: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimalPlaces",
				required: false
			}]
		}],
		allowNegative: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowNegative",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		requiredMarker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "requiredMarker",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		plain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		skipTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skipTab",
				required: false
			}]
		}],
		formula: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formula",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		describedByExtra: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedByExtra",
				required: false
			}]
		}]
	}
});
var TextInputComponent = class TextInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	maxLength = input.required(...ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	requiredMarker = input(false, ...ngDevMode ? [{ debugName: "requiredMarker" }] : /* istanbul ignore next */ []);
	showsRequired = computed(() => this.required() || this.requiredMarker(), ...ngDevMode ? [{ debugName: "showsRequired" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	plain = input(false, ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	displayText = computed(() => this.value(), ...ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []);
	plainClass = PLAIN_VALUE_CLASS;
	emptyText = "—";
	skipTab = input(false, ...ngDevMode ? [{ debugName: "skipTab" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	tone = input(null, ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	describedByExtra = input(null, ...ngDevMode ? [{ debugName: "describedByExtra" }] : /* istanbul ignore next */ []);
	invalid = computed(() => this.errorMessage() !== null || this.tone() === "invalid", ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = signal("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	remaining = computed(() => {
		const max = this.maxLength();
		return max === null ? null : max - this.value().length;
	}, ...ngDevMode ? [{ debugName: "remaining" }] : /* istanbul ignore next */ []);
	nearLimit = computed(() => {
		const max = this.maxLength();
		const remaining = this.remaining();
		if (max === null || remaining === null) return false;
		return remaining <= Math.max(5, Math.floor(max * .1));
	}, ...ngDevMode ? [{ debugName: "nearLimit" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		const ids = [`${this.controlId()}-counter`];
		if (this.errorMessage()) ids.push(`${this.controlId()}-error`);
		else if (this.warningText()) ids.push(`${this.controlId()}-hint`);
		const extra = this.describedByExtra();
		if (extra !== null) ids.push(extra);
		return ids.join(" ");
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "string" ? this.clamp(value) : "");
	}
	clamp(value) {
		const max = this.maxLength();
		return max === null ? value : value.slice(0, max);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		const element = event.target;
		const clamped = this.clamp(element.value);
		if (element.value !== clamped) element.value = clamped;
		this.value.set(clamped);
		this.onChange(clamped === "" ? null : clamped);
	}
	onBlur() {
		this.onTouched();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TextInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TextInputComponent,
		isStandalone: true,
		selector: "cms-text-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			maxLength: {
				classPropertyName: "maxLength",
				publicName: "maxLength",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			requiredMarker: {
				classPropertyName: "requiredMarker",
				publicName: "requiredMarker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plain: {
				classPropertyName: "plain",
				publicName: "plain",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skipTab: {
				classPropertyName: "skipTab",
				publicName: "skipTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedByExtra: {
				classPropertyName: "describedByExtra",
				publicName: "describedByExtra",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => TextInputComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<!--\n  The label row, the required marker and the error/hint line come from `cms-field` (2026-09-16).\n  This template used to carry all three itself, as did five sibling controls — identically, down to\n  the byte. The `min-h-5` row-height fix recorded below now lives there, which is the point: it was\n  made here, on the screen where the bug was reported, and four of the six controls never got it.\n-->\n<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n  <ng-container cmsFieldAside>\n    <!--\n      aria-live=\"polite\" so the count is announced as it changes, but only when it starts to\n      matter — announcing every keystroke of a 72-character remark would be unusable.\n\n      🔴 **Hidden when read-only** (2026-09-03). A remaining-character count answers \"how much more may\n      I type\", and in a read-only field the answer is \"none, ever\" — so it was ~100 instances of\n      \"255 left\" competing with the labels on the record screen's view mode, which is the primary way a\n      contract is *read*. It is the loudest thing on the page and it says nothing.\n\n      Not merely faded: an `aria-live` region on a value that cannot change is noise for a screen\n      reader too, and `maxlength` is not enforced on an input nobody can edit.\n    -->\n    @if (!readOnly() && !hideLabel()) {\n      <span\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\n        [class.cws:text-slate-500]=\"!nearLimit()\"\n        [class.cws:dark:text-slate-400]=\"!nearLimit()\"\n        [class.cws:text-amber-700]=\"nearLimit()\"\n        [class.cws:dark:text-amber-400]=\"nearLimit()\"\n        [id]=\"controlId() + '-counter'\"\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\n        >{{ remaining() === null ? 'No known limit' : remaining() + ' left' }}</span\n      >\n    }\n  </ng-container>\n\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <!-- `plain`: a read-only value drawn as text, with a quiet dash when empty (PLAIN_VALUE_CLASS). -->\n  <input\n    class=\"scoular-form-input\"\n    [class]=\"plain() ? plainClass : ''\"\n    [attr.placeholder]=\"plain() ? emptyText : null\"\n    [class.error]=\"invalid()\"\n    [class.cws:border-scoular-yellow]=\"borderWarning() && !invalid()\"\n    [class.cws:border-scoular-green]=\"tone() === 'valid' && !invalid()\"\n    [attr.data-tone]=\"tone()\"\n    [id]=\"controlId()\"\n    type=\"text\"\n    autocomplete=\"off\"\n    [value]=\"value()\"\n    [attr.maxlength]=\"maxLength()\"\n    [readOnly]=\"readOnly()\"\n    [attr.tabindex]=\"skipTab() ? -1 : null\"\n    [disabled]=\"disabled()\"\n    [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n    [attr.aria-invalid]=\"invalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.title]=\"warningText()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  />\n  }\n</cms-field>\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor",
				"help",
				"marker",
				"display"
			]
		}, {
			kind: "component",
			type: FieldValueComponent,
			selector: "cms-field-value",
			inputs: [
				"controlId",
				"text",
				"multiline"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TextInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-text-input",
			imports: [FieldComponent, FieldValueComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => TextInputComponent),
				multi: true
			}],
			template: "<!--\n  The label row, the required marker and the error/hint line come from `cms-field` (2026-09-16).\n  This template used to carry all three itself, as did five sibling controls — identically, down to\n  the byte. The `min-h-5` row-height fix recorded below now lives there, which is the point: it was\n  made here, on the screen where the bug was reported, and four of the six controls never got it.\n-->\n<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n  <ng-container cmsFieldAside>\n    <!--\n      aria-live=\"polite\" so the count is announced as it changes, but only when it starts to\n      matter — announcing every keystroke of a 72-character remark would be unusable.\n\n      🔴 **Hidden when read-only** (2026-09-03). A remaining-character count answers \"how much more may\n      I type\", and in a read-only field the answer is \"none, ever\" — so it was ~100 instances of\n      \"255 left\" competing with the labels on the record screen's view mode, which is the primary way a\n      contract is *read*. It is the loudest thing on the page and it says nothing.\n\n      Not merely faded: an `aria-live` region on a value that cannot change is noise for a screen\n      reader too, and `maxlength` is not enforced on an input nobody can edit.\n    -->\n    @if (!readOnly() && !hideLabel()) {\n      <span\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\n        [class.cws:text-slate-500]=\"!nearLimit()\"\n        [class.cws:dark:text-slate-400]=\"!nearLimit()\"\n        [class.cws:text-amber-700]=\"nearLimit()\"\n        [class.cws:dark:text-amber-400]=\"nearLimit()\"\n        [id]=\"controlId() + '-counter'\"\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\n        >{{ remaining() === null ? 'No known limit' : remaining() + ' left' }}</span\n      >\n    }\n  </ng-container>\n\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <!-- `plain`: a read-only value drawn as text, with a quiet dash when empty (PLAIN_VALUE_CLASS). -->\n  <input\n    class=\"scoular-form-input\"\n    [class]=\"plain() ? plainClass : ''\"\n    [attr.placeholder]=\"plain() ? emptyText : null\"\n    [class.error]=\"invalid()\"\n    [class.cws:border-scoular-yellow]=\"borderWarning() && !invalid()\"\n    [class.cws:border-scoular-green]=\"tone() === 'valid' && !invalid()\"\n    [attr.data-tone]=\"tone()\"\n    [id]=\"controlId()\"\n    type=\"text\"\n    autocomplete=\"off\"\n    [value]=\"value()\"\n    [attr.maxlength]=\"maxLength()\"\n    [readOnly]=\"readOnly()\"\n    [attr.tabindex]=\"skipTab() ? -1 : null\"\n    [disabled]=\"disabled()\"\n    [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n    [attr.aria-invalid]=\"invalid() ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.title]=\"warningText()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  />\n  }\n</cms-field>\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		maxLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLength",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		requiredMarker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "requiredMarker",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		plain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		skipTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skipTab",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		describedByExtra: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedByExtra",
				required: false
			}]
		}]
	}
});
const CODE_SEARCH_MIN_LENGTH = 3;
const CODE_SEARCH_MAX_RESULTS = 50;
var DropdownCaretComponent = class DropdownCaretComponent {
	open = input(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DropdownCaretComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: DropdownCaretComponent,
		isStandalone: true,
		selector: "cms-dropdown-caret",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: {
				"aria-hidden": "true",
				"data-dropdown-caret": ""
			},
			properties: { "class.cws:opacity-50": "disabled()" },
			classAttribute: "cws:pointer-events-none cws:inline-flex cws:shrink-0 cws:items-center"
		},
		ngImport: i0,
		template: `
    <svg
      class="cws:size-4 cws:transition-transform"
      [class.cws:rotate-180]="open()"
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
      focusable="false"
    >
      <path d="M4 6l4 4 4-4" />
    </svg>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DropdownCaretComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-dropdown-caret",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"aria-hidden": "true",
				"data-dropdown-caret": "",
				class: "cws:pointer-events-none cws:inline-flex cws:shrink-0 cws:items-center",
				"[class.cws:opacity-50]": "disabled()"
			},
			template: `
    <svg
      class="cws:size-4 cws:transition-transform"
      [class.cws:rotate-180]="open()"
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
      focusable="false"
    >
      <path d="M4 6l4 4 4-4" />
    </svg>
  `
		}]
	}],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
var CodeComboComponent = class CodeComboComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	requiredMarker = input(false, ...ngDevMode ? [{ debugName: "requiredMarker" }] : /* istanbul ignore next */ []);
	showsRequired = computed(() => this.required() || this.requiredMarker(), ...ngDevMode ? [{ debugName: "showsRequired" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	plain = input(false, ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	compact = input(false, ...ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []);
	search = input(null, ...ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []);
	searchState = signal(null, ...ngDevMode ? [{ debugName: "searchState" }] : /* istanbul ignore next */ []);
	searchQueries = new Subject();
	chosen = signal(null, ...ngDevMode ? [{ debugName: "chosen" }] : /* istanbul ignore next */ []);
	constructor() {
		this.searchQueries.pipe(debounceTime(SEARCH_DEBOUNCE_MS), switchMap((text) => {
			const search = this.search();
			return search === null || text.length < 3 ? of(null) : search(text);
		}), takeUntilDestroyed()).subscribe((state) => this.searchState.set(state));
	}
	searchStatus = computed(() => {
		if (this.search() === null) return null;
		if ((this.query() ?? "").trim().length < 3) return `Type at least 3 characters to search.`;
		const state = this.searchState();
		if (state === null || state.status === "idle" || state.status === "loading") return "Searching…";
		if (state.status === "error") return "Search unavailable. Enter the code; CTRM checks it when you save.";
		return state.value.length === 0 ? "No matches. CTRM checks the code when you save." : null;
	}, ...ngDevMode ? [{ debugName: "searchStatus" }] : /* istanbul ignore next */ []);
	emptyListText = computed(() => this.searchStatus() ?? "No matches", ...ngDevMode ? [{ debugName: "emptyListText" }] : /* istanbul ignore next */ []);
	compactTitle = computed(() => {
		const selected = this.selectedOption();
		return this.compact() && selected !== null ? `${selected.code} — ${selected.description}` : null;
	}, ...ngDevMode ? [{ debugName: "compactTitle" }] : /* istanbul ignore next */ []);
	displayText = computed(() => {
		const selected = this.query() === null ? this.selectedOption() : null;
		if (selected === null) return this.displayValue();
		return this.compact() ? selected.code : `${selected.code} — ${selected.description}`;
	}, ...ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []);
	plainClass = PLAIN_VALUE_CLASS;
	emptyText = "—";
	showsCaret = computed(() => !this.readOnly() && !this.plain(), ...ngDevMode ? [{ debugName: "showsCaret" }] : /* istanbul ignore next */ []);
	skipTab = input(false, ...ngDevMode ? [{ debugName: "skipTab" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	tone = input(null, ...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	describedByExtra = input(null, ...ngDevMode ? [{ debugName: "describedByExtra" }] : /* istanbul ignore next */ []);
	invalid = computed(() => this.errorMessage() !== null || this.tone() === "invalid", ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	inputElement = viewChild("comboInput", ...ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	activeIndex = signal(-1, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	selectedCode = signal(null, ...ngDevMode ? [{ debugName: "selectedCode" }] : /* istanbul ignore next */ []);
	query = signal(null, ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	selectedOption = computed(() => {
		const code = this.selectedCode();
		const chosen = this.chosen();
		return this.options().find((option) => option.code === code) ?? (chosen !== null && chosen.code === code ? chosen : null);
	}, ...ngDevMode ? [{ debugName: "selectedOption" }] : /* istanbul ignore next */ []);
	displayValue = computed(() => {
		const typed = this.query();
		if (typed !== null) return typed;
		const selected = this.selectedOption();
		if (selected) return this.compact() ? selected.code : `${selected.code} — ${selected.description}`;
		return this.selectedCode() ?? "";
	}, ...ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []);
	filtered = computed(() => {
		if (this.search() !== null) {
			const state = this.searchState();
			return this.searchStatus() === null && state?.status === "loaded" ? state.value : [];
		}
		const typed = this.query();
		if (typed === null || typed.trim() === "") return this.options();
		const needle = typed.trim().toLowerCase();
		return this.options().filter((option) => option.code.toLowerCase().includes(needle) || option.description.toLowerCase().includes(needle));
	}, ...ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		const ids = [this.errorMessage() ? `${this.controlId()}-error` : this.warningText() ? `${this.controlId()}-hint` : null, this.describedByExtra()].filter((id) => id !== null);
		return ids.length > 0 ? ids.join(" ") : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	optionClass(active) {
		return active ? ACTIVE_OPTION_CLASS : INACTIVE_OPTION_CLASS;
	}
	optionId(index) {
		return `${this.controlId()}-option-${index}`;
	}
	activeOptionId = computed(() => {
		const index = this.activeIndex();
		return this.open() && index >= 0 ? this.optionId(index) : null;
	}, ...ngDevMode ? [{ debugName: "activeOptionId" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.selectedCode.set(typeof value === "string" && value !== "" ? value : null);
		this.query.set(null);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		const raw = event.target.value;
		this.query.set(raw);
		this.open.set(true);
		if (this.search() !== null) {
			const typed = raw.trim();
			this.searchState.set(typed.length < 3 ? null : remoteLoading());
			this.activeIndex.set(-1);
			this.searchQueries.next(typed);
			return;
		}
		const exact = this.options().find((option) => option.code.toLowerCase() === raw.trim().toLowerCase());
		if (exact) {
			this.commit(exact, { keepOpen: true });
			return;
		}
		this.activeIndex.set(this.filtered().length > 0 ? 0 : -1);
	}
	onFocus() {
		if (this.inputElement()?.nativeElement.hasAttribute("data-cws-quiet-focus")) return;
		if (!this.readOnly() && !this.disabled()) {
			this.open.set(true);
			this.activeIndex.set(this.indexOfSelected());
		}
	}
	onKeydown(event) {
		if (this.readOnly() || this.disabled()) return;
		switch (event.key) {
			case "ArrowDown":
				event.preventDefault();
				this.openIfClosed();
				this.move(1);
				break;
			case "ArrowUp":
				event.preventDefault();
				this.openIfClosed();
				this.move(-1);
				break;
			case "Home":
				if (this.open()) {
					event.preventDefault();
					this.activeIndex.set(0);
				}
				break;
			case "End":
				if (this.open()) {
					event.preventDefault();
					this.activeIndex.set(this.filtered().length - 1);
				}
				break;
			case "Enter": {
				if (!this.open()) return;
				const option = this.filtered()[this.activeIndex()];
				if (option) {
					event.preventDefault();
					this.commit(option);
				} else if (this.search() !== null) this.commitTyped();
				break;
			}
			case "Escape":
				if (this.open() || this.query() !== null) {
					event.preventDefault();
					this.revert();
				}
				break;
			case "Tab": this.closeAndSettle();
		}
	}
	openLookup() {
		if (!this.readOnly() && !this.disabled()) this.openIfClosed();
	}
	onClick() {
		this.openLookup();
	}
	onOptionClick(option) {
		this.commit(option);
		this.inputElement()?.nativeElement.focus();
	}
	onBlur() {
		this.closeAndSettle();
		this.onTouched();
	}
	openIfClosed() {
		if (!this.open()) {
			this.open.set(true);
			this.activeIndex.set(this.indexOfSelected());
		}
	}
	move(delta) {
		const list = this.filtered();
		if (list.length === 0) {
			this.activeIndex.set(-1);
			return;
		}
		const next = this.activeIndex() + delta;
		this.activeIndex.set((next % list.length + list.length) % list.length);
	}
	indexOfSelected() {
		const index = this.filtered().findIndex((option) => option.code === this.selectedCode());
		return index >= 0 ? index : 0;
	}
	commit(option, options = {}) {
		if (this.search() !== null) this.chosen.set(option);
		this.selectedCode.set(option.code);
		this.onChange(option.code);
		if (!options.keepOpen) {
			this.query.set(null);
			this.open.set(false);
			this.activeIndex.set(-1);
		}
	}
	revert() {
		this.query.set(null);
		this.open.set(false);
		this.activeIndex.set(-1);
	}
	commitTyped() {
		const typed = this.query();
		if (typed === null) return;
		const code = typed.trim().toUpperCase();
		const option = this.filtered().find((candidate) => candidate.code.toUpperCase() === code);
		if (option !== void 0) {
			this.commit(option);
			return;
		}
		const value = code === "" ? null : code;
		if (value !== this.selectedCode()) {
			this.selectedCode.set(value);
			this.onChange(value);
		}
		this.query.set(null);
		this.open.set(false);
		this.activeIndex.set(-1);
	}
	closeAndSettle() {
		if (this.search() !== null) this.commitTyped();
		this.query.set(null);
		this.open.set(false);
		this.activeIndex.set(-1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CodeComboComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CodeComboComponent,
		isStandalone: true,
		selector: "cms-code-combo",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			requiredMarker: {
				classPropertyName: "requiredMarker",
				publicName: "requiredMarker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plain: {
				classPropertyName: "plain",
				publicName: "plain",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			compact: {
				classPropertyName: "compact",
				publicName: "compact",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			search: {
				classPropertyName: "search",
				publicName: "search",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skipTab: {
				classPropertyName: "skipTab",
				publicName: "skipTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedByExtra: {
				classPropertyName: "describedByExtra",
				publicName: "describedByExtra",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => CodeComboComponent),
			multi: true
		}],
		viewQueries: [{
			propertyName: "inputElement",
			first: true,
			predicate: ["comboInput"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <div class=\"cws:relative\">\n    <!--\n      ARIA combobox pattern: focus never leaves this input. The active option is conveyed by\n      aria-activedescendant, so arrow keys announce options without moving DOM focus.\n    -->\n    <input\n      #comboInput\n      class=\"scoular-form-input\"\n      [class]=\"plain() ? plainClass : ''\"\n      [attr.placeholder]=\"plain() ? emptyText : null\"\n      [class.error]=\"invalid()\"\n      [class.cws:border-scoular-yellow]=\"borderWarning() && !invalid()\"\n      [class.cws:border-scoular-green]=\"tone() === 'valid' && !invalid()\"\n      [class.cws:pr-7]=\"showsCaret() && !compact()\"\n      [class.cws:pl-3]=\"showsCaret() && compact()\"\n      [class.cws:pr-6]=\"showsCaret() && compact()\"\n      [attr.data-tone]=\"tone()\"\n      [id]=\"controlId()\"\n      type=\"text\"\n      role=\"combobox\"\n      autocomplete=\"off\"\n      [attr.aria-expanded]=\"open()\"\n      [attr.aria-controls]=\"controlId() + '-listbox'\"\n      [attr.aria-activedescendant]=\"activeOptionId()\"\n      aria-autocomplete=\"list\"\n      [value]=\"displayValue()\"\n      [readOnly]=\"readOnly()\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [disabled]=\"disabled()\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"invalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"warningText() ?? compactTitle()\"\n      [attr.data-cws-lookup]=\"readOnly() || disabled() ? null : ''\"\n      (focus)=\"onFocus()\"\n      (click)=\"onClick()\"\n      (cws-open-lookup)=\"openLookup()\"\n      (input)=\"onInput($event)\"\n      (keydown)=\"onKeydown($event)\"\n      (blur)=\"onBlur()\"\n    />\n\n    @if (showsCaret()) {\n      <!--\n        The caret (2026-10-28): says this box opens a list, as a native select's does. Decoration, so\n        a click on it passes through to the input, which opens the list. The input's right padding\n        above keeps text from running under it; a compact box trims its left padding so its code still shows.\n        Placed and coloured as the browser draws a native select's chevron.\n      -->\n      <cms-dropdown-caret\n        class=\"cws:absolute cws:top-1/2 cws:right-0.5 cws:-translate-y-1/2 cws:text-slate-900 cws:dark:text-white\"\n        [open]=\"open()\"\n        [disabled]=\"disabled()\"\n      />\n    }\n\n    @if (open()) {\n      <ul\n        class=\"scoular-dropdown cws:absolute cws:mt-1 cws:max-h-60 cws:w-full cws:overflow-auto\"\n        [class.cws:min-w-72]=\"compact()\"\n        role=\"listbox\"\n        [id]=\"controlId() + '-listbox'\"\n        [attr.aria-label]=\"label()\"\n      >\n        @for (option of filtered(); track option.code; let i = $index) {\n          <!--\n            mousedown rather than click: blur fires first on click and would close the list before\n            the selection registered.\n          -->\n          <!--\n            ⚠ These rows deliberately do NOT use `.scoular-dropdown-item`. The whole class string\n            comes from `optionClass()`, and the reasoning — two contrast bugs, both caused by\n            unlayered design-system CSS beating Tailwind utilities — is documented there. Do not\n            \"restore\" the design-system class: it re-breaks both, and both look fine in review.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n          -->\n          <li\n            [class]=\"optionClass(i === activeIndex())\"\n            role=\"option\"\n            [id]=\"optionId(i)\"\n            [attr.aria-selected]=\"i === activeIndex()\"\n            (mousedown)=\"$event.preventDefault(); onOptionClick(option)\"\n          >\n            <span class=\"cws:font-mono cws:text-xs\">{{ option.code }}</span>\n            <span class=\"cws:mx-1\" aria-hidden=\"true\">—</span>\n            <span>{{ option.description }}</span>\n          </li>\n        } @empty {\n          <!-- \"No matches\", or in search mode the search's own line (#1064): too short, searching,\n               no matches or unavailable. -->\n          <li\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\"\n            role=\"option\"\n            aria-disabled=\"true\"\n          >\n            {{ emptyListText() }}\n          </li>\n        }\n      </ul>\n    }\n  </div>\n  }\n</cms-field>\n",
		dependencies: [
			{
				kind: "component",
				type: DropdownCaretComponent,
				selector: "cms-dropdown-caret",
				inputs: ["open", "disabled"]
			},
			{
				kind: "component",
				type: FieldComponent,
				selector: "cms-field",
				inputs: [
					"label",
					"controlId",
					"required",
					"hideLabel",
					"errorMessage",
					"hint",
					"labelFor",
					"help",
					"marker",
					"display"
				]
			},
			{
				kind: "component",
				type: FieldValueComponent,
				selector: "cms-field-value",
				inputs: [
					"controlId",
					"text",
					"multiline"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CodeComboComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-code-combo",
			imports: [
				DropdownCaretComponent,
				FieldComponent,
				FieldValueComponent
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => CodeComboComponent),
				multi: true
			}],
			template: "<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <div class=\"cws:relative\">\n    <!--\n      ARIA combobox pattern: focus never leaves this input. The active option is conveyed by\n      aria-activedescendant, so arrow keys announce options without moving DOM focus.\n    -->\n    <input\n      #comboInput\n      class=\"scoular-form-input\"\n      [class]=\"plain() ? plainClass : ''\"\n      [attr.placeholder]=\"plain() ? emptyText : null\"\n      [class.error]=\"invalid()\"\n      [class.cws:border-scoular-yellow]=\"borderWarning() && !invalid()\"\n      [class.cws:border-scoular-green]=\"tone() === 'valid' && !invalid()\"\n      [class.cws:pr-7]=\"showsCaret() && !compact()\"\n      [class.cws:pl-3]=\"showsCaret() && compact()\"\n      [class.cws:pr-6]=\"showsCaret() && compact()\"\n      [attr.data-tone]=\"tone()\"\n      [id]=\"controlId()\"\n      type=\"text\"\n      role=\"combobox\"\n      autocomplete=\"off\"\n      [attr.aria-expanded]=\"open()\"\n      [attr.aria-controls]=\"controlId() + '-listbox'\"\n      [attr.aria-activedescendant]=\"activeOptionId()\"\n      aria-autocomplete=\"list\"\n      [value]=\"displayValue()\"\n      [readOnly]=\"readOnly()\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [disabled]=\"disabled()\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"invalid() ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"warningText() ?? compactTitle()\"\n      [attr.data-cws-lookup]=\"readOnly() || disabled() ? null : ''\"\n      (focus)=\"onFocus()\"\n      (click)=\"onClick()\"\n      (cws-open-lookup)=\"openLookup()\"\n      (input)=\"onInput($event)\"\n      (keydown)=\"onKeydown($event)\"\n      (blur)=\"onBlur()\"\n    />\n\n    @if (showsCaret()) {\n      <!--\n        The caret (2026-10-28): says this box opens a list, as a native select's does. Decoration, so\n        a click on it passes through to the input, which opens the list. The input's right padding\n        above keeps text from running under it; a compact box trims its left padding so its code still shows.\n        Placed and coloured as the browser draws a native select's chevron.\n      -->\n      <cms-dropdown-caret\n        class=\"cws:absolute cws:top-1/2 cws:right-0.5 cws:-translate-y-1/2 cws:text-slate-900 cws:dark:text-white\"\n        [open]=\"open()\"\n        [disabled]=\"disabled()\"\n      />\n    }\n\n    @if (open()) {\n      <ul\n        class=\"scoular-dropdown cws:absolute cws:mt-1 cws:max-h-60 cws:w-full cws:overflow-auto\"\n        [class.cws:min-w-72]=\"compact()\"\n        role=\"listbox\"\n        [id]=\"controlId() + '-listbox'\"\n        [attr.aria-label]=\"label()\"\n      >\n        @for (option of filtered(); track option.code; let i = $index) {\n          <!--\n            mousedown rather than click: blur fires first on click and would close the list before\n            the selection registered.\n          -->\n          <!--\n            ⚠ These rows deliberately do NOT use `.scoular-dropdown-item`. The whole class string\n            comes from `optionClass()`, and the reasoning — two contrast bugs, both caused by\n            unlayered design-system CSS beating Tailwind utilities — is documented there. Do not\n            \"restore\" the design-system class: it re-breaks both, and both look fine in review.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n          -->\n          <li\n            [class]=\"optionClass(i === activeIndex())\"\n            role=\"option\"\n            [id]=\"optionId(i)\"\n            [attr.aria-selected]=\"i === activeIndex()\"\n            (mousedown)=\"$event.preventDefault(); onOptionClick(option)\"\n          >\n            <span class=\"cws:font-mono cws:text-xs\">{{ option.code }}</span>\n            <span class=\"cws:mx-1\" aria-hidden=\"true\">—</span>\n            <span>{{ option.description }}</span>\n          </li>\n        } @empty {\n          <!-- \"No matches\", or in search mode the search's own line (#1064): too short, searching,\n               no matches or unavailable. -->\n          <li\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\"\n            role=\"option\"\n            aria-disabled=\"true\"\n          >\n            {{ emptyListText() }}\n          </li>\n        }\n      </ul>\n    }\n  </div>\n  }\n</cms-field>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		requiredMarker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "requiredMarker",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		plain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		compact: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "compact",
				required: false
			}]
		}],
		search: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "search",
				required: false
			}]
		}],
		skipTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skipTab",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: false
			}]
		}],
		describedByExtra: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedByExtra",
				required: false
			}]
		}],
		inputElement: [{
			type: i0.ViewChild,
			args: ["comboInput", { isSignal: true }]
		}]
	}
});
const QUIET_FOCUS_ATTRIBUTE = "data-cws-quiet-focus";
const SEARCH_DEBOUNCE_MS = 250;
function focusWithoutOpening(element) {
	element.setAttribute(QUIET_FOCUS_ATTRIBUTE, "");
	try {
		element.focus();
	} finally {
		element.removeAttribute(QUIET_FOCUS_ATTRIBUTE);
	}
}
const OPTION_LAYOUT = "cws:flex cws:w-full cws:cursor-pointer cws:items-center cws:gap-3 cws:px-4 cws:py-2 cws:text-sm cws:transition-colors";
const ACTIVE_OPTION_CLASS = `${OPTION_LAYOUT} cws:bg-scoular-blue cws:text-white cws:hover:bg-scoular-blue-dark`;
const INACTIVE_OPTION_CLASS = `${OPTION_LAYOUT} cws:text-slate-700 cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700`;
const WEEKDAYS = [
	{
		short: "Su",
		full: "Sunday"
	},
	{
		short: "Mo",
		full: "Monday"
	},
	{
		short: "Tu",
		full: "Tuesday"
	},
	{
		short: "We",
		full: "Wednesday"
	},
	{
		short: "Th",
		full: "Thursday"
	},
	{
		short: "Fr",
		full: "Friday"
	},
	{
		short: "Sa",
		full: "Saturday"
	}
];
const MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
const CELLS = 42;
var DatePickerComponent = class DatePickerComponent {
	value = input(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	today = input(toIsoDate(nowParts()), ...ngDevMode ? [{ debugName: "today" }] : /* istanbul ignore next */ []);
	dateSelected = output();
	cleared = output();
	dismissed = output();
	grid = viewChild("grid", ...ngDevMode ? [{ debugName: "grid" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef);
	view = signal("day", ...ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []);
	focused = signal(this.today(), ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	viewMonth = computed(() => {
		const parsed = fromIsoDate(this.focused());
		return parsed === null ? this.today() : toIsoDate({
			year: parsed.year,
			month: parsed.month,
			day: 1
		});
	}, ...ngDevMode ? [{ debugName: "viewMonth" }] : /* istanbul ignore next */ []);
	weekdays = WEEKDAYS;
	months = MONTHS;
	monthLabel = computed(() => {
		const parsed = fromIsoDate(this.viewMonth());
		return parsed === null ? "" : `${MONTHS[parsed.month - 1]} ${parsed.year}`;
	}, ...ngDevMode ? [{ debugName: "monthLabel" }] : /* istanbul ignore next */ []);
	decadeStart = computed(() => {
		const parsed = fromIsoDate(this.focused());
		const year = parsed === null ? nowParts().year : parsed.year;
		return year - (year % 12 + 12) % 12;
	}, ...ngDevMode ? [{ debugName: "decadeStart" }] : /* istanbul ignore next */ []);
	decadeYears = computed(() => Array.from({ length: 12 }, (_, index) => this.decadeStart() + index), ...ngDevMode ? [{ debugName: "decadeYears" }] : /* istanbul ignore next */ []);
	decadeLabel = computed(() => `${this.decadeStart()} – ${this.decadeStart() + 11}`, ...ngDevMode ? [{ debugName: "decadeLabel" }] : /* istanbul ignore next */ []);
	days = computed(() => {
		const first = this.viewMonth();
		const parsedFirst = fromIsoDate(first);
		if (parsedFirst === null) return [];
		const offset = dayOfWeek(first) ?? 0;
		const start = addDays(first, -offset);
		if (start === null) return [];
		const selected = this.value();
		const today = this.today();
		const focused = this.focused();
		const cells = [];
		for (let index = 0; index < CELLS; index += 1) {
			const iso = addDays(start, index);
			if (iso === null) continue;
			const parsed = fromIsoDate(iso);
			if (parsed === null) continue;
			cells.push({
				iso,
				day: parsed.day,
				adjacent: parsed.month !== parsedFirst.month,
				today: iso === today,
				selected: selected !== null && iso === selected,
				focused: iso === focused,
				label: `${MONTHS[parsed.month - 1]} ${parsed.day}, ${parsed.year}`
			});
		}
		return cells;
	}, ...ngDevMode ? [{ debugName: "days" }] : /* istanbul ignore next */ []);
	showClear = computed(() => !this.required() && this.value() !== null, ...ngDevMode ? [{ debugName: "showClear" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const value = this.value();
			this.focused.set(value !== null && fromIsoDate(value) !== null ? value : this.today());
		});
	}
	focusActiveCell() {
		queueMicrotask(() => {
			this.host.nativeElement.querySelector("[data-active=\"true\"]")?.focus();
		});
	}
	select(iso) {
		const parsed = fromIsoDate(iso);
		if (parsed === null || !isRealDate(parsed)) return;
		this.dateSelected.emit(iso);
	}
	step(days) {
		const next = addDays(this.focused(), days);
		if (next !== null) {
			this.focused.set(next);
			this.focusActiveCell();
		}
	}
	stepMonths(count) {
		const next = addMonths(this.focused(), count);
		if (next !== null) {
			this.focused.set(next);
			this.focusActiveCell();
		}
	}
	page(direction) {
		const view = this.view();
		if (view === "day") {
			this.stepMonths(direction);
			return;
		}
		if (view === "month") {
			this.stepMonths(direction * 12);
			return;
		}
		this.stepMonths(direction * 12 * 12);
	}
	pageLabel(direction) {
		const unit = this.view() === "day" ? "month" : this.view() === "month" ? "year" : "decade";
		return `${direction === -1 ? "Previous" : "Next"} ${unit}`;
	}
	cycleView() {
		this.view.update((current) => current === "day" ? "month" : current === "month" ? "year" : "day");
	}
	chooseMonth(monthIndex) {
		const parsed = fromIsoDate(this.focused());
		if (parsed === null) return;
		const lastDay = new Date(Date.UTC(parsed.year, monthIndex + 1, 0)).getUTCDate();
		this.focused.set(toIsoDate({
			year: parsed.year,
			month: monthIndex + 1,
			day: Math.min(parsed.day, lastDay)
		}));
		this.view.set("day");
		this.focusActiveCell();
	}
	chooseYear(year) {
		const parsed = fromIsoDate(this.focused());
		if (parsed === null) return;
		const lastDay = new Date(Date.UTC(year, parsed.month, 0)).getUTCDate();
		this.focused.set(toIsoDate({
			year,
			month: parsed.month,
			day: Math.min(parsed.day, lastDay)
		}));
		this.view.set("month");
	}
	onToday() {
		this.focused.set(this.today());
		this.view.set("day");
		this.select(this.today());
	}
	onClear() {
		this.cleared.emit();
	}
	onGridKeydown(event) {
		const key = event.key;
		if (key === "ArrowLeft") this.step(-1);
		else if (key === "ArrowRight") this.step(1);
		else if (key === "ArrowUp") this.step(-7);
		else if (key === "ArrowDown") this.step(7);
		else if (key === "Home") this.step(-(dayOfWeek(this.focused()) ?? 0));
		else if (key === "End") this.step(6 - (dayOfWeek(this.focused()) ?? 0));
		else if (key === "PageUp") this.stepMonths(event.shiftKey ? -12 : -1);
		else if (key === "PageDown") this.stepMonths(event.shiftKey ? 12 : 1);
		else if (key === "Enter" || key === " ") this.select(this.focused());
		else return;
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DatePickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: DatePickerComponent,
		isStandalone: true,
		selector: "cms-date-picker",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			today: {
				classPropertyName: "today",
				publicName: "today",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			dateSelected: "dateSelected",
			cleared: "cleared",
			dismissed: "dismissed"
		},
		host: { classAttribute: "cws:block" },
		viewQueries: [{
			propertyName: "grid",
			first: true,
			predicate: ["grid"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<!--\n  🔴 Utilities composed directly, never layered over a `scoular-*` class.\n\n  The design system compiles UNLAYERED while Tailwind utilities land in `@layer utilities`, so a\n  utility beside a design-system class silently loses and looks entirely correct in review. The day\n  cells therefore wear no `scoular-*` class at all -- their size, radius and fill are all utilities,\n  so nothing is contested. The two footer buttons DO use `scoular-btn`, and add only height, which\n  the design system leaves undeclared.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n-->\n<div\n  class=\"cws:w-72 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-3 cws:shadow-lg cws:dark:border-slate-700 cws:dark:bg-slate-800\"\n  role=\"dialog\"\n  aria-label=\"Choose a date\"\n  aria-modal=\"true\"\n>\n  <!--\n    The header. Chevrons FLANK the label rather than sitting together at one end: the native picker\n    put both arrows in the top-right corner, so paging back meant aiming at a control nowhere near\n    the month it changed.\n  -->\n  <div class=\"cws:mb-2 cws:flex cws:items-center cws:justify-between cws:gap-1\">\n    <button\n      type=\"button\"\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\n      [attr.aria-label]=\"pageLabel(-1)\"\n      (click)=\"page(-1)\"\n    >\n      <span aria-hidden=\"true\">&#8249;</span>\n    </button>\n\n    <!--\n      One button, cycling day -> month -> year. A separate month menu and year menu would be two\n      controls for one question (\"show me a different month\"), and the drill-up is what every\n      calendar the user has met already does.\n    -->\n    <button\n      type=\"button\"\n      class=\"cws:flex-1 cws:rounded cws:px-2 cws:py-1 cws:text-sm cws:font-semibold cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\n      [attr.aria-label]=\"'Showing ' + (view() === 'year' ? decadeLabel() : monthLabel()) + '. Change view.'\"\n      (click)=\"cycleView()\"\n    >\n      {{ view() === 'year' ? decadeLabel() : monthLabel() }}\n    </button>\n\n    <button\n      type=\"button\"\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\n      [attr.aria-label]=\"pageLabel(1)\"\n      (click)=\"page(1)\"\n    >\n      <span aria-hidden=\"true\">&#8250;</span>\n    </button>\n  </div>\n\n  @if (view() === 'day') {\n    <!--\n      `abbr` on the short weekday names, so a screen reader says \"Monday\" where a sighted reader\n      sees \"Mo\". Two letters is what keeps the column 2.25rem wide.\n    -->\n    <div class=\"cws:grid cws:grid-cols-7\" aria-hidden=\"true\">\n      @for (weekday of weekdays; track weekday.short) {\n        <div class=\"cws:flex cws:h-7 cws:w-9 cws:items-center cws:justify-center cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\n          <abbr class=\"cws:no-underline\" [title]=\"weekday.full\">{{ weekday.short }}</abbr>\n        </div>\n      }\n    </div>\n\n    <!--\n      🔴 Roving tabindex: exactly ONE cell is tabbable and the arrows move which. Making every cell\n      tabbable would put 42 stops between the grid and the footer.\n\n      `data-active` is what `focusActiveCell` aims at -- an attribute rather than a class so that\n      restyling a cell can never change which one receives focus.\n    -->\n    <!--\n      🔴 The colour choices here are MEASURED, not picked. In Edge against the built stylesheet:\n\n        selected text on its fill    7.54 light / 7.54 dark\n        selected chip vs surface     7.54 light / ring at 6.71 dark\n        today ring on the surface    7.54 light / 6.71 dark\n        plain in-month day           17.83 light / 14.62 dark\n        adjacent-month day            4.76 light /  5.56 dark\n\n      ⚠ Three of those were failures first time, and the dark-mode one is a genuine tension\n      rather than a slip. `bg-scoular-blue` measures **1.94:1** against the dark panel -- the\n      brand blue IS a dark blue -- so the selected chip nearly vanished and the 1px today ring\n      was invisible. But every blue light enough to separate from that panel is too light to\n      carry white text: `sky-600` fixed the surface (3.63) and broke the text (4.02).\n\n      🔑 So the fill keeps the brand blue, which white text clears at 7.54, and the chip is\n      separated from the dark panel by a `sky-400` RING at 6.71 -- a boundary rather than a fill,\n      which is what WCAG 1.4.11 asks for on a non-text component. `sky-400` is also what the rest\n      of the application already uses for a blue accent in the dark theme.\n\n      ⚠ Adjacent-month days were `slate-400`/`slate-500` and measured 2.63 and 3.07. They are\n      meant to be quiet, but they are CLICKABLE, so they have to be legible: one step in each\n      theme clears 4.5:1 while staying visibly dimmer than an in-month day.\n\n      🔴 **Each class below is bound EXACTLY ONCE.** Two `[class.x]` bindings for one class do not\n      combine -- Angular applies the last, so the first condition is silently dead. `ring-1`,\n      `ring-inset` and `dark:ring-sky-400` were each bound twice here, and the selected day lost\n      its ring entirely: the markup read correctly and the DOM simply did not have the class.\n      Caught by dumping the rendered cell and grepping it, not by reading the template.\n\n      ⚠ Today keeps a ring even when it is also the selected day, which is why the ring colour\n      switches to white there -- a brand-blue ring on a brand-blue fill is invisible, so \"today\"\n      would disappear on exactly the day a user is most likely to be looking at.\n\n      ⚠ The dark selected chip is separated by a BORDER rather than a ring, because the ring is\n      already spoken for by today. Different property, no collision, and the cell is a fixed\n      `h-9 w-9` under border-box so a 1px border cannot move the grid.\n    -->\n    <div #grid role=\"grid\" class=\"cws:grid cws:grid-cols-7\" (keydown)=\"onGridKeydown($event)\">\n      @for (cell of days(); track cell.iso) {\n        <button\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"cws:flex cws:h-9 cws:w-9 cws:items-center cws:justify-center cws:rounded-full cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue\"\n          [class.cws:bg-scoular-blue]=\"cell.selected\"\n          [class.cws:text-white]=\"cell.selected\"\n          [class.cws:font-semibold]=\"cell.selected\"\n\n          [class.cws:ring-1]=\"cell.today\"\n          [class.cws:ring-inset]=\"cell.today\"\n          [class.cws:ring-white]=\"cell.today && cell.selected\"\n          [class.cws:ring-scoular-blue]=\"cell.today && !cell.selected\"\n          [class.cws:dark:ring-sky-400]=\"cell.today && !cell.selected\"\n\n          [class.cws:dark:border]=\"cell.selected\"\n          [class.cws:dark:border-sky-400]=\"cell.selected\"\n          [class.cws:text-slate-900]=\"!cell.selected && !cell.adjacent\"\n          [class.cws:dark:text-white]=\"!cell.selected && !cell.adjacent\"\n          [class.cws:text-slate-500]=\"!cell.selected && cell.adjacent\"\n          [class.cws:dark:text-slate-400]=\"!cell.selected && cell.adjacent\"\n          [class.cws:hover:bg-slate-100]=\"!cell.selected\"\n          [class.cws:dark:hover:bg-slate-700]=\"!cell.selected\"\n          [attr.data-active]=\"cell.focused ? 'true' : null\"\n          [attr.tabindex]=\"cell.focused ? 0 : -1\"\n          [attr.aria-label]=\"cell.label\"\n          [attr.aria-selected]=\"cell.selected ? 'true' : 'false'\"\n          [attr.aria-current]=\"cell.today ? 'date' : null\"\n          (click)=\"select(cell.iso)\"\n        >\n          {{ cell.day }}\n        </button>\n      }\n    </div>\n  } @else if (view() === 'month') {\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a month\">\n      @for (month of months; track month; let index = $index) {\n        <button\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\n          (click)=\"chooseMonth(index)\"\n        >\n          {{ month.slice(0, 3) }}\n        </button>\n      }\n    </div>\n  } @else {\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a year\">\n      @for (year of decadeYears(); track year) {\n        <button\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\n          (click)=\"chooseYear(year)\"\n        >\n          {{ year }}\n        </button>\n      }\n    </div>\n  }\n\n  <!--\n    ⚠ Real buttons in a row, both left-aligned. The native picker splits \"Clear\" and \"Today\" into\n    opposite corners as text links, which reads as one destructive control and one navigational one\n    when they are two peers.\n\n    `h-8` is added to `scoular-btn-sm` because the design system sets that variant's padding and font\n    size and never its height -- supplying a property nobody else declares applies normally, where\n    one that fought `py-1` would lose to the unlayered rule.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <div class=\"cws:mt-2 cws:flex cws:items-center cws:gap-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:dark:border-slate-700\">\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\n      (click)=\"onToday()\"\n    >\n      Today\n    </button>\n\n    @if (showClear()) {\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\n        (click)=\"onClear()\"\n      >\n        Clear\n      </button>\n    }\n  </div>\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DatePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-date-picker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: "<!--\n  🔴 Utilities composed directly, never layered over a `scoular-*` class.\n\n  The design system compiles UNLAYERED while Tailwind utilities land in `@layer utilities`, so a\n  utility beside a design-system class silently loses and looks entirely correct in review. The day\n  cells therefore wear no `scoular-*` class at all -- their size, radius and fill are all utilities,\n  so nothing is contested. The two footer buttons DO use `scoular-btn`, and add only height, which\n  the design system leaves undeclared.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n-->\n<div\n  class=\"cws:w-72 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-3 cws:shadow-lg cws:dark:border-slate-700 cws:dark:bg-slate-800\"\n  role=\"dialog\"\n  aria-label=\"Choose a date\"\n  aria-modal=\"true\"\n>\n  <!--\n    The header. Chevrons FLANK the label rather than sitting together at one end: the native picker\n    put both arrows in the top-right corner, so paging back meant aiming at a control nowhere near\n    the month it changed.\n  -->\n  <div class=\"cws:mb-2 cws:flex cws:items-center cws:justify-between cws:gap-1\">\n    <button\n      type=\"button\"\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\n      [attr.aria-label]=\"pageLabel(-1)\"\n      (click)=\"page(-1)\"\n    >\n      <span aria-hidden=\"true\">&#8249;</span>\n    </button>\n\n    <!--\n      One button, cycling day -> month -> year. A separate month menu and year menu would be two\n      controls for one question (\"show me a different month\"), and the drill-up is what every\n      calendar the user has met already does.\n    -->\n    <button\n      type=\"button\"\n      class=\"cws:flex-1 cws:rounded cws:px-2 cws:py-1 cws:text-sm cws:font-semibold cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\n      [attr.aria-label]=\"'Showing ' + (view() === 'year' ? decadeLabel() : monthLabel()) + '. Change view.'\"\n      (click)=\"cycleView()\"\n    >\n      {{ view() === 'year' ? decadeLabel() : monthLabel() }}\n    </button>\n\n    <button\n      type=\"button\"\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\n      [attr.aria-label]=\"pageLabel(1)\"\n      (click)=\"page(1)\"\n    >\n      <span aria-hidden=\"true\">&#8250;</span>\n    </button>\n  </div>\n\n  @if (view() === 'day') {\n    <!--\n      `abbr` on the short weekday names, so a screen reader says \"Monday\" where a sighted reader\n      sees \"Mo\". Two letters is what keeps the column 2.25rem wide.\n    -->\n    <div class=\"cws:grid cws:grid-cols-7\" aria-hidden=\"true\">\n      @for (weekday of weekdays; track weekday.short) {\n        <div class=\"cws:flex cws:h-7 cws:w-9 cws:items-center cws:justify-center cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\n          <abbr class=\"cws:no-underline\" [title]=\"weekday.full\">{{ weekday.short }}</abbr>\n        </div>\n      }\n    </div>\n\n    <!--\n      🔴 Roving tabindex: exactly ONE cell is tabbable and the arrows move which. Making every cell\n      tabbable would put 42 stops between the grid and the footer.\n\n      `data-active` is what `focusActiveCell` aims at -- an attribute rather than a class so that\n      restyling a cell can never change which one receives focus.\n    -->\n    <!--\n      🔴 The colour choices here are MEASURED, not picked. In Edge against the built stylesheet:\n\n        selected text on its fill    7.54 light / 7.54 dark\n        selected chip vs surface     7.54 light / ring at 6.71 dark\n        today ring on the surface    7.54 light / 6.71 dark\n        plain in-month day           17.83 light / 14.62 dark\n        adjacent-month day            4.76 light /  5.56 dark\n\n      ⚠ Three of those were failures first time, and the dark-mode one is a genuine tension\n      rather than a slip. `bg-scoular-blue` measures **1.94:1** against the dark panel -- the\n      brand blue IS a dark blue -- so the selected chip nearly vanished and the 1px today ring\n      was invisible. But every blue light enough to separate from that panel is too light to\n      carry white text: `sky-600` fixed the surface (3.63) and broke the text (4.02).\n\n      🔑 So the fill keeps the brand blue, which white text clears at 7.54, and the chip is\n      separated from the dark panel by a `sky-400` RING at 6.71 -- a boundary rather than a fill,\n      which is what WCAG 1.4.11 asks for on a non-text component. `sky-400` is also what the rest\n      of the application already uses for a blue accent in the dark theme.\n\n      ⚠ Adjacent-month days were `slate-400`/`slate-500` and measured 2.63 and 3.07. They are\n      meant to be quiet, but they are CLICKABLE, so they have to be legible: one step in each\n      theme clears 4.5:1 while staying visibly dimmer than an in-month day.\n\n      🔴 **Each class below is bound EXACTLY ONCE.** Two `[class.x]` bindings for one class do not\n      combine -- Angular applies the last, so the first condition is silently dead. `ring-1`,\n      `ring-inset` and `dark:ring-sky-400` were each bound twice here, and the selected day lost\n      its ring entirely: the markup read correctly and the DOM simply did not have the class.\n      Caught by dumping the rendered cell and grepping it, not by reading the template.\n\n      ⚠ Today keeps a ring even when it is also the selected day, which is why the ring colour\n      switches to white there -- a brand-blue ring on a brand-blue fill is invisible, so \"today\"\n      would disappear on exactly the day a user is most likely to be looking at.\n\n      ⚠ The dark selected chip is separated by a BORDER rather than a ring, because the ring is\n      already spoken for by today. Different property, no collision, and the cell is a fixed\n      `h-9 w-9` under border-box so a 1px border cannot move the grid.\n    -->\n    <div #grid role=\"grid\" class=\"cws:grid cws:grid-cols-7\" (keydown)=\"onGridKeydown($event)\">\n      @for (cell of days(); track cell.iso) {\n        <button\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"cws:flex cws:h-9 cws:w-9 cws:items-center cws:justify-center cws:rounded-full cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue\"\n          [class.cws:bg-scoular-blue]=\"cell.selected\"\n          [class.cws:text-white]=\"cell.selected\"\n          [class.cws:font-semibold]=\"cell.selected\"\n\n          [class.cws:ring-1]=\"cell.today\"\n          [class.cws:ring-inset]=\"cell.today\"\n          [class.cws:ring-white]=\"cell.today && cell.selected\"\n          [class.cws:ring-scoular-blue]=\"cell.today && !cell.selected\"\n          [class.cws:dark:ring-sky-400]=\"cell.today && !cell.selected\"\n\n          [class.cws:dark:border]=\"cell.selected\"\n          [class.cws:dark:border-sky-400]=\"cell.selected\"\n          [class.cws:text-slate-900]=\"!cell.selected && !cell.adjacent\"\n          [class.cws:dark:text-white]=\"!cell.selected && !cell.adjacent\"\n          [class.cws:text-slate-500]=\"!cell.selected && cell.adjacent\"\n          [class.cws:dark:text-slate-400]=\"!cell.selected && cell.adjacent\"\n          [class.cws:hover:bg-slate-100]=\"!cell.selected\"\n          [class.cws:dark:hover:bg-slate-700]=\"!cell.selected\"\n          [attr.data-active]=\"cell.focused ? 'true' : null\"\n          [attr.tabindex]=\"cell.focused ? 0 : -1\"\n          [attr.aria-label]=\"cell.label\"\n          [attr.aria-selected]=\"cell.selected ? 'true' : 'false'\"\n          [attr.aria-current]=\"cell.today ? 'date' : null\"\n          (click)=\"select(cell.iso)\"\n        >\n          {{ cell.day }}\n        </button>\n      }\n    </div>\n  } @else if (view() === 'month') {\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a month\">\n      @for (month of months; track month; let index = $index) {\n        <button\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\n          (click)=\"chooseMonth(index)\"\n        >\n          {{ month.slice(0, 3) }}\n        </button>\n      }\n    </div>\n  } @else {\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a year\">\n      @for (year of decadeYears(); track year) {\n        <button\n          type=\"button\"\n          role=\"gridcell\"\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\n          (click)=\"chooseYear(year)\"\n        >\n          {{ year }}\n        </button>\n      }\n    </div>\n  }\n\n  <!--\n    ⚠ Real buttons in a row, both left-aligned. The native picker splits \"Clear\" and \"Today\" into\n    opposite corners as text links, which reads as one destructive control and one navigational one\n    when they are two peers.\n\n    `h-8` is added to `scoular-btn-sm` because the design system sets that variant's padding and font\n    size and never its height -- supplying a property nobody else declares applies normally, where\n    one that fought `py-1` would lose to the unlayered rule.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <div class=\"cws:mt-2 cws:flex cws:items-center cws:gap-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:dark:border-slate-700\">\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\n      (click)=\"onToday()\"\n    >\n      Today\n    </button>\n\n    @if (showClear()) {\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\n        (click)=\"onClear()\"\n      >\n        Clear\n      </button>\n    }\n  </div>\n</div>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		today: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "today",
				required: false
			}]
		}],
		dateSelected: [{
			type: i0.Output,
			args: ["dateSelected"]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		dismissed: [{
			type: i0.Output,
			args: ["dismissed"]
		}],
		grid: [{
			type: i0.ViewChild,
			args: ["grid", { isSignal: true }]
		}]
	}
});
function nowParts() {
	const now = /* @__PURE__ */ new Date();
	return {
		year: now.getFullYear(),
		month: now.getMonth() + 1,
		day: now.getDate()
	};
}
var DateInputComponent = class DateInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	requiredMarker = input(false, ...ngDevMode ? [{ debugName: "requiredMarker" }] : /* istanbul ignore next */ []);
	showsRequired = computed(() => this.required() || this.requiredMarker(), ...ngDevMode ? [{ debugName: "showsRequired" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	plain = input(false, ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	displayText = computed(() => this.displayValue(), ...ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []);
	plainClass = PLAIN_VALUE_CLASS;
	emptyText = "—";
	skipTab = input(false, ...ngDevMode ? [{ debugName: "skipTab" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = signal(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	rawText = signal(null, ...ngDevMode ? [{ debugName: "rawText" }] : /* istanbul ignore next */ []);
	parseError = signal(false, ...ngDevMode ? [{ debugName: "parseError" }] : /* istanbul ignore next */ []);
	displayValue = computed(() => {
		const raw = this.rawText();
		if (raw !== null) return raw;
		return this.formatForDisplay(this.value());
	}, ...ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []);
	effectiveError = computed(() => this.parseError() ? "Enter a date as MMDDYYYY, MMDDYY, MM/DD/YYYY or YYYY-MM-DD." : this.errorMessage(), ...ngDevMode ? [{ debugName: "effectiveError" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		if (this.effectiveError()) return `${this.controlId()}-error`;
		return this.warningText() ? `${this.controlId()}-hint` : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	overlay = inject(Overlay);
	pickerScroll = this.overlay.scrollStrategies.reposition();
	pickerOpen = signal(false, ...ngDevMode ? [{ debugName: "pickerOpen" }] : /* istanbul ignore next */ []);
	textInput = viewChild("textInput", ...ngDevMode ? [{ debugName: "textInput" }] : /* istanbul ignore next */ []);
	picker = viewChild(DatePickerComponent, ...ngDevMode ? [{ debugName: "picker" }] : /* istanbul ignore next */ []);
	pickerValue = computed(() => this.value(), ...ngDevMode ? [{ debugName: "pickerValue" }] : /* istanbul ignore next */ []);
	showTrigger = computed(() => !this.readOnly() && !this.disabled(), ...ngDevMode ? [{ debugName: "showTrigger" }] : /* istanbul ignore next */ []);
	pickerPositions = [{
		originX: "start",
		originY: "bottom",
		overlayX: "start",
		overlayY: "top",
		offsetY: 4
	}, {
		originX: "start",
		originY: "top",
		overlayX: "start",
		overlayY: "bottom",
		offsetY: -4
	}];
	onOverlayKeydown(event) {
		if (event.key !== "Escape") return;
		this.closePicker();
		event.preventDefault();
		event.stopPropagation();
	}
	togglePicker() {
		this.pickerOpen() ? this.closePicker() : this.openPicker();
	}
	openPicker() {
		if (!this.showTrigger()) return;
		this.pickerOpen.set(true);
	}
	closePicker() {
		if (!this.pickerOpen()) return;
		this.pickerOpen.set(false);
		this.textInput()?.nativeElement.focus();
	}
	onPickerAttached() {
		this.picker()?.focusActiveCell();
	}
	onPicked(iso) {
		this.value.set(iso);
		this.rawText.set(null);
		this.parseError.set(false);
		this.onChange(iso);
		this.onTouched();
		this.closePicker();
	}
	onPickerCleared() {
		this.value.set(null);
		this.rawText.set(null);
		this.parseError.set(false);
		this.onChange(null);
		this.onTouched();
		this.closePicker();
	}
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "string" && value !== "" ? value : null);
		this.rawText.set(null);
		this.parseError.set(false);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		this.rawText.set(event.target.value);
		this.parseError.set(false);
	}
	onBlur() {
		const raw = this.rawText();
		if (raw !== null) {
			const trimmed = raw.trim();
			if (trimmed === "") {
				this.value.set(null);
				this.rawText.set(null);
				this.parseError.set(false);
				this.onChange(null);
			} else {
				const parsed = parseShipPeriodDate(trimmed, (/* @__PURE__ */ new Date()).getFullYear());
				if (parsed === null) {
					this.parseError.set(true);
					this.onChange(null);
				} else {
					this.value.set(parsed);
					this.rawText.set(null);
					this.parseError.set(false);
					this.onChange(parsed);
				}
			}
		}
		this.onTouched();
	}
	formatForDisplay(iso) {
		return formatDisplayDate(iso);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DateInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: DateInputComponent,
		isStandalone: true,
		selector: "cms-date-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			requiredMarker: {
				classPropertyName: "requiredMarker",
				publicName: "requiredMarker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plain: {
				classPropertyName: "plain",
				publicName: "plain",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skipTab: {
				classPropertyName: "skipTab",
				publicName: "skipTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => DateInputComponent),
			multi: true
		}],
		viewQueries: [{
			propertyName: "textInput",
			first: true,
			predicate: ["textInput"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "picker",
			first: true,
			predicate: DatePickerComponent,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"effectiveError()\"\n  [hint]=\"warningText()\"\n>\n\n  <!--\n    🔴 `relative` so the trigger can sit inside the input's right edge, and `cdkOverlayOrigin` so the\n    popover attaches to the FIELD rather than to the button — a panel anchored to a 28px button\n    drifts left of the control it belongs to.\n  -->\n  <div class=\"cws:relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n    <!--\n      `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n      control. The same id, so the label above still names it. See `FieldValueComponent`.\n\n      ⚠ INSIDE the overlay origin, not around it: the picker overlay below the field refers to\n      `#origin`, and a reference declared inside an `@else` is not visible outside it.\n    -->\n    @if (display()) {\n      <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n    } @else {\n    <!--\n      type=\"text\", not type=\"date\". A native date input imposes its own picker and rejects the\n      MMDDYYYY / MMDDYY shapes BR-020 requires, which is precisely the green-screen entry speed\n      02a §1.1 exists to preserve. The calendar below is ours, for the same reason: the browser's\n      is unstyleable, differs per engine, and shows a locale-driven display form.\n    -->\n    <input\n      #textInput\n      class=\"scoular-form-input\"\n      [class]=\"plain() ? plainClass : ''\"\n      [attr.placeholder]=\"plain() ? emptyText : 'MM/DD/YYYY'\"\n      [class.error]=\"effectiveError() !== null\"\n      [class.cws:border-scoular-yellow]=\"borderWarning() && effectiveError() === null\"\n      [class.cws:pr-9]=\"showTrigger()\"\n      [id]=\"controlId()\"\n      type=\"text\"\n      inputmode=\"numeric\"\n      autocomplete=\"off\"\n      [value]=\"displayValue()\"\n      [readOnly]=\"readOnly()\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [disabled]=\"disabled()\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"effectiveError() !== null ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"warningText()\"\n      [attr.data-cws-lookup]=\"showTrigger() ? '' : null\"\n      (input)=\"onInput($event)\"\n      (blur)=\"onBlur()\"\n      (cws-open-lookup)=\"openPicker()\"\n    />\n\n    @if (showTrigger()) {\n      <!--\n        ⚠ **No trigger at all on a read-only or disabled field**, rather than a disabled one. A\n        greyed calendar button invites a click that can never do anything; its absence says the\n        field is not editable, which is the truth.\n\n        `type=\"button\"` so it cannot submit the form it sits in.\n      -->\n      <button\n        type=\"button\"\n        class=\"cws:absolute cws:top-1/2 cws:right-2 cws:flex cws:h-7 cws:w-7 cws:-translate-y-1/2 cws:items-center cws:justify-center cws:rounded cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-200\"\n        aria-label=\"Choose date\"\n        aria-haspopup=\"dialog\"\n        [attr.aria-expanded]=\"pickerOpen()\"\n        [attr.aria-controls]=\"controlId() + '-picker'\"\n        (click)=\"togglePicker()\"\n      >\n        <!-- An inline SVG rather than a glyph: a text calendar character renders differently per font. -->\n        <svg\n          aria-hidden=\"true\"\n          class=\"cws:h-4 cws:w-4\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.6\"\n        >\n          <rect x=\"3\" y=\"4.5\" width=\"14\" height=\"12\" rx=\"2\" />\n          <path d=\"M3 8.5h14M7 3v3M13 3v3\" />\n        </svg>\n      </button>\n    }\n    }\n  </div>\n</cms-field>\n\n<!--\n  🔴 CDK overlay rather than an absolutely-positioned panel, and rather than the repo's own\n  `cmsDropdown` directive.\n\n  `cmsDropdown` gives dismissal and Escape handling and is used by five other panels, but it cannot\n  be used here: a CDK panel renders in a container appended to `<body>`, so the directive's\n  outside-click test — \"is the click inside my host element?\" — is false for every click INSIDE the\n  popover, and the calendar would close on its own first day cell.\n\n  What CDK buys that neither `cmsDropdown` nor CSS can: the panel **flips above the field** when\n  there is no room below, which for a date field near the foot of a long form is the difference\n  between a usable control and one whose footer is off-screen. `reposition` keeps it attached while\n  the page scrolls instead of leaving it behind.\n\n  ⚠ `(overlayKeydown)` handles Escape here rather than a document listener, and deliberately calls\n  `preventDefault`: the contract record screen uses Escape to navigate back to the grid, so an\n  Escape spent closing this popover must not also leave the record. That is the same reasoning\n  `cmsDropdown` carries, reproduced because the directive itself could not be.\n-->\n<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"origin\"\n  [cdkConnectedOverlayOpen]=\"pickerOpen()\"\n  [cdkConnectedOverlayPositions]=\"pickerPositions\"\n  [cdkConnectedOverlayScrollStrategy]=\"pickerScroll\"\n  (attach)=\"onPickerAttached()\"\n  (overlayOutsideClick)=\"closePicker()\"\n  (detach)=\"closePicker()\"\n>\n  <!--\n    ⚠ Focus is trapped while the popover is open, and `cdkTrapFocusAutoCapture` is deliberately NOT\n    set: the picker puts focus on the active day cell itself once attached, and letting the trap\n    capture first would land focus on the header's previous-month chevron instead.\n  -->\n  <div cdkTrapFocus [id]=\"controlId() + '-picker'\" (keydown)=\"onOverlayKeydown($event)\">\n    <cms-date-picker\n      [value]=\"pickerValue()\"\n      [required]=\"showsRequired()\"\n      (dateSelected)=\"onPicked($event)\"\n      (cleared)=\"onPickerCleared()\"\n      (dismissed)=\"closePicker()\"\n    />\n  </div>\n</ng-template>\n",
		dependencies: [
			{
				kind: "directive",
				type: CdkConnectedOverlay,
				selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]",
				inputs: [
					"cdkConnectedOverlayOrigin",
					"cdkConnectedOverlayPositions",
					"cdkConnectedOverlayPositionStrategy",
					"cdkConnectedOverlayOffsetX",
					"cdkConnectedOverlayOffsetY",
					"cdkConnectedOverlayWidth",
					"cdkConnectedOverlayHeight",
					"cdkConnectedOverlayMinWidth",
					"cdkConnectedOverlayMinHeight",
					"cdkConnectedOverlayBackdropClass",
					"cdkConnectedOverlayPanelClass",
					"cdkConnectedOverlayViewportMargin",
					"cdkConnectedOverlayScrollStrategy",
					"cdkConnectedOverlayOpen",
					"cdkConnectedOverlayDisableClose",
					"cdkConnectedOverlayTransformOriginOn",
					"cdkConnectedOverlayHasBackdrop",
					"cdkConnectedOverlayLockPosition",
					"cdkConnectedOverlayFlexibleDimensions",
					"cdkConnectedOverlayGrowAfterOpen",
					"cdkConnectedOverlayPush",
					"cdkConnectedOverlayDisposeOnNavigation",
					"cdkConnectedOverlayUsePopover",
					"cdkConnectedOverlayMatchWidth",
					"cdkConnectedOverlay"
				],
				outputs: [
					"backdropClick",
					"positionChange",
					"attach",
					"detach",
					"overlayKeydown",
					"overlayOutsideClick"
				],
				exportAs: ["cdkConnectedOverlay"]
			},
			{
				kind: "directive",
				type: CdkOverlayOrigin,
				selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]",
				exportAs: ["cdkOverlayOrigin"]
			},
			{
				kind: "directive",
				type: CdkTrapFocus,
				selector: "[cdkTrapFocus]",
				inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"],
				exportAs: ["cdkTrapFocus"]
			},
			{
				kind: "component",
				type: DatePickerComponent,
				selector: "cms-date-picker",
				inputs: [
					"value",
					"required",
					"today"
				],
				outputs: [
					"dateSelected",
					"cleared",
					"dismissed"
				]
			},
			{
				kind: "component",
				type: FieldComponent,
				selector: "cms-field",
				inputs: [
					"label",
					"controlId",
					"required",
					"hideLabel",
					"errorMessage",
					"hint",
					"labelFor",
					"help",
					"marker",
					"display"
				]
			},
			{
				kind: "component",
				type: FieldValueComponent,
				selector: "cms-field-value",
				inputs: [
					"controlId",
					"text",
					"multiline"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DateInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-date-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				CdkConnectedOverlay,
				CdkOverlayOrigin,
				CdkTrapFocus,
				DatePickerComponent,
				FieldComponent,
				FieldValueComponent
			],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => DateInputComponent),
				multi: true
			}],
			template: "<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"effectiveError()\"\n  [hint]=\"warningText()\"\n>\n\n  <!--\n    🔴 `relative` so the trigger can sit inside the input's right edge, and `cdkOverlayOrigin` so the\n    popover attaches to the FIELD rather than to the button — a panel anchored to a 28px button\n    drifts left of the control it belongs to.\n  -->\n  <div class=\"cws:relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\n    <!--\n      `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n      control. The same id, so the label above still names it. See `FieldValueComponent`.\n\n      ⚠ INSIDE the overlay origin, not around it: the picker overlay below the field refers to\n      `#origin`, and a reference declared inside an `@else` is not visible outside it.\n    -->\n    @if (display()) {\n      <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n    } @else {\n    <!--\n      type=\"text\", not type=\"date\". A native date input imposes its own picker and rejects the\n      MMDDYYYY / MMDDYY shapes BR-020 requires, which is precisely the green-screen entry speed\n      02a §1.1 exists to preserve. The calendar below is ours, for the same reason: the browser's\n      is unstyleable, differs per engine, and shows a locale-driven display form.\n    -->\n    <input\n      #textInput\n      class=\"scoular-form-input\"\n      [class]=\"plain() ? plainClass : ''\"\n      [attr.placeholder]=\"plain() ? emptyText : 'MM/DD/YYYY'\"\n      [class.error]=\"effectiveError() !== null\"\n      [class.cws:border-scoular-yellow]=\"borderWarning() && effectiveError() === null\"\n      [class.cws:pr-9]=\"showTrigger()\"\n      [id]=\"controlId()\"\n      type=\"text\"\n      inputmode=\"numeric\"\n      autocomplete=\"off\"\n      [value]=\"displayValue()\"\n      [readOnly]=\"readOnly()\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [disabled]=\"disabled()\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"effectiveError() !== null ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"warningText()\"\n      [attr.data-cws-lookup]=\"showTrigger() ? '' : null\"\n      (input)=\"onInput($event)\"\n      (blur)=\"onBlur()\"\n      (cws-open-lookup)=\"openPicker()\"\n    />\n\n    @if (showTrigger()) {\n      <!--\n        ⚠ **No trigger at all on a read-only or disabled field**, rather than a disabled one. A\n        greyed calendar button invites a click that can never do anything; its absence says the\n        field is not editable, which is the truth.\n\n        `type=\"button\"` so it cannot submit the form it sits in.\n      -->\n      <button\n        type=\"button\"\n        class=\"cws:absolute cws:top-1/2 cws:right-2 cws:flex cws:h-7 cws:w-7 cws:-translate-y-1/2 cws:items-center cws:justify-center cws:rounded cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-200\"\n        aria-label=\"Choose date\"\n        aria-haspopup=\"dialog\"\n        [attr.aria-expanded]=\"pickerOpen()\"\n        [attr.aria-controls]=\"controlId() + '-picker'\"\n        (click)=\"togglePicker()\"\n      >\n        <!-- An inline SVG rather than a glyph: a text calendar character renders differently per font. -->\n        <svg\n          aria-hidden=\"true\"\n          class=\"cws:h-4 cws:w-4\"\n          viewBox=\"0 0 20 20\"\n          fill=\"none\"\n          stroke=\"currentColor\"\n          stroke-width=\"1.6\"\n        >\n          <rect x=\"3\" y=\"4.5\" width=\"14\" height=\"12\" rx=\"2\" />\n          <path d=\"M3 8.5h14M7 3v3M13 3v3\" />\n        </svg>\n      </button>\n    }\n    }\n  </div>\n</cms-field>\n\n<!--\n  🔴 CDK overlay rather than an absolutely-positioned panel, and rather than the repo's own\n  `cmsDropdown` directive.\n\n  `cmsDropdown` gives dismissal and Escape handling and is used by five other panels, but it cannot\n  be used here: a CDK panel renders in a container appended to `<body>`, so the directive's\n  outside-click test — \"is the click inside my host element?\" — is false for every click INSIDE the\n  popover, and the calendar would close on its own first day cell.\n\n  What CDK buys that neither `cmsDropdown` nor CSS can: the panel **flips above the field** when\n  there is no room below, which for a date field near the foot of a long form is the difference\n  between a usable control and one whose footer is off-screen. `reposition` keeps it attached while\n  the page scrolls instead of leaving it behind.\n\n  ⚠ `(overlayKeydown)` handles Escape here rather than a document listener, and deliberately calls\n  `preventDefault`: the contract record screen uses Escape to navigate back to the grid, so an\n  Escape spent closing this popover must not also leave the record. That is the same reasoning\n  `cmsDropdown` carries, reproduced because the directive itself could not be.\n-->\n<ng-template\n  cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"origin\"\n  [cdkConnectedOverlayOpen]=\"pickerOpen()\"\n  [cdkConnectedOverlayPositions]=\"pickerPositions\"\n  [cdkConnectedOverlayScrollStrategy]=\"pickerScroll\"\n  (attach)=\"onPickerAttached()\"\n  (overlayOutsideClick)=\"closePicker()\"\n  (detach)=\"closePicker()\"\n>\n  <!--\n    ⚠ Focus is trapped while the popover is open, and `cdkTrapFocusAutoCapture` is deliberately NOT\n    set: the picker puts focus on the active day cell itself once attached, and letting the trap\n    capture first would land focus on the header's previous-month chevron instead.\n  -->\n  <div cdkTrapFocus [id]=\"controlId() + '-picker'\" (keydown)=\"onOverlayKeydown($event)\">\n    <cms-date-picker\n      [value]=\"pickerValue()\"\n      [required]=\"showsRequired()\"\n      (dateSelected)=\"onPicked($event)\"\n      (cleared)=\"onPickerCleared()\"\n      (dismissed)=\"closePicker()\"\n    />\n  </div>\n</ng-template>\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		requiredMarker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "requiredMarker",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		plain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		skipTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skipTab",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		textInput: [{
			type: i0.ViewChild,
			args: ["textInput", { isSignal: true }]
		}],
		picker: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => DatePickerComponent), { isSignal: true }]
		}]
	}
});
var NoteInputComponent = class NoteInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	maxLength = input.required(...ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []);
	rows = input(3, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	requiredMarker = input(false, ...ngDevMode ? [{ debugName: "requiredMarker" }] : /* istanbul ignore next */ []);
	showsRequired = computed(() => this.required() || this.requiredMarker(), ...ngDevMode ? [{ debugName: "showsRequired" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	plain = input(false, ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	displayText = computed(() => this.value(), ...ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []);
	plainClass = PLAIN_VALUE_CLASS;
	emptyText = "—";
	skipTab = input(false, ...ngDevMode ? [{ debugName: "skipTab" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = signal("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	remaining = computed(() => {
		const max = this.maxLength();
		return max === null ? null : max - this.value().length;
	}, ...ngDevMode ? [{ debugName: "remaining" }] : /* istanbul ignore next */ []);
	nearLimit = computed(() => {
		const max = this.maxLength();
		const remaining = this.remaining();
		if (max === null || remaining === null) return false;
		return remaining <= Math.max(5, Math.floor(max * .1));
	}, ...ngDevMode ? [{ debugName: "nearLimit" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		const ids = [`${this.controlId()}-counter`];
		if (this.errorMessage()) ids.push(`${this.controlId()}-error`);
		else if (this.warningText()) ids.push(`${this.controlId()}-hint`);
		return ids.join(" ");
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "string" ? this.clamp(value) : "");
	}
	clamp(value) {
		const max = this.maxLength();
		return max === null ? value : value.slice(0, max);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		const element = event.target;
		const clamped = this.clamp(element.value);
		if (element.value !== clamped) element.value = clamped;
		this.value.set(clamped);
		this.onChange(clamped === "" ? null : clamped);
	}
	onBlur() {
		this.onTouched();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NoteInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NoteInputComponent,
		isStandalone: true,
		selector: "cms-note-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			maxLength: {
				classPropertyName: "maxLength",
				publicName: "maxLength",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			requiredMarker: {
				classPropertyName: "requiredMarker",
				publicName: "requiredMarker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plain: {
				classPropertyName: "plain",
				publicName: "plain",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skipTab: {
				classPropertyName: "skipTab",
				publicName: "skipTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => NoteInputComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<!-- Label row, required marker and the error/hint line come from `cms-field` (2026-09-16). -->\n<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n  <ng-container cmsFieldAside>\n    <!-- Hidden when read-only, for the reason `text-input` records: the count answers a question a\n         read-only field cannot raise, and it was the loudest thing on the record screen. -->\n    @if (!readOnly()) {\n      <span\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\n        [class.cws:text-slate-500]=\"!nearLimit()\"\n        [class.cws:dark:text-slate-400]=\"!nearLimit()\"\n        [class.cws:text-amber-700]=\"nearLimit()\"\n        [class.cws:dark:text-amber-400]=\"nearLimit()\"\n        [id]=\"controlId() + '-counter'\"\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\n        >{{ remaining() === null ? 'No known limit' : remaining() + ' left' }}</span\n      >\n    }\n  </ng-container>\n\n  <!--\n    field-sizing:content grows the textarea with its content where the browser supports it, with\n    the rows attribute as both the floor and the fallback. No scroll-height measurement and no\n    resize observer — a lot of machinery to avoid a scrollbar.\n\n    As a `plain` value the floor drops to one line and the design system's 100px minimum goes, so the\n    text reads as a paragraph that is exactly as tall as what it says, wrapped, with its own line\n    breaks kept. An empty note is the quiet dash, never an empty box.\n  -->\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" [multiline]=\"true\" />\n  } @else {\n  <textarea\n    class=\"scoular-form-textarea cws:[field-sizing:content]\"\n    [class]=\"plain() ? plainClass + ' cws:min-h-0! cws:resize-none!' : ''\"\n    [attr.placeholder]=\"plain() ? emptyText : null\"\n    [class.error]=\"errorMessage() !== null\"\n    [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\n    [id]=\"controlId()\"\n    [rows]=\"plain() ? 1 : rows()\"\n    [value]=\"value()\"\n    [attr.maxlength]=\"maxLength()\"\n    [readOnly]=\"readOnly()\"\n    [attr.tabindex]=\"skipTab() ? -1 : null\"\n    [disabled]=\"disabled()\"\n    [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n    [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.title]=\"warningText()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  ></textarea>\n  }\n</cms-field>\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor",
				"help",
				"marker",
				"display"
			]
		}, {
			kind: "component",
			type: FieldValueComponent,
			selector: "cms-field-value",
			inputs: [
				"controlId",
				"text",
				"multiline"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NoteInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-note-input",
			imports: [FieldComponent, FieldValueComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NoteInputComponent),
				multi: true
			}],
			template: "<!-- Label row, required marker and the error/hint line come from `cms-field` (2026-09-16). -->\n<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n  <ng-container cmsFieldAside>\n    <!-- Hidden when read-only, for the reason `text-input` records: the count answers a question a\n         read-only field cannot raise, and it was the loudest thing on the record screen. -->\n    @if (!readOnly()) {\n      <span\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\n        [class.cws:text-slate-500]=\"!nearLimit()\"\n        [class.cws:dark:text-slate-400]=\"!nearLimit()\"\n        [class.cws:text-amber-700]=\"nearLimit()\"\n        [class.cws:dark:text-amber-400]=\"nearLimit()\"\n        [id]=\"controlId() + '-counter'\"\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\n        >{{ remaining() === null ? 'No known limit' : remaining() + ' left' }}</span\n      >\n    }\n  </ng-container>\n\n  <!--\n    field-sizing:content grows the textarea with its content where the browser supports it, with\n    the rows attribute as both the floor and the fallback. No scroll-height measurement and no\n    resize observer — a lot of machinery to avoid a scrollbar.\n\n    As a `plain` value the floor drops to one line and the design system's 100px minimum goes, so the\n    text reads as a paragraph that is exactly as tall as what it says, wrapped, with its own line\n    breaks kept. An empty note is the quiet dash, never an empty box.\n  -->\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" [multiline]=\"true\" />\n  } @else {\n  <textarea\n    class=\"scoular-form-textarea cws:[field-sizing:content]\"\n    [class]=\"plain() ? plainClass + ' cws:min-h-0! cws:resize-none!' : ''\"\n    [attr.placeholder]=\"plain() ? emptyText : null\"\n    [class.error]=\"errorMessage() !== null\"\n    [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\n    [id]=\"controlId()\"\n    [rows]=\"plain() ? 1 : rows()\"\n    [value]=\"value()\"\n    [attr.maxlength]=\"maxLength()\"\n    [readOnly]=\"readOnly()\"\n    [attr.tabindex]=\"skipTab() ? -1 : null\"\n    [disabled]=\"disabled()\"\n    [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n    [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy()\"\n    [attr.title]=\"warningText()\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onBlur()\"\n  ></textarea>\n  }\n</cms-field>\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		maxLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLength",
				required: true
			}]
		}],
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		requiredMarker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "requiredMarker",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		plain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		skipTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skipTab",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}]
	}
});
var ToggleComponent = class ToggleComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	onLabel = input("Yes", ...ngDevMode ? [{ debugName: "onLabel" }] : /* istanbul ignore next */ []);
	offLabel = input("No", ...ngDevMode ? [{ debugName: "offLabel" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	requiredMarker = input(false, ...ngDevMode ? [{ debugName: "requiredMarker" }] : /* istanbul ignore next */ []);
	showsRequired = computed(() => this.required() || this.requiredMarker(), ...ngDevMode ? [{ debugName: "showsRequired" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	plain = input(false, ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	displayText = computed(() => this.stateLabel(), ...ngDevMode ? [{ debugName: "displayText" }] : /* istanbul ignore next */ []);
	plainClass = PLAIN_VALUE_CLASS;
	emptyText = "—";
	skipTab = input(false, ...ngDevMode ? [{ debugName: "skipTab" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	checked = signal(false, ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	stateLabel = computed(() => this.checked() ? this.onLabel() : this.offLabel(), ...ngDevMode ? [{ debugName: "stateLabel" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		if (this.errorMessage()) return `${this.controlId()}-error`;
		return this.warningText() ? `${this.controlId()}-hint` : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.checked.set(value === true);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	toggle() {
		if (this.readOnly() || this.disabled()) return;
		const next = !this.checked();
		this.checked.set(next);
		this.onChange(next);
		this.onTouched();
	}
	onKeydown(event) {
		if (event.key === " " || event.key === "Enter") {
			event.preventDefault();
			this.toggle();
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ToggleComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ToggleComponent,
		isStandalone: true,
		selector: "cms-toggle",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			onLabel: {
				classPropertyName: "onLabel",
				publicName: "onLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offLabel: {
				classPropertyName: "offLabel",
				publicName: "offLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			requiredMarker: {
				classPropertyName: "requiredMarker",
				publicName: "requiredMarker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			plain: {
				classPropertyName: "plain",
				publicName: "plain",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skipTab: {
				classPropertyName: "skipTab",
				publicName: "skipTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => ToggleComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<!--\n  Label row, required marker and the error/hint line come from `cms-field` (2026-09-16).\n\n  🔴 `[labelFor]=\"false\"` is the whole reason that input exists. `role=\"switch\"` is a button, and a\n  <label for> pointing at a button is not an accessible-name association — so the heading has to be a\n  <span> with an id that the button's `aria-labelledby` points at. Flipping this to the default would\n  leave the control looking perfectly labelled and unnamed to a screen reader.\n-->\n<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [labelFor]=\"false\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <div class=\"cws:flex cws:items-center cws:gap-3\">\n    <!--\n      The inactive look for `readOnly` — the record screen's view mode.\n\n      Tailwind utilities work here, unlike on the text controls: every class on this button is already a\n      utility, so there is no unlayered design-system declaration to lose to. The text controls carry\n      `scoular-form-input`, whose `bg-white` is unlayered and therefore beats any utility — their\n      inactive styling has to live in the shell's `styles.css` for that reason. See the note there.\n\n      `!cursor-default` carries the important flag because the base class list sets `cursor-pointer`,\n      and between two utilities in the same layer Tailwind's own ordering decides — not source order.\n      Not `not-allowed`: the switch keeps its place in the tab sequence and stays readable, which is\n      what `readOnly` means here — `toggle()` returns early rather than the button being disabled.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <!--\n      `plain` (2026-10-13): the same switch, drawn as the word Yes or No. A read-only switch is a value,\n      not a control, and a dimmed track read as a broken one. The button is kept, not swapped for text,\n      so it keeps `role=\"switch\"`, `aria-checked`, its name and its place in the tab sequence.\n    -->\n    <button\n      class=\"cws:relative cws:inline-flex cws:shrink-0 cws:cursor-pointer cws:border-2 cws:border-transparent cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:focus-visible:ring-offset-2 cws:disabled:cursor-not-allowed cws:disabled:opacity-50\"\n      [class]=\"plain() ? 'cws:rounded-sm cws:py-1.5 cws:text-sm cws:text-slate-900 cws:dark:text-slate-100' : 'cws:h-6 cws:w-11 cws:rounded-full'\"\n      [class.cws:bg-scoular-blue]=\"checked() && !plain()\"\n      [class.cws:bg-slate-300]=\"!checked() && !plain()\"\n      [class.cws:dark:bg-slate-600]=\"!checked() && !plain()\"\n      [class.cws:ring-2]=\"borderWarning() && errorMessage() === null\"\n      [class.cws:ring-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\n      [class.cws:ring-scoular-red]=\"errorMessage() !== null\"\n      [class.cws:opacity-70]=\"readOnly() && !disabled() && !plain()\"\n      [class.cws:!cursor-default]=\"readOnly()\"\n      [id]=\"controlId()\"\n      type=\"button\"\n      role=\"switch\"\n      [attr.aria-checked]=\"checked()\"\n      [attr.aria-labelledby]=\"controlId() + '-label'\"\n      [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"warningText()\"\n      [disabled]=\"disabled()\"\n      (click)=\"toggle()\"\n      (keydown)=\"onKeydown($event)\"\n    >\n      @if (plain()) {\n        <span aria-hidden=\"true\">{{ stateLabel() }}</span>\n      } @else {\n        <!-- Decorative: the state is already conveyed by aria-checked and the visible text label. -->\n        <span\n          class=\"cws:pointer-events-none cws:inline-block cws:h-5 cws:w-5 cws:transform cws:rounded-full cws:bg-white cws:shadow cws:ring-0 cws:transition-transform\"\n          [class.cws:translate-x-5]=\"checked()\"\n          [class.cws:translate-x-0]=\"!checked()\"\n          aria-hidden=\"true\"\n        ></span>\n      }\n    </button>\n\n    @if (!plain()) {\n      <!-- 02a C9: an explicit Yes/No label, never the switch position alone. -->\n      <span class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" aria-hidden=\"true\">{{\n        stateLabel()\n      }}</span>\n    }\n  </div>\n  }\n</cms-field>\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor",
				"help",
				"marker",
				"display"
			]
		}, {
			kind: "component",
			type: FieldValueComponent,
			selector: "cms-field-value",
			inputs: [
				"controlId",
				"text",
				"multiline"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ToggleComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-toggle",
			imports: [FieldComponent, FieldValueComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => ToggleComponent),
				multi: true
			}],
			template: "<!--\n  Label row, required marker and the error/hint line come from `cms-field` (2026-09-16).\n\n  🔴 `[labelFor]=\"false\"` is the whole reason that input exists. `role=\"switch\"` is a button, and a\n  <label for> pointing at a button is not an accessible-name association — so the heading has to be a\n  <span> with an id that the button's `aria-labelledby` points at. Flipping this to the default would\n  leave the control looking perfectly labelled and unnamed to a screen reader.\n-->\n<cms-field\n  [label]=\"label()\"\n  [controlId]=\"controlId()\"\n  [required]=\"showsRequired()\"\n  [hideLabel]=\"hideLabel()\"\n  [labelFor]=\"false\"\n  [help]=\"help()\"\n  [marker]=\"marker()\"\n  [display]=\"display()\"\n  [errorMessage]=\"errorMessage()\"\n  [hint]=\"warningText()\"\n>\n  <!--\n    `display`: the value as text on the record screen's details sheet (2026-10-13), in place of the\n    control. The same id, so the label above still names it. See `FieldValueComponent`.\n  -->\n  @if (display()) {\n    <cms-field-value [controlId]=\"controlId()\" [text]=\"displayText()\" />\n  } @else {\n  <div class=\"cws:flex cws:items-center cws:gap-3\">\n    <!--\n      The inactive look for `readOnly` — the record screen's view mode.\n\n      Tailwind utilities work here, unlike on the text controls: every class on this button is already a\n      utility, so there is no unlayered design-system declaration to lose to. The text controls carry\n      `scoular-form-input`, whose `bg-white` is unlayered and therefore beats any utility — their\n      inactive styling has to live in the shell's `styles.css` for that reason. See the note there.\n\n      `!cursor-default` carries the important flag because the base class list sets `cursor-pointer`,\n      and between two utilities in the same layer Tailwind's own ordering decides — not source order.\n      Not `not-allowed`: the switch keeps its place in the tab sequence and stays readable, which is\n      what `readOnly` means here — `toggle()` returns early rather than the button being disabled.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <!--\n      `plain` (2026-10-13): the same switch, drawn as the word Yes or No. A read-only switch is a value,\n      not a control, and a dimmed track read as a broken one. The button is kept, not swapped for text,\n      so it keeps `role=\"switch\"`, `aria-checked`, its name and its place in the tab sequence.\n    -->\n    <button\n      class=\"cws:relative cws:inline-flex cws:shrink-0 cws:cursor-pointer cws:border-2 cws:border-transparent cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:focus-visible:ring-offset-2 cws:disabled:cursor-not-allowed cws:disabled:opacity-50\"\n      [class]=\"plain() ? 'cws:rounded-sm cws:py-1.5 cws:text-sm cws:text-slate-900 cws:dark:text-slate-100' : 'cws:h-6 cws:w-11 cws:rounded-full'\"\n      [class.cws:bg-scoular-blue]=\"checked() && !plain()\"\n      [class.cws:bg-slate-300]=\"!checked() && !plain()\"\n      [class.cws:dark:bg-slate-600]=\"!checked() && !plain()\"\n      [class.cws:ring-2]=\"borderWarning() && errorMessage() === null\"\n      [class.cws:ring-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\n      [class.cws:ring-scoular-red]=\"errorMessage() !== null\"\n      [class.cws:opacity-70]=\"readOnly() && !disabled() && !plain()\"\n      [class.cws:!cursor-default]=\"readOnly()\"\n      [id]=\"controlId()\"\n      type=\"button\"\n      role=\"switch\"\n      [attr.aria-checked]=\"checked()\"\n      [attr.aria-labelledby]=\"controlId() + '-label'\"\n      [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\n      [attr.tabindex]=\"skipTab() ? -1 : null\"\n      [attr.aria-required]=\"showsRequired() ? 'true' : null\"\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy()\"\n      [attr.title]=\"warningText()\"\n      [disabled]=\"disabled()\"\n      (click)=\"toggle()\"\n      (keydown)=\"onKeydown($event)\"\n    >\n      @if (plain()) {\n        <span aria-hidden=\"true\">{{ stateLabel() }}</span>\n      } @else {\n        <!-- Decorative: the state is already conveyed by aria-checked and the visible text label. -->\n        <span\n          class=\"cws:pointer-events-none cws:inline-block cws:h-5 cws:w-5 cws:transform cws:rounded-full cws:bg-white cws:shadow cws:ring-0 cws:transition-transform\"\n          [class.cws:translate-x-5]=\"checked()\"\n          [class.cws:translate-x-0]=\"!checked()\"\n          aria-hidden=\"true\"\n        ></span>\n      }\n    </button>\n\n    @if (!plain()) {\n      <!-- 02a C9: an explicit Yes/No label, never the switch position alone. -->\n      <span class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" aria-hidden=\"true\">{{\n        stateLabel()\n      }}</span>\n    }\n  </div>\n  }\n</cms-field>\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		onLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "onLabel",
				required: false
			}]
		}],
		offLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offLabel",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		requiredMarker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "requiredMarker",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		plain: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "plain",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		skipTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skipTab",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}]
	}
});
function sameSortChain(left, right) {
	return left.length === right.length && left.every((sort, index) => sort.key === right[index].key && sort.direction === right[index].direction);
}
const DEFAULT_COLUMN_WIDTH = 140;
const MIN_COLUMN_WIDTH = 56;
const priorityColumnKeys = (columns) => columns.filter((column) => (column.priority ?? 1) <= 1).map((column) => column.key);
const flipDirection = (direction) => direction === "asc" ? "desc" : "asc";
function compareRows(column, left, right, direction) {
	const key = column.sortValue ?? column.format;
	const a = key(left);
	const b = key(right);
	const sign = direction === "asc" ? 1 : -1;
	if (typeof a === "number" && typeof b === "number") return (a - b) * sign;
	return String(a).localeCompare(String(b)) * sign;
}
function nextSort(current, key) {
	const existing = current.find((sort) => sort.key === key);
	if (!existing) return [...current, {
		key,
		direction: "asc"
	}];
	if (existing.direction === "asc") return current.map((sort) => sort.key === key ? {
		key,
		direction: "desc"
	} : sort);
	return current.filter((sort) => sort.key !== key);
}
function ariaSort(current, key) {
	const existing = current.find((sort) => sort.key === key);
	if (!existing) return "none";
	return existing.direction === "asc" ? "ascending" : "descending";
}
function sortRank(current, key) {
	const index = current.findIndex((sort) => sort.key === key);
	return index === -1 ? null : index + 1;
}
function compareBySorts(columns, sorts, left, right) {
	for (const sort of sorts) {
		const column = columns.find((candidate) => candidate.key === sort.key);
		if (!column) continue;
		const result = compareRows(column, left, right, sort.direction);
		if (result !== 0) return result;
	}
	return 0;
}
const CONDENSED_BELOW_PX = 1300;
const READ_MOSTLY_BELOW_PX = 950;
function layoutBandFor(width) {
	if (width === null || width >= 1300) return "full";
	return width >= 950 ? "condensed" : "read-mostly";
}
function observeLayoutBand(target) {
	const width = signal(null, ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	let observer;
	effect(() => {
		const element = target()?.nativeElement;
		observer?.disconnect();
		if (element === void 0 || typeof ResizeObserver === "undefined") return;
		observer = new ResizeObserver((entries) => width.set(entries[0]?.contentRect.width ?? null));
		observer.observe(element);
	});
	inject(DestroyRef).onDestroy(() => observer?.disconnect());
	return computed(() => layoutBandFor(width()));
}
var RowMenuComponent = class RowMenuComponent {
	row = input.required(...ngDevMode ? [{ debugName: "row" }] : /* istanbul ignore next */ []);
	actions = input.required(...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	refusalFor(action) {
		return actionRefusal(action, this.row());
	}
	isDisabled(action) {
		return isActionUnavailable(action, this.row());
	}
	run(action) {
		if (this.isDisabled(action)) return;
		action.run(this.row());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RowMenuComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: RowMenuComponent,
		isStandalone: true,
		selector: "cms-row-menu",
		inputs: {
			row: {
				classPropertyName: "row",
				publicName: "row",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<!--\n  `(click)` stopped: in the data grid a row is click-to-select and double-click-to-open, and the\n  button must open its menu without also doing either.\n-->\n<button\n  type=\"button\"\n  class=\"scoular-btn scoular-btn-sm scoular-btn-secondary cws:px-2\"\n  aria-haspopup=\"menu\"\n  [attr.aria-label]=\"label()\"\n  [cdkMenuTriggerFor]=\"menu\"\n  (click)=\"$event.stopPropagation()\"\n>\n  <svg aria-hidden=\"true\" viewBox=\"0 0 16 16\" class=\"cws:h-4 cws:w-4\" fill=\"currentColor\">\n    <circle cx=\"3\" cy=\"8\" r=\"1.5\" />\n    <circle cx=\"8\" cy=\"8\" r=\"1.5\" />\n    <circle cx=\"13\" cy=\"8\" r=\"1.5\" />\n  </svg>\n</button>\n\n<!--\n  `cws:static` overrides `scoular-dropdown`'s `absolute` and `mt-2`: in an overlay pane an absolute\n  panel has no size, so the overlay could not measure it to flip it above a row near the bottom.\n-->\n<ng-template #menu>\n  <div cdkMenu class=\"scoular-dropdown cws:static cws:mt-1\" aria-label=\"Row actions\">\n    @for (action of actions(); track action.label) {\n      <!--\n        ⚠ **The access-key letter is rendered, not merely handled.** CTRM's option codes are the\n        precedent, and the study's finding about them is that an unlabelled key is a key nobody\n        learns. `aria-keyshortcuts` carries the same letter for a screen reader, from one source.\n      -->\n      <button\n        type=\"button\"\n        cdkMenuItem\n        class=\"scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0\"\n        [class.cws:cursor-not-allowed]=\"isDisabled(action)\"\n        [class.cws:opacity-60]=\"isDisabled(action)\"\n        [cdkMenuItemDisabled]=\"isDisabled(action)\"\n        [attr.aria-busy]=\"action.busy?.(row()) ? 'true' : null\"\n        [attr.aria-keyshortcuts]=\"action.accessKey ? action.accessKey.toUpperCase() : null\"\n        (cdkMenuItemTriggered)=\"run(action)\"\n      >\n        <span class=\"cws:flex cws:w-full cws:items-center cws:justify-between cws:gap-4\">\n          <span>{{ action.label }}</span>\n          @if (action.accessKey) {\n            <!-- `aria-hidden`: `aria-keyshortcuts` already announces it, and \"Edit E\" reads as a typo. -->\n            <kbd aria-hidden=\"true\" class=\"cws:font-mono cws:text-[10px] cws:uppercase cws:opacity-60\">{{\n              action.accessKey\n            }}</kbd>\n          }\n        </span>\n        @if (refusalFor(action); as reason) {\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ reason }}</span>\n        }\n      </button>\n    }\n  </div>\n</ng-template>\n",
		dependencies: [
			{
				kind: "directive",
				type: CdkMenu,
				selector: "[cdkMenu]",
				outputs: ["closed"],
				exportAs: ["cdkMenu"]
			},
			{
				kind: "directive",
				type: CdkMenuItem,
				selector: "[cdkMenuItem]",
				inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"],
				outputs: ["cdkMenuItemTriggered"],
				exportAs: ["cdkMenuItem"]
			},
			{
				kind: "directive",
				type: CdkMenuTrigger,
				selector: "[cdkMenuTriggerFor]",
				inputs: [
					"cdkMenuTriggerFor",
					"cdkMenuPosition",
					"cdkMenuTriggerData",
					"cdkMenuTriggerTransformOriginOn"
				],
				outputs: ["cdkMenuOpened", "cdkMenuClosed"],
				exportAs: ["cdkMenuTriggerFor"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RowMenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-row-menu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				CdkMenu,
				CdkMenuItem,
				CdkMenuTrigger
			],
			template: "<!--\n  `(click)` stopped: in the data grid a row is click-to-select and double-click-to-open, and the\n  button must open its menu without also doing either.\n-->\n<button\n  type=\"button\"\n  class=\"scoular-btn scoular-btn-sm scoular-btn-secondary cws:px-2\"\n  aria-haspopup=\"menu\"\n  [attr.aria-label]=\"label()\"\n  [cdkMenuTriggerFor]=\"menu\"\n  (click)=\"$event.stopPropagation()\"\n>\n  <svg aria-hidden=\"true\" viewBox=\"0 0 16 16\" class=\"cws:h-4 cws:w-4\" fill=\"currentColor\">\n    <circle cx=\"3\" cy=\"8\" r=\"1.5\" />\n    <circle cx=\"8\" cy=\"8\" r=\"1.5\" />\n    <circle cx=\"13\" cy=\"8\" r=\"1.5\" />\n  </svg>\n</button>\n\n<!--\n  `cws:static` overrides `scoular-dropdown`'s `absolute` and `mt-2`: in an overlay pane an absolute\n  panel has no size, so the overlay could not measure it to flip it above a row near the bottom.\n-->\n<ng-template #menu>\n  <div cdkMenu class=\"scoular-dropdown cws:static cws:mt-1\" aria-label=\"Row actions\">\n    @for (action of actions(); track action.label) {\n      <!--\n        ⚠ **The access-key letter is rendered, not merely handled.** CTRM's option codes are the\n        precedent, and the study's finding about them is that an unlabelled key is a key nobody\n        learns. `aria-keyshortcuts` carries the same letter for a screen reader, from one source.\n      -->\n      <button\n        type=\"button\"\n        cdkMenuItem\n        class=\"scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0\"\n        [class.cws:cursor-not-allowed]=\"isDisabled(action)\"\n        [class.cws:opacity-60]=\"isDisabled(action)\"\n        [cdkMenuItemDisabled]=\"isDisabled(action)\"\n        [attr.aria-busy]=\"action.busy?.(row()) ? 'true' : null\"\n        [attr.aria-keyshortcuts]=\"action.accessKey ? action.accessKey.toUpperCase() : null\"\n        (cdkMenuItemTriggered)=\"run(action)\"\n      >\n        <span class=\"cws:flex cws:w-full cws:items-center cws:justify-between cws:gap-4\">\n          <span>{{ action.label }}</span>\n          @if (action.accessKey) {\n            <!-- `aria-hidden`: `aria-keyshortcuts` already announces it, and \"Edit E\" reads as a typo. -->\n            <kbd aria-hidden=\"true\" class=\"cws:font-mono cws:text-[10px] cws:uppercase cws:opacity-60\">{{\n              action.accessKey\n            }}</kbd>\n          }\n        </span>\n        @if (refusalFor(action); as reason) {\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ reason }}</span>\n        }\n      </button>\n    }\n  </div>\n</ng-template>\n"
		}]
	}],
	propDecorators: {
		row: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "row",
				required: true
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}]
	}
});
function actionRefusal(action, row) {
	const refusal = action.disabled?.(row) ?? false;
	return refusal === false ? null : refusal;
}
function isActionUnavailable(action, row) {
	return actionRefusal(action, row) !== null || (action.busy?.(row) ?? false);
}
const GRID_COLUMN_STORE = new InjectionToken("GRID_COLUMN_STORE");
var BrowserGridColumnStore = class {
	owner;
	constructor(owner) {
		this.owner = owner;
	}
	read(key) {
		const storageKey = this.storageKey(key);
		if (storageKey === null) return null;
		try {
			const stored = localStorage.getItem(storageKey);
			const parsed = stored === null ? null : JSON.parse(stored);
			return Array.isArray(parsed) && parsed.every((entry) => typeof entry === "string") ? parsed : null;
		} catch {
			return null;
		}
	}
	write(key, columns) {
		const storageKey = this.storageKey(key);
		if (storageKey === null) return "failed";
		try {
			if (columns === null) localStorage.removeItem(storageKey);
			else localStorage.setItem(storageKey, JSON.stringify(columns));
			return "browser";
		} catch {
			return "failed";
		}
	}
	storageKey(key) {
		const owner = this.owner();
		return owner === null || owner === "" ? null : `cws.gridColumns.${owner}.grid.${key}`;
	}
};
function savedViewShownKeys(allowed, layout) {
	const allowedSet = new Set(allowed);
	const hidden = new Set(layout.hidden);
	const mentioned = /* @__PURE__ */ new Set([...layout.order, ...layout.hidden]);
	return [...layout.order.filter((key) => allowedSet.has(key) && !hidden.has(key)), ...allowed.filter((key) => !mentioned.has(key))];
}
function savedViewColumnsOf(fields) {
	return {
		order: fields.map((field) => field.key),
		hidden: fields.filter((field) => !field.included).map((field) => field.key)
	};
}
const SAVED_FILTER_STORE = new InjectionToken("SAVED_FILTER_STORE");
const SAVED_FILTER_OWNER = new InjectionToken("SAVED_FILTER_OWNER");
const PREFIX = "cws.savedFilters";
var LocalSavedFilterStore = class LocalSavedFilterStore {
	changed = signal(0, ...ngDevMode ? [{ debugName: "changed" }] : /* istanbul ignore next */ []);
	revision = () => this.changed();
	owner = inject(SAVED_FILTER_OWNER, { optional: true }) ?? (() => "shared");
	refusals = inject(StorageRefusals);
	list(scope) {
		return this.read(scope);
	}
	save(scope, name, group, sort, columns) {
		const trimmed = name.trim();
		const existing = this.read(scope);
		const match = existing.find((filter) => filter.name.toLocaleLowerCase() === trimmed.toLocaleLowerCase());
		const saved = {
			id: match?.id ?? `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
			name: trimmed,
			group,
			scope,
			...sort === void 0 ? {} : { sort: [...sort] },
			...columns === void 0 ? {} : { columns: {
				order: [...columns.order],
				hidden: [...columns.hidden]
			} }
		};
		const next = match ? existing.map((filter) => filter.id === match.id ? saved : filter) : [...existing, saved];
		this.write(scope, next);
		return saved;
	}
	remove(scope, id) {
		this.write(scope, this.read(scope).filter((filter) => filter.id !== id));
		if (this.defaultId(scope) === id) this.setDefault(scope, null);
	}
	defaultId(scope) {
		this.changed();
		try {
			const raw = localStorage.getItem(this.defaultKey(scope));
			return raw !== null && this.read(scope).some((filter) => filter.id === raw) ? raw : null;
		} catch {
			return null;
		}
	}
	setDefault(scope, id) {
		try {
			if (id === null) localStorage.removeItem(this.defaultKey(scope));
			else localStorage.setItem(this.defaultKey(scope), id);
		} catch {
			this.refusals.report("saved views");
		}
		this.changed.update((value) => value + 1);
	}
	key(scope) {
		return `${PREFIX}.${this.owner()}.${scope}`;
	}
	defaultKey(scope) {
		return `${this.key(scope)}.default`;
	}
	read(scope) {
		this.changed();
		try {
			const raw = localStorage.getItem(this.key(scope));
			if (raw === null) return [];
			const parsed = JSON.parse(raw);
			return Array.isArray(parsed) ? parsed.filter(isSavedFilter).map(withReadableColumns) : [];
		} catch {
			return [];
		}
	}
	write(scope, filters) {
		try {
			localStorage.setItem(this.key(scope), JSON.stringify(filters));
		} catch {
			this.refusals.report("saved views");
		}
		this.changed.update((value) => value + 1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LocalSavedFilterStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LocalSavedFilterStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LocalSavedFilterStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
function isSavedFilter(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return typeof candidate.id === "string" && typeof candidate.name === "string" && typeof candidate.scope === "string" && typeof candidate.group === "object" && candidate.group !== null && isGroup(candidate.group) && isSort(candidate.sort);
}
function isGroup(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return Array.isArray(candidate.rules) && candidate.rules.every(isNode);
}
function isNode(value) {
	if (typeof value !== "object" || value === null) return false;
	if (typeof value.columnKey !== "string") return isGroup(value);
	const rule = value;
	return typeof rule["id"] === "string" && typeof rule["operator"] === "string" && typeof rule["value"] === "string";
}
function isSort(value) {
	if (value === void 0) return true;
	return Array.isArray(value) && value.every((entry) => typeof entry === "object" && entry !== null && typeof entry.key === "string" && (entry.direction === "asc" || entry.direction === "desc"));
}
function withReadableColumns(saved) {
	if (!("columns" in saved)) return saved;
	const { columns, ...rest } = saved;
	const readable = columnsOf(columns);
	return readable === null ? rest : {
		...rest,
		columns: readable
	};
}
function columnsOf(value) {
	if (typeof value !== "object" || value === null) return null;
	const candidate = value;
	if (!Array.isArray(candidate.order) || !Array.isArray(candidate.hidden)) return null;
	const strings = (keys) => keys.filter((key) => typeof key === "string");
	return {
		order: strings(candidate.order),
		hidden: strings(candidate.hidden)
	};
}
const SAVED_FILTER_SCOPES = {
	contracts: "contracts",
	approvals: "approvals",
	pricing: "pricing",
	pricingApprovals: "pricing-approvals"
};
var GridColumnChoice = class {
	columns;
	key;
	locked;
	store;
	chosen = linkedSignal(() => {
		const key = this.key();
		return key === null || this.store === null ? null : this.store.read(key);
	}, ...ngDevMode ? [{ debugName: "chosen" }] : /* istanbul ignore next */ []);
	session = signal(null, ...ngDevMode ? [{ debugName: "session" }] : /* istanbul ignore next */ []);
	effective = computed(() => this.session() ?? this.chosen(), ...ngDevMode ? [{ debugName: "effective" }] : /* istanbul ignore next */ []);
	keptIn = signal(null, ...ngDevMode ? [{ debugName: "keptIn" }] : /* istanbul ignore next */ []);
	failure = computed(() => this.keptIn() === "failed" ? {
		correlationId: null,
		sent: false
	} : null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	shown = computed(() => {
		const columns = this.columns();
		const chosen = this.effective();
		if (chosen === null) return columns;
		const byKey = new Map(columns.map((column) => [column.key, column]));
		const locked = this.locked();
		const shown = [...columns.filter((column) => locked.includes(column.key) && !chosen.includes(column.key)).map((column) => column.key), ...chosen].map((key) => byKey.get(key)).filter((column) => column !== void 0);
		return shown.length === 0 ? columns : shown;
	}, ...ngDevMode ? [{ debugName: "shown" }] : /* istanbul ignore next */ []);
	shownKeys = computed(() => this.shown().map((column) => column.key), ...ngDevMode ? [{ debugName: "shownKeys" }] : /* istanbul ignore next */ []);
	fields = computed(() => {
		const shown = this.shown();
		const shownKeys = new Set(shown.map((column) => column.key));
		return [...shown.map((column) => ({
			key: column.key,
			header: column.header,
			included: true
		})), ...this.columns().filter((column) => !shownKeys.has(column.key)).map((column) => ({
			key: column.key,
			header: column.header,
			included: false
		}))];
	}, ...ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []);
	constructor(columns, key, locked, store) {
		this.columns = columns;
		this.key = key;
		this.locked = locked;
		this.store = store;
	}
	change(fields) {
		const shown = fields.filter((field) => field.included).map((field) => field.key);
		if (shown.length === 0) return;
		if (this.session() !== null) {
			this.session.set(shown);
			this.keptIn.set("session");
			return;
		}
		this.keep(shown);
	}
	reset() {
		if (this.session() !== null) {
			this.session.set(this.columns().map((column) => column.key));
			this.keptIn.set("session");
			return;
		}
		this.keep(null);
	}
	layout = computed(() => {
		const shown = this.shownKeys();
		const all = this.columns().map((column) => column.key);
		return {
			current: savedViewColumnsOf(this.fields()),
			isDefault: shown.length === all.length && shown.every((key, index) => key === all[index])
		};
	}, ...ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []);
	applyView(columns) {
		if (columns === void 0) return;
		this.session.set(columns === null ? null : savedViewShownKeys(this.columns().map((column) => column.key), columns));
		this.keptIn.set(null);
	}
	keep(columns) {
		this.chosen.set(columns);
		const key = this.key();
		this.keptIn.set(key === null || this.store === null ? null : this.store.write(key, columns));
	}
};
function gridColumnChoice(columns, key, locked = []) {
	return new GridColumnChoice(signal(columns), signal(key), signal(locked), inject(GRID_COLUMN_STORE, { optional: true }));
}
var DropdownDirective = class DropdownDirective {
	host = inject(ElementRef);
	previouslyFocused = null;
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	toggle() {
		this.open() ? this.close() : this.show();
	}
	show() {
		this.previouslyFocused = document.activeElement;
		this.open.set(true);
	}
	close(restoreFocus = false) {
		if (!this.open()) return;
		this.open.set(false);
		if (restoreFocus) this.previouslyFocused?.focus();
	}
	onDocumentClick(event) {
		if (this.open() && !this.host.nativeElement.contains(event.target)) this.close();
	}
	onEscape(event) {
		if (!this.open()) return;
		this.close(true);
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DropdownDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DropdownDirective,
		isStandalone: true,
		selector: "[cmsDropdown]",
		host: { listeners: {
			"document:click": "onDocumentClick($event)",
			"document:keydown.escape": "onEscape($event)"
		} },
		exportAs: ["cmsDropdown"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DropdownDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[cmsDropdown]",
			exportAs: "cmsDropdown"
		}]
	}],
	propDecorators: {
		onDocumentClick: [{
			type: HostListener,
			args: ["document:click", ["$event"]]
		}],
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	}
});
function exportFieldsFor(columns, visibleKeys = null) {
	if (visibleKeys === null) return columns.map((column) => ({
		key: column.key,
		header: column.header,
		included: true
	}));
	const byKey = new Map(columns.map((column) => [column.key, column]));
	const shown = visibleKeys.map((key) => byKey.get(key)).filter((column) => column !== void 0);
	const shownKeys = new Set(shown.map((column) => column.key));
	return [...shown.map((column) => ({
		key: column.key,
		header: column.header,
		included: true
	})), ...columns.filter((column) => !shownKeys.has(column.key)).map((column) => ({
		key: column.key,
		header: column.header,
		included: false
	}))];
}
function reconcileExportFields(fields, columns) {
	const byKey = new Map(columns.map((column) => [column.key, column]));
	const seen = /* @__PURE__ */ new Set();
	const kept = [];
	for (const field of fields) {
		const column = byKey.get(field.key);
		if (column !== void 0 && !seen.has(field.key)) {
			seen.add(field.key);
			kept.push({
				key: field.key,
				header: column.header,
				included: field.included
			});
		}
	}
	for (const column of columns) if (!seen.has(column.key)) kept.push({
		key: column.key,
		header: column.header,
		included: true
	});
	return kept;
}
function applyExportFields(columns, fields) {
	const byKey = new Map(columns.map((column) => [column.key, column]));
	return fields.filter((field) => field.included).map((field) => byKey.get(field.key)).filter((column) => column !== void 0);
}
function toggleExportField(fields, key) {
	return fields.map((field) => field.key === key ? {
		...field,
		included: !field.included
	} : field);
}
function setAllExportFields(fields, included) {
	return fields.map((field) => ({
		...field,
		included
	}));
}
function moveExportField(fields, from, to) {
	if (from === to || from < 0 || to < 0 || from >= fields.length || to >= fields.length) return fields;
	const next = [...fields];
	const [moved] = next.splice(from, 1);
	next.splice(to, 0, moved);
	return next;
}
function includedExportFieldCount(fields) {
	return fields.filter((field) => field.included).length;
}
var ExportFieldsComponent = class ExportFieldsComponent {
	fields = input.required(...ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []);
	fieldsChange = output();
	lockedKeys = input([], ...ngDevMode ? [{ debugName: "lockedKeys" }] : /* istanbul ignore next */ []);
	noun = input("fields", ...ngDevMode ? [{ debugName: "noun" }] : /* istanbul ignore next */ []);
	listLabel = input("Fields to export, in order", ...ngDevMode ? [{ debugName: "listLabel" }] : /* istanbul ignore next */ []);
	emptyMessage = input("Select at least one field to export.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	isLocked(key) {
		return this.lockedKeys().includes(key);
	}
	draggingIndex = signal(null, ...ngDevMode ? [{ debugName: "draggingIndex" }] : /* istanbul ignore next */ []);
	dropIndex = signal(null, ...ngDevMode ? [{ debugName: "dropIndex" }] : /* istanbul ignore next */ []);
	includedCount = computed(() => includedExportFieldCount(this.fields()), ...ngDevMode ? [{ debugName: "includedCount" }] : /* istanbul ignore next */ []);
	total = computed(() => this.fields().length, ...ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []);
	canExport = computed(() => this.includedCount() > 0, ...ngDevMode ? [{ debugName: "canExport" }] : /* istanbul ignore next */ []);
	onToggle(key) {
		if (this.isLocked(key)) return;
		this.fieldsChange.emit(toggleExportField(this.fields(), key));
	}
	onSelectAll() {
		this.fieldsChange.emit(setAllExportFields(this.fields(), true));
	}
	onClearAll() {
		this.fieldsChange.emit(setAllExportFields(this.fields(), false).map((field) => this.isLocked(field.key) ? {
			...field,
			included: true
		} : field));
	}
	onMove(from, to) {
		this.fieldsChange.emit(moveExportField(this.fields(), from, to));
	}
	onDragStart(index, event) {
		this.draggingIndex.set(index);
		event.dataTransfer?.setData("text/plain", String(index));
		if (event.dataTransfer) event.dataTransfer.effectAllowed = "move";
	}
	onDragOver(index, event) {
		event.preventDefault();
		this.dropIndex.set(index);
	}
	onDrop(index, event) {
		event.preventDefault();
		const from = this.draggingIndex();
		this.draggingIndex.set(null);
		this.dropIndex.set(null);
		if (from !== null) this.onMove(from, index);
	}
	onDragEnd() {
		this.draggingIndex.set(null);
		this.dropIndex.set(null);
	}
	onKeydown(index, event) {
		if (!event.altKey) return;
		if (event.key === "ArrowUp" && index > 0) {
			event.preventDefault();
			this.onMove(index, index - 1);
		} else if (event.key === "ArrowDown" && index < this.fields().length - 1) {
			event.preventDefault();
			this.onMove(index, index + 1);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExportFieldsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ExportFieldsComponent,
		isStandalone: true,
		selector: "cms-export-fields",
		inputs: {
			fields: {
				classPropertyName: "fields",
				publicName: "fields",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			lockedKeys: {
				classPropertyName: "lockedKeys",
				publicName: "lockedKeys",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			noun: {
				classPropertyName: "noun",
				publicName: "noun",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			listLabel: {
				classPropertyName: "listLabel",
				publicName: "listLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyMessage: {
				classPropertyName: "emptyMessage",
				publicName: "emptyMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { fieldsChange: "fieldsChange" },
		ngImport: i0,
		template: "<div class=\"cws:flex cws:flex-col cws:gap-2\">\n  <!--\n    The count is the answer to \"what am I about to get\", and it is stated rather than left to be\n    counted off the list — 24 rows is more than anyone tallies by eye, and the whole point of the\n    panel is that the file no longer matches the grid.\n  -->\n  <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\n    <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n      {{ includedCount() }} of {{ total() }} {{ noun() }}\n    </span>\n\n    <div class=\"cws:flex cws:items-center cws:gap-1\">\n      <button\n        type=\"button\"\n        class=\"cws:text-xs cws:text-scoular-blue cws:dark:text-sky-400 cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\n        [disabled]=\"includedCount() === total()\"\n        (click)=\"onSelectAll()\"\n      >\n        Select all\n      </button>\n      <span aria-hidden=\"true\" class=\"cws:text-xs cws:text-slate-400\">·</span>\n      <button\n        type=\"button\"\n        class=\"cws:text-xs cws:text-scoular-blue cws:dark:text-sky-400 cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\n        [disabled]=\"includedCount() === 0\"\n        (click)=\"onClearAll()\"\n      >\n        Clear\n      </button>\n    </div>\n  </div>\n\n  <!--\n    🔴 A LIST, not a table, and `role=\"list\"` is explicit because `list-none` removes the implicit\n    one in Safari and VoiceOver. The order is the meaning here, so a screen reader announcing \"list,\n    24 items, item 3 of 24\" is carrying the information the drag gesture conveys visually.\n\n    Capped height with its own scroll: the workspace grid has 24 columns, and a panel that grows to\n    fit them pushes its own export buttons off the bottom of the viewport — the one thing the user\n    opened it to reach.\n  -->\n  <!--\n    ⚠ **`select-none` is load-bearing here too, and it is the same defect the filter chips had**\n    (JFrisbie, 2026-09-14). These rows are `draggable`, and a press inside a TEXT SELECTION makes\n    Chrome drag the selection rather than the row -- so once a user has selected anything across\n    this list, reordering stops working until the selection is cleared. Measured on the chip row,\n    where the same cause could not be dragged out of without reloading the page.\n  -->\n  <ul\n    role=\"list\"\n    class=\"cws:max-h-64 cws:select-none cws:overflow-y-auto cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\"\n    [attr.aria-label]=\"listLabel()\"\n  >\n    @for (field of fields(); track field.key) {\n      <li\n        class=\"cws:flex cws:items-center cws:gap-2 cws:border-b cws:border-slate-100 cws:px-2 cws:py-1.5 cws:last:border-b-0 cws:dark:border-slate-800\"\n        [class.cws:bg-slate-100]=\"draggingIndex() === $index\"\n        [class.cws:dark:bg-slate-800]=\"draggingIndex() === $index\"\n        [class.cws:border-t-2]=\"dropIndex() === $index && draggingIndex() !== $index\"\n        [class.cws:border-t-scoular-blue]=\"dropIndex() === $index && draggingIndex() !== $index\"\n        draggable=\"true\"\n        tabindex=\"0\"\n        [attr.aria-label]=\"\n          field.header\n            + ', position ' + ($index + 1) + ' of ' + total()\n            + (field.included ? ', included' : ', not included')\n            + '. Alt+Arrow Up or Alt+Arrow Down to reorder.'\n        \"\n        (dragstart)=\"onDragStart($index, $event)\"\n        (dragover)=\"onDragOver($index, $event)\"\n        (drop)=\"onDrop($index, $event)\"\n        (dragend)=\"onDragEnd()\"\n        (keydown)=\"onKeydown($index, $event)\"\n      >\n        <!--\n          The grip is `aria-hidden` and has no tab stop: it is an affordance for the pointer, and the\n          keyboard equivalent is the two buttons at the end of the row. A focusable grip would add a\n          tab stop per field — 24 extra stops — that does nothing when activated.\n        -->\n        <span aria-hidden=\"true\" class=\"cws:cursor-grab cws:select-none cws:text-slate-400\" title=\"Drag to reorder\">\n          ⠿\n        </span>\n\n        <label class=\"cws:flex cws:min-w-0 cws:flex-1 cws:items-center cws:gap-2\">\n          <input\n            type=\"checkbox\"\n            [checked]=\"field.included\"\n            [disabled]=\"isLocked(field.key)\"\n            [attr.title]=\"isLocked(field.key) ? 'Always shown' : null\"\n            (change)=\"onToggle(field.key)\"\n          />\n          <!--\n            `truncate` with the header also in `title`: a long heading must not wrap the row, because\n            a variable row height makes the drop indicator land somewhere other than where the pointer\n            is.\n          -->\n          <span class=\"truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" [title]=\"field.header\">\n            {{ field.header }}\n          </span>\n        </label>\n\n        <!-- 24 px targets each (WCAG 2.2, 2.5.8): the arrows were 18 x 16 and axe failed them (#764). -->\n        <span class=\"cws:flex cws:shrink-0 cws:items-center\">\n          <button\n            type=\"button\"\n            class=\"cws:inline-flex cws:size-6 cws:items-center cws:justify-center cws:rounded cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\n            [disabled]=\"$first\"\n            [attr.aria-label]=\"'Move ' + field.header + ' up'\"\n            (click)=\"onMove($index, $index - 1)\"\n          >\n            ▲\n          </button>\n          <button\n            type=\"button\"\n            class=\"cws:inline-flex cws:size-6 cws:items-center cws:justify-center cws:rounded cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\n            [disabled]=\"$last\"\n            [attr.aria-label]=\"'Move ' + field.header + ' down'\"\n            (click)=\"onMove($index, $index + 1)\"\n          >\n            ▼\n          </button>\n        </span>\n      </li>\n    }\n  </ul>\n\n  @if (!canExport()) {\n    <!--\n      Stated where the choice was made, rather than as a disabled button with no explanation. An\n      export of no fields produces a file of empty lines, which reads as missing data rather than as\n      the user's own selection.\n    -->\n    <p role=\"status\" class=\"cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\n      {{ emptyMessage() }}\n    </p>\n  }\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExportFieldsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-export-fields",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"cws:flex cws:flex-col cws:gap-2\">\n  <!--\n    The count is the answer to \"what am I about to get\", and it is stated rather than left to be\n    counted off the list — 24 rows is more than anyone tallies by eye, and the whole point of the\n    panel is that the file no longer matches the grid.\n  -->\n  <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\n    <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n      {{ includedCount() }} of {{ total() }} {{ noun() }}\n    </span>\n\n    <div class=\"cws:flex cws:items-center cws:gap-1\">\n      <button\n        type=\"button\"\n        class=\"cws:text-xs cws:text-scoular-blue cws:dark:text-sky-400 cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\n        [disabled]=\"includedCount() === total()\"\n        (click)=\"onSelectAll()\"\n      >\n        Select all\n      </button>\n      <span aria-hidden=\"true\" class=\"cws:text-xs cws:text-slate-400\">·</span>\n      <button\n        type=\"button\"\n        class=\"cws:text-xs cws:text-scoular-blue cws:dark:text-sky-400 cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\n        [disabled]=\"includedCount() === 0\"\n        (click)=\"onClearAll()\"\n      >\n        Clear\n      </button>\n    </div>\n  </div>\n\n  <!--\n    🔴 A LIST, not a table, and `role=\"list\"` is explicit because `list-none` removes the implicit\n    one in Safari and VoiceOver. The order is the meaning here, so a screen reader announcing \"list,\n    24 items, item 3 of 24\" is carrying the information the drag gesture conveys visually.\n\n    Capped height with its own scroll: the workspace grid has 24 columns, and a panel that grows to\n    fit them pushes its own export buttons off the bottom of the viewport — the one thing the user\n    opened it to reach.\n  -->\n  <!--\n    ⚠ **`select-none` is load-bearing here too, and it is the same defect the filter chips had**\n    (JFrisbie, 2026-09-14). These rows are `draggable`, and a press inside a TEXT SELECTION makes\n    Chrome drag the selection rather than the row -- so once a user has selected anything across\n    this list, reordering stops working until the selection is cleared. Measured on the chip row,\n    where the same cause could not be dragged out of without reloading the page.\n  -->\n  <ul\n    role=\"list\"\n    class=\"cws:max-h-64 cws:select-none cws:overflow-y-auto cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\"\n    [attr.aria-label]=\"listLabel()\"\n  >\n    @for (field of fields(); track field.key) {\n      <li\n        class=\"cws:flex cws:items-center cws:gap-2 cws:border-b cws:border-slate-100 cws:px-2 cws:py-1.5 cws:last:border-b-0 cws:dark:border-slate-800\"\n        [class.cws:bg-slate-100]=\"draggingIndex() === $index\"\n        [class.cws:dark:bg-slate-800]=\"draggingIndex() === $index\"\n        [class.cws:border-t-2]=\"dropIndex() === $index && draggingIndex() !== $index\"\n        [class.cws:border-t-scoular-blue]=\"dropIndex() === $index && draggingIndex() !== $index\"\n        draggable=\"true\"\n        tabindex=\"0\"\n        [attr.aria-label]=\"\n          field.header\n            + ', position ' + ($index + 1) + ' of ' + total()\n            + (field.included ? ', included' : ', not included')\n            + '. Alt+Arrow Up or Alt+Arrow Down to reorder.'\n        \"\n        (dragstart)=\"onDragStart($index, $event)\"\n        (dragover)=\"onDragOver($index, $event)\"\n        (drop)=\"onDrop($index, $event)\"\n        (dragend)=\"onDragEnd()\"\n        (keydown)=\"onKeydown($index, $event)\"\n      >\n        <!--\n          The grip is `aria-hidden` and has no tab stop: it is an affordance for the pointer, and the\n          keyboard equivalent is the two buttons at the end of the row. A focusable grip would add a\n          tab stop per field — 24 extra stops — that does nothing when activated.\n        -->\n        <span aria-hidden=\"true\" class=\"cws:cursor-grab cws:select-none cws:text-slate-400\" title=\"Drag to reorder\">\n          ⠿\n        </span>\n\n        <label class=\"cws:flex cws:min-w-0 cws:flex-1 cws:items-center cws:gap-2\">\n          <input\n            type=\"checkbox\"\n            [checked]=\"field.included\"\n            [disabled]=\"isLocked(field.key)\"\n            [attr.title]=\"isLocked(field.key) ? 'Always shown' : null\"\n            (change)=\"onToggle(field.key)\"\n          />\n          <!--\n            `truncate` with the header also in `title`: a long heading must not wrap the row, because\n            a variable row height makes the drop indicator land somewhere other than where the pointer\n            is.\n          -->\n          <span class=\"truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" [title]=\"field.header\">\n            {{ field.header }}\n          </span>\n        </label>\n\n        <!-- 24 px targets each (WCAG 2.2, 2.5.8): the arrows were 18 x 16 and axe failed them (#764). -->\n        <span class=\"cws:flex cws:shrink-0 cws:items-center\">\n          <button\n            type=\"button\"\n            class=\"cws:inline-flex cws:size-6 cws:items-center cws:justify-center cws:rounded cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\n            [disabled]=\"$first\"\n            [attr.aria-label]=\"'Move ' + field.header + ' up'\"\n            (click)=\"onMove($index, $index - 1)\"\n          >\n            ▲\n          </button>\n          <button\n            type=\"button\"\n            class=\"cws:inline-flex cws:size-6 cws:items-center cws:justify-center cws:rounded cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\n            [disabled]=\"$last\"\n            [attr.aria-label]=\"'Move ' + field.header + ' down'\"\n            (click)=\"onMove($index, $index + 1)\"\n          >\n            ▼\n          </button>\n        </span>\n      </li>\n    }\n  </ul>\n\n  @if (!canExport()) {\n    <!--\n      Stated where the choice was made, rather than as a disabled button with no explanation. An\n      export of no fields produces a file of empty lines, which reads as missing data rather than as\n      the user's own selection.\n    -->\n    <p role=\"status\" class=\"cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\n      {{ emptyMessage() }}\n    </p>\n  }\n</div>\n"
		}]
	}],
	propDecorators: {
		fields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fields",
				required: true
			}]
		}],
		fieldsChange: [{
			type: i0.Output,
			args: ["fieldsChange"]
		}],
		lockedKeys: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lockedKeys",
				required: false
			}]
		}],
		noun: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "noun",
				required: false
			}]
		}],
		listLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "listLabel",
				required: false
			}]
		}],
		emptyMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyMessage",
				required: false
			}]
		}]
	}
});
var GridColumnMenuComponent = class GridColumnMenuComponent {
	fields = input.required(...ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []);
	lockedKeys = input([], ...ngDevMode ? [{ debugName: "lockedKeys" }] : /* istanbul ignore next */ []);
	keptIn = input(null, ...ngDevMode ? [{ debugName: "keptIn" }] : /* istanbul ignore next */ []);
	failure = input(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	resetLabel = input("Reset to the trade unit's columns", ...ngDevMode ? [{ debugName: "resetLabel" }] : /* istanbul ignore next */ []);
	fieldsChange = output();
	reset = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GridColumnMenuComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: GridColumnMenuComponent,
		isStandalone: true,
		selector: "cms-grid-column-menu",
		inputs: {
			fields: {
				classPropertyName: "fields",
				publicName: "fields",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			lockedKeys: {
				classPropertyName: "lockedKeys",
				publicName: "lockedKeys",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			keptIn: {
				classPropertyName: "keptIn",
				publicName: "keptIn",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			failure: {
				classPropertyName: "failure",
				publicName: "failure",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resetLabel: {
				classPropertyName: "resetLabel",
				publicName: "resetLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			fieldsChange: "fieldsChange",
			reset: "reset"
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <!-- The directive wraps the trigger AND the panel, so a click inside the panel is not "outside". -->
    <div cmsDropdown #menu="cmsDropdown" class="cws:relative">
      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        [disabled]="disabled()"
        [attr.aria-expanded]="menu.open()"
        aria-haspopup="true"
        (click)="menu.toggle()"
      >
        Columns
        <span aria-hidden="true" class="cws:text-xs">{{ menu.open() ? '▲' : '▼' }}</span>
      </button>

      @if (menu.open()) {
        <!-- A group, not a menu: it holds checkboxes and reorder buttons, not commands. -->
        <div class="scoular-dropdown cws:right-0 cws:top-full cws:w-80" role="group" aria-label="Columns">
          <div class="scoular-dropdown-header">Columns</div>

          <div class="cws:px-3 cws:py-2">
            <cms-export-fields
              [fields]="fields()"
              [lockedKeys]="lockedKeys()"
              noun="columns"
              listLabel="Columns shown, in order"
              emptyMessage="Select at least one column."
              (fieldsChange)="fieldsChange.emit($event)"
            />
          </div>

          <div class="scoular-dropdown-divider"></div>

          <div class="cws:flex cws:flex-col cws:gap-1 cws:px-3 cws:pb-2 cws:pt-1">
            <button type="button" class="scoular-btn scoular-btn-secondary cws:justify-center" (click)="reset.emit()">
              {{ resetLabel() }}
            </button>

            @switch (keptIn()) {
              @case ('browser') {
                <p role="status" class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  Kept in this browser. Your account cannot store column choices yet.
                </p>
              }
              @case ('failed') {
                <!-- #803: a failure, so an alert, ending with the server's reference or why there is none. -->
                <div role="alert" class="cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow">
                  <p>Could not be kept. It lasts until you leave this page.</p>
                  <cms-reference-line [correlationId]="failure()?.correlationId ?? null" [sent]="failure()?.sent ?? true" />
                </div>
              }
              @case ('account') {
                <p role="status" class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  Kept on your account.
                </p>
              }
              @case ('session') {
                <!-- #1150: a change on top of a saved view's columns. Not kept, and it says so. -->
                <p role="status" class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  For this session only, on top of the saved view. Not kept.
                </p>
              }
            }
          </div>
        </div>
      }
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: DropdownDirective,
				selector: "[cmsDropdown]",
				exportAs: ["cmsDropdown"]
			},
			{
				kind: "component",
				type: ExportFieldsComponent,
				selector: "cms-export-fields",
				inputs: [
					"fields",
					"lockedKeys",
					"noun",
					"listLabel",
					"emptyMessage"
				],
				outputs: ["fieldsChange"]
			},
			{
				kind: "component",
				type: ReferenceLineComponent,
				selector: "cms-reference-line",
				inputs: ["correlationId", "sent"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GridColumnMenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-grid-column-menu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				DropdownDirective,
				ExportFieldsComponent,
				ReferenceLineComponent
			],
			host: { class: "cws:block" },
			template: `
    <!-- The directive wraps the trigger AND the panel, so a click inside the panel is not "outside". -->
    <div cmsDropdown #menu="cmsDropdown" class="cws:relative">
      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        [disabled]="disabled()"
        [attr.aria-expanded]="menu.open()"
        aria-haspopup="true"
        (click)="menu.toggle()"
      >
        Columns
        <span aria-hidden="true" class="cws:text-xs">{{ menu.open() ? '▲' : '▼' }}</span>
      </button>

      @if (menu.open()) {
        <!-- A group, not a menu: it holds checkboxes and reorder buttons, not commands. -->
        <div class="scoular-dropdown cws:right-0 cws:top-full cws:w-80" role="group" aria-label="Columns">
          <div class="scoular-dropdown-header">Columns</div>

          <div class="cws:px-3 cws:py-2">
            <cms-export-fields
              [fields]="fields()"
              [lockedKeys]="lockedKeys()"
              noun="columns"
              listLabel="Columns shown, in order"
              emptyMessage="Select at least one column."
              (fieldsChange)="fieldsChange.emit($event)"
            />
          </div>

          <div class="scoular-dropdown-divider"></div>

          <div class="cws:flex cws:flex-col cws:gap-1 cws:px-3 cws:pb-2 cws:pt-1">
            <button type="button" class="scoular-btn scoular-btn-secondary cws:justify-center" (click)="reset.emit()">
              {{ resetLabel() }}
            </button>

            @switch (keptIn()) {
              @case ('browser') {
                <p role="status" class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  Kept in this browser. Your account cannot store column choices yet.
                </p>
              }
              @case ('failed') {
                <!-- #803: a failure, so an alert, ending with the server's reference or why there is none. -->
                <div role="alert" class="cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow">
                  <p>Could not be kept. It lasts until you leave this page.</p>
                  <cms-reference-line [correlationId]="failure()?.correlationId ?? null" [sent]="failure()?.sent ?? true" />
                </div>
              }
              @case ('account') {
                <p role="status" class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  Kept on your account.
                </p>
              }
              @case ('session') {
                <!-- #1150: a change on top of a saved view's columns. Not kept, and it says so. -->
                <p role="status" class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  For this session only, on top of the saved view. Not kept.
                </p>
              }
            }
          </div>
        </div>
      }
    </div>
  `
		}]
	}],
	propDecorators: {
		fields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fields",
				required: true
			}]
		}],
		lockedKeys: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lockedKeys",
				required: false
			}]
		}],
		keptIn: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "keptIn",
				required: false
			}]
		}],
		failure: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "failure",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		resetLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resetLabel",
				required: false
			}]
		}],
		fieldsChange: [{
			type: i0.Output,
			args: ["fieldsChange"]
		}],
		reset: [{
			type: i0.Output,
			args: ["reset"]
		}]
	}
});
const LOOKUP_ATTRIBUTE = "data-cws-lookup";
const OPEN_LOOKUP_EVENT = "cws-open-lookup";
const SCOPE_RANK = {
	shell: 0,
	feature: 1,
	control: 2,
	dialog: 3
};
function scopeRank(scope) {
	return SCOPE_RANK[scope];
}
function defaultGroup(scope) {
	switch (scope) {
		case "shell": return "Navigation";
		case "feature": return "This screen";
		case "control": return "The control you are in";
		case "dialog": return "This dialog";
	}
}
function formatShortcut(keys) {
	return keys.split("+").map((part) => {
		switch (part) {
			case "ctrl": return "Ctrl";
			case "alt": return "Alt";
			case "shift": return "Shift";
			case "pagedown": return "Page Down";
			case "pageup": return "Page Up";
			case "escape": return "Esc";
			case "enter": return "Enter";
			case "space": return "Space";
			default: return part.length === 1 ? part.toUpperCase() : part.replace(/^f(\d+)$/, "F$1");
		}
	}).join(" + ");
}
function ariaKeyShortcuts(keys) {
	return keys.split("+").map((part) => {
		switch (part) {
			case "ctrl": return "Control";
			case "alt": return "Alt";
			case "shift": return "Shift";
			default: return part.length === 1 ? part.toUpperCase() : part.replace(/^f(\d+)$/, "F$1");
		}
	}).join("+");
}
function shortcutTokens(event) {
	const modifiers = [];
	if (event.ctrlKey || event.metaKey) modifiers.push("ctrl");
	if (event.altKey) modifiers.push("alt");
	const names = /* @__PURE__ */ new Set();
	const fromKey = normaliseKeyName(event.key);
	if (fromKey !== null) names.add(fromKey);
	const fromCode = normaliseCodeName(event.code);
	if (fromCode !== null) names.add(fromCode);
	const shiftVariants = event.shiftKey ? ["shift", null] : [null];
	const tokens = [];
	for (const name of names) for (const shift of shiftVariants) tokens.push([
		...modifiers,
		...shift === null ? [] : [shift],
		name
	].join("+"));
	return tokens;
}
function normaliseKeyName(key) {
	if (key === "" || key === "Control" || key === "Alt" || key === "Shift" || key === "Meta") return null;
	return key === " " ? "space" : key.toLowerCase();
}
function normaliseCodeName(code) {
	const letter = /^Key([A-Z])$/.exec(code);
	if (letter !== null) return letter[1].toLowerCase();
	const digit = /^Digit([0-9])$/.exec(code);
	return digit === null ? null : digit[1];
}
function isTextEditable(target) {
	const element = target;
	if (element === null || typeof element.tagName !== "string") return false;
	if (element.isContentEditable) return true;
	if (element.tagName === "TEXTAREA") return true;
	if (element.tagName !== "INPUT") return false;
	const type = element.type;
	return ![
		"button",
		"checkbox",
		"color",
		"file",
		"image",
		"radio",
		"range",
		"reset",
		"submit"
	].includes(type);
}
var ShortcutRegistry = class ShortcutRegistry {
	registrations = signal([], ...ngDevMode ? [{ debugName: "registrations" }] : /* istanbul ignore next */ []);
	sequence = 0;
	visible = computed(() => this.registrations().filter((entry) => entry.binding.available?.() ?? true), ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	contexts = signal([], ...ngDevMode ? [{ debugName: "contexts" }] : /* istanbul ignore next */ []);
	contextHints = computed(() => this.contexts().at(-1)?.hints ?? [], ...ngDevMode ? [{ debugName: "contextHints" }] : /* istanbul ignore next */ []);
	setContext(owner, hints) {
		this.contexts.update((current) => {
			const others = current.filter((entry) => entry.owner !== owner);
			return hints === null ? others : [...others, {
				owner,
				hints
			}];
		});
	}
	constructor() {
		document.addEventListener("keydown", this.onKeydown);
		inject(DestroyRef).onDestroy(() => {
			document.removeEventListener("keydown", this.onKeydown);
		});
	}
	register(bindings) {
		const added = bindings.map((binding) => {
			this.sequence += 1;
			return {
				binding,
				sequence: this.sequence
			};
		});
		if (isDevMode()) {
			const existing = this.registrations();
			for (const entry of added) {
				const clash = existing.find((other) => other.binding.keys === entry.binding.keys && other.binding.scope === entry.binding.scope);
				if (clash !== void 0) throw new Error(`Shortcut "${entry.binding.keys}" is already registered at scope "${entry.binding.scope}" ("${clash.binding.label}"). Two meanings for one key is the defect this registry exists to prevent — pick a different key, or a different scope if one genuinely outranks the other.`);
			}
		}
		this.registrations.update((current) => [...current, ...added]);
		return () => {
			this.registrations.update((current) => current.filter((entry) => !added.includes(entry)));
		};
	}
	onKeydown = (event) => {
		if (event.defaultPrevented) return;
		const tokens = shortcutTokens(event);
		const editable = isTextEditable(event.target);
		let best = null;
		for (const entry of this.registrations()) {
			const binding = entry.binding;
			if (binding.run === void 0) continue;
			if (!tokens.includes(binding.keys)) continue;
			if (editable && binding.allowInTextInput !== true) continue;
			if (!(binding.available?.() ?? true)) continue;
			if (!targetsWithin(event.target, binding.within?.())) continue;
			if (!(binding.accepts?.(event) ?? true)) continue;
			if (best === null || rank(entry) > rank(best)) best = entry;
		}
		if (best === null) return;
		event.preventDefault();
		best.binding.run?.(event);
	};
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ShortcutRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ShortcutRegistry,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ShortcutRegistry,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
function targetsWithin(target, root) {
	if (root === void 0 || root === null || !(target instanceof Element)) return true;
	const document = target.ownerDocument;
	return target === document.body || target === document.documentElement || root.contains(target);
}
function rank(entry) {
	return scopeRank(entry.binding.scope) * 1e6 + entry.sequence;
}
function registerShortcuts(bindings) {
	const disposer = inject(ShortcutRegistry).register(bindings);
	inject(DestroyRef).onDestroy(disposer);
}
const TONE_CLASS = {
	positive: "scoular-badge-success",
	caution: "scoular-badge-warning",
	negative: "scoular-badge-error",
	info: "scoular-badge-info",
	neutral: "scoular-badge-neutral cws:border-slate-300 cws:dark:border-slate-500 cws:dark:bg-slate-800 cws:dark:text-slate-300"
};
function statusBadgeClass(tone, small = false) {
	return small ? `${TONE_CLASS[tone]} scoular-badge-sm` : TONE_CLASS[tone];
}
var StatusBadgeComponent = class StatusBadgeComponent {
	tone = input.required(...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	small = input(false, ...ngDevMode ? [{ debugName: "small" }] : /* istanbul ignore next */ []);
	classes = computed(() => `scoular-badge ${statusBadgeClass(this.tone(), this.small())}`, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StatusBadgeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: StatusBadgeComponent,
		isStandalone: true,
		selector: "cms-status-badge",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			small: {
				classPropertyName: "small",
				publicName: "small",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "class": "classes()" } },
		ngImport: i0,
		template: `<ng-content />`,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StatusBadgeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-status-badge",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class]": "classes()" },
			template: `<ng-content />`
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: true
			}]
		}],
		small: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "small",
				required: false
			}]
		}]
	}
});
const SELECTED_CELL_CLASS = "cws:bg-scoular-blue/10 cws:outline cws:outline-2 cws:-outline-offset-2 cws:outline-scoular-blue cws:dark:bg-sky-400/20 cws:dark:outline-sky-400";
const SELECTED_ROW_CLASS = "cws:bg-scoular-blue/5 cws:focus:outline-none cws:dark:bg-sky-400/10";
const UNSELECTED_ROW_CLASS = "cws:hover:bg-slate-100 cws:focus:outline-2 cws:focus:outline-offset-[-2px] cws:focus:outline-scoular-blue cws:dark:hover:bg-slate-700/70";
const ROW_TONE_CLASS = {
	negative: "cws:bg-scoular-red/4 cws:dark:bg-scoular-red/15",
	caution: "cws:bg-scoular-yellow/5 cws:dark:bg-scoular-yellow/10"
};
const STRIPE_CLASS = "cws:bg-slate-50/70 cws:dark:bg-slate-800/40";
const SORTED_HEADER_CLASS = "cws:bg-scoular-blue/10 cws:text-scoular-blue cws:hover:bg-scoular-blue/15 cws:dark:bg-sky-400/15 cws:dark:text-sky-400 cws:dark:hover:bg-sky-400/20";
const UNSORTED_HEADER_CLASS = "cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700/70";
const CELL_HEIGHT_CLASS = "cws:h-11";
var DataGridComponent = class DataGridComponent {
	cellHeightClass = CELL_HEIGHT_CLASS;
	rows = input.required(...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	columnMenu = input(true, ...ngDevMode ? [{ debugName: "columnMenu" }] : /* istanbul ignore next */ []);
	columnsKey = input(null, ...ngDevMode ? [{ debugName: "columnsKey" }] : /* istanbul ignore next */ []);
	lockedColumns = input([], ...ngDevMode ? [{ debugName: "lockedColumns" }] : /* istanbul ignore next */ []);
	columnChoice = new GridColumnChoice(this.columns, this.columnsKey, this.lockedColumns, inject(GRID_COLUMN_STORE, { optional: true }));
	shownColumns = this.columnChoice.shown;
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	striped = input(false, ...ngDevMode ? [{ debugName: "striped" }] : /* istanbul ignore next */ []);
	actions = input([], ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
	actionsHeader = input("Actions", ...ngDevMode ? [{ debugName: "actionsHeader" }] : /* istanbul ignore next */ []);
	actionsWidth = input(96, ...ngDevMode ? [{ debugName: "actionsWidth" }] : /* istanbul ignore next */ []);
	rowLabel = input(void 0, ...ngDevMode ? [{ debugName: "rowLabel" }] : /* istanbul ignore next */ []);
	activateLabel = input(null, ...ngDevMode ? [{ debugName: "activateLabel" }] : /* istanbul ignore next */ []);
	selectable = input(false, ...ngDevMode ? [{ debugName: "selectable" }] : /* istanbul ignore next */ []);
	hasActions = computed(() => this.actions().length > 0, ...ngDevMode ? [{ debugName: "hasActions" }] : /* istanbul ignore next */ []);
	sorts = input([], ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	rowTone = input(() => null, ...ngDevMode ? [{ debugName: "rowTone" }] : /* istanbul ignore next */ []);
	trackBy = input((row) => row, ...ngDevMode ? [{ debugName: "trackBy" }] : /* istanbul ignore next */ []);
	focusKey = input(null, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	sortChange = output();
	rowActivate = output();
	cellCopy = output();
	pageStep = output();
	rowToggle = output();
	selectAll = output();
	body = viewChild("body", ...ngDevMode ? [{ debugName: "body" }] : /* istanbul ignore next */ []);
	honouredFocusKey = null;
	constructor() {
		afterRenderEffect(() => {
			const key = this.focusKey();
			const rows = this.rows();
			const columns = this.shownColumns();
			if (key === null || key === void 0 || key === this.honouredFocusKey) return;
			if (columns.length === 0) return;
			const index = rows.findIndex((row, position) => this.trackBy()(row, position) === key);
			if (index === -1) return;
			this.honouredFocusKey = key;
			this.selected.set({
				row: rows[index],
				key: columns[0].key
			});
			this.focusRow(index);
		});
		effect(() => {
			const row = this.focusedRow();
			this.shortcuts.setContext(this, row === null ? null : this.rowHintsFor(row));
		});
		inject(DestroyRef).onDestroy(() => this.shortcuts.setContext(this, null));
	}
	shortcuts = inject(ShortcutRegistry);
	focusedRow = signal(null, ...ngDevMode ? [{ debugName: "focusedRow" }] : /* istanbul ignore next */ []);
	onRowFocusIn(row) {
		this.focusedRow.set(row);
	}
	onBodyFocusOut() {
		this.focusedRow.set(null);
	}
	rowHintsFor(row) {
		const open = this.activateLabel();
		const letters = this.actionsFor(row).filter((action) => action.accessKey !== void 0 && !this.isActionDisabled(action, row)).map((action) => ({
			keys: action.accessKey.toLowerCase(),
			label: action.label
		}));
		const selection = this.selectable() ? [{
			keys: "space",
			label: "Select or clear this row"
		}, {
			keys: "ctrl+a",
			label: "Select every row shown"
		}] : [];
		return [
			...open === null ? [] : [{
				keys: "enter",
				label: open
			}],
			...letters,
			...selection,
			{
				keys: "ctrl+c",
				label: "Copy cell"
			}
		];
	}
	hasRows = computed(() => this.rows().length > 0, ...ngDevMode ? [{ debugName: "hasRows" }] : /* istanbul ignore next */ []);
	selected = signal(null, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	isSelected(row, column) {
		const selected = this.selected();
		return selected !== null && selected.row === row && selected.key === column.key;
	}
	cellClassFor(row, column) {
		const selection = this.isSelected(row, column) ? ` ${SELECTED_CELL_CLASS}` : "";
		return `${CELL_HEIGHT_CLASS}${selection}`;
	}
	resized = signal({}, ...ngDevMode ? [{ debugName: "resized" }] : /* istanbul ignore next */ []);
	drag = null;
	widths = computed(() => this.shownColumns().map((column) => ({
		key: column.key,
		width: this.resized()[column.key] ?? column.width ?? 140
	})), ...ngDevMode ? [{ debugName: "widths" }] : /* istanbul ignore next */ []);
	widthOf(column) {
		return this.resized()[column.key] ?? column.width ?? 140;
	}
	onResizeStart(event, column) {
		event.preventDefault();
		event.stopPropagation();
		this.drag = {
			key: column.key,
			startX: event.clientX,
			startWidth: this.widthOf(column)
		};
		event.target.setPointerCapture(event.pointerId);
	}
	onResizeMove(event, column) {
		if (this.drag?.key !== column.key) return;
		const floor = column.minWidth ?? 56;
		const width = Math.max(floor, this.drag.startWidth + (event.clientX - this.drag.startX));
		this.resized.update((widths) => ({
			...widths,
			[column.key]: width
		}));
	}
	onResizeEnd() {
		this.drag = null;
	}
	onResizeKeydown(event, column) {
		const step = 16;
		const floor = column.minWidth ?? 56;
		const current = this.widthOf(column);
		switch (event.key) {
			case "ArrowLeft":
				this.resized.update((w) => ({
					...w,
					[column.key]: Math.max(floor, current - step)
				}));
				break;
			case "ArrowRight":
				this.resized.update((w) => ({
					...w,
					[column.key]: current + step
				}));
				break;
			case "Home":
				this.resized.update((w) => {
					const { [column.key]: _removed, ...rest } = w;
					return rest;
				});
				break;
			default: return;
		}
		event.preventDefault();
		event.stopPropagation();
	}
	titleFor(column, row) {
		return column.tooltip?.(row) ?? column.format(row);
	}
	ariaSortFor(key) {
		return ariaSort(this.sorts(), key);
	}
	sortRankFor(key) {
		return this.sorts().length > 1 ? sortRank(this.sorts(), key) : null;
	}
	headerClassFor(column) {
		const state = this.ariaSortFor(column.key) === "none" ? UNSORTED_HEADER_CLASS : SORTED_HEADER_CLASS;
		return `${CELL_HEIGHT_CLASS} ${state}`;
	}
	badgeToneFor(column, row) {
		return column.badge?.(row)?.tone ?? null;
	}
	badgeLabelFor(column, row) {
		return column.badge?.(row)?.label ?? null;
	}
	rowToneClassFor(row) {
		const tone = this.rowTone()(row);
		return tone === null ? "" : ROW_TONE_CLASS[tone];
	}
	holdsSelection(row) {
		return this.selected()?.row === row;
	}
	rowClassFor(row, index) {
		if (this.holdsSelection(row)) return SELECTED_ROW_CLASS;
		const tone = this.rowToneClassFor(row);
		const stripe = this.striped() && tone === "" && index % 2 === 1 ? STRIPE_CLASS : "";
		return `${UNSELECTED_ROW_CLASS} ${tone} ${stripe}`;
	}
	onHeaderActivate(column) {
		if (column.sortable) this.sortChange.emit(nextSort(this.sorts(), column.key));
	}
	onCellMousedown(row, index, column) {
		this.selected.set({
			row,
			key: column.key
		});
		this.focusRow(index);
	}
	onRowFocus(row) {
		const columns = this.shownColumns();
		if (columns.length === 0 || this.holdsSelection(row)) return;
		this.selected.set({
			row,
			key: columns[0].key
		});
	}
	stepCell(row, step) {
		const columns = this.shownColumns();
		if (columns.length === 0) return;
		const selected = this.selected();
		const current = selected !== null && selected.row === row ? columns.findIndex((column) => column.key === selected.key) : -1;
		const next = current === -1 ? step === 1 ? 0 : columns.length - 1 : Math.min(Math.max(current + step, 0), columns.length - 1);
		this.selected.set({
			row,
			key: columns[next].key
		});
		this.revealSelected();
	}
	revealSelected() {
		const selected = this.selected();
		if (selected === null) return;
		this.body()?.nativeElement.querySelector(`td[data-cell-key="${CSS.escape(selected.key)}"]`)?.scrollIntoView?.({
			block: "nearest",
			inline: "nearest"
		});
	}
	copySelected() {
		const selected = this.selected();
		if (selected === null || navigator.clipboard === void 0) return false;
		const column = this.shownColumns().find((candidate) => candidate.key === selected.key);
		if (column === void 0) return false;
		const text = column.format(selected.row);
		navigator.clipboard.writeText(text).then(() => this.cellCopy.emit(text)).catch(() => void 0);
		return true;
	}
	onRowKeydown(event, row, index) {
		if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "c") {
			if ((window.getSelection()?.toString() ?? "") !== "") return;
			if (this.copySelected()) event.preventDefault();
			return;
		}
		if (this.selectable() && this.onSelectionKey(event, row)) return;
		if (!event.ctrlKey && !event.metaKey && !event.altKey && event.key.length === 1) {
			const letter = event.key.toLowerCase();
			const action = this.actionsFor(row).find((candidate) => candidate.accessKey?.toLowerCase() === letter);
			if (action !== void 0) {
				event.preventDefault();
				if ((action.disabled?.(row) ?? false) === false && (action.busy?.(row) ?? false) === false) action.run(row);
				return;
			}
		}
		switch (event.key) {
			case "ArrowDown":
				this.focusRow(index + 1, row);
				break;
			case "ArrowUp":
				this.focusRow(index - 1, row);
				break;
			case "ArrowRight":
				this.stepCell(row, 1);
				break;
			case "ArrowLeft":
				this.stepCell(row, -1);
				break;
			case "Home":
				this.focusRow(0, row);
				break;
			case "End":
				this.focusRow(this.rows().length - 1, row);
				break;
			case "PageDown":
				this.pageStep.emit(1);
				break;
			case "PageUp":
				this.pageStep.emit(-1);
				break;
			case "Enter":
				this.rowActivate.emit(row);
				break;
			default: return;
		}
		event.preventDefault();
	}
	onSelectionKey(event, row) {
		if (event.target !== event.currentTarget || event.altKey) return false;
		const command = event.ctrlKey || event.metaKey;
		if (event.key === " " && !command && !event.shiftKey) {
			event.preventDefault();
			this.rowToggle.emit(row);
			return true;
		}
		if (command && !event.shiftKey && event.key.toLowerCase() === "a") {
			event.preventDefault();
			this.selectAll.emit();
			return true;
		}
		return false;
	}
	focusRow(index, from) {
		const rows = this.body()?.nativeElement.querySelectorAll("tr");
		if (!rows || rows.length === 0) return;
		const clamped = Math.min(Math.max(index, 0), rows.length - 1);
		if (from !== void 0) {
			const selected = this.selected();
			const target = this.rows()[clamped];
			if (selected !== null && selected.row === from && target !== void 0) this.selected.set({
				row: target,
				key: selected.key
			});
		}
		rows[clamped]?.focus();
	}
	actionsFor(row) {
		return this.actions().filter((action) => !(action.hidden?.(row) ?? false));
	}
	isActionDisabled(action, row) {
		return isActionUnavailable(action, row);
	}
	rowNameFor(row, index) {
		return this.rowLabel()?.(row) ?? `row ${index + 1}`;
	}
	onActionKeydown(event) {
		if ([
			"Enter",
			" ",
			"Spacebar",
			"ArrowDown",
			"ArrowUp"
		].includes(event.key)) event.stopPropagation();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DataGridComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: DataGridComponent,
		isStandalone: true,
		selector: "cms-data-grid",
		inputs: {
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			columnMenu: {
				classPropertyName: "columnMenu",
				publicName: "columnMenu",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnsKey: {
				classPropertyName: "columnsKey",
				publicName: "columnsKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			lockedColumns: {
				classPropertyName: "lockedColumns",
				publicName: "lockedColumns",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			striped: {
				classPropertyName: "striped",
				publicName: "striped",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actionsHeader: {
				classPropertyName: "actionsHeader",
				publicName: "actionsHeader",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actionsWidth: {
				classPropertyName: "actionsWidth",
				publicName: "actionsWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowLabel: {
				classPropertyName: "rowLabel",
				publicName: "rowLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			activateLabel: {
				classPropertyName: "activateLabel",
				publicName: "activateLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectable: {
				classPropertyName: "selectable",
				publicName: "selectable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sorts: {
				classPropertyName: "sorts",
				publicName: "sorts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowTone: {
				classPropertyName: "rowTone",
				publicName: "rowTone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			trackBy: {
				classPropertyName: "trackBy",
				publicName: "trackBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			focusKey: {
				classPropertyName: "focusKey",
				publicName: "focusKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			sortChange: "sortChange",
			rowActivate: "rowActivate",
			cellCopy: "cellCopy",
			pageStep: "pageStep",
			rowToggle: "rowToggle",
			selectAll: "selectAll"
		},
		viewQueries: [{
			propertyName: "body",
			first: true,
			predicate: ["body"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<!--\n  A real <table>, not a div grid. Semantics come free (row/column relationships announced, headers\n  associated with cells), and the design system already styles `scoular-table`.\n\n  `tabindex=\"0\"` on every row rather than a roving tabindex: the grid is one page of at most 200 rows\n  (ContractListQuery.MaxPageSize), so the simpler model costs nothing and cannot desynchronise from\n  the focused row the way a roving index can.\n\n  The rounded, bordered wrapper is what makes the table read as one surface in dark mode. Without it\n  the striped rows run into the page background and the grid loses its edges. Square corners were\n  tried on 2026-08-25 and reverted the same day — rounded reads better against the page.\n-->\n<!--\n  The Columns menu (JFrisbie, 2026-10-23): on every standard grid, right-aligned above it. A grid of\n  one column has nothing to choose. Home turns it off and keeps its own trade-unit menu.\n-->\n@if (columnMenu() && columns().length > 1) {\n  <div class=\"cws:mb-2 cws:flex cws:justify-end\">\n    <cms-grid-column-menu\n      [fields]=\"columnChoice.fields()\"\n      [lockedKeys]=\"lockedColumns()\"\n      [keptIn]=\"columnChoice.keptIn()\"\n      [failure]=\"columnChoice.failure()\"\n      resetLabel=\"Show every column\"\n      (fieldsChange)=\"columnChoice.change($event)\"\n      (reset)=\"columnChoice.reset()\"\n    />\n  </div>\n}\n<div\n  class=\"cws:overflow-x-auto cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-900 cws:dark:shadow-none\"\n>\n  <!--\n    `table-fixed` is load-bearing, not tidiness. `text-overflow: ellipsis` needs a cell whose width\n    does not depend on its content, so auto layout — which sizes columns to the longest value — can\n    never truncate. Fixed layout is also what makes a dragged width stick instead of being\n    recalculated from the text.\n\n    The consequence to know about: every column takes its declared width and content no longer\n    influences it, so a column with no width falls back to DEFAULT_COLUMN_WIDTH rather than sizing\n    itself.\n  -->\n  <!--\n    **Never `scoular-table-striped`, even when `striped` is on.**\n\n    `.scoular-table-striped tbody tr:nth-child(even)` has specificity (0,2,2); a Tailwind background\n    utility like `.bg-scoular-red\\/5` has (0,1,0). So that class beat the row tint on every *even*\n    row — half the rejected and unapproved contracts showed no tint at all — and because it is\n    declared after the design system's own `tbody tr:hover`, even rows did not highlight on hover\n    either. Raising the tint's specificity would then have had to beat hover as well, which is a\n    fight with no end.\n\n    ⚠ **Striping returned as an opt-in input** (JFrisbie, 2026-09-14) and is emitted from\n    `rowClassFor`, where tone, hover, focus and selection are already arbitrated — so the stripe can\n    be made to lose to all of them by simply not being emitted.\n\n    ⚠ **This comment used to end \"a grid using tones must not stripe\". That is now too strong** — the\n    workspace grid stripes with tones on measured evidence (2026-09-15). The tone still always wins,\n    and the two remain distinguishable because the stripe is *cool* and both tints are *warm*. See\n    the `striped` input for the two conditions a grid has to meet before combining them.\n\n    Rows remain separable without it via the `divide-y` borders the design system already applies,\n    which is why `striped` defaults to off.\n  -->\n  <table class=\"scoular-table scoular-table-compact cws:table-fixed\" [attr.aria-label]=\"label()\">\n    <colgroup>\n      @for (column of widths(); track column.key) {\n        <col [style.width.px]=\"column.width\" />\n      }\n      <!--\n        The actions column's width. Needed here as well as on the cells because the table is\n        `table-fixed`, so the colgroup is what sizes it — without this the browser divides the\n        remaining space and the buttons wrap.\n      -->\n      @if (hasActions()) {\n        <col [style.width.px]=\"actionsWidth()\" />\n      }\n    </colgroup>\n\n    <!--\n      A single firm rule under the header, so the headings read as a separate band from the data.\n      Heavier than the row dividers on purpose: `divide-y` between rows is a hairline, and matching it\n      here would leave the header floating.\n    -->\n    <!--\n      A tinted header band (2026-09-03). It was white on white in light mode, so the only thing\n      separating the column names from the first row of data was the 2px rule underneath — the header\n      read as another row rather than as the table's chrome. Dark mode already had the separation for\n      free, which is why this only shows up in light.\n\n      A `bg-*` on `<thead>` rather than on each `<th>`: one declaration, and it cannot fall out of step\n      with the header hover, which is a `hover:bg-*` on the cell and still wins over this (0,2,0)\n      against (0,1,0).\n    -->\n    <thead class=\"cws:border-b-2 cws:border-slate-300 cws:bg-slate-50 cws:dark:border-slate-600 cws:dark:bg-slate-800/60\">\n      <tr>\n        @for (column of shownColumns(); track column.key) {\n          <!--\n            Hover tints the whole header cell rather than just its text. `group` so the resize handle\n            can reveal itself with the same hover, and `relative` so the handle can sit on the cell's\n            trailing edge.\n\n            Hover lives in `headerClassFor` rather than here, because the sorted and unsorted variants\n            both declare one and only one may be emitted — see SORTED_HEADER_CLASS.\n          -->\n          <th\n            scope=\"col\"\n            class=\"cws:group cws:relative cws:transition-colors\"\n            [class]=\"headerClassFor(column)\"\n            [class.scoular-table-sortable]=\"column.sortable\"\n            [class.cws:text-right]=\"column.align === 'end'\"\n            [attr.aria-sort]=\"column.sortable ? ariaSortFor(column.key) : null\"\n          >\n            <div class=\"truncate\" [class.cws:text-right]=\"column.align === 'end'\">\n              @if (column.sortable) {\n                <!--\n                  A real <button> inside the <th>: the sort must be reachable by Tab and activated by\n                  Enter *and* Space, which a click handler on the <th> gives you neither of.\n                -->\n                <!--\n                  `cursor-pointer` explicitly. `.scoular-table-sortable` already sets it on the\n                  `<th>`, and cursor inherits — but a `<button>` resets it to the default arrow, so\n                  the one part of the header a user actually aims at was the one part not showing a\n                  click pointer. The resize handle keeps its own `cursor-col-resize`.\n                -->\n                <!--\n                  `before:absolute before:inset-0` stretches the button's HIT AREA over the whole\n                  header cell, so clicking anywhere in the tinted box sorts — not just the label and\n                  the arrow (JFrisbie, 2026-08-26). The `<th>`'s own padding and any width left over\n                  after a short label are the parts that used to swallow a click, and\n                  `.scoular-table-sortable` already put a `cursor-pointer` across all of it, so the\n                  cursor was promising a click the hit area did not deliver.\n\n                  Done as a stretched pseudo-element rather than by widening the button or moving the\n                  click onto the `<th>`, and both alternatives are worse:\n                    - `w-full` still cannot cover the `<th>`'s padding, and the design system's\n                      table CSS is unlayered, so that padding cannot be moved onto the button with a\n                      Tailwind utility anyway;\n                    - a handler on the `<th>` is not reachable by Tab and answers neither Enter nor\n                      Space, and it would double-fire when the click landed on the button too.\n\n                  ⚠ Two couplings this depends on, both silent if broken:\n                    1. the overlay anchors to the nearest positioned ancestor, which is the `<th>`\n                       (`relative`). **Do not add `relative` to this button** — the overlay would\n                       shrink back to the button's own box and the hit area would quietly revert.\n                    2. the resize handle carries `z-10` and so stays above the overlay; with\n                       `stopPropagation` in `onResizeStart`, a drag on the trailing edge still\n                       resizes rather than sorting.\n                  Both are pinned by tests, because neither has any visual symptom.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n                -->\n                <button\n                  type=\"button\"\n                  class=\"cws:inline-flex cws:max-w-full cws:cursor-pointer cws:items-center cws:gap-1 truncate cws:font-medium cws:before:absolute cws:before:inset-0 cws:before:content-['']\"\n                  (click)=\"onHeaderActivate(column)\"\n                >\n                  <span class=\"truncate\">{{ column.header }}</span>\n\n                  <!--\n                    A permanent affordance, then the state. An arrow that appears only once a column\n                    is sorted gives no hint that the others can be sorted at all, which is why every\n                    sortable header carries the neutral double arrow until it becomes the active one.\n\n                    aria-hidden throughout: `aria-sort` on the <th> is what assistive technology\n                    reads, and announcing \"up down arrow\" beside every header would be pure noise.\n                  -->\n                  <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-[0.65rem] cws:leading-none\">\n                    @if (ariaSortFor(column.key) === 'ascending') {\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9650;</span>\n                    } @else if (ariaSortFor(column.key) === 'descending') {\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9660;</span>\n                    } @else {\n                      <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">&#8645;</span>\n                    }\n                  </span>\n\n                  <!--\n                    The sort rank, shown only once more than one column is sorted. Without it a\n                    multi-column sort is indistinguishable from the grid ignoring the click that\n                    added the second key — which is exactly what accumulating sorts feels like\n                    otherwise.\n                  -->\n                  @if (sortRankFor(column.key); as rank) {\n                    <span\n                      aria-hidden=\"true\"\n                      class=\"cws:shrink-0 cws:rounded-sm cws:bg-scoular-blue/15 cws:px-1 cws:text-[0.6rem] cws:font-semibold cws:leading-none cws:text-scoular-blue cws:dark:bg-sky-400/20 cws:dark:text-sky-400\"\n                    >\n                      {{ rank }}\n                    </span>\n                  }\n\n                  <!--\n                    The rank for assistive technology. `aria-sort` reports the direction but has no\n                    way to express \"second key\", so without this a screen-reader user hears three\n                    columns each \"sorted descending\" and no order between them.\n                  -->\n                  @if (sortRankFor(column.key); as rank) {\n                    <span class=\"sr-only\">sort {{ rank }} of {{ sorts().length }}</span>\n                  }\n                </button>\n              } @else {\n                {{ column.header }}\n              }\n            </div>\n\n            <!--\n              Column resize handle, on the trailing edge of the header cell.\n\n              A <button> rather than a bare <div>: it has to be focusable and driveable by keyboard,\n              because a mouse-only resize is unavailable to anyone navigating by keyboard (02a §4.3).\n              Arrow keys nudge, Home resets to the caller's width.\n\n              `touch-none` stops the browser scrolling the table instead of reporting the drag on a\n              touch device, which is what makes this work on a laptop trackpad in tablet mode too.\n            -->\n            @if (!$last) {\n              <button\n                type=\"button\"\n                class=\"cws:absolute cws:-right-px cws:top-0 cws:z-10 cws:h-full cws:w-1.5 cws:cursor-col-resize cws:touch-none cws:bg-transparent cws:opacity-0 cws:transition-opacity cws:hover:bg-scoular-blue/40 cws:focus-visible:bg-scoular-blue cws:dark:focus-visible:bg-sky-400 cws:focus-visible:opacity-100 cws:focus-visible:outline-none cws:group-hover:opacity-100 cws:dark:hover:bg-sky-400/40\"\n                [attr.aria-label]=\"'Resize ' + column.header + ' column'\"\n                (pointerdown)=\"onResizeStart($event, column)\"\n                (pointermove)=\"onResizeMove($event, column)\"\n                (pointerup)=\"onResizeEnd()\"\n                (pointercancel)=\"onResizeEnd()\"\n                (keydown)=\"onResizeKeydown($event, column)\"\n              ></button>\n            }\n          </th>\n        }\n\n        <!--\n          The actions heading. Not sortable and carries no resize handle — there is nothing to sort\n          and nothing to measure — so it is a plain `<th>` rather than going through the header\n          button that every data column uses.\n        -->\n        @if (hasActions()) {\n          <!--\n            🔴 **Pinned to the right edge, and this is a correctness point rather than a flourish.**\n\n            The approval queue is 15 columns and ~1900px wide inside an `overflow-x-auto` wrapper, so\n            without `sticky right-0` the buttons sit past the viewport and the primary action on the\n            screen can only be reached by scrolling right past fourteen columns of data. Measured:\n            they rendered off-screen at every width tested.\n\n            `bg-slate-50` matches the header band exactly, because a sticky cell needs its own opaque\n            background or the columns scroll through underneath it. `z-20` clears the resize handles\n            (`z-10`) so a handle cannot be dragged out from under it.\n          -->\n          <!--\n            ⚠ **The height comes from `cellHeightClass`, the same constant every other cell uses**, so\n            this cell cannot end up a different height from the data headers beside it.\n\n            ⚠ **It carried `px-3 py-2` and both were DEAD** (measured 2026-09-15: this cell computes\n            `8px 16px`, i.e. the design system's `px-4 py-2`). `.scoular-table-compact thead th` is\n            unlayered CSS at specificity (0,1,2) and beats a Tailwind utility in `@layer utilities`, so\n            the padding declared here never applied. Removed rather than left asserting something\n            untrue — and note the corollary: **padding is not available as a lever on these cells at\n            all**, which is why the uniform height is a `height`.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n          -->\n          <th\n            scope=\"col\"\n            class=\"cws:sticky cws:right-0 cws:z-20 cws:border-l cws:border-slate-300 cws:bg-slate-50 cws:text-left cws:font-medium cws:dark:border-slate-600 cws:dark:bg-slate-800\"\n            [class]=\"cellHeightClass\"\n          >\n            {{ actionsHeader() }}\n          </th>\n        }\n      </tr>\n    </thead>\n\n    <tbody #body (focusout)=\"onBodyFocusOut()\">\n      @for (row of rows(); track trackBy()(row, $index); let index = $index) {\n        <!--\n          The tint is on the <tr> so it covers every cell. Hover is declared here rather than left to\n          the design system's own `tbody tr:hover`, because a tinted row needs a hover that is\n          brighter than its tint — otherwise the row a user is pointing at is the one that stops\n          responding.\n        -->\n        <!--\n          ⚠ **`dblclick`, not `click`** (2026-08-27). A single click now selects the cell under it, and\n          the two cannot both be true: a click that activates the row cannot leave a highlighted cell\n          behind to look at. Enter still activates, so the keyboard path is unchanged.\n        -->\n        <!--\n          Hover, focus, tone and selection all resolve in `rowClassFor` rather than being layered here,\n          because the tone tint and the selection tint are both plain `bg-*` on this element and the\n          winner would otherwise depend on stylesheet order. See that method for which wins and why.\n\n          `(focus)` selects the first column when focus lands on a row with nothing selected in it —\n          which is what makes **Tab** land on a cell rather than on a bare row.\n        -->\n        <tr\n          tabindex=\"0\"\n          class=\"cws:cursor-pointer cws:transition-colors\"\n          [class]=\"rowClassFor(row, index)\"\n          (focus)=\"onRowFocus(row)\"\n          (focusin)=\"onRowFocusIn(row)\"\n          (keydown)=\"onRowKeydown($event, row, index)\"\n          (dblclick)=\"rowActivate.emit(row)\"\n        >\n          @for (column of shownColumns(); track column.key) {\n            <!--\n              `truncate` on every cell: one uniform row height is the point, so a long value is cut\n              with an ellipsis rather than wrapping and making its row taller than its neighbours. The\n              `title` carries the full text so nothing is unreachable — see GridColumn.tooltip for why\n              that is a convenience and not an accessibility answer.\n            -->\n            <!--\n              Cell hover and cell selection (JFrisbie, 2026-08-27).\n\n              **Hover is one step darker than the row's**, so pointing at a cell reads as \"this cell,\n              within this highlighted row\" rather than as a second, competing row highlight. The cell's\n              background paints over the row's because it is the inner element — no specificity contest,\n              and it deliberately covers the row *tint* for that one cell too.\n\n              **Selection is carried by the OUTLINE, not the background**, and that is on purpose:\n              `hover:bg-*` is a class-plus-pseudo-class (0,2,0) and beats a plain `bg-*` (0,1,0), so\n              hovering the selected cell repaints its background. The outline is untouched by hover, so\n              the selected cell stays identifiable while still giving hover feedback. Swapping the cue\n              to a background would make the selection vanish under the pointer.\n\n              `-outline-offset-2` draws the outline inside the cell, so it is not clipped by the\n              neighbouring cell or by the scroll container at the row's edges.\n\n              `data-cell-key` is how the component finds a keyboard-selected cell to scroll into view —\n              focus stays on the `<tr>`, so the browser will not do it.\n\n              🔴 `tabular-nums` on the end-aligned columns (2026-09-03). The model's own remarks say\n              these columns right-align \"so digits line up down the column, which is what makes a\n              column of figures scannable\" — and right-alignment alone does not deliver that in a\n              proportional font, where 1 is narrower than 8: 14,000 over 29,500 put its thousands\n              separator in a different place on each row.\n\n              Tied to `align === 'end'` rather than listed per column, so it cannot fall out of step —\n              the columns that right-align are exactly the numeric and date ones.\n            -->\n            <td\n              class=\"truncate cws:transition-colors cws:hover:bg-slate-200 cws:dark:hover:bg-slate-600/60\"\n              [attr.data-cell-key]=\"column.key\"\n              [class.cws:text-right]=\"column.align === 'end'\"\n              [class.cws:tabular-nums]=\"column.align === 'end'\"\n              [class]=\"cellClassFor(row, column)\"\n              (mousedown)=\"onCellMousedown(row, index, column)\"\n            >\n              @if (column.cell; as cellComponent) {\n                <!--\n                  A column that paints its own cell (F4.3b). The component gets the row and nothing\n                  else; `format` still decides what sorting, filtering and CSV read, so a component\n                  changes what is painted and never what the grid knows.\n                -->\n                <ng-container *ngComponentOutlet=\"cellComponent; inputs: { row: row }\" />\n              } @else if (badgeLabelFor(column, row); as badgeLabel) {\n                <!--\n                  The tone-to-class mapping lives in `cms-status-badge` (2026-09-16). It was one of\n                  three copies of the same five strings, and the copy that had dark-mode colours was\n                  the one in the shell's identity menu, so the grid's neutral pill did not.\n                -->\n                <cms-status-badge [tone]=\"badgeToneFor(column, row)!\" [small]=\"true\">\n                  {{ badgeLabel }}\n                </cms-status-badge>\n              } @else {\n                <span [attr.title]=\"titleFor(column, row) || null\">{{ column.format(row) }}</span>\n              }\n            </td>\n          }\n\n          <!--\n            🔴 The actions cell, and the two guards on it are load-bearing — each proven by a control\n            test that goes red without it.\n\n              • `(dblclick)` stopped: **the row** is double-click-to-activate. A double press — which\n                is exactly what someone does when a button appears not to have worked — would\n                otherwise navigate off the queue in the middle of the action it had just started.\n              • `(keydown)` stopped for Enter and Space: the row treats Enter as activate, and a\n                `<button>` fires `click` on both keys, so a keyboard user would do the action *and*\n                navigate.\n\n            ⚠ **There is deliberately NO `mousedown` guard, and the reason is worth recording because\n            the opposite looks obviously right.** Cell selection is bound per data `<td>`\n            (`onCellMousedown` on each one), not on the row — so a mousedown inside this cell reaches\n            no selection handler at all and a guard here would be a no-op. A first version had one,\n            with a comment calling it load-bearing; the control test for it passed with the guard\n            removed, which is what exposed the claim as false.\n\n            ⚠ This `<td>` also deliberately does not carry `data-cell-key`, the hover class or the\n            selection class. It is not a value, so it must not join cell selection or Ctrl+C —\n            copying a cell whose content is two buttons would put an empty string on the clipboard\n            and read as a broken copy.\n          -->\n          @if (hasActions()) {\n            <!--\n              ⚠ **`px-3 py-1` was here and both were DEAD**, overridden by\n              `.scoular-table-compact tbody td`'s `px-4 py-2` — unlayered CSS, so a Tailwind utility\n              cannot win. Measured 2026-09-15: this cell computed `8px 16px`, not `4px 12px`.\n\n              🔑 **That dead `py-1` is why the rows were ~6px taller than the header.** The Review\n              button is a 26px `scoular-btn-sm`, and with the design system supplying 16px of vertical\n              padding instead of the 8px this asked for, the cell measured **43.5px** while every\n              other cell in the grid topped out at 36px.\n\n              ⚠ **This cell is still the tallest thing in the table, and that is what set the\n              standard's floor.** Its 43.5px requirement is intrinsic — measured identical with and\n              without a declared height — so `cellHeightClass` is **44px**, the smallest value that\n              clears it. Do not lower it without shrinking this button first; see\n              `CELL_HEIGHT_CLASS`.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n            -->\n            <td\n              class=\"cws:sticky cws:right-0 cws:z-10 cws:border-l cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-900\"\n              [class]=\"cellHeightClass\"\n              (dblclick)=\"$event.stopPropagation()\"\n              (keydown)=\"onActionKeydown($event)\"\n            >\n              <!--\n                #816 (JFrisbie, 2026-10-13): one menu per row in place of a button per action, as\n                docs/02a §4.3 described. The menu is `cms-row-menu` (#825), shared with the admin\n                tables; its overlay is positioned against the viewport, which matters in this cell: it\n                is sticky inside a horizontally scrolled wrapper, which would clip a panel drawn in it.\n              -->\n              @if (actionsFor(row).length > 0) {<cms-row-menu [row]=\"row\" [actions]=\"actionsFor(row)\" [label]=\"'Actions for ' + rowNameFor(row, index)\" />}\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</div>\n\n",
		dependencies: [
			{
				kind: "component",
				type: GridColumnMenuComponent,
				selector: "cms-grid-column-menu",
				inputs: [
					"fields",
					"lockedKeys",
					"keptIn",
					"failure",
					"disabled",
					"resetLabel"
				],
				outputs: ["fieldsChange", "reset"]
			},
			{
				kind: "directive",
				type: NgComponentOutlet,
				selector: "[ngComponentOutlet]",
				inputs: [
					"ngComponentOutlet",
					"ngComponentOutletInputs",
					"ngComponentOutletInjector",
					"ngComponentOutletEnvironmentInjector",
					"ngComponentOutletContent",
					"ngComponentOutletNgModule"
				],
				exportAs: ["ngComponentOutlet"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusBadgeComponent,
				selector: "cms-status-badge",
				inputs: ["tone", "small"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DataGridComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-data-grid",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				GridColumnMenuComponent,
				NgComponentOutlet,
				RowMenuComponent,
				StatusBadgeComponent
			],
			template: "<!--\n  A real <table>, not a div grid. Semantics come free (row/column relationships announced, headers\n  associated with cells), and the design system already styles `scoular-table`.\n\n  `tabindex=\"0\"` on every row rather than a roving tabindex: the grid is one page of at most 200 rows\n  (ContractListQuery.MaxPageSize), so the simpler model costs nothing and cannot desynchronise from\n  the focused row the way a roving index can.\n\n  The rounded, bordered wrapper is what makes the table read as one surface in dark mode. Without it\n  the striped rows run into the page background and the grid loses its edges. Square corners were\n  tried on 2026-08-25 and reverted the same day — rounded reads better against the page.\n-->\n<!--\n  The Columns menu (JFrisbie, 2026-10-23): on every standard grid, right-aligned above it. A grid of\n  one column has nothing to choose. Home turns it off and keeps its own trade-unit menu.\n-->\n@if (columnMenu() && columns().length > 1) {\n  <div class=\"cws:mb-2 cws:flex cws:justify-end\">\n    <cms-grid-column-menu\n      [fields]=\"columnChoice.fields()\"\n      [lockedKeys]=\"lockedColumns()\"\n      [keptIn]=\"columnChoice.keptIn()\"\n      [failure]=\"columnChoice.failure()\"\n      resetLabel=\"Show every column\"\n      (fieldsChange)=\"columnChoice.change($event)\"\n      (reset)=\"columnChoice.reset()\"\n    />\n  </div>\n}\n<div\n  class=\"cws:overflow-x-auto cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-900 cws:dark:shadow-none\"\n>\n  <!--\n    `table-fixed` is load-bearing, not tidiness. `text-overflow: ellipsis` needs a cell whose width\n    does not depend on its content, so auto layout — which sizes columns to the longest value — can\n    never truncate. Fixed layout is also what makes a dragged width stick instead of being\n    recalculated from the text.\n\n    The consequence to know about: every column takes its declared width and content no longer\n    influences it, so a column with no width falls back to DEFAULT_COLUMN_WIDTH rather than sizing\n    itself.\n  -->\n  <!--\n    **Never `scoular-table-striped`, even when `striped` is on.**\n\n    `.scoular-table-striped tbody tr:nth-child(even)` has specificity (0,2,2); a Tailwind background\n    utility like `.bg-scoular-red\\/5` has (0,1,0). So that class beat the row tint on every *even*\n    row — half the rejected and unapproved contracts showed no tint at all — and because it is\n    declared after the design system's own `tbody tr:hover`, even rows did not highlight on hover\n    either. Raising the tint's specificity would then have had to beat hover as well, which is a\n    fight with no end.\n\n    ⚠ **Striping returned as an opt-in input** (JFrisbie, 2026-09-14) and is emitted from\n    `rowClassFor`, where tone, hover, focus and selection are already arbitrated — so the stripe can\n    be made to lose to all of them by simply not being emitted.\n\n    ⚠ **This comment used to end \"a grid using tones must not stripe\". That is now too strong** — the\n    workspace grid stripes with tones on measured evidence (2026-09-15). The tone still always wins,\n    and the two remain distinguishable because the stripe is *cool* and both tints are *warm*. See\n    the `striped` input for the two conditions a grid has to meet before combining them.\n\n    Rows remain separable without it via the `divide-y` borders the design system already applies,\n    which is why `striped` defaults to off.\n  -->\n  <table class=\"scoular-table scoular-table-compact cws:table-fixed\" [attr.aria-label]=\"label()\">\n    <colgroup>\n      @for (column of widths(); track column.key) {\n        <col [style.width.px]=\"column.width\" />\n      }\n      <!--\n        The actions column's width. Needed here as well as on the cells because the table is\n        `table-fixed`, so the colgroup is what sizes it — without this the browser divides the\n        remaining space and the buttons wrap.\n      -->\n      @if (hasActions()) {\n        <col [style.width.px]=\"actionsWidth()\" />\n      }\n    </colgroup>\n\n    <!--\n      A single firm rule under the header, so the headings read as a separate band from the data.\n      Heavier than the row dividers on purpose: `divide-y` between rows is a hairline, and matching it\n      here would leave the header floating.\n    -->\n    <!--\n      A tinted header band (2026-09-03). It was white on white in light mode, so the only thing\n      separating the column names from the first row of data was the 2px rule underneath — the header\n      read as another row rather than as the table's chrome. Dark mode already had the separation for\n      free, which is why this only shows up in light.\n\n      A `bg-*` on `<thead>` rather than on each `<th>`: one declaration, and it cannot fall out of step\n      with the header hover, which is a `hover:bg-*` on the cell and still wins over this (0,2,0)\n      against (0,1,0).\n    -->\n    <thead class=\"cws:border-b-2 cws:border-slate-300 cws:bg-slate-50 cws:dark:border-slate-600 cws:dark:bg-slate-800/60\">\n      <tr>\n        @for (column of shownColumns(); track column.key) {\n          <!--\n            Hover tints the whole header cell rather than just its text. `group` so the resize handle\n            can reveal itself with the same hover, and `relative` so the handle can sit on the cell's\n            trailing edge.\n\n            Hover lives in `headerClassFor` rather than here, because the sorted and unsorted variants\n            both declare one and only one may be emitted — see SORTED_HEADER_CLASS.\n          -->\n          <th\n            scope=\"col\"\n            class=\"cws:group cws:relative cws:transition-colors\"\n            [class]=\"headerClassFor(column)\"\n            [class.scoular-table-sortable]=\"column.sortable\"\n            [class.cws:text-right]=\"column.align === 'end'\"\n            [attr.aria-sort]=\"column.sortable ? ariaSortFor(column.key) : null\"\n          >\n            <div class=\"truncate\" [class.cws:text-right]=\"column.align === 'end'\">\n              @if (column.sortable) {\n                <!--\n                  A real <button> inside the <th>: the sort must be reachable by Tab and activated by\n                  Enter *and* Space, which a click handler on the <th> gives you neither of.\n                -->\n                <!--\n                  `cursor-pointer` explicitly. `.scoular-table-sortable` already sets it on the\n                  `<th>`, and cursor inherits — but a `<button>` resets it to the default arrow, so\n                  the one part of the header a user actually aims at was the one part not showing a\n                  click pointer. The resize handle keeps its own `cursor-col-resize`.\n                -->\n                <!--\n                  `before:absolute before:inset-0` stretches the button's HIT AREA over the whole\n                  header cell, so clicking anywhere in the tinted box sorts — not just the label and\n                  the arrow (JFrisbie, 2026-08-26). The `<th>`'s own padding and any width left over\n                  after a short label are the parts that used to swallow a click, and\n                  `.scoular-table-sortable` already put a `cursor-pointer` across all of it, so the\n                  cursor was promising a click the hit area did not deliver.\n\n                  Done as a stretched pseudo-element rather than by widening the button or moving the\n                  click onto the `<th>`, and both alternatives are worse:\n                    - `w-full` still cannot cover the `<th>`'s padding, and the design system's\n                      table CSS is unlayered, so that padding cannot be moved onto the button with a\n                      Tailwind utility anyway;\n                    - a handler on the `<th>` is not reachable by Tab and answers neither Enter nor\n                      Space, and it would double-fire when the click landed on the button too.\n\n                  ⚠ Two couplings this depends on, both silent if broken:\n                    1. the overlay anchors to the nearest positioned ancestor, which is the `<th>`\n                       (`relative`). **Do not add `relative` to this button** — the overlay would\n                       shrink back to the button's own box and the hit area would quietly revert.\n                    2. the resize handle carries `z-10` and so stays above the overlay; with\n                       `stopPropagation` in `onResizeStart`, a drag on the trailing edge still\n                       resizes rather than sorting.\n                  Both are pinned by tests, because neither has any visual symptom.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n                -->\n                <button\n                  type=\"button\"\n                  class=\"cws:inline-flex cws:max-w-full cws:cursor-pointer cws:items-center cws:gap-1 truncate cws:font-medium cws:before:absolute cws:before:inset-0 cws:before:content-['']\"\n                  (click)=\"onHeaderActivate(column)\"\n                >\n                  <span class=\"truncate\">{{ column.header }}</span>\n\n                  <!--\n                    A permanent affordance, then the state. An arrow that appears only once a column\n                    is sorted gives no hint that the others can be sorted at all, which is why every\n                    sortable header carries the neutral double arrow until it becomes the active one.\n\n                    aria-hidden throughout: `aria-sort` on the <th> is what assistive technology\n                    reads, and announcing \"up down arrow\" beside every header would be pure noise.\n                  -->\n                  <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-[0.65rem] cws:leading-none\">\n                    @if (ariaSortFor(column.key) === 'ascending') {\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9650;</span>\n                    } @else if (ariaSortFor(column.key) === 'descending') {\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9660;</span>\n                    } @else {\n                      <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">&#8645;</span>\n                    }\n                  </span>\n\n                  <!--\n                    The sort rank, shown only once more than one column is sorted. Without it a\n                    multi-column sort is indistinguishable from the grid ignoring the click that\n                    added the second key — which is exactly what accumulating sorts feels like\n                    otherwise.\n                  -->\n                  @if (sortRankFor(column.key); as rank) {\n                    <span\n                      aria-hidden=\"true\"\n                      class=\"cws:shrink-0 cws:rounded-sm cws:bg-scoular-blue/15 cws:px-1 cws:text-[0.6rem] cws:font-semibold cws:leading-none cws:text-scoular-blue cws:dark:bg-sky-400/20 cws:dark:text-sky-400\"\n                    >\n                      {{ rank }}\n                    </span>\n                  }\n\n                  <!--\n                    The rank for assistive technology. `aria-sort` reports the direction but has no\n                    way to express \"second key\", so without this a screen-reader user hears three\n                    columns each \"sorted descending\" and no order between them.\n                  -->\n                  @if (sortRankFor(column.key); as rank) {\n                    <span class=\"sr-only\">sort {{ rank }} of {{ sorts().length }}</span>\n                  }\n                </button>\n              } @else {\n                {{ column.header }}\n              }\n            </div>\n\n            <!--\n              Column resize handle, on the trailing edge of the header cell.\n\n              A <button> rather than a bare <div>: it has to be focusable and driveable by keyboard,\n              because a mouse-only resize is unavailable to anyone navigating by keyboard (02a §4.3).\n              Arrow keys nudge, Home resets to the caller's width.\n\n              `touch-none` stops the browser scrolling the table instead of reporting the drag on a\n              touch device, which is what makes this work on a laptop trackpad in tablet mode too.\n            -->\n            @if (!$last) {\n              <button\n                type=\"button\"\n                class=\"cws:absolute cws:-right-px cws:top-0 cws:z-10 cws:h-full cws:w-1.5 cws:cursor-col-resize cws:touch-none cws:bg-transparent cws:opacity-0 cws:transition-opacity cws:hover:bg-scoular-blue/40 cws:focus-visible:bg-scoular-blue cws:dark:focus-visible:bg-sky-400 cws:focus-visible:opacity-100 cws:focus-visible:outline-none cws:group-hover:opacity-100 cws:dark:hover:bg-sky-400/40\"\n                [attr.aria-label]=\"'Resize ' + column.header + ' column'\"\n                (pointerdown)=\"onResizeStart($event, column)\"\n                (pointermove)=\"onResizeMove($event, column)\"\n                (pointerup)=\"onResizeEnd()\"\n                (pointercancel)=\"onResizeEnd()\"\n                (keydown)=\"onResizeKeydown($event, column)\"\n              ></button>\n            }\n          </th>\n        }\n\n        <!--\n          The actions heading. Not sortable and carries no resize handle — there is nothing to sort\n          and nothing to measure — so it is a plain `<th>` rather than going through the header\n          button that every data column uses.\n        -->\n        @if (hasActions()) {\n          <!--\n            🔴 **Pinned to the right edge, and this is a correctness point rather than a flourish.**\n\n            The approval queue is 15 columns and ~1900px wide inside an `overflow-x-auto` wrapper, so\n            without `sticky right-0` the buttons sit past the viewport and the primary action on the\n            screen can only be reached by scrolling right past fourteen columns of data. Measured:\n            they rendered off-screen at every width tested.\n\n            `bg-slate-50` matches the header band exactly, because a sticky cell needs its own opaque\n            background or the columns scroll through underneath it. `z-20` clears the resize handles\n            (`z-10`) so a handle cannot be dragged out from under it.\n          -->\n          <!--\n            ⚠ **The height comes from `cellHeightClass`, the same constant every other cell uses**, so\n            this cell cannot end up a different height from the data headers beside it.\n\n            ⚠ **It carried `px-3 py-2` and both were DEAD** (measured 2026-09-15: this cell computes\n            `8px 16px`, i.e. the design system's `px-4 py-2`). `.scoular-table-compact thead th` is\n            unlayered CSS at specificity (0,1,2) and beats a Tailwind utility in `@layer utilities`, so\n            the padding declared here never applied. Removed rather than left asserting something\n            untrue — and note the corollary: **padding is not available as a lever on these cells at\n            all**, which is why the uniform height is a `height`.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n          -->\n          <th\n            scope=\"col\"\n            class=\"cws:sticky cws:right-0 cws:z-20 cws:border-l cws:border-slate-300 cws:bg-slate-50 cws:text-left cws:font-medium cws:dark:border-slate-600 cws:dark:bg-slate-800\"\n            [class]=\"cellHeightClass\"\n          >\n            {{ actionsHeader() }}\n          </th>\n        }\n      </tr>\n    </thead>\n\n    <tbody #body (focusout)=\"onBodyFocusOut()\">\n      @for (row of rows(); track trackBy()(row, $index); let index = $index) {\n        <!--\n          The tint is on the <tr> so it covers every cell. Hover is declared here rather than left to\n          the design system's own `tbody tr:hover`, because a tinted row needs a hover that is\n          brighter than its tint — otherwise the row a user is pointing at is the one that stops\n          responding.\n        -->\n        <!--\n          ⚠ **`dblclick`, not `click`** (2026-08-27). A single click now selects the cell under it, and\n          the two cannot both be true: a click that activates the row cannot leave a highlighted cell\n          behind to look at. Enter still activates, so the keyboard path is unchanged.\n        -->\n        <!--\n          Hover, focus, tone and selection all resolve in `rowClassFor` rather than being layered here,\n          because the tone tint and the selection tint are both plain `bg-*` on this element and the\n          winner would otherwise depend on stylesheet order. See that method for which wins and why.\n\n          `(focus)` selects the first column when focus lands on a row with nothing selected in it —\n          which is what makes **Tab** land on a cell rather than on a bare row.\n        -->\n        <tr\n          tabindex=\"0\"\n          class=\"cws:cursor-pointer cws:transition-colors\"\n          [class]=\"rowClassFor(row, index)\"\n          (focus)=\"onRowFocus(row)\"\n          (focusin)=\"onRowFocusIn(row)\"\n          (keydown)=\"onRowKeydown($event, row, index)\"\n          (dblclick)=\"rowActivate.emit(row)\"\n        >\n          @for (column of shownColumns(); track column.key) {\n            <!--\n              `truncate` on every cell: one uniform row height is the point, so a long value is cut\n              with an ellipsis rather than wrapping and making its row taller than its neighbours. The\n              `title` carries the full text so nothing is unreachable — see GridColumn.tooltip for why\n              that is a convenience and not an accessibility answer.\n            -->\n            <!--\n              Cell hover and cell selection (JFrisbie, 2026-08-27).\n\n              **Hover is one step darker than the row's**, so pointing at a cell reads as \"this cell,\n              within this highlighted row\" rather than as a second, competing row highlight. The cell's\n              background paints over the row's because it is the inner element — no specificity contest,\n              and it deliberately covers the row *tint* for that one cell too.\n\n              **Selection is carried by the OUTLINE, not the background**, and that is on purpose:\n              `hover:bg-*` is a class-plus-pseudo-class (0,2,0) and beats a plain `bg-*` (0,1,0), so\n              hovering the selected cell repaints its background. The outline is untouched by hover, so\n              the selected cell stays identifiable while still giving hover feedback. Swapping the cue\n              to a background would make the selection vanish under the pointer.\n\n              `-outline-offset-2` draws the outline inside the cell, so it is not clipped by the\n              neighbouring cell or by the scroll container at the row's edges.\n\n              `data-cell-key` is how the component finds a keyboard-selected cell to scroll into view —\n              focus stays on the `<tr>`, so the browser will not do it.\n\n              🔴 `tabular-nums` on the end-aligned columns (2026-09-03). The model's own remarks say\n              these columns right-align \"so digits line up down the column, which is what makes a\n              column of figures scannable\" — and right-alignment alone does not deliver that in a\n              proportional font, where 1 is narrower than 8: 14,000 over 29,500 put its thousands\n              separator in a different place on each row.\n\n              Tied to `align === 'end'` rather than listed per column, so it cannot fall out of step —\n              the columns that right-align are exactly the numeric and date ones.\n            -->\n            <td\n              class=\"truncate cws:transition-colors cws:hover:bg-slate-200 cws:dark:hover:bg-slate-600/60\"\n              [attr.data-cell-key]=\"column.key\"\n              [class.cws:text-right]=\"column.align === 'end'\"\n              [class.cws:tabular-nums]=\"column.align === 'end'\"\n              [class]=\"cellClassFor(row, column)\"\n              (mousedown)=\"onCellMousedown(row, index, column)\"\n            >\n              @if (column.cell; as cellComponent) {\n                <!--\n                  A column that paints its own cell (F4.3b). The component gets the row and nothing\n                  else; `format` still decides what sorting, filtering and CSV read, so a component\n                  changes what is painted and never what the grid knows.\n                -->\n                <ng-container *ngComponentOutlet=\"cellComponent; inputs: { row: row }\" />\n              } @else if (badgeLabelFor(column, row); as badgeLabel) {\n                <!--\n                  The tone-to-class mapping lives in `cms-status-badge` (2026-09-16). It was one of\n                  three copies of the same five strings, and the copy that had dark-mode colours was\n                  the one in the shell's identity menu, so the grid's neutral pill did not.\n                -->\n                <cms-status-badge [tone]=\"badgeToneFor(column, row)!\" [small]=\"true\">\n                  {{ badgeLabel }}\n                </cms-status-badge>\n              } @else {\n                <span [attr.title]=\"titleFor(column, row) || null\">{{ column.format(row) }}</span>\n              }\n            </td>\n          }\n\n          <!--\n            🔴 The actions cell, and the two guards on it are load-bearing — each proven by a control\n            test that goes red without it.\n\n              • `(dblclick)` stopped: **the row** is double-click-to-activate. A double press — which\n                is exactly what someone does when a button appears not to have worked — would\n                otherwise navigate off the queue in the middle of the action it had just started.\n              • `(keydown)` stopped for Enter and Space: the row treats Enter as activate, and a\n                `<button>` fires `click` on both keys, so a keyboard user would do the action *and*\n                navigate.\n\n            ⚠ **There is deliberately NO `mousedown` guard, and the reason is worth recording because\n            the opposite looks obviously right.** Cell selection is bound per data `<td>`\n            (`onCellMousedown` on each one), not on the row — so a mousedown inside this cell reaches\n            no selection handler at all and a guard here would be a no-op. A first version had one,\n            with a comment calling it load-bearing; the control test for it passed with the guard\n            removed, which is what exposed the claim as false.\n\n            ⚠ This `<td>` also deliberately does not carry `data-cell-key`, the hover class or the\n            selection class. It is not a value, so it must not join cell selection or Ctrl+C —\n            copying a cell whose content is two buttons would put an empty string on the clipboard\n            and read as a broken copy.\n          -->\n          @if (hasActions()) {\n            <!--\n              ⚠ **`px-3 py-1` was here and both were DEAD**, overridden by\n              `.scoular-table-compact tbody td`'s `px-4 py-2` — unlayered CSS, so a Tailwind utility\n              cannot win. Measured 2026-09-15: this cell computed `8px 16px`, not `4px 12px`.\n\n              🔑 **That dead `py-1` is why the rows were ~6px taller than the header.** The Review\n              button is a 26px `scoular-btn-sm`, and with the design system supplying 16px of vertical\n              padding instead of the 8px this asked for, the cell measured **43.5px** while every\n              other cell in the grid topped out at 36px.\n\n              ⚠ **This cell is still the tallest thing in the table, and that is what set the\n              standard's floor.** Its 43.5px requirement is intrinsic — measured identical with and\n              without a declared height — so `cellHeightClass` is **44px**, the smallest value that\n              clears it. Do not lower it without shrinking this button first; see\n              `CELL_HEIGHT_CLASS`.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n            -->\n            <td\n              class=\"cws:sticky cws:right-0 cws:z-10 cws:border-l cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-900\"\n              [class]=\"cellHeightClass\"\n              (dblclick)=\"$event.stopPropagation()\"\n              (keydown)=\"onActionKeydown($event)\"\n            >\n              <!--\n                #816 (JFrisbie, 2026-10-13): one menu per row in place of a button per action, as\n                docs/02a §4.3 described. The menu is `cms-row-menu` (#825), shared with the admin\n                tables; its overlay is positioned against the viewport, which matters in this cell: it\n                is sticky inside a horizontally scrolled wrapper, which would clip a panel drawn in it.\n              -->\n              @if (actionsFor(row).length > 0) {<cms-row-menu [row]=\"row\" [actions]=\"actionsFor(row)\" [label]=\"'Actions for ' + rowNameFor(row, index)\" />}\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</div>\n\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: true
			}]
		}],
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		columnMenu: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnMenu",
				required: false
			}]
		}],
		columnsKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnsKey",
				required: false
			}]
		}],
		lockedColumns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "lockedColumns",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		striped: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "striped",
				required: false
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: false
			}]
		}],
		actionsHeader: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actionsHeader",
				required: false
			}]
		}],
		actionsWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actionsWidth",
				required: false
			}]
		}],
		rowLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowLabel",
				required: false
			}]
		}],
		activateLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activateLabel",
				required: false
			}]
		}],
		selectable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectable",
				required: false
			}]
		}],
		sorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sorts",
				required: false
			}]
		}],
		rowTone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowTone",
				required: false
			}]
		}],
		trackBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trackBy",
				required: false
			}]
		}],
		focusKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "focusKey",
				required: false
			}]
		}],
		sortChange: [{
			type: i0.Output,
			args: ["sortChange"]
		}],
		rowActivate: [{
			type: i0.Output,
			args: ["rowActivate"]
		}],
		cellCopy: [{
			type: i0.Output,
			args: ["cellCopy"]
		}],
		pageStep: [{
			type: i0.Output,
			args: ["pageStep"]
		}],
		rowToggle: [{
			type: i0.Output,
			args: ["rowToggle"]
		}],
		selectAll: [{
			type: i0.Output,
			args: ["selectAll"]
		}],
		body: [{
			type: i0.ViewChild,
			args: ["body", { isSignal: true }]
		}]
	}
});
function toCsv(columns, rows) {
	return [columns.map((column) => escapeCell(column.header)), ...rows.map((row) => columns.map((column) => escapeCell(column.format(row))))].map((cells) => cells.join(",")).join("\r\n");
}
function escapeCell(value) {
	const guarded = /^[=+\-@\t\r]/.test(value) ? `\t${value}` : value;
	return /[",\r\n]|^\s|\s$/.test(guarded) ? `"${guarded.replace(/"/g, "\"\"")}"` : guarded;
}
function downloadCsv(filename, csv) {
	downloadBlob(filename, new Blob([`﻿${csv}`], { type: "text/csv;charset=utf-8" }));
}
function downloadBlob(filename, blob) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
var PagerComponent = class PagerComponent {
	page = input.required(...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	totalPages = input.required(...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	position = input.required(...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	goTo = output();
	canPrevious = computed(() => this.page() > 1, ...ngDevMode ? [{ debugName: "canPrevious" }] : /* istanbul ignore next */ []);
	canNext = computed(() => this.page() < this.totalPages(), ...ngDevMode ? [{ debugName: "canNext" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PagerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PagerComponent,
		isStandalone: true,
		selector: "cms-pager",
		inputs: {
			page: {
				classPropertyName: "page",
				publicName: "page",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			totalPages: {
				classPropertyName: "totalPages",
				publicName: "totalPages",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { goTo: "goTo" },
		ngImport: i0,
		template: `
    <!--
      A nav landmark with a label, because there are two of these on the page: assistive technology
      announces "Pagination, top" and "Pagination, bottom" rather than two identical unnamed regions.
    -->
    <nav class="cws:flex cws:items-center cws:gap-1" [attr.aria-label]="'Pagination ' + position()">
      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="First page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(1)"
      >
        <span aria-hidden="true">&laquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Previous page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(page() - 1)"
      >
        <span aria-hidden="true">&lsaquo;</span>
      </button>

      <!--
        leading-none plus the flex container's items-center is what actually centres this against the
        38px buttons. Left to its own line-height the text sits a pixel or two high, which is the kind
        of misalignment you cannot unsee once noticed.

        aria-live="polite" so a screen reader hears the new position after a page change — the button
        that was activated does not itself announce where you landed.

        (No backticks in this comment on purpose: the template is a template literal, and a backtick
        here terminates it. That cost one broken build.)
      -->
      <span
        class="cws:px-3 cws:text-sm cws:leading-none cws:whitespace-nowrap cws:text-slate-700 cws:dark:text-slate-300"
        aria-live="polite"
      >
        Page {{ page() }} of {{ totalPages() }}
      </span>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Next page"
        [disabled]="!canNext()"
        (click)="goTo.emit(page() + 1)"
      >
        <span aria-hidden="true">&rsaquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Last page"
        [disabled]="!canNext()"
        (click)="goTo.emit(totalPages())"
      >
        <span aria-hidden="true">&raquo;</span>
      </button>
    </nav>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PagerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pager",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <!--
      A nav landmark with a label, because there are two of these on the page: assistive technology
      announces "Pagination, top" and "Pagination, bottom" rather than two identical unnamed regions.
    -->
    <nav class="cws:flex cws:items-center cws:gap-1" [attr.aria-label]="'Pagination ' + position()">
      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="First page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(1)"
      >
        <span aria-hidden="true">&laquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Previous page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(page() - 1)"
      >
        <span aria-hidden="true">&lsaquo;</span>
      </button>

      <!--
        leading-none plus the flex container's items-center is what actually centres this against the
        38px buttons. Left to its own line-height the text sits a pixel or two high, which is the kind
        of misalignment you cannot unsee once noticed.

        aria-live="polite" so a screen reader hears the new position after a page change — the button
        that was activated does not itself announce where you landed.

        (No backticks in this comment on purpose: the template is a template literal, and a backtick
        here terminates it. That cost one broken build.)
      -->
      <span
        class="cws:px-3 cws:text-sm cws:leading-none cws:whitespace-nowrap cws:text-slate-700 cws:dark:text-slate-300"
        aria-live="polite"
      >
        Page {{ page() }} of {{ totalPages() }}
      </span>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Next page"
        [disabled]="!canNext()"
        (click)="goTo.emit(page() + 1)"
      >
        <span aria-hidden="true">&rsaquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Last page"
        [disabled]="!canNext()"
        (click)="goTo.emit(totalPages())"
      >
        <span aria-hidden="true">&raquo;</span>
      </button>
    </nav>
  `
		}]
	}],
	propDecorators: {
		page: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "page",
				required: true
			}]
		}],
		totalPages: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "totalPages",
				required: true
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: true
			}]
		}],
		goTo: [{
			type: i0.Output,
			args: ["goTo"]
		}]
	}
});
var GridExportComponent = class GridExportComponent {
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	visibleKeys = input(null, ...ngDevMode ? [{ debugName: "visibleKeys" }] : /* istanbul ignore next */ []);
	pageRows = input.required(...ngDevMode ? [{ debugName: "pageRows" }] : /* istanbul ignore next */ []);
	totalCount = input.required(...ngDevMode ? [{ debugName: "totalCount" }] : /* istanbul ignore next */ []);
	allRows = input.required(...ngDevMode ? [{ debugName: "allRows" }] : /* istanbul ignore next */ []);
	filename = input.required(...ngDevMode ? [{ debugName: "filename" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	serverExport = input(null, ...ngDevMode ? [{ debugName: "serverExport" }] : /* istanbul ignore next */ []);
	completed = output();
	failed = output();
	scope = signal(null, ...ngDevMode ? [{ debugName: "scope" }] : /* istanbul ignore next */ []);
	fields = signal([], ...ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	canExport = computed(() => includedExportFieldCount(this.fields()) > 0, ...ngDevMode ? [{ debugName: "canExport" }] : /* istanbul ignore next */ []);
	onToggle() {
		this.scope.set(null);
	}
	onPickScope(scope) {
		this.fields.set(exportFieldsFor(this.columns(), this.visibleKeys()));
		this.scope.set(scope);
	}
	onBack() {
		this.scope.set(null);
	}
	onFieldsChange(fields) {
		this.fields.set(fields);
	}
	run() {
		const scope = this.scope();
		if (scope === "page") this.exportPage();
		else if (scope === "all") this.exportAll();
	}
	selectedColumns() {
		return applyExportFields(this.columns(), this.fields());
	}
	exportPage() {
		if (!this.canExport()) return;
		this.failed.emit(null);
		downloadCsv(`${this.filename()("page")}.csv`, toCsv(this.selectedColumns(), this.pageRows()));
		this.completed.emit({
			ran: "screen",
			scope: "page",
			rows: this.pageRows().length,
			reason: null
		});
	}
	async exportAll() {
		if (this.busy() || !this.canExport()) return;
		this.busy.set(true);
		this.failed.emit(null);
		try {
			const server = this.serverExport();
			let reason = null;
			if (server !== null) {
				const outcome = await server("all", this.selectedColumns().map((column) => column.key));
				if (outcome.ran === "server") {
					this.completed.emit({
						ran: "server",
						scope: "all",
						rows: this.totalCount(),
						reason: null
					});
					return;
				}
				if (outcome.ran === "failed") {
					this.failed.emit(outcome.message);
					return;
				}
				reason = outcome.reason;
			}
			const rows = await this.allRows()();
			if (rows === null) {
				this.failed.emit("We could not export every page. Nothing was downloaded.");
				return;
			}
			downloadCsv(`${this.filename()("all")}.csv`, toCsv(this.selectedColumns(), rows));
			this.completed.emit({
				ran: "screen",
				scope: "all",
				rows: rows.length,
				reason
			});
		} catch {
			this.failed.emit("The export could not be completed. Nothing was downloaded.");
		} finally {
			this.busy.set(false);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GridExportComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: GridExportComponent,
		isStandalone: true,
		selector: "cms-grid-export",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			visibleKeys: {
				classPropertyName: "visibleKeys",
				publicName: "visibleKeys",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pageRows: {
				classPropertyName: "pageRows",
				publicName: "pageRows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			totalCount: {
				classPropertyName: "totalCount",
				publicName: "totalCount",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			allRows: {
				classPropertyName: "allRows",
				publicName: "allRows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			filename: {
				classPropertyName: "filename",
				publicName: "filename",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			serverExport: {
				classPropertyName: "serverExport",
				publicName: "serverExport",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			completed: "completed",
			failed: "failed"
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<!--\n  🔴 The directive goes on a wrapper that contains BOTH the trigger and the panel, never on the\n  button. Its outside-click check is `host.contains(event.target)`, so with the directive on the\n  button every click *inside* the panel would read as outside and close it — the field picker would\n  shut on its first checkbox.\n-->\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative\">\n  <!--\n    The trigger. `scoular-btn-secondary` rather than a size variant, so the box model matches the\n    refresh button and the pager beside it: all three are `px-4 py-2 text-sm` with a 1px border,\n    which is what keeps them the same height without a hard-coded pixel value that would drift when\n    the design system changes its own padding.\n  -->\n  <button\n    type=\"button\"\n    class=\"scoular-btn scoular-btn-secondary\"\n    [disabled]=\"disabled() || busy()\"\n    [attr.aria-expanded]=\"menu.open()\"\n    aria-haspopup=\"menu\"\n    (click)=\"menu.toggle(); onToggle()\"\n  >\n    <!--\n      An inline SVG rather than a glyph: the arrow-out-of-tray mark is the conventional \"export\"\n      icon and no single Unicode character carries it. `currentColor` so it inherits the button's\n      text colour in both themes, and aria-hidden because the button already says what it does.\n    -->\n    <svg\n      aria-hidden=\"true\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      class=\"cws:size-4 cws:shrink-0\"\n    >\n      <path d=\"M12 15V3\" />\n      <path d=\"m8 7 4-4 4 4\" />\n      <path d=\"M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4\" />\n    </svg>\n    {{ busy() ? 'Exporting…' : 'Export data' }}\n    <span aria-hidden=\"true\" class=\"cws:text-xs\">{{ menu.open() ? '▲' : '▼' }}</span>\n  </button>\n\n  @if (menu.open()) {\n    <!--\n      🔴 A GROUP, not a `role=\"menu\"`, and the change is required rather than cosmetic. A menu's\n      children must be `menuitem`s, and the second step holds checkboxes, reorder buttons and\n      draggable rows — announcing those as menu items tells a screen-reader user they are about to\n      activate a command when they are about to toggle a field. The export actions are still\n      buttons; they simply are not menu items any more.\n\n      ⚠ The role stays `group` on BOTH steps even though step one is only two buttons and would\n      qualify as a menu. Switching role with the step would change what a screen reader announces\n      part-way through one gesture, which is worse than the slightly loose fit.\n    -->\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\" role=\"group\" aria-label=\"Export\">\n      @if (scope() === null) {\n        <div class=\"scoular-dropdown-header\">Export as CSV</div>\n\n        <!--\n          🔴 SCOPE FIRST, fields second. The two scopes differ by orders of magnitude in cost on the\n          workspace — the current page is already in memory, every page is one CTRM read per 200\n          rows — so that is the choice every export has to make, and it is asked on its own. The\n          field picker is a refinement most exports do not need, and putting it first made every\n          export pay for it.\n\n          The row counts stay in the labels: the choice is made with the numbers visible.\n        -->\n        <!--\n          `text-left` on the item is load-bearing. `.scoular-dropdown-item` is a `<button>`, and a\n          button inherits `text-align: center` — so a subtext short enough to fit looked fine while\n          the longer one *wrapped* and centred its second line. `items-start` does not fix that: it\n          aligns the flex children, not the text inside a child that wraps.\n        -->\n        <button type=\"button\" class=\"scoular-dropdown-item cws:text-left\" (click)=\"onPickScope('page')\">\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\n            <span>This page</span>\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              {{ pageRows().length }} rows, as sorted on screen\n            </span>\n          </span>\n        </button>\n\n        <button\n          type=\"button\"\n          class=\"scoular-dropdown-item cws:text-left\"\n          [disabled]=\"busy()\"\n          (click)=\"onPickScope('all')\"\n        >\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\n            <span>All pages</span>\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              {{ totalCount() }} rows — every row this filter matches\n            </span>\n          </span>\n        </button>\n      } @else {\n        <!--\n          ⚠ The header names the scope rather than repeating \"Export as CSV\". Once the field list is\n          on screen it is the only thing saying which of the two exports is about to run, and the two\n          differ by every row in the result set.\n        -->\n        <div class=\"scoular-dropdown-header cws:flex cws:items-center cws:gap-2\">\n          <!--\n            Back rather than only Escape: Escape closes the whole panel, which throws away the scope\n            AND the fields. A wrong pick must not cost the gesture.\n          -->\n          <button\n            type=\"button\"\n            class=\"cws:shrink-0 cws:text-scoular-blue cws:hover:underline\"\n            aria-label=\"Back to choosing what to export\"\n            (click)=\"onBack()\"\n          >\n            ‹\n          </button>\n          <span class=\"truncate\">{{ scope() === 'page' ? 'This page' : 'All pages' }}</span>\n        </div>\n\n        <div class=\"cws:px-3 cws:py-2\">\n          @if (visibleKeys() !== null) {\n            <!-- docs/02 §8 (#748): say where the ticks came from, so an unticked column is not a surprise. -->\n            <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-export-visible-note>\n              Starts from the visible columns. Tick a hidden one to add it to this file.\n            </p>\n          }\n          <cms-export-fields [fields]=\"fields()\" (fieldsChange)=\"onFieldsChange($event)\" />\n        </div>\n\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <!--\n          The confirm, and the only place the export actually runs. `canExport()` gates it here\n          rather than on the scope buttons: at scope-choosing time every field is ticked by\n          construction, so a disabled scope button could only ever confuse.\n        -->\n        <div class=\"cws:px-3 cws:pb-2 cws:pt-1\">\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-primary cws:w-full cws:justify-center\"\n            [disabled]=\"!canExport() || busy()\"\n            (click)=\"menu.close(); run()\"\n          >\n            {{\n              scope() === 'page'\n                ? 'Export ' + pageRows().length + ' rows'\n                : 'Export ' + totalCount() + ' rows'\n            }}\n          </button>\n        </div>\n      }\n    </div>\n  }\n</div>\n",
		dependencies: [{
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}, {
			kind: "component",
			type: ExportFieldsComponent,
			selector: "cms-export-fields",
			inputs: [
				"fields",
				"lockedKeys",
				"noun",
				"listLabel",
				"emptyMessage"
			],
			outputs: ["fieldsChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GridExportComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-grid-export",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownDirective, ExportFieldsComponent],
			host: { class: "cws:block" },
			template: "<!--\n  🔴 The directive goes on a wrapper that contains BOTH the trigger and the panel, never on the\n  button. Its outside-click check is `host.contains(event.target)`, so with the directive on the\n  button every click *inside* the panel would read as outside and close it — the field picker would\n  shut on its first checkbox.\n-->\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative\">\n  <!--\n    The trigger. `scoular-btn-secondary` rather than a size variant, so the box model matches the\n    refresh button and the pager beside it: all three are `px-4 py-2 text-sm` with a 1px border,\n    which is what keeps them the same height without a hard-coded pixel value that would drift when\n    the design system changes its own padding.\n  -->\n  <button\n    type=\"button\"\n    class=\"scoular-btn scoular-btn-secondary\"\n    [disabled]=\"disabled() || busy()\"\n    [attr.aria-expanded]=\"menu.open()\"\n    aria-haspopup=\"menu\"\n    (click)=\"menu.toggle(); onToggle()\"\n  >\n    <!--\n      An inline SVG rather than a glyph: the arrow-out-of-tray mark is the conventional \"export\"\n      icon and no single Unicode character carries it. `currentColor` so it inherits the button's\n      text colour in both themes, and aria-hidden because the button already says what it does.\n    -->\n    <svg\n      aria-hidden=\"true\"\n      viewBox=\"0 0 24 24\"\n      fill=\"none\"\n      stroke=\"currentColor\"\n      stroke-width=\"2\"\n      stroke-linecap=\"round\"\n      stroke-linejoin=\"round\"\n      class=\"cws:size-4 cws:shrink-0\"\n    >\n      <path d=\"M12 15V3\" />\n      <path d=\"m8 7 4-4 4 4\" />\n      <path d=\"M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4\" />\n    </svg>\n    {{ busy() ? 'Exporting…' : 'Export data' }}\n    <span aria-hidden=\"true\" class=\"cws:text-xs\">{{ menu.open() ? '▲' : '▼' }}</span>\n  </button>\n\n  @if (menu.open()) {\n    <!--\n      🔴 A GROUP, not a `role=\"menu\"`, and the change is required rather than cosmetic. A menu's\n      children must be `menuitem`s, and the second step holds checkboxes, reorder buttons and\n      draggable rows — announcing those as menu items tells a screen-reader user they are about to\n      activate a command when they are about to toggle a field. The export actions are still\n      buttons; they simply are not menu items any more.\n\n      ⚠ The role stays `group` on BOTH steps even though step one is only two buttons and would\n      qualify as a menu. Switching role with the step would change what a screen reader announces\n      part-way through one gesture, which is worse than the slightly loose fit.\n    -->\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\" role=\"group\" aria-label=\"Export\">\n      @if (scope() === null) {\n        <div class=\"scoular-dropdown-header\">Export as CSV</div>\n\n        <!--\n          🔴 SCOPE FIRST, fields second. The two scopes differ by orders of magnitude in cost on the\n          workspace — the current page is already in memory, every page is one CTRM read per 200\n          rows — so that is the choice every export has to make, and it is asked on its own. The\n          field picker is a refinement most exports do not need, and putting it first made every\n          export pay for it.\n\n          The row counts stay in the labels: the choice is made with the numbers visible.\n        -->\n        <!--\n          `text-left` on the item is load-bearing. `.scoular-dropdown-item` is a `<button>`, and a\n          button inherits `text-align: center` — so a subtext short enough to fit looked fine while\n          the longer one *wrapped* and centred its second line. `items-start` does not fix that: it\n          aligns the flex children, not the text inside a child that wraps.\n        -->\n        <button type=\"button\" class=\"scoular-dropdown-item cws:text-left\" (click)=\"onPickScope('page')\">\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\n            <span>This page</span>\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              {{ pageRows().length }} rows, as sorted on screen\n            </span>\n          </span>\n        </button>\n\n        <button\n          type=\"button\"\n          class=\"scoular-dropdown-item cws:text-left\"\n          [disabled]=\"busy()\"\n          (click)=\"onPickScope('all')\"\n        >\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\n            <span>All pages</span>\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              {{ totalCount() }} rows — every row this filter matches\n            </span>\n          </span>\n        </button>\n      } @else {\n        <!--\n          ⚠ The header names the scope rather than repeating \"Export as CSV\". Once the field list is\n          on screen it is the only thing saying which of the two exports is about to run, and the two\n          differ by every row in the result set.\n        -->\n        <div class=\"scoular-dropdown-header cws:flex cws:items-center cws:gap-2\">\n          <!--\n            Back rather than only Escape: Escape closes the whole panel, which throws away the scope\n            AND the fields. A wrong pick must not cost the gesture.\n          -->\n          <button\n            type=\"button\"\n            class=\"cws:shrink-0 cws:text-scoular-blue cws:hover:underline\"\n            aria-label=\"Back to choosing what to export\"\n            (click)=\"onBack()\"\n          >\n            ‹\n          </button>\n          <span class=\"truncate\">{{ scope() === 'page' ? 'This page' : 'All pages' }}</span>\n        </div>\n\n        <div class=\"cws:px-3 cws:py-2\">\n          @if (visibleKeys() !== null) {\n            <!-- docs/02 §8 (#748): say where the ticks came from, so an unticked column is not a surprise. -->\n            <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-export-visible-note>\n              Starts from the visible columns. Tick a hidden one to add it to this file.\n            </p>\n          }\n          <cms-export-fields [fields]=\"fields()\" (fieldsChange)=\"onFieldsChange($event)\" />\n        </div>\n\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <!--\n          The confirm, and the only place the export actually runs. `canExport()` gates it here\n          rather than on the scope buttons: at scope-choosing time every field is ticked by\n          construction, so a disabled scope button could only ever confuse.\n        -->\n        <div class=\"cws:px-3 cws:pb-2 cws:pt-1\">\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-primary cws:w-full cws:justify-center\"\n            [disabled]=\"!canExport() || busy()\"\n            (click)=\"menu.close(); run()\"\n          >\n            {{\n              scope() === 'page'\n                ? 'Export ' + pageRows().length + ' rows'\n                : 'Export ' + totalCount() + ' rows'\n            }}\n          </button>\n        </div>\n      }\n    </div>\n  }\n</div>\n"
		}]
	}],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		visibleKeys: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visibleKeys",
				required: false
			}]
		}],
		pageRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageRows",
				required: true
			}]
		}],
		totalCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "totalCount",
				required: true
			}]
		}],
		allRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allRows",
				required: true
			}]
		}],
		filename: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filename",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		serverExport: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "serverExport",
				required: false
			}]
		}],
		completed: [{
			type: i0.Output,
			args: ["completed"]
		}],
		failed: [{
			type: i0.Output,
			args: ["failed"]
		}]
	}
});
var ShortcutOverlayComponent = class ShortcutOverlayComponent {
	registry = inject(ShortcutRegistry);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	constructor() {
		registerShortcuts([
			{
				keys: "?",
				scope: "shell",
				label: "Show this list of keys",
				group: "Help",
				run: () => this.toggle()
			},
			{
				keys: "f1",
				scope: "shell",
				label: "Show this list of keys",
				group: "Help",
				run: () => this.toggle()
			},
			{
				keys: "escape",
				scope: "dialog",
				label: "Close this list",
				group: "Help",
				available: () => this.open(),
				run: () => this.open.set(false)
			},
			{
				keys: "escape",
				scope: "shell",
				label: "Go back without saving",
				group: "Navigation",
				note: "F3 or F12 on the green screen"
			}
		]);
	}
	toggle() {
		this.open.update((value) => !value);
	}
	groups = computed(() => {
		const byHeading = /* @__PURE__ */ new Map();
		for (const entry of this.registry.visible()) {
			const binding = entry.binding;
			const heading = binding.group ?? defaultGroup(binding.scope);
			const rows = byHeading.get(heading) ?? [];
			rows.push({
				keys: formatShortcut(binding.keys),
				label: binding.label,
				note: binding.note ?? null
			});
			byHeading.set(heading, rows);
		}
		return [...byHeading.entries()].map(([heading, rows]) => ({
			heading,
			rows
		}));
	}, ...ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ShortcutOverlayComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ShortcutOverlayComponent,
		isStandalone: true,
		selector: "cms-shortcut-overlay",
		host: { classAttribute: "cws:contents" },
		ngImport: i0,
		template: "@if (open()) {\n  <!--\n    A modal panel over a scrim. `role=\"dialog\"` with `aria-modal` so a screen reader treats it as one,\n    and the scrim is a plain div rather than a button: a click anywhere dismisses it, which is what the\n    overlay's own Escape binding does, and an interactive element there would land in the tab order\n    ahead of the content it covers.\n  -->\n  <div\n    class=\"cws:fixed cws:inset-0 cws:z-50 cws:flex cws:items-start cws:justify-center cws:overflow-y-auto cws:bg-slate-900/40 cws:p-4 cws:pt-16\"\n    (click)=\"open.set(false)\"\n  >\n    <!--\n      ⚠ `stopPropagation` so a click inside the panel does not dismiss it — the same shape as the\n      export panel's wrapper, for the same reason.\n    -->\n    <div\n      role=\"dialog\"\n      aria-modal=\"true\"\n      aria-labelledby=\"cms-shortcut-overlay-title\"\n      class=\"scoular-card cws:w-full cws:max-w-2xl cws:p-6\"\n      (click)=\"$event.stopPropagation()\"\n    >\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\n        <div>\n          <h2\n            id=\"cms-shortcut-overlay-title\"\n            class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\"\n          >\n            Keyboard shortcuts\n          </h2>\n\n          <!--\n            🔴 Names the green screen explicitly. The population this is for has spent years on\n            CTRM's 5250 screens, and the single most useful sentence in this panel is the one that\n            says which of their four reliable keys still works and what replaced the rest.\n          -->\n          <p class=\"cws:mt-1 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n            Press <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">?</kbd> or <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">F1</kbd> to open this at any\n            time. Keys are listed only while they apply.\n          </p>\n        </div>\n\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\n          (click)=\"open.set(false)\"\n        >\n          Close\n        </button>\n      </div>\n\n      <div class=\"cws:mt-5 cws:flex cws:flex-col cws:gap-5\">\n        @for (group of groups(); track group.heading) {\n          <section>\n            <h3\n              class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\"\n            >\n              {{ group.heading }}\n            </h3>\n\n            <dl class=\"cws:mt-2 cws:flex cws:flex-col cws:gap-1\">\n              @for (row of group.rows; track row.keys + row.label) {\n                <div class=\"cws:flex cws:items-baseline cws:gap-3 cws:text-sm\">\n                  <dt class=\"cws:w-40 cws:shrink-0\">\n                    <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ row.keys }}</kbd>\n                  </dt>\n\n                  <dd class=\"cws:text-slate-700 cws:dark:text-slate-200\">\n                    {{ row.label }}\n\n                    @if (row.note) {\n                      <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ row.note }})</span>\n                    }\n                  </dd>\n                </div>\n              }\n            </dl>\n          </section>\n        }\n      </div>\n    </div>\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ShortcutOverlayComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-shortcut-overlay",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:contents" },
			template: "@if (open()) {\n  <!--\n    A modal panel over a scrim. `role=\"dialog\"` with `aria-modal` so a screen reader treats it as one,\n    and the scrim is a plain div rather than a button: a click anywhere dismisses it, which is what the\n    overlay's own Escape binding does, and an interactive element there would land in the tab order\n    ahead of the content it covers.\n  -->\n  <div\n    class=\"cws:fixed cws:inset-0 cws:z-50 cws:flex cws:items-start cws:justify-center cws:overflow-y-auto cws:bg-slate-900/40 cws:p-4 cws:pt-16\"\n    (click)=\"open.set(false)\"\n  >\n    <!--\n      ⚠ `stopPropagation` so a click inside the panel does not dismiss it — the same shape as the\n      export panel's wrapper, for the same reason.\n    -->\n    <div\n      role=\"dialog\"\n      aria-modal=\"true\"\n      aria-labelledby=\"cms-shortcut-overlay-title\"\n      class=\"scoular-card cws:w-full cws:max-w-2xl cws:p-6\"\n      (click)=\"$event.stopPropagation()\"\n    >\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\n        <div>\n          <h2\n            id=\"cms-shortcut-overlay-title\"\n            class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\"\n          >\n            Keyboard shortcuts\n          </h2>\n\n          <!--\n            🔴 Names the green screen explicitly. The population this is for has spent years on\n            CTRM's 5250 screens, and the single most useful sentence in this panel is the one that\n            says which of their four reliable keys still works and what replaced the rest.\n          -->\n          <p class=\"cws:mt-1 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n            Press <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">?</kbd> or <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">F1</kbd> to open this at any\n            time. Keys are listed only while they apply.\n          </p>\n        </div>\n\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\n          (click)=\"open.set(false)\"\n        >\n          Close\n        </button>\n      </div>\n\n      <div class=\"cws:mt-5 cws:flex cws:flex-col cws:gap-5\">\n        @for (group of groups(); track group.heading) {\n          <section>\n            <h3\n              class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\"\n            >\n              {{ group.heading }}\n            </h3>\n\n            <dl class=\"cws:mt-2 cws:flex cws:flex-col cws:gap-1\">\n              @for (row of group.rows; track row.keys + row.label) {\n                <div class=\"cws:flex cws:items-baseline cws:gap-3 cws:text-sm\">\n                  <dt class=\"cws:w-40 cws:shrink-0\">\n                    <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ row.keys }}</kbd>\n                  </dt>\n\n                  <dd class=\"cws:text-slate-700 cws:dark:text-slate-200\">\n                    {{ row.label }}\n\n                    @if (row.note) {\n                      <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ row.note }})</span>\n                    }\n                  </dd>\n                </div>\n              }\n            </dl>\n          </section>\n        }\n      </div>\n    </div>\n  </div>\n}\n"
		}]
	}],
	ctorParameters: () => []
});
var ShortcutHintsComponent = class ShortcutHintsComponent {
	registry = inject(ShortcutRegistry);
	hints = computed(() => {
		const context = this.registry.contextHints();
		const taken = new Set(context.map((hint) => hint.keys));
		const registered = [...this.registry.visible()].filter((entry) => entry.binding.run !== void 0 && !taken.has(entry.binding.keys)).sort((left, right) => scopeWeight(right) - scopeWeight(left)).map((entry) => ({
			keys: entry.binding.keys,
			label: entry.binding.label
		}));
		return [...context, ...registered].slice(0, MAX_HINTS).map((hint) => ({
			keys: formatShortcut(hint.keys),
			label: hint.label
		}));
	}, ...ngDevMode ? [{ debugName: "hints" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ShortcutHintsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ShortcutHintsComponent,
		isStandalone: true,
		selector: "cms-shortcut-hints",
		host: { classAttribute: "cws:sticky cws:bottom-0 cws:z-30 cws:block" },
		ngImport: i0,
		template: "<!--\n  ⚠ `aria-hidden`, deliberately. Every key here is already announced by the control it belongs to\n  through `aria-keyshortcuts`, and the overlay lists them all in a structure a screen reader can\n  navigate — so reading this strip out on every page is duplication rather than access.\n\n  ⚠ Rendered as an empty bar when nothing is registered rather than hidden, so the chrome does not\n  change height as a user moves between screens.\n-->\n<div\n  aria-hidden=\"true\"\n  class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-x-4 cws:gap-y-1 cws:border-t cws:border-slate-200 cws:bg-slate-50 cws:px-4 cws:py-1.5 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-400\"\n>\n  @for (hint of hints(); track hint.keys + hint.label) {\n    <span class=\"cws:flex cws:items-center cws:gap-1.5\">\n      <kbd\n        class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:px-1 cws:py-0.5 cws:font-mono cws:text-[11px] cws:text-slate-600 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\n        >{{ hint.keys }}</kbd\n      >\n      {{ hint.label }}\n    </span>\n  }\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ShortcutHintsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-shortcut-hints",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:sticky cws:bottom-0 cws:z-30 cws:block" },
			template: "<!--\n  ⚠ `aria-hidden`, deliberately. Every key here is already announced by the control it belongs to\n  through `aria-keyshortcuts`, and the overlay lists them all in a structure a screen reader can\n  navigate — so reading this strip out on every page is duplication rather than access.\n\n  ⚠ Rendered as an empty bar when nothing is registered rather than hidden, so the chrome does not\n  change height as a user moves between screens.\n-->\n<div\n  aria-hidden=\"true\"\n  class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-x-4 cws:gap-y-1 cws:border-t cws:border-slate-200 cws:bg-slate-50 cws:px-4 cws:py-1.5 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-400\"\n>\n  @for (hint of hints(); track hint.keys + hint.label) {\n    <span class=\"cws:flex cws:items-center cws:gap-1.5\">\n      <kbd\n        class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:px-1 cws:py-0.5 cws:font-mono cws:text-[11px] cws:text-slate-600 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\n        >{{ hint.keys }}</kbd\n      >\n      {{ hint.label }}\n    </span>\n  }\n</div>\n"
		}]
	}]
});
const MAX_HINTS = 9;
function scopeWeight(entry) {
	switch (entry.binding.scope) {
		case "dialog": return 3;
		case "feature": return 2;
		case "control": return 1;
		default: return 0;
	}
}
var SearchShortcutDirective = class SearchShortcutDirective {
	host = inject(ElementRef);
	constructor() {
		registerShortcuts([{
			keys: "/",
			scope: "feature",
			label: "Search this grid",
			group: "Grids",
			run: () => {
				const input = this.host.nativeElement;
				input.focus();
				input.select();
			}
		}]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SearchShortcutDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: SearchShortcutDirective,
		isStandalone: true,
		selector: "input[cmsSearchShortcut]",
		host: { properties: { "attr.aria-keyshortcuts": "\"/\"" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SearchShortcutDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[cmsSearchShortcut]",
			host: { "[attr.aria-keyshortcuts]": "\"/\"" }
		}]
	}],
	ctorParameters: () => []
});
var GridToolbarComponent = class GridToolbarComponent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: GridToolbarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: GridToolbarComponent,
		isStandalone: true,
		selector: "cms-grid-toolbar",
		host: { classAttribute: "scoular-card cws:flex cws:flex-wrap cws:items-end cws:gap-2 cws:p-3" },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: GridToolbarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-grid-toolbar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: { class: "scoular-card cws:flex cws:flex-wrap cws:items-end cws:gap-2 cws:p-3" }
		}]
	}]
});
var RefreshButtonComponent = class RefreshButtonComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	busy = input(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	refresh = output();
	isDisabled = computed(() => this.busy() || this.disabled(), ...ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RefreshButtonComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: RefreshButtonComponent,
		isStandalone: true,
		selector: "cms-refresh-button",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			busy: {
				classPropertyName: "busy",
				publicName: "busy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { refresh: "refresh" },
		ngImport: i0,
		template: `
    <button
      type="button"
      class="scoular-btn scoular-btn-secondary"
      [attr.aria-label]="label()"
      [attr.title]="label()"
      [attr.aria-busy]="busy() ? 'true' : null"
      [disabled]="isDisabled()"
      (click)="refresh.emit()"
    >
      <!--
        The 20px line box the button's missing text would have had — see the class remarks. The icon
        itself stays 16px, so it matches the Export data mark beside it rather than growing to fill.
      -->
      <span class="cws:flex cws:h-5 cws:items-center" aria-hidden="true">
        <!--
          Two arcs with their arrowheads: the conventional "refresh" mark, and no single Unicode
          character carries it (U+21BB is a single arc and renders at wildly different weights across
          fonts). Stroked in currentColor so it inherits the button's text colour in both themes.

          It spins while a refresh is in flight. That is the only feedback this control gives — the
          screen's own loading state is what says the data is coming — and it is why aria-busy is set
          rather than the label changing: a label that becomes "Refreshing…" on an icon-only button is
          announced but invisible.

          (No backticks anywhere in this template. It is a template literal, so one would end it —
          the same warning the pager carries, and this component walked into it on the first build.)
        -->
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          class="cws:size-4 cws:shrink-0"
          [class.animate-spin]="busy()"
        >
          <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
          <path d="M21 3v5h-5" />
          <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
          <path d="M8 16H3v5" />
        </svg>
      </span>
    </button>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RefreshButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-refresh-button",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button
      type="button"
      class="scoular-btn scoular-btn-secondary"
      [attr.aria-label]="label()"
      [attr.title]="label()"
      [attr.aria-busy]="busy() ? 'true' : null"
      [disabled]="isDisabled()"
      (click)="refresh.emit()"
    >
      <!--
        The 20px line box the button's missing text would have had — see the class remarks. The icon
        itself stays 16px, so it matches the Export data mark beside it rather than growing to fill.
      -->
      <span class="cws:flex cws:h-5 cws:items-center" aria-hidden="true">
        <!--
          Two arcs with their arrowheads: the conventional "refresh" mark, and no single Unicode
          character carries it (U+21BB is a single arc and renders at wildly different weights across
          fonts). Stroked in currentColor so it inherits the button's text colour in both themes.

          It spins while a refresh is in flight. That is the only feedback this control gives — the
          screen's own loading state is what says the data is coming — and it is why aria-busy is set
          rather than the label changing: a label that becomes "Refreshing…" on an icon-only button is
          announced but invisible.

          (No backticks anywhere in this template. It is a template literal, so one would end it —
          the same warning the pager carries, and this component walked into it on the first build.)
        -->
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          class="cws:size-4 cws:shrink-0"
          [class.animate-spin]="busy()"
        >
          <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
          <path d="M21 3v5h-5" />
          <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
          <path d="M8 16H3v5" />
        </svg>
      </span>
    </button>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		busy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "busy",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		refresh: [{
			type: i0.Output,
			args: ["refresh"]
		}]
	}
});
var ClearSortButtonComponent = class ClearSortButtonComponent {
	sorts = input.required(...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	defaultSorts = input([], ...ngDevMode ? [{ debugName: "defaultSorts" }] : /* istanbul ignore next */ []);
	clear = output();
	visible = computed(() => !this.same(this.sorts(), this.defaultSorts()), ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	hint = computed(() => this.defaultSorts().length === 0 ? "Remove the sort and return to the order the rows arrived in" : "Return to this queue's default order", ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	same(left, right) {
		return left.length === right.length && left.every((sort, index) => sort.key === right[index]?.key && sort.direction === right[index]?.direction);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ClearSortButtonComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ClearSortButtonComponent,
		isStandalone: true,
		selector: "cms-clear-sort-button",
		inputs: {
			sorts: {
				classPropertyName: "sorts",
				publicName: "sorts",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			defaultSorts: {
				classPropertyName: "defaultSorts",
				publicName: "defaultSorts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { clear: "clear" },
		ngImport: i0,
		template: `
    @if (visible()) {
      <button
        type="button"
        class="scoular-btn scoular-btn-outline"
        [attr.title]="hint()"
        (click)="clear.emit(defaultSorts())"
      >
        <!--
          The same double arrow the grid puts on an unsorted header, so the button shows the state it
          returns you to. aria-hidden because the label already says it.
        -->
        <span aria-hidden="true">&#8645;</span>
        Clear sort
        @if (sorts().length > 1) {
          <!--
            🔴 The h-5 rides on the shared badge rather than being replaced by it. The tone classes
            come from cms-status-badge; the height is this button's own, and is why the badge does
            not make it 2px taller than its neighbours - see the class docstring. Angular merges a
            consumer class with the component's host binding, and the primitive has a test for it.

            ⚠ No backticks in this comment, deliberately: an inline template IS a template literal,
            so one would end it. That is Known Issue 37, and it cost a build on the way in here.
          -->
          <cms-status-badge tone="info" [small]="true" class="cws:h-5">
            {{ sorts().length }}
          </cms-status-badge>
        }
      </button>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: StatusBadgeComponent,
			selector: "cms-status-badge",
			inputs: ["tone", "small"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ClearSortButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-clear-sort-button",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [StatusBadgeComponent],
			template: `
    @if (visible()) {
      <button
        type="button"
        class="scoular-btn scoular-btn-outline"
        [attr.title]="hint()"
        (click)="clear.emit(defaultSorts())"
      >
        <!--
          The same double arrow the grid puts on an unsorted header, so the button shows the state it
          returns you to. aria-hidden because the label already says it.
        -->
        <span aria-hidden="true">&#8645;</span>
        Clear sort
        @if (sorts().length > 1) {
          <!--
            🔴 The h-5 rides on the shared badge rather than being replaced by it. The tone classes
            come from cms-status-badge; the height is this button's own, and is why the badge does
            not make it 2px taller than its neighbours - see the class docstring. Angular merges a
            consumer class with the component's host binding, and the primitive has a test for it.

            ⚠ No backticks in this comment, deliberately: an inline template IS a template literal,
            so one would end it. That is Known Issue 37, and it cost a build on the way in here.
          -->
          <cms-status-badge tone="info" [small]="true" class="cws:h-5">
            {{ sorts().length }}
          </cms-status-badge>
        }
      </button>
    }
  `
		}]
	}],
	propDecorators: {
		sorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sorts",
				required: true
			}]
		}],
		defaultSorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "defaultSorts",
				required: false
			}]
		}],
		clear: [{
			type: i0.Output,
			args: ["clear"]
		}]
	}
});
let nextPanelId = 0;
var NoticesPanelComponent = class NoticesPanelComponent {
	detailId = `cms-notices-detail-${nextPanelId++}`;
	summaries = input.required(...ngDevMode ? [{ debugName: "summaries" }] : /* istanbul ignore next */ []);
	heading = input("Environment & System Notices", ...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	systemNotices = input(true, ...ngDevMode ? [{ debugName: "systemNotices" }] : /* istanbul ignore next */ []);
	title = computed(() => this.systemNotices() ? this.heading() : "Notices", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	initiallyExpanded = input(false, ...ngDevMode ? [{ debugName: "initiallyExpanded" }] : /* istanbul ignore next */ []);
	expanded = linkedSignal(() => this.initiallyExpanded(), ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	count = computed(() => this.summaries().length, ...ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []);
	hasNotices = computed(() => this.count() > 0, ...ngDevMode ? [{ debugName: "hasNotices" }] : /* istanbul ignore next */ []);
	toggle() {
		this.expanded.update((open) => !open);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NoticesPanelComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: NoticesPanelComponent,
		isStandalone: true,
		selector: "cms-notices-panel",
		inputs: {
			summaries: {
				classPropertyName: "summaries",
				publicName: "summaries",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			heading: {
				classPropertyName: "heading",
				publicName: "heading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			systemNotices: {
				classPropertyName: "systemNotices",
				publicName: "systemNotices",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initiallyExpanded: {
				classPropertyName: "initiallyExpanded",
				publicName: "initiallyExpanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "@if (hasNotices()) {\n  <!--\n    One bordered block rather than a stack of full-width alerts.\n\n    ⚠ **Amber, not red.** These are standing conditions a user works alongside, not failures — and a\n    red block at the top of every visit trains people to skip the place errors will one day appear.\n\n    🔴 **Collapsed, it is ONE LINE: the heading, the count, and the disclosure** (JFrisbie,\n    2026-09-29). The summary bullets that used to sit under the heading in both states are gone —\n    the panel said too much before anyone asked. `py-2` rather than `py-3` for the same reason;\n    `px-4` still matches the cards and toolbar around it.\n  -->\n  <section\n    class=\"cws:rounded-md cws:border cws:border-amber-200 cws:bg-amber-50/60 cws:px-4 cws:py-2 cws:dark:border-amber-900/60 cws:dark:bg-amber-950/20\"\n    [attr.aria-label]=\"title()\"\n  >\n    <!--\n      ⚠ **The header row is NOT the button** (JFrisbie, 2026-09-14). It was, on the reasoning that a\n      small target is easy to miss — but a whole row that toggles on click is a row you cannot select\n      text in, and the heading and count are the two things a reader is most likely to want to read\n      rather than press. Only the control is the control.\n    -->\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\n      <span aria-hidden=\"true\" class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">⚠</span>\n\n      <!--\n        The heading and its count, as one line of text: \"Environment & System Notices (3)\".\n\n        ⚠ The visible count is `aria-hidden` and the screen-reader text says \"active notices\",\n        because a bare \"(3)\" beside a heading is ambiguous read aloud — it could as easily be a step\n        or a version.\n      -->\n      <span class=\"cws:text-sm cws:font-medium cws:text-amber-900 cws:dark:text-amber-200\">\n        {{ title() }} <span aria-hidden=\"true\">({{ count() }})</span>\n        <span class=\"sr-only\">{{ count() }} active notices</span>\n      </span>\n\n      <!--\n        The disclosure, and the whole of it is the target: the words and the triangle sit inside one\n        button so the hit area is the label rather than the 12px glyph.\n      -->\n      <button\n        type=\"button\"\n        class=\"cws:ml-auto cws:flex cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-800 cws:hover:bg-amber-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-amber-700 cws:dark:text-amber-300 cws:dark:hover:bg-amber-900/40\"\n        [attr.aria-expanded]=\"expanded()\"\n        [attr.aria-controls]=\"detailId\"\n        (click)=\"toggle()\"\n      >\n        {{ expanded() ? 'Hide' : 'Show' }} details\n\n        <!--\n          ⚠ `aria-hidden`, because the button already announces its state through `aria-expanded`\n          and the word beside it. Announcing a triangle as well would read as a third control.\n        -->\n        <span\n          aria-hidden=\"true\"\n          class=\"cws:text-[10px] cws:transition-transform\"\n          [class.cws:rotate-90]=\"expanded()\"\n        >\n          ▶\n        </span>\n      </button>\n    </div>\n\n    <!--\n      The detail: rendered ALWAYS and hidden, rather than removed.\n\n      ⚠ `aria-controls` must name an element that exists. Pointing it at a node the collapsed state\n      has removed is a dangling reference, and assistive technology then has nothing to move to when\n      the panel is opened.\n\n      🔴 **Every projected `scoular-alert` renders as a plain BULLET here, not as a card**\n      (JFrisbie, 2026-09-29). Callers project design-system alerts, and inside this panel the\n      coloured, bordered, padded boxes read as a second stack of banners — the thing the panel\n      exists to replace. Restyling them in ONE place keeps each caller's text, links and controls\n      (the create screen's template picker is one) while every screen gets the same list, so no\n      caller had to be rewritten. The title runs into its description on one line.\n\n      ⚠ This works because the design system's alert rules sit in the `components` layer and these\n      are utilities, which win by layer order rather than by specificity. If `components.css` is\n      ever imported unlayered, the cards come back.\n\n      `pl-6` lines the bullets up under the heading text rather than under the warning glyph, and\n      leaves room for the outside marker.\n    -->\n    <div\n      [id]=\"detailId\"\n      [hidden]=\"!expanded()\"\n      class=\"cws:mt-1.5 cws:space-y-1 cws:pb-1 cws:pl-6 cws:text-xs cws:text-amber-900/90 cws:dark:text-amber-200/90 cws:[&_.scoular-alert]:list-item cws:[&_.scoular-alert]:list-disc cws:[&_.scoular-alert]:rounded-none cws:[&_.scoular-alert]:border-0 cws:[&_.scoular-alert]:bg-transparent cws:[&_.scoular-alert]:p-0 cws:[&_.scoular-alert]:text-xs cws:[&_.scoular-alert]:text-amber-900/90 cws:dark:[&_.scoular-alert]:bg-transparent cws:dark:[&_.scoular-alert]:text-amber-200/90 cws:[&_.scoular-alert-description]:mt-0 cws:[&_.scoular-alert-description]:inline cws:[&_.scoular-alert-description]:text-xs cws:[&_.scoular-alert-title]:inline cws:[&_.scoular-alert-title]:font-medium cws:[&_.scoular-alert-title]:after:content-[':_']\"\n    >\n      <ng-content />\n    </div>\n  </section>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NoticesPanelComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-notices-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: "@if (hasNotices()) {\n  <!--\n    One bordered block rather than a stack of full-width alerts.\n\n    ⚠ **Amber, not red.** These are standing conditions a user works alongside, not failures — and a\n    red block at the top of every visit trains people to skip the place errors will one day appear.\n\n    🔴 **Collapsed, it is ONE LINE: the heading, the count, and the disclosure** (JFrisbie,\n    2026-09-29). The summary bullets that used to sit under the heading in both states are gone —\n    the panel said too much before anyone asked. `py-2` rather than `py-3` for the same reason;\n    `px-4` still matches the cards and toolbar around it.\n  -->\n  <section\n    class=\"cws:rounded-md cws:border cws:border-amber-200 cws:bg-amber-50/60 cws:px-4 cws:py-2 cws:dark:border-amber-900/60 cws:dark:bg-amber-950/20\"\n    [attr.aria-label]=\"title()\"\n  >\n    <!--\n      ⚠ **The header row is NOT the button** (JFrisbie, 2026-09-14). It was, on the reasoning that a\n      small target is easy to miss — but a whole row that toggles on click is a row you cannot select\n      text in, and the heading and count are the two things a reader is most likely to want to read\n      rather than press. Only the control is the control.\n    -->\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\n      <span aria-hidden=\"true\" class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">⚠</span>\n\n      <!--\n        The heading and its count, as one line of text: \"Environment & System Notices (3)\".\n\n        ⚠ The visible count is `aria-hidden` and the screen-reader text says \"active notices\",\n        because a bare \"(3)\" beside a heading is ambiguous read aloud — it could as easily be a step\n        or a version.\n      -->\n      <span class=\"cws:text-sm cws:font-medium cws:text-amber-900 cws:dark:text-amber-200\">\n        {{ title() }} <span aria-hidden=\"true\">({{ count() }})</span>\n        <span class=\"sr-only\">{{ count() }} active notices</span>\n      </span>\n\n      <!--\n        The disclosure, and the whole of it is the target: the words and the triangle sit inside one\n        button so the hit area is the label rather than the 12px glyph.\n      -->\n      <button\n        type=\"button\"\n        class=\"cws:ml-auto cws:flex cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-800 cws:hover:bg-amber-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-amber-700 cws:dark:text-amber-300 cws:dark:hover:bg-amber-900/40\"\n        [attr.aria-expanded]=\"expanded()\"\n        [attr.aria-controls]=\"detailId\"\n        (click)=\"toggle()\"\n      >\n        {{ expanded() ? 'Hide' : 'Show' }} details\n\n        <!--\n          ⚠ `aria-hidden`, because the button already announces its state through `aria-expanded`\n          and the word beside it. Announcing a triangle as well would read as a third control.\n        -->\n        <span\n          aria-hidden=\"true\"\n          class=\"cws:text-[10px] cws:transition-transform\"\n          [class.cws:rotate-90]=\"expanded()\"\n        >\n          ▶\n        </span>\n      </button>\n    </div>\n\n    <!--\n      The detail: rendered ALWAYS and hidden, rather than removed.\n\n      ⚠ `aria-controls` must name an element that exists. Pointing it at a node the collapsed state\n      has removed is a dangling reference, and assistive technology then has nothing to move to when\n      the panel is opened.\n\n      🔴 **Every projected `scoular-alert` renders as a plain BULLET here, not as a card**\n      (JFrisbie, 2026-09-29). Callers project design-system alerts, and inside this panel the\n      coloured, bordered, padded boxes read as a second stack of banners — the thing the panel\n      exists to replace. Restyling them in ONE place keeps each caller's text, links and controls\n      (the create screen's template picker is one) while every screen gets the same list, so no\n      caller had to be rewritten. The title runs into its description on one line.\n\n      ⚠ This works because the design system's alert rules sit in the `components` layer and these\n      are utilities, which win by layer order rather than by specificity. If `components.css` is\n      ever imported unlayered, the cards come back.\n\n      `pl-6` lines the bullets up under the heading text rather than under the warning glyph, and\n      leaves room for the outside marker.\n    -->\n    <div\n      [id]=\"detailId\"\n      [hidden]=\"!expanded()\"\n      class=\"cws:mt-1.5 cws:space-y-1 cws:pb-1 cws:pl-6 cws:text-xs cws:text-amber-900/90 cws:dark:text-amber-200/90 cws:[&_.scoular-alert]:list-item cws:[&_.scoular-alert]:list-disc cws:[&_.scoular-alert]:rounded-none cws:[&_.scoular-alert]:border-0 cws:[&_.scoular-alert]:bg-transparent cws:[&_.scoular-alert]:p-0 cws:[&_.scoular-alert]:text-xs cws:[&_.scoular-alert]:text-amber-900/90 cws:dark:[&_.scoular-alert]:bg-transparent cws:dark:[&_.scoular-alert]:text-amber-200/90 cws:[&_.scoular-alert-description]:mt-0 cws:[&_.scoular-alert-description]:inline cws:[&_.scoular-alert-description]:text-xs cws:[&_.scoular-alert-title]:inline cws:[&_.scoular-alert-title]:font-medium cws:[&_.scoular-alert-title]:after:content-[':_']\"\n    >\n      <ng-content />\n    </div>\n  </section>\n}\n"
		}]
	}],
	propDecorators: {
		summaries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "summaries",
				required: true
			}]
		}],
		heading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "heading",
				required: false
			}]
		}],
		systemNotices: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "systemNotices",
				required: false
			}]
		}],
		initiallyExpanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initiallyExpanded",
				required: false
			}]
		}]
	}
});
const DRAG_THRESHOLD_PX = 5;
function elementUnder(x, y, selector) {
	return document.elementFromPoint(x, y)?.closest(selector) ?? null;
}
var PointerDragGesture = class {
	handlers;
	pending = null;
	active = false;
	current = null;
	stop = null;
	constructor(handlers) {
		this.handlers = handlers;
	}
	dragging() {
		return this.active;
	}
	press(event) {
		const target = event.target;
		if (event.button !== 0 || target === null || typeof target.closest !== "function") return;
		if (target.closest(this.handlers.ignoreSelector ?? "button") !== null) return;
		const handle = target.closest(this.handlers.handleSelector);
		if (handle === null) return;
		const source = this.handlers.source(handle);
		if (source === null) return;
		this.end();
		this.pending = {
			source,
			x: event.clientX,
			y: event.clientY,
			pointerId: event.pointerId
		};
		this.listen();
	}
	cancel() {
		if (this.pending !== null || this.stop !== null) this.end();
	}
	listen() {
		const move = (event) => this.onMove(event);
		const up = (event) => this.onUp(event);
		const cancel = () => this.end();
		const key = (event) => {
			if (event.key === "Escape") this.end();
		};
		window.addEventListener("pointermove", move);
		window.addEventListener("pointerup", up);
		window.addEventListener("pointercancel", cancel);
		window.addEventListener("blur", cancel);
		window.addEventListener("keydown", key);
		this.stop = () => {
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			window.removeEventListener("pointercancel", cancel);
			window.removeEventListener("blur", cancel);
			window.removeEventListener("keydown", key);
			this.stop = null;
		};
	}
	onMove(event) {
		const pending = this.pending;
		if (pending === null || event.pointerId !== pending.pointerId) return;
		if (!this.active) {
			if (Math.abs(event.clientX - pending.x) + Math.abs(event.clientY - pending.y) < (this.handlers.threshold ?? 5)) return;
			this.active = true;
			this.handlers.started(pending.source);
		}
		event.preventDefault();
		this.current = this.handlers.target(event.clientX, event.clientY);
		this.handlers.over(this.current);
	}
	onUp(event) {
		const pending = this.pending;
		if (pending === null || event.pointerId !== pending.pointerId) return;
		const wasDragging = this.active;
		const target = this.current;
		this.end();
		if (wasDragging && target !== null) this.handlers.dropped(pending.source, target);
	}
	end() {
		const wasFollowing = this.pending !== null;
		this.pending = null;
		this.active = false;
		this.current = null;
		this.stop?.();
		if (wasFollowing) this.handlers.ended();
	}
};
const EMPTY_FILTER = {
	combinator: "and",
	rules: []
};
function isRuleNode(node) {
	return typeof node.columnKey === "string";
}
function isGroupNode(node) {
	return !isRuleNode(node);
}
function isLive(node) {
	return isRuleNode(node) ? isComplete(node) : node.rules.some(isLive);
}
const OPERATORS_BY_KIND = {
	text: [
		"contains",
		"notContains",
		"equals",
		"notEquals",
		"startsWith",
		"endsWith",
		"isBlank",
		"isNotBlank"
	],
	number: [
		"equals",
		"notEquals",
		"gt",
		"gte",
		"lt",
		"lte",
		"isBlank",
		"isNotBlank"
	],
	date: [
		"equals",
		"notEquals",
		"gt",
		"gte",
		"lt",
		"lte",
		"isBlank",
		"isNotBlank"
	]
};
const OPERATOR_LABELS = {
	text: {
		contains: "contains",
		notContains: "does not contain",
		equals: "is",
		notEquals: "is not",
		startsWith: "starts with",
		endsWith: "ends with",
		gt: "is after",
		gte: "is at or after",
		lt: "is before",
		lte: "is at or before",
		isBlank: "is blank",
		isNotBlank: "is not blank"
	},
	number: {
		contains: "contains",
		notContains: "does not contain",
		equals: "equals",
		notEquals: "does not equal",
		startsWith: "starts with",
		endsWith: "ends with",
		gt: "is greater than",
		gte: "is at least",
		lt: "is less than",
		lte: "is at most",
		isBlank: "is blank",
		isNotBlank: "is not blank"
	},
	date: {
		contains: "contains",
		notContains: "does not contain",
		equals: "is on",
		notEquals: "is not on",
		gt: "is after",
		gte: "is on or after",
		lt: "is before",
		lte: "is on or before",
		startsWith: "starts with",
		endsWith: "ends with",
		isBlank: "is blank",
		isNotBlank: "is not blank"
	}
};
const VALUELESS = /* @__PURE__ */ new Set(["isBlank", "isNotBlank"]);
function needsValue(operator) {
	return !VALUELESS.has(operator);
}
function operatorsFor(kind) {
	return OPERATORS_BY_KIND[kind];
}
function operatorLabel(kind, operator) {
	return OPERATOR_LABELS[kind][operator];
}
function matchesGroup(row, columns, group) {
	const active = group.rules.filter(isLive);
	if (active.length === 0) return true;
	const results = active.map((node) => isRuleNode(node) ? matchesRule(row, columns, node) : matchesGroup(row, columns, node));
	return group.combinator === "and" ? results.every(Boolean) : results.some(Boolean);
}
function isComplete(rule) {
	if (rule.columnKey === "") return false;
	return !needsValue(rule.operator) || rule.value.trim() !== "";
}
function matchesRule(row, columns, rule) {
	const column = columns.find((candidate) => candidate.key === rule.columnKey);
	if (column === void 0) return false;
	const text = column.format(row) ?? "";
	const kind = column.filterKind ?? "text";
	switch (rule.operator) {
		case "isBlank": return text.trim() === "";
		case "isNotBlank": return text.trim() !== "";
		case "contains": return includes(text, rule.value);
		case "notContains": return !includes(text, rule.value);
		case "startsWith": return normalise(text).startsWith(normalise(rule.value));
		case "endsWith": return normalise(text).endsWith(normalise(rule.value));
		default: return compares(row, column, kind, rule);
	}
}
function compares(row, column, kind, rule) {
	const left = column.sortValue?.(row) ?? column.format(row) ?? "";
	const right = rule.value.trim();
	if (kind === "number") {
		const leftNumber = typeof left === "number" ? left : Number.parseFloat(String(left).replace(/,/g, ""));
		const rightNumber = Number.parseFloat(right.replace(/,/g, ""));
		if (!Number.isFinite(leftNumber) || !Number.isFinite(rightNumber)) return false;
		return orders(leftNumber, rightNumber, rule.operator);
	}
	if (kind === "date") {
		const leftDate = String(left);
		const rightDate = right;
		if (leftDate === "" || rightDate === "") return false;
		return orders(leftDate, rightDate, rule.operator);
	}
	return orders(normalise(String(left)), normalise(right), rule.operator);
}
function orders(left, right, operator) {
	switch (operator) {
		case "equals": return left === right;
		case "notEquals": return left !== right;
		case "gt": return left > right;
		case "gte": return left >= right;
		case "lt": return left < right;
		case "lte": return left <= right;
		default: return false;
	}
}
function normalise(value) {
	return value.trim().toLocaleLowerCase();
}
function includes(haystack, needle) {
	return normalise(haystack).includes(normalise(needle));
}
function matchesSearch(row, columns, term) {
	const needle = normalise(term);
	if (needle === "") return true;
	return columns.some((column) => includes((column.searchText ?? column.format)(row) ?? "", needle));
}
function describeGroup(columns, group) {
	return group.rules.filter(isLive).map((node) => {
		if (isGroupNode(node)) {
			const inner = describeGroup(columns, node);
			return node.rules.filter(isLive).length > 1 ? `(${inner})` : inner;
		}
		const column = columns.find((candidate) => candidate.key === node.columnKey);
		const kind = column?.filterKind ?? "text";
		const header = column?.header ?? node.columnKey;
		const operator = operatorLabel(kind, node.operator);
		return needsValue(node.operator) ? `${header} ${operator} "${node.value.trim()}"` : `${header} ${operator}`;
	}).join(group.combinator === "and" ? " and " : " or ");
}
function activeRuleCount(group) {
	return group.rules.reduce((total, node) => total + (isRuleNode(node) ? isComplete(node) ? 1 : 0 : activeRuleCount(node)), 0);
}
function sameGroup(left, right) {
	const active = (group) => group.rules.filter(isLive);
	const a = active(left);
	const b = active(right);
	if (a.length > 1 && left.combinator !== right.combinator) return false;
	return a.length === b.length && a.every((node, index) => {
		const other = b[index];
		if (other === void 0) return false;
		if (isGroupNode(node) !== isGroupNode(other)) return false;
		if (isGroupNode(node) && isGroupNode(other)) return sameGroup(node, other);
		const rule = node;
		const otherRule = other;
		return rule.columnKey === otherRule.columnKey && rule.operator === otherRule.operator && rule.value.trim() === otherRule.value.trim();
	});
}
function nodeAt(group, path) {
	let current = group;
	for (const index of path) {
		if (isRuleNode(current)) return null;
		const next = current.rules[index];
		if (next === void 0) return null;
		current = next;
	}
	return current;
}
function setAt(group, path, replacement) {
	const [head, ...rest] = path;
	if (head === void 0) return group;
	const rules = [...group.rules];
	if (rest.length === 0) {
		if (replacement === null) rules.splice(head, 1);
		else rules[head] = replacement;
		return {
			...group,
			rules
		};
	}
	const child = rules[head];
	if (child === void 0 || isRuleNode(child)) return group;
	rules[head] = setAt(child, rest, replacement);
	return {
		...group,
		rules
	};
}
function removeAt(group, path) {
	return setAt(group, path, null);
}
function replaceRuleById(group, rule) {
	return {
		...group,
		rules: group.rules.map((node) => {
			if (isRuleNode(node)) return node.id === rule.id ? rule : node;
			return replaceRuleById(node, rule);
		})
	};
}
function normaliseGroup(group) {
	const rules = [];
	for (const node of group.rules) {
		if (isRuleNode(node)) {
			rules.push(node);
			continue;
		}
		const child = normaliseGroup(node);
		if (child.rules.length === 0) continue;
		if (child.rules.length === 1) {
			const only = child.rules[0];
			if (only !== void 0) rules.push(only);
			continue;
		}
		rules.push(child);
	}
	return {
		...group,
		rules
	};
}
function toggleCombinatorAt(group, path) {
	const target = path.length === 0 ? group : nodeAt(group, path);
	if (target === null || isRuleNode(target)) return group;
	const flipped = {
		...target,
		combinator: target.combinator === "and" ? "or" : "and"
	};
	return path.length === 0 ? flipped : setAt(group, path, flipped);
}
function moveNode(group, from, to, mode) {
	if (from.length === 0 || to.length === 0) return group;
	if (samePath(from, to) || isAncestor(from, to)) return group;
	const moving = nodeAt(group, from);
	if (moving === null) return group;
	const target = nodeAt(group, to);
	const parentPath = to.slice(0, -1);
	const parent = parentPath.length === 0 ? group : nodeAt(group, parentPath);
	if (parent === null || isRuleNode(parent)) return group;
	let next;
	if (mode === "onto") {
		if (target === null) return group;
		next = isGroupNode(target) ? setAt(group, to, {
			...target,
			rules: [...target.rules, moving]
		}) : setAt(group, to, {
			combinator: parent.combinator === "and" ? "or" : "and",
			rules: [target, moving]
		});
	} else {
		const rules = [...parent.rules];
		const index = Math.min(to[to.length - 1] ?? rules.length, rules.length);
		rules.splice(index, 0, moving);
		next = parentPath.length === 0 ? {
			...group,
			rules
		} : setAt(group, parentPath, {
			...parent,
			rules
		});
	}
	return normaliseGroup(setAt(next, shiftForInsert(from, to, mode), null));
}
function samePath(a, b) {
	return a.length === b.length && a.every((value, index) => value === b[index]);
}
function isAncestor(ancestor, descendant) {
	return ancestor.length <= descendant.length && ancestor.every((value, index) => value === descendant[index]);
}
function shiftForInsert(from, to, mode) {
	if (mode !== "before") return from;
	const toParent = to.slice(0, -1);
	const toIndex = to[to.length - 1] ?? 0;
	if (from.length <= toParent.length || !samePath(toParent, from.slice(0, toParent.length))) return from;
	const component = from[toParent.length] ?? 0;
	return component >= toIndex ? [
		...from.slice(0, toParent.length),
		component + 1,
		...from.slice(toParent.length + 1)
	] : from;
}
function ungroupAt(group, path) {
	if (path.length < 2) return group;
	const node = nodeAt(group, path);
	if (node === null) return group;
	const parentPath = path.slice(0, -1);
	const grandParentPath = parentPath.slice(0, -1);
	const parentIndex = parentPath[parentPath.length - 1] ?? 0;
	const without = removeAt(group, path);
	const container = grandParentPath.length === 0 ? without : nodeAt(without, grandParentPath);
	if (container === null || !isGroupNode(container)) return group;
	const rules = [...container.rules];
	rules.splice(parentIndex + 1, 0, node);
	return normaliseGroup(grandParentPath.length === 0 ? {
		...without,
		rules
	} : setAt(without, grandParentPath, {
		...container,
		rules
	}));
}
function groupNodes(group, first, second) {
	return moveNode(group, second, first, "onto");
}
var SelectComponent = class SelectComponent {
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	value = input("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	labelledBy = input(null, ...ngDevMode ? [{ debugName: "labelledBy" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	valueChange = output();
	selectedLabel = computed(() => {
		const options = this.options();
		return options.find((option) => option.value === this.value())?.label ?? options[0]?.label ?? "";
	}, ...ngDevMode ? [{ debugName: "selectedLabel" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SelectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: SelectComponent,
		isStandalone: true,
		selector: "cms-select",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			labelledBy: {
				classPropertyName: "labelledBy",
				publicName: "labelledBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { valueChange: "valueChange" },
		ngImport: i0,
		template: "<div cmsDropdown #panel=\"cmsDropdown\" class=\"cws:relative\">\n  <!--\n    `text-left` is load-bearing: a `<button>` inherits `text-align: center`, so the value would sit\n    centred while every input beside it is left-aligned.\n\n    The trigger wears `scoular-form-input` so it matches the bordered filter inputs it sits among.\n    ⚠ That class is `@apply w-full`, so its width comes from the wrapper — see the component's own\n    remarks. Sizing this button directly does nothing.\n  -->\n  <button\n    type=\"button\"\n    class=\"scoular-form-input cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\n    [attr.aria-label]=\"labelledBy() === null ? label() : null\"\n    [attr.aria-labelledby]=\"labelledBy()\"\n    aria-haspopup=\"listbox\"\n    [attr.aria-expanded]=\"panel.open()\"\n    [disabled]=\"disabled()\"\n    (click)=\"panel.toggle()\"\n  >\n    <span class=\"truncate\">{{ selectedLabel() }}</span>\n    <!-- The shared caret (2026-10-28), so this and a typeable combo draw the same chevron. The\n         button's own disabled styling mutes it. -->\n    <cms-dropdown-caret [open]=\"panel.open()\" />\n  </button>\n\n  @if (panel.open()) {\n    <!--\n      `w-full min-w-max` so the panel is at least as wide as its trigger and never narrower than its\n      longest option — an operator list reading \"does not contain\" cannot fit a 144px field, and\n      clipping the choices is worse than a panel wider than the control that opened it.\n\n      `max-h-64 overflow-y-auto` because a column list is as long as the grid has columns.\n    -->\n    <div\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:max-h-64 cws:w-full cws:min-w-max cws:overflow-y-auto\"\n      role=\"listbox\"\n      [attr.aria-label]=\"labelledBy() === null ? label() : null\"\n      [attr.aria-labelledby]=\"labelledBy()\"\n    >\n      @for (option of options(); track option.value) {\n        <button\n          type=\"button\"\n          role=\"option\"\n          class=\"scoular-dropdown-item cws:w-full cws:text-left\"\n          [class.active]=\"option.value === value()\"\n          [attr.aria-selected]=\"option.value === value()\"\n          (click)=\"panel.close(); valueChange.emit(option.value)\"\n        >\n          {{ option.label }}\n        </button>\n      }\n    </div>\n  }\n</div>\n",
		dependencies: [{
			kind: "component",
			type: DropdownCaretComponent,
			selector: "cms-dropdown-caret",
			inputs: ["open", "disabled"]
		}, {
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownCaretComponent, DropdownDirective],
			template: "<div cmsDropdown #panel=\"cmsDropdown\" class=\"cws:relative\">\n  <!--\n    `text-left` is load-bearing: a `<button>` inherits `text-align: center`, so the value would sit\n    centred while every input beside it is left-aligned.\n\n    The trigger wears `scoular-form-input` so it matches the bordered filter inputs it sits among.\n    ⚠ That class is `@apply w-full`, so its width comes from the wrapper — see the component's own\n    remarks. Sizing this button directly does nothing.\n  -->\n  <button\n    type=\"button\"\n    class=\"scoular-form-input cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\n    [attr.aria-label]=\"labelledBy() === null ? label() : null\"\n    [attr.aria-labelledby]=\"labelledBy()\"\n    aria-haspopup=\"listbox\"\n    [attr.aria-expanded]=\"panel.open()\"\n    [disabled]=\"disabled()\"\n    (click)=\"panel.toggle()\"\n  >\n    <span class=\"truncate\">{{ selectedLabel() }}</span>\n    <!-- The shared caret (2026-10-28), so this and a typeable combo draw the same chevron. The\n         button's own disabled styling mutes it. -->\n    <cms-dropdown-caret [open]=\"panel.open()\" />\n  </button>\n\n  @if (panel.open()) {\n    <!--\n      `w-full min-w-max` so the panel is at least as wide as its trigger and never narrower than its\n      longest option — an operator list reading \"does not contain\" cannot fit a 144px field, and\n      clipping the choices is worse than a panel wider than the control that opened it.\n\n      `max-h-64 overflow-y-auto` because a column list is as long as the grid has columns.\n    -->\n    <div\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:max-h-64 cws:w-full cws:min-w-max cws:overflow-y-auto\"\n      role=\"listbox\"\n      [attr.aria-label]=\"labelledBy() === null ? label() : null\"\n      [attr.aria-labelledby]=\"labelledBy()\"\n    >\n      @for (option of options(); track option.value) {\n        <button\n          type=\"button\"\n          role=\"option\"\n          class=\"scoular-dropdown-item cws:w-full cws:text-left\"\n          [class.active]=\"option.value === value()\"\n          [attr.aria-selected]=\"option.value === value()\"\n          (click)=\"panel.close(); valueChange.emit(option.value)\"\n        >\n          {{ option.label }}\n        </button>\n      }\n    </div>\n  }\n</div>\n"
		}]
	}],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		labelledBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelledBy",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
var FilterChipsComponent = class FilterChipsComponent {
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	group = input.required(...ngDevMode ? [{ debugName: "group" }] : /* istanbul ignore next */ []);
	path = input([], ...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	markedPath = input(null, ...ngDevMode ? [{ debugName: "markedPath" }] : /* istanbul ignore next */ []);
	draggingPath = input(null, ...ngDevMode ? [{ debugName: "draggingPath" }] : /* istanbul ignore next */ []);
	dropTarget = input(null, ...ngDevMode ? [{ debugName: "dropTarget" }] : /* istanbul ignore next */ []);
	editingId = input(null, ...ngDevMode ? [{ debugName: "editingId" }] : /* istanbul ignore next */ []);
	removeNode = output();
	toggleCombinator = output();
	markNode = output();
	editNode = output();
	ungroupNode = output();
	nodes = computed(() => this.group().rules, ...ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []);
	combinatorLabel = computed(() => this.group().combinator === "and" ? "AND" : "OR", ...ngDevMode ? [{ debugName: "combinatorLabel" }] : /* istanbul ignore next */ []);
	nested = computed(() => this.path().length > 0, ...ngDevMode ? [{ debugName: "nested" }] : /* istanbul ignore next */ []);
	dragActive = computed(() => this.draggingPath() !== null, ...ngDevMode ? [{ debugName: "dragActive" }] : /* istanbul ignore next */ []);
	childPath(index) {
		return [...this.path(), index];
	}
	isRule(node) {
		return isRuleNode(node);
	}
	asRule(node) {
		return node;
	}
	asGroup(node) {
		return node;
	}
	isMarked(index) {
		return this.samePath(this.markedPath(), this.childPath(index));
	}
	isDragging(index) {
		return this.samePath(this.draggingPath(), this.childPath(index));
	}
	isEditing(node) {
		const id = this.editingId();
		return id !== null && isRuleNode(node) && node.id === id;
	}
	gapClassFor(index) {
		if (this.dropModeFor(index) === "before") return "cws:bg-scoular-blue";
		return this.dragActive() ? "cws:bg-slate-300 cws:dark:bg-slate-600" : "cws:bg-transparent";
	}
	dropModeFor(index) {
		const target = this.dropTarget();
		if (target === null || target.mode === "ungroup") return null;
		return this.samePath(target.path, this.childPath(index)) ? target.mode : null;
	}
	describe(node) {
		const rule = this.asRule(node);
		const column = this.columns().find((candidate) => candidate.key === rule.columnKey);
		const kind = column?.filterKind ?? "text";
		return {
			header: column?.header ?? rule.columnKey,
			operator: operatorLabel(kind, rule.operator),
			value: needsValue(rule.operator) ? rule.value : null
		};
	}
	isUnknown(node) {
		const rule = this.asRule(node);
		return rule.columnKey !== "" && !this.columns().some((column) => column.key === rule.columnKey);
	}
	liveCount(node) {
		return isGroupNode(node) ? node.rules.filter(isLive).length : 1;
	}
	combinatorOf(node) {
		return this.asGroup(node).combinator;
	}
	pathAttr(index) {
		return this.childPath(index).join(".");
	}
	onChipKeydown(index, event) {
		if (event.key === " " || event.key === "Spacebar") {
			event.preventDefault();
			this.markNode.emit(this.childPath(index));
			return;
		}
		if (event.key === "Enter") {
			event.preventDefault();
			this.editNode.emit(this.childPath(index));
			return;
		}
		if (event.key === "Delete" || event.key === "Backspace") {
			event.preventDefault();
			this.removeNode.emit(this.childPath(index));
		}
	}
	samePath(a, b) {
		return a !== null && a.length === b.length && a.every((value, index) => value === b[index]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FilterChipsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FilterChipsComponent,
		isStandalone: true,
		selector: "cms-filter-chips",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			group: {
				classPropertyName: "group",
				publicName: "group",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			path: {
				classPropertyName: "path",
				publicName: "path",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markedPath: {
				classPropertyName: "markedPath",
				publicName: "markedPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			draggingPath: {
				classPropertyName: "draggingPath",
				publicName: "draggingPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropTarget: {
				classPropertyName: "dropTarget",
				publicName: "dropTarget",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			editingId: {
				classPropertyName: "editingId",
				publicName: "editingId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			removeNode: "removeNode",
			toggleCombinator: "toggleCombinator",
			markNode: "markNode",
			editNode: "editNode",
			ungroupNode: "ungroupNode"
		},
		host: { classAttribute: "cws:contents" },
		ngImport: i0,
		template: "<!--\n  One level of the filter tree. A group renders `cms-filter-chips` again, which is what makes the\n  nesting arbitrary rather than a fixed number of hand-written levels.\n\n  ⚠ The host is `display: contents`, so these chips join their parent's flex row rather than forming\n  a box of their own. A nested group needs its own box — it draws the parentheses — so that one\n  wraps its children in a bordered span.\n-->\n@for (node of nodes(); track $index; let last = $last) {\n  @if ($first) {\n    <!--\n      The insertion point BEFORE the first chip, so a chip can be moved to the front.\n\n      🔴 **Rendered ALWAYS, never conditionally on the drag** (JFrisbie, 2026-09-14 — reported as\n      \"it shows this and doesn't let me drag it around\", in Chrome).\n\n      These gaps used to appear on `dragstart`, which inserts nodes **immediately beside the element\n      being dragged, inside the dragstart handler**. Chromium takes its drag image and starts its\n      native drag loop at the end of that handler, and a DOM mutation there aborts the drag: the\n      chip never follows the pointer, and the only visible result is the gaps themselves appearing —\n      exactly what the screenshot showed.\n\n      ⚠ **Measured, because it cannot be reproduced through Playwright**: its synthetic drag goes\n      through CDP and skips the drag-image capture, so it completed happily in both browsers while a\n      real mouse could not. What IS measurable is the cause — four DOM mutations during `dragstart`\n      before this change, zero after. That number is the regression test a browser cannot be.\n\n      So only the *colour* changes now. The space is reserved from first paint, which also means the\n      row does not reflow the instant a drag begins.\n\n      🔴 **Reordering lives in the gaps now, and grouping owns the chip.** It used to be split by\n      arithmetic inside the chip — outer quarter \"before\", middle \"onto\" — which made the common\n      gesture fail silently: a grouping drag that landed in the first quarter of the target was read\n      as a reorder, and a reorder onto your own neighbour is a no-op, so nothing happened at all.\n      See the component's own note on `onDragOver`.\n\n      ⚠ **The padding is the hit area, and it is deliberately much wider than the bar it draws.**\n      A drop is only permitted on an element that received a `dragover` and cancelled it, so a\n      target narrow enough to fall between two pointer samples is a target a quick flick misses\n      entirely — and the gesture then ends in nothing, which is the same silent failure this whole\n      change exists to remove. The bar stays 6px because that is what reads as an insertion point;\n      the span around it is 26px because that is what can be hit. The connectors need no such\n      padding, being ~46px already.\n    -->\n    <span\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\n      data-drop-gap\n      data-drop-mode=\"before\"\n      [attr.data-drop-path]=\"pathAttr($index)\"\n      [attr.aria-hidden]=\"true\"\n    >\n      <span\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\n        [class]=\"gapClassFor($index)\"\n      ></span>\n    </span>\n  }\n\n  @if (isRule(node)) {\n    <!--\n      A chip.\n\n      🔴 **Draggable, focusable, double-clickable and hoverable.** `draggable` gives the mouse\n      gesture; `tabindex=\"0\"` plus the keydown handler gives the keyboard one; `dblclick` opens the\n      editor (JFrisbie, 2026-09-11) with Enter as its keyboard twin; the hover colour is what tells\n      someone the chip is a thing you can pick up at all, which a static label does not.\n    -->\n    <span\n      data-drop-mode=\"onto\"\n      [attr.data-drop-path]=\"pathAttr($index)\"\n      [attr.data-drag-path]=\"pathAttr($index)\"\n      tabindex=\"0\"\n      role=\"button\"\n      class=\"cws:inline-flex cws:cursor-grab cws:items-center cws:gap-1.5 cws:rounded cws:border cws:px-2 cws:py-1 cws:text-xs cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:active:cursor-grabbing\"\n      [class]=\"\n        isMarked($index) || isEditing(node)\n          ? 'cws:border-scoular-blue cws:bg-sky-100 cws:text-sky-900 cws:ring-1 cws:ring-scoular-blue cws:dark:bg-sky-900 cws:dark:text-sky-100'\n          : 'cws:border-transparent cws:bg-sky-50 cws:text-sky-900 cws:hover:border-sky-300 cws:hover:bg-sky-100 cws:dark:bg-sky-950/50 cws:dark:text-sky-200 cws:dark:hover:bg-sky-900/70'\n      \"\n      [class.cws:opacity-40]=\"isDragging($index)\"\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\n      [attr.aria-pressed]=\"isMarked($index)\"\n      title=\"Double-click to edit. Drag onto another filter to group them, or into the gap between two to reorder.\"\n      [attr.aria-label]=\"\n        describe(node).header +\n        ' ' +\n        describe(node).operator +\n        (describe(node).value === null ? '' : ' ' + describe(node).value) +\n        (isEditing(node) ? ' — being edited' : '') +\n        (isMarked($index) ? ' — marked for grouping' : '') +\n        '. Press Enter to edit, Space to mark for grouping, Delete to remove.'\n      \"\n      (dblclick)=\"editNode.emit(childPath($index))\"\n      (keydown)=\"onChipKeydown($index, $event)\"\n    >\n      <span class=\"cws:font-medium\">{{ describe(node).header }}</span>\n      <span class=\"cws:italic cws:opacity-80\">{{ describe(node).operator }}</span>\n      @if (describe(node).value !== null) {\n        <span class=\"cws:font-medium\">{{ describe(node).value }}</span>\n      }\n\n      @if (isUnknown(node)) {\n        <!--\n          A saved filter can name a column this grid no longer has. Such a rule matches NOTHING, so\n          the chip says so rather than looking like an ordinary filter that happens to return little.\n        -->\n        <span\n          class=\"cws:rounded cws:bg-amber-100 cws:px-1 cws:text-[10px] cws:font-semibold cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\n          title=\"This column is not in this grid, so this rule matches nothing.\"\n        >\n          not in grid\n        </span>\n      }\n\n      @if (nested()) {\n        <!--\n          Move out of the group — the keyboard's version of dragging the chip clear, and a target for\n          anyone who would rather click than drag.\n\n          🔴 **Only rendered inside a group**, because at the top level there is nothing to move out\n          of. That is also what keeps the chip uncluttered in the common case: the button appears\n          exactly when it has something to do.\n        -->\n        <button\n          type=\"button\"\n          class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\n          title=\"Move out of the group\"\n          [attr.aria-label]=\"\n            'Move ' + describe(node).header + ' ' + describe(node).operator + ' out of its group'\n          \"\n          (click)=\"ungroupNode.emit(childPath($index))\"\n        >\n          ⤴\n        </button>\n      }\n\n      <button\n        type=\"button\"\n        class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\n        [attr.aria-label]=\"'Remove filter ' + describe(node).header + ' ' + describe(node).operator\"\n        (click)=\"removeNode.emit(childPath($index))\"\n      >\n        ✕\n      </button>\n    </span>\n  } @else {\n    <!--\n      A nested group — the parentheses.\n\n      🔴 **Also a drop target.** Dropping onto a group JOINS it, which is how a third rule reaches an\n      existing pair; dropping onto a rule pairs the two. Both read the same gesture and differ only\n      in what is underneath, which is why the mode is decided by the target rather than by the drag.\n    -->\n    <span\n      class=\"cws:inline-flex cws:items-center cws:gap-1.5 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-1.5 cws:py-1 cws:dark:border-slate-600\"\n      data-drop-mode=\"onto\"\n      [attr.data-drop-path]=\"pathAttr($index)\"\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\n      [class.cws:opacity-40]=\"isDragging($index)\"\n    >\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">(</span>\n\n      <cms-filter-chips\n        [columns]=\"columns()\"\n        [group]=\"asGroup(node)\"\n        [path]=\"childPath($index)\"\n        [markedPath]=\"markedPath()\"\n        [draggingPath]=\"draggingPath()\"\n        [dropTarget]=\"dropTarget()\"\n        [editingId]=\"editingId()\"\n        (removeNode)=\"removeNode.emit($event)\"\n        (toggleCombinator)=\"toggleCombinator.emit($event)\"\n        (markNode)=\"markNode.emit($event)\"\n        (editNode)=\"editNode.emit($event)\"\n        (ungroupNode)=\"ungroupNode.emit($event)\"\n      />\n\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">)</span>\n    </span>\n  }\n\n  @if (!last) {\n    <!--\n      The connector, and it is a BUTTON now (JFrisbie, 2026-09-10) — clicking it flips this group's\n      combinator.\n\n      ⚠ **One combinator governs a whole group**, so every connector in this row is the same control\n      shown more than once: clicking any of them flips them all. That is what the model holds, and\n      mixed logic comes from grouping rather than from per-position operators. Stated in the title so\n      the behaviour is not a surprise on a three-chip filter.\n\n      🔴 **It is also the insertion point between these two chips.** That space measured 52px and was\n      completely dead: nothing in it called `preventDefault` on `dragover`, so the browser refused\n      the drop and a chip released between two others simply went back where it came from. The\n      wrapper is what makes the gap a target; the button inside it still toggles on click.\n    -->\n    <span\n      class=\"cws:inline-flex cws:items-center cws:gap-1 cws:self-stretch\"\n      data-drop-gap\n      data-drop-mode=\"before\"\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\n    >\n      <!--\n        The same insertion bar the ends of the row carry, so all three gaps read alike: a bar means\n        \"it lands here\", a ring around a chip means \"it groups with that one\". One signal per\n        gesture — the chip used to carry a left border for `before` as well, which made a reorder\n        look like a group target on the chip next to the gap.\n\n        ⚠ Always present, colour-only — see the leading gap. Inserting this on `dragstart` put a new\n        node beside the chip being dragged and Chromium abandoned the drag.\n      -->\n      <span\n        class=\"cws:w-1.5 cws:self-stretch cws:rounded cws:transition-colors\"\n        [attr.aria-hidden]=\"true\"\n        [class]=\"gapClassFor($index + 1)\"\n      ></span>\n\n      <button\n        type=\"button\"\n        class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-[11px] cws:font-semibold cws:uppercase cws:text-slate-500 cws:transition-colors cws:hover:bg-scoular-blue cws:hover:text-white cws:dark:bg-slate-700 cws:dark:text-slate-300\"\n        [title]=\"\n          'Switch this group to ' +\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND') +\n          ' — one connector governs the whole group'\n        \"\n        [attr.aria-label]=\"\n          'Switch this group from ' +\n          combinatorLabel() +\n          ' to ' +\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND')\n        \"\n        (click)=\"toggleCombinator.emit(path())\"\n      >\n        {{ combinatorLabel() }}\n      </button>\n    </span>\n  }\n\n  @if (last) {\n    <!--\n      The insertion point AFTER the last chip.\n\n      ⚠ Always present, colour-only — see the leading gap.\n\n      🔴 **Without it the end of the row is unreachable**, because every other target is an existing\n      node and \"before the last one\" still lands short of it. Its path is one past the end, which\n      `moveNode` accepts for a `before` drop precisely because that path names a gap rather than a\n      node. Padded to a hittable width for the reason given on the leading gap.\n    -->\n    <span\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\n      data-drop-gap\n      data-drop-mode=\"before\"\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\n      [attr.aria-hidden]=\"true\"\n    >\n      <span\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\n        [class]=\"gapClassFor($index + 1)\"\n      ></span>\n    </span>\n  }\n}\n",
		dependencies: [{
			kind: "component",
			type: FilterChipsComponent,
			selector: "cms-filter-chips",
			inputs: [
				"columns",
				"group",
				"path",
				"markedPath",
				"draggingPath",
				"dropTarget",
				"editingId"
			],
			outputs: [
				"removeNode",
				"toggleCombinator",
				"markNode",
				"editNode",
				"ungroupNode"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FilterChipsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-filter-chips",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FilterChipsComponent],
			host: { class: "cws:contents" },
			template: "<!--\n  One level of the filter tree. A group renders `cms-filter-chips` again, which is what makes the\n  nesting arbitrary rather than a fixed number of hand-written levels.\n\n  ⚠ The host is `display: contents`, so these chips join their parent's flex row rather than forming\n  a box of their own. A nested group needs its own box — it draws the parentheses — so that one\n  wraps its children in a bordered span.\n-->\n@for (node of nodes(); track $index; let last = $last) {\n  @if ($first) {\n    <!--\n      The insertion point BEFORE the first chip, so a chip can be moved to the front.\n\n      🔴 **Rendered ALWAYS, never conditionally on the drag** (JFrisbie, 2026-09-14 — reported as\n      \"it shows this and doesn't let me drag it around\", in Chrome).\n\n      These gaps used to appear on `dragstart`, which inserts nodes **immediately beside the element\n      being dragged, inside the dragstart handler**. Chromium takes its drag image and starts its\n      native drag loop at the end of that handler, and a DOM mutation there aborts the drag: the\n      chip never follows the pointer, and the only visible result is the gaps themselves appearing —\n      exactly what the screenshot showed.\n\n      ⚠ **Measured, because it cannot be reproduced through Playwright**: its synthetic drag goes\n      through CDP and skips the drag-image capture, so it completed happily in both browsers while a\n      real mouse could not. What IS measurable is the cause — four DOM mutations during `dragstart`\n      before this change, zero after. That number is the regression test a browser cannot be.\n\n      So only the *colour* changes now. The space is reserved from first paint, which also means the\n      row does not reflow the instant a drag begins.\n\n      🔴 **Reordering lives in the gaps now, and grouping owns the chip.** It used to be split by\n      arithmetic inside the chip — outer quarter \"before\", middle \"onto\" — which made the common\n      gesture fail silently: a grouping drag that landed in the first quarter of the target was read\n      as a reorder, and a reorder onto your own neighbour is a no-op, so nothing happened at all.\n      See the component's own note on `onDragOver`.\n\n      ⚠ **The padding is the hit area, and it is deliberately much wider than the bar it draws.**\n      A drop is only permitted on an element that received a `dragover` and cancelled it, so a\n      target narrow enough to fall between two pointer samples is a target a quick flick misses\n      entirely — and the gesture then ends in nothing, which is the same silent failure this whole\n      change exists to remove. The bar stays 6px because that is what reads as an insertion point;\n      the span around it is 26px because that is what can be hit. The connectors need no such\n      padding, being ~46px already.\n    -->\n    <span\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\n      data-drop-gap\n      data-drop-mode=\"before\"\n      [attr.data-drop-path]=\"pathAttr($index)\"\n      [attr.aria-hidden]=\"true\"\n    >\n      <span\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\n        [class]=\"gapClassFor($index)\"\n      ></span>\n    </span>\n  }\n\n  @if (isRule(node)) {\n    <!--\n      A chip.\n\n      🔴 **Draggable, focusable, double-clickable and hoverable.** `draggable` gives the mouse\n      gesture; `tabindex=\"0\"` plus the keydown handler gives the keyboard one; `dblclick` opens the\n      editor (JFrisbie, 2026-09-11) with Enter as its keyboard twin; the hover colour is what tells\n      someone the chip is a thing you can pick up at all, which a static label does not.\n    -->\n    <span\n      data-drop-mode=\"onto\"\n      [attr.data-drop-path]=\"pathAttr($index)\"\n      [attr.data-drag-path]=\"pathAttr($index)\"\n      tabindex=\"0\"\n      role=\"button\"\n      class=\"cws:inline-flex cws:cursor-grab cws:items-center cws:gap-1.5 cws:rounded cws:border cws:px-2 cws:py-1 cws:text-xs cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:active:cursor-grabbing\"\n      [class]=\"\n        isMarked($index) || isEditing(node)\n          ? 'cws:border-scoular-blue cws:bg-sky-100 cws:text-sky-900 cws:ring-1 cws:ring-scoular-blue cws:dark:bg-sky-900 cws:dark:text-sky-100'\n          : 'cws:border-transparent cws:bg-sky-50 cws:text-sky-900 cws:hover:border-sky-300 cws:hover:bg-sky-100 cws:dark:bg-sky-950/50 cws:dark:text-sky-200 cws:dark:hover:bg-sky-900/70'\n      \"\n      [class.cws:opacity-40]=\"isDragging($index)\"\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\n      [attr.aria-pressed]=\"isMarked($index)\"\n      title=\"Double-click to edit. Drag onto another filter to group them, or into the gap between two to reorder.\"\n      [attr.aria-label]=\"\n        describe(node).header +\n        ' ' +\n        describe(node).operator +\n        (describe(node).value === null ? '' : ' ' + describe(node).value) +\n        (isEditing(node) ? ' — being edited' : '') +\n        (isMarked($index) ? ' — marked for grouping' : '') +\n        '. Press Enter to edit, Space to mark for grouping, Delete to remove.'\n      \"\n      (dblclick)=\"editNode.emit(childPath($index))\"\n      (keydown)=\"onChipKeydown($index, $event)\"\n    >\n      <span class=\"cws:font-medium\">{{ describe(node).header }}</span>\n      <span class=\"cws:italic cws:opacity-80\">{{ describe(node).operator }}</span>\n      @if (describe(node).value !== null) {\n        <span class=\"cws:font-medium\">{{ describe(node).value }}</span>\n      }\n\n      @if (isUnknown(node)) {\n        <!--\n          A saved filter can name a column this grid no longer has. Such a rule matches NOTHING, so\n          the chip says so rather than looking like an ordinary filter that happens to return little.\n        -->\n        <span\n          class=\"cws:rounded cws:bg-amber-100 cws:px-1 cws:text-[10px] cws:font-semibold cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\n          title=\"This column is not in this grid, so this rule matches nothing.\"\n        >\n          not in grid\n        </span>\n      }\n\n      @if (nested()) {\n        <!--\n          Move out of the group — the keyboard's version of dragging the chip clear, and a target for\n          anyone who would rather click than drag.\n\n          🔴 **Only rendered inside a group**, because at the top level there is nothing to move out\n          of. That is also what keeps the chip uncluttered in the common case: the button appears\n          exactly when it has something to do.\n        -->\n        <button\n          type=\"button\"\n          class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\n          title=\"Move out of the group\"\n          [attr.aria-label]=\"\n            'Move ' + describe(node).header + ' ' + describe(node).operator + ' out of its group'\n          \"\n          (click)=\"ungroupNode.emit(childPath($index))\"\n        >\n          ⤴\n        </button>\n      }\n\n      <button\n        type=\"button\"\n        class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\n        [attr.aria-label]=\"'Remove filter ' + describe(node).header + ' ' + describe(node).operator\"\n        (click)=\"removeNode.emit(childPath($index))\"\n      >\n        ✕\n      </button>\n    </span>\n  } @else {\n    <!--\n      A nested group — the parentheses.\n\n      🔴 **Also a drop target.** Dropping onto a group JOINS it, which is how a third rule reaches an\n      existing pair; dropping onto a rule pairs the two. Both read the same gesture and differ only\n      in what is underneath, which is why the mode is decided by the target rather than by the drag.\n    -->\n    <span\n      class=\"cws:inline-flex cws:items-center cws:gap-1.5 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-1.5 cws:py-1 cws:dark:border-slate-600\"\n      data-drop-mode=\"onto\"\n      [attr.data-drop-path]=\"pathAttr($index)\"\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\n      [class.cws:opacity-40]=\"isDragging($index)\"\n    >\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">(</span>\n\n      <cms-filter-chips\n        [columns]=\"columns()\"\n        [group]=\"asGroup(node)\"\n        [path]=\"childPath($index)\"\n        [markedPath]=\"markedPath()\"\n        [draggingPath]=\"draggingPath()\"\n        [dropTarget]=\"dropTarget()\"\n        [editingId]=\"editingId()\"\n        (removeNode)=\"removeNode.emit($event)\"\n        (toggleCombinator)=\"toggleCombinator.emit($event)\"\n        (markNode)=\"markNode.emit($event)\"\n        (editNode)=\"editNode.emit($event)\"\n        (ungroupNode)=\"ungroupNode.emit($event)\"\n      />\n\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">)</span>\n    </span>\n  }\n\n  @if (!last) {\n    <!--\n      The connector, and it is a BUTTON now (JFrisbie, 2026-09-10) — clicking it flips this group's\n      combinator.\n\n      ⚠ **One combinator governs a whole group**, so every connector in this row is the same control\n      shown more than once: clicking any of them flips them all. That is what the model holds, and\n      mixed logic comes from grouping rather than from per-position operators. Stated in the title so\n      the behaviour is not a surprise on a three-chip filter.\n\n      🔴 **It is also the insertion point between these two chips.** That space measured 52px and was\n      completely dead: nothing in it called `preventDefault` on `dragover`, so the browser refused\n      the drop and a chip released between two others simply went back where it came from. The\n      wrapper is what makes the gap a target; the button inside it still toggles on click.\n    -->\n    <span\n      class=\"cws:inline-flex cws:items-center cws:gap-1 cws:self-stretch\"\n      data-drop-gap\n      data-drop-mode=\"before\"\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\n    >\n      <!--\n        The same insertion bar the ends of the row carry, so all three gaps read alike: a bar means\n        \"it lands here\", a ring around a chip means \"it groups with that one\". One signal per\n        gesture — the chip used to carry a left border for `before` as well, which made a reorder\n        look like a group target on the chip next to the gap.\n\n        ⚠ Always present, colour-only — see the leading gap. Inserting this on `dragstart` put a new\n        node beside the chip being dragged and Chromium abandoned the drag.\n      -->\n      <span\n        class=\"cws:w-1.5 cws:self-stretch cws:rounded cws:transition-colors\"\n        [attr.aria-hidden]=\"true\"\n        [class]=\"gapClassFor($index + 1)\"\n      ></span>\n\n      <button\n        type=\"button\"\n        class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-[11px] cws:font-semibold cws:uppercase cws:text-slate-500 cws:transition-colors cws:hover:bg-scoular-blue cws:hover:text-white cws:dark:bg-slate-700 cws:dark:text-slate-300\"\n        [title]=\"\n          'Switch this group to ' +\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND') +\n          ' — one connector governs the whole group'\n        \"\n        [attr.aria-label]=\"\n          'Switch this group from ' +\n          combinatorLabel() +\n          ' to ' +\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND')\n        \"\n        (click)=\"toggleCombinator.emit(path())\"\n      >\n        {{ combinatorLabel() }}\n      </button>\n    </span>\n  }\n\n  @if (last) {\n    <!--\n      The insertion point AFTER the last chip.\n\n      ⚠ Always present, colour-only — see the leading gap.\n\n      🔴 **Without it the end of the row is unreachable**, because every other target is an existing\n      node and \"before the last one\" still lands short of it. Its path is one past the end, which\n      `moveNode` accepts for a `before` drop precisely because that path names a gap rather than a\n      node. Padded to a hittable width for the reason given on the leading gap.\n    -->\n    <span\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\n      data-drop-gap\n      data-drop-mode=\"before\"\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\n      [attr.aria-hidden]=\"true\"\n    >\n      <span\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\n        [class]=\"gapClassFor($index + 1)\"\n      ></span>\n    </span>\n  }\n}\n"
		}]
	}],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		group: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "group",
				required: true
			}]
		}],
		path: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "path",
				required: false
			}]
		}],
		markedPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markedPath",
				required: false
			}]
		}],
		draggingPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "draggingPath",
				required: false
			}]
		}],
		dropTarget: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropTarget",
				required: false
			}]
		}],
		editingId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editingId",
				required: false
			}]
		}],
		removeNode: [{
			type: i0.Output,
			args: ["removeNode"]
		}],
		toggleCombinator: [{
			type: i0.Output,
			args: ["toggleCombinator"]
		}],
		markNode: [{
			type: i0.Output,
			args: ["markNode"]
		}],
		editNode: [{
			type: i0.Output,
			args: ["editNode"]
		}],
		ungroupNode: [{
			type: i0.Output,
			args: ["ungroupNode"]
		}]
	}
});
function parsePathAttr(attribute) {
	return attribute === null || attribute === "" ? [] : attribute.split(".").map(Number);
}
function dropUnder(x, y) {
	const zone = elementUnder(x, y, "[data-drop-mode]");
	if (zone === null) return null;
	const mode = zone.getAttribute("data-drop-mode");
	if (mode === "ungroup") return {
		path: [],
		mode: "ungroup"
	};
	if (mode !== "onto" && mode !== "before") return null;
	const path = parsePathAttr(zone.getAttribute("data-drop-path"));
	return path.length === 0 ? null : {
		path,
		mode
	};
}
var FilterBuilderComponent = class FilterBuilderComponent {
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	filter = input(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	showAddButton = input(true, ...ngDevMode ? [{ debugName: "showAddButton" }] : /* istanbul ignore next */ []);
	filterChange = output();
	activeConnector = "cws:bg-scoular-blue cws:text-white";
	inactiveConnector = "cws:bg-white cws:text-slate-600 cws:hover:bg-slate-50 cws:dark:bg-slate-700 cws:dark:text-slate-200 cws:dark:hover:bg-slate-600";
	editing = signal(null, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	rules = computed(() => this.filter().rules, ...ngDevMode ? [{ debugName: "rules" }] : /* istanbul ignore next */ []);
	combinator = computed(() => this.filter().combinator, ...ngDevMode ? [{ debugName: "combinator" }] : /* istanbul ignore next */ []);
	activeCount = computed(() => activeRuleCount(this.filter()), ...ngDevMode ? [{ debugName: "activeCount" }] : /* istanbul ignore next */ []);
	showChipsRow = computed(() => this.rules().length > 0 || this.showAddButton() && this.editing() === null, ...ngDevMode ? [{ debugName: "showChipsRow" }] : /* istanbul ignore next */ []);
	hasContent = computed(() => this.showAddButton() || this.rules().length > 0 || this.editing() !== null, ...ngDevMode ? [{ debugName: "hasContent" }] : /* istanbul ignore next */ []);
	showConnector = computed(() => {
		const draft = this.editing();
		const editingExisting = draft !== null && draft.id !== "";
		return activeRuleCount(this.filter()) - (editingExisting ? 1 : 0) > 0;
	}, ...ngDevMode ? [{ debugName: "showConnector" }] : /* istanbul ignore next */ []);
	editingId = computed(() => {
		const draft = this.editing();
		return draft !== null && draft.id !== "" ? draft.id : null;
	}, ...ngDevMode ? [{ debugName: "editingId" }] : /* istanbul ignore next */ []);
	byKey = computed(() => new Map(this.columns().map((column) => [column.key, column])), ...ngDevMode ? [{ debugName: "byKey" }] : /* istanbul ignore next */ []);
	columnOptions = computed(() => this.columns().map((column) => ({
		value: column.key,
		label: column.header
	})), ...ngDevMode ? [{ debugName: "columnOptions" }] : /* istanbul ignore next */ []);
	kindFor(columnKey) {
		return this.byKey().get(columnKey)?.filterKind ?? "text";
	}
	headerFor(rule) {
		return this.byKey().get(rule.columnKey)?.header ?? rule.columnKey;
	}
	operatorTextFor(rule) {
		return operatorLabel(this.kindFor(rule.columnKey), rule.operator);
	}
	showsValue(rule) {
		return needsValue(rule.operator);
	}
	isUnknown(rule) {
		return rule.columnKey !== "" && !this.byKey().has(rule.columnKey);
	}
	draftOperatorOptions = computed(() => {
		const draft = this.editing();
		if (draft === null) return [];
		const kind = this.kindFor(draft.columnKey);
		return operatorsFor(kind).map((operator) => ({
			value: operator,
			label: operatorLabel(kind, operator)
		}));
	}, ...ngDevMode ? [{ debugName: "draftOperatorOptions" }] : /* istanbul ignore next */ []);
	draftInputType = computed(() => {
		const kind = this.kindFor(this.editing()?.columnKey ?? "");
		return kind === "date" ? "date" : kind === "number" ? "number" : "text";
	}, ...ngDevMode ? [{ debugName: "draftInputType" }] : /* istanbul ignore next */ []);
	beginAdd() {
		const first = this.columns()[0];
		this.editing.set({
			id: "",
			columnKey: first?.key ?? "",
			operator: "contains",
			value: ""
		});
	}
	cancelDraft() {
		this.editing.set(null);
	}
	setDraftColumn(columnKey) {
		this.editing.update((draft) => {
			if (draft === null) return draft;
			const allowed = operatorsFor(this.kindFor(columnKey));
			return {
				...draft,
				columnKey,
				operator: allowed.includes(draft.operator) ? draft.operator : allowed[0]
			};
		});
	}
	setDraftOperator(operator) {
		this.editing.update((draft) => draft === null ? draft : {
			...draft,
			operator
		});
	}
	setDraftValue(value) {
		this.editing.update((draft) => draft === null ? draft : {
			...draft,
			value
		});
	}
	canCommit = computed(() => {
		const draft = this.editing();
		return draft !== null && isComplete(draft);
	}, ...ngDevMode ? [{ debugName: "canCommit" }] : /* istanbul ignore next */ []);
	commitDraft() {
		const draft = this.editing();
		if (draft === null || !isComplete(draft)) return;
		const existing = draft.id !== "";
		const committed = existing ? draft : {
			...draft,
			id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
		};
		this.emit({
			...this.filter(),
			rules: existing ? replaceRuleById(this.filter(), committed).rules : [...this.rules(), committed]
		});
		this.editing.set(null);
	}
	marked = signal(null, ...ngDevMode ? [{ debugName: "marked" }] : /* istanbul ignore next */ []);
	dragging = signal(null, ...ngDevMode ? [{ debugName: "dragging" }] : /* istanbul ignore next */ []);
	dropTarget = signal(null, ...ngDevMode ? [{ debugName: "dropTarget" }] : /* istanbul ignore next */ []);
	onRemove(path) {
		const target = nodeAt(this.filter(), path);
		const removedId = target !== null && isRuleNode(target) ? target.id : null;
		this.emit(normaliseGroup(removeAt(this.filter(), path)));
		this.clearGestures();
		if (removedId !== null && this.editing()?.id === removedId) this.editing.set(null);
	}
	onToggleCombinator(path) {
		this.emit(toggleCombinatorAt(this.filter(), path));
	}
	onMark(path) {
		const first = this.marked();
		if (first === null) {
			this.marked.set(path);
			return;
		}
		if (first.length === path.length && first.every((value, index) => value === path[index])) {
			this.marked.set(null);
			return;
		}
		this.emit(groupNodes(this.filter(), path, first));
		this.marked.set(null);
	}
	onEdit(path) {
		const node = nodeAt(this.filter(), path);
		if (node === null || !isRuleNode(node)) return;
		this.clearGestures();
		this.editing.set({ ...node });
	}
	onUngroup(path) {
		this.emit(ungroupAt(this.filter(), path));
		this.clearGestures();
	}
	draggingNested = computed(() => (this.dragging()?.length ?? 0) > 1, ...ngDevMode ? [{ debugName: "draggingNested" }] : /* istanbul ignore next */ []);
	gesture = new PointerDragGesture({
		handleSelector: "[data-drag-path]",
		source: (handle) => parsePathAttr(handle.getAttribute("data-drag-path")),
		target: dropUnder,
		started: (path) => this.dragging.set(path),
		over: (target) => this.dropTarget.set(target),
		ended: () => this.clearGestures(),
		dropped: (from, target) => {
			if (target.mode === "ungroup") {
				this.onUngroup(from);
				return;
			}
			this.applyDrop(from, {
				to: target.path,
				mode: target.mode
			});
		}
	});
	constructor() {
		inject(DestroyRef).onDestroy(() => this.gesture.cancel());
	}
	onPointerDown(event) {
		this.gesture.press(event);
	}
	applyDrop(from, drop) {
		const current = this.filter();
		const next = moveNode(current, from, drop.to, drop.mode);
		if (!sameGroup(next, current)) this.emit(next);
	}
	onEscape() {
		this.clearGestures();
	}
	clearGestures() {
		this.marked.set(null);
		this.dragging.set(null);
		this.dropTarget.set(null);
	}
	setCombinator(combinator) {
		this.emit({
			...this.filter(),
			combinator
		});
	}
	clear() {
		this.editing.set(null);
		this.clearGestures();
		this.emit(EMPTY_FILTER);
	}
	emit(group) {
		this.filterChange.emit(group);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FilterBuilderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FilterBuilderComponent,
		isStandalone: true,
		selector: "cms-filter-builder",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			filter: {
				classPropertyName: "filter",
				publicName: "filter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAddButton: {
				classPropertyName: "showAddButton",
				publicName: "showAddButton",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { filterChange: "filterChange" },
		host: {
			listeners: {
				"pointerdown": "onPointerDown($event)",
				"keydown.escape": "onEscape()"
			},
			properties: { "class.cws:block": "hasContent()" }
		},
		ngImport: i0,
		template: "@if (hasContent()) {\n<div class=\"cws:space-y-2\">\n  <!--\n    🔴 **The chips are a TREE now** (JFrisbie, 2026-09-10), rendered by `cms-filter-chips`, which\n    recurses. This row used to be a flat `@for` over rules with one connector for the whole set.\n\n    What that buys: `A AND (B OR C)`, built by dragging one chip onto another. The model was always\n    a tree away from allowing it — the old docstring said so — and this is the interface for it.\n  -->\n  @if (showChipsRow()) {\n  <!--\n    🔴 **`select-none` is load-bearing, and it is the whole of the Chrome drag defect**\n    (JFrisbie, 2026-09-14).\n\n    Dragging a chip leaves a text SELECTION across this row. Press inside that selection and\n    Chrome does not start our gesture at all -- it starts a native drag of the selected text, and\n    announces it by firing `pointercancel`, which correctly tears our gesture down. So the first\n    drag of a session worked and every one after it did nothing, and the row appeared stuck.\n\n    Measured, with a control: clearing the selection by hand between the two drags makes the\n    second one work, and `user-select: none` makes both work with nothing else changed.\n\n    ⚠ It is also why the same gesture failed under HTML5 drag-and-drop, which is what this row\n    used before: a press inside a selection drags the selection rather than the `draggable`\n    element, so the chip never lifted and the drag could not be cancelled. Two earlier fixes aimed\n    at DOM mutation during `dragstart`; that is a real Chromium rule and it was not this.\n\n    ⚠ The cost is that the chip text can no longer be selected for copying. Chips are controls\n    rather than prose, and the filter is in the URL, so nothing needs to be copied out of here.\n  -->\n  <div class=\"cws:flex cws:select-none cws:flex-wrap cws:items-center cws:gap-2\">\n    @if (activeCount() > 0) {\n      <!--\n        Clear all, with the count — the screenshot's own leading control. Destructive, so it wears\n        the danger colouring rather than looking like the neutral chips beside it.\n      -->\n      <button\n        type=\"button\"\n        class=\"cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:border-red-200 cws:px-2 cws:py-1 cws:text-xs cws:font-medium cws:text-red-700 cws:hover:bg-red-50 cws:dark:border-red-900 cws:dark:text-red-400 cws:dark:hover:bg-red-950/40\"\n        (click)=\"clear()\"\n      >\n        <span aria-hidden=\"true\">✕</span>\n        Clear all filters ({{ activeCount() }})\n      </button>\n    }\n\n    <cms-filter-chips\n      [columns]=\"columns()\"\n      [group]=\"filter()\"\n      [markedPath]=\"marked()\"\n      [draggingPath]=\"dragging()\"\n      [dropTarget]=\"dropTarget()\"\n      [editingId]=\"editingId()\"\n      (removeNode)=\"onRemove($event)\"\n      (toggleCombinator)=\"onToggleCombinator($event)\"\n      (markNode)=\"onMark($event)\"\n      (editNode)=\"onEdit($event)\"\n      (ungroupNode)=\"onUngroup($event)\"\n    />\n\n    <!--\n      The way OUT of a group, shown only while a chip that is inside one is being dragged.\n\n      Every other drop target is a node, so a filter whose chips are all inside one set of\n      parentheses had nowhere to aim -- there was no chip outside the group to drop before, and the\n      row read as permanently grouped.\n\n      ⚠ **`[hidden]`, not `@if`.** A hidden element is not returned by `elementFromPoint`, so it\n      cannot be hit while it does not apply -- which is the whole of the guard, and it costs no\n      structural change when a drag begins.\n\n      ⚠ **Its original reason is SUPERSEDED and is corrected rather than deleted.** This was written\n      as a fix for Chromium abandoning a native drag when the DOM changes inside `dragstart`. That is\n      a real rule and it was not the defect: the row no longer uses native drag at all, and the cause\n      was the text selection recorded on the chip row above. Kept as `[hidden]` on its own merits.\n    -->\n    <span\n      class=\"cws:inline-flex cws:items-center cws:rounded cws:border cws:border-dashed cws:border-scoular-blue cws:bg-sky-50 cws:px-3 cws:py-1 cws:text-xs cws:font-medium cws:text-scoular-blue cws:dark:bg-sky-950/40\"\n      data-drop-mode=\"ungroup\"\n      [hidden]=\"!draggingNested()\"\n      [class.cws:ring-2]=\"dropTarget()?.mode === 'ungroup'\"\n      [class.cws:ring-scoular-blue]=\"dropTarget()?.mode === 'ungroup'\"\n    >\n      Drop here to take it out of the group\n    </span>\n\n    @if (showAddButton() && !editing()) {\n      <button\n        type=\"button\"\n        class=\"cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:border-scoular-blue cws:hover:text-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-300\"\n        (click)=\"beginAdd()\"\n      >\n        + Add filter\n      </button>\n    }\n  </div>\n  }\n\n  <!--\n    What the chips can DO, which nothing else on screen says.\n\n    Double-click to edit is the line that has to be there: a chip looks like a label, and nothing\n    about it suggests it opens the editor. The grouping half appears only once a second chip exists,\n    because grouping needs two and before that it is an instruction for something impossible.\n\n    It is not decoration. Drag-and-drop is unreachable from a keyboard and \"fully keyboard operable\"\n    is a standing acceptance criterion here (docs/05): Space marks a chip and Space on a second\n    groups them, Enter opens the editor, and a chip inside a group carries its own Move out button.\n  -->\n  @if (activeCount() > 0) {\n    <p class=\"cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n      @if (marked() !== null) {\n        <span class=\"cws:font-medium cws:text-scoular-blue\">One filter marked.</span>\n        Press Space on another to group them, or Escape to cancel.\n      } @else if (activeCount() > 1) {\n        Double-click a filter to edit it. Drag one onto another to group them, drop one between two\n        to reorder, or press Space on one and then on a second.\n      } @else {\n        Double-click a filter to edit it.\n      }\n    </p>\n  }\n\n  <!--\n    The editor row. Appears on \"+ Add filter\" and on editing a chip, and commits explicitly.\n\n    Laid out as the screenshot has it: Connect with · Field · Operator · Value · Add filter · Cancel,\n    each control under its own label.\n  -->\n  @if (editing(); as draft) {\n    <div\n      class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:dark:bg-slate-800/60\"\n      role=\"group\"\n      aria-label=\"Add a filter\"\n    >\n      <!--\n        🔴 **Only from the SECOND rule onward** (JFrisbie, 2026-09-10). AND/OR describes how a rule\n        combines with another rule, so on the first one the control asks a question with no\n        consequence — and whichever way it is answered then silently governs every rule added after.\n\n        See `showConnector`: it counts the rules OTHER than the one being edited, so picking up the\n        only chip to edit it hides the control again rather than offering the same empty choice.\n      -->\n      @if (showConnector()) {\n      <div class=\"cws:flex cws:items-center cws:gap-1\">\n        <!--\n          ⚠ The caption is `sr-only` rather than removed. The AND/OR pair is a `role=\"group\"` whose\n          own `aria-label` says what it does, but the two buttons read as bare \"AND\" / \"OR\" without\n          something naming the choice they belong to.\n\n          The (i) hint that sat here was removed at JFrisbie's request (2026-09-10). Nothing asserted\n          it, and the group's label carries the same information to assistive technology.\n        -->\n        <span class=\"sr-only\">Connect with</span>\n\n        <div class=\"cws:flex cws:overflow-hidden cws:rounded cws:border cws:border-slate-300 cws:dark:border-slate-600\" role=\"group\" aria-label=\"How rules combine\">\n          <button\n            type=\"button\"\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\n            [class]=\"combinator() === 'and' ? activeConnector : inactiveConnector\"\n            [attr.aria-pressed]=\"combinator() === 'and'\"\n            (click)=\"setCombinator('and')\"\n          >\n            AND\n          </button>\n          <button\n            type=\"button\"\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\n            [class]=\"combinator() === 'or' ? activeConnector : inactiveConnector\"\n            [attr.aria-pressed]=\"combinator() === 'or'\"\n            (click)=\"setCombinator('or')\"\n          >\n            OR\n          </button>\n        </div>\n      </div>\n      }\n\n      <div class=\"cws:w-44\">\n        <cms-select\n          [options]=\"columnOptions()\"\n          [value]=\"draft.columnKey\"\n          label=\"Field\"\n          (valueChange)=\"setDraftColumn($event)\"\n        />\n      </div>\n\n      <div class=\"cws:w-40\">\n        <cms-select\n          [options]=\"draftOperatorOptions()\"\n          [value]=\"draft.operator\"\n          label=\"Operator\"\n          (valueChange)=\"setDraftOperator($event)\"\n        />\n      </div>\n\n      <!--\n        Hidden for `is blank` / `is not blank`, which take no value. A disabled box there would\n        invite someone to type into it and wonder why nothing changed.\n      -->\n      @if (showsValue(draft)) {\n        <label class=\"cws:w-44\">\n          <span class=\"sr-only\">Value</span>\n          <input\n            [type]=\"draftInputType()\"\n            class=\"scoular-form-input cws:w-full\"\n            autocomplete=\"off\"\n            placeholder=\"Enter value…\"\n            [value]=\"draft.value\"\n            (input)=\"setDraftValue($any($event.target).value)\"\n            (keydown.enter)=\"commitDraft()\"\n          />\n        </label>\n      }\n\n      <!--\n        ⚠ Add is disabled until the draft is complete, and `commitDraft` refuses a blank a second\n        time — the attribute is a courtesy, not a guarantee. A rule committed without a value would\n        sit in the chip row filtering nothing and reading as though it were.\n      -->\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n        [disabled]=\"!canCommit()\"\n        (click)=\"commitDraft()\"\n      >\n        {{ draft.id === '' ? 'Add filter' : 'Update filter' }}\n      </button>\n\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelDraft()\">\n        Cancel\n      </button>\n    </div>\n  }\n</div>\n}\n",
		dependencies: [{
			kind: "component",
			type: FilterChipsComponent,
			selector: "cms-filter-chips",
			inputs: [
				"columns",
				"group",
				"path",
				"markedPath",
				"draggingPath",
				"dropTarget",
				"editingId"
			],
			outputs: [
				"removeNode",
				"toggleCombinator",
				"markNode",
				"editNode",
				"ungroupNode"
			]
		}, {
			kind: "component",
			type: SelectComponent,
			selector: "cms-select",
			inputs: [
				"options",
				"value",
				"label",
				"labelledBy",
				"disabled"
			],
			outputs: ["valueChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FilterBuilderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-filter-builder",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FilterChipsComponent, SelectComponent],
			host: {
				"(pointerdown)": "onPointerDown($event)",
				"[class.cws:block]": "hasContent()",
				"(keydown.escape)": "onEscape()"
			},
			template: "@if (hasContent()) {\n<div class=\"cws:space-y-2\">\n  <!--\n    🔴 **The chips are a TREE now** (JFrisbie, 2026-09-10), rendered by `cms-filter-chips`, which\n    recurses. This row used to be a flat `@for` over rules with one connector for the whole set.\n\n    What that buys: `A AND (B OR C)`, built by dragging one chip onto another. The model was always\n    a tree away from allowing it — the old docstring said so — and this is the interface for it.\n  -->\n  @if (showChipsRow()) {\n  <!--\n    🔴 **`select-none` is load-bearing, and it is the whole of the Chrome drag defect**\n    (JFrisbie, 2026-09-14).\n\n    Dragging a chip leaves a text SELECTION across this row. Press inside that selection and\n    Chrome does not start our gesture at all -- it starts a native drag of the selected text, and\n    announces it by firing `pointercancel`, which correctly tears our gesture down. So the first\n    drag of a session worked and every one after it did nothing, and the row appeared stuck.\n\n    Measured, with a control: clearing the selection by hand between the two drags makes the\n    second one work, and `user-select: none` makes both work with nothing else changed.\n\n    ⚠ It is also why the same gesture failed under HTML5 drag-and-drop, which is what this row\n    used before: a press inside a selection drags the selection rather than the `draggable`\n    element, so the chip never lifted and the drag could not be cancelled. Two earlier fixes aimed\n    at DOM mutation during `dragstart`; that is a real Chromium rule and it was not this.\n\n    ⚠ The cost is that the chip text can no longer be selected for copying. Chips are controls\n    rather than prose, and the filter is in the URL, so nothing needs to be copied out of here.\n  -->\n  <div class=\"cws:flex cws:select-none cws:flex-wrap cws:items-center cws:gap-2\">\n    @if (activeCount() > 0) {\n      <!--\n        Clear all, with the count — the screenshot's own leading control. Destructive, so it wears\n        the danger colouring rather than looking like the neutral chips beside it.\n      -->\n      <button\n        type=\"button\"\n        class=\"cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:border-red-200 cws:px-2 cws:py-1 cws:text-xs cws:font-medium cws:text-red-700 cws:hover:bg-red-50 cws:dark:border-red-900 cws:dark:text-red-400 cws:dark:hover:bg-red-950/40\"\n        (click)=\"clear()\"\n      >\n        <span aria-hidden=\"true\">✕</span>\n        Clear all filters ({{ activeCount() }})\n      </button>\n    }\n\n    <cms-filter-chips\n      [columns]=\"columns()\"\n      [group]=\"filter()\"\n      [markedPath]=\"marked()\"\n      [draggingPath]=\"dragging()\"\n      [dropTarget]=\"dropTarget()\"\n      [editingId]=\"editingId()\"\n      (removeNode)=\"onRemove($event)\"\n      (toggleCombinator)=\"onToggleCombinator($event)\"\n      (markNode)=\"onMark($event)\"\n      (editNode)=\"onEdit($event)\"\n      (ungroupNode)=\"onUngroup($event)\"\n    />\n\n    <!--\n      The way OUT of a group, shown only while a chip that is inside one is being dragged.\n\n      Every other drop target is a node, so a filter whose chips are all inside one set of\n      parentheses had nowhere to aim -- there was no chip outside the group to drop before, and the\n      row read as permanently grouped.\n\n      ⚠ **`[hidden]`, not `@if`.** A hidden element is not returned by `elementFromPoint`, so it\n      cannot be hit while it does not apply -- which is the whole of the guard, and it costs no\n      structural change when a drag begins.\n\n      ⚠ **Its original reason is SUPERSEDED and is corrected rather than deleted.** This was written\n      as a fix for Chromium abandoning a native drag when the DOM changes inside `dragstart`. That is\n      a real rule and it was not the defect: the row no longer uses native drag at all, and the cause\n      was the text selection recorded on the chip row above. Kept as `[hidden]` on its own merits.\n    -->\n    <span\n      class=\"cws:inline-flex cws:items-center cws:rounded cws:border cws:border-dashed cws:border-scoular-blue cws:bg-sky-50 cws:px-3 cws:py-1 cws:text-xs cws:font-medium cws:text-scoular-blue cws:dark:bg-sky-950/40\"\n      data-drop-mode=\"ungroup\"\n      [hidden]=\"!draggingNested()\"\n      [class.cws:ring-2]=\"dropTarget()?.mode === 'ungroup'\"\n      [class.cws:ring-scoular-blue]=\"dropTarget()?.mode === 'ungroup'\"\n    >\n      Drop here to take it out of the group\n    </span>\n\n    @if (showAddButton() && !editing()) {\n      <button\n        type=\"button\"\n        class=\"cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:border-scoular-blue cws:hover:text-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-300\"\n        (click)=\"beginAdd()\"\n      >\n        + Add filter\n      </button>\n    }\n  </div>\n  }\n\n  <!--\n    What the chips can DO, which nothing else on screen says.\n\n    Double-click to edit is the line that has to be there: a chip looks like a label, and nothing\n    about it suggests it opens the editor. The grouping half appears only once a second chip exists,\n    because grouping needs two and before that it is an instruction for something impossible.\n\n    It is not decoration. Drag-and-drop is unreachable from a keyboard and \"fully keyboard operable\"\n    is a standing acceptance criterion here (docs/05): Space marks a chip and Space on a second\n    groups them, Enter opens the editor, and a chip inside a group carries its own Move out button.\n  -->\n  @if (activeCount() > 0) {\n    <p class=\"cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n      @if (marked() !== null) {\n        <span class=\"cws:font-medium cws:text-scoular-blue\">One filter marked.</span>\n        Press Space on another to group them, or Escape to cancel.\n      } @else if (activeCount() > 1) {\n        Double-click a filter to edit it. Drag one onto another to group them, drop one between two\n        to reorder, or press Space on one and then on a second.\n      } @else {\n        Double-click a filter to edit it.\n      }\n    </p>\n  }\n\n  <!--\n    The editor row. Appears on \"+ Add filter\" and on editing a chip, and commits explicitly.\n\n    Laid out as the screenshot has it: Connect with · Field · Operator · Value · Add filter · Cancel,\n    each control under its own label.\n  -->\n  @if (editing(); as draft) {\n    <div\n      class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:dark:bg-slate-800/60\"\n      role=\"group\"\n      aria-label=\"Add a filter\"\n    >\n      <!--\n        🔴 **Only from the SECOND rule onward** (JFrisbie, 2026-09-10). AND/OR describes how a rule\n        combines with another rule, so on the first one the control asks a question with no\n        consequence — and whichever way it is answered then silently governs every rule added after.\n\n        See `showConnector`: it counts the rules OTHER than the one being edited, so picking up the\n        only chip to edit it hides the control again rather than offering the same empty choice.\n      -->\n      @if (showConnector()) {\n      <div class=\"cws:flex cws:items-center cws:gap-1\">\n        <!--\n          ⚠ The caption is `sr-only` rather than removed. The AND/OR pair is a `role=\"group\"` whose\n          own `aria-label` says what it does, but the two buttons read as bare \"AND\" / \"OR\" without\n          something naming the choice they belong to.\n\n          The (i) hint that sat here was removed at JFrisbie's request (2026-09-10). Nothing asserted\n          it, and the group's label carries the same information to assistive technology.\n        -->\n        <span class=\"sr-only\">Connect with</span>\n\n        <div class=\"cws:flex cws:overflow-hidden cws:rounded cws:border cws:border-slate-300 cws:dark:border-slate-600\" role=\"group\" aria-label=\"How rules combine\">\n          <button\n            type=\"button\"\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\n            [class]=\"combinator() === 'and' ? activeConnector : inactiveConnector\"\n            [attr.aria-pressed]=\"combinator() === 'and'\"\n            (click)=\"setCombinator('and')\"\n          >\n            AND\n          </button>\n          <button\n            type=\"button\"\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\n            [class]=\"combinator() === 'or' ? activeConnector : inactiveConnector\"\n            [attr.aria-pressed]=\"combinator() === 'or'\"\n            (click)=\"setCombinator('or')\"\n          >\n            OR\n          </button>\n        </div>\n      </div>\n      }\n\n      <div class=\"cws:w-44\">\n        <cms-select\n          [options]=\"columnOptions()\"\n          [value]=\"draft.columnKey\"\n          label=\"Field\"\n          (valueChange)=\"setDraftColumn($event)\"\n        />\n      </div>\n\n      <div class=\"cws:w-40\">\n        <cms-select\n          [options]=\"draftOperatorOptions()\"\n          [value]=\"draft.operator\"\n          label=\"Operator\"\n          (valueChange)=\"setDraftOperator($event)\"\n        />\n      </div>\n\n      <!--\n        Hidden for `is blank` / `is not blank`, which take no value. A disabled box there would\n        invite someone to type into it and wonder why nothing changed.\n      -->\n      @if (showsValue(draft)) {\n        <label class=\"cws:w-44\">\n          <span class=\"sr-only\">Value</span>\n          <input\n            [type]=\"draftInputType()\"\n            class=\"scoular-form-input cws:w-full\"\n            autocomplete=\"off\"\n            placeholder=\"Enter value…\"\n            [value]=\"draft.value\"\n            (input)=\"setDraftValue($any($event.target).value)\"\n            (keydown.enter)=\"commitDraft()\"\n          />\n        </label>\n      }\n\n      <!--\n        ⚠ Add is disabled until the draft is complete, and `commitDraft` refuses a blank a second\n        time — the attribute is a courtesy, not a guarantee. A rule committed without a value would\n        sit in the chip row filtering nothing and reading as though it were.\n      -->\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n        [disabled]=\"!canCommit()\"\n        (click)=\"commitDraft()\"\n      >\n        {{ draft.id === '' ? 'Add filter' : 'Update filter' }}\n      </button>\n\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelDraft()\">\n        Cancel\n      </button>\n    </div>\n  }\n</div>\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		filter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: false
			}]
		}],
		showAddButton: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAddButton",
				required: false
			}]
		}],
		filterChange: [{
			type: i0.Output,
			args: ["filterChange"]
		}]
	}
});
var FilterSelectComponent = class FilterSelectComponent {
	store = inject(SAVED_FILTER_STORE);
	scope = input.required(...ngDevMode ? [{ debugName: "scope" }] : /* istanbul ignore next */ []);
	filter = input.required(...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	sorts = input.required(...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	baselineLabel = input("All Contracts", ...ngDevMode ? [{ debugName: "baselineLabel" }] : /* istanbul ignore next */ []);
	columnLayout = input(null, ...ngDevMode ? [{ debugName: "columnLayout" }] : /* istanbul ignore next */ []);
	viewChange = output();
	panel = signal("list", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	draftName = signal("", ...ngDevMode ? [{ debugName: "draftName" }] : /* istanbul ignore next */ []);
	includeSort = signal(false, ...ngDevMode ? [{ debugName: "includeSort" }] : /* istanbul ignore next */ []);
	includeColumns = signal(false, ...ngDevMode ? [{ debugName: "includeColumns" }] : /* istanbul ignore next */ []);
	columnSummary = computed(() => {
		const layout = this.columnLayout();
		if (layout === null || layout.isDefault) return "the grid shows its default columns";
		const hidden = layout.current.hidden.length;
		return hidden === 0 ? "columns reordered" : `${hidden} not shown`;
	}, ...ngDevMode ? [{ debugName: "columnSummary" }] : /* istanbul ignore next */ []);
	savedFilters = computed(() => {
		this.store.revision();
		return this.store.list(this.scope());
	}, ...ngDevMode ? [{ debugName: "savedFilters" }] : /* istanbul ignore next */ []);
	defaultId = computed(() => {
		this.store.revision();
		return this.store.defaultId(this.scope());
	}, ...ngDevMode ? [{ debugName: "defaultId" }] : /* istanbul ignore next */ []);
	activeFilter = computed(() => {
		const candidates = this.savedFilters().filter((saved) => sameGroup(saved.group, this.filter()));
		if (candidates.length <= 1) return candidates[0] ?? null;
		const sorts = this.sorts();
		return candidates.find((saved) => sameSortChain(saved.sort ?? [], sorts)) ?? candidates[0];
	}, ...ngDevMode ? [{ debugName: "activeFilter" }] : /* istanbul ignore next */ []);
	isCustom = computed(() => this.activeFilter() === null && activeRuleCount(this.filter()) > 0, ...ngDevMode ? [{ debugName: "isCustom" }] : /* istanbul ignore next */ []);
	label = computed(() => {
		const active = this.activeFilter();
		if (active !== null) return active.name;
		return this.isCustom() ? "Custom view" : this.baselineLabel();
	}, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	adHocCount = computed(() => this.isCustom() ? activeRuleCount(this.filter()) : 0, ...ngDevMode ? [{ debugName: "adHocCount" }] : /* istanbul ignore next */ []);
	sortSummary = computed(() => {
		const sorts = this.sorts();
		return sorts.length === 0 ? "currently unsorted" : sorts.map((sort) => `${sort.key} ${sort.direction === "asc" ? "asc" : "desc"}`).join(", ");
	}, ...ngDevMode ? [{ debugName: "sortSummary" }] : /* istanbul ignore next */ []);
	canSave = computed(() => this.draftName().trim().length > 0, ...ngDevMode ? [{ debugName: "canSave" }] : /* istanbul ignore next */ []);
	openSave() {
		this.draftName.set(this.activeFilter()?.name ?? "");
		this.includeSort.set(this.sorts().length > 0);
		this.includeColumns.set(this.columnLayout()?.isDefault === false);
		this.panel.set("save");
	}
	openManage() {
		this.panel.set("manage");
	}
	backToList() {
		this.panel.set("list");
	}
	reset() {
		this.panel.set("list");
		this.draftName.set("");
	}
	apply(saved) {
		if (saved === null) {
			this.viewChange.emit({
				group: {
					combinator: "and",
					rules: []
				},
				sort: [],
				columns: null
			});
			return;
		}
		this.viewChange.emit({
			group: saved.group,
			sort: saved.sort ?? [],
			...saved.columns === void 0 ? {} : { columns: saved.columns }
		});
	}
	commitSave() {
		if (!this.canSave()) return;
		const layout = this.columnLayout();
		this.store.save(this.scope(), this.draftName(), this.filter(), this.includeSort() ? this.sorts() : void 0, layout !== null && this.includeColumns() ? layout.current : void 0);
		this.reset();
	}
	remove(saved) {
		this.store.remove(this.scope(), saved.id);
	}
	toggleDefault(saved) {
		this.store.setDefault(this.scope(), this.defaultId() === saved.id ? null : saved.id);
	}
	onNameInput(value) {
		this.draftName.set(value);
	}
	onIncludeSortChange(checked) {
		this.includeSort.set(checked);
	}
	onIncludeColumnsChange(checked) {
		this.includeColumns.set(checked);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FilterSelectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FilterSelectComponent,
		isStandalone: true,
		selector: "cms-filter-select",
		inputs: {
			scope: {
				classPropertyName: "scope",
				publicName: "scope",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			filter: {
				classPropertyName: "filter",
				publicName: "filter",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			sorts: {
				classPropertyName: "sorts",
				publicName: "sorts",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			baselineLabel: {
				classPropertyName: "baselineLabel",
				publicName: "baselineLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			columnLayout: {
				classPropertyName: "columnLayout",
				publicName: "columnLayout",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { viewChange: "viewChange" },
		ngImport: i0,
		template: "<!--\n  The view selector. Sits where the Status dropdown used to (JFrisbie, 2026-09-10).\n\n  🔴 A disclosure, not a `role=\"menu\"`. Two of the three panels contain a form — a name box, a\n  checkbox, a Save button — and menu semantics promise arrow-key item navigation that a form inside\n  breaks. `aria-expanded` + `aria-controls` on the trigger describes what this actually is.\n-->\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:flex-col cws:gap-1\">\n  <!--\n    The caption wears the Search box's caption style (`text-sm`, `slate-700`), because the two sit side by\n    side on every grid toolbar. At `text-xs` it was smaller and sat 3px lower than \"Search\" beside it.\n  -->\n  <span id=\"view-select-label\" class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">\n    View\n  </span>\n\n  <!--\n    `scoular-form-input` for the box model, so this matches the search box's height exactly without a\n    hard-coded pixel value.\n\n    ⚠ That class is `@apply w-full`, so a `w-56` here would be overridden — the design system compiles\n    unlayered and beats a Tailwind utility at equal specificity. The width goes on the wrapper this\n    component is placed in, where nothing contests it. Seventh instance of that trap.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <button\n    type=\"button\"\n    class=\"scoular-form-input cws:flex cws:w-full cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\n    aria-haspopup=\"true\"\n    aria-controls=\"view-select-panel\"\n    aria-labelledby=\"view-select-label\"\n    [attr.aria-expanded]=\"menu.open()\"\n    (click)=\"menu.toggle(); reset()\"\n  >\n    <span class=\"truncate\">\n      {{ label() }}\n      @if (adHocCount() > 0) {\n        <!--\n          The qualifier beside \"Custom view\". The name already says the grid is filtered; this says\n          by how much, which is what tells someone whether the chips below are all of it.\n        -->\n        <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n          · {{ adHocCount() }} {{ adHocCount() === 1 ? 'filter' : 'filters' }}\n        </span>\n      }\n    </span>\n    <!-- The shared caret (2026-10-28), the same chevron as every other list-opening field. -->\n    <cms-dropdown-caret [open]=\"menu.open()\" />\n  </button>\n\n  @if (menu.open()) {\n    <div\n      id=\"view-select-panel\"\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:w-80 cws:p-2\"\n      [attr.aria-label]=\"panel() === 'manage' ? 'Manage filters' : 'Views'\"\n    >\n      @switch (panel()) {\n        @case ('list') {\n          <ul class=\"cws:space-y-1\">\n            <li>\n              <button\n                type=\"button\"\n                class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\n                (click)=\"menu.close(); apply(null)\"\n              >\n                <!--\n                  ⚠ Ticked only when the grid really is unfiltered. `activeFilter() === null` is\n                  true of a custom view too, so ticking on that alone would mark the baseline as\n                  selected while the grid showed a filtered set — and selecting it would then look\n                  like a no-op rather than the way back to everything.\n                -->\n                <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\n                  {{ activeFilter() === null && !isCustom() ? '✓' : '' }}\n                </span>\n                <span class=\"cws:flex-1\">{{ baselineLabel() }}</span>\n              </button>\n            </li>\n\n            @if (savedFilters().length > 0) {\n              <li aria-hidden=\"true\"><div class=\"scoular-dropdown-divider\"></div></li>\n            }\n\n            @for (saved of savedFilters(); track saved.id) {\n              <li>\n                <button\n                  type=\"button\"\n                  class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\n                  (click)=\"menu.close(); apply(saved)\"\n                >\n                  <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\n                    {{ activeFilter()?.id === saved.id ? '✓' : '' }}\n                  </span>\n                  <span class=\"cws:flex-1 truncate\">{{ saved.name }}</span>\n                  @if (defaultId() === saved.id) {\n                    <!--\n                      The star is the only place the default is visible from the list. Titled rather\n                      than left to be inferred: a marked row with no explanation reads as decoration.\n                    -->\n                    <span\n                      class=\"cws:shrink-0 cws:text-amber-500\"\n                      title=\"Applied automatically when you open this screen\"\n                      >★</span\n                    >\n                  }\n                  @if (saved.sort !== undefined) {\n                    <span\n                      class=\"cws:shrink-0 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\"\n                      title=\"Selecting this view also sets its sorting\"\n                      >sorted</span\n                    >\n                  }\n                  @if (saved.columns !== undefined) {\n                    <!-- #1150: the column layout's tag, beside the sorting's. -->\n                    <span\n                      class=\"cws:shrink-0 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\"\n                      title=\"Selecting this view also sets its columns for this session\"\n                      >columns</span\n                    >\n                  }\n                </button>\n              </li>\n            }\n          </ul>\n\n          <div class=\"scoular-dropdown-divider\"></div>\n\n          <div class=\"cws:flex cws:items-center cws:gap-1\">\n            <button\n              type=\"button\"\n              class=\"scoular-dropdown-item cws:flex-1 cws:text-left\"\n              (click)=\"openSave()\"\n            >\n              + Save current filter…\n            </button>\n\n            <!--\n              The gear, per the ask. `title` gives the hover text and `aria-label` gives it a name —\n              both, because a `title` alone is not an accessible name and an icon-only control with\n              neither is unreachable by anything but a mouse.\n            -->\n            <button\n              type=\"button\"\n              class=\"cws:rounded cws:px-2 cws:py-1 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700\"\n              title=\"Manage filters\"\n              aria-label=\"Manage filters\"\n              (click)=\"openManage()\"\n            >\n              ⚙\n            </button>\n          </div>\n\n          <!--\n            🔴 Not boilerplate. These live in this browser's `localStorage` — there is no preferences\n            endpoint — so they do NOT follow the user to another machine or profile, and clearing site\n            data loses them. Someone who names a view will look for it again, and finding it missing\n            on a second machine reads as the feature being broken.\n          -->\n          <p class=\"cws:px-2 cws:pt-1 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n            Saved for you, in this browser only.\n          </p>\n        }\n\n        @case ('save') {\n          <p class=\"cws:px-2 cws:pb-2 cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\n            Save current filter\n          </p>\n\n          <div class=\"cws:space-y-2 cws:px-2\">\n            <label class=\"cws:flex cws:flex-col cws:gap-1\">\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Name</span>\n              <input\n                type=\"text\"\n                class=\"scoular-form-input cws:w-full\"\n                placeholder=\"My unpriced corn\"\n                [value]=\"draftName()\"\n                (input)=\"onNameInput($any($event.target).value)\"\n                (keydown.enter)=\"commitSave()\"\n              />\n            </label>\n\n            <!--\n              The sorting checkbox, per the ask.\n\n              ⚠ Checked by default only when something IS sorted. Saving an empty sort chain is\n              legitimate — it makes selecting the view *clear* the sort — but it is not what someone\n              means when they name a view on an unsorted grid, and a checkbox that silently arms that\n              would make an unrelated view reset the user's sorting later.\n            -->\n            <label class=\"cws:flex cws:items-start cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n              <input\n                type=\"checkbox\"\n                class=\"cws:mt-0.5\"\n                [checked]=\"includeSort()\"\n                (change)=\"onIncludeSortChange($any($event.target).checked)\"\n              />\n              <span>\n                Also save the sorting\n                <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ sortSummary() }})</span>\n              </span>\n            </label>\n\n            <!--\n              #1150: the column layout, built the same way as the sorting box above. Offered only\n              where the grid passes a layout. Checked by default only when the layout differs from\n              the default; otherwise unchecked, and it says the grid shows its default columns.\n            -->\n            @if (columnLayout() !== null) {\n              <label class=\"cws:flex cws:items-start cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n                <input\n                  type=\"checkbox\"\n                  class=\"cws:mt-0.5\"\n                  [checked]=\"includeColumns()\"\n                  (change)=\"onIncludeColumnsChange($any($event.target).checked)\"\n                />\n                <span>\n                  Include column layout\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ columnSummary() }})</span>\n                </span>\n              </label>\n            }\n\n            @if (activeFilter(); as active) {\n              <p class=\"cws:text-[11px] cws:text-amber-700 cws:dark:text-amber-500\">\n                Saving under the name “{{ active.name }}” replaces that view.\n              </p>\n            }\n          </div>\n\n          <div class=\"cws:mt-2 cws:flex cws:justify-end cws:gap-2 cws:px-2\">\n            <button type=\"button\" class=\"scoular-btn scoular-btn-outline\" (click)=\"backToList()\">\n              Cancel\n            </button>\n            <button\n              type=\"button\"\n              class=\"scoular-btn scoular-btn-primary\"\n              [disabled]=\"!canSave()\"\n              (click)=\"commitSave()\"\n            >\n              Save\n            </button>\n          </div>\n        }\n\n        @case ('manage') {\n          <div class=\"cws:flex cws:items-center cws:justify-between cws:px-2 cws:pb-2\">\n            <p class=\"cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">Manage filters</p>\n            <button\n              type=\"button\"\n              class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\n              (click)=\"backToList()\"\n            >\n              Back\n            </button>\n          </div>\n\n          @if (savedFilters().length === 0) {\n            <p class=\"cws:px-2 cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Nothing saved yet.</p>\n          } @else {\n            <ul class=\"cws:space-y-1\">\n              @for (saved of savedFilters(); track saved.id) {\n                <li class=\"cws:flex cws:items-center cws:gap-1 cws:px-1\">\n                  <!--\n                    A toggle rather than a radio group with a fourth \"none\" row: the star that makes a\n                    view the default also clears it, and a list of filters stays a list of filters.\n                  -->\n                  <button\n                    type=\"button\"\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\n                    [class.cws:text-amber-500]=\"defaultId() === saved.id\"\n                    [class.cws:text-slate-400]=\"defaultId() !== saved.id\"\n                    [attr.aria-pressed]=\"defaultId() === saved.id\"\n                    [title]=\"\n                      defaultId() === saved.id\n                        ? 'Stop applying this on load'\n                        : 'Apply this automatically on load'\n                    \"\n                    [attr.aria-label]=\"\n                      (defaultId() === saved.id ? 'Unset default filter ' : 'Set default filter ') +\n                      saved.name\n                    \"\n                    (click)=\"toggleDefault(saved)\"\n                  >\n                    ★\n                  </button>\n\n                  <span class=\"cws:flex-1 truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\n                    {{ saved.name }}\n                  </span>\n\n                  <button\n                    type=\"button\"\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:bg-slate-100 cws:hover:text-red-700 cws:dark:hover:bg-slate-700\"\n                    [attr.aria-label]=\"'Delete saved filter ' + saved.name\"\n                    title=\"Delete\"\n                    (click)=\"remove(saved)\"\n                  >\n                    ✕\n                  </button>\n                </li>\n              }\n            </ul>\n\n            <p class=\"cws:px-2 cws:pt-2 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n              ★ marks the view applied when you open this screen.\n            </p>\n          }\n        }\n      }\n    </div>\n  }\n</div>\n",
		dependencies: [{
			kind: "component",
			type: DropdownCaretComponent,
			selector: "cms-dropdown-caret",
			inputs: ["open", "disabled"]
		}, {
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FilterSelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-filter-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownCaretComponent, DropdownDirective],
			template: "<!--\n  The view selector. Sits where the Status dropdown used to (JFrisbie, 2026-09-10).\n\n  🔴 A disclosure, not a `role=\"menu\"`. Two of the three panels contain a form — a name box, a\n  checkbox, a Save button — and menu semantics promise arrow-key item navigation that a form inside\n  breaks. `aria-expanded` + `aria-controls` on the trigger describes what this actually is.\n-->\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:flex-col cws:gap-1\">\n  <!--\n    The caption wears the Search box's caption style (`text-sm`, `slate-700`), because the two sit side by\n    side on every grid toolbar. At `text-xs` it was smaller and sat 3px lower than \"Search\" beside it.\n  -->\n  <span id=\"view-select-label\" class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">\n    View\n  </span>\n\n  <!--\n    `scoular-form-input` for the box model, so this matches the search box's height exactly without a\n    hard-coded pixel value.\n\n    ⚠ That class is `@apply w-full`, so a `w-56` here would be overridden — the design system compiles\n    unlayered and beats a Tailwind utility at equal specificity. The width goes on the wrapper this\n    component is placed in, where nothing contests it. Seventh instance of that trap.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <button\n    type=\"button\"\n    class=\"scoular-form-input cws:flex cws:w-full cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\n    aria-haspopup=\"true\"\n    aria-controls=\"view-select-panel\"\n    aria-labelledby=\"view-select-label\"\n    [attr.aria-expanded]=\"menu.open()\"\n    (click)=\"menu.toggle(); reset()\"\n  >\n    <span class=\"truncate\">\n      {{ label() }}\n      @if (adHocCount() > 0) {\n        <!--\n          The qualifier beside \"Custom view\". The name already says the grid is filtered; this says\n          by how much, which is what tells someone whether the chips below are all of it.\n        -->\n        <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n          · {{ adHocCount() }} {{ adHocCount() === 1 ? 'filter' : 'filters' }}\n        </span>\n      }\n    </span>\n    <!-- The shared caret (2026-10-28), the same chevron as every other list-opening field. -->\n    <cms-dropdown-caret [open]=\"menu.open()\" />\n  </button>\n\n  @if (menu.open()) {\n    <div\n      id=\"view-select-panel\"\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:w-80 cws:p-2\"\n      [attr.aria-label]=\"panel() === 'manage' ? 'Manage filters' : 'Views'\"\n    >\n      @switch (panel()) {\n        @case ('list') {\n          <ul class=\"cws:space-y-1\">\n            <li>\n              <button\n                type=\"button\"\n                class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\n                (click)=\"menu.close(); apply(null)\"\n              >\n                <!--\n                  ⚠ Ticked only when the grid really is unfiltered. `activeFilter() === null` is\n                  true of a custom view too, so ticking on that alone would mark the baseline as\n                  selected while the grid showed a filtered set — and selecting it would then look\n                  like a no-op rather than the way back to everything.\n                -->\n                <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\n                  {{ activeFilter() === null && !isCustom() ? '✓' : '' }}\n                </span>\n                <span class=\"cws:flex-1\">{{ baselineLabel() }}</span>\n              </button>\n            </li>\n\n            @if (savedFilters().length > 0) {\n              <li aria-hidden=\"true\"><div class=\"scoular-dropdown-divider\"></div></li>\n            }\n\n            @for (saved of savedFilters(); track saved.id) {\n              <li>\n                <button\n                  type=\"button\"\n                  class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\n                  (click)=\"menu.close(); apply(saved)\"\n                >\n                  <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\n                    {{ activeFilter()?.id === saved.id ? '✓' : '' }}\n                  </span>\n                  <span class=\"cws:flex-1 truncate\">{{ saved.name }}</span>\n                  @if (defaultId() === saved.id) {\n                    <!--\n                      The star is the only place the default is visible from the list. Titled rather\n                      than left to be inferred: a marked row with no explanation reads as decoration.\n                    -->\n                    <span\n                      class=\"cws:shrink-0 cws:text-amber-500\"\n                      title=\"Applied automatically when you open this screen\"\n                      >★</span\n                    >\n                  }\n                  @if (saved.sort !== undefined) {\n                    <span\n                      class=\"cws:shrink-0 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\"\n                      title=\"Selecting this view also sets its sorting\"\n                      >sorted</span\n                    >\n                  }\n                  @if (saved.columns !== undefined) {\n                    <!-- #1150: the column layout's tag, beside the sorting's. -->\n                    <span\n                      class=\"cws:shrink-0 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\"\n                      title=\"Selecting this view also sets its columns for this session\"\n                      >columns</span\n                    >\n                  }\n                </button>\n              </li>\n            }\n          </ul>\n\n          <div class=\"scoular-dropdown-divider\"></div>\n\n          <div class=\"cws:flex cws:items-center cws:gap-1\">\n            <button\n              type=\"button\"\n              class=\"scoular-dropdown-item cws:flex-1 cws:text-left\"\n              (click)=\"openSave()\"\n            >\n              + Save current filter…\n            </button>\n\n            <!--\n              The gear, per the ask. `title` gives the hover text and `aria-label` gives it a name —\n              both, because a `title` alone is not an accessible name and an icon-only control with\n              neither is unreachable by anything but a mouse.\n            -->\n            <button\n              type=\"button\"\n              class=\"cws:rounded cws:px-2 cws:py-1 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700\"\n              title=\"Manage filters\"\n              aria-label=\"Manage filters\"\n              (click)=\"openManage()\"\n            >\n              ⚙\n            </button>\n          </div>\n\n          <!--\n            🔴 Not boilerplate. These live in this browser's `localStorage` — there is no preferences\n            endpoint — so they do NOT follow the user to another machine or profile, and clearing site\n            data loses them. Someone who names a view will look for it again, and finding it missing\n            on a second machine reads as the feature being broken.\n          -->\n          <p class=\"cws:px-2 cws:pt-1 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n            Saved for you, in this browser only.\n          </p>\n        }\n\n        @case ('save') {\n          <p class=\"cws:px-2 cws:pb-2 cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\n            Save current filter\n          </p>\n\n          <div class=\"cws:space-y-2 cws:px-2\">\n            <label class=\"cws:flex cws:flex-col cws:gap-1\">\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Name</span>\n              <input\n                type=\"text\"\n                class=\"scoular-form-input cws:w-full\"\n                placeholder=\"My unpriced corn\"\n                [value]=\"draftName()\"\n                (input)=\"onNameInput($any($event.target).value)\"\n                (keydown.enter)=\"commitSave()\"\n              />\n            </label>\n\n            <!--\n              The sorting checkbox, per the ask.\n\n              ⚠ Checked by default only when something IS sorted. Saving an empty sort chain is\n              legitimate — it makes selecting the view *clear* the sort — but it is not what someone\n              means when they name a view on an unsorted grid, and a checkbox that silently arms that\n              would make an unrelated view reset the user's sorting later.\n            -->\n            <label class=\"cws:flex cws:items-start cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n              <input\n                type=\"checkbox\"\n                class=\"cws:mt-0.5\"\n                [checked]=\"includeSort()\"\n                (change)=\"onIncludeSortChange($any($event.target).checked)\"\n              />\n              <span>\n                Also save the sorting\n                <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ sortSummary() }})</span>\n              </span>\n            </label>\n\n            <!--\n              #1150: the column layout, built the same way as the sorting box above. Offered only\n              where the grid passes a layout. Checked by default only when the layout differs from\n              the default; otherwise unchecked, and it says the grid shows its default columns.\n            -->\n            @if (columnLayout() !== null) {\n              <label class=\"cws:flex cws:items-start cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n                <input\n                  type=\"checkbox\"\n                  class=\"cws:mt-0.5\"\n                  [checked]=\"includeColumns()\"\n                  (change)=\"onIncludeColumnsChange($any($event.target).checked)\"\n                />\n                <span>\n                  Include column layout\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ columnSummary() }})</span>\n                </span>\n              </label>\n            }\n\n            @if (activeFilter(); as active) {\n              <p class=\"cws:text-[11px] cws:text-amber-700 cws:dark:text-amber-500\">\n                Saving under the name “{{ active.name }}” replaces that view.\n              </p>\n            }\n          </div>\n\n          <div class=\"cws:mt-2 cws:flex cws:justify-end cws:gap-2 cws:px-2\">\n            <button type=\"button\" class=\"scoular-btn scoular-btn-outline\" (click)=\"backToList()\">\n              Cancel\n            </button>\n            <button\n              type=\"button\"\n              class=\"scoular-btn scoular-btn-primary\"\n              [disabled]=\"!canSave()\"\n              (click)=\"commitSave()\"\n            >\n              Save\n            </button>\n          </div>\n        }\n\n        @case ('manage') {\n          <div class=\"cws:flex cws:items-center cws:justify-between cws:px-2 cws:pb-2\">\n            <p class=\"cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">Manage filters</p>\n            <button\n              type=\"button\"\n              class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\n              (click)=\"backToList()\"\n            >\n              Back\n            </button>\n          </div>\n\n          @if (savedFilters().length === 0) {\n            <p class=\"cws:px-2 cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Nothing saved yet.</p>\n          } @else {\n            <ul class=\"cws:space-y-1\">\n              @for (saved of savedFilters(); track saved.id) {\n                <li class=\"cws:flex cws:items-center cws:gap-1 cws:px-1\">\n                  <!--\n                    A toggle rather than a radio group with a fourth \"none\" row: the star that makes a\n                    view the default also clears it, and a list of filters stays a list of filters.\n                  -->\n                  <button\n                    type=\"button\"\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\n                    [class.cws:text-amber-500]=\"defaultId() === saved.id\"\n                    [class.cws:text-slate-400]=\"defaultId() !== saved.id\"\n                    [attr.aria-pressed]=\"defaultId() === saved.id\"\n                    [title]=\"\n                      defaultId() === saved.id\n                        ? 'Stop applying this on load'\n                        : 'Apply this automatically on load'\n                    \"\n                    [attr.aria-label]=\"\n                      (defaultId() === saved.id ? 'Unset default filter ' : 'Set default filter ') +\n                      saved.name\n                    \"\n                    (click)=\"toggleDefault(saved)\"\n                  >\n                    ★\n                  </button>\n\n                  <span class=\"cws:flex-1 truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\n                    {{ saved.name }}\n                  </span>\n\n                  <button\n                    type=\"button\"\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400 cws:hover:bg-slate-100 cws:hover:text-red-700 cws:dark:hover:bg-slate-700\"\n                    [attr.aria-label]=\"'Delete saved filter ' + saved.name\"\n                    title=\"Delete\"\n                    (click)=\"remove(saved)\"\n                  >\n                    ✕\n                  </button>\n                </li>\n              }\n            </ul>\n\n            <p class=\"cws:px-2 cws:pt-2 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n              ★ marks the view applied when you open this screen.\n            </p>\n          }\n        }\n      }\n    </div>\n  }\n</div>\n"
		}]
	}],
	propDecorators: {
		scope: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scope",
				required: true
			}]
		}],
		filter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: true
			}]
		}],
		sorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sorts",
				required: true
			}]
		}],
		baselineLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "baselineLabel",
				required: false
			}]
		}],
		columnLayout: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columnLayout",
				required: false
			}]
		}],
		viewChange: [{
			type: i0.Output,
			args: ["viewChange"]
		}]
	}
});
var PageHeaderComponent = class PageHeaderComponent {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input(null, ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PageHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PageHeaderComponent,
		isStandalone: true,
		selector: "cms-page-header",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<header class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\n  <!--\n    `min-w-0` so a long title truncates inside the flex row rather than refusing to shrink and\n    pushing the actions off the end. A flex item will not go below its content width without it.\n  -->\n  <div class=\"cws:min-w-0\">\n    <ng-content select=\"[cmsPageHeaderBreadcrumb]\" />\n\n    <!-- Anything beside the title, such as a version chip, projects into `cmsPageHeaderTitleSuffix`. -->\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\n      <h2 class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\">{{ title() }}</h2>\n      <ng-content select=\"[cmsPageHeaderTitleSuffix]\" />\n    </div>\n\n    @if (description(); as text) {\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ text }}</p>\n    }\n  </div>\n\n  <!--\n    🔴 `self-start` aligns the actions with the TOP of the header rather than with the baseline of\n    the description (JFrisbie, 2026-08-26). The row keeps `items-end` so the heading block is\n    unaffected — aligning one child is `self-*`, never a change to the row.\n\n    Always rendered rather than gated on whether anything was projected: `ng-content` cannot sit\n    inside a conditional without losing its content, and an empty flex item of zero width changes\n    nothing under `justify-between`.\n  -->\n  <div class=\"cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-2 cws:self-start\">\n    <ng-content select=\"[cmsPageHeaderActions]\" />\n  </div>\n</header>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PageHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-page-header",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: "<header class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\n  <!--\n    `min-w-0` so a long title truncates inside the flex row rather than refusing to shrink and\n    pushing the actions off the end. A flex item will not go below its content width without it.\n  -->\n  <div class=\"cws:min-w-0\">\n    <ng-content select=\"[cmsPageHeaderBreadcrumb]\" />\n\n    <!-- Anything beside the title, such as a version chip, projects into `cmsPageHeaderTitleSuffix`. -->\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\n      <h2 class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\">{{ title() }}</h2>\n      <ng-content select=\"[cmsPageHeaderTitleSuffix]\" />\n    </div>\n\n    @if (description(); as text) {\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ text }}</p>\n    }\n  </div>\n\n  <!--\n    🔴 `self-start` aligns the actions with the TOP of the header rather than with the baseline of\n    the description (JFrisbie, 2026-08-26). The row keeps `items-end` so the heading block is\n    unaffected — aligning one child is `self-*`, never a change to the row.\n\n    Always rendered rather than gated on whether anything was projected: `ng-content` cannot sit\n    inside a conditional without losing its content, and an empty flex item of zero width changes\n    nothing under `justify-between`.\n  -->\n  <div class=\"cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-2 cws:self-start\">\n    <ng-content select=\"[cmsPageHeaderActions]\" />\n  </div>\n</header>\n"
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}]
	}
});
var FormRowComponent = class FormRowComponent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormRowComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FormRowComponent,
		isStandalone: true,
		selector: "cms-form-row",
		host: { classAttribute: "cws:flex cws:flex-wrap cws:items-start cws:gap-3" },
		ngImport: i0,
		template: `
    <ng-content />
    <div class="cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-3 cws:pt-5 cws:min-h-[3.625rem]" data-form-row-actions>
      <ng-content select="[cmsFormRowActions]" />
    </div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormRowComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-row",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:flex cws:flex-wrap cws:items-start cws:gap-3" },
			template: `
    <ng-content />
    <div class="cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-3 cws:pt-5 cws:min-h-[3.625rem]" data-form-row-actions>
      <ng-content select="[cmsFormRowActions]" />
    </div>
  `
		}]
	}]
});
var FormRowFieldComponent = class FormRowFieldComponent {
	cmsFormRowField = input.required(...ngDevMode ? [{ debugName: "cmsFormRowField" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormRowFieldComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FormRowFieldComponent,
		isStandalone: true,
		selector: "label[cmsFormRowField]",
		inputs: { cmsFormRowField: {
			classPropertyName: "cmsFormRowField",
			publicName: "cmsFormRowField",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { classAttribute: "cws:flex cws:flex-col cws:gap-1" },
		ngImport: i0,
		template: `
    <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">{{ cmsFormRowField() }}</span>
    <ng-content />
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormRowFieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "label[cmsFormRowField]",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:flex cws:flex-col cws:gap-1" },
			template: `
    <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">{{ cmsFormRowField() }}</span>
    <ng-content />
  `
		}]
	}],
	propDecorators: { cmsFormRowField: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "cmsFormRowField",
			required: true
		}]
	}] }
});
var ConfirmDialogComponent = class ConfirmDialogComponent {
	data = inject(DIALOG_DATA);
	ref = inject(DialogRef);
	confirm() {
		this.ref.close(true);
	}
	cancel() {
		this.ref.close(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ConfirmDialogComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ConfirmDialogComponent,
		isStandalone: true,
		selector: "cms-confirm-dialog",
		host: {
			attributes: {
				"role": "alertdialog",
				"aria-modal": "true"
			},
			listeners: { "keydown.escape": "cancel()" },
			properties: {
				"attr.aria-labelledby": "\"confirm-dialog-title\"",
				"attr.aria-describedby": "\"confirm-dialog-message\""
			},
			classAttribute: "cws:block cws:max-w-md cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800"
		},
		ngImport: i0,
		template: `
    <h2
      id="confirm-dialog-title"
      class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100"
    >
      {{ data.title }}
    </h2>

    <p id="confirm-dialog-message" class="cws:mt-2 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
      {{ data.message }}
    </p>

    <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
      <!--
        ⚠ The cancelling button is FIRST in the DOM and carries the initial focus, so the default
        answer to "you are about to lose your work" is to keep it. Autofocusing the destructive
        button would make Enter the fastest way to discard.
      -->
      <button type="button" class="scoular-btn scoular-btn-secondary" cdkFocusInitial (click)="cancel()">
        {{ data.cancelLabel ?? 'Cancel' }}
      </button>
      <button
        type="button"
        class="scoular-btn"
        [class.scoular-btn-danger]="data.destructive === true"
        [class.scoular-btn-primary]="data.destructive !== true"
        (click)="confirm()"
      >
        {{ data.confirmLabel }}
      </button>
    </div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ConfirmDialogComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-confirm-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "cws:block cws:max-w-md cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800",
				role: "alertdialog",
				"aria-modal": "true",
				"[attr.aria-labelledby]": "\"confirm-dialog-title\"",
				"[attr.aria-describedby]": "\"confirm-dialog-message\"",
				"(keydown.escape)": "cancel()"
			},
			template: `
    <h2
      id="confirm-dialog-title"
      class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100"
    >
      {{ data.title }}
    </h2>

    <p id="confirm-dialog-message" class="cws:mt-2 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
      {{ data.message }}
    </p>

    <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
      <!--
        ⚠ The cancelling button is FIRST in the DOM and carries the initial focus, so the default
        answer to "you are about to lose your work" is to keep it. Autofocusing the destructive
        button would make Enter the fastest way to discard.
      -->
      <button type="button" class="scoular-btn scoular-btn-secondary" cdkFocusInitial (click)="cancel()">
        {{ data.cancelLabel ?? 'Cancel' }}
      </button>
      <button
        type="button"
        class="scoular-btn"
        [class.scoular-btn-danger]="data.destructive === true"
        [class.scoular-btn-primary]="data.destructive !== true"
        (click)="confirm()"
      >
        {{ data.confirmLabel }}
      </button>
    </div>
  `
		}]
	}]
});
function injectConfirm() {
	const dialog = inject(Dialog);
	return (request) => dialog.open(ConfirmDialogComponent, {
		data: request,
		disableClose: true
	}).closed.pipe(map((result) => result === true));
}
const confirmed = () => of(true);
const confirmNavigationGuard = (component) => component.confirmNavigation();
var BreadcrumbComponent = class BreadcrumbComponent {
	crumbs = input.required(...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	current = input.required(...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	context = input(null, ...ngDevMode ? [{ debugName: "context" }] : /* istanbul ignore next */ []);
	queryParams = input(null, ...ngDevMode ? [{ debugName: "queryParams" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BreadcrumbComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: BreadcrumbComponent,
		isStandalone: true,
		selector: "cms-breadcrumb",
		inputs: {
			crumbs: {
				classPropertyName: "crumbs",
				publicName: "crumbs",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			current: {
				classPropertyName: "current",
				publicName: "current",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			context: {
				classPropertyName: "context",
				publicName: "context",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queryParams: {
				classPropertyName: "queryParams",
				publicName: "queryParams",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<!--\n  A real `<nav>` with an ordered list, because that is what a breadcrumb is, and the ARIA breadcrumb\n  pattern is what tells a screen-reader user this is navigation rather than a heading. The last crumb\n  is the current page and so is not a link.\n-->\n<nav aria-label=\"Breadcrumb\">\n  <ol class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1 cws:text-sm\">\n    @if (context(); as scope) {\n      <!-- The trade unit leads, inline. Context, and deliberately not a link. -->\n      <li class=\"cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ scope }}</li>\n      <li aria-hidden=\"true\" class=\"cws:text-slate-500 cws:dark:text-slate-400\">&rsaquo;</li>\n    }\n\n    <!--\n      ⚠ Tracked by `label`, not by `path`. A path may be a segment ARRAY, which is a fresh object\n      identity on every change-detection pass, so tracking it would tear down and rebuild every\n      anchor in the trail each time — including the one the user is tabbing through.\n    -->\n    @for (crumb of crumbs(); track crumb.label) {\n      <li>\n        @if (crumb.link; as link) {\n          <!-- The host decides this one (an embeddable screen): its href, and a click handed to it. -->\n          <a\n            [attr.href]=\"link.href\"\n            (click)=\"link.follow($event)\"\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\n          >\n            {{ crumb.label }}\n          </a>\n        } @else {\n          <a\n            [routerLink]=\"crumb.path\"\n            [queryParams]=\"queryParams()\"\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\n          >\n            {{ crumb.label }}\n          </a>\n        }\n      </li>\n      <li aria-hidden=\"true\" class=\"cws:text-slate-500 cws:dark:text-slate-400\">&rsaquo;</li>\n    }\n\n    <li aria-current=\"page\" class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">{{ current() }}</li>\n  </ol>\n</nav>\n",
		dependencies: [{
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BreadcrumbComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-breadcrumb",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			imports: [RouterLink],
			template: "<!--\n  A real `<nav>` with an ordered list, because that is what a breadcrumb is, and the ARIA breadcrumb\n  pattern is what tells a screen-reader user this is navigation rather than a heading. The last crumb\n  is the current page and so is not a link.\n-->\n<nav aria-label=\"Breadcrumb\">\n  <ol class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1 cws:text-sm\">\n    @if (context(); as scope) {\n      <!-- The trade unit leads, inline. Context, and deliberately not a link. -->\n      <li class=\"cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ scope }}</li>\n      <li aria-hidden=\"true\" class=\"cws:text-slate-500 cws:dark:text-slate-400\">&rsaquo;</li>\n    }\n\n    <!--\n      ⚠ Tracked by `label`, not by `path`. A path may be a segment ARRAY, which is a fresh object\n      identity on every change-detection pass, so tracking it would tear down and rebuild every\n      anchor in the trail each time — including the one the user is tabbing through.\n    -->\n    @for (crumb of crumbs(); track crumb.label) {\n      <li>\n        @if (crumb.link; as link) {\n          <!-- The host decides this one (an embeddable screen): its href, and a click handed to it. -->\n          <a\n            [attr.href]=\"link.href\"\n            (click)=\"link.follow($event)\"\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\n          >\n            {{ crumb.label }}\n          </a>\n        } @else {\n          <a\n            [routerLink]=\"crumb.path\"\n            [queryParams]=\"queryParams()\"\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\n          >\n            {{ crumb.label }}\n          </a>\n        }\n      </li>\n      <li aria-hidden=\"true\" class=\"cws:text-slate-500 cws:dark:text-slate-400\">&rsaquo;</li>\n    }\n\n    <li aria-current=\"page\" class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">{{ current() }}</li>\n  </ol>\n</nav>\n"
		}]
	}],
	propDecorators: {
		crumbs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "crumbs",
				required: true
			}]
		}],
		current: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "current",
				required: true
			}]
		}],
		context: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "context",
				required: false
			}]
		}],
		queryParams: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queryParams",
				required: false
			}]
		}]
	}
});
export { AsyncContainerComponent, BreadcrumbComponent, BrowserGridColumnStore, CODE_SEARCH_MAX_RESULTS, CODE_SEARCH_MIN_LENGTH, CONDENSED_BELOW_PX, ClearSortButtonComponent, CodeComboComponent, ConfirmDialogComponent, DEFAULT_COLUMN_WIDTH, DRAG_THRESHOLD_PX, DataGridComponent, DateInputComponent, DatePickerComponent, DropdownCaretComponent, DropdownDirective, EMPTY_FILTER, EMPTY_VALUE_TEXT, ExportFieldsComponent, FieldComponent, FieldValueComponent, FilterBuilderComponent, FilterSelectComponent, FormRowComponent, FormRowFieldComponent, GRID_COLUMN_STORE, GridColumnChoice, GridColumnMenuComponent, GridExportComponent, GridToolbarComponent, HelpTipComponent, LOOKUP_ATTRIBUTE, LocalSavedFilterStore, MIN_COLUMN_WIDTH, NO_REFERENCE_NOT_SENT, NO_REFERENCE_RETURNED, NoteInputComponent, NoticesPanelComponent, OPEN_LOOKUP_EVENT, OPERATORS_BY_KIND, OPERATOR_LABELS, PLAIN_VALUE_CLASS, PageHeaderComponent, PagerComponent, PointerDragGesture, QUIET_FOCUS_ATTRIBUTE, QuantityInputComponent, READ_MOSTLY_BELOW_PX, READ_ONLY_FOCUS_CLASS, READ_ONLY_SURFACE_CLASS, ReferenceLineComponent, RefreshButtonComponent, RowMenuComponent, SAVED_FILTER_OWNER, SAVED_FILTER_SCOPES, SAVED_FILTER_STORE, STATUS_MESSAGE_DISMISS_MS, SearchShortcutDirective, SelectComponent, ShortcutHintsComponent, ShortcutOverlayComponent, ShortcutRegistry, StatusBadgeComponent, StatusMessageComponent, StorageRefusals, TextInputComponent, ToggleComponent, actionRefusal, activeRuleCount, applyExportFields, ariaKeyShortcuts, ariaSort, compareBySorts, compareRows, confirmNavigationGuard, confirmed, correlationIdOf, defaultGroup, describeGroup, downloadBlob, downloadCsv, elementUnder, exportFieldsFor, flipDirection, focusWithoutOpening, formatShortcut, gridColumnChoice, groupNodes, includedExportFieldCount, injectConfirm, isActionUnavailable, isComplete, isGroupNode, isLive, isRuleNode, isTextEditable, layoutBandFor, matchesGroup, matchesSearch, moveExportField, moveNode, mutationFailed, mutationRefused, mutationSucceeded, needsValue, nextSort, nodeAt, normaliseGroup, observeLayoutBand, operatorLabel, operatorsFor, priorityColumnKeys, reconcileExportFields, registerShortcuts, remoteError, remoteIdle, remoteLoaded, remoteLoading, remoteValue, removeAt, replaceRuleById, sameGroup, sameSortChain, savedViewColumnsOf, savedViewShownKeys, scopeRank, setAllExportFields, shortcutTokens, sortRank, statusBadgeClass, toCsv, toggleCombinatorAt, toggleExportField, ungroupAt };

//# sourceMappingURL=cws-shared-ui.mjs.map
import * as i0 from "@angular/core";
import { ElementRef, InjectionToken, Signal, Type } from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";
import { Observable } from "rxjs";
import { ConnectedPosition } from "@angular/cdk/overlay";
import { CanDeactivateFn } from "@angular/router";
/**
 * The `RemoteData<T>` signal pattern every async view uses (docs/03 §3.2).
 *
 * A discriminated union rather than the classic `{ data, loading, error }` triple, because that
 * triple permits states the domain does not have — loading *and* errored, loaded *with* an error —
 * and every consumer then has to decide which field wins. Here the compiler decides.
 */
export type RemoteData<T> = {
  readonly status: 'idle';
} | {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
  readonly value: T;
} | {
  readonly status: 'error';
  readonly error: RemoteError;
};
/**
 * A failure already translated for display. Nothing CTRM-shaped or RFC 7807-shaped reaches a
 * component: `problemDetailsInterceptor` maps ProblemDetails to this at the HTTP boundary
 * (docs/03 §3.2), so the UI never parses a wire format.
 */
export interface RemoteError {
  /** Plain-language, non-technical. error-handling.md §7 forbids stack traces or exception names. */
  readonly message: string;
  /**
   * Correlation id, surfaced so a user can quote it to support (docs/02 §9 — "every user-visible
   * error carries a correlation id"). Absent for client-side failures that never reached the API.
   */
  readonly correlationId?: string;
  /**
   * Reasons from the API's `formErrors` extension member — refusals that address no control (F2.4).
   *
   * 🔴 **Separate from {@link message}, not folded into it.** `message` is one plain sentence the
   * container renders; these are CTRM's own wording, often several, and each names something the
   * user can act on. Concatenating them into `message` would lose that they are a list and would
   * put CTRM's phrasing where a written-for-humans sentence belongs.
   *
   * Optional and defaulted to `[]` by readers, matching the API's own contract — it omits the
   * member entirely when there are none.
   */
  readonly formErrors?: readonly string[];
  /**
   * The HTTP status, where the source chose to keep it (#459).
   *
   * ⚠ Optional, and only for a caller that must tell a **refusal** (4xx: nothing was written) from a
   * **fault** (5xx: the write may or may not have happened, C-4). Copy-with-pricing is that caller:
   * a refused price is "not copied", a faulted one is settled only by reading it back. Absent means
   * the source did not say, and a reader must treat it as unknown, never as a refusal.
   */
  readonly status?: number;
}
export declare const remoteIdle: <T>() => RemoteData<T>;
export declare const remoteLoading: <T>() => RemoteData<T>;
export declare const remoteLoaded: <T>(value: T) => RemoteData<T>;
export declare const remoteError: <T>(error: RemoteError) => RemoteData<T>;
/** Narrows to the loaded value, or `null` in any other state. */
export declare function remoteValue<T>(data: RemoteData<T>): T | null;
/**
 * The state wrapper every data region uses (docs/02a §5).
 *
 * Skeleton while loading → content / a typed empty state / an error state carrying its correlation
 * id and a Retry. Centralising it is what stops each screen inventing its own spinner and its own
 * error copy, and it is the single place the "every user-visible error carries a correlation id"
 * rule (docs/02 §9) can actually be enforced.
 *
 * `empty` is a separate input rather than something inferred from the value, because only the
 * caller knows what empty means for its own shape — an empty array, a null, a zero-row page.
 *
 * Ships no global styles and makes no assumption about the page it renders in: this library is
 * consumed inside foreign host applications under Module Federation (docs/02a §8, 03 §3.4.7).
 */
export declare class AsyncContainerComponent<T> {
  /** Current state of the region. */
  readonly data: import("@angular/core").InputSignal<RemoteData<T>>;
  /** True when the load succeeded but there is nothing to show. */
  readonly empty: import("@angular/core").InputSignal<boolean>;
  /** Shown in the empty state — one line, per 02a §5. */
  readonly emptyMessage: import("@angular/core").InputSignal<string>;
  /** Accessible label for the loading state; announced to assistive technology. */
  readonly loadingLabel: import("@angular/core").InputSignal<string>;
  /** Emitted by the error state's Retry. The caller owns what retrying means. */
  readonly retry: import("@angular/core").OutputEmitterRef<void>;
  protected readonly isLoading: import("@angular/core").Signal<boolean>;
  protected readonly error: import("@angular/core").Signal<import("@cws/shared-ui").RemoteError | null>;
  protected readonly showContent: import("@angular/core").Signal<boolean>;
  protected readonly showEmpty: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AsyncContainerComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AsyncContainerComponent<any>, "cms-async-container", never, {
    "data": {
      "alias": "data";
      "required": true;
      "isSignal": true;
    };
    "empty": {
      "alias": "empty";
      "required": false;
      "isSignal": true;
    };
    "emptyMessage": {
      "alias": "emptyMessage";
      "required": false;
      "isSignal": true;
    };
    "loadingLabel": {
      "alias": "loadingLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "retry": "retry";
  }, never, ["[cmsEmptyAction]", "*"], true, never>;
}
/**
 * How a mutation came out, as a screen says it once it has answered (docs/02a §5, docs/02 §9, #803).
 *
 * - `success`: the server accepted it. Announced, then dismissed on its own.
 * - `failure`, `sent: true`: the request reached the API and was refused or broke. It carries the
 *   reference id the server returned, so a user can quote it to support. When the server returned
 *   none, the message says so; it is never left blank, which would read as "there is no problem".
 * - `failure`, `sent: false`: refused here, before any request (a client-side check). There is no
 *   reference because nothing reached the server, and the message says that instead.
 *
 * There is no undo, by ruling: a CTRM write is not reversible, and an "undo" that only hides a
 * message is worse than none.
 *
 * A success with `stays: true` is not dismissed on its own (#812): it carries something the user must
 * act on, such as a save that went through while CTRM could not notify the trader. It is still a
 * success, because the write happened.
 */
export type MutationOutcome = {
  readonly kind: 'success';
  readonly message: string;
  readonly stays?: boolean;
} | {
  readonly kind: 'failure';
  readonly message: string;
  readonly sent: true;
  readonly correlationId?: string | null;
} | {
  readonly kind: 'failure';
  readonly message: string;
  readonly sent: false;
};
/** A success, in a screen's own words. `stays` keeps it until the user dismisses it. */
export declare function mutationSucceeded(message: string, options?: {
  readonly stays?: boolean;
}): MutationOutcome;
/**
 * A failure the API answered, from the `RemoteError` (or any refusal carrying a message and an id)
 * the screen's source produced. `null` and absent both mean the server returned no reference.
 */
export declare function mutationFailed(error: Pick<RemoteError, 'message'> & {
  readonly correlationId?: string | null;
}): MutationOutcome;
/** A refusal made here, before any request. */
export declare function mutationRefused(message: string): MutationOutcome;
/**
 * The reference id in a raw HTTP failure, for a screen whose source hands back the error itself: the
 * `traceId` of the RFC 7807 body the API sends with every failure. Read without importing anything
 * HTTP, so this library stays below the transport. `null` when there is none, which the message then
 * says rather than leaving blank.
 */
export declare function correlationIdOf(error: unknown): string | null;
/** What a failure says in place of a reference id, by why there is none. */
export declare const NO_REFERENCE_RETURNED = "No reference: the server did not return one.";
export declare const NO_REFERENCE_NOT_SENT = "No reference: nothing was sent to the server.";
/**
 * **The reference line a failure ends with** (#803, docs/02 §9): the id a person quotes to support.
 *
 * The server's id when it returned one. When it did not, a sentence saying so, and when nothing was
 * sent at all, a sentence saying that: a blank where the reference goes reads as "there is nothing to
 * report", which is the opposite of a failure.
 *
 * `cms-status-message` ends every failure with this. A screen whose failure is richer than one
 * message (the record screen's three save outcomes, each with its own title and action) puts this
 * line in its own alert, so the reference is said the same way everywhere.
 */
export declare class ReferenceLineComponent {
  /** The id the server returned, or `null`/absent when it returned none. */
  readonly correlationId: import("@angular/core").InputSignal<string | null | undefined>;
  /** `false` for a refusal made before any request: there is no reference because nothing went. */
  readonly sent: import("@angular/core").InputSignal<boolean>;
  protected readonly note: import("@angular/core").Signal<"No reference: the server did not return one." | "No reference: nothing was sent to the server.">;
  static ɵfac: i0.ɵɵFactoryDeclaration<ReferenceLineComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ReferenceLineComponent, "cms-reference-line", never, {
    "correlationId": {
      "alias": "correlationId";
      "required": false;
      "isSignal": true;
    };
    "sent": {
      "alias": "sent";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** How long a success stays before it dismisses itself. Long enough to read a sentence twice. */
export declare const STATUS_MESSAGE_DISMISS_MS = 6000;
/**
 * **The outcome of a mutation, said one way on every screen** (#803).
 *
 * - **Success** is `role="status"`, polite, and dismisses itself after
 *   {@link STATUS_MESSAGE_DISMISS_MS}. A person who wants it gone sooner closes it. A success marked
 *   `stays` (#812) waits for Dismiss, because it asks the user to do something.
 * - **Failure** is `role="alert"` and **never dismisses itself**: a refusal a person did not get to
 *   read is a refusal they will repeat. It always ends with a reference line, the server's id or a
 *   sentence saying why there is none.
 *
 * A failure projects its content after the reference line, for a screen's own action (Reload after a
 * `409`). A success projects nothing: there is no undo, by ruling.
 *
 * Dismissal is the parent's: the component emits `dismissed` and the screen clears its outcome, so
 * the screen's own state stays the one source of what is showing.
 *
 * ⚠ `cws:`-prefixed utilities only, and the design system's alert classes, so a host page's own
 * styles cannot restyle it (F9.4).
 */
export declare class StatusMessageComponent {
  readonly outcome: import("@angular/core").InputSignal<MutationOutcome | null>;
  readonly dismissMs: import("@angular/core").InputSignal<number>;
  readonly dismissed: import("@angular/core").OutputEmitterRef<void>;
  constructor();
  protected dismiss(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<StatusMessageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<StatusMessageComponent, "cms-status-message", never, {
    "outcome": {
      "alias": "outcome";
      "required": false;
      "isSignal": true;
    };
    "dismissMs": {
      "alias": "dismissMs";
      "required": false;
      "isSignal": true;
    };
  }, {
    "dismissed": "dismissed";
  }, never, ["*"], true, never>;
}
/** What the browser can refuse to remember. Each names itself in the sentence the user reads. */
export type RefusedStore = 'theme' | 'saved views';
/**
 * **A choice the browser refused to store, said once** (#889).
 *
 * `localStorage` throws rather than storing when the quota is full, in a privacy mode, or under a
 * host that sandboxes it. The theme and saved views catch that so a click never fails, which left the
 * choice working for this session and gone on the next, with nothing said. A store that is refused
 * reports it here, and the workspace chrome says it through `cms-status-message`.
 *
 * - **Writes only.** A refused read is a first visit as far as the user can tell, and says nothing.
 * - **Once a session per kind**: a theme toggled ten times under a refusing browser is said once, and
 *   a dismissal holds until something else is refused.
 * - **A refusal, not a success**: it stays until dismissed, as the choice will be lost.
 */
export declare class StorageRefusals {
  private readonly refused;
  private readonly showing;
  readonly notice: import("@angular/core").Signal<MutationOutcome | null>;
  /** Called by a store whose write the browser refused. */
  report(store: RefusedStore): void;
  dismiss(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<StorageRefusals, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * A field's description, offered on request behind an "i" beside its label rather than printed under
 * the control.
 *
 * `source` is the name of the system field the value is stored in, shown above the text. It is what
 * tells two similar labels apart ("Contract type" and "Contract type code").
 */
export interface FieldHelp {
  readonly text: string;
  readonly source?: string | null;
}
/**
 * The QUIET READ-ONLY SURFACE (2026-10-13): how a value nobody can change here is drawn, in every mode.
 *
 * A field box, so the screen keeps its structure, but plainly not a control. It is RECESSED: a fill a
 * step darker than the panel and no visible border, where an editable control is RAISED, with its own
 * border, a lighter fill and a focus ring. So the eye can tell information from entry at a glance,
 * and nothing here looks disabled (no fading, no `not-allowed` cursor; the text is full contrast).
 * The border is kept, transparent, so the box is exactly the height of the control it stands in for.
 *
 * Shared by `cms-field-value` (view mode) and {@link PLAIN_VALUE_CLASS} (a read-only field while
 * editing), so a derived value looks the same whichever mode it is seen in.
 */
export declare const READ_ONLY_SURFACE_CLASS = "cws:border-transparent cws:bg-slate-100 cws:text-slate-900 cws:dark:bg-slate-900/60 cws:dark:text-slate-100";
/**
 * The read-only surface applied to a read-only `<input>` or `<textarea>` while the form is editable.
 *
 * Applied by each control while its `plain` input is true. The element stays an `<input readonly>` on
 * purpose: it keeps its `<label for>` name, its place in the record's DOM and Ctrl+C, and the edit
 * specs that read it. Only the look changes.
 *
 * 🔴 **Every declaration carries `!`.** The shell paints `.scoular-form-input[readonly]` from an
 * unlayered rule, and an unlayered declaration beats any layered utility whatever its specificity. An
 * important utility beats both, and it also holds in an embedding host that supplies the design system
 * unlayered and never loads the shell's rule.
 *
 * The box model is the input's own (`py-2`, `px-4`, the 1px border), so the value sits exactly where
 * the text of the editable control beside it sits. The focus ring is replaced by an outline, because a
 * focusable element with no visible focus fails WCAG 2.4.7.
 *
 * 🔴 **`outline-solid` is load-bearing (#842).** The design system's `outline-none` sets the outline
 * STYLE to none, and `outline-2` sets only a width, so without it the outline had a width and a colour
 * and drew nothing: a focused plain value showed no focus at all (measured in Edge, 2026-10-21).
 */
export declare const PLAIN_VALUE_CLASS = "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
/**
 * The read-only focus style for a read-only control that keeps its box (#842).
 *
 * A read-only field is drawn {@link PLAIN_VALUE_CLASS} unless it carries an error or a C10 warning,
 * when it keeps its box so the coloured border can say so. That box used to take the design system's
 * editing ring on focus, which says "type here" on a field that cannot be typed into. This swaps the
 * ring for the same focus outline a plain value shows, so focus stays visible (WCAG 2.4.7) and the
 * border keeps its colour. Important for the reason given on {@link PLAIN_VALUE_CLASS}.
 */
export declare const READ_ONLY_FOCUS_CLASS = "cws:ring-0! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
/** Shown in place of an empty read-only value. Quiet, and never an empty box with nothing to read. */
export declare const EMPTY_VALUE_TEXT = "—";
/**
 * The scaffold every form control in this library wears: the label row, the required marker, and the
 * one error-or-hint line beneath.
 *
 * ### Why it exists
 *
 * Six controls hand-rolled the identical ~20 lines — `code-combo`, `date-input`, `note-input`,
 * `quantity-input`, `text-input` and `toggle`. Identical is not an exaggeration: the inner label
 * markup was byte-for-byte the same in all six. What drifts in that situation is never the obvious
 * thing; it is the detail that is invisible when wrong. Two of the six had the `min-h-5` row-height
 * fix and four did not, because the fix was made on the screen where the bug was reported.
 *
 * ### 🔴 The ids are a contract, not a detail
 *
 * Each control's own `describedBy()` returns `<controlId>-error` or `<controlId>-hint`, and this
 * component is what renders the elements carrying those ids. If the two ever disagree the control
 * still renders, still validates and still looks right — and the `aria-describedby` points at
 * nothing, so the error is announced to nobody. That is why `controlId` is required here rather than
 * being derived, and why the ids are spelled out in the template rather than passed in.
 *
 * ### ⚠ `labelFor` is about the ELEMENT, not about preference
 *
 * A `<label for>` only forms an accessible-name association with a *labelable* element. `toggle`
 * renders `role="switch"` on a button, which is not one, so it takes a `<span>` with an id and points
 * `aria-labelledby` at it. Getting this backwards produces a control that is unnamed to a screen
 * reader while looking perfectly labelled on screen.
 *
 * ### What it deliberately does NOT own
 *
 * The control element, its `aria-describedby`, its `aria-invalid`, its error *styling* hooks. Those
 * stay with each control, because they differ per control and because a wrapper that reached into
 * the projected element would be the harder thing to reason about, not the easier one.
 */
export declare class FieldComponent {
  /** The visible heading. Also the `title`, so a truncated label is readable on hover. */
  readonly label: import("@angular/core").InputSignal<string>;
  /**
   * The id of the control this labels.
   *
   * Used for `for`/`id` and to build the error and hint ids. Required rather than optional because
   * a missing one breaks the description association silently.
   */
  readonly controlId: import("@angular/core").InputSignal<string>;
  /** Renders the red asterisk. Presentation only — requiredness is enforced by the control. */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /**
   * Hides the heading text while KEEPING the row's height.
   *
   * For a field grouped under a shared heading, where repeating the label would be noise. The height
   * is kept because `sr-only` positions absolutely, and collapsing the row lifts the control out of
   * line with its neighbours in the same grid row.
   */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  /** The refusal to show beneath the control. Wins over {@link hint} when both are set. */
  readonly errorMessage: import("@angular/core").InputSignal<string | null>;
  /** Advisory text, shown only when there is no error. */
  readonly hint: import("@angular/core").InputSignal<string | null>;
  /**
   * Whether the heading is a `<label for>` (true) or a `<span id>` the control points at (false).
   *
   * True for every ordinary input. False for `toggle`, whose control is a button.
   */
  readonly labelFor: import("@angular/core").InputSignal<boolean>;
  /**
   * The field's description, behind an "i" beside the label. `null` renders no icon.
   *
   * ⚠ For INFORMATION only. A validation error, a warning, or anything a user must see before acting
   * goes in {@link errorMessage} or {@link hint}, which stay on screen.
   */
  readonly help: import("@angular/core").InputSignal<FieldHelp | null>;
  /**
   * A quiet word at the right of the label row, such as "Set by CTRM" on a value the user cannot change
   * here. Takes the counter's place, which a read-only control never shows.
   */
  readonly marker: import("@angular/core").InputSignal<string | null>;
  /**
   * Renders the field's VALUE on the quiet read-only surface instead of the control (2026-10-13):
   * the record screen's view mode. The label row is unchanged, so the field reads the same in every
   * mode; the label becomes a `<span id>` because the value it names (`cms-field-value`'s `<output>`)
   * is named with `aria-labelledby`.
   */
  readonly display: import("@angular/core").InputSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FieldComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FieldComponent, "cms-field", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "labelFor": {
      "alias": "labelFor";
      "required": false;
      "isSignal": true;
    };
    "help": {
      "alias": "help";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[cmsFieldAside]", "*"], true, never>;
}
/**
 * **Control pattern C4 — quantity / decimal input** (docs/02a §3).
 *
 * Applies to quantities, prices, adjustments, rates and loads. Right-aligned, thousands separators
 * applied on blur, an optional unit-of-measure suffix rendered inside the control, negatives only
 * where the domain permits them, and a read-only presentation for auto-calculated fields whose
 * formula is surfaced in a tooltip.
 *
 * **Separators appear on blur, never while typing.** Reformatting mid-keystroke moves the caret and
 * fights the user — and these users type at green-screen speed (02a §1.1). While focused the raw
 * number is shown; on blur it is parsed once and redisplayed formatted.
 *
 * Implements `ControlValueAccessor` so the config-driven `FormGroup` the form engine builds
 * (docs/03 §3.1) binds to it with no adapter. The model value is always a `number | null` — the
 * formatted string never escapes this component, so nothing downstream has to parse display text.
 */
export declare class QuantityInputComponent implements ControlValueAccessor {
  /** Visible label. Also the accessible name — every control needs one. */
  readonly label: import("@angular/core").InputSignal<string>;
  /** Stable id used to tie label, input and description together. */
  readonly controlId: import("@angular/core").InputSignal<string>;
  /** Unit of measure shown inside the control, e.g. `BU`. Omit where not applicable. */
  readonly unitOfMeasure: import("@angular/core").InputSignal<string | null>;
  /** Decimal places used when formatting. Sourced per component from `constraints.json` (ADR-7). */
  readonly decimalPlaces: import("@angular/core").InputSignal<number>;
  /** C4: negatives are allowed only where the domain permits them, so this defaults to false. */
  readonly allowNegative: import("@angular/core").InputSignal<boolean>;
  /**
   * Angular-required: Angular's `RequiredValidator` matches `[required]` beside a form binding, so
   * this adds `Validators.required` to the control as well as the marker. For a template-driven or
   * reactive caller that wants exactly that.
   */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /**
   * The asterisk and `aria-required` ONLY, never a validator (#1074). For a caller that owns the
   * control's validators itself, as the form engine does: the name matches no Angular selector, so
   * binding it late cannot merge `Validators.required` in behind the owner's back.
   */
  readonly requiredMarker: import("@angular/core").InputSignal<boolean>;
  /** Either input marks the field required. */
  protected readonly showsRequired: import("@angular/core").Signal<boolean>;
  /** Renders the label screen-reader-only (#221): still the control's name, never removed. */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  /** Read-only presentation — set by config, or by a rule such as BR-004's auto-calculation. */
  readonly readOnly: import("@angular/core").InputSignal<boolean>;
  /**
   * Renders a read-only value as TEXT rather than as a box (2026-10-13). See `PLAIN_VALUE_CLASS`.
   *
   * Presentation only: it changes nothing about what the control accepts. The form engine sets it on a
   * read-only field that has no error and no warning, because a value needing attention keeps its box.
   */
  readonly plain: import("@angular/core").InputSignal<boolean>;
  /** The field's description, behind an "i" beside the label. See `FieldComponent.help`. */
  readonly help: import("@angular/core").InputSignal<FieldHelp | null>;
  /** A quiet word on the label row, such as "Set by CTRM". See `FieldComponent.marker`. */
  readonly marker: import("@angular/core").InputSignal<string | null>;
  /**
   * Renders the VALUE on the quiet read-only surface instead of the control (2026-10-13): the
   * record screen's view mode. See `FieldValueComponent`. The control keeps its value and its form binding;
   * only what is drawn changes.
   */
  readonly display: import("@angular/core").InputSignal<boolean>;
  /** The value as this control shows it, for the sheet. The same text the box would hold. */
  protected readonly displayText: import("@angular/core").Signal<string>;
  /**
   * The surface classes: plain for a quiet read-only value, the read-only focus style for a read-only
   * value that keeps its box (#842), and none for an editable one, which keeps the editing ring.
   */
  protected readonly surfaceClass: import("@angular/core").Signal<"" | "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!" | "cws:ring-0! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!">;
  protected readonly emptyText = "—";
  /**
   * Takes the field out of the tab order (#314). The form sets it on a read-only field while the
   * form is editable, so Tab and Enter skip what cannot be typed into, as protected fields are
   * skipped on the green screen.
   *
   * ⚠ Not `disabled`: the field stays focusable by click and copyable, and a read-only form leaves
   * it false so view mode keeps every value reachable by keyboard (JFrisbie, 2026-09-01).
   */
  readonly skipTab: import("@angular/core").InputSignal<boolean>;
  /**
   * Formula behind a calculated value, e.g. `Price = Basis + Hedge + Grade Adj + Freight Adj`.
   * Surfaced as a tooltip so a trader can always see why a number is what it is (BR-004, 02a C4).
   */
  readonly formula: import("@angular/core").InputSignal<string | null>;
  /** C10 — amber border plus an explanatory tooltip; never blocks save. */
  readonly borderWarning: import("@angular/core").InputSignal<boolean>;
  readonly warningText: import("@angular/core").InputSignal<string | null>;
  /** Validation message. Presence switches the control into its error presentation. */
  readonly errorMessage: import("@angular/core").InputSignal<string | null>;
  /**
   * A verdict's outline, beside the value rather than as an error (#965, as #962 drew the text input's):
   * `invalid` is the error outline and marks the box `aria-invalid`, `valid` the design system's green.
   * The words are the caller's to render, and {@link describedByExtra} links them, so the colour never
   * stands alone. An `errorMessage` wins over either.
   */
  readonly tone: import("@angular/core").InputSignal<"valid" | "invalid" | null>;
  /** One more element id this box is described by: the caller's verdict sentence (#965). */
  readonly describedByExtra: import("@angular/core").InputSignal<string | null>;
  /** Whether the box draws the error outline: an error, or an invalid verdict. */
  protected readonly invalid: import("@angular/core").Signal<boolean>;
  protected readonly disabled: import("@angular/core").WritableSignal<boolean>;
  protected readonly focused: import("@angular/core").WritableSignal<boolean>;
  protected readonly value: import("@angular/core").WritableSignal<number | null>;
  /** Raw text while focused; `null` means "derive it from the model value". */
  private readonly editingText;
  protected readonly describedBy: import("@angular/core").Signal<string | null>;
  protected readonly hint: import("@angular/core").Signal<string | null>;
  /**
   * Formatted for display, raw while focused for editing.
   *
   * ⚠ A read-only value stays formatted on focus (#842). The raw number is there so the caret does not
   * jump while typing, and nothing is typed into a read-only field: focus there is for reading and
   * copying, so switching format only made a derived Price or Hedge look editable.
   */
  protected readonly displayValue: import("@angular/core").Signal<string>;
  private onChange;
  private onTouched;
  writeValue(value: number | null): void;
  registerOnChange(fn: (value: number | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  protected onFocus(): void;
  /**
   * Filters the keystroke rather than flagging it afterwards (#200, QA finding F-17).
   *
   * A numeric field used to accept `abc`, parse it to `null` and then show a validation error. The
   * field knows it is numeric from `constraints.json` before the user types, so refusing entry costs
   * nothing and removes an error message that only ever said "you cannot do the thing you just did".
   *
   * 🔴 **Filtered on `input`, not on `keydown`, and that is what covers paste.** A `keydown` handler
   * sees one key and never sees a pasted `1e5` or a drag-and-dropped string; every one of those paths
   * raises `input`. It also keeps IME and autofill working, which a key-level filter breaks.
   *
   * ⚠ **The caret is restored by hand.** Rewriting `element.value` moves the caret to the end, so
   * typing a letter mid-number would silently jump the user to the end of the field — a worse defect
   * than the one being fixed, and one that only shows up when the filter actually does something.
   */
  protected onInput(event: Event): void;
  /**
   * Strips anything that cannot be part of a number the {@link parse} step would accept.
   *
   * Deliberately permissive about *shape* and strict about *characters*: `1..2` and a lone `-` are
   * intermediate states a user passes through while typing, so they survive here and are settled by
   * `parse` and by the precision/scale validators. **Entry filtering does not replace validation** —
   * it only stops input that could never become a number under any further keystroke.
   */
  private sanitize;
  protected onBlur(): void;
  /** Accepts separators and stray spaces so a pasted `12,500.00` is not rejected. */
  private parse;
  private format;
  static ɵfac: i0.ɵɵFactoryDeclaration<QuantityInputComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<QuantityInputComponent, "cms-quantity-input", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "unitOfMeasure": {
      "alias": "unitOfMeasure";
      "required": false;
      "isSignal": true;
    };
    "decimalPlaces": {
      "alias": "decimalPlaces";
      "required": false;
      "isSignal": true;
    };
    "allowNegative": {
      "alias": "allowNegative";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "requiredMarker": {
      "alias": "requiredMarker";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "readOnly": {
      "alias": "readOnly";
      "required": false;
      "isSignal": true;
    };
    "plain": {
      "alias": "plain";
      "required": false;
      "isSignal": true;
    };
    "help": {
      "alias": "help";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
    "skipTab": {
      "alias": "skipTab";
      "required": false;
      "isSignal": true;
    };
    "formula": {
      "alias": "formula";
      "required": false;
      "isSignal": true;
    };
    "borderWarning": {
      "alias": "borderWarning";
      "required": false;
      "isSignal": true;
    };
    "warningText": {
      "alias": "warningText";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "describedByExtra": {
      "alias": "describedByExtra";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * **Control pattern C5 — text input with counter** (docs/02a §3).
 *
 * Applies to remarks (72 characters), descriptive quantity (25), customer contract (10) and the
 * other free-text fields. A live remaining-character counter, and a hard stop at the maximum.
 *
 * The limits are CTRM column widths, sourced per component from `constraints.json` (ADR-7), so the
 * same number drives this counter and the server-side FluentValidation rule. Truncating here rather
 * than letting the user overrun is deliberate: CTRM would silently cut the value at its own width,
 * and a remark that quietly loses its last eight characters somewhere between the browser and the
 * AS/400 is worse than one the user can see is full.
 */
export declare class TextInputComponent implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  /**
   * Renders the label row screen-reader-only, for a field grouped under one heading.
   *
   * ⚠ The row carries the character counter too, so hiding it hides that as well -- which is the
   * intent: a grouped field has no heading of its own to hang a count beside.
   */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  readonly controlId: import("@angular/core").InputSignal<string>;
  /** Maximum length, from `constraints.json`. Remarks are 72, per the CTRM column. */
  /**
   * The most characters the column holds, or `null` when no width is known (#732).
   *
   * `null` is "not known", never "unlimited by design": the control neither truncates nor counts down
   * from an invented number, and its counter says no limit is known. A guessed default would be worse
   * than the admitted unknown (Known Issue 16), which is why there is no fallback width here.
   */
  readonly maxLength: import("@angular/core").InputSignal<number | null>;
  /**
   * Angular-required: Angular's `RequiredValidator` matches `[required]` beside a form binding, so
   * this adds `Validators.required` to the control as well as the marker. For a template-driven or
   * reactive caller that wants exactly that.
   */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /**
   * The asterisk and `aria-required` ONLY, never a validator (#1074). For a caller that owns the
   * control's validators itself, as the form engine does: the name matches no Angular selector, so
   * binding it late cannot merge `Validators.required` in behind the owner's back.
   */
  readonly requiredMarker: import("@angular/core").InputSignal<boolean>;
  /** Either input marks the field required. */
  protected readonly showsRequired: import("@angular/core").Signal<boolean>;
  readonly readOnly: import("@angular/core").InputSignal<boolean>;
  /**
   * Renders a read-only value as TEXT rather than as a box (2026-10-13). See `PLAIN_VALUE_CLASS`.
   *
   * Presentation only: it changes nothing about what the control accepts. The form engine sets it on a
   * read-only field that has no error and no warning, because a value needing attention keeps its box.
   */
  readonly plain: import("@angular/core").InputSignal<boolean>;
  /** The field's description, behind an "i" beside the label. See `FieldComponent.help`. */
  readonly help: import("@angular/core").InputSignal<FieldHelp | null>;
  /** A quiet word on the label row, such as "Set by CTRM". See `FieldComponent.marker`. */
  readonly marker: import("@angular/core").InputSignal<string | null>;
  /**
   * Renders the VALUE on the quiet read-only surface instead of the control (2026-10-13): the
   * record screen's view mode. See `FieldValueComponent`. The control keeps its value and its form binding;
   * only what is drawn changes.
   */
  readonly display: import("@angular/core").InputSignal<boolean>;
  /** The value as this control shows it, for the sheet. The same text the box would hold. */
  protected readonly displayText: import("@angular/core").Signal<string>;
  protected readonly plainClass = "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
  protected readonly emptyText = "—";
  /**
   * Takes the field out of the tab order (#314). The form sets it on a read-only field while the
   * form is editable, so Tab and Enter skip what cannot be typed into, as protected fields are
   * skipped on the green screen.
   *
   * ⚠ Not `disabled`: the field stays focusable by click and copyable, and a read-only form leaves
   * it false so view mode keeps every value reachable by keyboard (JFrisbie, 2026-09-01).
   */
  readonly skipTab: import("@angular/core").InputSignal<boolean>;
  /** C10 — amber border plus tooltip; never blocks save. */
  readonly borderWarning: import("@angular/core").InputSignal<boolean>;
  readonly warningText: import("@angular/core").InputSignal<string | null>;
  readonly errorMessage: import("@angular/core").InputSignal<string | null>;
  /**
   * A verdict's outline, beside the value rather than as an error (#962): `invalid` is the error
   * outline and marks the box `aria-invalid`, `valid` the design system's green. The words are the
   * caller's to render, and {@link describedByExtra} links them, so the colour never stands alone.
   * An `errorMessage` wins over either.
   */
  readonly tone: import("@angular/core").InputSignal<"valid" | "invalid" | null>;
  /** One more element id this box is described by: the caller's verdict sentence (#962). */
  readonly describedByExtra: import("@angular/core").InputSignal<string | null>;
  /** Whether the box draws the error outline: an error, or an invalid verdict. */
  protected readonly invalid: import("@angular/core").Signal<boolean>;
  protected readonly disabled: import("@angular/core").WritableSignal<boolean>;
  protected readonly value: import("@angular/core").WritableSignal<string>;
  protected readonly remaining: import("@angular/core").Signal<number | null>;
  /** Warn as the user approaches the limit — 10% of the budget, at least 5 characters. */
  protected readonly nearLimit: import("@angular/core").Signal<boolean>;
  protected readonly describedBy: import("@angular/core").Signal<string>;
  private onChange;
  private onTouched;
  writeValue(value: string | null): void;
  /** The value cut to the maximum, or untouched when no maximum is known. */
  private clamp;
  registerOnChange(fn: (value: string | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  protected onInput(event: Event): void;
  protected onBlur(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<TextInputComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<TextInputComponent, "cms-text-input", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "maxLength": {
      "alias": "maxLength";
      "required": true;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "requiredMarker": {
      "alias": "requiredMarker";
      "required": false;
      "isSignal": true;
    };
    "readOnly": {
      "alias": "readOnly";
      "required": false;
      "isSignal": true;
    };
    "plain": {
      "alias": "plain";
      "required": false;
      "isSignal": true;
    };
    "help": {
      "alias": "help";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
    "skipTab": {
      "alias": "skipTab";
      "required": false;
      "isSignal": true;
    };
    "borderWarning": {
      "alias": "borderWarning";
      "required": false;
      "isSignal": true;
    };
    "warningText": {
      "alias": "warningText";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "describedByExtra": {
      "alias": "describedByExtra";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * A server-searched code list, for a combo whose list is too large to send whole (#1064).
 *
 * The code combo's search mode calls {@link CodeSearchSource.search} with what the user typed; the
 * form engine finds the source for a field by its `searchSet` key. Declared here, beside the combo,
 * because the combo is the one consumer that must agree with every source about the minimum length.
 */
export interface CodeSearchSource {
  /** Server search. Text shorter than {@link CODE_SEARCH_MIN_LENGTH} answers `remoteLoaded([])` without a request. */
  search(text: string): Observable<RemoteData<readonly CodeOption[]>>;
}
/** What the combo's `search` input takes: a source's `search`, bound. */
export type CodeSearch = (text: string) => Observable<RemoteData<readonly CodeOption[]>>;
/**
 * The fewest characters a search is sent for.
 *
 * ⚠ **3, where docs/02a §3 says 2 for C2, and on purpose.** Measured on apiuat (#1064): a name search
 * for three letters of a city returned 528 rows, and the cap below is applied in the browser, so the
 * server still sends every row. Without a backend change the length is the only lever on the payload.
 */
export declare const CODE_SEARCH_MIN_LENGTH = 3;
/** The most options a search offers. Applied client-side: the route has no page size. */
export declare const CODE_SEARCH_MAX_RESULTS = 50;
/**
 * One selectable value. Structurally identical to `AllowedValue` in `@cws/shared-form-engine`, and
 * declared here rather than imported on purpose: the form engine renders *through* this kit, so a
 * dependency in this direction would close a cycle. TypeScript's structural typing means the form
 * engine's own values pass without conversion.
 */
export interface CodeOption {
  readonly code: string;
  readonly description: string;
}
/**
 * **Control pattern C1 — searchable code combo** (docs/02a §3).
 *
 * The most-used pattern in the application: UOM, price type, contract type, payment terms, grade,
 * market zone, incoterms, market month and roughly a dozen more all map to it. Displays
 * `CODE — Description`, and type-ahead matches **code and description simultaneously** — a trader
 * who knows `BU` types `BU`, one who does not types `bushel`, and both land on the same option.
 *
 * Allowed values come from the trade unit's value configuration (BR-001); this control renders what
 * it is given and never filters on business grounds of its own.
 *
 * **Fully keyboard operable, which is an acceptance criterion, not a nicety** (02a §4, docs/05
 * header). Type to filter, ↑↓ to move, Enter to select, Esc to revert to the last committed value.
 * A pasted exact code is accepted directly, because that is how values arrive from the green screen
 * and from spreadsheets.
 *
 * Implements the ARIA combobox pattern: `role="combobox"` with `aria-expanded` and
 * `aria-activedescendant` on the input, a `role="listbox"` popup, and `role="option"` items — so the
 * active option is announced without focus ever leaving the text field.
 */
export declare class CodeComboComponent implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly controlId: import("@angular/core").InputSignal<string>;
  /** Allowed values for this component in this trade unit (BR-001 value configuration). */
  readonly options: import("@angular/core").InputSignal<readonly CodeOption[]>;
  /**
   * Angular-required: Angular's `RequiredValidator` matches `[required]` beside a form binding, so
   * this adds `Validators.required` to the control as well as the marker. For a template-driven or
   * reactive caller that wants exactly that.
   */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /**
   * The asterisk and `aria-required` ONLY, never a validator (#1074). For a caller that owns the
   * control's validators itself, as the form engine does: the name matches no Angular selector, so
   * binding it late cannot merge `Validators.required` in behind the owner's back.
   */
  readonly requiredMarker: import("@angular/core").InputSignal<boolean>;
  /** Either input marks the field required. */
  protected readonly showsRequired: import("@angular/core").Signal<boolean>;
  /** Renders the label screen-reader-only (#221): still the control's name, never removed. */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  readonly readOnly: import("@angular/core").InputSignal<boolean>;
  /**
   * Renders a read-only value as TEXT rather than as a box (2026-10-13). See `PLAIN_VALUE_CLASS`.
   *
   * Presentation only: it changes nothing about what the control accepts. The form engine sets it on a
   * read-only field that has no error and no warning, because a value needing attention keeps its box.
   */
  readonly plain: import("@angular/core").InputSignal<boolean>;
  /** The field's description, behind an "i" beside the label. See `FieldComponent.help`. */
  readonly help: import("@angular/core").InputSignal<FieldHelp | null>;
  /** A quiet word on the label row, such as "Set by CTRM". See `FieldComponent.marker`. */
  readonly marker: import("@angular/core").InputSignal<string | null>;
  /**
   * Renders the VALUE on the quiet read-only surface instead of the control (2026-10-13): the
   * record screen's view mode. See `FieldValueComponent`. The control keeps its value and its form binding;
   * only what is drawn changes.
   */
  readonly display: import("@angular/core").InputSignal<boolean>;
  /**
   * A box sized for its code alone, such as a one-character key prefix (#920). The box shows the code,
   * the description goes in the box's tooltip, and the list opens wider than the box so its options
   * stay readable. The sheet shows the code alone too: a box sized for one character wrapped its
   * description a few letters to a line (JFrisbie, 2026-10-23).
   */
  readonly compact: import("@angular/core").InputSignal<boolean>;
  /**
   * **Search mode** (#1064): the list is a server search for what was typed, not a filter over
   * {@link options}. For a code list too large to send whole, such as Origin and Destination code.
   *
   * - From {@link CODE_SEARCH_MIN_LENGTH} characters, 250 ms after the last keystroke, the latest
   *   query wins (`switchMap`). Below it, nothing is asked.
   * - The list says what is happening: too short, searching, no matches, or search unavailable.
   * - 🔴 **A typed code still commits** on Enter, Tab or blur, trimmed and upper-cased, whatever the
   *   search said. CTRM checks the code on save, and a search that is down or finds nothing must not
   *   stop a trader entering a code they know. That is the one way this mode is not a closed set.
   *
   * `null`, the default, leaves the combo exactly as it was.
   */
  readonly search: import("@angular/core").InputSignal<CodeSearch | null>;
  /** The latest search answer, or `null` below the minimum length. */
  protected readonly searchState: import("@angular/core").WritableSignal<RemoteData<readonly CodeOption[]> | null>;
  /** What was typed, for the debounced search. */
  private readonly searchQueries;
  /** The option last chosen from a search, so the box can still show its description. */
  private readonly chosen;
  constructor();
  /**
   * The line the list shows instead of options in search mode, or `null` when it has options to
   * show. The wordings are frozen by #1064.
   */
  protected readonly searchStatus: import("@angular/core").Signal<"Type at least 3 characters to search." | "Searching…" | "Search unavailable. Enter the code; CTRM checks it when you save." | "No matches. CTRM checks the code when you save." | null>;
  /** What an empty list says: the search's line in search mode, "No matches" otherwise. */
  protected readonly emptyListText: import("@angular/core").Signal<"Type at least 3 characters to search." | "Searching…" | "Search unavailable. Enter the code; CTRM checks it when you save." | "No matches. CTRM checks the code when you save." | "No matches">;
  /** The selected option's full text, as the compact box's tooltip. */
  protected readonly compactTitle: import("@angular/core").Signal<string | null>;
  /** The value as this control shows it, for the sheet. The same text the box would hold. */
  protected readonly displayText: import("@angular/core").Signal<string>;
  protected readonly plainClass = "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
  protected readonly emptyText = "—";
  /**
   * Whether the box draws the dropdown caret (2026-10-28): so a combo reads as a list, as a native
   * select does. Not on a read-only or plain box, where nothing opens. A disabled box keeps it, muted.
   * Display mode draws no box at all, so no caret either.
   */
  protected readonly showsCaret: import("@angular/core").Signal<boolean>;
  /**
   * Takes the field out of the tab order (#314). The form sets it on a read-only field while the
   * form is editable, so Tab and Enter skip what cannot be typed into, as protected fields are
   * skipped on the green screen.
   *
   * ⚠ Not `disabled`: the field stays focusable by click and copyable, and a read-only form leaves
   * it false so view mode keeps every value reachable by keyboard (JFrisbie, 2026-09-01).
   */
  readonly skipTab: import("@angular/core").InputSignal<boolean>;
  /** C10 — amber border plus tooltip; never blocks save. */
  readonly borderWarning: import("@angular/core").InputSignal<boolean>;
  readonly warningText: import("@angular/core").InputSignal<string | null>;
  readonly errorMessage: import("@angular/core").InputSignal<string | null>;
  /**
   * A verdict's outline, beside the value rather than as an error (#965, as #962 drew the text input's):
   * `invalid` is the error outline and marks the box `aria-invalid`, `valid` the design system's green.
   * The words are the caller's to render, and {@link describedByExtra} links them, so the colour never
   * stands alone. An `errorMessage` wins over either.
   */
  readonly tone: import("@angular/core").InputSignal<"valid" | "invalid" | null>;
  /** One more element id this box is described by: the caller's verdict sentence (#965). */
  readonly describedByExtra: import("@angular/core").InputSignal<string | null>;
  /** Whether the box draws the error outline: an error, or an invalid verdict. */
  protected readonly invalid: import("@angular/core").Signal<boolean>;
  private readonly inputElement;
  protected readonly disabled: import("@angular/core").WritableSignal<boolean>;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  protected readonly activeIndex: import("@angular/core").WritableSignal<number>;
  /** The committed code — what the form model holds. */
  protected readonly selectedCode: import("@angular/core").WritableSignal<string | null>;
  /** What the user has typed. `null` means "show the committed selection". */
  protected readonly query: import("@angular/core").WritableSignal<string | null>;
  protected readonly selectedOption: import("@angular/core").Signal<CodeOption | null>;
  /** `CODE — Description` when committed and not being edited. */
  protected readonly displayValue: import("@angular/core").Signal<string>;
  /** Matches code and description together, case-insensitively. */
  protected readonly filtered: import("@angular/core").Signal<readonly CodeOption[]>;
  protected readonly describedBy: import("@angular/core").Signal<string | null>;
  /**
   * The classes for one option row, active or not.
   *
   * ### 🔴 Why this does not use `.scoular-dropdown-item`, which it used to
   *
   * The design system models exactly one active state — `.scoular-dropdown-item.active` is
   * `bg-slate-50 text-scoular-blue` — and this listbox needs a blue *fill* with white text. Half
   * using the class and overriding the rest is what produced two contrast bugs in a row, both from
   * the same cause: **the design system compiles as unlayered CSS and Tailwind utilities land in
   * `@layer utilities`, so unlayered wins at equal specificity, every time.**
   *
   * 1. `text-slate-700` on the base class beat `text-white` → slate-700 on scoular-blue, **1.37:1**.
   * 2. `hover:bg-slate-50` on the base class beat `bg-scoular-blue` → hovering the active row turned
   *    it near-white while the text stayed white, so the row all but vanished under the pointer.
   *
   * The first was worked around by moving the colour onto the child spans, which a background cannot
   * copy: the padding that makes the fill reach the row's edges lives on the same class. Owning both
   * states here removes the contest instead of fighting it twice — every declaration below is a
   * Tailwind utility competing only with other Tailwind utilities.
   *
   * ⚠ **The layout half is a deliberate duplicate** of `.scoular-dropdown-item`'s
   * `flex w-full items-center gap-3 px-4 py-2 text-sm transition-colors`, copied so the option rows
   * still match every other dropdown in the application. If the design system changes those, this
   * will not follow — that is the cost of the divergence, and it is accepted because the *colour*
   * half was never going to match anyway.
   *
   * `scoular-blue-dark` (#004671) on hover is the design system's own primary-hover token, so the
   * active row darkens under the pointer exactly as a primary button does. White on it is darker
   * than white on #00588E, which already measures 7.5:1 — so hover raises contrast rather than
   * destroying it.
   *
   * ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported
   * into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept
   * because it explains why this code looks the way it does, and the code is unchanged: each of these
   * shapes has a second justification that has nothing to do with layers. See the header of the
   * shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to
   * the shell, so an embedded host may still supply the old cascade.
   */
  protected optionClass(active: boolean): string;
  protected optionId(index: number): string;
  protected readonly activeOptionId: import("@angular/core").Signal<string | null>;
  private onChange;
  private onTouched;
  writeValue(value: string | null): void;
  registerOnChange(fn: (value: string | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  protected onInput(event: Event): void;
  /**
   * Opens the list when the user moves focus here, by Tab or a click. A focus the screen moved
   * with {@link focusWithoutOpening} leaves it closed (#1050): see that function.
   */
  protected onFocus(): void;
  protected onKeydown(event: KeyboardEvent): void;
  /**
   * `F4` (#314), the green screen's Prompt key. The form's binding dispatches `OPEN_LOOKUP_EVENT`
   * here; the template only marks the input as having a list while it is editable.
   */
  protected openLookup(): void;
  /**
   * A click opens a closed list (#1050). Focus alone opened it, so a click on a combo that already
   * had the caret, after Esc or a focus that kept it closed, used to do nothing at all.
   */
  protected onClick(): void;
  protected onOptionClick(option: CodeOption): void;
  protected onBlur(): void;
  private openIfClosed;
  private move;
  private indexOfSelected;
  private commit;
  /** Esc abandons the in-progress text and restores the last committed value (02a C1). */
  private revert;
  /**
   * Search mode's typed code (#1064): the text, trimmed and upper-cased, or the searched option whose
   * code it is, so its description still shows. Cleared text clears the value. Text that was never
   * edited commits nothing.
   */
  private commitTyped;
  /**
   * Leaving the control discards half-typed text. A combo is a closed set — free text that matched
   * nothing is not a value, and keeping it would let unconfigured codes reach CTRM.
   *
   * ⚠ **Except in search mode** (#1064), where the typed code commits: the list there is a search
   * over CTRM's codes rather than the set of allowed values, and CTRM checks the code on save.
   */
  private closeAndSettle;
  static ɵfac: i0.ɵɵFactoryDeclaration<CodeComboComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<CodeComboComponent, "cms-code-combo", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "requiredMarker": {
      "alias": "requiredMarker";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "readOnly": {
      "alias": "readOnly";
      "required": false;
      "isSignal": true;
    };
    "plain": {
      "alias": "plain";
      "required": false;
      "isSignal": true;
    };
    "help": {
      "alias": "help";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
    "compact": {
      "alias": "compact";
      "required": false;
      "isSignal": true;
    };
    "search": {
      "alias": "search";
      "required": false;
      "isSignal": true;
    };
    "skipTab": {
      "alias": "skipTab";
      "required": false;
      "isSignal": true;
    };
    "borderWarning": {
      "alias": "borderWarning";
      "required": false;
      "isSignal": true;
    };
    "warningText": {
      "alias": "warningText";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
    "tone": {
      "alias": "tone";
      "required": false;
      "isSignal": true;
    };
    "describedByExtra": {
      "alias": "describedByExtra";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Set on a control for the length of a {@link focusWithoutOpening} call. A combo that sees it on
 * focus keeps its list closed.
 */
export declare const QUIET_FOCUS_ATTRIBUTE = "data-cws-quiet-focus";
/**
 * Puts the caret in a control without opening its list (#1050).
 *
 * 🔴 **For a focus the SCREEN moves, to show the user something about the field**: a refused save, or
 * the validation summary's link. A combo opens its list on focus, and the list is drawn over the line
 * below the box, which is where the field's error sentence is. So the user arrived at the refused
 * field and could not read why it was refused. The list still opens on ArrowDown, typing, `F4` or a
 * click, so nothing is lost to the keyboard.
 *
 * ⚠ **An attribute on the element, not a flag in this module**, so it still works if a host bundles
 * two copies of this library. It is removed straight after, because the focus event fires during
 * `focus()`. Harmless on a control that is not a combo.
 */
export declare function focusWithoutOpening(element: HTMLElement): void;
/**
 * **The caret that says "this field opens a list"** (JFrisbie, 2026-10-28, system-wide).
 *
 * A native `<select>` draws its own chevron. The typeable pickers built on a text input (the code
 * combo, the admin code picker) did not, so they read as plain text boxes. This is the one chevron
 * every list-opening field uses, so a combo and a button-styled select look alike.
 *
 * - **Decoration only.** `aria-hidden`, because the control's own `role="combobox"` or
 *   `aria-haspopup` already says a list opens. `pointer-events-none`, so a click on it lands on the
 *   input underneath, which opens the list itself.
 * - **The caller places it.** Inside a text input it is absolutely positioned on the right, and the
 *   input takes right padding so text never runs under it. Inside a button it is a flex child.
 * - **The caller decides when to draw it.** Nothing opens on a read-only field or in the record
 *   screen's display mode, so those draw no caret. A disabled field keeps it, muted.
 *
 * **Drawn to match the browser's own select chevron** (Edge, measured 2026-10-28): 8px wide, a 2px
 * stroke, in the text colour, about 10px in from the right border. It takes the colour of the text
 * around it, so a caller inside a text input sets the input's text colour on it.
 *
 * An inline SVG rather than a glyph: a text triangle renders differently per font, and the date
 * field's calendar icon is drawn the same way.
 */
export declare class DropdownCaretComponent {
  /** Whether the list is open. The chevron turns over while it is. */
  readonly open: import("@angular/core").InputSignal<boolean>;
  /** Whether the field is disabled. The chevron is muted to match. */
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DropdownCaretComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DropdownCaretComponent, "cms-dropdown-caret", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * **Control pattern C3 — masked date input** (docs/02a §3).
 *
 * Applies to contract date, ship-period dates, price date and the LC dates. Grain traders type
 * dates as digits at green-screen speed, so free typing is the primary path and the calendar picker
 * is an affordance, never a requirement (02a §1.1).
 *
 * Parsing is **not** reimplemented here — it imports `parseShipPeriodDate` from the form engine,
 * which already implements BR-020's accepted shapes (`MMDDYYYY`, `MMDDYY` with the 1930–2029
 * century pivot, `MM/DD/YYYY`, and since #688 a strict `YYYY-MM-DD`) and is covered by 20 tests. Duplicating a rule with a century
 * pivot in it is how a date silently moves by a hundred years, so this control deliberately owns no
 * date logic of its own. (This import is also the first cross-library import in the workspace, which
 * is why the alias mapping had to be fixed before C3 could exist at all.)
 *
 * Per 02a C3: parse on **blur**, and on a failed parse **keep the raw text** and show an inline
 * error rather than discarding what the user typed — losing a half-typed date to a silent reset is
 * worse than showing it back with a complaint.
 *
 * The model value is a canonical ISO `yyyy-MM-dd` string, so nothing downstream parses display text.
 */
export declare class DateInputComponent implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly controlId: import("@angular/core").InputSignal<string>;
  /**
   * Angular-required: Angular's `RequiredValidator` matches `[required]` beside a form binding, so
   * this adds `Validators.required` to the control as well as the marker. For a template-driven or
   * reactive caller that wants exactly that.
   */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /**
   * The asterisk and `aria-required` ONLY, never a validator (#1074). For a caller that owns the
   * control's validators itself, as the form engine does: the name matches no Angular selector, so
   * binding it late cannot merge `Validators.required` in behind the owner's back.
   */
  readonly requiredMarker: import("@angular/core").InputSignal<boolean>;
  /** Either input marks the field required. */
  protected readonly showsRequired: import("@angular/core").Signal<boolean>;
  /** Renders the label screen-reader-only (#221): still the control's name, never removed. */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  readonly readOnly: import("@angular/core").InputSignal<boolean>;
  /**
   * Renders a read-only value as TEXT rather than as a box (2026-10-13). See `PLAIN_VALUE_CLASS`.
   *
   * Presentation only: it changes nothing about what the control accepts. The form engine sets it on a
   * read-only field that has no error and no warning, because a value needing attention keeps its box.
   */
  readonly plain: import("@angular/core").InputSignal<boolean>;
  /** The field's description, behind an "i" beside the label. See `FieldComponent.help`. */
  readonly help: import("@angular/core").InputSignal<FieldHelp | null>;
  /** A quiet word on the label row, such as "Set by CTRM". See `FieldComponent.marker`. */
  readonly marker: import("@angular/core").InputSignal<string | null>;
  /**
   * Renders the VALUE on the quiet read-only surface instead of the control (2026-10-13): the
   * record screen's view mode. See `FieldValueComponent`. The control keeps its value and its form binding;
   * only what is drawn changes.
   */
  readonly display: import("@angular/core").InputSignal<boolean>;
  /** The value as this control shows it, for the sheet. The same text the box would hold. */
  protected readonly displayText: import("@angular/core").Signal<string>;
  protected readonly plainClass = "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
  protected readonly emptyText = "—";
  /**
   * Takes the field out of the tab order (#314). The form sets it on a read-only field while the
   * form is editable, so Tab and Enter skip what cannot be typed into, as protected fields are
   * skipped on the green screen.
   *
   * ⚠ Not `disabled`: the field stays focusable by click and copyable, and a read-only form leaves
   * it false so view mode keeps every value reachable by keyboard (JFrisbie, 2026-09-01).
   */
  readonly skipTab: import("@angular/core").InputSignal<boolean>;
  /** C10 — amber border plus tooltip; never blocks save. */
  readonly borderWarning: import("@angular/core").InputSignal<boolean>;
  readonly warningText: import("@angular/core").InputSignal<string | null>;
  /** Validation message from the form. A local parse failure adds its own on top. */
  readonly errorMessage: import("@angular/core").InputSignal<string | null>;
  protected readonly disabled: import("@angular/core").WritableSignal<boolean>;
  /** Canonical ISO value — what the form model holds. */
  protected readonly value: import("@angular/core").WritableSignal<string | null>;
  /** Raw text the user typed. Non-null only while editing or after a failed parse. */
  protected readonly rawText: import("@angular/core").WritableSignal<string | null>;
  /** Set when the last blur could not parse. Cleared as soon as the text parses or empties. */
  protected readonly parseError: import("@angular/core").WritableSignal<boolean>;
  protected readonly displayValue: import("@angular/core").Signal<string>;
  /** A local parse failure takes precedence — it is the more immediate problem. */
  protected readonly effectiveError: import("@angular/core").Signal<string | null>;
  protected readonly describedBy: import("@angular/core").Signal<string | null>;
  /**
   * Whether the calendar popover is open.
   *
   * 🔴 It opens from the trigger button and from nothing else -- never on focus, never on a
   * keystroke. 02a §1.1: traders type dates at green-screen speed, and a popover that appeared
   * when the field took focus would cover the next field on every tab through a form.
   */
  private readonly overlay;
  /**
   * Stays attached to the field while the page scrolls, rather than being left behind.
   *
   * ⚠ An OBJECT, not the string the directive appears to take. `cdkConnectedOverlayScrollStrategy
   * = "reposition"` compiles as a template string and fails the type check -- the strategies are
   * built from the injected `Overlay`, which is also what lets them be swapped in a test.
   */
  protected readonly pickerScroll: import("@angular/cdk/overlay").RepositionScrollStrategy;
  protected readonly pickerOpen: import("@angular/core").WritableSignal<boolean>;
  /** Where the overlay attaches, and what focus returns to. */
  private readonly textInput;
  private readonly picker;
  /**
   * The date the picker should open on.
   *
   * ⚠ The COMMITTED value, not the raw text. Opening the calendar while half a date is typed
   * must not try to read it -- and must not discard it either (brief item 6): the raw text stays
   * exactly where it was, and the picker simply opens on today.
   */
  protected readonly pickerValue: import("@angular/core").Signal<string | null>;
  /** No trigger at all when the field cannot be edited -- a picker that writes nothing is a lie. */
  protected readonly showTrigger: import("@angular/core").Signal<boolean>;
  /**
   * Below the field, flipping above when there is no room.
   *
   * 🔴 The fallback is the whole reason this uses an overlay rather than an absolutely positioned
   * panel. A date field near the foot of a long form -- which on the contract record screen is
   * most of them -- would otherwise open a 20rem popover off the bottom of the viewport, with its
   * Today and Clear buttons unreachable.
   *
   * `start` on both, so the calendar aligns with the left edge of the field rather than with the
   * trigger button at its right.
   */
  protected readonly pickerPositions: ConnectedPosition[];
  /**
   * Escape closes the popover without selecting, and marks the key spent.
   *
   * ⚠ The `preventDefault` is not about a browser default -- Escape has none here. It signals to
   * other Escape handlers on the page that this keypress is used: the contract record screen
   * navigates back to the grid on Escape, and a user closing this calendar must not also leave
   * the record. `cmsDropdown` carries the same reasoning for the five panels it serves.
   */
  protected onOverlayKeydown(event: KeyboardEvent): void;
  protected togglePicker(): void;
  protected openPicker(): void;
  /**
   * Closes the popover and returns focus to the text input.
   *
   * 🔑 Focus goes to the INPUT rather than the trigger button. The input is where typing
   * continues, and it is what the user was working in before they reached for the calendar --
   * leaving focus on the button would make the next keystroke go nowhere.
   */
  protected closePicker(): void;
  /** Moves DOM focus onto the grid once the overlay has attached. */
  protected onPickerAttached(): void;
  /**
   * A date chosen from the calendar.
   *
   * 🔴 Indistinguishable to the form from a typed date that parsed -- same three signals set the
   * same way, same `onChange`, same `onTouched`. That equivalence is asserted against the typed
   * path rather than against a fresh expectation, so the two cannot drift apart.
   */
  protected onPicked(iso: string): void;
  /** Clear, from the popover footer. The empty path of `onBlur`, reached a different way. */
  protected onPickerCleared(): void;
  private onChange;
  private onTouched;
  writeValue(value: string | null): void;
  registerOnChange(fn: (value: string | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  protected onInput(event: Event): void;
  protected onBlur(): void;
  /**
   * `yyyy-MM-dd` → `MM/DD/YYYY`, the canonical display form. Shared with the record header (#774)
   * through `formatDisplayDate`, so the two cannot drift.
   */
  private formatForDisplay;
  static ɵfac: i0.ɵɵFactoryDeclaration<DateInputComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DateInputComponent, "cms-date-input", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "requiredMarker": {
      "alias": "requiredMarker";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "readOnly": {
      "alias": "readOnly";
      "required": false;
      "isSignal": true;
    };
    "plain": {
      "alias": "plain";
      "required": false;
      "isSignal": true;
    };
    "help": {
      "alias": "help";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
    "skipTab": {
      "alias": "skipTab";
      "required": false;
      "isSignal": true;
    };
    "borderWarning": {
      "alias": "borderWarning";
      "required": false;
      "isSignal": true;
    };
    "warningText": {
      "alias": "warningText";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * **Control pattern C6 — multiline note** (docs/02a §3).
 *
 * Applies to internal notes, the approval email message and additional terms. An auto-growing
 * textarea with a remaining-character counter, capped from `constraints.json` — `note` is 32,000
 * characters in CTRM, so the counter matters far less than C5's 72-character remark, but the hard
 * stop is the same rule for the same reason: CTRM truncates silently at its own column width.
 *
 * Growth is done with `field-sizing: content` where supported, falling back to a `rows` floor. No
 * scroll-height measurement and no `afterEveryRender` hook — a resize observer on every note in a
 * form is a lot of machinery to avoid a scrollbar.
 */
export declare class NoteInputComponent implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly controlId: import("@angular/core").InputSignal<string>;
  /** Maximum length, from `constraints.json`. `note` is 32,000; additional terms are shorter. */
  /**
   * The most characters the column holds, or `null` when no width is known (#732).
   *
   * `null` is "not known", never "unlimited by design": the control neither truncates nor counts down
   * from an invented number, and its counter says no limit is known. A guessed default would be worse
   * than the admitted unknown (Known Issue 16), which is why there is no fallback width here.
   */
  readonly maxLength: import("@angular/core").InputSignal<number | null>;
  /** Minimum visible rows before growth. */
  readonly rows: import("@angular/core").InputSignal<number>;
  /**
   * Angular-required: Angular's `RequiredValidator` matches `[required]` beside a form binding, so
   * this adds `Validators.required` to the control as well as the marker. For a template-driven or
   * reactive caller that wants exactly that.
   */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /**
   * The asterisk and `aria-required` ONLY, never a validator (#1074). For a caller that owns the
   * control's validators itself, as the form engine does: the name matches no Angular selector, so
   * binding it late cannot merge `Validators.required` in behind the owner's back.
   */
  readonly requiredMarker: import("@angular/core").InputSignal<boolean>;
  /** Either input marks the field required. */
  protected readonly showsRequired: import("@angular/core").Signal<boolean>;
  /** Renders the label screen-reader-only (#221): still the control's name, never removed. */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  readonly readOnly: import("@angular/core").InputSignal<boolean>;
  /**
   * Renders a read-only value as TEXT rather than as a box (2026-10-13). See `PLAIN_VALUE_CLASS`.
   *
   * Presentation only: it changes nothing about what the control accepts. The form engine sets it on a
   * read-only field that has no error and no warning, because a value needing attention keeps its box.
   */
  readonly plain: import("@angular/core").InputSignal<boolean>;
  /** The field's description, behind an "i" beside the label. See `FieldComponent.help`. */
  readonly help: import("@angular/core").InputSignal<FieldHelp | null>;
  /** A quiet word on the label row, such as "Set by CTRM". See `FieldComponent.marker`. */
  readonly marker: import("@angular/core").InputSignal<string | null>;
  /**
   * Renders the VALUE on the quiet read-only surface instead of the control (2026-10-13): the
   * record screen's view mode. See `FieldValueComponent`. The control keeps its value and its form binding;
   * only what is drawn changes.
   */
  readonly display: import("@angular/core").InputSignal<boolean>;
  /** The value as this control shows it, for the sheet. The same text the box would hold. */
  protected readonly displayText: import("@angular/core").Signal<string>;
  protected readonly plainClass = "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
  protected readonly emptyText = "—";
  /**
   * Takes the field out of the tab order (#314). The form sets it on a read-only field while the
   * form is editable, so Tab and Enter skip what cannot be typed into, as protected fields are
   * skipped on the green screen.
   *
   * ⚠ Not `disabled`: the field stays focusable by click and copyable, and a read-only form leaves
   * it false so view mode keeps every value reachable by keyboard (JFrisbie, 2026-09-01).
   */
  readonly skipTab: import("@angular/core").InputSignal<boolean>;
  /** C10 — amber border plus tooltip; never blocks save. */
  readonly borderWarning: import("@angular/core").InputSignal<boolean>;
  readonly warningText: import("@angular/core").InputSignal<string | null>;
  readonly errorMessage: import("@angular/core").InputSignal<string | null>;
  protected readonly disabled: import("@angular/core").WritableSignal<boolean>;
  protected readonly value: import("@angular/core").WritableSignal<string>;
  protected readonly remaining: import("@angular/core").Signal<number | null>;
  /** Warn near the limit — 10% of the budget, at least 5 characters. */
  protected readonly nearLimit: import("@angular/core").Signal<boolean>;
  protected readonly describedBy: import("@angular/core").Signal<string>;
  private onChange;
  private onTouched;
  writeValue(value: string | null): void;
  /** The value cut to the maximum, or untouched when no maximum is known. */
  private clamp;
  registerOnChange(fn: (value: string | null) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  protected onInput(event: Event): void;
  protected onBlur(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NoteInputComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NoteInputComponent, "cms-note-input", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "maxLength": {
      "alias": "maxLength";
      "required": true;
      "isSignal": true;
    };
    "rows": {
      "alias": "rows";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "requiredMarker": {
      "alias": "requiredMarker";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "readOnly": {
      "alias": "readOnly";
      "required": false;
      "isSignal": true;
    };
    "plain": {
      "alias": "plain";
      "required": false;
      "isSignal": true;
    };
    "help": {
      "alias": "help";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
    "skipTab": {
      "alias": "skipTab";
      "required": false;
      "isSignal": true;
    };
    "borderWarning": {
      "alias": "borderWarning";
      "required": false;
      "isSignal": true;
    };
    "warningText": {
      "alias": "warningText";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * **Control pattern C9 — toggle / flag** (docs/02a §3).
 *
 * Applies to Print Immediately, the pricing print flag and the admin toggles. 02a is specific about
 * two things: the state carries an **explicit Yes/No label** rather than relying on the switch's
 * position alone, and **Space toggles**.
 *
 * Built on a `<button role="switch">` rather than a checkbox. A checkbox would give Space for free,
 * but `aria-checked` on a `role="switch"` is announced as "on/off" rather than "checked", which is
 * what a Yes/No flag actually means — and the visual switch is then honest markup instead of a
 * checkbox styled to look like something it is not. Space and Enter are both wired explicitly;
 * a native `<button>` already fires click on both, so this is belt and braces for the Space case
 * where the browser would otherwise scroll.
 *
 * The model value is a strict boolean. `writeValue(null)` becomes `false` — a flag CTRM did not
 * send is off, not indeterminate.
 */
export declare class ToggleComponent implements ControlValueAccessor {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly controlId: import("@angular/core").InputSignal<string>;
  /** Text shown for the on state. Overridable because some flags read better as Include/Exclude. */
  readonly onLabel: import("@angular/core").InputSignal<string>;
  readonly offLabel: import("@angular/core").InputSignal<string>;
  /**
   * Angular-required: Angular's `RequiredValidator` matches `[required]` beside a form binding, so
   * this adds `Validators.required` to the control as well as the marker. For a template-driven or
   * reactive caller that wants exactly that.
   */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /**
   * The asterisk and `aria-required` ONLY, never a validator (#1074). For a caller that owns the
   * control's validators itself, as the form engine does: the name matches no Angular selector, so
   * binding it late cannot merge `Validators.required` in behind the owner's back.
   */
  readonly requiredMarker: import("@angular/core").InputSignal<boolean>;
  /** Either input marks the field required. */
  protected readonly showsRequired: import("@angular/core").Signal<boolean>;
  /** Renders the label screen-reader-only (#221): still the control's name, never removed. */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  readonly readOnly: import("@angular/core").InputSignal<boolean>;
  /**
   * Renders a read-only value as TEXT rather than as a box (2026-10-13). See `PLAIN_VALUE_CLASS`.
   *
   * Presentation only: it changes nothing about what the control accepts. The form engine sets it on a
   * read-only field that has no error and no warning, because a value needing attention keeps its box.
   */
  readonly plain: import("@angular/core").InputSignal<boolean>;
  /** The field's description, behind an "i" beside the label. See `FieldComponent.help`. */
  readonly help: import("@angular/core").InputSignal<FieldHelp | null>;
  /** A quiet word on the label row, such as "Set by CTRM". See `FieldComponent.marker`. */
  readonly marker: import("@angular/core").InputSignal<string | null>;
  /**
   * Renders the VALUE on the quiet read-only surface instead of the control (2026-10-13): the
   * record screen's view mode. See `FieldValueComponent`. The control keeps its value and its form binding;
   * only what is drawn changes.
   */
  readonly display: import("@angular/core").InputSignal<boolean>;
  /** The value as this control shows it, for the sheet. The same text the box would hold. */
  protected readonly displayText: import("@angular/core").Signal<string>;
  protected readonly plainClass = "cws:border-transparent! cws:bg-slate-100! cws:text-slate-900! cws:dark:bg-slate-900/60! cws:dark:text-slate-100! cws:shadow-none! cws:ring-0! cws:cursor-default! cws:placeholder:text-slate-400! cws:dark:placeholder:text-slate-500! cws:focus-visible:outline-solid! cws:focus-visible:outline-2! cws:focus-visible:outline-offset-2! cws:focus-visible:outline-scoular-blue!";
  protected readonly emptyText = "—";
  /**
   * Takes the field out of the tab order (#314). The form sets it on a read-only field while the
   * form is editable, so Tab and Enter skip what cannot be typed into, as protected fields are
   * skipped on the green screen.
   *
   * ⚠ Not `disabled`: the field stays focusable by click and copyable, and a read-only form leaves
   * it false so view mode keeps every value reachable by keyboard (JFrisbie, 2026-09-01).
   */
  readonly skipTab: import("@angular/core").InputSignal<boolean>;
  /** C10 — amber border plus tooltip; never blocks save. */
  readonly borderWarning: import("@angular/core").InputSignal<boolean>;
  readonly warningText: import("@angular/core").InputSignal<string | null>;
  readonly errorMessage: import("@angular/core").InputSignal<string | null>;
  protected readonly disabled: import("@angular/core").WritableSignal<boolean>;
  protected readonly checked: import("@angular/core").WritableSignal<boolean>;
  protected readonly stateLabel: import("@angular/core").Signal<string>;
  protected readonly describedBy: import("@angular/core").Signal<string | null>;
  private onChange;
  private onTouched;
  writeValue(value: boolean | null): void;
  registerOnChange(fn: (value: boolean) => void): void;
  registerOnTouched(fn: () => void): void;
  setDisabledState(isDisabled: boolean): void;
  protected toggle(): void;
  protected onKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ToggleComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ToggleComponent, "cms-toggle", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "onLabel": {
      "alias": "onLabel";
      "required": false;
      "isSignal": true;
    };
    "offLabel": {
      "alias": "offLabel";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "requiredMarker": {
      "alias": "requiredMarker";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
    "readOnly": {
      "alias": "readOnly";
      "required": false;
      "isSignal": true;
    };
    "plain": {
      "alias": "plain";
      "required": false;
      "isSignal": true;
    };
    "help": {
      "alias": "help";
      "required": false;
      "isSignal": true;
    };
    "marker": {
      "alias": "marker";
      "required": false;
      "isSignal": true;
    };
    "display": {
      "alias": "display";
      "required": false;
      "isSignal": true;
    };
    "skipTab": {
      "alias": "skipTab";
      "required": false;
      "isSignal": true;
    };
    "borderWarning": {
      "alias": "borderWarning";
      "required": false;
      "isSignal": true;
    };
    "warningText": {
      "alias": "warningText";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * What a status pill MEANS, rather than what colour it is.
 *
 * The design system's own names are colour-ish (`error`, `warning`) and these are meaning-ish. That
 * indirection is the point: a caller says what the value signifies and this file decides how it
 * looks, so re-tinting every "needs attention" pill in the application is one edit here.
 */
export type StatusTone = 'positive' | 'caution' | 'negative' | 'info' | 'neutral';
/**
 * The tone's class string, for the two callers that must compose a class rather than render an
 * element — a grid cell decides between a pill and plain text inside its own template.
 *
 * Prefer {@link StatusBadgeComponent}. This exists so that those callers do not need their own copy
 * of the mapping, which is exactly how the three copies happened.
 */
export declare function statusBadgeClass(tone: StatusTone, small?: boolean): string;
/**
 * A status pill.
 *
 * 🔴 **The HOST is the pill — there is no wrapper element**, and that is what makes the call sites
 * migrate cleanly. Every one of them was already a bare `<span class="scoular-badge ...">`, so a
 * component that rendered its own inner span would have put a second box between the pill and
 * whatever lays it out, and `display: contents` on the wrapper would have made a consumer's own class
 * (the clear-sort count badge needs `h-5`) style the wrong element.
 *
 * Angular merges a consumer's static `class` with a host `[class]` binding, so
 * `<cms-status-badge tone="info" class="h-5">` keeps both. There is a test for that rather than a
 * comment asserting it, because it is the property the count badge depends on.
 *
 * The label is projected rather than an input: the call sites already had the text in the template,
 * and an input would have made them build a string to pass in.
 */
export declare class StatusBadgeComponent {
  /** What the value means. */
  readonly tone: import("@angular/core").InputSignal<StatusTone>;
  /** The compact variant, for dense surfaces like a grid cell. */
  readonly small: import("@angular/core").InputSignal<boolean>;
  protected readonly classes: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<StatusBadgeComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<StatusBadgeComponent, "cms-status-badge", never, {
    "tone": {
      "alias": "tone";
      "required": true;
      "isSignal": true;
    };
    "small": {
      "alias": "small";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/** Which way a column is sorted. */
export type SortDirection = 'asc' | 'desc';
/**
 * How a status pill is coloured.
 *
 * Named by *meaning* rather than by colour, so a caller cannot make a rejection green.
 *
 * ✅ **An alias since 2026-09-16, not a second type.** The tone vocabulary and its mapping to
 * `scoular-badge-*` now live in `status-badge.component.ts`, with the grid as one of three consumers.
 * Keeping the name means the ~40 `GridColumn` definitions that reference it did not have to change;
 * keeping it as an *alias* means a tone added there cannot be missing here.
 */
export type GridBadgeTone = StatusTone;
/** A status rendered as a pill instead of plain text. */
export interface GridBadge {
  readonly label: string;
  readonly tone: GridBadgeTone;
}
/**
 * How a whole row is tinted.
 *
 * Separate from a cell badge because it answers a different question: the badge says what this
 * *field* is, the tint says this *contract* needs attention. Tinting is deliberately limited to two
 * tones — a grid where every row is a different colour communicates nothing.
 *
 * ⚠ **Colour is never the only carrier.** A tinted row must also show the badge that explains it,
 * because roughly 1 in 12 men has a colour vision deficiency and a tint alone would be invisible to
 * them (02a §4 accessibility).
 */
export type GridRowTone = 'caution' | 'negative';
/** The active sort. `null` means the caller's own default ordering. */
export interface GridSort<TKey extends string = string> {
  readonly key: TKey;
  readonly direction: SortDirection;
}
/**
 * Whether two sort chains are the same sort.
 *
 * ⚠ **Order-sensitive, deliberately.** A multi-column sort is applied in priority order, so
 * `[zone asc, trader asc]` and `[trader asc, zone asc]` are different orderings of the same rows and
 * must not compare equal — treating them as equal would let the view selector tick a view whose
 * ordering is not the one on screen.
 */
export declare function sameSortChain(left: readonly GridSort[], right: readonly GridSort[]): boolean;
/**
 * How one column is rendered.
 *
 * `format` exists because the grid must not know what a bushel or a basis price is. Alignment is a
 * declared property rather than inferred from the value's type: a quantity and a contract number can
 * both arrive as strings and belong on opposite edges.
 */
export interface GridColumn<TRow> {
  /** Stable identifier — also the sort key sent to the server. */
  readonly key: string;
  /** Column heading. */
  readonly header: string;
  /** Renders the cell. Returning an empty string is how a null becomes a blank cell. */
  readonly format: (row: TRow) => string;
  /**
   * The value to sort on, when the displayed text does not sort correctly.
   *
   * **Sorting on {@link format}'s output is wrong for anything that is not plain text**, and it was
   * wrong here for four columns before this existed:
   *
   * | Column | Displayed | Sorted as text |
   * |---|---|---|
   * | Date | `9/12/25` | `10/…` before `9/…`, because `1` < `9` |
   * | Quantity | `2,500 BU` | the comma and the unit both participate |
   * | Price | `10.0000` | before `6.4275`, same reason |
   * | Ship period | `1 Sep 2026 – …` | by day-of-month, then month name alphabetically |
   *
   * Return an **ISO date** for dates (`yyyy-MM-dd` sorts lexicographically *and* chronologically, so
   * no date parsing is needed) and a **number** for numerics. Omit it for text columns, where the
   * displayed value is the right sort key.
   */
  readonly sortValue?: (row: TRow) => string | number;
  /**
   * The text the grid's search box matches for this column, when it is more than {@link format}.
   * Defaults to {@link format}'s output.
   *
   * 🔴 **Search matches what a column shows unless the column says otherwise**, so a value that is in
   * no column's text cannot be found. The contract grid's Customer column shows the id and is found by
   * the customer's name too (#768, ruled 2026-10-12): without this, moving the name off the cell would
   * have stopped name search with no error. Include what {@link format} shows, or the column stops
   * being found by its own cell. Sorting, filtering and CSV still read {@link format}.
   */
  readonly searchText?: (row: TRow) => string;
  /**
   * Renders the cell as a status pill instead of plain text.
   *
   * Returning `null` falls back to {@link format}, which is what a blank status needs — an empty pill
   * is worse than an empty cell. `format` must still be supplied, because it is what the accessible
   * text and any future CSV export read.
   */
  readonly badge?: (row: TRow) => GridBadge | null;
  /**
   * Numeric and date columns right-align so digits line up down the column, which is what makes a
   * price list scannable. Defaults to `'start'`.
   */
  readonly align?: 'start' | 'end';
  /**
   * What kinds of comparison this column admits in the filter builder. Defaults to `'text'`.
   *
   * 🔴 **Declared rather than inferred, and the alternatives were both wrong.** Guessing from
   * `align === 'end'` conflates numerics with dates, which need different operator *wording* — `gt`
   * is "greater than" on a quantity and "after" on a date — and reading the type off a sample row
   * fails on an empty grid and on a column whose first row is null.
   *
   * ⚠ Setting this to `'number'` or `'date'` is what makes the ordered comparisons read
   * {@link GridColumn.sortValue} instead of the displayed text — which is required, because
   * `2,500 BU` compares by its comma and `9/12/25` puts October before September.
   */
  readonly filterKind?: 'text' | 'number' | 'date';
  /**
   * Whether the header offers sorting. docs/02 §2.1 requires contract date, contract number and
   * commodity "at minimum"; the rest are opt-in as the server learns to sort them (CR-4).
   */
  readonly sortable?: boolean;
  /**
   * Starting width in pixels.
   *
   * A number rather than a Tailwind class because the user can now drag columns wider, and a resize
   * has to produce a value of the same kind it started from. Defaults to
   * {@link DEFAULT_COLUMN_WIDTH}.
   */
  readonly width?: number;
  /**
   * Smallest width a drag may produce. Defaults to {@link MIN_COLUMN_WIDTH}.
   *
   * Worth setting above the default on a column whose header is long: dragging a column narrower
   * than its own heading hides the heading, and then the user cannot tell which column they broke.
   */
  readonly minWidth?: number;
  /**
   * docs/02a §7's priority columns (#759). In the `condensed` and `read-mostly` bands a screen that
   * opts in shows only its priority-1 columns, unless the user has chosen columns themselves.
   *
   * ⚠ **Absent means always shown, the same as 1**, so a grid that never states a priority never loses
   * a column. Only a column that says `2` or higher can be condensed away.
   */
  readonly priority?: number;
  /**
   * Full text for the cell's `title`, when the visible text is not the whole story.
   *
   * Two uses, and both matter now that every row is one line high: a truncated value needs its full
   * form reachable, and a deliberately abbreviated one — the short date — needs its unambiguous form
   * reachable. Defaults to {@link format}'s output, which is what makes ellipsis recoverable without
   * every column having to opt in.
   *
   * ⚠ A `title` is **not** an accessibility substitute. It is invisible to touch, unreachable by
   * keyboard, and inconsistently announced. It is a convenience on top of the text, and anything a
   * user must have has to be in the cell itself or in a detail view.
   */
  readonly tooltip?: (row: TRow) => string;
  /**
   * A component that paints this column's cell instead of the formatted text (F4.3b).
   *
   * Still data: a component type is a value on the column, so the list stays configurable and the
   * grid stays ignorant of what the component does — which is how the Customer cell can open a
   * lookup popover without the grid learning what a customer is. The component receives the row
   * and nothing else.
   *
   * 🔴 {@link format} is still what sorting, filtering, search and CSV read. A component changes
   * what is painted and never what the grid knows about the value, so a column that paints a name
   * and formats an id would sort and export by the id — set both deliberately.
   *
   * ⚠ A cell component sits inside a `<td>` that selects on mousedown and a row that activates on
   * double-click. Anything interactive inside it must stop those events itself, as the action
   * buttons do.
   */
  readonly cell?: Type<GridCellComponent<TRow>>;
}
/** What a {@link GridColumn.cell} component must accept: the row, as a required input. */
export interface GridCellComponent<TRow> {
  readonly row: () => TRow;
}
/** Starting width for a column that does not state one. */
export declare const DEFAULT_COLUMN_WIDTH = 140;
/** Floor for a drag, so a column cannot be dragged out of existence. */
export declare const MIN_COLUMN_WIDTH = 56;
/** The keys a condensed layout keeps: priority 1, or no priority stated (#759). */
export declare const priorityColumnKeys: <TRow>(columns: readonly GridColumn<TRow>[]) => string[];
/** Flips a sort direction. */
export declare const flipDirection: (direction: SortDirection) => SortDirection;
/**
 * Compares two rows on a column, using {@link GridColumn.sortValue} when the column supplies one.
 *
 * Numbers are compared numerically and everything else by `localeCompare`, so a column cannot get a
 * text comparison by accident just because its key happens to be numeric-looking. Lives here rather
 * than in the page component so every caller of the grid sorts the same way — a second consumer
 * re-implementing this is how two screens end up disagreeing about what "sorted by price" means.
 */
export declare function compareRows<TRow>(column: GridColumn<TRow>, left: TRow, right: TRow, direction: SortDirection): number;
/**
 * The next sort chain when a header is activated: **ascending → descending → out of the chain**.
 *
 * **Multi-column (JFrisbie, 2026-08-26).** Each column cycles independently, and activating a column
 * that is not yet sorted *appends* it — so the order in which columns are activated is the sort
 * priority, and no modifier key is needed. Sort by Date descending, then click Price, and you get
 * Date desc then Price asc.
 *
 * **Accumulating rather than replacing is the deliberate choice, and it has a cost worth naming.** The
 * alternative convention is shift-click to append, plain click to replace (Excel, AG Kit). That is
 * safer against surprise — a user who wants "just sort by Price" gets it in one click — but it hides
 * multi-sort behind a modifier that is undiscoverable and unavailable on touch. Accumulating makes it
 * reachable by everyone and composes with the existing three-state cycle, at the price of needing a
 * third click on each unwanted column. The rank badges are what make that legible: without a visible
 * "1, 2, 3" this behaviour would feel like the grid ignoring you.
 *
 * The three-state cycle itself was added 2026-08-25; the paragraphs below are why the third state is
 * safe here.
 *
 * **This reverses an earlier decision, and the reason it is now safe is worth recording rather than
 * deleting.** The two-state version argued there should be no third state because "a grid with no
 * ordering shows rows in whatever order the server happened to return, which reads as a bug". That
 * objection was sound in general and does not apply here: `ContractListProjector` sorts newest-first
 * before paging, with its own comment explaining that docs/02 §2.1 requires a defined starting order.
 * So clearing the sort returns to *newest first*, which is a meaningful default rather than an
 * arbitrary one.
 *
 * **A caller whose source has no defined default should not offer the third state.** That is why this
 * returns `null` rather than silently substituting a fallback key: the grid does not know what the
 * caller's natural order is, and inventing one here would hide the very problem the original comment
 * was about.
 */
export declare function nextSort(current: readonly GridSort[], key: string): readonly GridSort[];
/**
 * The `aria-sort` value for a header, per the WAI-ARIA grid pattern.
 *
 * ⚠ **With a multi-column sort, more than one header carries `aria-sort`.** The ARIA spec describes
 * `aria-sort` as applying to a single column, and there is no standard attribute for "third sort key".
 * Reporting each sorted column is the least-bad reading: the alternative is marking only the primary,
 * which would tell a screen-reader user the grid is sorted by one column when it is sorted by three.
 * The rank is carried separately as visually-hidden text on the header button, so the order is
 * announced rather than merely implied.
 */
export declare function ariaSort(current: readonly GridSort[], key: string): 'ascending' | 'descending' | 'none';
/**
 * A column's 1-based position in the sort chain, or `null` when it is not sorted.
 *
 * Derived from array position rather than stored on the sort, so removing a column cannot leave a gap
 * or a stale number — the thing that would otherwise show "1, 3" after the second key was cleared.
 */
export declare function sortRank(current: readonly GridSort[], key: string): number | null;
/**
 * Compares two rows across the whole sort chain, in priority order.
 *
 * The first column that distinguishes the rows decides; ties fall through to the next. Returning 0
 * when every key ties is what keeps `Array.prototype.sort` stable in modern engines, so equal rows
 * keep the order the server sent them in rather than shuffling.
 *
 * A key naming a column that is not in `columns` is skipped rather than throwing: the sort chain can
 * outlive a column configuration change (docs/02 §2.1 makes columns per-trade-unit configuration), and
 * a stale key should degrade to "not sorted by that" instead of breaking the grid.
 */
export declare function compareBySorts<TRow>(columns: readonly GridColumn<TRow>[], sorts: readonly GridSort[], left: TRow, right: TRow): number;
/**
 * One button in the grid's trailing actions column.
 *
 * **Declarative, matching the rest of this model.** Every other per-cell concern here is a function
 * of the row — {@link GridColumn.format}, `badge`, `tooltip` — so actions are too, rather than the
 * grid accepting a `TemplateRef`. A template input would have been more flexible and would have put
 * a second paradigm into a component whose whole API is "give me functions of a row"; the callers
 * that exist need a label, a handler and a disabled rule.
 *
 * 🔴 **The grid stops event propagation around these buttons, and that is required rather than
 * tidy.** A row is double-click-to-activate and its cells are click-to-select, so without it
 * pressing a button here would also select the cell, and a double-press would navigate away from the
 * screen mid-action. See the template.
 */
export interface GridRowAction<TRow> {
  readonly label: string;
  /** What the menu item does. The grid neither knows nor waits for the outcome. */
  readonly run: (row: TRow) => void;
  /**
   * Refuse the action for this row, with the reason shown as text under the menu item (#816; it was
   * the inline button's title before).
   *
   * Returning a **string** disables and explains; `false` leaves it enabled. A bare boolean was
   * considered and rejected: a disabled button with no stated reason is the thing that makes people
   * wonder, and on a queue where some rows are actionable and some are not, "why not this one" is
   * the first question.
   */
  readonly disabled?: (row: TRow) => string | false;
  /**
   * Leave the action off this row altogether (JFrisbie, 2026-10-23): a read-only contract offers no
   * Edit, rather than an Edit that refuses. Its access key is dead on that row too.
   */
  readonly hidden?: (row: TRow) => boolean;
  /** In flight for this row — the menu item shows it and refuses further presses. */
  readonly busy?: (row: TRow) => boolean;
  /**
   * Which `scoular-btn` variant the inline button wore.
   *
   * ⚠ **No longer rendered** (#816): actions are menu items, and a menu has no primary item. Kept on
   * the type because `@cws/shared-ui` is published and a host's actions still set it.
   */
  readonly tone?: 'primary' | 'secondary' | 'outline';
  /**
   * A single letter that runs this action on the focused row — `E` edit, `C` copy, `A` approve
   * (docs/02a §4.3).
   *
   * ### 🔴 It is shown on the button, and that is not optional
   *
   * This is CTRM's option-code convention — `2`=Update, `4`=Delete, `5`=Display typed against a
   * subfile row — and the CTRM study's finding about it is that an unlabelled key is a key users
   * never learn exists. The grid renders the letter beside the label and sets `aria-keyshortcuts`
   * from the same value, so the printed key, the announced key and the handled key are one string.
   *
   * ⚠ **Bare `C` here is NOT `Ctrl+C`**, which copies the selected *cell*. docs/02a §4.3 warns about
   * exactly this pair: one puts a value on the clipboard, the other duplicates a contract. They are
   * handled on separate branches in `onRowKeydown` and the modifier branch runs first.
   *
   * ⚠ **A disabled action does not fire**, and its letter is still shown with the reason as the
   * button's title — the same treatment the button gets, because a key that silently does nothing is
   * the "enabled does not mean does something" defect in a different costume.
   */
  readonly accessKey?: string;
}
/**
 * **docs/02a §7's three layouts** (#759): desktop-first, for a trading floor.
 *
 * | Band | Width | What changes |
 * |---|---|---|
 * | `full` | 1300 and up | nothing |
 * | `condensed` | 950 to 1300 | grids show their priority columns |
 * | `read-mostly` | under 950 | search, view and approve; contract creation is not optimised (Phase 1) |
 *
 * 🔴 **The width is the CONTAINER's, never the window's** (docs/02a §8, layout neutrality). Under a
 * host, the window says nothing about the space CWS was given; standalone, the two are the same.
 */
export type LayoutBand = 'full' | 'condensed' | 'read-mostly';
/** At or above this width, the full layout. */
export declare const CONDENSED_BELOW_PX = 1300;
/** Below this width, read-mostly. */
export declare const READ_MOSTLY_BELOW_PX = 950;
/** The band for a measured width. Unmeasured (`null`) is `full`: never hide anything on a guess. */
export declare function layoutBandFor(width: number | null): LayoutBand;
/**
 * The band of an element's width, kept current by a `ResizeObserver`. Call in an injection context.
 *
 * ⚠ Pass a BLOCK element (a template ref), not a component host: an Angular host is `display: inline`
 * by default, and an inline box reports a content width of 0, which would read as `read-mostly`.
 * Where `ResizeObserver` does not exist (jsdom) the band stays `full`.
 */
export declare function observeLayoutBand(target: Signal<ElementRef<HTMLElement> | undefined>): Signal<LayoutBand>;
/**
 * One row of the export field picker: a grid column, whether it is included, and where it sits.
 *
 * Order is the array's order — there is deliberately no `position` number. A stored index and an
 * array index are two answers to the same question, and they drift the moment a column is added:
 * the array is the single one.
 */
export interface ExportField {
  /** Matches {@link GridColumn.key}. */
  readonly key: string;
  /** The column heading, carried so the picker can render without the column array. */
  readonly header: string;
  /** Whether this field is written to the file. */
  readonly included: boolean;
}
/** Every column, included, in the order the grid declares them — the default and the reset target. */
export declare function exportFieldsFor<TRow>(columns: readonly GridColumn<TRow>[], visibleKeys?: readonly string[] | null): readonly ExportField[];
/**
 * Brings a held selection back into step with the columns that actually exist.
 *
 * 🔴 **This is the function that stops a selection going stale in silence**, and it is why the
 * picker holds `ExportField[]` rather than a list of `GridColumn`. A selection outlives the column
 * array it was made against — across a deploy that adds a column, and across the reconciliation of
 * two different grids — so the two have to be reconciled rather than assumed equal.
 *
 * Two rules, and the asymmetry is deliberate:
 *
 * - **A key the columns no longer have is dropped.** It cannot be exported; keeping it would put a
 *   row in the picker that does nothing when ticked.
 * - **A column the selection has never seen is appended, INCLUDED.** The alternative — appending it
 *   unticked — means a column added by a future deploy is silently absent from every export made by
 *   anyone who had ever opened this panel, with nothing on screen saying so. Defaulting to included
 *   is the direction that fails loudly: a user sees a column they did not ask for and unticks it.
 *
 * The header is refreshed from the column rather than kept, so renaming a heading in code does not
 * leave the picker showing the old name.
 */
export declare function reconcileExportFields<TRow>(fields: readonly ExportField[], columns: readonly GridColumn<TRow>[]): readonly ExportField[];
/**
 * The columns to write, in the user's order.
 *
 * ⚠ **Returns `GridColumn`s, not headers or keys**, so the export keeps using `column.format`. That
 * is what makes a cell in the file identical to the cell on screen — the property `toCsv`'s own
 * remarks call the whole point of reusing the column definitions. A picker that rebuilt cells from
 * keys would reintroduce the drift this avoided.
 */
export declare function applyExportFields<TRow>(columns: readonly GridColumn<TRow>[], fields: readonly ExportField[]): readonly GridColumn<TRow>[];
/** Flips one field's inclusion, leaving order alone. */
export declare function toggleExportField(fields: readonly ExportField[], key: string): readonly ExportField[];
/** Sets every field's inclusion at once — the Select all / Clear buttons. */
export declare function setAllExportFields(fields: readonly ExportField[], included: boolean): readonly ExportField[];
/**
 * Moves the field at `from` so that it sits at `to`.
 *
 * ⚠ **Removal happens before insertion, and the index is not adjusted afterwards.** Splicing the
 * source out shifts every later element down by one, so inserting at the raw `to` lands in the right
 * place for both directions — the off-by-one that shows up only when dragging *downwards* is what a
 * naive insert-then-remove produces. A test covers both directions for exactly that reason.
 *
 * An out-of-range index returns the list unchanged rather than throwing: this is driven by pointer
 * events, and a drop landing nowhere should do nothing rather than break the panel.
 */
export declare function moveExportField(fields: readonly ExportField[], from: number, to: number): readonly ExportField[];
/** How many fields the file will carry. Zero is a state the caller must refuse to export. */
export declare function includedExportFieldCount(fields: readonly ExportField[]): number;
/**
 * Where the last column choice was kept, for the line under the list (#748).
 *
 * - `account`: on the server, so it follows the user.
 * - `browser`: in this browser only, while the server cannot store it.
 * - `failed`: nowhere; it lasts until the user leaves the page.
 * - `session`: on top of a saved view's layout, for this session only, and deliberately not kept
 *   (#1150). The standing choice is written only when no view layout is applied.
 * - `null`: nothing has been changed yet.
 */
export type GridColumnsKeptIn = 'account' | 'browser' | 'failed' | 'session' | null;
/**
 * **The grid's column menu: show, hide and reorder** (02a C8 "column config", F4.1a, #748).
 *
 * A dropdown around the export's field picker, which already does exactly this list: tick to show,
 * buttons and Alt+↑/↓ to reorder, drag with `select-none` on the list (Known Issue 44). One component
 * for both, so the two lists cannot drift apart in how they behave.
 *
 * It is told which columns the trade unit allows, in the current order with what is shown; it emits
 * the new list and leaves storing it to the screen. `lockedKeys` cannot be hidden (the contract
 * number), and Reset hands the choice back to the trade unit's default.
 */
export declare class GridColumnMenuComponent {
  /** Every column the trade unit allows, in display order, shown ones first. */
  readonly fields: import("@angular/core").InputSignal<readonly ExportField[]>;
  /** Columns that cannot be hidden. */
  readonly lockedKeys: import("@angular/core").InputSignal<readonly string[]>;
  /** Where the last change was kept. */
  readonly keptIn: import("@angular/core").InputSignal<GridColumnsKeptIn>;
  /**
   * Why a `failed` choice has no reference, or the one it has (#803): `sent` is false where nothing
   * was asked of the server (no trade unit chosen, no store), so the line says so.
   */
  readonly failure: import("@angular/core").InputSignal<{
    readonly correlationId: string | null;
    readonly sent: boolean;
  } | null>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  /** The reset button's words. Home resets to the trade unit's columns; a plain grid to all of them. */
  readonly resetLabel: import("@angular/core").InputSignal<string>;
  /** The whole list after a tick or a move. */
  readonly fieldsChange: import("@angular/core").OutputEmitterRef<readonly ExportField[]>;
  /** Hand the choice back to the trade unit. */
  readonly reset: import("@angular/core").OutputEmitterRef<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridColumnMenuComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GridColumnMenuComponent, "cms-grid-column-menu", never, {
    "fields": {
      "alias": "fields";
      "required": true;
      "isSignal": true;
    };
    "lockedKeys": {
      "alias": "lockedKeys";
      "required": false;
      "isSignal": true;
    };
    "keptIn": {
      "alias": "keptIn";
      "required": false;
      "isSignal": true;
    };
    "failure": {
      "alias": "failure";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "resetLabel": {
      "alias": "resetLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "fieldsChange": "fieldsChange";
    "reset": "reset";
  }, never, never, true, never>;
}
/**
 * Where a grid's column choice is kept (JFrisbie, 2026-10-23: every standard grid has the Columns
 * menu). Keyed by the grid's `columnsKey`. `null` from `read` means no choice: every column.
 *
 * Absent, the choice lasts until the user leaves the page. The workspace provides
 * {@link BrowserGridColumnStore}, scoped to the signed-in user.
 */
export interface GridColumnStore {
  read(key: string): readonly string[] | null;
  /** `browser` when kept, `failed` when the browser refused it. `null` clears the choice. */
  write(key: string, columns: readonly string[] | null): 'browser' | 'failed';
}
export declare const GRID_COLUMN_STORE: InjectionToken<GridColumnStore>;
/**
 * `localStorage`, under `cws.gridColumns.<owner>.grid.<key>`. The `grid.` segment keeps these apart
 * from Home's per-trade-unit choice (`cws.gridColumns.<owner>.<tradeUnit>`).
 *
 * No owner (not signed in yet) keeps nothing, so one user's choice is never read back as another's.
 */
export declare class BrowserGridColumnStore implements GridColumnStore {
  private readonly owner;
  constructor(owner: () => string | null);
  read(key: string): readonly string[] | null;
  write(key: string, columns: readonly string[] | null): 'browser' | 'failed';
  private storageKey;
}
/**
 * A composable filter over any column a grid renders.
 *
 * ### Why this exists, and what it replaces
 *
 * The workspace grid offered **four** filters — commodity, customer id, trader initials, market zone
 * — because those are the four `ContractListQuery` accepts. That is a server capability leaking into
 * a user interface: a trader who wants "payment terms is not NET 10" or "quantity over 20,000" could
 * see the column and not filter on it, with the panel's own footer explaining that the rest needed a
 * change request.
 *
 * 🔴 **And the reason the restriction was never necessary is in the server:**
 * `ContractListProjector` fetches the whole status set from CTRM and filters **in process**
 * (`rows.Where(row => Matches(row, query))`, `FilteredInProcess: true`). So a server-side filter
 * parameter does not reduce the CTRM read at all — it only reduces the JSON sent to the browser.
 * Filtering on the client therefore costs CTRM exactly the same work, which is what makes an
 * arbitrary filter over any column affordable without a single CR.
 *
 * ### ⚠ The limit this cannot design away, and it must always be reported
 *
 * The list is **paged by the server**, so a client-side rule can only see the rows that arrived. A
 * filter builder that quietly matched one page and presented the result as the whole set would be
 * this project's cardinal error — a complete-looking answer that is not complete, which is exactly
 * what CR-4 (#31) is about on the CTRM side. So every consumer of this model owes the user two
 * numbers: how many rows matched, and how many were read to find them.
 *
 * Rules that the server *can* apply are still pushed down where it is safe to do so, which keeps the
 * fetched set narrow and makes the client-side pass much more likely to see everything. See
 * `pushdownFor`.
 */
/** What kinds of comparison a column admits. Declared per column; text is the default. */
export type FilterKind = 'text' | 'number' | 'date';
export type FilterOperator = 'contains' | 'notContains' | 'equals' | 'notEquals' | 'startsWith' | 'endsWith' | 'gt' | 'gte' | 'lt' | 'lte' | 'isBlank' | 'isNotBlank';
/** How the rules combine. */
export type FilterCombinator = 'and' | 'or';
export interface FilterRule {
  /** Stable identity for `@for` tracking, so editing one rule does not rebuild the others. */
  readonly id: string;
  /** The {@link GridColumn.key} this rule reads. */
  readonly columnKey: string;
  readonly operator: FilterOperator;
  /** Always a string — the operator and the column's kind decide how it is read. */
  readonly value: string;
}
/**
 * A set of rules and how they combine.
 *
 * ⚠ **Flat, with one combinator — nesting is deliberately not built.** "Commodity is Corn AND (zone
 * is PNW OR zone is CIF)" cannot be expressed here, and that is a scope decision rather than an
 * oversight: nested groups roughly triple the builder's interface and every real filter asked for so
 * far is a single conjunction or a single disjunction. The model would extend to a tree without
 * changing any consumer, because {@link matchesGroup} is already recursive in shape.
 */
/**
 * A rule, or a parenthesised group of them.
 *
 * 🔴 **This is what makes `A AND (B OR C)` expressible** (JFrisbie, 2026-09-10). The model was flat
 * until now, and the builder's docstring said so: *"nesting roughly triples this component; the
 * model would extend to a tree without changing any consumer."* This is that extension.
 *
 * 🔑 **Every existing filter is already a valid tree**, which is why there is no migration. A flat
 * `FilterRule[]` is a `FilterNode[]` whose every element happens to be a rule — so saved filters in
 * `localStorage` and grouped filters in a pasted URL both keep working untouched. That property is
 * worth protecting: it is the reason a shape change to user-writable stored data costs nothing here.
 */
export type FilterNode = FilterRule | FilterGroup;
export interface FilterGroup {
  readonly combinator: FilterCombinator;
  readonly rules: readonly FilterNode[];
}
export declare const EMPTY_FILTER: FilterGroup;
/**
 * Narrows a node to a rule.
 *
 * ⚠ Keys on `columnKey` rather than on the absence of `rules`, because a *malformed* stored value
 * can carry neither — and treating "neither" as a rule would put an object with no operator into
 * `matchesRule`. This way an unrecognised shape is a group with no children, which is inert.
 */
export declare function isRuleNode(node: FilterNode): node is FilterRule;
export declare function isGroupNode(node: FilterNode): node is FilterGroup;
/**
 * Whether a node contributes anything to the filter.
 *
 * A rule is live when it is complete; a group is live when **any descendant** is. An empty group,
 * or one holding only half-built rules, filters nothing — and must not be counted, or the badge and
 * the "Custom view" label would announce a filter the grid is not applying.
 */
export declare function isLive(node: FilterNode): boolean;
/** The operators each kind of column admits, in the order a picker should offer them. */
export declare const OPERATORS_BY_KIND: Readonly<Record<FilterKind, readonly FilterOperator[]>>;
/**
 * Wording for each operator, by kind — because the same comparison reads differently.
 *
 * `gt` is "after" on a date and "greater than" on a number. One label for both would make one of
 * them wrong, and a filter whose operator reads wrongly is a filter people mistrust.
 */
export declare const OPERATOR_LABELS: Readonly<Record<FilterKind, Readonly<Record<FilterOperator, string>>>>;
export declare function needsValue(operator: FilterOperator): boolean;
export declare function operatorsFor(kind: FilterKind): readonly FilterOperator[];
export declare function operatorLabel(kind: FilterKind, operator: FilterOperator): string;
/**
 * Whether a row satisfies a filter.
 *
 * 🔴 **An empty rule set matches everything, and that is load-bearing.** "No filter" and "a filter
 * nothing matches" are different questions, and one empty value cannot answer both — the same defect
 * that once rendered all 111 fields on the Remarks tab because `[]` was read as "not filtering". A
 * caller that wants nothing shown must not pass an empty group.
 *
 * ⚠ **An incomplete rule is skipped rather than treated as unsatisfied.** A rule being typed has an
 * empty value for a keystroke or two; failing it would blank the grid mid-edit and read as "no
 * matches" when the user has not finished asking the question.
 */
export declare function matchesGroup<TRow>(row: TRow, columns: readonly GridColumn<TRow>[], group: FilterGroup): boolean;
/** A rule with no column, or one needing a value and lacking one, is still being written. */
export declare function isComplete(rule: FilterRule): boolean;
/**
 * Free-text search across **every column the grid renders**.
 *
 * Replaces a server-side `search` that covered three fields. ⚠ That is a widening rather than a
 * like-for-like move: the server's version narrowed before paging, so it could see rows this cannot.
 * Consumers report the counts for exactly that reason.
 */
export declare function matchesSearch<TRow>(row: TRow, columns: readonly GridColumn<TRow>[], term: string): boolean;
/** A one-line summary, for a chip or a saved filter's description. */
export declare function describeGroup<TRow>(columns: readonly GridColumn<TRow>[], group: FilterGroup): string;
/**
 * Counts the rules that are actually filtering, across the whole tree.
 *
 * ⚠ **Counts RULES, not nodes.** The badge answers "how many conditions are narrowing this grid",
 * and a group is not a condition — reporting `(A OR B)` as one would make a two-rule filter read as
 * one, which is the number people check against the chips they can see.
 */
export declare function activeRuleCount(group: FilterGroup): number;
/**
 * Whether two groups filter identically.
 *
 * 🔴 **Ignores `id`, and that is the whole reason this exists rather than a `JSON.stringify`
 * comparison.** `FilterRule.id` is minted per rule for `@for` tracking, so a group restored from a
 * saved filter or from the URL has different ids than the one that produced it while filtering the
 * grid exactly the same. Comparing serialised objects answers "is this the same object graph",
 * which is never the question anyone has.
 *
 * ⚠ Also ignores **incomplete** rules — a half-built rule in the editor filters nothing, so a view
 * with one is still the view it claims to be. Without that, opening the editor row would make the
 * selector drop the saved view's name the moment a column was picked.
 *
 * Used by the view selector to decide which saved filter is active, which is what lets the applied
 * view be *derived* from the current filter rather than tracked as a second copy of it.
 */
export declare function sameGroup(left: FilterGroup, right: FilterGroup): boolean;
/**
 * Where a node sits in the tree — child indices from the root down. `[2]` is the third top-level
 * node; `[2, 0]` is the first child of that group.
 *
 * 🔑 **Paths rather than ids on groups.** Rules already carry an `id` for template tracking, and
 * giving groups one too would mean minting and threading identity through every tree operation for
 * no gain: a drag knows *where* it started and *where* it landed, which is exactly a path. It also
 * left `FilterGroup` unchanged, so every stored filter stayed valid.
 *
 * ⚠ A path is only valid against the tree it was read from. Any operation that moves a node
 * invalidates every path after it, which is why {@link moveNode} resolves both ends before it
 * mutates anything.
 */
export type FilterPath = readonly number[];
export declare function nodeAt(group: FilterGroup, path: FilterPath): FilterNode | null;
/**
 * Removes the node at `path`. Pure, and **not** normalised — the caller decides, because a removal
 * mid-drag is followed by an insert and collapsing in between would invalidate the second path.
 */
export declare function removeAt(group: FilterGroup, path: FilterPath): FilterGroup;
/**
 * Replaces the rule with `id`, wherever it sits in the tree.
 *
 * ⚠ Searches the whole tree rather than the top level. A rule picked up for editing may live inside
 * a group, and replacing it by index at the root would either miss it or overwrite a sibling.
 */
export declare function replaceRuleById(group: FilterGroup, rule: FilterRule): FilterGroup;
/**
 * Collapses the shapes a drag can leave behind.
 *
 * 🔴 **Required, not tidying.** Dragging the second-to-last chip out of a group leaves a group of
 * one — which renders as pointless parentheses around a single rule and, worse, carries a
 * combinator that governs nothing. Dragging the last one out leaves an empty group: brackets around
 * nothing, which reads as a filter that is doing something invisible.
 *
 * So: a group of one becomes its child, a group of none disappears, and both rules run bottom-up so
 * a collapse can cascade.
 */
export declare function normaliseGroup(group: FilterGroup): FilterGroup;
/** Flips the combinator of the group at `path` — the root when the path is empty. */
export declare function toggleCombinatorAt(group: FilterGroup, path: FilterPath): FilterGroup;
/**
 * What the pointer is over during a chip drag, and how a drop there would read.
 *
 * ⚠ `'ungroup'` carries an empty path deliberately: the ungroup zone is not a node, it is the one
 * target whose meaning comes from the chip being *dragged* rather than from what is underneath.
 */
export interface DropTarget {
  readonly path: FilterPath;
  readonly mode: 'onto' | 'before' | 'ungroup';
}
/** How a drop should be interpreted. */
export type DropMode =
/** Onto a node: pair with a rule, or join an existing group. */
'onto' |
/** Into the gap before a node: move without grouping. */
'before';
/**
 * Moves the node at `from` to `to`.
 *
 * `onto` a **rule** pairs the two in a new group; `onto` a **group** appends to it; `before` moves
 * without grouping. The result is always normalised, so no caller has to remember to.
 *
 * 🔴 **A node cannot be dropped inside itself**, and that guard is what stops a group being made
 * its own descendant — which would detach it from the tree and lose every rule in it. Checked by
 * prefix, because `[1]` is an ancestor of `[1, 0]`.
 */
export declare function moveNode(group: FilterGroup, from: FilterPath, to: FilterPath, mode: DropMode): FilterGroup;
/**
 * Lifts the node at `path` out of the group it sits in, landing it immediately after that group.
 *
 * 🔴 **This is the ungrouping gesture, and the tree could not express it before.** Every drop target
 * is another *node*, so on a filter whose chips are all inside one set of parentheses there was
 * nowhere to aim: no chip sat outside the group to drop before. The row looked permanently grouped.
 *
 * ⚠ **It lands after its former group rather than at the end of the row**, which is the difference
 * between a move you can predict and one you have to go looking for. `(A OR B OR C)` with C pulled
 * out reads `(A OR B) and C` — the chip stays where the eye left it.
 *
 * Normalised on the way out, so pulling the second-to-last rule out collapses the parentheses around
 * the one left behind rather than leaving a group of one.
 */
export declare function ungroupAt(group: FilterGroup, path: FilterPath): FilterGroup;
/**
 * Groups two nodes explicitly — the keyboard path's equivalent of dropping one chip on another.
 *
 * Shares {@link moveNode}, deliberately: two ways to group that did not share an implementation
 * would be two sets of edge cases, and the interesting ones here (normalisation, the
 * cannot-contain-itself guard, the new group's combinator) are exactly the ones nobody re-derives
 * correctly the second time.
 */
export declare function groupNodes(group: FilterGroup, first: FilterPath, second: FilterPath): FilterGroup;
/**
 * Filters a user has named and kept.
 *
 * ### 🔴 Stored per browser, NOT per user account — and that limit is real
 *
 * The default implementation is `localStorage`. There is no API for this: the config database holds
 * `FormConfigurations`, `FormConfigurationAudits` and `AuditEntries`, and nothing else, and no
 * endpoint publishes a per-user preference of any kind.
 *
 * So a saved filter **does not follow the user to another machine or another browser profile**, and
 * it is lost if site data is cleared. That is stated on screen rather than left to be discovered,
 * because a filter someone spent a minute building and named is something they will expect to find
 * again — and finding it missing on a second machine reads as the feature being broken.
 *
 * ⚠ **Keyed by the signed-in user anyway.** Two people sharing a workstation profile is unusual but
 * not impossible, and one inheriting the other's saved filters would be confusing at best. The key
 * is the sign-in name the shell already knows.
 *
 * 🔑 **The seam is the point.** When a preferences endpoint exists this becomes a one-line provider
 * swap in `app.config.ts`, exactly as the approval action source is arranged. Per C-13 the server
 * copy should key on the token's `oid` — immutable — and carry the sign-in name only for display;
 * keying a stored row on a UPN is how permission rows get orphaned when someone's name changes.
 */
export interface SavedFilter {
  /** Stable id, so renaming does not orphan it. */
  readonly id: string;
  readonly name: string;
  readonly group: FilterGroup;
  /** Which grid it belongs to — a workspace filter has no meaning on the approvals queue. */
  readonly scope: string;
  /**
   * The sort chain to restore with the filter, or `undefined` to leave the current sort alone.
   *
   * 🔴 **`undefined` and `[]` mean different things, and conflating them is the trap.** A saved
   * filter with `undefined` was saved *without* its sorting and must not touch it; one with `[]` was
   * saved while the grid was unsorted and restoring it means **clearing** the sort back to the
   * server's own ordering. Reading an empty array as "nothing to restore" would make an unsorted
   * view silently inherit whatever sort happened to be applied when it was selected.
   *
   * Same class as the `visibleSections` defect this library already fixed: an absent value and a
   * value that matches nothing are different questions, and one empty value cannot answer both.
   */
  readonly sort?: readonly GridSort[];
  /**
   * The column layout to apply with the view, for the session (#1150), or `undefined` to leave the
   * grid's columns alone.
   *
   * 🔑 **Absent is the legacy shape, and it is the safe one.** Every view saved before #1150 carries
   * no `columns`, and selecting it must not touch the layout. A stored layout that is malformed is
   * read as absent rather than dropping the view (see {@link columnsOf}).
   */
  readonly columns?: SavedViewColumns;
}
/**
 * **A saved view's column layout** (#1150): every column in display order, and which of them are
 * hidden.
 *
 * ⚠ `hidden` is explicit rather than "whatever `order` leaves out", so a column the view never knew
 * about (added to the grid, or newly allowed by the trade unit) shows rather than vanishing. The keys
 * are not validated here: an unknown key is dropped where the layout is applied, which is the only
 * place that knows the grid's columns.
 */
export interface SavedViewColumns {
  readonly order: readonly string[];
  readonly hidden: readonly string[];
}
/**
 * The grid's column layout, as the save dialog offers it (#1150): what the grid shows now, and
 * whether that is the grid's default (Home: the trade unit's column set with no choice of the
 * person's; a `GridColumnChoice` grid: every column, in definition order).
 */
export interface SavedViewColumnLayout {
  readonly current: SavedViewColumns;
  readonly isDefault: boolean;
}
/**
 * The keys a saved layout shows, out of `allowed` (#1150): the layout's order without its hidden
 * keys, then every allowed key the layout never mentions, in `allowed` order.
 *
 * 🔑 One rule for every grid, so Home and the `GridColumnChoice` grids cannot disagree about what a
 * view shows. An unknown key is dropped and the rest kept. A must-show column is NOT handled here:
 * each caller pins its own, after this.
 *
 * ⚠ A column the layout never mentions shows rather than hides. That is why a layout records
 * `hidden` and not only what it shows: a column added since the view was saved was never hidden by
 * anyone.
 */
export declare function savedViewShownKeys(allowed: readonly string[], layout: SavedViewColumns): string[];
/** A column menu's list read as a layout: every key in order, and the unticked ones as hidden. */
export declare function savedViewColumnsOf(fields: readonly {
  readonly key: string;
  readonly included: boolean;
}[]): SavedViewColumns;
export interface SavedFilterStore {
  /** Everything saved for the current user in a scope, in the order it should be listed. */
  list(scope: string): readonly SavedFilter[];
  /**
   * Adds or replaces by name within the scope, and returns what was stored.
   *
   * Pass `sort` to save the sorting along with the rules; omit it to save the rules alone. Pass
   * `columns` to save the column layout too (#1150); omit it and the view leaves the layout alone.
   */
  save(scope: string, name: string, group: FilterGroup, sort?: readonly GridSort[], columns?: SavedViewColumns): SavedFilter;
  remove(scope: string, id: string): void;
  /**
   * The filter to apply on arrival, or `null` for none. Per user, per scope.
   */
  defaultId(scope: string): string | null;
  /** Marks one saved filter as the default, or clears it with `null`. */
  setDefault(scope: string, id: string | null): void;
  /**
   * Bumped whenever the set changes, so a component can react without polling.
   *
   * 🔴 **Must read a signal.** Consumers call this inside a `computed` to re-list after a save or a
   * delete; a plain counter satisfies the type and produces **no reactivity at all**, so the panel
   * would save successfully and never show the result. A test double got this wrong and the list
   * simply did not update — the type cannot express the requirement, so it is stated here.
   */
  readonly revision: () => number;
}
export declare const SAVED_FILTER_STORE: InjectionToken<SavedFilterStore>;
/** Who the filters belong to. Supplied by the shell, which is the only place identity lives. */
export declare const SAVED_FILTER_OWNER: InjectionToken<() => string>;
/**
 * `localStorage`-backed, keyed by owner and scope.
 *
 * ⚠ **Every read is guarded and every failure is swallowed to an empty list.** `localStorage` throws
 * in more situations than people expect — disabled site data, private-browsing quota, a corrupt
 * value from an older shape of this type — and a filter panel that threw on open would take the
 * whole grid down with it. A saved filter is a convenience; losing one must never cost the screen.
 */
export declare class LocalSavedFilterStore implements SavedFilterStore {
  private readonly changed;
  readonly revision: () => number;
  /**
   * Who the filters belong to.
   *
   * ⚠ Injected **optionally**, defaulting to a shared key. The shell provides
   * {@link SAVED_FILTER_OWNER} from the signed-in account; a test or an embedded host that does not
   * gets one bucket rather than a failed injection — losing per-user partitioning is a far smaller
   * problem than a filter panel that cannot be constructed.
   */
  private readonly owner;
  /** #889: where a refused write is reported, so it is said rather than swallowed. */
  private readonly refusals;
  list(scope: string): readonly SavedFilter[];
  save(scope: string, name: string, group: FilterGroup, sort?: readonly GridSort[], columns?: SavedViewColumns): SavedFilter;
  remove(scope: string, id: string): void;
  defaultId(scope: string): string | null;
  setDefault(scope: string, id: string | null): void;
  private key;
  /**
   * A separate key rather than an `isDefault` flag on each entry.
   *
   * 🔑 The flag admits a state the concept does not: **two defaults**. Every reader would then have
   * to pick one, and "the first with the flag" is an arbitrary answer that two components could
   * disagree about. One key holds one id, so the invariant is structural instead of enforced.
   */
  private defaultKey;
  private read;
  private write;
  static ɵfac: i0.ɵɵFactoryDeclaration<LocalSavedFilterStore, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * The grid screens that save filters, and the key each one stores under.
 *
 * 🔴 **Declared in one place because a scope is what keeps two screens' views apart, and a collision
 * is silent.** `SavedFilterStore.scope` is a plain `string`, so two screens that happened to pass the
 * same literal would share a list — the workspace's "Unpriced corn" would appear on the approvals
 * queue and apply rules against columns that queue does not have. Nothing would throw; the view would
 * simply match nothing, which reads as an empty queue rather than as a mistake.
 *
 * ⚠ The values are also **persistence keys**. Renaming one does not migrate anything: every view a
 * user saved under the old name becomes unreachable, with no error and no empty state to explain it.
 * Add a scope freely; do not rename one without deciding what happens to what is already stored.
 */
export declare const SAVED_FILTER_SCOPES: {
  /** The contract workspace. */
  readonly contracts: "contracts";
  /** The trader approval queue. */
  readonly approvals: "approvals";
  /** The unpriced-contract queue. */
  readonly pricing: "pricing";
  /** The pricing approval queue — a different grid from {@link SAVED_FILTER_SCOPES.approvals}. */
  readonly pricingApprovals: "pricing-approvals";
};
export type SavedFilterScope = (typeof SAVED_FILTER_SCOPES)[keyof typeof SAVED_FILTER_SCOPES];
/**
 * **One grid's column choice: which columns it shows, in what order** (JFrisbie, 2026-10-23: every
 * standard grid has the Columns menu). `columns` stays the full list; {@link shown} is what to draw.
 *
 * The grid builds one for its own menu. A screen with a toolbar builds one with
 * {@link gridColumnChoice}, so the menu sits in the toolbar beside Export as Home's does, and passes
 * {@link shown} to the grid with the grid's own menu turned off.
 */
export declare class GridColumnChoice<TRow> {
  private readonly columns;
  private readonly key;
  readonly locked: Signal<readonly string[]>;
  private readonly store;
  /** The user's choice: shown keys in order, or `null` for every column. Re-read when the key changes. */
  private readonly chosen;
  /**
   * A saved view's layout, as shown keys, applied for the session (#1150); `null` for none.
   *
   * 🔴 **Never written to the store.** It sits over {@link chosen}, so the baseline view puts the
   * standing choice back with nothing to restore. A Columns-menu change made while it is set changes
   * IT, not the standing choice (JFrisbie, 2026-10-25): the store is written only with no view layout.
   */
  private readonly session;
  /** What is drawn from: the view's layout while one is applied, else the standing choice. */
  private readonly effective;
  /** Where the last change was kept, for the menu's status line. */
  readonly keptIn: import("@angular/core").WritableSignal<GridColumnsKeptIn>;
  /** A choice the browser refused asked nothing of a server, so it has no reference to show (#803). */
  readonly failure: Signal<{
    readonly correlationId: null;
    readonly sent: false;
  } | null>;
  /**
   * What to draw. A stored key no longer in `columns` is dropped, a locked column is always there,
   * and a choice that names nothing left falls back to every column.
   */
  readonly shown: Signal<readonly GridColumn<TRow>[]>;
  /** The shown keys in order, for an export that starts from what is on screen. */
  readonly shownKeys: Signal<string[]>;
  /** What the menu lists: the shown columns in order, then the hidden ones in definition order. */
  readonly fields: Signal<readonly ExportField[]>;
  constructor(columns: Signal<readonly GridColumn<TRow>[]>, key: Signal<string | null>, locked: Signal<readonly string[]>, store: GridColumnStore | null);
  /** The menu's list after a tick or a move. An empty choice is ignored: the menu asks for one column. */
  change(fields: readonly ExportField[]): void;
  /**
   * Every column again, and the stored choice cleared. Under a view's layout (#1150), every column
   * for the session instead, with the standing choice untouched.
   */
  reset(): void;
  /**
   * What the save dialog offers behind "Include column layout" (#1150): the menu's list as a layout,
   * and whether the grid shows its default, which is every column in definition order.
   */
  readonly layout: Signal<SavedViewColumnLayout>;
  /**
   * Applies a chosen view's layout for the session (#1150), as `AppliedView.columns` says:
   * `undefined` leaves the layout alone, `null` (the baseline) returns to the standing choice, and a
   * layout is shown over the standing choice without writing it.
   */
  applyView(columns: SavedViewColumns | null | undefined): void;
  private keep;
}
/**
 * A {@link GridColumnChoice} for a screen's toolbar. Call it in a field initializer (it injects the
 * store). `key` is stable per grid, never its label.
 */
export declare function gridColumnChoice<TRow>(columns: readonly GridColumn<TRow>[], key: string, locked?: readonly string[]): GridColumnChoice<TRow>;
/**
 * **Control pattern C8 — data grid** (docs/02a §3).
 *
 * Presentational and generic: it renders rows it is given and reports interaction. It does not
 * fetch, page, filter or sort — the caller owns all four, because sorting a page of 50 client-side
 * would silently sort the *page* rather than the result set and look like it worked (CR-4, #31).
 *
 * **Keyboard operability is an acceptance criterion, not a nicety** (docs/02a §4.3, docs/05 header).
 * Arrow keys move row focus, Home/End jump to the first/last row, PgUp/PgDn request the previous or
 * next page, and Enter activates the focused row. Row focus is real DOM focus on the `<tr>` rather
 * than a styled "current row" signal, so a screen reader announces the move and browser scrolling
 * follows for free.
 *
 * Row *selection* (Space, `Ctrl+A`, 02a §4.3) is opt-in through {@link selectable}, for bulk pricing
 * approval (E4, #884). The grid reports the key and holds no selection of its own: the page decides
 * what "every row shown" means and what a selection is for.
 *
 * Ships no global styles and no element selector — these libraries render inside foreign host
 * applications under Module Federation (docs/02a §8, 03 §3.4.7).
 */
export declare class DataGridComponent<TRow> {
  /**
   * The uniform cell height, for the template's four cell sites.
   *
   * A field rather than four literals so the header and the body cannot be given different heights
   * by an edit to one of them — see {@link CELL_HEIGHT_CLASS} for why they differed in the first
   * place, and why the fix is a height rather than padding.
   */
  protected readonly cellHeightClass = "cws:h-11";
  /** The rows for the current page, already ordered by the caller. */
  readonly rows: import("@angular/core").InputSignal<readonly TRow[]>;
  /** Column definitions, in display order. */
  readonly columns: import("@angular/core").InputSignal<readonly GridColumn<TRow>[]>;
  /**
   * **The Columns menu: show, hide and reorder** (JFrisbie, 2026-10-23: every standard grid has it).
   * On by default. Home turns it off, because its own menu also knows the trade unit's columns.
   * `columns` stays the full list; what the table draws is {@link shownColumns}.
   */
  readonly columnMenu: import("@angular/core").InputSignal<boolean>;
  /**
   * Where the choice is kept, through {@link GRID_COLUMN_STORE}. One stable key per grid, not its
   * label, so a reworded label does not lose anyone's choice. `null` keeps it for the page only.
   */
  readonly columnsKey: import("@angular/core").InputSignal<string | null>;
  /** Columns the menu cannot hide. */
  readonly lockedColumns: import("@angular/core").InputSignal<readonly string[]>;
  /** The column choice behind the built-in menu. A screen with a toolbar passes its own `shown` instead. */
  protected readonly columnChoice: GridColumnChoice<TRow>;
  /** What the table draws: the whole of `columns` unless the built-in menu has narrowed it. */
  protected readonly shownColumns: import("@angular/core").Signal<readonly GridColumn<TRow>[]>;
  /** Accessible name for the table. Required — an unnamed grid is unnavigable. */
  readonly label: import("@angular/core").InputSignal<string>;
  /**
   * Alternating row backgrounds.
   *
   * ⚠ **Opt-in and default OFF**, because a stripe and a semantic row tint are both a background on
   * the same element and the two can compete.
   *
   * 🔴 **This used to say a grid with a {@link rowTone} "should leave this alone". That is now too
   * strong, and the workspace grid stripes with tones on measured evidence** (2026-09-15). Two things
   * make it safe there, and a grid wanting the same combination should check both rather than copying
   * the binding:
   *
   *   1. **The mechanism cannot lose a tone.** {@link rowClassFor} emits the stripe only when the
   *      tone is empty, so a tinted row is never striped and the two never fight.
   *   2. **The cues must separate by HUE, not by lightness.** Measured composited over white: the
   *      stripe is `rgb(250, 251, 253)`, cool; `negative` is `rgb(254, 248, 246)` and `caution`
   *      `rgb(255, 253, 242)`, both warm. Tone-versus-stripe separation (9 and 12) exceeds
   *      stripe-versus-plain (7), which is what stops a striped row reading as tinted.
   *
   * ⚠ **A tone that was a neutral grey would fail test 2 and must not stripe** — that is the case the
   * original warning was really about, and it is worth keeping in mind when a third tone is added.
   *
   * ⚠ And the tint must not be the *only* carrier of its meaning: on the workspace every tinted row
   * also carries an approval pill, which is what a reader who cannot separate two faint hues relies
   * on.
   * {@link rowClassFor} enforces the precedence rather than trusting the caller.
   */
  readonly striped: import("@angular/core").InputSignal<boolean>;
  /**
   * Buttons in a trailing column, one set per row. Empty means no such column is rendered at all.
   *
   * ⚠ **The column is deliberately outside {@link columns}**, so it takes no part in sorting, in
   * `compareBySorts`, or in the CSV export — none of which have any meaning for a button. Putting it
   * in the column list would have made it sortable by default and exportable as an empty cell.
   */
  readonly actions: import("@angular/core").InputSignal<readonly GridRowAction<TRow>[]>;
  /** Heading for the actions column. */
  readonly actionsHeader: import("@angular/core").InputSignal<string>;
  /**
   * Width of the actions column, in pixels — the grid is `table-fixed`.
   *
   * 96 since #816: the column holds one menu button, and 96 fits the heading "Actions" beside it.
   */
  readonly actionsWidth: import("@angular/core").InputSignal<number>;
  /**
   * Names a row in its menu button's label, "Actions for SC1240000" (#816). Without it the label
   * falls back to the row's position, because fifty buttons all called "Actions" cannot be told apart
   * by a screen reader.
   */
  readonly rowLabel: import("@angular/core").InputSignal<((row: TRow) => string) | undefined>;
  /**
   * What Enter (and double-click) does to a row on this page, for the hint strip: "Open", "Review"
   * (#821). **Absent means the page does not open rows**, so no Enter hint: the grid emits
   * `rowActivate` either way and cannot tell whether anyone is listening.
   */
  readonly activateLabel: import("@angular/core").InputSignal<string | null>;
  /**
   * Space and `Ctrl+A` on a focused row report {@link rowToggle} and {@link selectAll} (#884).
   *
   * ⚠ **Default off, and the browser keeps both keys on every other grid.** Space scrolls the page and
   * `Ctrl+A` selects its text; taking either from a grid with no selection would break the key and
   * put nothing in its place.
   */
  readonly selectable: import("@angular/core").InputSignal<boolean>;
  protected readonly hasActions: import("@angular/core").Signal<boolean>;
  /**
   * The active sort chain, in priority order.
   *
   * An array rather than a single sort: position in it is the priority, shown as a rank badge on the
   * header so a three-column sort is legible rather than mysterious.
   */
  readonly sorts: import("@angular/core").InputSignal<readonly GridSort<string>[]>;
  /**
   * Tints a row that needs attention, or `null` for the normal case.
   *
   * A function rather than a property on the row, so the grid stays ignorant of the domain: it does
   * not know what an unapproved contract is, only that the caller wants this row to stand out.
   */
  readonly rowTone: import("@angular/core").InputSignal<(row: TRow) => GridRowTone | null>;
  /**
   * Identity for `@for` tracking. Defaults to the row object itself, which is correct for immutable
   * page payloads; a caller with mutable rows should supply a stable key.
   */
  readonly trackBy: import("@angular/core").InputSignal<(row: TRow, index: number) => unknown>;
  /**
   * Selects and focuses the row whose {@link trackBy} value equals this, **once**, when it appears.
   *
   * Exists so a caller can restore where the user was — the contract-detail screen's breadcrumb comes
   * back to the grid and the user expects `ArrowDown` to move to the *next* record immediately, which
   * requires real DOM focus on the row they left (JFrisbie, 2026-08-27).
   *
   * **Matched on `trackBy`, not on object identity, and that is the whole reason `trackBy` matters
   * here.** Coming back re-fetches, so the row object for a given contract is a *different* object
   * than the one that was on screen before. A caller wanting this must supply a `trackBy` keyed on
   * something stable — for contracts, the contract number.
   *
   * **Once**, tracked per key: without that guard the effect would drag focus back every time anything
   * re-rendered, which would fight the user's own arrow keys the moment they moved.
   *
   * ⚠ It moves focus into the grid on arrival. That is deliberate *here* — the user asked to arrow
   * straight into the list — but it is why this is an opt-in input and not the default: unrequested
   * focus movement on load is disorienting and would be an accessibility problem on a screen the user
   * did not navigate back to.
   */
  readonly focusKey: import("@angular/core").InputSignal<unknown>;
  /**
   * A header was activated. Carries the *next* sort chain, so the caller does not recompute it.
   *
   * An empty array is the state where the last sorted column was cycled out — fall back to your own
   * ordering. It is a real value in the cycle, not an absence of an event.
   */
  readonly sortChange: import("@angular/core").OutputEmitterRef<readonly GridSort<string>[]>;
  /**
   * Enter, or a **double**-click, on a row.
   *
   * ⚠ **Single click selects a cell instead** (2026-08-27). It used to activate the row, and the two
   * cannot both be true: a click that navigates cannot leave a highlighted cell behind to look at.
   * Enter is unchanged, so the keyboard path never moved.
   */
  readonly rowActivate: import("@angular/core").OutputEmitterRef<TRow>;
  /**
   * A cell's contents were copied to the clipboard.
   *
   * Exists because this component cannot tell the user anything: it ships no toast and 02a puts
   * messaging in the shell. Without this hook a copy is an async side effect with no observable
   * result — including when the clipboard write *fails*, which it does in a non-secure context or
   * when permission is refused. The caller decides whether to confirm it.
   */
  readonly cellCopy: import("@angular/core").OutputEmitterRef<string>;
  /** PgUp/PgDn on the grid. `-1` for the previous page, `1` for the next. */
  readonly pageStep: import("@angular/core").OutputEmitterRef<1 | -1>;
  /** Space on a focused row of a {@link selectable} grid: select the row, or clear it. */
  readonly rowToggle: import("@angular/core").OutputEmitterRef<TRow>;
  /** `Ctrl+A` on a focused row of a {@link selectable} grid: select every row the page shows. */
  readonly selectAll: import("@angular/core").OutputEmitterRef<void>;
  private readonly body;
  /** The {@link focusKey} already honoured, so it is honoured once and does not fight the user. */
  private honouredFocusKey;
  constructor();
  private readonly shortcuts;
  /**
   * The row focus is in, or `null` when focus is outside the body (#821).
   *
   * Set on `focusin` rather than `focus`, so focus on the row's own menu button still counts as the
   * row: that is where Tab goes next, and the row's keys still apply there.
   */
  private readonly focusedRow;
  protected onRowFocusIn(row: TRow): void;
  /**
   * Clears {@link focusedRow} on every `focusout` from the body. Moving between rows, or onto a row's
   * menu button, fires `focusout` then `focusin`, so the next row sets itself straight back; only
   * focus that lands outside the body stays cleared.
   */
  protected onBodyFocusOut(): void;
  /**
   * The keys that work on this row right now, in the order a user reaches for them: open, the
   * action letters, then copying the cell.
   *
   * 🔴 A refused or in-flight action's letter is left out: its press does nothing on this row, and a
   * hint for a key that does nothing is the "enabled does not mean does something" defect again.
   */
  private rowHintsFor;
  protected readonly hasRows: import("@angular/core").Signal<boolean>;
  /**
   * The selected cell — the row it belongs to and its column key — or `null` for none.
   *
   * **Keyed on the row OBJECT rather than its index, and that is a correctness choice.** An index
   * survives a page change and would then point at a different contract: the highlight would stay
   * put while the data under it changed, and `Ctrl+C` would copy a value the user never selected.
   * Holding the row means a new page's rows are different objects, nothing matches, and the selection
   * disappears on its own — no clearing logic to forget.
   *
   * It also means a selection *survives* a re-sort of the same rows, which is the behaviour you want:
   * the cell you were looking at is still the cell you were looking at.
   */
  private readonly selected;
  /** Whether a cell is the selected one. */
  protected isSelected(row: TRow, column: GridColumn<TRow>): boolean;
  /**
   * The height and selection classes for a cell, resolved to one string.
   *
   * A string binding rather than several `[class.x]` bindings because some of the utilities carry a
   * `/` (`bg-scoular-blue/10`, `dark:bg-sky-400/20`) and an opacity slash inside a `[class.…]` key is
   * not something to rely on parsing. `rowToneClassFor` already establishes this pattern for the row
   * tint, for the same reason.
   *
   * ⚠ **{@link CELL_HEIGHT_CLASS} is emitted unconditionally**, and it has to come through here rather
   * than the template's static `class` for the reason {@link headerClassFor} records: this cell's one
   * `[class]` binding is already spent on this method. Keeping the header's height and the body's in
   * the same shape is what stops an edit to one of them separating the two.
   */
  protected cellClassFor(row: TRow, column: GridColumn<TRow>): string;
  /**
   * User-dragged column widths, by column key.
   *
   * Only holds the columns actually resized, so a column the user never touched keeps whatever the
   * caller declared — including when the caller changes it. Storing every width up front would
   * silently pin the defaults on first render.
   *
   * Not persisted. docs/02 §2.1 puts column show/hide and ordering in *user-level configuration*
   * alongside the per-trade-unit column set (F1.3), so width belongs in that store rather than in a
   * second, ad-hoc one that would later have to be migrated out.
   */
  private readonly resized;
  /** The drag in progress: which column, where it started, and how wide it was then. */
  private drag;
  /** Effective width for every column, in display order — drives the `<colgroup>`. */
  protected readonly widths: import("@angular/core").Signal<{
    key: string;
    width: number;
  }[]>;
  protected widthOf(column: GridColumn<TRow>): number;
  /**
   * Starts a column resize.
   *
   * `setPointerCapture` rather than document-level listeners: the pointer keeps reporting to this
   * element even when it leaves the 4px handle, which it does immediately on any real drag. Without
   * it the resize stops the moment the cursor moves off the divider.
   *
   * `stopPropagation` because the handle sits inside a `<th>` whose button sorts the column — a drag
   * that also sorted would make the grid jump under the cursor.
   */
  protected onResizeStart(event: PointerEvent, column: GridColumn<TRow>): void;
  protected onResizeMove(event: PointerEvent, column: GridColumn<TRow>): void;
  protected onResizeEnd(): void;
  /**
   * Keyboard resizing, because a drag handle is unusable without it (02a §4.3).
   *
   * Arrow keys nudge by 16px and Home resets the column to the caller's width. A mouse-only resize
   * would make the feature unavailable to anyone navigating by keyboard, which is an acceptance
   * criterion here rather than a nicety.
   */
  protected onResizeKeydown(event: KeyboardEvent, column: GridColumn<TRow>): void;
  /** The `title` for a cell: the column's own tooltip, or its formatted text. */
  protected titleFor(column: GridColumn<TRow>, row: TRow): string;
  protected ariaSortFor(key: string): 'ascending' | 'descending' | 'none';
  /**
   * The column's 1-based place in the sort chain, or `null`.
   *
   * Returns `null` for a single-column sort even though the rank is technically 1: a lone "1" beside
   * the only sorted column is noise, and the badge exists to disambiguate an *order*.
   */
  protected sortRankFor(key: string): number | null;
  /**
   * Hover, sort-state and height classes for a header cell, resolved to one string.
   *
   * A method rather than two `[class.x]` bindings for the same reason {@link rowClassFor} is one: the
   * sorted and unsorted variants both declare a `hover:bg-*`, so only one may be emitted. See
   * {@link SORTED_HEADER_CLASS}.
   *
   * Keyed on `aria-sort` rather than on `column.sortable`, so a column that *can* be sorted but is not
   * currently in the chain reads as unsorted — which is the whole point of the cue.
   *
   * ⚠ **{@link CELL_HEIGHT_CLASS} rides along here rather than on the template's static `class`**, and
   * so does {@link cellClassFor}'s. Angular permits one `[class]` binding per element and both cells
   * already spend theirs on this method, so the height has to come through it — otherwise the header
   * and body heights end up declared in different places and the next edit separates them.
   */
  protected headerClassFor(column: GridColumn<TRow>): string;
  /** The cell's tone, or `null` when the cell is plain text. */
  protected badgeToneFor(column: GridColumn<TRow>, row: TRow): GridBadgeTone | null;
  /** The pill's text, or `null` when the cell is plain text. */
  protected badgeLabelFor(column: GridColumn<TRow>, row: TRow): string | null;
  /** The tint class for a row's *tone*, or an empty string. */
  protected rowToneClassFor(row: TRow): string;
  /** Whether this row holds the selected cell. */
  private holdsSelection;
  /**
   * Every state class for a row: hover, focus, tone and selection, resolved to one string.
   *
   * **One background class is emitted, never two**, and that is why this is a method rather than several
   * `[class.x]` bindings. The tone tint and the selection tint are both plain `bg-*` on the same element,
   * so with both present the winner would be decided by their order in the compiled stylesheet — which
   * is not something a template should depend on. Choosing here makes it explicit.
   *
   * **Selection wins over tone**, deliberately: knowing where you are is the more urgent signal, and the
   * tone's meaning is not lost — a tinted row always carries the badge that explains it (see
   * {@link GridRowTone}), so the tint was never the only carrier.
   */
  protected rowClassFor(row: TRow, index: number): string;
  protected onHeaderActivate(column: GridColumn<TRow>): void;
  /**
   * Selects a cell.
   *
   * **`mousedown`, not `click`, and the ordering is the whole reason** (JFrisbie noticed the symptom,
   * 2026-08-27). The browser moves focus to the nearest focusable ancestor — the `<tr>` — as the
   * *default action* of `mousedown`, which runs after this listener but well before `click`. On `click`
   * the sequence was therefore: press → browser focuses the row → {@link onRowFocus} finds nothing
   * selected and takes column 0 → release → the real column finally wins. That produced a visible flash
   * of the first cell, and holding the button down parked the highlight there indefinitely.
   *
   * Selecting here puts the right cell in place *before* the focus default action, so `onRowFocus` sees
   * a selection that already belongs to this row and stands down. The intermediate state stops existing
   * rather than being hidden — no flag, no timer, nothing to race.
   *
   * Selecting on press rather than release also matches every spreadsheet, and reads as more responsive.
   *
   * **Every mouse button selects, deliberately.** A `button !== 0` guard was tried and is worse: the
   * press still focuses the row, so `onRowFocus` fills the gap and the selection jumps to *column 0* of
   * the row that was right-clicked — a stranger outcome than either not moving or moving to the cell
   * under the pointer. Pinned by a test.
   *
   * **Focus is still moved explicitly** rather than left to that default action: everything keyboard —
   * `ArrowLeft`/`ArrowRight`, `Ctrl+C` — is handled on the row, so a press that failed to focus it would
   * leave a highlighted cell no key could act on.
   */
  protected onCellMousedown(row: TRow, index: number, column: GridColumn<TRow>): void;
  /**
   * Selects the first column when focus arrives on a row with no selection of its own.
   *
   * **This is what makes Tab land on a cell** (JFrisbie, 2026-08-27): tabbing moves DOM focus to the
   * next `<tr>`, which used to leave a focused row and no selected cell — so there was nothing to
   * `Ctrl+C` and nothing outlined.
   *
   * Guarded on the selection already belonging to *this* row so it cannot clobber a carried column:
   * `focusRow` sets the carried selection **before** focusing precisely so that this handler sees it and
   * stands down. Arrowing down column 5 must stay on column 5.
   */
  protected onRowFocus(row: TRow): void;
  /**
   * Moves the selected cell within the focused row.
   *
   * With nothing selected, the first step selects an end cell rather than doing nothing — otherwise
   * the keyboard user has no way to *begin* selecting, and the whole feature would be mouse-only with
   * a keyboard-only action (`Ctrl+C`) attached to it.
   *
   * Clamped, not wrapped, matching `focusRow`: at the last column, ArrowRight should not jump to the
   * first, which reads as the row changing.
   */
  private stepCell;
  /**
   * Keeps a keyboard-selected cell on screen.
   *
   * The grid wrapper is a horizontal scroll container and **focus stays on the `<tr>`**, so the
   * browser will not scroll a newly selected cell into view by itself — with twelve columns, stepping
   * right would silently select cells nobody can see. Optional call because `scrollIntoView` is not
   * implemented in jsdom.
   */
  private revealSelected;
  /**
   * Copies the selected cell to the clipboard.
   *
   * **The text comes from `column.format(row)`, not from the DOM**, and that is the whole point of
   * "the entirety of the cell's contents": every cell is `truncate`d, so `textContent` would give
   * whatever survived the ellipsis. `format` is also exactly what {@link toCsv} writes, so a copied
   * cell and an exported cell cannot disagree — the class of silent divergence that made the grid's
   * "export all pages" ignore the sort.
   *
   * @returns Whether there was a selection to copy, so the caller can decide about `preventDefault`.
   */
  private copySelected;
  /**
   * Row-level keyboard handling.
   *
   * `preventDefault` only on keys actually consumed, so an unhandled key still reaches the page —
   * otherwise the grid would swallow browser shortcuts and the `/` search key from 02a §6.1.
   */
  protected onRowKeydown(event: KeyboardEvent, row: TRow, index: number): void;
  /**
   * Space and `Ctrl+A` on a selectable grid (#884). Returns whether the key was consumed.
   *
   * 🔴 **Only from the row itself.** A cell can hold a component with its own input, and its keys
   * bubble here: Space typed there must type a space, and `Ctrl+A` must select its text.
   *
   * ⚠ Bare Space and `Ctrl+A` only. `Shift+Space` and `Ctrl+Shift+A` are left alone, so a key this
   * grid does not document never selects anything.
   */
  private onSelectionKey;
  /**
   * Moves DOM focus to a row, clamped to the page, carrying any cell selection with it.
   *
   * Clamped rather than wrapped: at the last row, ArrowDown should not jump to the first one — in a
   * paged grid that reads as "the page changed" when it did not.
   *
   * **`from` is what keeps the selection and the focus coherent.** Without it, moving down would leave
   * the highlighted cell behind in a row that is no longer focused — two competing "you are here"
   * cues, and `Ctrl+C` would then copy from a row the user has moved off. Passing the row being left
   * carries the same *column* to the destination, which is the spreadsheet behaviour people expect.
   * Callers that are setting the selection themselves omit it.
   */
  private focusRow;
  /** Whether an action cannot run on a row right now. The rule is `cms-row-menu`'s, so the two agree. */
  /** The row's actions, without any it hides (a read-only contract's Edit). One list for the menu, keys and hints. */
  protected actionsFor(row: TRow): readonly GridRowAction<TRow>[];
  protected isActionDisabled(action: GridRowAction<TRow>, row: TRow): boolean;
  /** The row's name in its menu button's label: the caller's {@link rowLabel}, or its position. */
  protected rowNameFor(row: TRow, index: number): string;
  /**
   * Keeps a keyboard press on the menu button off the row's own handler.
   *
   * The row treats Enter as "activate" and the arrow keys as "move focus", and the menu button opens
   * on Enter, Space and the arrow keys. Without this, opening the menu would also navigate, or move
   * the focused row out from under it. Stopped rather than cancelled, because the button's own
   * handling is what opens the menu.
   */
  protected onActionKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<DataGridComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DataGridComponent<any>, "cms-data-grid", never, {
    "rows": {
      "alias": "rows";
      "required": true;
      "isSignal": true;
    };
    "columns": {
      "alias": "columns";
      "required": true;
      "isSignal": true;
    };
    "columnMenu": {
      "alias": "columnMenu";
      "required": false;
      "isSignal": true;
    };
    "columnsKey": {
      "alias": "columnsKey";
      "required": false;
      "isSignal": true;
    };
    "lockedColumns": {
      "alias": "lockedColumns";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "striped": {
      "alias": "striped";
      "required": false;
      "isSignal": true;
    };
    "actions": {
      "alias": "actions";
      "required": false;
      "isSignal": true;
    };
    "actionsHeader": {
      "alias": "actionsHeader";
      "required": false;
      "isSignal": true;
    };
    "actionsWidth": {
      "alias": "actionsWidth";
      "required": false;
      "isSignal": true;
    };
    "rowLabel": {
      "alias": "rowLabel";
      "required": false;
      "isSignal": true;
    };
    "activateLabel": {
      "alias": "activateLabel";
      "required": false;
      "isSignal": true;
    };
    "selectable": {
      "alias": "selectable";
      "required": false;
      "isSignal": true;
    };
    "sorts": {
      "alias": "sorts";
      "required": false;
      "isSignal": true;
    };
    "rowTone": {
      "alias": "rowTone";
      "required": false;
      "isSignal": true;
    };
    "trackBy": {
      "alias": "trackBy";
      "required": false;
      "isSignal": true;
    };
    "focusKey": {
      "alias": "focusKey";
      "required": false;
      "isSignal": true;
    };
  }, {
    "sortChange": "sortChange";
    "rowActivate": "rowActivate";
    "cellCopy": "cellCopy";
    "pageStep": "pageStep";
    "rowToggle": "rowToggle";
    "selectAll": "selectAll";
  }, never, never, true, never>;
}
/**
 * **One row's actions behind a ⋯ button** (#816, extracted for #825).
 *
 * The data grid's Actions column renders this, and so do the admin tables, so a row's secondary
 * actions look and behave the same wherever they appear. Built on the CDK menu, which supplies the
 * menu pattern itself: arrow keys between items, Escape returning focus to the button, a click
 * elsewhere closing it, and an overlay positioned against the viewport, so a menu near the bottom of
 * the page opens upwards and a scrolling container cannot clip it.
 *
 * 🔴 **A refused action stays in the menu, disabled, with its reason as TEXT under its label.** An
 * inline button could only carry the reason as a `title`, which touch and most keyboard users never
 * see. `cdkMenuItemDisabled` keeps the item focusable, as the menu pattern asks, and {@link run}
 * checks again, because an action can turn busy while its menu is open and a write sent twice is the
 * failure.
 *
 * ⚠ `templateUrl`, not an inline template: the markup's comments carry backticks, and an inline
 * template is a template literal (Known Issue 37).
 */
export declare class RowMenuComponent<TRow> {
  /** The row the actions act on. */
  readonly row: import("@angular/core").InputSignal<TRow>;
  /** The actions offered, in menu order. */
  readonly actions: import("@angular/core").InputSignal<readonly GridRowAction<TRow>[]>;
  /**
   * The button's accessible name, naming the row: "Actions for SC1240000". Fifty buttons all called
   * "Actions" cannot be told apart by a screen reader.
   */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The refusal reason for an action on this row, or `null` when it is available. */
  protected refusalFor(action: GridRowAction<TRow>): string | null;
  protected isDisabled(action: GridRowAction<TRow>): boolean;
  protected run(action: GridRowAction<TRow>): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RowMenuComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RowMenuComponent<any>, "cms-row-menu", never, {
    "row": {
      "alias": "row";
      "required": true;
      "isSignal": true;
    };
    "actions": {
      "alias": "actions";
      "required": true;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** An action's refusal for a row, or `null` when it is available. */
export declare function actionRefusal<TRow>(action: GridRowAction<TRow>, row: TRow): string | null;
/** Whether an action cannot run on a row right now: refused, or already in flight. */
export declare function isActionUnavailable<TRow>(action: GridRowAction<TRow>, row: TRow): boolean;
/**
 * Builds a CSV from the same column definitions the grid renders.
 *
 * **Reusing `column.format` is the point.** An export that read the raw row would drift from the
 * screen the moment a formatter changed — a quantity exported as `2500` where the grid shows
 * `2,500 BU`, or a date in ISO where the grid shows a short date. What a trader exports has to be
 * what they were looking at, so the formatter is the single source for both.
 *
 * Badge columns export their `format` text rather than the pill's label, which is the same string
 * today and is the right dependency in either case: `format` is the column's textual value and the
 * badge is a presentation of it.
 *
 * ⚠ **This is a client-side interim, and docs/02 §2.3 specifies something else** — "Export CSV
 * (current filter result; direct authenticated stream)", i.e. a server endpoint that streams. That
 * is the better design and it becomes the obviously right one once CR-4 (#31) lands, because the
 * server will then be able to select and stream the filtered set without our fetching it a page at a
 * time. Until then this exports what the client already holds.
 */
export declare function toCsv<TRow>(columns: readonly GridColumn<TRow>[], rows: readonly TRow[]): string;
/**
 * Hands a CSV to the browser as a download.
 *
 * The BOM is required rather than decorative: without it Excel reads the file as the system codepage
 * and mangles every non-ASCII character — an accented customer name arrives as `JosÃ©`. Every other
 * reader tolerates a BOM, so it is the cheap side of the trade.
 *
 * `text/csv` rather than an Excel MIME type. Naming a file `.xlsx` while writing CSV produces a
 * "the file format does not match the extension" warning on open, which looks like corruption. A
 * genuine `.xlsx` needs a workbook writer — a new dependency, which CLAUDE.md gates behind approval
 * and an SBOM entry in the same commit — so this is honest CSV that Excel opens natively.
 */
export declare function downloadCsv(filename: string, csv: string): void;
/**
 * Saves a blob the caller already holds — a stream the server produced (F4.3c) — under a name.
 *
 * Deliberately adds nothing to the bytes: a server stream is saved as served. The BOM that
 * {@link downloadCsv} prepends belongs to the file this side builds, not to one it merely relays.
 */
export declare function downloadBlob(filename: string, blob: Blob): void;
/**
 * Chooses which grid fields an export carries, and in what order.
 *
 * Presentational: it holds no selection of its own and emits a whole new list on every change, so the
 * owning screen keeps the single copy. That is what lets the same panel drive the current-page export
 * and the all-pages export without the two being able to disagree about what was ticked.
 *
 * 🔴 **Drag is the mouse gesture, and it is NOT the only one.** A keyboard path for every gesture is a
 * standing acceptance criterion in this repository (docs/05, cited in CLAUDE.md), and drag-and-drop
 * satisfies none of it — it is unreachable by keyboard, invisible to a screen reader, and awkward on
 * a touch device. Each row therefore carries **Move up / Move down buttons** as well, which are the
 * same operation and are discoverable without being told. `Alt+ArrowUp` / `Alt+ArrowDown` do it from
 * the row itself for anyone who would rather not tab to the buttons.
 *
 * ⚠ **Alt is what keeps the arrow keys usable.** A bare ArrowUp/ArrowDown on a focusable row is how a
 * user scrolls a long list, and this list is 24 rows on the workspace grid — binding the bare arrows
 * to reordering would take scrolling away and move a field every time someone tried to look further
 * down.
 *
 * Native HTML5 drag rather than a drag library, matching the filter chips: a CDK dependency is a new
 * package, an SBOM row and an approval, for a gesture the platform already has.
 */
export declare class ExportFieldsComponent {
  /** The current selection, in order. Owned by the caller. */
  readonly fields: import("@angular/core").InputSignal<readonly ExportField[]>;
  /** A whole new list, whenever anything changes. */
  readonly fieldsChange: import("@angular/core").OutputEmitterRef<readonly ExportField[]>;
  /**
   * Keys that are always included: their checkbox is disabled and Clear keeps them (#748, the home
   * grid's contract number). Empty for the export, where every field may be dropped.
   */
  readonly lockedKeys: import("@angular/core").InputSignal<readonly string[]>;
  /** What the list holds, for the count line ("3 of 11 fields"). */
  readonly noun: import("@angular/core").InputSignal<string>;
  /** The list's accessible name. */
  readonly listLabel: import("@angular/core").InputSignal<string>;
  /** Shown when nothing is ticked. */
  readonly emptyMessage: import("@angular/core").InputSignal<string>;
  protected isLocked(key: string): boolean;
  /** The index being dragged, or null. Drives the row's own "lifted" styling. */
  protected readonly draggingIndex: import("@angular/core").WritableSignal<number | null>;
  /** The index the pointer is currently over, so the drop position is visible before releasing. */
  protected readonly dropIndex: import("@angular/core").WritableSignal<number | null>;
  protected readonly includedCount: import("@angular/core").Signal<number>;
  protected readonly total: import("@angular/core").Signal<number>;
  /**
   * Whether the export can proceed.
   *
   * 🔴 A zero-field export is refused rather than produced. `toCsv` with no columns writes a file
   * containing one empty header line and one empty line per row — a plausible-looking download that
   * is entirely useless, and the user would reasonably read it as the data being missing rather than
   * as their own selection. Refusing at the button is the only place it can be explained.
   */
  protected readonly canExport: import("@angular/core").Signal<boolean>;
  protected onToggle(key: string): void;
  protected onSelectAll(): void;
  protected onClearAll(): void;
  protected onMove(from: number, to: number): void;
  protected onDragStart(index: number, event: DragEvent): void;
  /**
   * Marks the row under the pointer as the landing place.
   *
   * ⚠ **`preventDefault` is what makes the element a drop target at all.** Without it the browser's
   * default handling refuses the drop and `drop` never fires — the single most common reason a
   * hand-rolled drag "does nothing", and it looks like a broken event binding rather than a missing
   * default-prevention.
   */
  protected onDragOver(index: number, event: DragEvent): void;
  protected onDrop(index: number, event: DragEvent): void;
  protected onDragEnd(): void;
  /**
   * `Alt+ArrowUp` / `Alt+ArrowDown` reorder from the row itself.
   *
   * ⚠ `preventDefault` only once the combination matches, so an unmodified arrow still scrolls the
   * list — see the class remarks. Returning early rather than swallowing every key also leaves Tab,
   * Escape and Space doing what the browser and the dropdown already do with them.
   */
  protected onKeydown(index: number, event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ExportFieldsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ExportFieldsComponent, "cms-export-fields", never, {
    "fields": {
      "alias": "fields";
      "required": true;
      "isSignal": true;
    };
    "lockedKeys": {
      "alias": "lockedKeys";
      "required": false;
      "isSignal": true;
    };
    "noun": {
      "alias": "noun";
      "required": false;
      "isSignal": true;
    };
    "listLabel": {
      "alias": "listLabel";
      "required": false;
      "isSignal": true;
    };
    "emptyMessage": {
      "alias": "emptyMessage";
      "required": false;
      "isSignal": true;
    };
  }, {
    "fieldsChange": "fieldsChange";
  }, never, never, true, never>;
}
/**
 * `« ‹ Page 1 of 2 › »` — first, previous, position, next, last.
 *
 * **One component rendered twice**, above and below the grid, rather than the markup duplicated. Two
 * copies of a control drift: one gains a disabled state or an aria-label the other does not, and the
 * pair stops behaving identically for exactly the users least able to notice.
 *
 * Styled with `scoular-btn scoular-btn-secondary` rather than the design system's own
 * `scoular-pagination-item`, deliberately. That class is `h-9` (36px) while a `scoular-btn` is 38px
 * — `py-2` plus a `text-sm` line box plus a 1px border — and the requirement is that these line up
 * with the Export data button on the same row.
 *
 * ✅ **Updated 2026-09-16: a utility CAN override the height now, and this still does not use one.**
 * The design system used to compile as *unlayered* CSS against Tailwind's `@layer utilities`, so
 * unlayered always won and a utility was not available at all; `components.css` now sits in
 * `@layer components` (see the note at the top of the shell's `styles.css`). What has not changed is
 * the better argument: matching by wearing the same class as the thing it must line up with is the
 * only version that stays true if the design system changes its padding. A hard-coded `h-[38px]`
 * would be correct today and silently wrong after a package bump.
 *
 * Rendered even when there is a single page, with every button disabled. The alternative — hiding it
 * — makes the toolbar jump as filters change the result size, and "Page 1 of 1" is genuinely useful
 * information rather than noise.
 */
export declare class PagerComponent {
  /** The current page, 1-based. */
  readonly page: import("@angular/core").InputSignal<number>;
  /** Total pages. At least 1, even for an empty result — "Page 1 of 0" reads as a bug. */
  readonly totalPages: import("@angular/core").InputSignal<number>;
  /**
   * Which instance this is, for the nav's accessible name.
   *
   * Required rather than defaulted: two unnamed pagination landmarks on one page is the failure this
   * exists to avoid, so a caller adding a third copy has to say what it is.
   */
  readonly position: import("@angular/core").InputSignal<"bottom" | "top">;
  /**
   * The page to go to, absolute rather than a step.
   *
   * A step cannot express "first" or "last" without the pager knowing the total, and it already does
   * — so emitting the destination keeps the arithmetic in one place instead of splitting it across
   * the component and its caller.
   */
  readonly goTo: import("@angular/core").OutputEmitterRef<number>;
  protected readonly canPrevious: import("@angular/core").Signal<boolean>;
  protected readonly canNext: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PagerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PagerComponent, "cms-pager", never, {
    "page": {
      "alias": "page";
      "required": true;
      "isSignal": true;
    };
    "totalPages": {
      "alias": "totalPages";
      "required": true;
      "isSignal": true;
    };
    "position": {
      "alias": "position";
      "required": true;
      "isSignal": true;
    };
  }, {
    "goTo": "goTo";
  }, never, never, true, never>;
}
/**
 * What a server export said when asked (F4.3c).
 *
 * - `server` — it wrote the file; nothing is built here.
 * - `skipped` — it stood aside, with the reason the note will carry: the server cannot reproduce
 *   the screen (a local filter or search), or it is not available (the route has not landed, the
 *   network, the server). **The in-screen export runs instead.**
 * - `failed` — it refused. **Nothing runs instead**: a file built here would not be the one the
 *   server refused to produce.
 */
export type ServerExportOutcome = {
  readonly ran: 'server';
} | {
  readonly ran: 'skipped';
  readonly reason: string;
} | {
  readonly ran: 'failed';
  readonly message: string;
};
/**
 * The server seam: asked for the `all` scope only, with the included column keys in picker order.
 *
 * A function rather than a service so this control stays ignorant of HTTP and of what a contract
 * is — the same reason `allRows` is a function.
 */
export type ServerExport = (scope: 'page' | 'all', fields: readonly string[]) => Promise<ServerExportOutcome>;
/**
 * Which path wrote the file, so the screen can say so. `reason` is set only when the in-screen
 * export ran *because* the server stood aside; an in-screen export chosen outright carries `null`.
 */
export interface ExportOutcome {
  readonly ran: 'server' | 'screen';
  readonly scope: 'page' | 'all';
  readonly rows: number;
  readonly reason: string | null;
}
/**
 * **The Export data control on a grid toolbar** — scope first, then fields, then the download.
 *
 * ### 🔴 Why this is a component rather than the workspace's markup copied onto three screens
 *
 * This started as ~120 lines of template plus ~90 lines of component on the workspace alone, and
 * every grid in the application is meant to carry it (JFrisbie, 2026-09-17). Four copies would have
 * drifted on the details that are invisible when wrong rather than on the obvious ones — the
 * `text-left` that stops a wrapped subtext centring its second line, the `role="group"` that must
 * NOT become `role="menu"` once the field picker renders checkboxes, the reset-on-toggle that is the
 * only thing making the reopened state reliable. Each of those was a separate fix on the workspace
 * and none of them would have been reproduced from reading the markup.
 *
 * ### 🔴 The two scopes differ by ORDERS OF MAGNITUDE on one screen and not at all on the others
 *
 * On the workspace, "all pages" is one CTRM read per 200 rows; on the approval and pricing queues the
 * whole matched set is already in memory, because those screens fetch one large page and slice it
 * locally. That is why {@link allRows} is a **resolver** rather than an array input: the caller
 * decides what "everything" costs, and a screen that already holds it returns it without a request.
 *
 * ⚠ **The scope step is still shown on those screens even though both arms are cheap there.** The
 * choice is not about cost alone — it is "what I am looking at" versus "everything the filter
 * matched", and on a paged grid those are different files. Hiding it where it happens to be cheap
 * would make the control mean something different on different screens, which is the whole failure
 * this component exists to prevent.
 *
 * ### ⚠ A failed export must not download a short file
 *
 * {@link allRows} returns `null` to mean *could not complete*, and nothing is written when it does.
 * Partial data exported as though it were complete is worse than no export: a trader reconciling
 * against a short spreadsheet has no way to know rows are missing. The message goes out on
 * {@link failed} so the screen can render it beside its own grid rather than inside a panel that has
 * already closed.
 */
export declare class GridExportComponent<TRow> {
  /** The grid's own columns, so an exported cell is formatted exactly as the screen formats it. */
  readonly columns: import("@angular/core").InputSignal<readonly GridColumn<TRow>[]>;
  /**
   * The keys the grid is SHOWING, in display order, or `null` when it shows every column (F4.1a, #748).
   *
   * docs/02 §8: the export honours the visible columns. Given, the field step starts with exactly
   * these ticked and the rest offered unticked; absent, every column is ticked as before.
   */
  readonly visibleKeys: import("@angular/core").InputSignal<readonly string[] | null>;
  /**
   * The rows on screen right now — the "this page" scope.
   *
   * ⚠ **The rows as DISPLAYED, sort included**, not the page's own array. Exporting a different
   * order from the one being looked at is the defect already fixed once on the workspace, where a
   * trader who sorted by price descending got a newest-first file.
   */
  readonly pageRows: import("@angular/core").InputSignal<readonly TRow[]>;
  /** How many rows the current filter matches in total, for the "all pages" label. */
  readonly totalCount: import("@angular/core").InputSignal<number>;
  /**
   * Resolves every row behind the current filter, or `null` if it could not.
   *
   * A screen holding the whole matched set returns it immediately; the workspace walks the server a
   * page at a time. Declared as a resolver rather than an array so the expensive case is only paid
   * for when the user picks it.
   */
  readonly allRows: import("@angular/core").InputSignal<() => Promise<readonly TRow[] | null>>;
  /**
   * Names the download, given the scope it was run at.
   *
   * ⚠ A function rather than a base string, because the two scopes legitimately want different
   * names — the workspace puts the page number in the per-page file so two exports of one trade unit
   * are told apart, and there is no page number to put in the all-pages one.
   *
   * ⚠ Return something that names the *scope of the data* — `contracts-0210-open-page-1` rather than
   * `contracts`. A downloads folder holding four exports of different trade units is the normal
   * case, and `contracts.csv (3)` says nothing about which is which. No timestamp: the filesystem
   * already has one, and a name that changes every second stops the browser offering to replace the
   * previous export.
   */
  readonly filename: import("@angular/core").InputSignal<(scope: "page" | "all") => string>;
  /** Refuses the control outright — no trade unit chosen, or the grid is empty. */
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  /**
   * The server export for the `all` scope (F4.3c), or `null` for none.
   *
   * 🔴 **The `page` scope never goes to the server, seam or no seam.** Its rows are already here in
   * the screen's order, so the in-screen file equals the screen by construction and costs nothing;
   * asking a server to reproduce a page it did not define would be the one way to make the two
   * disagree.
   */
  readonly serverExport: import("@angular/core").InputSignal<ServerExport | null>;
  /**
   * Fired after every export that produced a file, saying which path produced it.
   *
   * Separate from {@link failed} because it is not a failure: an in-screen export that ran because
   * the server stood aside is a successful export with something to say about itself.
   */
  readonly completed: import("@angular/core").OutputEmitterRef<ExportOutcome>;
  /**
   * What went wrong, or `null` when an export succeeded.
   *
   * Emitted rather than rendered here: the panel is closed by the time an all-pages export fails, so
   * a message inside it would be a message nobody sees.
   */
  readonly failed: import("@angular/core").OutputEmitterRef<string | null>;
  /**
   * Which step the panel is on — `null` is the scope step.
   *
   * 🔴 **Resetting on TOGGLE is what makes the reopened state reliable.** The dropdown directive has
   * no close callback and an outside click or Escape closes it without telling us, so the reset hangs
   * off the trigger, which every path back into the panel goes through.
   */
  protected readonly scope: import("@angular/core").WritableSignal<"all" | "page" | null>;
  /**
   * Which fields the next export carries, and in what order.
   *
   * Seeded from the grid's own column order, so opening the panel and exporting without touching
   * anything produces the file the screen would have produced with no picker at all.
   */
  protected readonly fields: import("@angular/core").WritableSignal<readonly ExportField[]>;
  /** True while an all-pages export is resolving, so the button can say so. */
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  /**
   * Whether an export can run at all.
   *
   * 🔴 Zero fields is refused rather than exported. `toCsv` with no columns writes one empty header
   * line and one empty line per row — a download that looks like it worked and reads as missing data
   * rather than as the user's own selection.
   */
  protected readonly canExport: import("@angular/core").Signal<boolean>;
  /** Opens or closes the panel, always landing on the scope step. */
  protected onToggle(): void;
  /**
   * Enters the field step, with the fields back at the grid's own order.
   *
   * 🔴 **Reset on every scope pick** rather than held for the session. Under scope-first the
   * selection is made *inside* a single export gesture, so carrying it forward would shape the next
   * file by a choice made during an export already finished — and present that carried state as
   * though it were the default.
   */
  protected onPickScope(scope: 'page' | 'all'): void;
  /** Returns to the scope step, so a wrong pick is not a dead end. */
  protected onBack(): void;
  protected onFieldsChange(fields: readonly ExportField[]): void;
  /**
   * Runs whichever export the scope names.
   *
   * ⚠ Explicit arms rather than a ternary on `=== 'page'`: an unset scope must run **nothing**, and a
   * ternary would quietly make `null` mean "all pages" — the expensive one, and the only one that can
   * reach the server.
   */
  protected run(): void;
  /** The columns the next export writes — the user's subset, in the user's order. */
  private selectedColumns;
  private exportPage;
  private exportAll;
  static ɵfac: i0.ɵɵFactoryDeclaration<GridExportComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GridExportComponent<any>, "cms-grid-export", never, {
    "columns": {
      "alias": "columns";
      "required": true;
      "isSignal": true;
    };
    "visibleKeys": {
      "alias": "visibleKeys";
      "required": false;
      "isSignal": true;
    };
    "pageRows": {
      "alias": "pageRows";
      "required": true;
      "isSignal": true;
    };
    "totalCount": {
      "alias": "totalCount";
      "required": true;
      "isSignal": true;
    };
    "allRows": {
      "alias": "allRows";
      "required": true;
      "isSignal": true;
    };
    "filename": {
      "alias": "filename";
      "required": true;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "serverExport": {
      "alias": "serverExport";
      "required": false;
      "isSignal": true;
    };
  }, {
    "completed": "completed";
    "failed": "failed";
  }, never, never, true, never>;
}
/**
 * Where a binding lives, and therefore what it outranks.
 *
 * 🔴 **Precedence is `dialog` › `control` › `feature` › `shell`**, and the ordering is the whole
 * reason scopes exist rather than one flat list. A dialog is modal: while it is open, `Escape` means
 * *close this dialog* and nothing else may claim it. A control that has focus — an open combo, a
 * calendar popover — owns its own arrow keys. A feature screen owns its save and its section
 * navigation. The shell owns navigation between modules, which is the only layer that is always
 * present and therefore the one that must always lose.
 *
 * ⚠ **`shell` is standalone-only** (docs/02a §8). Embedded under Module Federation the host owns the
 * chrome, so a feature registering `Alt+H` would fight the host for a key the host may already use.
 * `ShortcutRegistryGuardSpec` asserts no feature library registers at this scope.
 */
export type ShortcutScope = 'shell' | 'feature' | 'control' | 'dialog';
/**
 * One keyboard binding — what it is called, what it does, and where it is allowed to fire.
 *
 * ### 🔴 The label is not documentation, it is the legend
 *
 * CTRM's own study found the line-23 legend is a user's only discovery mechanism, and that 205
 * screens enable `F1` without labelling it while others label keys with no handler behind them. A
 * label that can disagree with a handler is that defect waiting to happen — so the `?` overlay is
 * **generated from these registrations**, and a binding with no label cannot be registered.
 */
export interface ShortcutBinding {
  /**
   * The key, normalised — `alt+h`, `ctrl+shift+s`, `f1`, `?`, `/`, `ctrl+pagedown`.
   *
   * Modifiers in the order `ctrl+alt+shift`, then the key name lowercased. `ctrl` also matches the
   * Command key, matching the grid's existing `Ctrl+C`.
   *
   * ⚠ **Shift is optional on a punctuation key.** `?` is typed with Shift on most layouts, so a
   * binding of `?` matches whether or not the token carries `shift` — see {@link shortcutTokens}.
   */
  readonly keys: string;
  readonly scope: ShortcutScope;
  /** What the overlay says this key does. Sentence case, no trailing stop. */
  readonly label: string;
  /**
   * The overlay heading this sits under. Defaults to a heading derived from the scope.
   *
   * Group by *what the user is doing* — "Navigation", "This contract", "Grids" — rather than by the
   * scope, which is an implementation detail they have no reason to learn.
   */
  readonly group?: string;
  /**
   * What the key does. **Absent means legend-only**: the overlay lists it and the registry never
   * fires it.
   *
   * 🔴 That is not a loophole, it is how a key the *browser* owns still reaches the user. `F12` is
   * Cancel/Previous on the green screen and DevTools in Chrome, and cannot be intercepted — so the
   * overlay says "Esc — back (F12 on green screen)" and the muscle memory has somewhere to land.
   */
  readonly run?: (event: KeyboardEvent) => void;
  /**
   * Whether the binding may fire while focus is in a text field. **Defaults to false.**
   *
   * 🔴 The default is the safe direction and the reason `?` and `/` are usable at all: a trader
   * typing `?` into a remark must get a question mark, not a cheat-sheet. Anything modified with
   * Ctrl or Alt normally sets this true — `Ctrl+S` has to save while the cursor is in a field, which
   * is the only time there is anything to save.
   */
  readonly allowInTextInput?: boolean;
  /**
   * Whether the binding applies right now. Defaults to always.
   *
   * ⚠ **This gates the OVERLAY as well as the handler**, deliberately. A cheat-sheet listing a key
   * that does nothing is CTRM's "enabled does not mean does something" defect reproduced in a nicer
   * font — and a row action the caller has no permission for is exactly that case.
   */
  readonly available?: () => boolean;
  /**
   * The element this binding belongs to. A keystroke aimed at a specific element OUTSIDE it is left
   * alone. Defaults to the whole document.
   *
   * 🔴 **Why it exists: embedding.** The registry listens on `document`, and a host page shares that
   * document. Without this, a host user pressing `Ctrl+S` in the host's own search box saved the
   * embedded contract, because the record's save binding is allowed inside text inputs (found by the
   * F9.3 host harness, 2026-09-28).
   *
   * ⚠ A keystroke with no focused element (`body` or `html` as the target) still counts as inside,
   * so `Ctrl+S` after clicking on blank space keeps saving the one record on screen.
   */
  readonly within?: () => Element | null;
  /**
   * Whether this binding wants this particular keystroke. Defaults to every keystroke.
   *
   * 🔴 **Checked before the registry cancels the default, and a refusal counts as no match.** That is
   * what lets Enter advance a single-line field while a note keeps its newline and an open combo
   * keeps its selection (#314). A handler that declined after `preventDefault()` had already run
   * would have spent the key anyway.
   *
   * ⚠ Unlike {@link available} it does NOT gate the overlay. It sees the event, and the overlay has
   * no event to ask about.
   */
  readonly accepts?: (event: KeyboardEvent) => boolean;
  /** An aside shown beside the label in the overlay — the green-screen key it replaces, usually. */
  readonly note?: string;
}
/**
 * Marks a field that has a list or calendar `F4` can open (#314). Set only while the field is
 * editable, so `F4` on a read-only field does nothing.
 */
export declare const LOOKUP_ATTRIBUTE = "data-cws-lookup";
/**
 * Dispatched at a {@link LOOKUP_ATTRIBUTE} element to ask its control to open its list or calendar.
 *
 * ⚠ **An event rather than an injected service**, so `F4` needs no registration per control. One
 * binding per key per scope is the registry's rule, and a form has dozens of combos.
 */
export declare const OPEN_LOOKUP_EVENT = "cws-open-lookup";
/** A registered binding, with the ordering the registry resolves ties by. */
/**
 * A key a focused control handles itself, for the hint strip (#821). Not a binding: the control keeps
 * its own handler (the grid's letters, Enter and `Ctrl+C`), and this only says the key applies now.
 */
export interface ShortcutHint {
  /** Normalised like {@link ShortcutBinding.keys}: `enter`, `e`, `ctrl+c`. */
  readonly keys: string;
  readonly label: string;
}
export interface RegisteredShortcut {
  readonly binding: ShortcutBinding;
  /** Monotonic, so the most recently registered of two equal-scope bindings wins. */
  readonly sequence: number;
}
/** Higher wins. See {@link ShortcutScope}. */
export declare function scopeRank(scope: ShortcutScope): number;
/** The overlay heading used when a binding names no group. */
export declare function defaultGroup(scope: ShortcutScope): string;
/**
 * Renders a binding's keys the way a person reads them — `Ctrl + Shift + S`, `Alt + H`, `?`.
 *
 * ⚠ The overlay and any `aria-keyshortcuts` attribute both go through here, so the key a screen
 * reader announces and the key printed beside the button cannot disagree.
 */
export declare function formatShortcut(keys: string): string;
/**
 * The `aria-keyshortcuts` form, which is a different grammar from the printed one.
 *
 * WAI-ARIA wants `Control+Shift+S` — capitalised names, `+` with no spaces, `Control` rather than
 * `Ctrl`. Getting this wrong is silent: assistive technology simply does not announce it.
 */
export declare function ariaKeyShortcuts(keys: string): string;
/**
 * Every binding token a key event could reasonably mean.
 *
 * ### 🔴 It returns several, and each extra one closes a real gap
 *
 * 1. **`event.key` and `event.code`.** With Alt held, some keyboard layouts report a dead key or an
 *    accented character in `event.key` rather than the letter printed on the cap — so `Alt+H` on a
 *    non-US layout would silently never match. `event.code` is the physical key and is layout
 *    independent, so `KeyH` gives `h` regardless.
 * 2. **With and without `shift`, whenever Shift is down.** `?` is Shift+`/` on a US layout, so the
 *    literal token is `shift+?` while the binding is written `?` — the shift is already expressed in
 *    the character. `Ctrl+Shift+S` needs the opposite, because there the character is a letter and
 *    the shift is the thing being pressed. Emitting both is what lets one rule serve both.
 *
 * ⚠ **`ctrl` covers the Command key**, matching what the data grid already does for `Ctrl+C`.
 */
export declare function shortcutTokens(event: KeyboardEvent): readonly string[];
/**
 * Whether typing into this element should suppress an unmodified shortcut.
 *
 * 🔴 **The `input` arm enumerates what is NOT text**, rather than listing what is. `type` grew from
 * three values to twenty-odd and will grow again; a whitelist silently stops recognising each new
 * one as text, which turns `/` into a shortcut inside a field a user is typing in.
 */
export declare function isTextEditable(target: EventTarget | null): boolean;
/**
 * **One registry, one document listener, scoped registrations, a generated legend.**
 *
 * ### 🔴 Why a registry rather than more `@HostListener`s
 *
 * This repository already had five components listening on `document:keydown`, each returning early
 * on `event.defaultPrevented`. That works, and it does not scale to a documented shortcut layer for
 * two reasons the CTRM study makes concrete:
 *
 * 1. **Nothing can enumerate the bindings**, so a cheat-sheet would have to be hand-maintained beside
 *    them — and CTRM's own display files show what that produces: 205 screens that enable `F1`
 *    without labelling it, and templates that advertise `F1`–`F24` with no logic behind any of them.
 *    Here the overlay *is* {@link visible}, so a label with no handler is not merely discouraged, it
 *    is unrepresentable.
 * 2. **Nothing can refuse a collision.** CTRM binds subfile fold to F8, F5, F11, F23, F10, F9, F12 or
 *    F20 depending on the screen, and Profound UI swapped F3 and F12 against the green screens — three
 *    conventions in one product. {@link register} throws on a duplicate in the same scope, so that
 *    cannot start here.
 *
 * ### ⚠ It coexists with the existing handlers rather than replacing them wholesale
 *
 * The listener stands down on `event.defaultPrevented`, exactly as the per-component handlers do, and
 * calls `preventDefault()` when it acts. So a component that has not been migrated keeps working, and
 * the order is the one already documented on the record page: whoever registered first gets first
 * refusal. **The grid's arrow, Home/End and `Ctrl+C` handling is deliberately NOT migrated** — it is
 * control-internal, correct, and moving it would buy a legend entry at the price of re-testing the
 * most heavily specified component in the library.
 */
export declare class ShortcutRegistry {
  private readonly registrations;
  private sequence;
  /**
   * Every binding that applies right now, for the overlay and the hint strip.
   *
   * ⚠ Filtered by `available()`, so a row action the caller cannot use is absent from the cheat-sheet
   * rather than listed and inert.
   */
  readonly visible: import("@angular/core").Signal<RegisteredShortcut[]>;
  /** Every owner's current context, most recently set last. */
  private readonly contexts;
  /**
   * The keys the focused control handles itself, for the hint strip to lead with (#821).
   *
   * The most recently set owner wins, so the control the user moved to is the one described. Clearing
   * it hands back to the one before, rather than blanking the strip while another control still holds
   * its context.
   */
  readonly contextHints: import("@angular/core").Signal<readonly ShortcutHint[]>;
  /**
   * Sets, or with `null` clears, an owner's context hints. An owner that sets again moves to the front.
   *
   * ⚠ Hints, not bindings: the owner keeps handling its own keys. This only tells the strip they apply.
   */
  setContext(owner: object, hints: readonly ShortcutHint[] | null): void;
  constructor();
  /**
   * Registers bindings and returns the disposer.
   *
   * 🔴 **Throws on a duplicate key within one scope, in development only.** Two handlers on one key
   * is the defect the CTRM study calls out by name — `F1` claimed as both Help and Exit across 147
   * screens, so what it does depends on the emulator. Failing loudly at registration is the only
   * point at which that is cheap to see.
   *
   * ⚠ **Same key, different scope is legitimate and must stay so.** `Escape` closes a dialog at
   * `dialog` scope and leaves the record at `feature` scope; precedence is what picks between them,
   * and refusing the pair would make modality impossible.
   */
  register(bindings: readonly ShortcutBinding[]): () => void;
  /**
   * Resolves one key event.
   *
   * An arrow property so `removeEventListener` gets the same reference `addEventListener` was given —
   * a bound method would be a new function each time and the listener would never come off.
   */
  private readonly onKeydown;
  static ɵfac: i0.ɵɵFactoryDeclaration<ShortcutRegistry, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Registers bindings for the lifetime of the calling component.
 *
 * ⚠ **Must be called in an injection context** — a field initialiser or a constructor. That is what
 * ties the disposal to the component rather than leaving a handler behind on a screen the user has
 * navigated away from, which is how a shortcut starts acting on the wrong page.
 */
export declare function registerShortcuts(bindings: readonly ShortcutBinding[]): void;
/** One rendered row of the cheat-sheet. */
interface OverlayRow {
  readonly keys: string;
  readonly label: string;
  readonly note: string | null;
}
/** One rendered section. */
interface OverlayGroup {
  readonly heading: string;
  readonly rows: readonly OverlayRow[];
}
/**
 * **The `?` cheat-sheet — CTRM's line-23 legend, generated rather than written.**
 *
 * ### 🔴 It has no hand-maintained content, and that is the point
 *
 * The CTRM study found 966 display files labelling `F3` and 205 enabling `F1` without labelling it,
 * plus templates advertising `F1`–`F24` with no logic behind any of them: *"enabled does not mean
 * does something"*. Every one of those is a legend and a handler drifting apart. Here they are the
 * same object — {@link ShortcutRegistry.visible} — so a key listed here is a key that fires, and a
 * key that fires is listed here.
 *
 * ⚠ **It lists what is registered NOW**, so it is contextual without anyone maintaining a per-screen
 * copy: open it on the record screen and the record screen's bindings are in it, because that
 * component registered them on init and will dispose them on navigation.
 *
 * ### ⚠ Opening it is itself a registration, at shell scope
 *
 * `?` and `F1` are registered here rather than by the shell, so the overlay cannot be mounted without
 * the keys that open it. Both are `shell` scope, which means a dialog can legitimately take `F1` for
 * its own help and win.
 */
export declare class ShortcutOverlayComponent {
  private readonly registry;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  constructor();
  protected toggle(): void;
  /**
   * The cheat-sheet, grouped.
   *
   * ⚠ **Groups are ordered by the order they are first met**, not alphabetically. The shell registers
   * before any feature does, so Navigation leads and the current screen's own keys follow — which is
   * the order someone scanning for "what can I do here" reads in.
   */
  protected readonly groups: import("@angular/core").Signal<readonly OverlayGroup[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ShortcutOverlayComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ShortcutOverlayComponent, "cms-shortcut-overlay", never, {}, {}, never, never, true, never>;
}
/**
 * **The line-23 equivalent** — a few keys, always on screen, for the screen you are on.
 *
 * ### 🔴 Why a strip and not only the `?` overlay
 *
 * The CTRM study's sharpest finding about discovery is that the legend on line 23 *is* the user's
 * discovery mechanism: 966 of 1,066 display files label `F3` there, and the keys that go unlabelled
 * are the ones users never learn exist. An overlay behind `?` is only discoverable by someone who
 * already knows to press `?`, which is the same problem one level up.
 *
 * ⚠ **Nine keys at most (six until #821), and the overlay is the way to see the rest.** The green screen had
 * one line and so does this; a strip listing everything would be a second cheat-sheet competing with
 * the first, and would reflow as the registry changed.
 *
 * ### ⚠ Standalone only (docs/02a §8)
 *
 * Embedded under Module Federation the host owns the chrome, and a fixed strip along the bottom of
 * *its* window is not ours to place. The shell renders this; feature libraries must not.
 *
 * ### ⚠ `templateUrl`, not an inline template — and that is not a style preference
 *
 * The markup's comments contain backticked identifiers, and an inline template **is a template
 * literal**, so the first backtick ends it. That is Known Issue 37's recorded mechanism and it was
 * hit writing this component: the compiler reported eight cascading parse errors in the decorator
 * rather than anything resembling the real cause.
 */
export declare class ShortcutHintsComponent {
  private readonly registry;
  /**
   * The keys worth a permanent line, for what the user is on right now (#821).
   *
   * 🔴 **The focused control's keys lead.** A focused grid row publishes the keys that work on THAT
   * row (Enter, its allowed action letters, `Ctrl+C`) through the registry's context channel, and they
   * leave when focus leaves the grid. Then the current screen's keys, then the shell's, sorted by scope
   * descending, so a user on the record screen sees Save before Home.
   *
   * 🔴 **Only keys CWS handles** (JFrisbie, 2026-10-13). A legend-only binding, one with no `run`, is
   * a key the browser keeps (Alt+D, Alt+F, F5). The `?` overlay lists those to explain the gap; on
   * this strip they were noise. ~~Legend-only entries are included~~ is withdrawn.
   *
   * ⚠ A key both the context and a registration name is listed once, with the context's label: it is
   * the more specific of the two.
   *
   * ⚠ **A stable sort, which matters here.** Two feature bindings must keep their registration
   * order, or the strip reorders itself between renders for no reason the user can see. `Array.sort`
   * is specified stable since ES2019, so comparing only the scope weight is enough.
   */
  protected readonly hints: import("@angular/core").Signal<{
    keys: string;
    label: string;
  }[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ShortcutHintsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ShortcutHintsComponent, "cms-shortcut-hints", never, {}, {}, never, never, true, never>;
}
/**
 * **`/` focuses this search box** — docs/02a §4.1, the one global key that is grid-scoped.
 *
 * ### 🔴 A directive rather than four registrations
 *
 * Four screens carry a grid search box, and `/` has to mean the same thing on all of them. Written
 * out per screen it is four copies of a three-line handler that will drift on the detail nobody
 * notices — this one selects the existing term as well as focusing, so a second `/` replaces rather
 * than appends, and that is exactly the kind of refinement that would land on one screen only.
 *
 * ### ⚠ It must NOT fire while the user is typing, and gets that for free
 *
 * `allowInTextInput` defaults to false, so typing `/` into a remark, a customer name or this box
 * itself inserts a slash. That default is the reason an unmodified punctuation key is usable as a
 * shortcut at all — and it is a default rather than a per-binding decision precisely so it cannot be
 * forgotten here.
 *
 * ⚠ **`feature` scope, not `shell`.** The box belongs to the screen, and an embedded feature may
 * legitimately register it while the host owns everything else (docs/02a §8).
 */
export declare class SearchShortcutDirective {
  private readonly host;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<SearchShortcutDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<SearchShortcutDirective, "input[cmsSearchShortcut]", never, {}, {}, never, never, true, never>;
}
/**
 * **The control strip above a data grid** — search and filters left, refresh and the pager right.
 *
 * ### 🔴 Why this is a component rather than a class string copied onto four screens
 *
 * The workspace, both pricing screens and the approval queue all carry the same strip, and it was
 * the same bare `flex flex-wrap items-end gap-2` on each — four copies with nothing holding them
 * together. This library already shares `cms-pager`, `cms-refresh-button`, `cms-clear-sort-button`
 * and `cms-select` for precisely that reason, and the detail that drifts is never the obvious one:
 * it is a `p-3` that became `p-4` on one screen, or a surface added to one and not the others, so
 * the controls shift as a user moves between grids that are meant to read as the same tool.
 *
 * ⚠ **It is a surface, not a layout engine.** Children arrange themselves — `flex-1` on the search,
 * `ml-auto` on the block that should sit hard right. Anything cleverer here would have to know what
 * each screen puts in it, which is the coupling this avoids.
 *
 * ### ⚠ The padding is `p-3`, not the design system's `p-6`
 *
 * `.scoular-card`'s own padding classes are meant for content. On a control strip they push the
 * search box away from the grid it filters, which reads as two unrelated blocks rather than one
 * control and the thing it controls.
 *
 * Ships no element selector styling of its own beyond the host class, and no global styles — these
 * libraries render inside foreign host applications under Module Federation (docs/02a §8).
 */
export declare class GridToolbarComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<GridToolbarComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<GridToolbarComponent, "cms-grid-toolbar", never, {}, {}, never, ["*"], true, never>;
}
/**
 * Open/close behaviour for a dropdown, without opinions about what is inside it.
 *
 * Extracted at the second use (docs/CLAUDE.md — centralise when the same logic appears in 2+
 * places): the identity menu and the trade-unit picker need identical dismissal semantics and
 * completely different ARIA. A shared *component* would have had to pick one of `role="menu"` and
 * `role="listbox"` for both, so the reusable part is the behaviour, not the markup.
 *
 * Apply to the wrapper and read it back with `exportAs`:
 *
 * ```html
 * <div cmsDropdown #menu="cmsDropdown" class="relative">
 *   <button (click)="menu.toggle()" [attr.aria-expanded]="menu.open()">…</button>
 *   @if (menu.open()) { <div class="scoular-dropdown">…</div> }
 * </div>
 * ```
 *
 * Dismissal is bound on the document rather than via a backdrop element: a backdrop covering the
 * page swallows the first click on whatever the user was actually reaching for, which costs more
 * than the listener does.
 */
export declare class DropdownDirective {
  private readonly host;
  /** What had focus when the panel opened, so Escape can put it back. */
  private previouslyFocused;
  readonly open: import("@angular/core").WritableSignal<boolean>;
  toggle(): void;
  show(): void;
  /**
   * Closes the panel.
   *
   * @param restoreFocus Return focus to whatever had it when the panel opened. True for keyboard
   * dismissal, where leaving focus on a removed element strands the user; false for a click
   * elsewhere, where the user has already chosen where to go.
   */
  close(restoreFocus?: boolean): void;
  protected onDocumentClick(event: MouseEvent): void;
  /**
   * Escape dismisses the panel — and **marks the event handled when it actually dismissed one**.
   *
   * The `preventDefault` is not about suppressing a browser default; Escape has none here. It is a
   * signal to other Escape handlers on the page that this keypress has already been spent. The
   * contract detail screen uses Escape to go back to the contract list, and without this a user who
   * pressed Escape merely to close the identity menu would also be navigated off the record.
   *
   * ⚠ **Only when something was open.** `close()` returns early otherwise, so guarding on `open()`
   * here is what keeps a closed dropdown from swallowing every Escape on the page — the failure
   * would be a keyboard shortcut that silently stops working wherever a dropdown happens to exist.
   */
  protected onEscape(event: Event): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<DropdownDirective, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<DropdownDirective, "[cmsDropdown]", ["cmsDropdown"], {}, {}, never, never, true, never>;
}
/**
 * An icon-only refresh control — re-read what is on screen, keeping every choice the user has made.
 *
 * Used by the contract workspace toolbar and the contract record screen. **One component rather than
 * the markup twice**, for the reason the pager gives: two copies drift, and one gains a disabled state
 * or an aria-label the other does not.
 *
 * ### 🔴 Height: why the icon sits in a 20px wrapper
 *
 * A `scoular-btn` is **38px** — `py-2` (8px each) plus a `text-sm` line box (20px) plus a 1px border.
 * That figure only holds while the button contains *text*. An icon-only button has no line box, so its
 * content height is the icon's own 16px and the button renders **36px** — two pixels short of the
 * Export data button and the pager it has to line up with, which is precisely the misalignment this
 * control was added next to.
 *
 * So the icon is wrapped in a `h-5` (20px) span, which restores the line box the text would have
 * occupied. **`h-5` is chosen because height is uncontested**: the design system sets padding and font
 * size on `.scoular-btn` but never a height.
 *
 * ✅ **Updated 2026-09-16.** That used to be the only reason it worked — the design system compiled
 * as *unlayered* CSS while Tailwind utilities land in `@layer utilities`, so a utility that fought
 * `py-2` silently lost. `components.css` now sits in `@layer components` (the shell's `styles.css`),
 * so a padding utility would win. **Nothing here changes**: the wrapper is not a cascade workaround,
 * it restores a missing *line box*, and no amount of padding does that. Measured after the change:
 * still 38px, identical to a button with text.
 *
 * ### What it does not do
 *
 * It does not know how to reload anything. It emits {@link refresh} and the screen re-issues its own
 * request — which is what keeps filters, sort and page intact, because the query is never touched.
 */
export declare class RefreshButtonComponent {
  /**
   * What the button is for, as an `aria-label` and a hover title.
   *
   * Required rather than defaulted: an icon-only button is unreadable without it, and a default like
   * "Refresh" would let a screen with two of them announce both identically.
   */
  readonly label: import("@angular/core").InputSignal<string>;
  /** A refresh is in flight — the icon spins and the button refuses further presses. */
  readonly busy: import("@angular/core").InputSignal<boolean>;
  /** Refusing for a reason of the screen's own, e.g. the workspace has no trade unit chosen yet. */
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  /** Re-read what is on screen. The screen owns the reload; see the class remarks. */
  readonly refresh: import("@angular/core").OutputEmitterRef<void>;
  /**
   * Disabled while busy as well as when the screen says so.
   *
   * Without the `busy` half, holding the button down queues one request per click against a screen
   * that is already loading — and on the workspace grid every one of those is a CTRM read.
   */
  protected readonly isDisabled: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RefreshButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RefreshButtonComponent, "cms-refresh-button", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "busy": {
      "alias": "busy";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "refresh": "refresh";
  }, never, never, true, never>;
}
/**
 * Returns a grid to the ordering it arrived with, and appears only once that ordering has changed.
 *
 * Used by the contract workspace, the approval queue and the unpriced queue. **One component rather
 * than the markup three times**, for the reason the refresh button gives: three copies drift, and
 * the details that drift are the ones that are invisible when wrong — the badge's height, the
 * suppression at one sort, the `aria-label`.
 *
 * ### 🔴 "Clear" means *back to how it arrived*, which is not always *no sort*
 *
 * On the workspace the grid arrives unsorted, so clearing empties the chain. The two queues arrive
 * **deliberately sorted** — approvals oldest-first, pricing largest-outstanding-first — because that
 * ordering *is* the queue's meaning. Emptying it there would not undo anything the user did; it
 * would discard the screen's own answer to "what should I work on next", and leave them to rebuild
 * it from a column header.
 *
 * So the control takes {@link defaultSorts} and restores that. With no default supplied it restores
 * nothing, which is exactly the workspace's existing behaviour — the two screens are the same rule,
 * not two rules.
 *
 * ### ⚠ Rendered conditionally rather than shipped disabled
 *
 * The workspace's own note, and it is what decides the visibility rule: a greyed control for
 * something the user cannot see and has not done is worse than no control. On a queue that means it
 * stays hidden on arrival — sorted oldest-first is the screen's doing, not theirs — and appears the
 * moment they sort it differently.
 *
 * ### ⚠ `h-5` on the badge is load-bearing
 *
 * Reported on the workspace (JFrisbie, 2026-09-03): with two or more sorts the button *"grows beyond
 * its regular height"* and stops lining up with its neighbours. A `scoular-btn` is `py-2` around a
 * 20px `text-sm` line box; `.scoular-badge-sm` is `py-0.5` around `text-xs` **plus the 1px border
 * `.scoular-badge` carries** — 22px — and the tallest child wins. It has to be a *height* rather than
 * trimmed padding, and ✅ **the reason changed on 2026-09-16 without the code changing.** It used to
 * be a cascade constraint: `py-0.5` comes from the design system, which compiled **unlayered**, so a
 * Tailwind `py-0` landed in `@layer utilities` and silently lost. `components.css` now sits in
 * `@layer components`, so `py-0` would win.
 *
 * The height stays because the argument that survives is the geometric one: the badge is the
 * *tallest child*, and trimming its padding to fit makes the badge wrong in order to make the button
 * right. Constraining the button's own height leaves the badge alone. Measured after the change:
 * badge still 22px, button still 38px.
 */
export declare class ClearSortButtonComponent {
  /** The sort chain in force. */
  readonly sorts: import("@angular/core").InputSignal<readonly GridSort<string>[]>;
  /**
   * The ordering the screen arrived with, restored when the button is used.
   *
   * Empty by default, which is the workspace's case: clearing there means no sort at all.
   */
  readonly defaultSorts: import("@angular/core").InputSignal<readonly GridSort<string>[]>;
  /** Emits the ordering to return to — the default, so the caller applies it like any other sort. */
  readonly clear: import("@angular/core").OutputEmitterRef<readonly GridSort<string>[]>;
  protected readonly visible: import("@angular/core").Signal<boolean>;
  protected readonly hint: import("@angular/core").Signal<"Remove the sort and return to the order the rows arrived in" | "Return to this queue's default order">;
  /**
   * Whether two sort chains are the same, **in order**.
   *
   * Order matters and is not a detail: a chain is applied left to right, so the same two columns
   * swapped is a different ordering — and treating them as equal would hide the button on a sort the
   * user did make.
   */
  private same;
  static ɵfac: i0.ɵɵFactoryDeclaration<ClearSortButtonComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ClearSortButtonComponent, "cms-clear-sort-button", never, {
    "sorts": {
      "alias": "sorts";
      "required": true;
      "isSignal": true;
    };
    "defaultSorts": {
      "alias": "defaultSorts";
      "required": false;
      "isSignal": true;
    };
  }, {
    "clear": "clear";
  }, never, never, true, never>;
}
export declare class NoticesPanelComponent {
  /**
   * Unique per instance, so two panels on one page cannot both claim the same `aria-controls`
   * target — which would point half the buttons at the wrong region.
   */
  protected readonly detailId: string;
  /**
   * One short line per notice. Their **count** is the count the header shows.
   *
   * ⚠ Not rendered: the collapsed panel shows only its heading and count, and the expanded one
   * shows the projected detail. Keep one entry per projected notice so the count stays true.
   */
  readonly summaries: import("@angular/core").InputSignal<readonly string[]>;
  /** Heading. Overridable because a screen may have notices that are not about the environment. */
  readonly heading: import("@angular/core").InputSignal<string>;
  /**
   * Whether the panel holds the environment and system caveats (#1223). They are the Admin role's
   * only, so a caller passes `false` for anyone else, and what is left is that screen's user notices:
   * the heading then reads "Notices" rather than naming caveats the panel does not hold.
   */
  readonly systemNotices: import("@angular/core").InputSignal<boolean>;
  protected readonly title: import("@angular/core").Signal<string>;
  /**
   * Whether the panel starts open.
   *
   * ⚠ Defaults to **closed**, which is the whole point — but it is an input because a screen whose
   * notices are genuinely blocking may want them open on arrival, and that is a per-screen call
   * rather than something this component should decide.
   */
  readonly initiallyExpanded: import("@angular/core").InputSignal<boolean>;
  /**
   * ⚠ A `linkedSignal` rather than a plain one seeded in the constructor: a signal input has not
   * received its bound value yet at construction, so seeding there would read the *default* and
   * silently ignore what the caller asked for.
   */
  protected readonly expanded: import("@angular/core").WritableSignal<boolean>;
  protected readonly count: import("@angular/core").Signal<number>;
  /**
   * Whether the panel renders at all.
   *
   * 🔴 **A panel with nothing in it must not appear.** Its whole value is that a non-zero count is
   * information; a permanent "Notices (0)" is the same furniture this replaced, one row shorter.
   */
  protected readonly hasNotices: import("@angular/core").Signal<boolean>;
  protected toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<NoticesPanelComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<NoticesPanelComponent, "cms-notices-panel", never, {
    "summaries": {
      "alias": "summaries";
      "required": true;
      "isSignal": true;
    };
    "heading": {
      "alias": "heading";
      "required": false;
      "isSignal": true;
    };
    "systemNotices": {
      "alias": "systemNotices";
      "required": false;
      "isSignal": true;
    };
    "initiallyExpanded": {
      "alias": "initiallyExpanded";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * **A drag driven by pointer events, shared** (extracted from the filter builder for F8.1).
 *
 * ### Why this exists as one piece
 *
 * The filter chip row was rewritten onto pointer events on 2026-09-14 after HTML5 drag-and-drop
 * reached a state in Chrome it could not recover from without a reload. The form-configuration
 * editor then needed the same gesture for its field rows. A second copy would have been the
 * second-copy drift ADR-7 exists to prevent: the next fix to one (a new way the browser takes the
 * pointer away, say) would silently miss the other. So the gesture lives here and both drive it.
 *
 * ### 🔴 Two rules that are not in this file, and every caller owes both
 *
 * 1. **The container must be `select-none`** (Known Issue 44). A press inside a leftover text
 *    selection is taken by the browser as a SELECTION drag and announced with `pointercancel`, so
 *    without it the gesture works once per session and then stops. This file cannot apply a class
 *    to a caller's markup, and jsdom cannot test it, so each caller carries the class and a comment.
 * 2. **A keyboard path to the same operation.** Drag is the mouse gesture, not the only one.
 *
 * ### What it does
 *
 * - **A press is not yet a drag.** Nothing starts until the pointer has travelled
 *   {@link DRAG_THRESHOLD_PX}, which keeps a click, a double-click and a press on a control inside a
 *   handle working as they did.
 * - **Window listeners, alive only while a press is followed.** A drag that begins on one row has to
 *   be tracked across every other row and off the list entirely, which a per-element listener cannot
 *   see.
 * - **Hit-tested with `elementFromPoint`**, through the caller's `target`, because the element that
 *   receives a pointer event is the one under the pointer and not the one the drag began on.
 * - **Every way out ends it.** `pointerup`, `pointercancel`, Escape and the window losing focus all
 *   clear the gesture, so a stuck row is structurally impossible rather than merely unlikely. Under
 *   `dragstart` the same interruptions are silent.
 *
 * ⚠ **Framework-free on purpose.** No Angular, no signals: a caller keeps its own in-flight state and
 * updates it from the callbacks, so the gesture can be unit tested as plain DOM.
 */
/**
 * How far the pointer must travel before a press becomes a drag.
 *
 * 🔴 **Without it every click on a handle would be a one-pixel drag.** Five pixels is below what a
 * deliberate drag covers in its first frame and above the jitter of a firm click.
 */
export declare const DRAG_THRESHOLD_PX = 5;
/** What a caller tells the gesture. `S` is what is being dragged, `T` is where it would land. */
export interface PointerDragHandlers<S, T> {
  /** The element a press must fall inside to be a potential drag. */
  readonly handleSelector: string;
  /**
   * Presses inside an element matching this are never drags. Defaults to `button`, so the controls
   * that live inside a handle (a remove ✕, a Move out) stay clickable.
   */
  readonly ignoreSelector?: string;
  /** Overrides {@link DRAG_THRESHOLD_PX}. */
  readonly threshold?: number;
  /** Reads the drag source off the pressed handle. `null` declines the press. */
  readonly source: (handle: Element) => S | null;
  /** What is under the pointer at a client coordinate, as a drop. `null` means nowhere. */
  readonly target: (x: number, y: number) => T | null;
  /** The press has become a drag. */
  readonly started: (source: S) => void;
  /** The pointer moved during a drag; this is what is now under it. */
  readonly over: (target: T | null) => void;
  /** Released over a target. Always called AFTER {@link ended}. */
  readonly dropped: (source: S, target: T) => void;
  /**
   * The gesture is over, for any reason. Called on every end, including a press that never became a
   * drag, so the owner can clear its in-flight state unconditionally.
   */
  readonly ended: () => void;
}
/**
 * The closest element matching `selector` at a client coordinate, or `null`.
 *
 * 🔴 A hidden element is not returned by `elementFromPoint`, so a drop zone that does not currently
 * apply can be hidden rather than guarded.
 */
export declare function elementUnder(x: number, y: number, selector: string): Element | null;
/**
 * The gesture. Construct one per owner and forward the owner's `pointerdown` to {@link press}.
 *
 * ⚠ Call {@link cancel} when the owner is destroyed, or a drag in flight at that moment would leave
 * its window listeners behind.
 */
export declare class PointerDragGesture<S, T> {
  private readonly handlers;
  private pending;
  private active;
  private current;
  private stop;
  constructor(handlers: PointerDragHandlers<S, T>);
  /** Whether a press has become a drag and has not yet ended. */
  dragging(): boolean;
  /**
   * Begins a *potential* drag.
   *
   * ⚠ Only the primary button, only inside a handle, and never inside the ignore selector.
   */
  press(event: PointerEvent): void;
  /** Ends whatever is in flight without dropping. Safe to call at any point, including twice. */
  cancel(): void;
  private listen;
  private onMove;
  private onUp;
  /** Clears every trace of the gesture and tells the owner. */
  private end;
}
/** One choice. `value` is what the caller stores; `label` is what a person reads. */
export interface SelectOption {
  readonly value: string;
  readonly label: string;
}
/**
 * A dropdown that looks like the rest of the application, for a closed set of choices.
 *
 * ### 🔴 Why this exists rather than a native `<select>`
 *
 * **A `<select>`'s option list is rendered by the operating system, so no CSS reaches it.** The
 * harsh blue selection block, the system font, the square corners — none of it can be styled, and
 * beside the Scoular design system it reads as a piece of a different application. This follows the
 * shell's trade-unit picker instead: `cmsDropdown` for the open/close behaviour, `role="listbox"`
 * markup in the template, `.scoular-dropdown-item` rows with `.active` marking the current value.
 *
 * ⚠ **The trigger wears `scoular-form-input`, not the picker's ghost-button styling.** The shell's
 * picker sits in a bar of plain text where a bordered control looked heavy; these sit among bordered
 * filter inputs, where a borderless one reads as a missing field.
 *
 * ⚠ **Width comes from the WRAPPER, never from this component.** `scoular-form-input` is
 * `@apply w-full` and the design system compiles unlayered, so a `w-40` on the trigger silently
 * loses — the seventh instance of that trap in this codebase. Give the containing element the width.
 *
 * ### Extracted at the fourth use
 *
 * The approvals queue's approver-type filter carried this markup inline, and the filter builder then
 * needed it twice more, for the column and the operator. Three hand-written listboxes would have
 * drifted on exactly the details that are easy to get wrong and invisible when wrong:
 * `aria-selected` on the active row, `text-left` on a button that otherwise centres its text, and
 * showing the chosen *label* rather than the raw value.
 *
 * ⚠ **The template is a separate file on purpose.** An inline template is a JavaScript template
 * literal, so a single backtick in a comment ends it — and this component's comments are about
 * `text-left` and `w-full`. The refresh button's own remarks record the same hazard; a first version
 * of this file hit it.
 *
 * ### ⚠ Nesting: Escape closes the enclosing dropdown too
 *
 * These are used inside the Filters panel, which is itself a `cmsDropdown`. Both directives listen
 * on `document:keydown.escape`, so pressing Escape with a select open closes the select **and** the
 * panel around it. Left as-is deliberately: nothing is lost, because every change is emitted to the
 * parent as it happens rather than on close, so re-opening shows the same state. Worth knowing
 * before it is reported as a defect.
 *
 * ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported
 * into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept
 * because it explains why this code looks the way it does, and the code is unchanged: each of these
 * shapes has a second justification that has nothing to do with layers. See the header of the
 * shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to
 * the shell, so an embedded host may still supply the old cascade.
 */
export declare class SelectComponent {
  readonly options: import("@angular/core").InputSignal<readonly SelectOption[]>;
  /** The chosen value. Not two-way — the parent owns it, as everything else here does. */
  readonly value: import("@angular/core").InputSignal<string>;
  /**
   * The accessible name, used when {@link labelledBy} is not supplied.
   *
   * Required because the trigger shows only a value: "Corn" tells a screen-reader user nothing about
   * what it is the value *of*, and a control with no name is unusable.
   */
  readonly label: import("@angular/core").InputSignal<string>;
  /**
   * The id of an element that already names this control — a visible span beside it.
   *
   * Preferred over {@link label} where a visible label exists, so the name a screen reader announces
   * is the one on screen rather than a second wording that could drift from it.
   */
  readonly labelledBy: import("@angular/core").InputSignal<string | null>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly valueChange: import("@angular/core").OutputEmitterRef<string>;
  /**
   * What the closed trigger reads.
   *
   * 🔴 **The chosen option's LABEL, never the raw value.** The values here are codes and keys —
   * `contains`, `marketZone`, `Secondary` — and showing them would put the implementation on screen.
   *
   * ⚠ Falls back to the first option rather than to an empty trigger: a value matching nothing
   * happens when a saved filter names an operator a column no longer offers, and a blank control
   * would read as "nothing chosen" while a real value was in force underneath.
   */
  protected readonly selectedLabel: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<SelectComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<SelectComponent, "cms-select", never, {
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "labelledBy": {
      "alias": "labelledBy";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "valueChange": "valueChange";
  }, never, never, true, never>;
}
export declare class FilterBuilderComponent<TRow> {
  /** The columns to offer. Pass the grid's own array. */
  readonly columns: import("@angular/core").InputSignal<readonly GridColumn<TRow>[]>;
  /** The filter in force. */
  readonly filter: import("@angular/core").InputSignal<FilterGroup>;
  /**
   * Whether to render the own "+ Add filter" button.
   *
   * Set `false` when the host puts that button on its own toolbar and opens the editor through a
   * template reference — `<cms-filter-builder #fb [showAddButton]="false">` then
   * `(click)="fb.beginAdd()"`. The workspace does exactly that so the button sits beside the view
   * selector rather than on a row of its own.
   *
   * 🔑 **The editor's open/closed state stays HERE either way.** Hoisting it to the host would make
   * two components share one piece of state and disagree about it — the host's button would need to
   * know that committing a rule closes the editor, and picking up a chip to edit opens it. Calling a
   * method on the child keeps one owner.
   */
  readonly showAddButton: import("@angular/core").InputSignal<boolean>;
  readonly filterChange: import("@angular/core").OutputEmitterRef<FilterGroup>;
  /** Segmented-control styling, kept here so the two connector buttons cannot drift apart. */
  protected readonly activeConnector = "cws:bg-scoular-blue cws:text-white";
  protected readonly inactiveConnector = "cws:bg-white cws:text-slate-600 cws:hover:bg-slate-50 cws:dark:bg-slate-700 cws:dark:text-slate-200 cws:dark:hover:bg-slate-600";
  /**
   * The rule being written, or `null` when the editor is closed.
   *
   * An **empty `id` means a new rule**, which is the only case that occurs today.
   *
   * ⚠ **A populated `id` was intended to mean “an existing chip is being edited”, and nothing wires
   * it.** The chips offer only Remove, and `beginAdd` always mints an empty id — so `commit`’s
   * replace-in-place branch and the connector’s exclude-the-edited-rule case are both unreachable.
   * Recorded rather than removed: the replace branch is what a chip-edit affordance would need, and
   * deleting it would leave the next person to rediscover why appending a near-duplicate is wrong.
   */
  protected readonly editing: import("@angular/core").WritableSignal<FilterRule | null>;
  protected readonly rules: import("@angular/core").Signal<readonly import("@cws/shared-ui").FilterNode[]>;
  protected readonly combinator: import("@angular/core").Signal<FilterCombinator>;
  protected readonly activeCount: import("@angular/core").Signal<number>;
  /**
   * Whether the chips row renders at all.
   *
   * **An empty chips row is not free.** It is a flex box with no height, and it still takes
   * `space-y-2`'s 8px margin -- which put 8px above the editor row and nothing below it. That was
   * the uneven gap reported three times; the fix that finally held was structural rather than a
   * padding tweak, so the row must not exist when it has nothing to show.
   *
   * `showAddButton()` is half the condition because the button lives INSIDE this row. With the
   * button hosted here the row is the only way to open the editor, so it renders on an empty
   * filter; with the host owning the button (the workspace toolbar) it must not.
   */
  protected readonly showChipsRow: import("@angular/core").Signal<boolean>;
  /**
   * Whether this component renders anything at all.
   *
   * One expression, read by the template's outer guard **and** by the host's `display` binding — so
   * "renders nothing" and "reserves no space" cannot come apart. Two copies of this condition is
   * exactly how an invisible element keeps its margin.
   *
   * ⚠ `showAddButton()` is part of it because with the button left here, this row must render even
   * on an empty filter — the button inside it is then the only way to open the editor.
   */
  readonly hasContent: import("@angular/core").Signal<boolean>;
  /**
   * Whether the editor should offer "Connect with" at all.
   *
   * **Hidden while there is nothing to connect to** (JFrisbie, 2026-09-10). On the first rule the
   * choice has no meaning -- AND and OR describe how a rule combines with *another* rule -- so
   * offering it asks a question with no consequence, and the answer then silently governs every
   * rule added afterwards. It appears on the second.
   *
   * **The rule being EDITED is excluded, and that clause is live now** (JFrisbie, 2026-09-11).
   * Double-clicking the only chip puts you back in the one-rule case, where the choice is as
   * meaningless as it is on a first rule -- and it was unreachable until chip editing existed,
   * which is why it was documented rather than written.
   */
  protected readonly showConnector: import("@angular/core").Signal<boolean>;
  /**
   * The id of the rule open in the editor, or `null` while adding.
   *
   * Handed to the chips so the one being edited can say so. By **id** rather than path, because
   * an edit survives a drag and a path would point at the wrong chip the moment anything moved.
   */
  protected readonly editingId: import("@angular/core").Signal<string | null>;
  private readonly byKey;
  protected readonly columnOptions: import("@angular/core").Signal<readonly SelectOption[]>;
  protected kindFor(columnKey: string): FilterKind;
  protected headerFor(rule: FilterRule): string;
  protected operatorTextFor(rule: FilterRule): string;
  protected showsValue(rule: FilterRule): boolean;
  /**
   * True when a rule names a column this grid does not have.
   *
   * ⚠ Surfaced on the chip rather than ignored. A saved filter outlives the columns it names, and
   * such a rule matches **nothing** — so silently ignoring it would leave someone staring at an
   * empty grid with no clue why.
   */
  protected isUnknown(rule: FilterRule): boolean;
  protected readonly draftOperatorOptions: import("@angular/core").Signal<readonly SelectOption[]>;
  /** A date column gets a date picker, a numeric one a number field. */
  protected readonly draftInputType: import("@angular/core").Signal<"number" | "text" | "date">;
  /**
   * Opens the editor on a new rule.
   *
   * **Public deliberately**, so a host that hides {@link showAddButton} can drive it from its own
   * toolbar through a template reference. It is the only member this component exposes for that.
   */
  beginAdd(): void;
  protected cancelDraft(): void;
  /**
   * Changes the draft's field, resetting the operator when the new column's kind does not admit it.
   *
   * 🔴 Required rather than tidy: moving from Customer (text, `contains`) to Quantity (number) would
   * otherwise leave `contains` selected on a numeric column — which the engine tolerates, but which
   * shows an operator the picker no longer lists and reads as a stuck control.
   */
  protected setDraftColumn(columnKey: string): void;
  protected setDraftOperator(operator: string): void;
  protected setDraftValue(value: string): void;
  protected readonly canCommit: import("@angular/core").Signal<boolean>;
  /**
   * Commits the draft to the filter.
   *
   * ⚠ **Refuses an incomplete rule even though the button is disabled.** The attribute is a
   * courtesy; this is the guarantee. A rule committed without a value would sit among the chips
   * filtering nothing while reading as though it were.
   */
  protected commitDraft(): void;
  /** The chip marked by the keyboard, awaiting a second to group with. */
  protected readonly marked: import("@angular/core").WritableSignal<FilterPath | null>;
  /** The chip in flight, so its own chip can show it. */
  protected readonly dragging: import("@angular/core").WritableSignal<FilterPath | null>;
  /** What is under the pointer and how a drop there would read. */
  protected readonly dropTarget: import("@angular/core").WritableSignal<DropTarget | null>;
  protected onRemove(path: FilterPath): void;
  protected onToggleCombinator(path: FilterPath): void;
  /**
   * The keyboard grouping gesture: mark one chip, then a second groups them.
   *
   * 🔑 **Routes through `groupNodes`, the same operation the drag uses.** Two ways to group with two
   * implementations would be two sets of edge cases, and the subtle ones here — normalisation, the
   * cannot-contain-itself guard, which combinator a new group takes — are exactly the ones nobody
   * re-derives correctly the second time.
   */
  protected onMark(path: FilterPath): void;
  /**
   * Opens the editor on an existing chip.
   *
   * **The double-click** (JFrisbie, 2026-09-11), and Enter is its keyboard twin. The draft keeps
   * the rule's own `id`, which is what selects `commitDraft`'s replace-in-place branch rather
   * than appending a near-duplicate -- that branch has existed since the builder was written and
   * was unreachable until now, recorded as such rather than deleted.
   *
   * Any half-finished gesture is cleared first: opening the editor with a chip still marked for
   * grouping would leave a mark nothing can now complete, since the next Space goes to the form.
   */
  protected onEdit(path: FilterPath): void;
  /** Takes a chip out of the group it sits in -- the Move out button, and the drop zone. */
  protected onUngroup(path: FilterPath): void;
  /**
   * Whether the chip in flight is inside a group, which is what the ungroup drop zone waits for.
   *
   * A path of length 1 is a top-level chip and has nowhere to come out of; anything deeper does.
   */
  protected readonly draggingNested: import("@angular/core").Signal<boolean>;
  /**
   * **The drag, driven by pointer events rather than HTML5 drag-and-drop** (JFrisbie, 2026-09-14).
   *
   * ### 🔴 Why this was rewritten rather than fixed again
   *
   * The chip row used `draggable` / `dragstart` / `dragover` / `drop`. In Chrome it reached a state
   * where the chip never followed the pointer **and could not be recovered from without reloading
   * the page**: because the native drag never actually began, `dragend` never fired either, so the
   * in-flight state had nothing to clear it. Two attempts to fix it in place did not hold.
   *
   * 🔑 **The actual cause was neither of the two things those attempts aimed at, and it is not in
   * this file** — it is the text selection a drag leaves behind, recorded on the chip row in
   * `filter-builder.component.html`. A press inside a selection makes Chrome drag the SELECTION
   * rather than whatever is under it, so the chip never lifted. `select-none` is the fix, and it
   * would have fixed the native version too.
   *
   * ⚠ **So the rewrite was not what repaired the defect, and it is kept anyway.** Pointer events are
   * ordinary DOM events with no hidden state machine: nothing can refuse to start, `pointercancel` is
   * delivered when the browser does take the pointer away, and `pointerup` is guaranteed — which is
   * what makes a stuck row **structurally impossible** rather than merely unlikely. Escape and losing
   * the window clear it too. Under `dragstart` the same interruption is silent and unrecoverable.
   *
   * 🔑 **And the rewrite is what made the defect VISIBLE.** Playwright drives a native drag through
   * CDP, which skips the drag loop entirely, so all eight gestures passed in both browsers while a
   * real mouse could do none of them. Driven as plain pointer events the same script reproduces it on
   * the first try — the second drag of a session dies on a `pointercancel`. An instrument that could
   * not see the failure could not have confirmed any fix.
   *
   * ### How it works, and why the owner holds it rather than the chips
   *
   * A drag that begins on one chip has to be tracked across every other chip, the gaps, the ungroup
   * zone and off the row entirely. A per-chip listener can only see its own element, so the chips
   * declare what they are — `data-drag-path` to be picked up, `data-drop-path` plus `data-drop-mode`
   * to accept — and this component hit-tests with `elementFromPoint` as the pointer moves.
   *
   * 🔑 **The gesture itself is `PointerDragGesture` in `../drag/pointer-drag.ts`, extracted from
   * here for F8.1** so the form-configuration editor's field rows could share it rather than carry a
   * second copy. What stays in this file is only what is specific to chips: which attribute names a
   * source, how a zone reads as a drop, and what a drop does to the tree. `filter-chips.drag.spec.ts`
   * drives this component end to end and is the proof the extraction changed nothing here.
   *
   * ⚠ **A press is not yet a drag.** Nothing happens until the pointer has moved the shared
   * `DRAG_THRESHOLD_PX`, which is what keeps a plain click, a double-click to edit and a press on the
   * chip's own ✕ button working as they did. Below the threshold this never touches the tree.
   */
  private readonly gesture;
  constructor();
  /**
   * Begins a *potential* drag. Bound on the host, so it sees a press on any chip at any depth.
   *
   * ⚠ Only the primary button, and never on a button inside a chip — the ✕ and Move out controls
   * live there, and swallowing their press would make them unclickable. Both rules are the shared
   * gesture's defaults.
   */
  protected onPointerDown(event: PointerEvent): void;
  /**
   * Applies a completed drag to the tree.
   *
   * ⚠ **Only when something actually moved.** `moveNode` returns the tree untouched for the moves it
   * refuses — a chip dropped on itself, or into its own descendant — and emitting an identical
   * filter is not harmless: the owner treats any `filterChange` as a new filter and resets the grid
   * to page 1, so releasing a chip where you picked it up would silently move someone off the page
   * they were reading.
   */
  private applyDrop;
  /** Escape cancels a pending mark, which is the only way out of the keyboard gesture. */
  protected onEscape(): void;
  private clearGestures;
  /**
   * Sets how every rule combines.
   *
   * ⚠ Applies to the whole set, not to the rule being added — see the class remarks. Emitted
   * immediately rather than on commit, so the chips' connector updates as the choice is made and the
   * grid reflects it without waiting for a rule to be added.
   */
  /**
   * Sets the ROOT combinator, from the editor's Connect with control.
   *
   * ⚠ The chips' own connectors call {@link onToggleCombinator} with a path instead, because they
   * may be flipping a nested group. This one is always the root: the editor builds into the top
   * level.
   */
  protected setCombinator(combinator: FilterCombinator): void;
  protected clear(): void;
  private emit;
  static ɵfac: i0.ɵɵFactoryDeclaration<FilterBuilderComponent<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FilterBuilderComponent<any>, "cms-filter-builder", never, {
    "columns": {
      "alias": "columns";
      "required": true;
      "isSignal": true;
    };
    "filter": {
      "alias": "filter";
      "required": false;
      "isSignal": true;
    };
    "showAddButton": {
      "alias": "showAddButton";
      "required": false;
      "isSignal": true;
    };
  }, {
    "filterChange": "filterChange";
  }, never, never, true, never>;
}
/**
 * What selecting a view asks the grid to do.
 *
 * 🔴 **Selecting ANY view leaves the grid in a determinate order — including the baseline.**
 * `sort` is always a chain, and an empty one means "clear the sort".
 *
 * ⚠ **`null` is gone, and this is its second correction.** 2026-09-14 made saved views clear the
 * sort and kept `null` for the baseline, on the reasoning that "show me everything" is a question
 * about which rows and not which order. In use that read as a defect: sorting under one view and
 * returning to "All Open Contracts" kept the previous view's ordering, with nothing on screen
 * saying why (JFrisbie, 2026-09-16). The baseline now clears like every other entry.
 *
 * 🔑 The type carries no `null` **on purpose**: it is what makes the compiler find every consumer
 * if the question is ever reopened. Four screens held a `view.sort !== null` guard that had become
 * unreachable, and a guard nobody can reach still reads as documentation of a behaviour.
 */
export interface AppliedView {
  readonly group: FilterGroup;
  readonly sort: readonly GridSort[];
  /**
   * The column layout to apply for the session (#1150). Three answers, and absent is the common one:
   *
   *   • **absent**: leave the layout alone. A saved view without a layout, which is every view saved
   *     before #1150, says this.
   *   • **`null`**: return to the person's standing column preference. Only the baseline says this,
   *     because choosing it is how a view is cleared.
   *   • **a layout**: show these columns until the view is cleared, without touching the standing
   *     preference.
   *
   * ⚠ Unlike `sort`, absent is NOT collapsed to "clear": a view that never knew about columns must
   * not undo a layout another view applied, or the order the views are picked in would decide the
   * columns.
   */
  readonly columns?: SavedViewColumns | null;
}
type Panel = 'list' | 'save' | 'manage';
/**
 * The grid's view selector — saved filters, saving the current one, and managing them.
 *
 * ### 🔴 The active view is DERIVED, not tracked
 *
 * There is no "currently selected filter" signal. The name on the button comes from matching the
 * filter the grid is actually using against the saved set ({@link sameGroup}), and that is what
 * makes three otherwise-separate cases work with no code of their own:
 *
 *   • a default filter applied on load shows its name, without the caller telling this component;
 *   • a link someone pasted that happens to match a saved view shows that view's name;
 *   • editing a chip drops the name the moment the filter stops being that view, rather than
 *     leaving the button claiming a view the grid is no longer showing.
 *
 * A tracked id would need syncing with the URL, the default and the builder — three places to
 * disagree, and the disagreement would be a button that lies about what is on screen.
 *
 * ### ⚠ It owns the store rather than emitting store intentions
 *
 * Save, delete and set-default are applied here; only *applying a view* is emitted, because that is
 * the only one the grid has to act on. The alternative — emitting six events for the caller to
 * forward to the store — would put the same three lines in every grid that wants saved views.
 */
export declare class FilterSelectComponent {
  private readonly store;
  /** Which grid these filters belong to. A workspace view is meaningless on the approvals queue. */
  readonly scope: import("@angular/core").InputSignal<string>;
  /** The filter the grid is using right now — matched against the saved set, and what Save stores. */
  readonly filter: import("@angular/core").InputSignal<FilterGroup>;
  /** The sort the grid is using right now, offered to Save behind the checkbox. */
  readonly sorts: import("@angular/core").InputSignal<readonly GridSort<string>[]>;
  /**
   * What to call the unfiltered view.
   *
   * ⚠ Defaults to naming the **status** as well as the absence of a filter, because this grid can
   * only ever fetch open contracts — `contract/list` has no all-statuses option and refuses the
   * call. A bare "All Contracts" would claim more than the screen shows, which is the defect #196
   * is open about.
   */
  readonly baselineLabel: import("@angular/core").InputSignal<string>;
  /**
   * The grid's column layout, offered to Save behind "Include column layout" (#1150). `null`, the
   * default, offers no such box: a grid that does not pass one saves and applies views exactly as
   * before.
   */
  readonly columnLayout: import("@angular/core").InputSignal<SavedViewColumnLayout | null>;
  readonly viewChange: import("@angular/core").OutputEmitterRef<AppliedView>;
  protected readonly panel: import("@angular/core").WritableSignal<Panel>;
  protected readonly draftName: import("@angular/core").WritableSignal<string>;
  /**
   * Whether Save should carry the sorting.
   *
   * Initialised from whether anything is sorted, and re-initialised each time the save panel opens.
   * Saving `[]` is legitimate — it makes selecting the view *clear* the sort — but it is not what
   * someone means when they name a view on an unsorted grid, so it is not the default there.
   */
  protected readonly includeSort: import("@angular/core").WritableSignal<boolean>;
  /**
   * Whether Save should carry the column layout (#1150), built the same way as {@link includeSort}.
   *
   * Initialised from whether the layout differs from the default, and re-initialised each time the
   * save panel opens. Saving the default layout is legitimate (selecting the view would then put the
   * default columns back), but it is not what someone means when they name a view on a grid they
   * never rearranged.
   */
  protected readonly includeColumns: import("@angular/core").WritableSignal<boolean>;
  /** What the layout box says beside its name. */
  protected readonly columnSummary: import("@angular/core").Signal<string>;
  protected readonly savedFilters: import("@angular/core").Signal<readonly SavedFilter[]>;
  protected readonly defaultId: import("@angular/core").Signal<string | null>;
  /**
   * The saved view the grid is showing, or `null` for the baseline. Derived — see the class note.
   *
   * ### 🔴 Group first, then sort as the tie-break — and the order matters
   *
   * Matching on the group alone made **two views with identical criteria and different sorting
   * indistinguishable** (JFrisbie, 2026-09-14): `find` returned whichever was saved first, so the
   * tick and the button name stayed on that one no matter which was clicked. The second view could
   * be applied but never *selected*, which is what the screen reported.
   *
   * ⚠ **The tie-break only runs when there is a tie**, and that is what keeps the fix from causing a
   * worse bug. Making the sort part of the match outright would mean selecting a view and then
   * clicking a column header drops the name to "Custom view" — with the *filter* completely
   * unchanged. The selector is about which rows, so a lone group match stays matched however the
   * grid is ordered; sort only decides *which* of several identical filters is the one on screen.
   *
   * ⚠ A saved view's effective sort is `sort ?? []`, because selecting one now always leaves the
   * grid in a determinate order — see {@link apply}.
   */
  protected readonly activeFilter: import("@angular/core").Signal<SavedFilter | null>;
  /**
   * Whether a filter is applied that is not one of the saved views.
   *
   * 🔴 **This is what makes the button stop claiming to be the baseline** (JFrisbie, 2026-09-10).
   * Without it an ad-hoc filter leaves the control reading exactly as it does when nothing is
   * filtered — the "why is this grid showing so little" confusion the inline chips were introduced
   * to remove, reappearing on the control above them.
   *
   * It also covers the second case in the same ask for free, because the active view is *derived*:
   * select a saved view, add a rule to it, and it stops matching that view's group — so this turns
   * true and the name reverts to Custom view with no separate "modified" state to track.
   */
  protected readonly isCustom: import("@angular/core").Signal<boolean>;
  protected readonly label: import("@angular/core").Signal<string>;
  /**
   * How many rules the custom view carries, for the qualifier beside its name.
   *
   * ⚠ Counts only *complete* rules ({@link activeRuleCount}), so opening the editor does not make
   * the button claim a filter that is not yet filtering anything.
   */
  protected readonly adHocCount: import("@angular/core").Signal<number>;
  protected readonly sortSummary: import("@angular/core").Signal<string>;
  protected readonly canSave: import("@angular/core").Signal<boolean>;
  protected openSave(): void;
  protected openManage(): void;
  protected backToList(): void;
  /** Called on close so the next open starts on the list rather than mid-save. */
  protected reset(): void;
  /**
   * Applies a view, or the baseline.
   *
   * 🔴 **A saved view with no saved sorting CLEARS the grid's sort** (JFrisbie, 2026-09-14) — hence
   * `?? []` rather than the `?? null` this used to emit. Selecting a view now always leaves the grid
   * in a determinate order, so what you see after selecting it is what that view is.
   *
   * ⚠ This deliberately collapses, at apply time, the `undefined`-versus-`[]` distinction that
   * {@link SavedFilter.sort} documents at length: both now clear. The distinction survives in the
   * stored shape and still carries the author's intent — it simply no longer changes what selecting
   * does. Do not "restore" the old behaviour from reading that docstring alone.
   *
   * ⚠ **The baseline clears the sort too, reversed 2026-09-16 (JFrisbie).** It used to emit
   * `null` — "leave the sort alone" — on the reasoning that asking for everything is a question
   * about rows rather than order. On screen that read as a defect rather than a choice: sort under
   * one view, click back to "All Open Contracts", and the previous ordering silently persisted.
   * Every entry in this list now answers the same question the same way.
   *
   * 🔑 **Columns (#1150) are the exception, on purpose.** The baseline asks for the standing
   * preference back (`columns: null`), a view with a layout asks for it, and a view without one says
   * nothing, so it leaves whatever layout is on screen. See {@link AppliedView.columns}.
   */
  protected apply(saved: SavedFilter | null): void;
  protected commitSave(): void;
  protected remove(saved: SavedFilter): void;
  /**
   * Toggles rather than sets, so the star that made a filter the default also clears it.
   *
   * A separate "no default" entry was the alternative and reads worse: it is a fourth thing in a
   * list of filters that is not a filter.
   */
  protected toggleDefault(saved: SavedFilter): void;
  protected onNameInput(value: string): void;
  protected onIncludeSortChange(checked: boolean): void;
  protected onIncludeColumnsChange(checked: boolean): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FilterSelectComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FilterSelectComponent, "cms-filter-select", never, {
    "scope": {
      "alias": "scope";
      "required": true;
      "isSignal": true;
    };
    "filter": {
      "alias": "filter";
      "required": true;
      "isSignal": true;
    };
    "sorts": {
      "alias": "sorts";
      "required": true;
      "isSignal": true;
    };
    "baselineLabel": {
      "alias": "baselineLabel";
      "required": false;
      "isSignal": true;
    };
    "columnLayout": {
      "alias": "columnLayout";
      "required": false;
      "isSignal": true;
    };
  }, {
    "viewChange": "viewChange";
  }, never, never, true, never>;
}
/** One rendered day cell. */
export interface CalendarDay {
  readonly iso: string;
  readonly day: number;
  /** Outside the month being shown — rendered at low emphasis, still selectable. */
  readonly adjacent: boolean;
  readonly today: boolean;
  readonly selected: boolean;
  readonly focused: boolean;
  /** The full date, for the cell's accessible name. */
  readonly label: string;
}
/**
 * **The calendar affordance for control pattern C3** (docs/02a §3).
 *
 * `contract-date.ts` has said since it was written that the calendar popup *"exists but must never
 * be required"*. It did not exist -- the picker a user saw was the browser's own
 * `input type="date"` popup on two screens, unstyled, unstylable, and different in every engine.
 * This is that popup, owned by the application.
 *
 * ### 🔴 It owns rendering and navigation. It owns NO date logic.
 *
 * Every arithmetic and validity question goes to `@cws/shared-utils` -- `addDays`, `addMonths`,
 * `isRealDate`, `fromIsoDate`, `toIsoDate`. That module carries BR-020's century pivot and a
 * comment explaining that a duplicated date rule is how a date silently moves by a hundred years.
 * A picker that did its own month arithmetic would be exactly that second implementation.
 *
 * It emits an ISO string and nothing else. {@link DateInputComponent} treats that identically to a
 * successful parse of typed text, which is what keeps the two input paths indistinguishable to the
 * form.
 *
 * ### ⚠ Six rows are rendered ALWAYS, even when five would do
 *
 * A month needs five rows or six depending on its length and which weekday it starts on. Rendering
 * only what is needed makes the popover change height as the user pages through months, which moves
 * the footer buttons under the pointer between clicks. 42 cells, every month.
 *
 * ### ⚠ Typing is the primary path and this must never interrupt it
 *
 * 02a §1.1: traders type dates at green-screen speed. This opens only from its trigger button --
 * never on focus, never on a keystroke in the text field -- and closes back onto the text input.
 */
export declare class DatePickerComponent {
  /** The currently selected date, ISO, or `null`. */
  readonly value: import("@angular/core").InputSignal<string | null>;
  /** Hides Clear: a required field has no empty state to return to. */
  readonly required: import("@angular/core").InputSignal<boolean>;
  /** Today, injectable so the specs are deterministic rather than dependent on the wall clock. */
  readonly today: import("@angular/core").InputSignal<string>;
  readonly dateSelected: import("@angular/core").OutputEmitterRef<string>;
  readonly cleared: import("@angular/core").OutputEmitterRef<void>;
  readonly dismissed: import("@angular/core").OutputEmitterRef<void>;
  private readonly grid;
  private readonly host;
  /** Which of the three panels is showing. */
  protected readonly view: import("@angular/core").WritableSignal<"day" | "month" | "year">;
  /**
   * The date the roving tabindex is on.
   *
   * 🔑 This is the picker's whole keyboard model: exactly one cell is tabbable and the arrows move
   * *this*, not focus directly. Moving focus without moving a model value is how a grid ends up with
   * two cells that both look focused.
   */
  protected readonly focused: import("@angular/core").WritableSignal<string>;
  /** The month being shown, as the ISO first-of-month. */
  protected readonly viewMonth: import("@angular/core").Signal<string>;
  protected readonly weekdays: readonly {
    short: string;
    full: string;
  }[];
  protected readonly months: readonly string[];
  protected readonly monthLabel: import("@angular/core").Signal<string>;
  /** The decade the year grid is showing, as its first year. */
  protected readonly decadeStart: import("@angular/core").Signal<number>;
  protected readonly decadeYears: import("@angular/core").Signal<number[]>;
  protected readonly decadeLabel: import("@angular/core").Signal<string>;
  /**
   * The 42 cells.
   *
   * Starts from the Sunday on or before the first of the month, so the first row always begins on a
   * Sunday and the weekday header lines up with the column beneath it.
   */
  protected readonly days: import("@angular/core").Signal<readonly CalendarDay[]>;
  /** Clear is pointless on a required field and meaningless when there is nothing to clear. */
  protected readonly showClear: import("@angular/core").Signal<boolean>;
  constructor();
  /** Puts DOM focus on whichever cell the roving tabindex is on. */
  focusActiveCell(): void;
  protected select(iso: string): void;
  protected step(days: number): void;
  protected stepMonths(count: number): void;
  /** Previous/next, meaning whatever the visible panel is paging through. */
  protected page(direction: -1 | 1): void;
  protected pageLabel(direction: -1 | 1): string;
  /** The header label cycles day → month → year, which is the standard drill-up. */
  protected cycleView(): void;
  protected chooseMonth(monthIndex: number): void;
  protected chooseYear(year: number): void;
  protected onToday(): void;
  protected onClear(): void;
  /**
   * The grid's keyboard model.
   *
   * ⚠ Every branch that moves the roving tabindex calls `preventDefault`. Without it the arrow keys
   * also scroll the page behind the popover, and PageUp/PageDown jump it a screen -- so the calendar
   * would page a month while the page moved underneath it.
   */
  protected onGridKeydown(event: KeyboardEvent): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DatePickerComponent, "cms-date-picker", never, {
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "required": {
      "alias": "required";
      "required": false;
      "isSignal": true;
    };
    "today": {
      "alias": "today";
      "required": false;
      "isSignal": true;
    };
  }, {
    "dateSelected": "dateSelected";
    "cleared": "cleared";
    "dismissed": "dismissed";
  }, never, never, true, never>;
}
/**
 * The band at the top of a routed screen — what this page is, and what you can do to it.
 *
 * ### 🔴 Why this exists: four header variants for one thing
 *
 * Before this component the same band was written four ways. The workspace had
 * `items-end justify-between` with `self-start` on its action; the two work queues had a heading and
 * description with no action and no row at all; the approval detail screen had its own
 * `mx-auto max-w-5xl p-4` *inside* a `<main>` that already pads, and was the only screen in the
 * application using `<h1>`/`<h2>` where every other one uses `<h2>`/`<h3>`. The admin area rendered
 * two `<h2>`s on one screen.
 *
 * `text-lg font-semibold text-slate-900 dark:text-white` was hand-repeated in seven templates, which
 * is the drift this replaces: seven chances for a heading to be a different size, and seven places to
 * edit when the type scale moves.
 *
 * ### 🔴 The heading is an `<h2>`, and that is not a style choice
 *
 * **The shell owns the page's only `<h1>`** — the application title in the top bar, stated in
 * `app.html` — so routed content starts at `<h2>` and its sections are `<h3>`. A screen that opens at
 * `<h1>` gives the document two top-level headings, which is a real defect for anyone navigating by
 * heading level rather than a cosmetic one.
 *
 * ### ⚠ Slots rather than a prop per variant
 *
 * The breadcrumb and the actions arrive by content projection. A `breadcrumb` input taking a string,
 * or an `actionLabel`/`actionRoute` pair, would need widening for every screen that wants something
 * slightly different — and the actions on these screens are already a refresh control, an anchor, a
 * pair of buttons and nothing at all. Projection carries whatever the screen has without this
 * component learning about it.
 *
 * ⚠ **The breadcrumb slot is above the heading, inside the same column**, so a screen that has one
 * keeps its `<nav>` and its `aria-current` exactly as written — this component never renders
 * navigation itself and must not, because the record screen's crumb carries query parameters that
 * restore the grid a user came from.
 *
 * ### ⚠ `host: { class: 'block' }`
 *
 * An Angular host is `display: inline` unless told otherwise, and a vertical margin has no effect on
 * an inline box. Every screen here stacks this component with `space-y-*` or `flex-col gap-*`, so
 * without the class the gap beneath the header would silently collapse — measured on this project
 * twice already, on `cms-notices-panel` and on `cms-contract-form`. A spec asserts the class for
 * exactly that reason: the consequence cannot be asserted in jsdom, which performs no layout.
 */
export declare class PageHeaderComponent {
  /** What this page is. Rendered as the screen's `<h2>`. */
  readonly title: import("@angular/core").InputSignal<string>;
  /**
   * A sentence under the heading, or nothing.
   *
   * Empty rather than absent is treated as absent, so a screen binding a computed that resolves to
   * `''` gets no paragraph instead of an empty one taking vertical space.
   */
  readonly description: import("@angular/core").InputSignal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<PageHeaderComponent, "cms-page-header", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["[cmsPageHeaderBreadcrumb]", "[cmsPageHeaderTitleSuffix]", "[cmsPageHeaderActions]"], true, never>;
}
/**
 * **One short form on a single line** — typically the "add a row" form under an admin table: a few
 * labelled inputs and the button that submits them (2026-10-29, the UI consistency pass).
 *
 * ### Why it exists
 *
 * Nine of these rows were hand-written across the admin screens and the record screen's addendum
 * section, and they had drifted three ways: the label sat inline to the LEFT of its input (a `<label>`
 * holding an inline `<span>` and a fixed-width input lays both out on one line), the button was pushed
 * down by a guessed `mt-5` that no longer matched, and the gap was `gap-2` on some and `gap-3` on others.
 * The same detail drifted on every copy, which is the case for a component rather than a class string.
 *
 * ### How it lines up
 *
 * - Fields are `label[cmsFormRowField]`: the label text above the control, `gap-1` between them, any
 *   error or note beneath.
 * - The row is `items-start`, so a field with an error under it grows downward without moving its
 *   input or its neighbours'.
 * - Anything marked `cmsFormRowActions` (the button, a checkbox that belongs beside it) goes in one
 *   group at the end, padded down by exactly one label line (`pt-5`: the `text-xs` label's 1rem line
 *   plus the `gap-1`), so the button sits level with the inputs rather than with their labels.
 * - The group is at least one input tall below that padding (`min-h-[3.625rem]`: the `pt-5` plus a
 *   `scoular-form-input`'s 2.375rem) and centres what it holds. A primary button has no border and is
 *   2px shorter than a secondary one or an input, so top-aligning it left its bottom edge visibly
 *   above the inputs'; centred, it sits level with them.
 *
 * ⚠ `items-end` is NOT the alternative it looks like: under it an error line under one input lifts the
 * button to that error's baseline and off the inputs.
 *
 * Ships no global styles; these libraries render inside foreign hosts (docs/02a §8).
 */
export declare class FormRowComponent {
  static ɵfac: i0.ɵɵFactoryDeclaration<FormRowComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormRowComponent, "cms-form-row", never, {}, {}, never, ["*", "[cmsFormRowActions]"], true, never>;
}
/**
 * **A labelled field in a {@link FormRowComponent}**, on the `<label>` itself so the control projected
 * into it keeps its implicit label and its accessible name is unchanged: the label text, then anything
 * projected after the control (an error line reads as part of the name, as it did before).
 *
 * ```html
 * <label cmsFormRowField="Code">
 *   <input class="scoular-form-input cws:w-28" ... />
 * </label>
 * ```
 *
 * The label text wears the admin forms' label style, the one `cws-admin-trade-unit-select` and the
 * configuration editor already use, so a row reads like the forms around it.
 */
export declare class FormRowFieldComponent {
  /** The label's text, shown above the control. */
  readonly cmsFormRowField: import("@angular/core").InputSignal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormRowFieldComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormRowFieldComponent, "label[cmsFormRowField]", never, {
    "cmsFormRowField": {
      "alias": "cmsFormRowField";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * One field's VALUE on the quiet read-only surface (2026-10-13): what each control renders in place of
 * itself while its `display` input is true, which is the record screen's view mode.
 *
 * A box the size of the control it stands in for (38px, the input's own padding), so view mode keeps
 * the structure of the form and a value sits where its control sits on Edit. But a quiet box: RECESSED,
 * a fill a step darker than the panel with no visible edge, full-contrast text, no caret, no focus ring
 * until the keyboard lands on it (`READ_ONLY_SURFACE_CLASS`). Information, not a disabled control.
 *
 * The control passes the text it would have shown in its box (a combo's `code — description`, a date's
 * `MM/DD/YYYY`, a quantity's grouped figure, a toggle's Yes or No), so formatting stays with the
 * control that owns it and cannot drift into a second copy here.
 *
 * ### 🔴 Why `<output>`
 *
 * It takes a name: `aria-labelledby` points at the field's label, which in view mode is a `<span id>`
 * rather than a `<label for>`, the same way the toggle's switch is named. So a screen reader reads
 * "Origin, Omaha Terminal". Its `.value` is its text, and it is ordinary text, so it can be selected
 * and copied. A `<p>` cannot take a name (`aria-labelledby` is prohibited on a paragraph).
 *
 * `tabindex="0"` keeps every value reachable from the keyboard, as the read-only inputs it replaces
 * were: the 2026-09-01 ruling is that a reader can Tab to any value and copy it.
 *
 * `aria-live="off"` because `<output>` is a polite live region by default, and a refresh that rewrote
 * a hundred values would otherwise read every one of them out.
 *
 * ### Empty is quiet, not absent
 *
 * An empty value keeps its surface, so the field still has its place, but holds only a pale dash, and
 * "Not set" for a screen reader. `data-empty` marks it.
 *
 * ### Multiline
 *
 * A note keeps its own line breaks and wraps; its surface grows with the text from the same one-line
 * floor, so a short note is not a tall empty box.
 */
export declare class FieldValueComponent {
  /** The id the field's label is bound to: the control's own id, so specs and links still find it. */
  readonly controlId: import("@angular/core").InputSignal<string>;
  /** The value as the control would display it. `null`, `undefined` or blank is empty. */
  readonly text: import("@angular/core").InputSignal<string | number | null | undefined>;
  /** A note: wrapped, its own line breaks kept, growing from one line. */
  readonly multiline: import("@angular/core").InputSignal<boolean>;
  protected readonly surfaceClass = "cws:border-transparent cws:bg-slate-100 cws:text-slate-900 cws:dark:bg-slate-900/60 cws:dark:text-slate-100";
  protected readonly empty: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<FieldValueComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FieldValueComponent, "cms-field-value", never, {
    "controlId": {
      "alias": "controlId";
      "required": true;
      "isSignal": true;
    };
    "text": {
      "alias": "text";
      "required": false;
      "isSignal": true;
    };
    "multiline": {
      "alias": "multiline";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** One description in a help tip: a field's text, with the system field it is stored in. */
export interface HelpTipEntry {
  /** Which part this describes, for a tip that covers a compound field's several parts. */
  readonly heading?: string | null;
  /** The system field the value is stored in, shown in small mono above the text. */
  readonly source?: string | null;
  readonly text: string;
}
/**
 * The "i" beside a label, and the description it opens (2026-10-13).
 *
 * One component so a single field and a compound group (the contract number's three parts) offer
 * descriptions the same way, and a group shows ONE "i" covering all its parts rather than one per
 * part, which read as three disconnected icons.
 *
 * CSS-only: `group-hover` and `group-focus-within` open it for a pointer and for the keyboard with no
 * handler. `type="button"` keeps it from submitting a form. The panel is `role="tooltip"` and the
 * button points at it with `aria-describedby`, so a screen reader hears the description when the
 * button is focused.
 *
 * `z-60` puts the panel above an open dropdown, whose `.scoular-dropdown` is `z-50`. At `z-20` the
 * open list of the field below painted over it and cut the description off (2026-10-28).
 *
 * ⚠ Render it OUTSIDE any `<label>`: a button inside a label is nested interactive content, and a
 * click on it would also move focus to the control.
 */
export declare class HelpTipComponent {
  /** What the tip is about, for the button's accessible name: "About <label>". */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The tooltip's id, which the button's `aria-describedby` points at. Unique on the page. */
  readonly tipId: import("@angular/core").InputSignal<string>;
  readonly entries: import("@angular/core").InputSignal<readonly HelpTipEntry[]>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HelpTipComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HelpTipComponent, "cms-help-tip", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "tipId": {
      "alias": "tipId";
      "required": true;
      "isSignal": true;
    };
    "entries": {
      "alias": "entries";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * What a confirmation asks.
 *
 * ⚠ **`confirmLabel` names the ACTION, never "OK".** A dialog whose buttons read OK and Cancel makes
 * the user reconstruct which one discards their work — and on the one this exists for, the wrong
 * choice loses everything they typed. "Discard changes" and "Keep editing" are answerable without
 * re-reading the question.
 */
export interface ConfirmRequest {
  readonly title: string;
  readonly message: string;
  /** The button that proceeds. Names the action. */
  readonly confirmLabel: string;
  /** The button that does not. Defaults to "Cancel". */
  readonly cancelLabel?: string;
  /** Renders the confirming button as destructive. */
  readonly destructive?: boolean;
}
/**
 * The smallest confirmation this repository can have, over the CDK's `Dialog`.
 *
 * ### ⚠ Why CDK `Dialog` and not `cmsDropdown`
 *
 * The same reason the date picker gives: a CDK panel renders **outside** the host element, so
 * `cmsDropdown`'s outside-click test is true for every click *inside* the panel — the dialog would
 * close on its own buttons. CDK `Dialog` also brings the focus trap, the `aria-modal` wiring and the
 * inert background, none of which are worth hand-rolling for a two-button prompt.
 *
 * ### 🔴 `disableClose`, and it is not a preference
 *
 * The caller asking this question is a navigation guard: it has already stopped a route change and is
 * waiting for a boolean. A backdrop click that resolved to "dismissed" would be indistinguishable
 * from "cancel" at the call site, which is fine — but an Escape that resolved to *nothing* would
 * leave the guard waiting forever and the application wedged. So the dialog cannot be dismissed
 * except through a button, and Escape is bound to the cancelling one.
 */
export declare class ConfirmDialogComponent {
  protected readonly data: ConfirmRequest;
  private readonly ref;
  protected confirm(): void;
  protected cancel(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmDialogComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmDialogComponent, "cms-confirm-dialog", never, {}, {}, never, never, true, never>;
}
/**
 * Injects the dialog once and hands back a function that asks a confirmation.
 *
 * 🔴 **A factory rather than a plain `confirmDialog(request)` helper, and the difference is the whole
 * reason this shape exists.** The first caller is a router guard: Angular calls `canDeactivate` long
 * after construction, outside any injection context, so a helper that ran `inject(Dialog)` in its own
 * body would throw at exactly the moment it was needed — and only when the form was dirty, which is
 * the path least likely to be exercised by accident. Injecting at field-initialiser time and
 * returning a closure moves that failure to startup, where it cannot hide.
 *
 * ⚠ **A dismissal answers `false`, not `undefined`.** `DialogRef.closed` emits `undefined` when the
 * dialog goes away without a result, so a caller writing `if (result)` would be right by luck while
 * `result === true` and `result !== false` disagree. Normalising here means every call site can treat
 * the answer as a plain boolean.
 */
export declare function injectConfirm(): (request: ConfirmRequest) => Observable<boolean>;
/** The answer when there is nothing to confirm — kept here so callers do not import rxjs for it. */
export declare const confirmed: () => Observable<boolean>;
/**
 * A component that wants a say before the router leaves it — F3.2f.
 *
 * 🔴 **Structural, not nominal, and that is what keeps the shell's route table free of a feature
 * import.** The guard is registered in `app.routes.ts` beside a `loadComponent` that deliberately
 * imports its component *lazily*; typing the guard to `ContractRecordPageComponent` would pull that
 * component — and everything its barrel re-exports — into `main` eagerly. That is #252's mechanism
 * exactly, and it cost 264 kB the first time.
 */
export interface ConfirmsNavigation {
  /**
   * Answers whether the router may leave.
   *
   * ⚠ Synchronous `true` is the overwhelmingly common answer (nothing is dirty), and returning it as
   * a plain boolean rather than an observable matters: Angular resolves a boolean without a
   * microtask, so an unguarded navigation stays as immediate as it was before the guard existed.
   */
  confirmNavigation(): Observable<boolean> | boolean;
}
/**
 * Stops a navigation away from a component with unsaved work until the user agrees.
 *
 * ### ⚠ What this covers, and the one thing it cannot
 *
 * Every in-application route change goes through the router — the breadcrumb, Cancel, the tab links,
 * the shell's module nav, and the browser Back button — so one guard is genuinely one code path for
 * all of them. What it cannot see is the browser leaving the application altogether: a reload, a
 * closed tab, a typed URL. Only `beforeunload` reaches that, and it is the component's own to
 * register because only the component knows whether it is dirty.
 *
 * ### 🔴 It is deliberately NOT an "are you sure" on every navigation
 *
 * The component decides, and it answers a plain `true` unless something would actually be lost.
 *
 * ⚠ **The tab links are not a case this has to handle, and it is worth knowing why rather than
 * discovering it.** They change only the `tab` query parameter on the same route, so Angular reuses
 * the component and never deactivates it — `canDeactivate` does not run at all. If the tabs ever
 * become separate routes, this guard starts firing on every tab click, and the component's own
 * answer is where that would need handling.
 */
export declare const confirmNavigationGuard: CanDeactivateFn<ConfirmsNavigation>;
/**
 * One link in a breadcrumb trail.
 *
 * ⚠ **`path` is `string | unknown[]`** because `routerLink` takes either, and the callers here use
 * both: a queue path is a literal (`/pricing`), while a per-contract screen is built from segments
 * (`['/contracts', contractNumber]`). Narrowing this to `string` would force every caller with
 * segments to join them by hand, which is where a missing slash gets introduced.
 */
export interface BreadcrumbCrumb {
  readonly label: string;
  readonly path: string | readonly unknown[];
  /**
   * A destination the HOST decides, which wins over {@link path} when present (2026-09-28).
   *
   * For a screen that can be embedded: `path` is the shell's own URL, which a host does not have.
   * `href` is the host's, so middle-click and copy-link still work, and `follow` receives a click so
   * the screen can hand it to the host's navigation.
   */
  readonly link?: BreadcrumbLink;
}
/** A crumb's host-resolved destination. See {@link BreadcrumbCrumb.link}. */
export interface BreadcrumbLink {
  readonly href: string;
  readonly follow: (event: MouseEvent) => void;
}
/**
 * The trail at the top of a detail screen — where you are, and every screen behind you.
 *
 * ### 🔴 Why this exists: three screens, three different breadcrumbs, one of them not a breadcrumb
 *
 * The contract record and the approval review rendered the same `<ol>`/`<li>` trail with `&rsaquo;`
 * separators and `aria-current` on the last crumb. **The pricing screen rendered an anchor, a
 * `<span>/</span>` and a second `<span>`** — no list, no `aria-current`, a different separator, and
 * link styling with no colour. So a user moving between screens one click apart met a control that
 * changed shape, and a screen-reader user met **navigation that did not announce itself as
 * navigation** on exactly one of the three.
 *
 * ⚠ **The markup below is the record screen's, unchanged.** This component was extracted from it
 * rather than designed fresh, so adopting it is a no-op on two of the three screens — which is what
 * makes the third screen's change reviewable as the only visual diff in the PR.
 *
 * ### 🔴 The last crumb is an input, not the last element of {@link crumbs}
 *
 * The current page is never a link, and keeping it out of the array is what makes that structural
 * rather than remembered. A single array with "the last one renders differently" invites a caller to
 * append the current page and get a link to the screen they are already on — which is the one crumb
 * that can never be useful.
 *
 * ⚠ It is a plain string rather than a crumb because callers compute it: the record screen renders
 * `New contract`, `SCW000123 — editing` or the bare number depending on its mode.
 *
 * ### ⚠ `queryParams` rides on EVERY crumb, and that is deliberate
 *
 * All three callers apply one set of parameters to every link, because the state being carried is the
 * queue's — its filter, its sort, the page it was on — and it has to survive whichever crumb the user
 * takes. An approver who presses the middle crumb and then the first one must arrive at the queue
 * they left, not a reset one. A per-crumb parameter set would allow those two to disagree, and the
 * failure would be silent: the crumb still works, the queue is simply gone.
 *
 * ### ⚠ `context` is not a link and must not become one
 *
 * It carries the trade unit, which is the scope everything below is resolved under — the same
 * contract number means a different contract under a different unit. **There is no trade-unit page**;
 * switching is the shell's picker. Rendering it as an anchor would promise a destination that does
 * not exist.
 *
 * ### ⚠ Weight says "crumb", colour says "link"
 *
 * Every crumb is `font-medium`, and the links are additionally `text-scoular-blue`. Do not drop the
 * colour to make them match further — weight is what groups them, colour is the only affordance
 * saying which ones can be pressed, and without it the trail has none.
 *
 * ### ⚠ `host: { class: 'block' }`
 *
 * An Angular host is `display: inline` by default and a vertical margin has no effect on an inline
 * box — the fourth instance of that trap on this project. This sits in `cms-page-header`'s breadcrumb
 * slot above an `<h2>`, so an inline host would let the heading close up against it.
 */
export declare class BreadcrumbComponent {
  /**
   * The screens behind this one, outermost first. **The current page is not among them** — see
   * {@link current}.
   */
  readonly crumbs: import("@angular/core").InputSignal<readonly BreadcrumbCrumb[]>;
  /** The current page. Rendered as `aria-current="page"` and never as a link. */
  readonly current: import("@angular/core").InputSignal<string>;
  /** A leading, non-navigable scope crumb — the trade unit. Absent when no unit is chosen. */
  readonly context: import("@angular/core").InputSignal<string | null>;
  /** Applied to every linked crumb. See the class remarks for why it is not per crumb. */
  readonly queryParams: import("@angular/core").InputSignal<Record<string, string> | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BreadcrumbComponent, "cms-breadcrumb", never, {
    "crumbs": {
      "alias": "crumbs";
      "required": true;
      "isSignal": true;
    };
    "current": {
      "alias": "current";
      "required": true;
      "isSignal": true;
    };
    "context": {
      "alias": "context";
      "required": false;
      "isSignal": true;
    };
    "queryParams": {
      "alias": "queryParams";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
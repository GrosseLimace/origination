import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, ErrorHandler, Injectable, InjectionToken, Injector, ViewContainerRef, computed, effect, inject, makeEnvironmentProviders, provideEnvironmentInitializer, signal, untracked, viewChild } from "@angular/core";
import { BrowserGridColumnStore, DropdownCaretComponent, DropdownDirective, GRID_COLUMN_STORE, LocalSavedFilterStore, SAVED_FILTER_OWNER, SAVED_FILTER_STORE, ShortcutHintsComponent, ShortcutOverlayComponent, StatusBadgeComponent, StatusMessageComponent, StorageRefusals, confirmNavigationGuard, mutationFailed, mutationSucceeded, registerShortcuts, remoteLoaded, remoteLoading } from "@cws/shared-ui";
import { APPROVAL_ACTION_SOURCE, APPROVAL_CONTRACT_SOURCE, APPROVAL_QUEUE_SOURCE, AVAILABILITY_SOURCE, AvailabilityGate, BASIS_LOCATION_ADMIN_SOURCE, BASIS_LOCATION_OPTIONS_SOURCE, CODE_SEARCH_SOURCES_PROVIDER, CONTRACTS_API_URL, CONTRACT_DETAIL_SOURCE, CONTRACT_DOCUMENTS_SOURCE, CONTRACT_EXPORT_SOURCE, CONTRACT_LIST_SOURCE, CONTRACT_LOG_SOURCE, CONTRACT_NUMBER_SOURCE, CONTRACT_STATE_SOURCE, CONTRACT_TEMPLATE_SOURCE, CONTRACT_WRITE_SOURCE, CUSTOMER_SEARCH_SOURCE, CUSTOMER_SOURCE, CWS_EXTERNAL_LINKS, DEFAULT_TRADE_UNIT_SOURCE, FORM_CONFIG_ADMIN_SOURCE, FORM_CONFIG_SOURCE, GRID_COLUMN_OWNER, GRID_COLUMN_PREFERENCE_SOURCE, GRID_COLUMN_SERVER_SOURCE, HOME_GRID_COLUMNS_SOURCE, HttpAvailabilitySource, HttpContractListSource, HttpCustomerSource, HttpLocationSource, HttpMeSource, LOCATION_SOURCE, MARKET_REFERENCE_SOURCE, ME_SOURCE, ORIGIN_DESTINATION_SOURCE, PERMISSION_CATALOG_SOURCE, PRICING_APPROVAL_QUEUE_SOURCE, PRICING_SOURCE, PermissionKeys, ROLE_ADMIN_SOURCE, TRADE_UNIT_VALUES_SOURCE, TRADE_UNIT_VISIBILITY_SOURCE, USER_DIRECTORY_SOURCE, WEIGHT_LIMIT_CHECK_SOURCE, WHATS_NEW_SOURCE, checkExternalLinks, defaultTradeUnitOf, holdsPermission, recordOrigin } from "@cws/domain-contracts";
import { CMS_HOST_CONTEXT, routerHostContext } from "@cws/core-host-context";
import { takeUntilDestroyed, toSignal } from "@angular/core/rxjs-interop";
import { CWS_MSAL_INSTANCE, CmsAuthService, cwsTokenInterceptor, provideCmsAuth, provideCwsHostTokenAuth } from "@cws/core-auth";
import { AccessNotice, PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT, TradeUnitStore } from "@cws/core-state";
import { Subject, defer, filter, firstValueFrom, map, of, shareReplay, startWith, switchMap, take } from "rxjs";
import { ActivatedRoute, NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from "@angular/router";
import { provideHttpClient, withInterceptors } from "@angular/common/http";
import { problemDetailsInterceptor } from "@cws/core-http";
import { APP_INSIGHTS_CONNECTION_STRING, APP_INSIGHTS_ROLE_NAME, AppInsightsErrorHandler, AppInsightsService } from "@cws/core-telemetry";
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
const CWS_ENVIRONMENT_NAME = new InjectionToken("CWS_ENVIRONMENT_NAME");
const CWS_THEME_MODE = new InjectionToken("CWS_THEME_MODE");
const CWS_EMBEDDED = new InjectionToken("CWS_EMBEDDED", { factory: () => false });
const STORAGE_KEY = "cms.theme";
const DARK_CLASS = "dark";
var ThemeStore = class ThemeStore {
	mode = inject(CWS_THEME_MODE, { optional: true }) ?? "own";
	refusals = inject(StorageRefusals);
	preference = signal(read(), ...ngDevMode ? [{ debugName: "preference" }] : /* istanbul ignore next */ []);
	hostDark = signal(false, ...ngDevMode ? [{ debugName: "hostDark" }] : /* istanbul ignore next */ []);
	selected = computed(() => this.preference(), ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	isDark = computed(() => this.mode === "host" ? this.hostDark() : resolve(this.preference()), ...ngDevMode ? [{ debugName: "isDark" }] : /* istanbul ignore next */ []);
	constructor() {
		if (this.mode === "host") {
			this.followHost();
			return;
		}
		this.apply();
	}
	set(preference) {
		this.preference.set(preference);
		if (!write(preference)) this.refusals.report("theme");
		this.apply();
	}
	toggle() {
		this.set(this.isDark() ? "light" : "dark");
	}
	apply() {
		if (this.mode === "host") return;
		const root = globalThis.document?.documentElement;
		if (!root) return;
		root.classList.toggle(DARK_CLASS, this.isDark());
	}
	followHost() {
		const root = globalThis.document?.documentElement;
		if (!root || typeof MutationObserver === "undefined") return;
		this.hostDark.set(root.classList.contains(DARK_CLASS));
		const observer = new MutationObserver(() => this.hostDark.set(root.classList.contains(DARK_CLASS)));
		observer.observe(root, {
			attributes: true,
			attributeFilter: ["class"]
		});
		inject(DestroyRef).onDestroy(() => observer.disconnect());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ThemeStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ThemeStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
function resolve(preference) {
	if (preference !== "system") return preference === "dark";
	return globalThis.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
}
function read() {
	try {
		const stored = globalThis.localStorage?.getItem(STORAGE_KEY);
		return stored === "light" || stored === "dark" || stored === "system" ? stored : "system";
	} catch {
		return "system";
	}
}
function write(preference) {
	try {
		globalThis.localStorage?.setItem(STORAGE_KEY, preference);
		return true;
	} catch {
		return false;
	}
}
function mountBaseOf(mountRoute) {
	return "/" + mountRoute.pathFromRoot.flatMap((route) => route.url.map((segment) => segment.path)).join("/");
}
var CwsMountBase = class CwsMountBase {
	base = signal("/", ...ngDevMode ? [{ debugName: "base" }] : /* istanbul ignore next */ []);
	path = this.base.asReadonly();
	set(path) {
		this.base.set(path);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CwsMountBase,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CwsMountBase
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CwsMountBase,
	decorators: [{ type: Injectable }]
});
function workspaceRoutes(base) {
	const under = (...segments) => [base(), ...segments];
	return {
		contract: (contractNumber) => under("contracts", contractNumber),
		origin: (origin) => under(...segmentsOf(recordOrigin(origin).path)),
		editContract: (contractNumber) => under("contracts", contractNumber, "edit"),
		newContract: () => under("contracts", "new"),
		review: (origin, contractNumber) => {
			const descriptor = recordOrigin(origin);
			return under(...segmentsOf(descriptor.review?.path(contractNumber) ?? descriptor.path));
		},
		module: (module) => under(...MODULE_SEGMENTS[module]),
		priceSequence: (contractNumber, priceSequence, mode) => priceSequence === null ? under("pricing", contractNumber, "sequences", "new") : under("pricing", contractNumber, "sequences", String(priceSequence), ...mode === "edit" ? ["edit"] : [])
	};
}
const MODULE_SEGMENTS = {
	home: [],
	approvals: ["approvals"],
	pricing: ["pricing"],
	"pricing-approvals": ["pricing", "approvals"],
	admin: ["admin"]
};
function segmentsOf(path) {
	return path.split("/").filter((segment) => segment !== "");
}
function workspaceHostContext(router, auth, tradeUnits, theme, base) {
	return routerHostContext(router, {
		tradeUnit: () => tradeUnits.code(),
		user: () => auth.isSignedIn() ? {
			id: auth.userId(),
			username: auth.username(),
			displayName: auth.displayName()
		} : null,
		theme: () => theme.isDark() ? "dark" : "light",
		baseHref: () => globalThis.document?.baseURI ?? "/",
		auth: {
			isSignedIn: () => auth.isSignedIn(),
			accessToken: (scopes) => auth.accessToken(scopes)
		},
		routes: workspaceRoutes(base)
	});
}
var MePermissionContext = class MePermissionContext {
	auth = inject(CmsAuthService);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	source = inject(ME_SOURCE, { optional: true });
	me = toSignal(this.source?.get() ?? of(remoteLoading()), { initialValue: remoteLoading() });
	tokenIsAdmin = computed(() => this.auth.roles().includes("Admin"), ...ngDevMode ? [{ debugName: "tokenIsAdmin" }] : /* istanbul ignore next */ []);
	grants = computed(() => {
		const answer = this.me();
		return answer.status === "loaded" && answer.value.status === "Available" ? answer.value : null;
	}, ...ngDevMode ? [{ debugName: "grants" }] : /* istanbul ignore next */ []);
	isAdmin = () => this.tokenIsAdmin() || (this.grants()?.isAdmin ?? false);
	has = (key) => this.isAdmin() || holdsPermission(this.grants(), this.tradeUnit.code(), key);
	canWriteContracts = () => this.has(PermissionKeys.ContractsUpdate);
	canEditPricing = () => this.has(PermissionKeys.PricesUpdate);
	canApproveContracts = () => this.has(PermissionKeys.ContractsApprove);
	canSeeSystemNotices = () => this.isAdmin();
	canAccessAdmin = () => {
		const grants = this.grants();
		return this.isAdmin() || (grants?.allTradeUnitPermissions ?? []).includes(PermissionKeys.SettingsManage) || (grants?.tradeUnits.some((unit) => unit.permissions.includes(PermissionKeys.SettingsManage)) ?? false);
	};
	writeRefusal = () => {
		const answer = this.me();
		if (this.source === null || answer.status === "loading" || answer.status === "idle") return null;
		if (answer.status === "error" || answer.value.status !== "Available") return {
			kind: "PermissionsUnavailable",
			message: "Permissions could not be read, so changes to CTRM are unavailable right now. Refresh the page to try again."
		};
		const active = this.tradeUnit.code();
		if (active === null || answer.value.onboardingGate !== "Enforce" || answer.value.onboardedTradeUnits.includes(active)) return null;
		return {
			kind: "NotOnboarded",
			message: `Trade unit ${active} is not onboarded yet, so it is read-only for everyone until an administrator, or someone who manages this trade unit's settings, onboards it.`
		};
	};
	settled() {
		if (this.source === null) return Promise.resolve();
		return firstValueFrom(this.source.get().pipe(filter((answer) => answer.status !== "loading"), map(() => void 0)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MePermissionContext,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MePermissionContext
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MePermissionContext,
	decorators: [{ type: Injectable }]
});
const ACCESS_NOTICE_PATH = "access";
const canUseContractsGuard = async (route) => {
	const auth = inject(CmsAuthService);
	const router = inject(Router);
	const base = route.parent ? mountBaseOf(route.parent) : "/";
	if (await auth.ensureSignedIn() && auth.canReadContracts()) return true;
	return router.createUrlTree([base, ACCESS_NOTICE_PATH]);
};
var access_notice_page_component_exports = /* @__PURE__ */ __exportAll({ AccessNoticePageComponent: () => AccessNoticePageComponent });
var AccessNoticePageComponent = class AccessNoticePageComponent {
	auth = inject(CmsAuthService);
	base = inject(CwsMountBase).path;
	state = computed(() => !this.auth.isSignedIn() ? "signed-out" : this.auth.signInBlocked() ? "sign-in-blocked" : this.auth.canReadContracts() ? "ok" : "no-role", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AccessNoticePageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AccessNoticePageComponent,
		isStandalone: true,
		selector: "cws-access-notice-page",
		ngImport: i0,
		template: "<section class=\"cws:mx-auto cws:max-w-2xl cws:py-12\" aria-labelledby=\"cws-access-title\">\n  @switch (state()) {\n    @case ('signed-out') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">Your Contracts sign-in did not complete</h1>\n      <p class=\"cws:mt-3\">Contracts needs a sign-in to show anything. Sign in to try again.</p>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary cws:mt-6\" (click)=\"auth.signIn()\">Sign in</button>\n    }\n    @case ('sign-in-blocked') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">Contracts needs you to sign in again</h1>\n      <p class=\"cws:mt-3\">\n        Your account is signed in, but Contracts could not get a token for it without you: consent may still be\n        needed, or your session has expired. Sign in to grant it or renew it.\n      </p>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary cws:mt-6\" (click)=\"auth.signIn()\">Sign in</button>\n    }\n    @case ('no-role') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">You don't have Contracts access</h1>\n      <p class=\"cws:mt-3\">\n        Your account is signed in and Contracts got a token for it, but the token carries no Contracts role.\n        Ask for Contracts access on this application; once it is granted, sign out and back in.\n      </p>\n    }\n    @case ('ok') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">You have Contracts access</h1>\n      <p class=\"cws:mt-3\">This page appears when a sign-in or a role is missing. Yours are in place.</p>\n      <a class=\"scoular-btn scoular-btn-primary cws:mt-6\" [routerLink]=\"base()\">Open Contracts</a>\n    }\n  }\n</section>\n",
		dependencies: [{
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AccessNoticePageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-access-notice-page",
			imports: [RouterLink],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<section class=\"cws:mx-auto cws:max-w-2xl cws:py-12\" aria-labelledby=\"cws-access-title\">\n  @switch (state()) {\n    @case ('signed-out') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">Your Contracts sign-in did not complete</h1>\n      <p class=\"cws:mt-3\">Contracts needs a sign-in to show anything. Sign in to try again.</p>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary cws:mt-6\" (click)=\"auth.signIn()\">Sign in</button>\n    }\n    @case ('sign-in-blocked') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">Contracts needs you to sign in again</h1>\n      <p class=\"cws:mt-3\">\n        Your account is signed in, but Contracts could not get a token for it without you: consent may still be\n        needed, or your session has expired. Sign in to grant it or renew it.\n      </p>\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary cws:mt-6\" (click)=\"auth.signIn()\">Sign in</button>\n    }\n    @case ('no-role') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">You don't have Contracts access</h1>\n      <p class=\"cws:mt-3\">\n        Your account is signed in and Contracts got a token for it, but the token carries no Contracts role.\n        Ask for Contracts access on this application; once it is granted, sign out and back in.\n      </p>\n    }\n    @case ('ok') {\n      <h1 id=\"cws-access-title\" class=\"cws:text-2xl cws:font-semibold\">You have Contracts access</h1>\n      <p class=\"cws:mt-3\">This page appears when a sign-in or a role is missing. Yours are in place.</p>\n      <a class=\"scoular-btn scoular-btn-primary cws:mt-6\" [routerLink]=\"base()\">Open Contracts</a>\n    }\n  }\n</section>\n"
		}]
	}]
});
const ADMIN_REFUSAL = "Administration needs the Admin role on this application. Your account can view contracts but not administer them.";
const canAccessAdminGuard = async (route) => {
	const auth = inject(CmsAuthService);
	const permissions = inject(PERMISSION_CONTEXT);
	const notice = inject(AccessNotice);
	const router = inject(Router);
	const base = route.parent ? mountBaseOf(route.parent) : "/";
	if (!await auth.ensureSignedIn()) return false;
	if (permissions.canAccessAdmin()) return true;
	await permissions.settled?.();
	if (permissions.canAccessAdmin()) return true;
	notice.refuse(ADMIN_REFUSAL);
	return router.createUrlTree([base]);
};
const SAVED_MESSAGE = {
	account: "Your trade-unit list is saved to your account.",
	"server-memory": "Your trade-unit list is saved, but this environment does not keep it: it is lost when the server restarts.",
	session: "Your trade-unit list is kept for this session only, and is lost when the page reloads.",
	unknown: "Your trade-unit list is saved."
};
function said(outcome) {
	if (outcome === "saved") return mutationSucceeded(SAVED_MESSAGE.unknown);
	if (outcome !== "failed" && outcome.kind === "saved") return mutationSucceeded(SAVED_MESSAGE[outcome.keptIn]);
	return mutationFailed({
		message: "Your last change was not saved. It applies until you sign out.",
		correlationId: outcome === "failed" ? null : outcome.correlationId
	});
}
var TradeUnitVisibilityStore = class TradeUnitVisibilityStore {
	source = inject(TRADE_UNIT_VISIBILITY_SOURCE, { optional: true });
	state = signal("idle", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	hidden = signal(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "hidden" }] : /* istanbul ignore next */ []);
	saves = new Subject();
	lastSave = signal(null, ...ngDevMode ? [{ debugName: "lastSave" }] : /* istanbul ignore next */ []);
	offered = this.source !== null;
	available = computed(() => this.state() === "available", ...ngDevMode ? [{ debugName: "available" }] : /* istanbul ignore next */ []);
	loading = computed(() => this.state() === "loading", ...ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []);
	saveFailed = computed(() => this.lastSave()?.kind === "failure", ...ngDevMode ? [{ debugName: "saveFailed" }] : /* istanbul ignore next */ []);
	saveOutcome = this.lastSave.asReadonly();
	dismissSaveOutcome() {
		this.lastSave.set(null);
	}
	showAll = signal(false, ...ngDevMode ? [{ debugName: "showAll" }] : /* istanbul ignore next */ []);
	hiddenCount = computed(() => this.hidden().size, ...ngDevMode ? [{ debugName: "hiddenCount" }] : /* istanbul ignore next */ []);
	constructor() {
		this.saves.pipe(switchMap((hidden) => this.source.save(hidden)), takeUntilDestroyed(inject(DestroyRef))).subscribe((outcome) => this.lastSave.set(said(outcome)));
	}
	load() {
		if (this.source === null || this.state() !== "idle") return;
		this.state.set("loading");
		this.source.get().pipe(take(1)).subscribe((answer) => {
			if (answer.status === "available") this.hidden.set(new Set(answer.hidden.map((code) => code.trim()).filter((code) => code !== "")));
			this.state.set(answer.status);
		});
	}
	isHidden(code) {
		return this.hidden().has(code);
	}
	setHidden(code, hide) {
		if (!this.available()) return;
		const next = new Set(this.hidden());
		if (hide) next.add(code);
		else next.delete(code);
		this.commit(next);
	}
	unhideAll() {
		if (this.available()) this.commit(/* @__PURE__ */ new Set());
	}
	commit(next) {
		this.hidden.set(next);
		this.saves.next([...next].sort());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TradeUnitVisibilityStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TradeUnitVisibilityStore
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TradeUnitVisibilityStore,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
let instances = 0;
var TradeUnitPickerComponent = class TradeUnitPickerComponent {
	store = inject(TradeUnitStore);
	source = inject(LOCATION_SOURCE);
	router = inject(Router);
	data = toSignal(this.source.list(), { initialValue: remoteLoading() });
	meSource = inject(ME_SOURCE, { optional: true });
	me = toSignal(this.meSource?.get() ?? of(remoteLoading()), { initialValue: remoteLoading() });
	identity = computed(() => {
		const state = this.me();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "identity" }] : /* istanbul ignore next */ []);
	mine = computed(() => new Map((this.identity()?.tradeUnits ?? []).map((unit) => [unit.code, unit])), ...ngDevMode ? [{ debugName: "mine" }] : /* istanbul ignore next */ []);
	notOnboarded(code) {
		const unit = this.mine().get(code);
		return unit !== void 0 && !unit.onboarded;
	}
	defaultSource = inject(DEFAULT_TRADE_UNIT_SOURCE, { optional: true });
	ownDefault = signal(this.defaultSource === null ? { status: "unavailable" } : "loading", ...ngDevMode ? [{ debugName: "ownDefault" }] : /* istanbul ignore next */ []);
	defaultKeptIn = signal(null, ...ngDevMode ? [{ debugName: "defaultKeptIn" }] : /* istanbul ignore next */ []);
	ownDefaultCode = computed(() => {
		const own = this.ownDefault();
		return own !== "loading" && own.status === "available" ? own.code : null;
	}, ...ngDevMode ? [{ debugName: "ownDefaultCode" }] : /* istanbul ignore next */ []);
	effectiveDefault = computed(() => this.ownDefaultCode() ?? defaultTradeUnitOf(this.identity())?.code ?? null, ...ngDevMode ? [{ debugName: "effectiveDefault" }] : /* istanbul ignore next */ []);
	defaultIsOwn = computed(() => this.ownDefaultCode() !== null, ...ngDevMode ? [{ debugName: "defaultIsOwn" }] : /* istanbul ignore next */ []);
	applyDefault = effect(() => {
		if (this.store.code() !== null || this.ownDefault() === "loading") return;
		const preferred = this.effectiveDefault();
		if (preferred !== null) this.store.select(preferred);
	}, ...ngDevMode ? [{ debugName: "applyDefault" }] : /* istanbul ignore next */ []);
	readOwnDefault = this.defaultSource?.get().pipe(take(1)).subscribe({
		next: (answer) => this.ownDefault.set(answer),
		error: () => this.ownDefault.set({ status: "unavailable" })
	});
	setOwnDefault(code) {
		if (this.defaultSource === null) return;
		this.defaultSource.save(code).pipe(take(1)).subscribe((outcome) => {
			if (outcome.kind === "saved") {
				this.ownDefault.set({
					status: "available",
					code
				});
				this.defaultKeptIn.set(outcome.keptIn);
			} else this.defaultKeptIn.set("failed");
		});
	}
	defaultOffered = this.defaultSource !== null;
	nameOf(code) {
		return this.locations().find((location) => location.code === code)?.name ?? "";
	}
	locations = computed(() => {
		const data = this.data();
		return data.status === "loaded" ? [...data.value.locations].sort((left, right) => left.code.localeCompare(right.code)) : [];
	}, ...ngDevMode ? [{ debugName: "locations" }] : /* istanbul ignore next */ []);
	visibility = inject(TradeUnitVisibilityStore, { optional: true });
	hiddenCount = computed(() => this.visibility?.hiddenCount() ?? 0, ...ngDevMode ? [{ debugName: "hiddenCount" }] : /* istanbul ignore next */ []);
	visibleLocations = computed(() => {
		const visibility = this.visibility;
		if (visibility === null || visibility.showAll()) return this.locations();
		const active = this.store.code();
		return this.locations().filter((location) => location.code === active || !visibility.isHidden(location.code));
	}, ...ngDevMode ? [{ debugName: "visibleLocations" }] : /* istanbul ignore next */ []);
	term = signal("", ...ngDevMode ? [{ debugName: "term" }] : /* istanbul ignore next */ []);
	filtered = computed(() => {
		const term = this.term().trim().toLowerCase();
		if (!term) return this.visibleLocations();
		return this.visibleLocations().filter((location) => [
			location.code,
			location.name,
			location.companyCode,
			location.companyName
		].some((text) => (text ?? "").toLowerCase().includes(term)));
	}, ...ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []);
	matchCount = computed(() => this.filtered().length, ...ngDevMode ? [{ debugName: "matchCount" }] : /* istanbul ignore next */ []);
	listboxId = `cws-trade-unit-listbox-${++instances}`;
	activeIndex = signal(-1, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	optionId(code) {
		return `${this.listboxId}-${code}`;
	}
	activeOptionId = computed(() => {
		const location = this.filtered()[this.activeIndex()];
		return location === void 0 ? null : this.optionId(location.code);
	}, ...ngDevMode ? [{ debugName: "activeOptionId" }] : /* istanbul ignore next */ []);
	onTermInput(value) {
		this.term.set(value);
		this.activeIndex.set(value.trim() === "" || this.filtered().length === 0 ? -1 : 0);
	}
	onSearchKeydown(event, picker) {
		const count = this.filtered().length;
		switch (event.key) {
			case "ArrowDown":
				this.moveActive(count === 0 ? -1 : Math.min(this.activeIndex() + 1, count - 1));
				break;
			case "ArrowUp":
				this.moveActive(count === 0 ? -1 : Math.max(this.activeIndex() - 1, 0));
				break;
			case "Home":
				this.moveActive(count === 0 ? -1 : 0);
				break;
			case "End":
				this.moveActive(count - 1);
				break;
			case "Enter": {
				const location = this.filtered()[this.activeIndex()];
				if (location !== void 0) this.choose(location.code, picker);
				break;
			}
			default: return;
		}
		event.preventDefault();
	}
	onOptionKeydown(event) {
		if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
		const option = event.target;
		const sibling = event.key === "ArrowDown" ? option.nextElementSibling : option.previousElementSibling;
		if (sibling instanceof HTMLElement && sibling.getAttribute("role") === "option") sibling.focus();
		event.preventDefault();
	}
	choose(code, picker) {
		this.store.select(code);
		picker.close();
	}
	moveActive(index) {
		this.activeIndex.set(index);
		const id = this.activeOptionId();
		if (id !== null) document.getElementById(id)?.scrollIntoView?.({ block: "nearest" });
	}
	resetSearch() {
		this.term.set("");
		this.activeIndex.set(-1);
		this.visibility?.load();
	}
	failed = computed(() => this.data().status === "error", ...ngDevMode ? [{ debugName: "failed" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const data = this.data();
		return data.status === "error" ? data.error : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	label = computed(() => {
		const code = this.store.code();
		if (!code) return this.failed() ? "Trade units unavailable" : "Select trade unit…";
		const match = this.locations().find((location) => location.code === code);
		return match?.name ? `${code} · ${match.name}` : code;
	}, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	locked = toSignal(this.router.events.pipe(filter((event) => event instanceof NavigationEnd), startWith(null), map(() => isLocked(this.router.routerState.snapshot.root))), { initialValue: false });
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TradeUnitPickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TradeUnitPickerComponent,
		isStandalone: true,
		selector: "cms-trade-unit-picker",
		ngImport: i0,
		template: "<div cmsDropdown #picker=\"cmsDropdown\" class=\"cws:relative\">\n  <!--\n    A ghost button, matching the identity menu, rather than a bordered <select>. The select was the\n    only filled block in a row of text and ~10px taller than everything else, which is most of what\n    made the bar look heavy.\n\n    No visible label: chosen it reads \"0210 · Omaha Terminal\", empty it reads \"Select trade unit…\".\n    The accessible name comes from aria-label so screen-reader users lose nothing.\n  -->\n  <button\n    type=\"button\"\n    class=\"cws:flex cws:h-9 cws:max-w-64 cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:text-[15px] cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:disabled:cursor-not-allowed cws:disabled:opacity-60 cws:disabled:hover:bg-transparent cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\n    aria-label=\"Trade unit\"\n    [attr.aria-expanded]=\"picker.open()\"\n    aria-haspopup=\"listbox\"\n    [disabled]=\"locked()\"\n    [attr.title]=\"locked() ? 'Trade unit is fixed while you are working on a contract' : null\"\n    (click)=\"picker.toggle(); resetSearch()\"\n  >\n    <!-- Truncated: some CTRM location names are long enough to shove the identity menu around. -->\n    <span class=\"truncate\">{{ label() }}</span>\n    <!-- The shared caret (2026-10-28), the same chevron as every list-opening field. -->\n    <cms-dropdown-caret [open]=\"picker.open()\" />\n  </button>\n\n  @if (picker.open()) {\n    <!--\n      Scrolls rather than growing: this list is ~1044 entries against live CTRM, and a panel sized\n      to its content would run off the screen.\n    -->\n    <!--\n      🔴 The PANEL is not the listbox (#764). It holds the search box, the hidden-units note and the\n      failure and no-match messages, and a `listbox` may own only `option`s and `group`s, so axe\n      failed it as critical (aria-required-children). The `listbox` is the wrapper around the groups\n      below; this box only scrolls and keeps the search sticky.\n    -->\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:max-h-96 cws:w-80 cws:overflow-y-auto\">\n      <!--\n        Typeahead over 1044 locations (C-15). Sticky so it stays reachable while the list scrolls —\n        a search box that disappears once you scroll past it is worse than none, because you have to\n        scroll back up to change a query that produced too many results.\n\n        `type=\"search\"` for the browser's own clear affordance. Not autofocused: the panel is opened\n        by a click, and stealing focus into a text field means the arrow keys stop moving through the\n        list for anyone browsing rather than searching.\n      -->\n      <div\n        class=\"cws:sticky cws:top-0 cws:z-10 cws:border-b cws:border-slate-200 cws:bg-white cws:p-2 cws:dark:border-slate-700 cws:dark:bg-slate-800\"\n      >\n        <!--\n          #840: the keyboard path. Arrows, Home and End move an active option the box points at with\n          aria-activedescendant, so focus never leaves it; Enter picks the active option, and typing\n          makes the first match active.\n        -->\n        <input\n          type=\"search\"\n          class=\"scoular-form-input\"\n          placeholder=\"Search code, name or company\"\n          aria-label=\"Search trade units\"\n          [attr.aria-controls]=\"listboxId\"\n          [attr.aria-activedescendant]=\"activeOptionId()\"\n          [value]=\"term()\"\n          (input)=\"onTermInput($any($event.target).value)\"\n          (keydown)=\"onSearchKeydown($event, picker)\"\n        />\n\n        <!--\n          🔴 The escape hatch for the user's hidden list (#103), and it must always be here while\n          anything is hidden. Hiding a unit is a PREFERENCE, not a permission (C-14, C-15 a): a\n          curated list with no way out would become a restriction by accident. Session-only; the\n          saved list is changed from the identity menu.\n\n          Inside the sticky header so it stays reachable however far the list is scrolled.\n        -->\n        <!--\n          The default trade unit (JFrisbie, 2026-10-23): the one a new session opens on, which the user\n          chooses here. Their own choice outranks the one an administrator assigned on the Roles page.\n          Inside the sticky header, so it is reachable however far the list is scrolled.\n        -->\n        @if (defaultOffered) {\n          <div class=\"cws:mt-1.5 cws:flex cws:flex-col cws:gap-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"default-trade-unit\">\n            <span data-testid=\"default-trade-unit-current\">\n              @if (effectiveDefault(); as code) {\n                Default: <span class=\"cws:font-mono\">{{ code }}</span> {{ nameOf(code) }}{{ defaultIsOwn() ? '' : ' (assigned)' }}\n              } @else {\n                No default trade unit.\n              }\n            </span>\n            <span class=\"cws:flex cws:flex-wrap cws:gap-3\">\n              @if (store.code(); as active) {\n                @if (active !== ownDefaultCode()) {\n                  <button\n                    type=\"button\"\n                    class=\"cws:font-medium cws:text-scoular-blue cws:hover:underline\"\n                    (click)=\"setOwnDefault(active)\"\n                  >\n                    Make {{ active }} my default\n                  </button>\n                }\n              }\n              <!--\n                No \"Clear my default\" (JFrisbie, 2026-10-29): rarely used and easy to misclick. A user\n                changes their default by making another trade unit it.\n              -->\n            </span>\n            @switch (defaultKeptIn()) {\n              @case ('account') { <span role=\"status\">Saved to your account.</span> }\n              @case ('browser') { <span role=\"status\">Kept in this browser. Your account cannot store it yet.</span> }\n              @case ('failed') { <span role=\"alert\" class=\"cws:text-red-700 cws:dark:text-scoular-yellow\">Could not be saved. Try again.</span> }\n            }\n          </div>\n        }\n\n        @if (visibility && hiddenCount() > 0) {\n          <div class=\"cws:mt-1.5 cws:flex cws:items-center cws:justify-between cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            <span>{{ hiddenCount() }} hidden by you</span>\n            <button\n              type=\"button\"\n              class=\"cws:font-medium cws:text-scoular-blue cws:hover:underline\"\n              (click)=\"visibility.showAll.set(!visibility.showAll())\"\n            >\n              {{ visibility.showAll() ? 'Hide them again' : 'Show all' }}\n            </button>\n          </div>\n        }\n      </div>\n\n      @if (failure(); as failure) {\n        <!--\n          The reason, not just the fact. \"Sign in again\" and \"your account has no role\" call for\n          opposite actions, and this used to show one fixed sentence for both (#65).\n        -->\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          <p>{{ failure.message }}</p>\n          @if (failure.correlationId; as correlationId) {\n            <!-- docs/02 §9: every user-visible error carries a correlation id to quote to support. -->\n            <p class=\"cws:mt-1 cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              Reference: {{ correlationId }}\n            </p>\n          }\n        </div>\n      } @else if (matchCount() === 0) {\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          No trade unit matches “{{ term() }}”.\n        </div>\n      } @else {\n        <!--\n          🔴 Locations only, with no company headers or groups (#840; ruled by GEstevez on the\n          2026-10-12 walk, confirmed by JFrisbie 2026-10-14; corrects C-15). The listbox owns only\n          options (#764), and the company stays reachable through the search.\n        -->\n        <div role=\"listbox\" aria-label=\"Trade unit\" [id]=\"listboxId\">\n            @for (location of filtered(); track location.code; let i = $index) {\n              <button\n                type=\"button\"\n                role=\"option\"\n                [id]=\"optionId(location.code)\"\n                [attr.aria-selected]=\"store.code() === location.code\"\n                class=\"scoular-dropdown-item\"\n                [class.active]=\"store.code() === location.code\"\n                [class.focused]=\"activeIndex() === i\"\n                [class.cws:ring-2]=\"activeIndex() === i\"\n                [class.cws:ring-inset]=\"activeIndex() === i\"\n                [class.cws:ring-scoular-blue]=\"activeIndex() === i\"\n                [class.cws:dark:ring-sky-400]=\"activeIndex() === i\"\n                (click)=\"choose(location.code, picker)\"\n                (keydown)=\"onOptionKeydown($event)\"\n              >\n                <span class=\"cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-300\">\n                  {{ location.code }}\n                </span>\n                <span class=\"truncate\">{{ location.name }}</span>\n                @if (effectiveDefault() === location.code) {\n                  <span\n                    class=\"cws:ml-auto cws:shrink-0 cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:bg-slate-700 cws:dark:text-slate-100\"\n                    data-testid=\"default-marker\"\n                  >Default</span>\n                }\n                @if (notOnboarded(location.code)) {\n                  <!--\n                    C-15 (d) — one of the caller's own trade units that this application cannot\n                    configure yet.\n\n                    🔴 **Marked, never hidden.** Hiding a trade unit somebody knows they have reads\n                    as a permissions fault, and they would go and ask for access they already hold.\n                    The marker says the truth instead: it is yours, and we are not ready for it.\n\n                    ⚠ Only ever on the caller's OWN units. The panel lists every CTRM location\n                    because reads are deliberately unscoped, so marking the rest would put a warning\n                    on almost every row and make the real ones invisible.\n                  -->\n                  <span\n                    class=\"cws:ml-auto cws:shrink-0 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\n                    title=\"This trade unit is not set up in this application yet\"\n                  >Not set up</span>\n                }\n              </button>\n            }\n        </div>\n      }\n    </div>\n  }\n</div>\n",
		dependencies: [{
			kind: "component",
			type: DropdownCaretComponent,
			selector: "cms-dropdown-caret",
			inputs: ["open", "disabled"]
		}, {
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TradeUnitPickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-trade-unit-picker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownCaretComponent, DropdownDirective],
			template: "<div cmsDropdown #picker=\"cmsDropdown\" class=\"cws:relative\">\n  <!--\n    A ghost button, matching the identity menu, rather than a bordered <select>. The select was the\n    only filled block in a row of text and ~10px taller than everything else, which is most of what\n    made the bar look heavy.\n\n    No visible label: chosen it reads \"0210 · Omaha Terminal\", empty it reads \"Select trade unit…\".\n    The accessible name comes from aria-label so screen-reader users lose nothing.\n  -->\n  <button\n    type=\"button\"\n    class=\"cws:flex cws:h-9 cws:max-w-64 cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:text-[15px] cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:disabled:cursor-not-allowed cws:disabled:opacity-60 cws:disabled:hover:bg-transparent cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\n    aria-label=\"Trade unit\"\n    [attr.aria-expanded]=\"picker.open()\"\n    aria-haspopup=\"listbox\"\n    [disabled]=\"locked()\"\n    [attr.title]=\"locked() ? 'Trade unit is fixed while you are working on a contract' : null\"\n    (click)=\"picker.toggle(); resetSearch()\"\n  >\n    <!-- Truncated: some CTRM location names are long enough to shove the identity menu around. -->\n    <span class=\"truncate\">{{ label() }}</span>\n    <!-- The shared caret (2026-10-28), the same chevron as every list-opening field. -->\n    <cms-dropdown-caret [open]=\"picker.open()\" />\n  </button>\n\n  @if (picker.open()) {\n    <!--\n      Scrolls rather than growing: this list is ~1044 entries against live CTRM, and a panel sized\n      to its content would run off the screen.\n    -->\n    <!--\n      🔴 The PANEL is not the listbox (#764). It holds the search box, the hidden-units note and the\n      failure and no-match messages, and a `listbox` may own only `option`s and `group`s, so axe\n      failed it as critical (aria-required-children). The `listbox` is the wrapper around the groups\n      below; this box only scrolls and keeps the search sticky.\n    -->\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:max-h-96 cws:w-80 cws:overflow-y-auto\">\n      <!--\n        Typeahead over 1044 locations (C-15). Sticky so it stays reachable while the list scrolls —\n        a search box that disappears once you scroll past it is worse than none, because you have to\n        scroll back up to change a query that produced too many results.\n\n        `type=\"search\"` for the browser's own clear affordance. Not autofocused: the panel is opened\n        by a click, and stealing focus into a text field means the arrow keys stop moving through the\n        list for anyone browsing rather than searching.\n      -->\n      <div\n        class=\"cws:sticky cws:top-0 cws:z-10 cws:border-b cws:border-slate-200 cws:bg-white cws:p-2 cws:dark:border-slate-700 cws:dark:bg-slate-800\"\n      >\n        <!--\n          #840: the keyboard path. Arrows, Home and End move an active option the box points at with\n          aria-activedescendant, so focus never leaves it; Enter picks the active option, and typing\n          makes the first match active.\n        -->\n        <input\n          type=\"search\"\n          class=\"scoular-form-input\"\n          placeholder=\"Search code, name or company\"\n          aria-label=\"Search trade units\"\n          [attr.aria-controls]=\"listboxId\"\n          [attr.aria-activedescendant]=\"activeOptionId()\"\n          [value]=\"term()\"\n          (input)=\"onTermInput($any($event.target).value)\"\n          (keydown)=\"onSearchKeydown($event, picker)\"\n        />\n\n        <!--\n          🔴 The escape hatch for the user's hidden list (#103), and it must always be here while\n          anything is hidden. Hiding a unit is a PREFERENCE, not a permission (C-14, C-15 a): a\n          curated list with no way out would become a restriction by accident. Session-only; the\n          saved list is changed from the identity menu.\n\n          Inside the sticky header so it stays reachable however far the list is scrolled.\n        -->\n        <!--\n          The default trade unit (JFrisbie, 2026-10-23): the one a new session opens on, which the user\n          chooses here. Their own choice outranks the one an administrator assigned on the Roles page.\n          Inside the sticky header, so it is reachable however far the list is scrolled.\n        -->\n        @if (defaultOffered) {\n          <div class=\"cws:mt-1.5 cws:flex cws:flex-col cws:gap-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"default-trade-unit\">\n            <span data-testid=\"default-trade-unit-current\">\n              @if (effectiveDefault(); as code) {\n                Default: <span class=\"cws:font-mono\">{{ code }}</span> {{ nameOf(code) }}{{ defaultIsOwn() ? '' : ' (assigned)' }}\n              } @else {\n                No default trade unit.\n              }\n            </span>\n            <span class=\"cws:flex cws:flex-wrap cws:gap-3\">\n              @if (store.code(); as active) {\n                @if (active !== ownDefaultCode()) {\n                  <button\n                    type=\"button\"\n                    class=\"cws:font-medium cws:text-scoular-blue cws:hover:underline\"\n                    (click)=\"setOwnDefault(active)\"\n                  >\n                    Make {{ active }} my default\n                  </button>\n                }\n              }\n              <!--\n                No \"Clear my default\" (JFrisbie, 2026-10-29): rarely used and easy to misclick. A user\n                changes their default by making another trade unit it.\n              -->\n            </span>\n            @switch (defaultKeptIn()) {\n              @case ('account') { <span role=\"status\">Saved to your account.</span> }\n              @case ('browser') { <span role=\"status\">Kept in this browser. Your account cannot store it yet.</span> }\n              @case ('failed') { <span role=\"alert\" class=\"cws:text-red-700 cws:dark:text-scoular-yellow\">Could not be saved. Try again.</span> }\n            }\n          </div>\n        }\n\n        @if (visibility && hiddenCount() > 0) {\n          <div class=\"cws:mt-1.5 cws:flex cws:items-center cws:justify-between cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            <span>{{ hiddenCount() }} hidden by you</span>\n            <button\n              type=\"button\"\n              class=\"cws:font-medium cws:text-scoular-blue cws:hover:underline\"\n              (click)=\"visibility.showAll.set(!visibility.showAll())\"\n            >\n              {{ visibility.showAll() ? 'Hide them again' : 'Show all' }}\n            </button>\n          </div>\n        }\n      </div>\n\n      @if (failure(); as failure) {\n        <!--\n          The reason, not just the fact. \"Sign in again\" and \"your account has no role\" call for\n          opposite actions, and this used to show one fixed sentence for both (#65).\n        -->\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          <p>{{ failure.message }}</p>\n          @if (failure.correlationId; as correlationId) {\n            <!-- docs/02 §9: every user-visible error carries a correlation id to quote to support. -->\n            <p class=\"cws:mt-1 cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              Reference: {{ correlationId }}\n            </p>\n          }\n        </div>\n      } @else if (matchCount() === 0) {\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          No trade unit matches “{{ term() }}”.\n        </div>\n      } @else {\n        <!--\n          🔴 Locations only, with no company headers or groups (#840; ruled by GEstevez on the\n          2026-10-12 walk, confirmed by JFrisbie 2026-10-14; corrects C-15). The listbox owns only\n          options (#764), and the company stays reachable through the search.\n        -->\n        <div role=\"listbox\" aria-label=\"Trade unit\" [id]=\"listboxId\">\n            @for (location of filtered(); track location.code; let i = $index) {\n              <button\n                type=\"button\"\n                role=\"option\"\n                [id]=\"optionId(location.code)\"\n                [attr.aria-selected]=\"store.code() === location.code\"\n                class=\"scoular-dropdown-item\"\n                [class.active]=\"store.code() === location.code\"\n                [class.focused]=\"activeIndex() === i\"\n                [class.cws:ring-2]=\"activeIndex() === i\"\n                [class.cws:ring-inset]=\"activeIndex() === i\"\n                [class.cws:ring-scoular-blue]=\"activeIndex() === i\"\n                [class.cws:dark:ring-sky-400]=\"activeIndex() === i\"\n                (click)=\"choose(location.code, picker)\"\n                (keydown)=\"onOptionKeydown($event)\"\n              >\n                <span class=\"cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-300\">\n                  {{ location.code }}\n                </span>\n                <span class=\"truncate\">{{ location.name }}</span>\n                @if (effectiveDefault() === location.code) {\n                  <span\n                    class=\"cws:ml-auto cws:shrink-0 cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:bg-slate-700 cws:dark:text-slate-100\"\n                    data-testid=\"default-marker\"\n                  >Default</span>\n                }\n                @if (notOnboarded(location.code)) {\n                  <!--\n                    C-15 (d) — one of the caller's own trade units that this application cannot\n                    configure yet.\n\n                    🔴 **Marked, never hidden.** Hiding a trade unit somebody knows they have reads\n                    as a permissions fault, and they would go and ask for access they already hold.\n                    The marker says the truth instead: it is yours, and we are not ready for it.\n\n                    ⚠ Only ever on the caller's OWN units. The panel lists every CTRM location\n                    because reads are deliberately unscoped, so marking the rest would put a warning\n                    on almost every row and make the real ones invisible.\n                  -->\n                  <span\n                    class=\"cws:ml-auto cws:shrink-0 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\n                    title=\"This trade unit is not set up in this application yet\"\n                  >Not set up</span>\n                }\n              </button>\n            }\n        </div>\n      }\n    </div>\n  }\n</div>\n"
		}]
	}]
});
function isLocked(route) {
	return route.data["tradeUnitLocked"] === true || route.children.some(isLocked);
}
const WHATS_NEW_LAST_SEEN_KEY = "cws.whatsNew.lastSeenVersion";
var WhatsNewStore = class WhatsNewStore {
	source = inject(WHATS_NEW_SOURCE, { optional: true });
	state = signal("idle", ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	all = signal([], ...ngDevMode ? [{ debugName: "all" }] : /* istanbul ignore next */ []);
	commit = signal(null, ...ngDevMode ? [{ debugName: "commit" }] : /* istanbul ignore next */ []);
	lastSeen = signal(readLastSeen(), ...ngDevMode ? [{ debugName: "lastSeen" }] : /* istanbul ignore next */ []);
	releases = this.all.asReadonly();
	build = this.commit.asReadonly();
	loading = computed(() => this.state() === "loading", ...ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []);
	loaded = computed(() => this.state() === "loaded", ...ngDevMode ? [{ debugName: "loaded" }] : /* istanbul ignore next */ []);
	unavailable = computed(() => this.state() === "unavailable", ...ngDevMode ? [{ debugName: "unavailable" }] : /* istanbul ignore next */ []);
	currentVersion = computed(() => this.all()[0]?.version ?? null, ...ngDevMode ? [{ debugName: "currentVersion" }] : /* istanbul ignore next */ []);
	unseen = computed(() => {
		const all = this.all();
		if (all.length === 0) return [];
		const seen = this.lastSeen();
		if (seen === null) return [all[0]];
		const index = all.findIndex((release) => release.version === seen);
		return index === -1 ? [all[0]] : all.slice(0, index);
	}, ...ngDevMode ? [{ debugName: "unseen" }] : /* istanbul ignore next */ []);
	hasUnseen = computed(() => this.unseen().length > 0, ...ngDevMode ? [{ debugName: "hasUnseen" }] : /* istanbul ignore next */ []);
	load() {
		if (this.state() !== "idle") return;
		if (this.source === null) {
			this.state.set("unavailable");
			return;
		}
		this.state.set("loading");
		this.source.releases().subscribe((result) => {
			if (result.status === "available") {
				this.all.set(result.releases);
				this.state.set("loaded");
			} else this.state.set("unavailable");
		});
		this.source.build().subscribe((commit) => this.commit.set(commit));
	}
	markCurrentAsSeen() {
		const current = this.currentVersion();
		if (current === null) return;
		this.lastSeen.set(current);
		try {
			localStorage.setItem(WHATS_NEW_LAST_SEEN_KEY, current);
		} catch {}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WhatsNewStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WhatsNewStore
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WhatsNewStore,
	decorators: [{ type: Injectable }]
});
function readLastSeen() {
	try {
		return localStorage.getItem(WHATS_NEW_LAST_SEEN_KEY);
	} catch {
		return null;
	}
}
function buildLine(release, commit, environment) {
	if (commit === null) return null;
	const parts = [release === null ? "Unreleased" : `Release ${release}`, `Build ${commit}`];
	if (environment) parts.push(environment);
	return parts.join(" · ");
}
var UserMenuComponent = class UserMenuComponent {
	auth = inject(CmsAuthService);
	sortedRoles = computed(() => [...this.auth.roles()].sort((a, b) => rankOf(a) - rankOf(b)), ...ngDevMode ? [{ debugName: "sortedRoles" }] : /* istanbul ignore next */ []);
	badgeTone(role) {
		return role === ADMIN ? "negative" : "neutral";
	}
	theme = inject(ThemeStore);
	themeMode = inject(CWS_THEME_MODE, { optional: true }) ?? "own";
	embedded = inject(CWS_EMBEDDED);
	visibility = inject(TradeUnitVisibilityStore, { optional: true });
	whatsNew = inject(WhatsNewStore, { optional: true });
	environmentName = inject(CWS_ENVIRONMENT_NAME, { optional: true });
	whatsNewBuildLine = computed(() => this.embedded || this.whatsNew === null ? null : buildLine(this.whatsNew.currentVersion(), this.whatsNew.build(), this.environmentName), ...ngDevMode ? [{ debugName: "whatsNewBuildLine" }] : /* istanbul ignore next */ []);
	curating = signal(false, ...ngDevMode ? [{ debugName: "curating" }] : /* istanbul ignore next */ []);
	curationPanel = signal(null, ...ngDevMode ? [{ debugName: "curationPanel" }] : /* istanbul ignore next */ []);
	curationHost = viewChild("curationHost", {
		...ngDevMode ? { debugName: "curationHost" } : /* istanbul ignore next */ {},
		read: ViewContainerRef
	});
	mountCuration = effect(() => {
		const host = this.curationHost();
		const panel = this.curationPanel();
		if (host && panel) host.createComponent(panel);
	}, ...ngDevMode ? [{ debugName: "mountCuration" }] : /* istanbul ignore next */ []);
	toggleCuration() {
		this.curating.update((open) => !open);
		if (this.curationPanel() === null) import("./cws-workspace-trade-unit-curation.component-B2DB3rgZ.mjs").then((m) => this.curationPanel.set(m.TradeUnitCurationComponent));
	}
	themeOptions = [
		{
			value: "light",
			label: "Light"
		},
		{
			value: "dark",
			label: "Dark"
		},
		{
			value: "system",
			label: "System"
		}
	];
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: UserMenuComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: UserMenuComponent,
		isStandalone: true,
		selector: "cms-user-menu",
		viewQueries: [{
			propertyName: "curationHost",
			first: true,
			predicate: ["curationHost"],
			descendants: true,
			read: ViewContainerRef,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:items-center cws:gap-2\">\n  <!--\n    \"No role\" stays OUTSIDE the menu, deliberately.\n\n    Its whole value is being visible without a click: a signed-in user with no app role gets a 403\n    on every request (#36), and that is indistinguishable from a broken application unless the\n    missing role is on screen. The normal role sits inside the menu, where it is reference rather\n    than a warning — so the common case is uncluttered and the failure case is loud.\n  -->\n  @if (!auth.canReadContracts()) {\n    <cms-status-badge tone=\"caution\" title=\"Your account has no CWS app role\">\n      No role\n    </cms-status-badge>\n  }\n\n  <!--\n    An avatar rather than the full name. The name was the widest thing in the bar and it tells you\n    something you already know; the avatar is the conventional affordance and the name is one click\n    away inside.\n\n    The accessible name still carries it — a circle reading \"JF\" would otherwise announce as \"JF\"\n    and tell a screen-reader user nothing.\n  -->\n  <button\n    type=\"button\"\n    class=\"cws:flex cws:h-9 cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\n    [attr.aria-label]=\"auth.displayName() + ' — account menu'\"\n    [attr.aria-expanded]=\"menu.open()\"\n    [attr.aria-controls]=\"menu.open() ? 'cws-account-panel' : null\"\n    (click)=\"menu.toggle()\"\n  >\n    <!--\n      No chevron. An avatar in the top-right corner is a near-universal affordance for an account\n      menu, so the arrow was restating it. The machine-readable cue is unaffected: the button still\n      carries aria-expanded (and aria-controls while open), so assistive technology reports it as a\n      disclosure and its state — which is what the arrow was doing for sighted users only. Not\n      aria-haspopup=\"menu\" since #764: the panel is a group, not a menu.\n    -->\n    <!--\n      The Outlook profile photo where the account has one, initials where it does not.\n\n      Not a progressive enhancement on top of the initials but a straight either/or, because the two\n      must never both paint: a photo layered over a coloured circle flashes the initials on every\n      load, and a transparent PNG would show them through it permanently.\n\n      `auth.photoUrl()` is null until Graph answers, so initials render first and are replaced. That\n      swap is the intended behaviour rather than a flicker to fix — blocking the shell's first paint\n      on a decorative image would be the worse trade (see CmsAuthService.refresh).\n\n      aria-hidden on both: the button's own aria-label already carries the user's name, so announcing\n      \"JF\" or an image alt beside it would say the same thing twice. The <img> keeps an empty alt as\n      well, which is what marks it decorative to any tool that ignores aria-hidden.\n    -->\n    @if (auth.photoUrl(); as photo) {\n      <img\n        [src]=\"photo\"\n        alt=\"\"\n        aria-hidden=\"true\"\n        width=\"32\"\n        height=\"32\"\n        class=\"cws:size-8 cws:rounded-full cws:object-cover\"\n      />\n    } @else {\n      <span\n        aria-hidden=\"true\"\n        class=\"cws:flex cws:size-8 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-[13px] cws:font-semibold cws:text-white\"\n      >\n        {{ auth.initials() }}\n      </span>\n    }\n  </button>\n\n  @if (menu.open()) {\n    <!--\n      `w-72` because the identity block is now a 48px avatar beside a full email address, and the\n      panel's own `min-w-[12rem]` would wrap `JFrisbie@scoular.com` onto two lines.\n    -->\n    <!--\n      🔴 **A GROUP, not a `role=\"menu\"`** (#764), the same ruling `grid-export` records. A menu may own\n      only `menuitem`s, and this panel holds an identity card, the role badges, the theme switch and\n      the trade-unit curation, so axe failed it as critical (aria-required-children). The trigger is a\n      disclosure: `aria-expanded` plus `aria-controls`, no `aria-haspopup`.\n    -->\n    <div id=\"cws-account-panel\" class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-72\" role=\"group\" aria-label=\"Account\">\n      <!--\n        Photo, name and sign-in address as one row — the Originations arrangement.\n\n        The avatar is repeated from the trigger deliberately: at 48px it is the confirmation that you\n        are on the right account, which a 32px chip in the corner cannot be. Same either/or as the\n        trigger, so the initials never paint behind a photo.\n\n        aria-hidden on both, because the name is right beside them in text — announcing an avatar and\n        then the name it stands for says the same thing twice.\n\n        `min-w-0` and `truncate` are load-bearing: a flex child defaults to `min-width: auto`, so\n        without it a long address widens the panel instead of ellipsing.\n      -->\n      <div class=\"cws:flex cws:items-center cws:gap-3 cws:px-4 cws:py-3\">\n        @if (auth.photoUrl(); as photo) {\n          <img\n            [src]=\"photo\"\n            alt=\"\"\n            aria-hidden=\"true\"\n            width=\"48\"\n            height=\"48\"\n            class=\"cws:size-12 cws:shrink-0 cws:rounded-full cws:object-cover\"\n          />\n        } @else {\n          <span\n            aria-hidden=\"true\"\n            class=\"cws:flex cws:size-12 cws:shrink-0 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-base cws:font-semibold cws:text-white\"\n          >\n            {{ auth.initials() }}\n          </span>\n        }\n\n        <div class=\"cws:min-w-0\">\n          <div class=\"truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n            {{ auth.displayName() }}\n          </div>\n          @if (auth.username(); as username) {\n            <!--\n              The sign-in name, not just the display name: two people can share a display name, and\n              someone opening this menu is usually trying to work out *which* account they are on.\n            -->\n            <div class=\"truncate cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" [title]=\"username\">\n              {{ username }}\n            </div>\n          }\n        </div>\n      </div>\n\n      <div class=\"scoular-dropdown-divider\"></div>\n\n      <!--\n        Roles as badges rather than a comma-joined string (JFrisbie, 2026-08-31).\n\n        Admin carries the same variant as the environment indicator, because it is the one role that\n        changes what the application will let you do — it should read as a flag, not as a label.\n        Everything else is neutral grey: reference rather than a warning.\n\n        Ordered most-privileged-first by the component, NOT in arrival order. `roles` is a JSON array\n        whose sequence Entra does not specify, so an account holding both could read \"User, Admin\"\n        one session and \"Admin, User\" the next.\n\n        The text is 12px, matching the environment indicator (JFrisbie, 2026-08-31). That is\n        `.scoular-badge`'s own size, so there is nothing to override — an earlier revision kept the\n        list's original 14px and needed an inner <span> to carry it, because `text-sm` on the badge\n        itself is silently overruled by the unlayered design-system rule. Taking the badge's own size\n        removes that workaround rather than inverting it.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n      -->\n      <div class=\"scoular-dropdown-header\">Role</div>\n      <div class=\"cws:px-4 cws:pb-2\">\n        @if (auth.canReadContracts()) {\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1.5\">\n            @for (role of sortedRoles(); track role) {\n              <cms-status-badge [tone]=\"badgeTone(role)\">{{ role }}</cms-status-badge>\n            }\n          </div>\n        } @else {\n          <span class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">\n            None — contract data will not load\n          </span>\n        }\n      </div>\n\n      <!--\n        Appearance. Three explicit choices rather than a two-state switch, because \"System\" is a real\n        answer and not a synonym for either: someone whose OS flips to dark at sunset wants the app to\n        follow, and a plain toggle cannot express that.\n\n        `aria-pressed` on each, and the menu stays open — changing theme is something you want to see\n        the result of, and closing the menu would hide most of the surface that just changed.\n\n        Absent in host theme mode (D-9): the host owns the page's theme.\n      -->\n      @if (themeMode === 'own') {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <div class=\"scoular-dropdown-header\">Appearance</div>\n        <div role=\"group\" aria-label=\"Appearance\" class=\"cws:flex cws:gap-1 cws:px-4 cws:pb-2\">\n          @for (option of themeOptions; track option.value) {\n            <button\n              type=\"button\"\n              class=\"scoular-btn scoular-btn-sm cws:flex-1\"\n              [class.scoular-btn-primary]=\"theme.selected() === option.value\"\n              [class.scoular-btn-outline]=\"theme.selected() !== option.value\"\n              [attr.aria-pressed]=\"theme.selected() === option.value\"\n              (click)=\"theme.set(option.value)\"\n            >\n              {{ option.label }}\n            </button>\n          }\n        </div>\n      }\n\n      <!--\n        Which trade units the picker shows (#103), self-service, beside the theme switch.\n\n        🔴 A PREFERENCE, NOT A PERMISSION (C-14, C-15 a): it shortens the picker and denies nothing,\n        and the panel says so. Collapsed until asked for, because it is the full trade unit list.\n      -->\n      @if (visibility) {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <div class=\"scoular-dropdown-header\">Trade units</div>\n        <div class=\"cws:px-4 cws:pb-2\">\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-sm scoular-btn-outline cws:w-full\"\n            [attr.aria-expanded]=\"curating()\"\n            (click)=\"toggleCuration()\"\n          >\n            {{ curating() ? 'Done choosing trade units' : 'Choose trade units in the picker…' }}\n          </button>\n        </div>\n\n        <!-- Loaded on first open, to keep it out of the initial bundle (#678). -->\n        @if (curating()) {\n          <ng-container #curationHost />\n          @if (curationPanel() === null) {\n            <p class=\"cws:px-4 cws:pb-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading…</p>\n          }\n        }\n      }\n\n      <!--\n        What's new (#1204), standalone only: under a host the host announces its own releases. The dot\n        stays until the current release is acknowledged, from the dialog or by opening the page, so a\n        dialog dismissed in a browser that refuses localStorage is still findable here.\n      -->\n      @if (!embedded && whatsNew) {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <a\n          routerLink=\"/whats-new\"\n          class=\"scoular-dropdown-item cws:flex cws:items-center cws:justify-between cws:gap-2\"\n          (click)=\"menu.close()\"\n        >\n          <span>What's new</span>\n          @if (whatsNew.hasUnseen()) {\n            <span class=\"cws:size-2 cws:shrink-0 cws:rounded-full cws:bg-scoular-red\" aria-hidden=\"true\"></span>\n            <span class=\"cws:sr-only\">(unread)</span>\n          }\n        </a>\n      }\n\n      <!-- Absent when embedded (D-18): the host owns the session. -->\n      @if (!embedded) {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <button\n          type=\"button\"\n          class=\"scoular-dropdown-item\"\n          (click)=\"menu.close(); auth.signOut()\"\n        >\n          Sign out\n        </button>\n      }\n\n      <!-- The build, so a support ticket can say exactly what someone was running (#1204). -->\n      @if (whatsNewBuildLine(); as line) {\n        <div class=\"cws:border-t cws:border-slate-100 cws:px-4 cws:py-2 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400\">\n          {{ line }}\n        </div>\n      }\n    </div>\n  }\n</div>\n",
		dependencies: [
			{
				kind: "directive",
				type: DropdownDirective,
				selector: "[cmsDropdown]",
				exportAs: ["cmsDropdown"]
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "component",
				type: StatusBadgeComponent,
				selector: "cms-status-badge",
				inputs: ["tone", "small"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: UserMenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-user-menu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				DropdownDirective,
				RouterLink,
				StatusBadgeComponent
			],
			template: "<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:items-center cws:gap-2\">\n  <!--\n    \"No role\" stays OUTSIDE the menu, deliberately.\n\n    Its whole value is being visible without a click: a signed-in user with no app role gets a 403\n    on every request (#36), and that is indistinguishable from a broken application unless the\n    missing role is on screen. The normal role sits inside the menu, where it is reference rather\n    than a warning — so the common case is uncluttered and the failure case is loud.\n  -->\n  @if (!auth.canReadContracts()) {\n    <cms-status-badge tone=\"caution\" title=\"Your account has no CWS app role\">\n      No role\n    </cms-status-badge>\n  }\n\n  <!--\n    An avatar rather than the full name. The name was the widest thing in the bar and it tells you\n    something you already know; the avatar is the conventional affordance and the name is one click\n    away inside.\n\n    The accessible name still carries it — a circle reading \"JF\" would otherwise announce as \"JF\"\n    and tell a screen-reader user nothing.\n  -->\n  <button\n    type=\"button\"\n    class=\"cws:flex cws:h-9 cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\n    [attr.aria-label]=\"auth.displayName() + ' — account menu'\"\n    [attr.aria-expanded]=\"menu.open()\"\n    [attr.aria-controls]=\"menu.open() ? 'cws-account-panel' : null\"\n    (click)=\"menu.toggle()\"\n  >\n    <!--\n      No chevron. An avatar in the top-right corner is a near-universal affordance for an account\n      menu, so the arrow was restating it. The machine-readable cue is unaffected: the button still\n      carries aria-expanded (and aria-controls while open), so assistive technology reports it as a\n      disclosure and its state — which is what the arrow was doing for sighted users only. Not\n      aria-haspopup=\"menu\" since #764: the panel is a group, not a menu.\n    -->\n    <!--\n      The Outlook profile photo where the account has one, initials where it does not.\n\n      Not a progressive enhancement on top of the initials but a straight either/or, because the two\n      must never both paint: a photo layered over a coloured circle flashes the initials on every\n      load, and a transparent PNG would show them through it permanently.\n\n      `auth.photoUrl()` is null until Graph answers, so initials render first and are replaced. That\n      swap is the intended behaviour rather than a flicker to fix — blocking the shell's first paint\n      on a decorative image would be the worse trade (see CmsAuthService.refresh).\n\n      aria-hidden on both: the button's own aria-label already carries the user's name, so announcing\n      \"JF\" or an image alt beside it would say the same thing twice. The <img> keeps an empty alt as\n      well, which is what marks it decorative to any tool that ignores aria-hidden.\n    -->\n    @if (auth.photoUrl(); as photo) {\n      <img\n        [src]=\"photo\"\n        alt=\"\"\n        aria-hidden=\"true\"\n        width=\"32\"\n        height=\"32\"\n        class=\"cws:size-8 cws:rounded-full cws:object-cover\"\n      />\n    } @else {\n      <span\n        aria-hidden=\"true\"\n        class=\"cws:flex cws:size-8 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-[13px] cws:font-semibold cws:text-white\"\n      >\n        {{ auth.initials() }}\n      </span>\n    }\n  </button>\n\n  @if (menu.open()) {\n    <!--\n      `w-72` because the identity block is now a 48px avatar beside a full email address, and the\n      panel's own `min-w-[12rem]` would wrap `JFrisbie@scoular.com` onto two lines.\n    -->\n    <!--\n      🔴 **A GROUP, not a `role=\"menu\"`** (#764), the same ruling `grid-export` records. A menu may own\n      only `menuitem`s, and this panel holds an identity card, the role badges, the theme switch and\n      the trade-unit curation, so axe failed it as critical (aria-required-children). The trigger is a\n      disclosure: `aria-expanded` plus `aria-controls`, no `aria-haspopup`.\n    -->\n    <div id=\"cws-account-panel\" class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-72\" role=\"group\" aria-label=\"Account\">\n      <!--\n        Photo, name and sign-in address as one row — the Originations arrangement.\n\n        The avatar is repeated from the trigger deliberately: at 48px it is the confirmation that you\n        are on the right account, which a 32px chip in the corner cannot be. Same either/or as the\n        trigger, so the initials never paint behind a photo.\n\n        aria-hidden on both, because the name is right beside them in text — announcing an avatar and\n        then the name it stands for says the same thing twice.\n\n        `min-w-0` and `truncate` are load-bearing: a flex child defaults to `min-width: auto`, so\n        without it a long address widens the panel instead of ellipsing.\n      -->\n      <div class=\"cws:flex cws:items-center cws:gap-3 cws:px-4 cws:py-3\">\n        @if (auth.photoUrl(); as photo) {\n          <img\n            [src]=\"photo\"\n            alt=\"\"\n            aria-hidden=\"true\"\n            width=\"48\"\n            height=\"48\"\n            class=\"cws:size-12 cws:shrink-0 cws:rounded-full cws:object-cover\"\n          />\n        } @else {\n          <span\n            aria-hidden=\"true\"\n            class=\"cws:flex cws:size-12 cws:shrink-0 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-base cws:font-semibold cws:text-white\"\n          >\n            {{ auth.initials() }}\n          </span>\n        }\n\n        <div class=\"cws:min-w-0\">\n          <div class=\"truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n            {{ auth.displayName() }}\n          </div>\n          @if (auth.username(); as username) {\n            <!--\n              The sign-in name, not just the display name: two people can share a display name, and\n              someone opening this menu is usually trying to work out *which* account they are on.\n            -->\n            <div class=\"truncate cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" [title]=\"username\">\n              {{ username }}\n            </div>\n          }\n        </div>\n      </div>\n\n      <div class=\"scoular-dropdown-divider\"></div>\n\n      <!--\n        Roles as badges rather than a comma-joined string (JFrisbie, 2026-08-31).\n\n        Admin carries the same variant as the environment indicator, because it is the one role that\n        changes what the application will let you do — it should read as a flag, not as a label.\n        Everything else is neutral grey: reference rather than a warning.\n\n        Ordered most-privileged-first by the component, NOT in arrival order. `roles` is a JSON array\n        whose sequence Entra does not specify, so an account holding both could read \"User, Admin\"\n        one session and \"Admin, User\" the next.\n\n        The text is 12px, matching the environment indicator (JFrisbie, 2026-08-31). That is\n        `.scoular-badge`'s own size, so there is nothing to override — an earlier revision kept the\n        list's original 14px and needed an inner <span> to carry it, because `text-sm` on the badge\n        itself is silently overruled by the unlayered design-system rule. Taking the badge's own size\n        removes that workaround rather than inverting it.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n      -->\n      <div class=\"scoular-dropdown-header\">Role</div>\n      <div class=\"cws:px-4 cws:pb-2\">\n        @if (auth.canReadContracts()) {\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1.5\">\n            @for (role of sortedRoles(); track role) {\n              <cms-status-badge [tone]=\"badgeTone(role)\">{{ role }}</cms-status-badge>\n            }\n          </div>\n        } @else {\n          <span class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">\n            None — contract data will not load\n          </span>\n        }\n      </div>\n\n      <!--\n        Appearance. Three explicit choices rather than a two-state switch, because \"System\" is a real\n        answer and not a synonym for either: someone whose OS flips to dark at sunset wants the app to\n        follow, and a plain toggle cannot express that.\n\n        `aria-pressed` on each, and the menu stays open — changing theme is something you want to see\n        the result of, and closing the menu would hide most of the surface that just changed.\n\n        Absent in host theme mode (D-9): the host owns the page's theme.\n      -->\n      @if (themeMode === 'own') {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <div class=\"scoular-dropdown-header\">Appearance</div>\n        <div role=\"group\" aria-label=\"Appearance\" class=\"cws:flex cws:gap-1 cws:px-4 cws:pb-2\">\n          @for (option of themeOptions; track option.value) {\n            <button\n              type=\"button\"\n              class=\"scoular-btn scoular-btn-sm cws:flex-1\"\n              [class.scoular-btn-primary]=\"theme.selected() === option.value\"\n              [class.scoular-btn-outline]=\"theme.selected() !== option.value\"\n              [attr.aria-pressed]=\"theme.selected() === option.value\"\n              (click)=\"theme.set(option.value)\"\n            >\n              {{ option.label }}\n            </button>\n          }\n        </div>\n      }\n\n      <!--\n        Which trade units the picker shows (#103), self-service, beside the theme switch.\n\n        🔴 A PREFERENCE, NOT A PERMISSION (C-14, C-15 a): it shortens the picker and denies nothing,\n        and the panel says so. Collapsed until asked for, because it is the full trade unit list.\n      -->\n      @if (visibility) {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <div class=\"scoular-dropdown-header\">Trade units</div>\n        <div class=\"cws:px-4 cws:pb-2\">\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-sm scoular-btn-outline cws:w-full\"\n            [attr.aria-expanded]=\"curating()\"\n            (click)=\"toggleCuration()\"\n          >\n            {{ curating() ? 'Done choosing trade units' : 'Choose trade units in the picker…' }}\n          </button>\n        </div>\n\n        <!-- Loaded on first open, to keep it out of the initial bundle (#678). -->\n        @if (curating()) {\n          <ng-container #curationHost />\n          @if (curationPanel() === null) {\n            <p class=\"cws:px-4 cws:pb-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading…</p>\n          }\n        }\n      }\n\n      <!--\n        What's new (#1204), standalone only: under a host the host announces its own releases. The dot\n        stays until the current release is acknowledged, from the dialog or by opening the page, so a\n        dialog dismissed in a browser that refuses localStorage is still findable here.\n      -->\n      @if (!embedded && whatsNew) {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <a\n          routerLink=\"/whats-new\"\n          class=\"scoular-dropdown-item cws:flex cws:items-center cws:justify-between cws:gap-2\"\n          (click)=\"menu.close()\"\n        >\n          <span>What's new</span>\n          @if (whatsNew.hasUnseen()) {\n            <span class=\"cws:size-2 cws:shrink-0 cws:rounded-full cws:bg-scoular-red\" aria-hidden=\"true\"></span>\n            <span class=\"cws:sr-only\">(unread)</span>\n          }\n        </a>\n      }\n\n      <!-- Absent when embedded (D-18): the host owns the session. -->\n      @if (!embedded) {\n        <div class=\"scoular-dropdown-divider\"></div>\n\n        <button\n          type=\"button\"\n          class=\"scoular-dropdown-item\"\n          (click)=\"menu.close(); auth.signOut()\"\n        >\n          Sign out\n        </button>\n      }\n\n      <!-- The build, so a support ticket can say exactly what someone was running (#1204). -->\n      @if (whatsNewBuildLine(); as line) {\n        <div class=\"cws:border-t cws:border-slate-100 cws:px-4 cws:py-2 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400\">\n          {{ line }}\n        </div>\n      }\n    </div>\n  }\n</div>\n"
		}]
	}],
	propDecorators: { curationHost: [{
		type: i0.ViewChild,
		args: ["curationHost", {
			read: ViewContainerRef,
			isSignal: true
		}]
	}] }
});
const ADMIN = "Admin";
const ROLE_RANK = {
	[ADMIN]: 0,
	User: 1
};
function rankOf(role) {
	return ROLE_RANK[role] ?? Number.MAX_SAFE_INTEGER;
}
const WHATS_NEW_PATH = "whats-new";
var WhatsNewAnnouncerComponent = class WhatsNewAnnouncerComponent {
	store = inject(WhatsNewStore, { optional: true });
	router = inject(Router);
	injector = inject(Injector);
	destroyRef = inject(DestroyRef);
	announced = false;
	constructor() {
		const store = this.store;
		if (store === null) return;
		store.load();
		effect(() => {
			const unseen = store.unseen();
			if (unseen.length === 0 || this.announced) return;
			this.announced = true;
			untracked(() => {
				if (onWhatsNewPage(this.router.url)) return;
				import("./cws-workspace-whats-new-dialog.component-BSJXKOOV.mjs").then((m) => {
					if (this.destroyRef.destroyed || !store.hasUnseen()) return;
					m.openWhatsNewDialog(this.injector, unseen).subscribe(() => store.markCurrentAsSeen());
				});
			});
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WhatsNewAnnouncerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: WhatsNewAnnouncerComponent,
		isStandalone: true,
		selector: "cms-whats-new-announcer",
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WhatsNewAnnouncerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-whats-new-announcer",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: ""
		}]
	}],
	ctorParameters: () => []
});
function onWhatsNewPage(url) {
	return url.split(/[?#]/)[0].endsWith(`/${WHATS_NEW_PATH}`);
}
const MODULES = [
	{
		module: "home",
		label: "Home",
		exact: true,
		accessKey: "h"
	},
	{
		module: "approvals",
		label: "Approvals",
		exact: false,
		accessKey: "a"
	},
	{
		module: "pricing",
		label: "Pricing",
		exact: false,
		accessKey: "p"
	},
	{
		module: "admin",
		label: "Admin",
		exact: false,
		allowed: (p) => p.canAccessAdmin()
	}
];
const MODULE_PATHS = MODULES.map((entry) => `/${MODULE_SEGMENTS[entry.module].join("/")}`);
var CwsWorkspaceComponent = class CwsWorkspaceComponent {
	auth = inject(CmsAuthService);
	host = inject(ElementRef);
	embedded = inject(CWS_EMBEDDED);
	availability = inject(AvailabilityGate);
	permissions = inject(PERMISSION_CONTEXT);
	permissionsUnavailable = computed(() => this.permissions.writeRefusal?.()?.kind === "PermissionsUnavailable", ...ngDevMode ? [{ debugName: "permissionsUnavailable" }] : /* istanbul ignore next */ []);
	accessNotice = inject(AccessNotice);
	modules = computed(() => MODULES.filter((entry) => entry.allowed?.(this.permissions) ?? true).map((entry) => ({
		...entry,
		commands: this.commandsFor(entry.module)
	})), ...ngDevMode ? [{ debugName: "modules" }] : /* istanbul ignore next */ []);
	mountBase = inject(CwsMountBase);
	accessMessage = this.accessNotice.message;
	storageRefusals = inject(StorageRefusals);
	logoUnavailable = signal(false, ...ngDevMode ? [{ debugName: "logoUnavailable" }] : /* istanbul ignore next */ []);
	environmentLabel = signal(environmentLabelOf(inject(CWS_ENVIRONMENT_NAME)), ...ngDevMode ? [{ debugName: "environmentLabel" }] : /* istanbul ignore next */ []);
	constructor() {
		inject(CwsMountBase).set(mountBaseOf(inject(ActivatedRoute).snapshot));
		let painted = false;
		inject(Router).events.pipe(filter((event) => event instanceof NavigationEnd), takeUntilDestroyed()).subscribe(() => {
			if (this.accessNotice.message() === null) {
				painted = false;
				return;
			}
			if (painted) {
				this.accessNotice.clear();
				painted = false;
			} else painted = true;
		});
		this.registerGlobalShortcuts();
	}
	registerGlobalShortcuts() {
		const router = inject(Router);
		const within = () => this.host.nativeElement;
		const navigation = MODULES.filter((module) => module.accessKey !== void 0).map((module) => ({
			keys: `alt+${module.accessKey}`,
			scope: "shell",
			label: `Go to ${module.label}`,
			group: "Navigation",
			allowInTextInput: true,
			within,
			available: () => this.modules().some((entry) => entry.module === module.module),
			run: () => {
				router.navigate([...this.commandsFor(module.module)]);
			}
		}));
		registerShortcuts([
			...navigation,
			{
				keys: "alt+n",
				scope: "shell",
				label: "New contract",
				group: "Navigation",
				allowInTextInput: true,
				within,
				available: () => this.permissions.canWriteContracts(),
				run: () => {
					router.navigate([
						this.mountBase.path(),
						"contracts",
						"new"
					]);
				}
			},
			{
				keys: "alt+d",
				scope: "shell",
				label: "The browser’s address bar, not a Contract Workspace key",
				group: "Kept by the browser",
				note: "Admin has no key"
			},
			{
				keys: "alt+f",
				scope: "shell",
				label: "The browser’s menu, not a Contract Workspace key",
				group: "Kept by the browser",
				note: "/ searches the grid"
			},
			{
				keys: "f5",
				scope: "shell",
				label: "Reloads the page",
				group: "Kept by the browser",
				note: "use the grid’s Refresh button to refresh the grid"
			}
		]);
	}
	dismissAccessNotice() {
		this.accessNotice.clear();
	}
	commandsFor(module) {
		return [this.mountBase.path(), ...MODULE_SEGMENTS[module]];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CwsWorkspaceComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CwsWorkspaceComponent,
		isStandalone: true,
		selector: "cws-workspace",
		host: { classAttribute: "cws:flex cws:min-h-dvh cws:flex-col" },
		ngImport: i0,
		template: "<!--\n  Shell chrome (docs/02 §1.1, 02a §6).\n\n  Top bar rather than a left rail. docs/02 §1.1 says \"Left rail / top bar navigation (final layout\n  in 02a)\" and 02a never resolved it, so this fills a gap rather than contradicting a decision — but\n  it is a decision, and a rail is still a live option if the module count grows.\n\n  Grouped by meaning rather than by convenience:\n    left   — the Scoular mark and the environment instance\n    then   — the modules you move between\n    middle — CONTEXT: what you are operating on (the trade unit)\n    right  — IDENTITY: who you are, and how to stop being them\n\n  The logo is the tallest thing here at 40px, so it sets the bar height at roughly 66px. Every\n  *control* is 32px, so nothing else sets an accidental maximum: the trade-unit picker used to be a\n  bordered <select> at ~38px and was most of why the bar looked heavy.\n\n  `py-2` was tried and reverted when the bar was single-line: at 49px it left 8px around a 32px\n  control and read cramped, and the 8px reclaimed is about one sixth of a table row.\n\n  The h1 is the brand link, so the heading and the primary navigation are one element rather than\n  two things competing for the same corner. Routed content starts at h2.\n-->\n<header class=\"cws:border-b cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-800\">\n  <!--\n    Width is capped at 1800px here and on <main>, and the two must stay in step — a top bar wider or\n    narrower than the content below it makes the nav and the grid look misaligned by a few pixels,\n    which reads as a rendering bug rather than a layout choice.\n\n    Widened from `max-w-7xl` (1280px), which left large margins on the monitors people actually use\n    (JFrisbie, 2026-08-26). Still capped rather than uncapped: this bar is chrome, but <main> also\n    carries the contract form, and an unbounded container puts its labelled fields on 2000px+ lines\n    on an ultrawide. 1800px fills a 1920 screen nearly edge to edge and leaves margins beyond that.\n  -->\n  <div class=\"cws:mx-auto cws:flex cws:max-w-[1800px] cws:flex-wrap cws:items-center cws:gap-x-6 cws:gap-y-3 cws:px-6 cws:py-3\">\n    <!--\n      Brand lockup, matching the Originations header: the Scoular mark and wordmark with the\n      application name beneath it.\n\n      Deliberately mirroring a sibling Scoular application rather than inventing our own arrangement.\n\n      🔴 Standalone only (D-17): when CWS_EMBEDDED is true the host's own header carries the brand,\n      and this lockup is not rendered at all. Its two images resolve relative to the page, so under a\n      host's prefix they would 404 and it would degrade to the text fallback below.\n\n      The h1 is a direct child of the header row, with no wrapper. It had one while the environment\n      chip sat beside the application name and the pair needed `items-end`; the chip now sits with the\n      module links, so the wrapper was a div that grouped one element.\n\n      The column is a FIXED 232px, and that number is derived rather than chosen: `scoular-logo.webp`\n      is 1692×292, so at `h-10` (40px) it renders 1692 ÷ 292 × 40 = 231.7px. Pinning it lets the\n      wordmark alignment below be expressed in the logo's own coordinate space, which is the only way\n      to line text up with a glyph inside a raster image.\n    -->\n    @if (!embedded) {\n    <h1 class=\"cws:m-0 cws:w-[232px] cws:shrink-0\">\n        <a\n          [routerLink]=\"[mountBase.path()]\"\n          class=\"cws:block cws:rounded cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\n          aria-label=\"Contract Workspace — contract list\"\n        >\n          @if (logoUnavailable()) {\n            <span class=\"cws:text-xl cws:font-semibold cws:text-scoular-gray cws:dark:text-slate-200\">SCOULAR</span>\n          } @else {\n            <img\n              src=\"scoular-logo.webp\"\n              alt=\"\"\n              class=\"cws:h-10 cws:w-full cws:dark:hidden\"\n              (error)=\"logoUnavailable.set(true)\"\n            />\n            <img\n              src=\"scoular-logo-dark.webp\"\n              alt=\"\"\n              class=\"cws:hidden cws:h-10 cws:w-full cws:dark:block\"\n              (error)=\"logoUnavailable.set(true)\"\n            />\n          }\n\n          <!--\n            The application name, under the mark and aligned to the wordmark (JFrisbie, 2026-08-31).\n\n            ### Why this is an <svg> and not a <span>\n\n            Two requirements a span cannot meet: it must start under the **S** of SCOULAR — not at\n            the logo's left edge, which is the pinwheel — and it must not run past the **R**. Both\n            are positions *inside a raster image*, so they can only be expressed as fractions of that\n            image, and the right edge additionally depends on font metrics that differ by platform.\n\n            The viewBox is the logo's own pixel grid (1692 wide), so the two numbers below are\n            measured in the same units as the image and scale with it automatically:\n\n              x=378         the left edge of the S      (22.3% of 1692)\n              textLength    ends at 1600, short of the R's right edge at ~1620\n\n            `lengthAdjust=\"spacing\"` makes the text span exactly that width by distributing the\n            difference **between** glyphs — it stretches the tracking, never the letterforms, so the\n            type is not distorted. That is what fills the wordmark's width regardless of which font\n            actually resolves, which a hand-tuned `tracking-[…]` cannot promise.\n\n            aria-hidden, because the link's own aria-label already reads \"Contract Workspace —\n            contract list\"; without it the accessible name is computed from the label AND this text\n            and a screen reader says the words twice.\n          -->\n          <svg\n            aria-hidden=\"true\"\n            focusable=\"false\"\n            class=\"cws:mt-0.5 cws:block cws:w-full\"\n            viewBox=\"0 0 1692 92\"\n          >\n            <text\n              x=\"378\"\n              y=\"76\"\n              textLength=\"1222\"\n              lengthAdjust=\"spacing\"\n              font-size=\"84\"\n              font-weight=\"600\"\n              class=\"cws:fill-scoular-gray cws:dark:fill-slate-300\"\n            >\n              CONTRACT WORKSPACE\n            </text>\n          </svg>\n        </a>\n    </h1>\n    }\n\n    <!--\n      Which *instance* you are in, where the trade unit says what you are operating on. Absent in\n      production, where saying so adds nothing — so the clutter only exists where it earns its place.\n      Fixed height and a minimum width so a two-letter DEV and a five-letter LOCAL read as the same\n      control rather than one being a nub.\n\n      A sibling of the brand and the module nav rather than a child of either (JFrisbie, 2026-08-31),\n      so the header row's own `items-center` centres it against the full bar height and it sits on the\n      module links' line. Deliberately outside `<nav aria-label=\"Modules\">`: it is not somewhere you\n      can navigate to, and putting it inside would offer it to a screen-reader user as a fifth module.\n    -->\n    @if (environmentLabel(); as label) {\n      <!--\n        The `info` tone — a teal tint.\n\n        A solid `scoular-blue` fill with white text was tried on 2026-08-31 to match the Originations\n        header and reverted the same day: JFrisbie preferred the original. Recorded so it is not\n        re-proposed as an obvious improvement. It was not a contrast problem — white on #00588E is\n        7.5:1 — it simply looked wrong here, where the chip sits on a white bar rather than a dark one.\n\n        ⚠ **This is a CHIP borrowing the badge's tint, not a status.** It says which instance you are\n        in; nothing about it has a state that could be positive or negative. It goes through\n        `cms-status-badge` anyway so the tone-to-class mapping stays in one file — but if a future\n        change makes the tone vocabulary mean something narrower, this is the call site to reconsider\n        rather than the one to bend the vocabulary around.\n\n        The sizing utilities are this chip's own: a fixed height and a minimum width so a three-letter\n        DEV and a five-letter LOCAL read as the same control. They compose with the component's host\n        classes rather than replacing them (the primitive has a test for that).\n\n        ⚠ `font-semibold` USED TO DO NOTHING here. `.scoular-badge` sets `font-medium`, and before the\n        design system was layered on 2026-09-16 the class beat the utility — measured in Edge at\n        weight 500 before and 600 after. This chip is the one place in the application where that\n        change is visible.\n      -->\n      <cms-status-badge\n        tone=\"info\"\n        class=\"cws:h-6 cws:min-w-16 cws:shrink-0 cws:justify-center cws:px-3 cws:font-semibold cws:uppercase cws:tracking-wide\"\n      >\n        {{ label }}\n      </cms-status-badge>\n    }\n\n    @if (auth.isSignedIn()) {\n      <!--\n        The modules of docs/02 §1.1 this caller may see — the list is MODULES in workspace.component.ts.\n\n        🔴 **Admin is gated and the other three are not**, which is deliberate rather than partial\n        work. Approvals and Pricing are READABLE by any signed-in user, so hiding those queues would\n        withhold information a User is entitled to; what is gated there is the decision controls\n        inside them. Admin differs in kind — every request it makes carries CwsAdmin and would 403.\n\n        ⚠ **The route is guarded too, and the nav alone would not be enough.** Hiding a link does\n        nothing about a bookmark, a pasted URL or the back button. See permission.guards.ts.\n\n        ⚠ Still NOT the per-trade-unit matrix — that is F1.3 / #138, BACKEND, blocked on a business\n        ruling. This is one boolean resolved in one file, shaped so the matrix can replace it without\n        touching a screen.\n\n        `routerLinkActive` with `exact` on Home only — otherwise \"/\" matches every route and Home\n        would look active everywhere.\n\n        `text-[15px]`, one step up from `text-sm` (JFrisbie, 2026-08-31). The bar is ~66px tall\n        because the 40px logo sets it, and 14px links left it looking under-filled. 15px rather than\n        `text-base`: 16px starts competing with the page's own headings for weight, and the ask was\n        \"a little bigger\", not a size class up. The trade-unit picker and the avatar move with it, so\n        the row still reads as one set of controls rather than three different sizes.\n      -->\n      <!--\n        🔴 **The active module is marked three ways, and none of them moves the layout**\n        (JFrisbie, 2026-09-14). It was a pale tint and a colour change, which on a white bar was\n        easy to miss — and on a four-item nav \"which section am I in\" is the one question the bar\n        exists to answer.\n\n        Now: a **2px bottom accent**, a stronger background, and higher-contrast text.\n\n        ⚠ **The border is always present and only changes colour.** Adding a 2px border on\n        activation would shift every link up by 2px as you navigate, and the whole bar with it.\n        `rounded-t` rather than `rounded` for the same reason the accent is at the bottom — a\n        rounded bottom edge would clip it.\n\n        ⚠ **The font weight deliberately does NOT change.** `font-medium` to `font-semibold` widens\n        the text, which moves every sibling along the bar on each navigation — a jitter that reads\n        as the page settling badly.\n\n        🔴 **`ariaCurrentWhenActive` is not decoration.** Three visual cues say nothing to a screen\n        reader; `aria-current=\"page\"` is what makes the active module obvious without sight of it,\n        and it was missing entirely.\n\n        🔴 **The active style keys off that same attribute, never off `routerLinkActive` classes**\n        (#545's clean room, measured in a host's production build). Applied as plain classes, the\n        active text colour and border lost to the inactive `text-slate-600` / `border-transparent`\n        in the same attribute: equal specificity, and the inactive rules happen to be emitted later\n        in the stylesheet. So the active module showed only a faint tint, and before the `cws:`\n        prefix, nothing at all. `aria-[current=page]:` variants are emitted after the base utilities,\n        so they win. `routerLinkActive=\"\"` stays only to drive `ariaCurrentWhenActive`.\n      -->\n      <nav aria-label=\"Modules\" class=\"cws:flex cws:items-center cws:gap-1\">\n        @for (entry of modules(); track entry.module) {\n          <a\n            [routerLink]=\"entry.commands\"\n            routerLinkActive=\"\"\n            [routerLinkActiveOptions]=\"{ exact: entry.exact }\"\n            ariaCurrentWhenActive=\"page\"\n            class=\"cws:rounded-t cws:border-b-2 cws:border-transparent cws:px-3 cws:py-1.5 cws:text-[15px] cws:font-medium cws:text-slate-600 cws:transition-colors cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60 cws:aria-[current=page]:border-scoular-blue cws:aria-[current=page]:bg-slate-100 cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:border-sky-400 cws:dark:aria-[current=page]:bg-slate-700 cws:dark:aria-[current=page]:text-sky-300\"\n          >\n            {{ entry.label }}\n          </a>\n        }\n      </nav>\n\n      <!-- CONTEXT: what you are operating as. Pushed right of the modules, left of identity. -->\n      <div class=\"cws:ml-auto cws:flex cws:items-center cws:gap-3\">\n        <cms-trade-unit-picker />\n\n        <!--\n          No CTRM availability light here, deliberately.\n\n          docs/02a §5 handles unavailability with *gates*, not a status dot: CTRM down is a\n          full-screen block page, the night run is a persistent amber banner with mutations\n          disabled. Both are far louder than a dot, so the dot's only remaining job would be saying\n          \"fine\" during the normal case — the least informative thing a control can do. There is\n          also no signal to bind it to: `operation/statuses` reports only the night run, so\n          reachability has to be inferred from a call succeeding (#40 finding 5).\n        -->\n      </div>\n\n      <!--\n        IDENTITY: who you are, and how to stop being them — collapsed into one control.\n\n        Role, name and sign-out were three separate items here and crowded out the things people\n        actually navigate with. The exception is the \"No role\" warning, which the menu deliberately\n        keeps outside itself; see user-menu.component.html.\n\n        🔴 Sign in beside it while sign-in is BLOCKED (D-15): the account is still known, but a token\n        could not be had without an interaction, which may only come from a gesture. This button is\n        that gesture; without it every request would fail with nothing on screen saying why.\n      -->\n      @if (auth.signInBlocked()) {\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:mr-4\"\n          (click)=\"auth.signIn()\"\n        >\n          Sign in\n        </button>\n      }\n      <div class=\"cws:flex cws:items-center cws:border-l cws:border-slate-200 cws:pl-4 cws:dark:border-slate-700\">\n        <cms-user-menu />\n        <!--\n          #1204: the once-per-deploy release notes, standalone only. The account menu renders under a host\n          too (without Sign out, D-18), so this is gated on its own: the host announces its own releases.\n        -->\n        @if (!embedded) {\n          <cms-whats-new-announcer />\n        }\n      </div>\n    } @else {\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:ml-auto\"\n        (click)=\"auth.signIn()\"\n      >\n        Sign in\n      </button>\n    }\n  </div>\n</header>\n\n<!--\n  F1.4 — the availability banner, on every screen.\n\n  🔴 **It NAMES the state rather than collapsing the five into \"CTRM is unavailable\".** They mean\n  different things to whoever reads this: a night run ends on its own, a closed CTRM is an\n  administrative decision, unreachable is an incident somebody should be told about, and unknown\n  means we cannot say. One sentence for all of them tells a trader nothing about whether to wait,\n  retry or call someone.\n\n  ⚠ Rendered in the SHELL rather than per screen, because the gate applies to every write in the\n  application and a banner a feature had to remember to add is one a feature will forget.\n\n  ⚠ Hidden only while CTRM is available — a permanent green bar is chrome nobody reads, and it\n  would make the states that matter less visible rather than more.\n-->\n@if (availability.notice(); as notice) {\n  @if (availability.state() !== 'Available') {\n    <!--\n      🔴 `role=\"status\"` even when it blocks writes, and that is this repository's own rule rather\n      than a concession: the panel convention is that an ALERT is the outcome of something the user\n      just did, and a STATUS is a standing condition of the screen. CTRM being closed is a standing\n      condition — it was true before they arrived and will be true after they leave.\n\n      ⚠ It was written as a conditional `alert` first, and the shell's access-notice tests caught it\n      immediately: two `role=\"alert\"` regions on one screen, so `getByRole('alert')` became\n      ambiguous. The collision is what surfaced it; the convention is why it stays `status`.\n    -->\n    <!--\n      ⚠ #485: a night run blocks CTRM writes now, and it stays AMBER. It is scheduled and ends on its\n      own, which is what docs/02a calls the soft gate; red is for a CTRM that is closed, unreachable\n      or unknown, where somebody may need to act.\n    -->\n    @let soft = !notice.blocksWrites || availability.state() === 'NightRun';\n    <div class=\"cws:mx-auto cws:max-w-[1800px] cws:px-6 cws:pt-4\" role=\"status\">\n      <div\n        class=\"cws:rounded-lg cws:border cws:px-4 cws:py-3 cws:text-sm\"\n        [class.cws:border-red-300]=\"!soft\"\n        [class.cws:bg-red-50]=\"!soft\"\n        [class.cws:text-red-900]=\"!soft\"\n        [class.cws:border-amber-300]=\"soft\"\n        [class.cws:bg-amber-50]=\"soft\"\n        [class.cws:text-amber-900]=\"soft\"\n      >\n        <p class=\"cws:font-semibold\">{{ notice.title }}</p>\n        <p class=\"cws:mt-0.5\">{{ notice.detail }}</p>\n        @if (availability.message(); as ctrmMessage) {\n          <!-- CTRM's own sentence, quoted rather than parsed: two producers share this channel. -->\n          <p class=\"cws:mt-0.5 cws:italic\">{{ ctrmMessage }}</p>\n        }\n      </div>\n    </div>\n  }\n}\n\n<!--\n  #411 — the permissions could not be read, so no write can be authorized. A standing condition, so\n  `role=\"status\"` like the banner above, and amber: reading still works. Each screen also disables its\n  CTRM writes at the control.\n  #1157: it says what to do. `HttpMeSource` also reads /me again a few times over about a minute, and\n  an Available answer removes this note and re-enables writes without a reload; after that, refreshing\n  is the way to try again, which is what the sentence tells the user.\n-->\n@if (permissionsUnavailable()) {\n  <div class=\"cws:mx-auto cws:max-w-[1800px] cws:px-6 cws:pt-4\" role=\"status\">\n    <div\n      class=\"cws:rounded-lg cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:text-sm cws:text-amber-900\"\n    >\n      <p class=\"cws:font-semibold\">Permissions could not be read</p>\n      <p class=\"cws:mt-0.5\">\n        Refresh the page to try again. Until then, changes to CTRM are unavailable; contracts can still be read.\n      </p>\n    </div>\n  </div>\n}\n\n<!--\n  Same 1800px cap as the top bar — see the note there for why they have to match.\n  `flex-1` fills the shell's full-height column, so the shortcut strip sits on the viewport's bottom\n  edge even when a screen is shorter than the window; `w-full`, because a flex item with auto margins\n  otherwise shrinks to its content.\n-->\n<main class=\"cws:mx-auto cws:w-full cws:max-w-[1800px] cws:flex-1 cws:px-6 cws:py-8\">\n  <!--\n    🔴 A refused navigation, stated once and then cleared — see AccessNotice for why this is a\n    banner rather than a line in cms-notices-panel. That panel is for STANDING conditions of a\n    screen; being bounced out of Admin is an EVENT, and it belongs to the shell that refused it\n    rather than to the workspace that happens to be where you land.\n\n    role=\"alert\" rather than \"status\": the user asked to go somewhere and did not arrive, so it\n    should interrupt. That is the opposite call from the record screen's Save gate, which is a\n    standing property of a screen you meant to be on.\n  -->\n  @if (accessMessage(); as message) {\n    <div class=\"scoular-alert scoular-alert-warning cws:mb-6\" role=\"alert\">\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\n        <div>\n          <div class=\"scoular-alert-title\">That module is not available to your account</div>\n          <div class=\"scoular-alert-description\">{{ message }}</div>\n        </div>\n\n        <!--\n          Dismissible as well as self-clearing: the automatic clear happens on the NEXT navigation,\n          so a user who stays put has no other way to put it down.\n        -->\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary cws:shrink-0\"\n          (click)=\"dismissAccessNotice()\"\n        >\n          Dismiss\n        </button>\n      </div>\n    </div>\n  }\n\n  <!--\n    #889: a choice the browser refused to store (the theme, saved views). The chrome's rather than\n    a screen's, because the refusal outlives the screen it happened on. It stays until dismissed.\n  -->\n  @if (storageRefusals.notice(); as refusal) {\n    <div class=\"cws:mb-6\">\n      <cms-status-message [outcome]=\"refusal\" (dismissed)=\"storageRefusals.dismiss()\" />\n    </div>\n  }\n\n  <router-outlet />\n</main>\n\n<!--\n  The line-23 equivalent and the cheat-sheet behind `?`, both rendered by the workspace rather than by a\n  feature.\n\n  Rendered by the workspace in both delivery models (ADR-18); the bindings are scoped `within` the\n  workspace element so a host's own inputs never trigger them.\n\n  ⚠ The strip is after `<main>` rather than inside it, and it is `sticky bottom-0` (its own host\n  class), so it does not scroll with the content — the green screen's own line 23 does not scroll\n  either, and a legend that leaves the viewport is a legend nobody reads. Being after `<main>` was\n  never enough on its own: in normal flow it simply sat at the end of the page and scrolled away\n  with a long grid (JFrisbie, 2026-09-29).\n-->\n<cms-shortcut-hints />\n<cms-shortcut-overlay />\n",
		dependencies: [
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			},
			{
				kind: "directive",
				type: RouterOutlet,
				selector: "router-outlet",
				inputs: ["name", "routerOutletData"],
				outputs: [
					"activate",
					"deactivate",
					"attach",
					"detach"
				],
				exportAs: ["outlet"]
			},
			{
				kind: "component",
				type: ShortcutHintsComponent,
				selector: "cms-shortcut-hints"
			},
			{
				kind: "component",
				type: ShortcutOverlayComponent,
				selector: "cms-shortcut-overlay"
			},
			{
				kind: "component",
				type: StatusBadgeComponent,
				selector: "cms-status-badge",
				inputs: ["tone", "small"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "component",
				type: TradeUnitPickerComponent,
				selector: "cms-trade-unit-picker"
			},
			{
				kind: "component",
				type: UserMenuComponent,
				selector: "cms-user-menu"
			},
			{
				kind: "component",
				type: WhatsNewAnnouncerComponent,
				selector: "cms-whats-new-announcer"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CwsWorkspaceComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-workspace",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				RouterLink,
				RouterLinkActive,
				RouterOutlet,
				ShortcutHintsComponent,
				ShortcutOverlayComponent,
				StatusBadgeComponent,
				StatusMessageComponent,
				TradeUnitPickerComponent,
				UserMenuComponent,
				WhatsNewAnnouncerComponent
			],
			host: { class: "cws:flex cws:min-h-dvh cws:flex-col" },
			template: "<!--\n  Shell chrome (docs/02 §1.1, 02a §6).\n\n  Top bar rather than a left rail. docs/02 §1.1 says \"Left rail / top bar navigation (final layout\n  in 02a)\" and 02a never resolved it, so this fills a gap rather than contradicting a decision — but\n  it is a decision, and a rail is still a live option if the module count grows.\n\n  Grouped by meaning rather than by convenience:\n    left   — the Scoular mark and the environment instance\n    then   — the modules you move between\n    middle — CONTEXT: what you are operating on (the trade unit)\n    right  — IDENTITY: who you are, and how to stop being them\n\n  The logo is the tallest thing here at 40px, so it sets the bar height at roughly 66px. Every\n  *control* is 32px, so nothing else sets an accidental maximum: the trade-unit picker used to be a\n  bordered <select> at ~38px and was most of why the bar looked heavy.\n\n  `py-2` was tried and reverted when the bar was single-line: at 49px it left 8px around a 32px\n  control and read cramped, and the 8px reclaimed is about one sixth of a table row.\n\n  The h1 is the brand link, so the heading and the primary navigation are one element rather than\n  two things competing for the same corner. Routed content starts at h2.\n-->\n<header class=\"cws:border-b cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-800\">\n  <!--\n    Width is capped at 1800px here and on <main>, and the two must stay in step — a top bar wider or\n    narrower than the content below it makes the nav and the grid look misaligned by a few pixels,\n    which reads as a rendering bug rather than a layout choice.\n\n    Widened from `max-w-7xl` (1280px), which left large margins on the monitors people actually use\n    (JFrisbie, 2026-08-26). Still capped rather than uncapped: this bar is chrome, but <main> also\n    carries the contract form, and an unbounded container puts its labelled fields on 2000px+ lines\n    on an ultrawide. 1800px fills a 1920 screen nearly edge to edge and leaves margins beyond that.\n  -->\n  <div class=\"cws:mx-auto cws:flex cws:max-w-[1800px] cws:flex-wrap cws:items-center cws:gap-x-6 cws:gap-y-3 cws:px-6 cws:py-3\">\n    <!--\n      Brand lockup, matching the Originations header: the Scoular mark and wordmark with the\n      application name beneath it.\n\n      Deliberately mirroring a sibling Scoular application rather than inventing our own arrangement.\n\n      🔴 Standalone only (D-17): when CWS_EMBEDDED is true the host's own header carries the brand,\n      and this lockup is not rendered at all. Its two images resolve relative to the page, so under a\n      host's prefix they would 404 and it would degrade to the text fallback below.\n\n      The h1 is a direct child of the header row, with no wrapper. It had one while the environment\n      chip sat beside the application name and the pair needed `items-end`; the chip now sits with the\n      module links, so the wrapper was a div that grouped one element.\n\n      The column is a FIXED 232px, and that number is derived rather than chosen: `scoular-logo.webp`\n      is 1692×292, so at `h-10` (40px) it renders 1692 ÷ 292 × 40 = 231.7px. Pinning it lets the\n      wordmark alignment below be expressed in the logo's own coordinate space, which is the only way\n      to line text up with a glyph inside a raster image.\n    -->\n    @if (!embedded) {\n    <h1 class=\"cws:m-0 cws:w-[232px] cws:shrink-0\">\n        <a\n          [routerLink]=\"[mountBase.path()]\"\n          class=\"cws:block cws:rounded cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\n          aria-label=\"Contract Workspace — contract list\"\n        >\n          @if (logoUnavailable()) {\n            <span class=\"cws:text-xl cws:font-semibold cws:text-scoular-gray cws:dark:text-slate-200\">SCOULAR</span>\n          } @else {\n            <img\n              src=\"scoular-logo.webp\"\n              alt=\"\"\n              class=\"cws:h-10 cws:w-full cws:dark:hidden\"\n              (error)=\"logoUnavailable.set(true)\"\n            />\n            <img\n              src=\"scoular-logo-dark.webp\"\n              alt=\"\"\n              class=\"cws:hidden cws:h-10 cws:w-full cws:dark:block\"\n              (error)=\"logoUnavailable.set(true)\"\n            />\n          }\n\n          <!--\n            The application name, under the mark and aligned to the wordmark (JFrisbie, 2026-08-31).\n\n            ### Why this is an <svg> and not a <span>\n\n            Two requirements a span cannot meet: it must start under the **S** of SCOULAR — not at\n            the logo's left edge, which is the pinwheel — and it must not run past the **R**. Both\n            are positions *inside a raster image*, so they can only be expressed as fractions of that\n            image, and the right edge additionally depends on font metrics that differ by platform.\n\n            The viewBox is the logo's own pixel grid (1692 wide), so the two numbers below are\n            measured in the same units as the image and scale with it automatically:\n\n              x=378         the left edge of the S      (22.3% of 1692)\n              textLength    ends at 1600, short of the R's right edge at ~1620\n\n            `lengthAdjust=\"spacing\"` makes the text span exactly that width by distributing the\n            difference **between** glyphs — it stretches the tracking, never the letterforms, so the\n            type is not distorted. That is what fills the wordmark's width regardless of which font\n            actually resolves, which a hand-tuned `tracking-[…]` cannot promise.\n\n            aria-hidden, because the link's own aria-label already reads \"Contract Workspace —\n            contract list\"; without it the accessible name is computed from the label AND this text\n            and a screen reader says the words twice.\n          -->\n          <svg\n            aria-hidden=\"true\"\n            focusable=\"false\"\n            class=\"cws:mt-0.5 cws:block cws:w-full\"\n            viewBox=\"0 0 1692 92\"\n          >\n            <text\n              x=\"378\"\n              y=\"76\"\n              textLength=\"1222\"\n              lengthAdjust=\"spacing\"\n              font-size=\"84\"\n              font-weight=\"600\"\n              class=\"cws:fill-scoular-gray cws:dark:fill-slate-300\"\n            >\n              CONTRACT WORKSPACE\n            </text>\n          </svg>\n        </a>\n    </h1>\n    }\n\n    <!--\n      Which *instance* you are in, where the trade unit says what you are operating on. Absent in\n      production, where saying so adds nothing — so the clutter only exists where it earns its place.\n      Fixed height and a minimum width so a two-letter DEV and a five-letter LOCAL read as the same\n      control rather than one being a nub.\n\n      A sibling of the brand and the module nav rather than a child of either (JFrisbie, 2026-08-31),\n      so the header row's own `items-center` centres it against the full bar height and it sits on the\n      module links' line. Deliberately outside `<nav aria-label=\"Modules\">`: it is not somewhere you\n      can navigate to, and putting it inside would offer it to a screen-reader user as a fifth module.\n    -->\n    @if (environmentLabel(); as label) {\n      <!--\n        The `info` tone — a teal tint.\n\n        A solid `scoular-blue` fill with white text was tried on 2026-08-31 to match the Originations\n        header and reverted the same day: JFrisbie preferred the original. Recorded so it is not\n        re-proposed as an obvious improvement. It was not a contrast problem — white on #00588E is\n        7.5:1 — it simply looked wrong here, where the chip sits on a white bar rather than a dark one.\n\n        ⚠ **This is a CHIP borrowing the badge's tint, not a status.** It says which instance you are\n        in; nothing about it has a state that could be positive or negative. It goes through\n        `cms-status-badge` anyway so the tone-to-class mapping stays in one file — but if a future\n        change makes the tone vocabulary mean something narrower, this is the call site to reconsider\n        rather than the one to bend the vocabulary around.\n\n        The sizing utilities are this chip's own: a fixed height and a minimum width so a three-letter\n        DEV and a five-letter LOCAL read as the same control. They compose with the component's host\n        classes rather than replacing them (the primitive has a test for that).\n\n        ⚠ `font-semibold` USED TO DO NOTHING here. `.scoular-badge` sets `font-medium`, and before the\n        design system was layered on 2026-09-16 the class beat the utility — measured in Edge at\n        weight 500 before and 600 after. This chip is the one place in the application where that\n        change is visible.\n      -->\n      <cms-status-badge\n        tone=\"info\"\n        class=\"cws:h-6 cws:min-w-16 cws:shrink-0 cws:justify-center cws:px-3 cws:font-semibold cws:uppercase cws:tracking-wide\"\n      >\n        {{ label }}\n      </cms-status-badge>\n    }\n\n    @if (auth.isSignedIn()) {\n      <!--\n        The modules of docs/02 §1.1 this caller may see — the list is MODULES in workspace.component.ts.\n\n        🔴 **Admin is gated and the other three are not**, which is deliberate rather than partial\n        work. Approvals and Pricing are READABLE by any signed-in user, so hiding those queues would\n        withhold information a User is entitled to; what is gated there is the decision controls\n        inside them. Admin differs in kind — every request it makes carries CwsAdmin and would 403.\n\n        ⚠ **The route is guarded too, and the nav alone would not be enough.** Hiding a link does\n        nothing about a bookmark, a pasted URL or the back button. See permission.guards.ts.\n\n        ⚠ Still NOT the per-trade-unit matrix — that is F1.3 / #138, BACKEND, blocked on a business\n        ruling. This is one boolean resolved in one file, shaped so the matrix can replace it without\n        touching a screen.\n\n        `routerLinkActive` with `exact` on Home only — otherwise \"/\" matches every route and Home\n        would look active everywhere.\n\n        `text-[15px]`, one step up from `text-sm` (JFrisbie, 2026-08-31). The bar is ~66px tall\n        because the 40px logo sets it, and 14px links left it looking under-filled. 15px rather than\n        `text-base`: 16px starts competing with the page's own headings for weight, and the ask was\n        \"a little bigger\", not a size class up. The trade-unit picker and the avatar move with it, so\n        the row still reads as one set of controls rather than three different sizes.\n      -->\n      <!--\n        🔴 **The active module is marked three ways, and none of them moves the layout**\n        (JFrisbie, 2026-09-14). It was a pale tint and a colour change, which on a white bar was\n        easy to miss — and on a four-item nav \"which section am I in\" is the one question the bar\n        exists to answer.\n\n        Now: a **2px bottom accent**, a stronger background, and higher-contrast text.\n\n        ⚠ **The border is always present and only changes colour.** Adding a 2px border on\n        activation would shift every link up by 2px as you navigate, and the whole bar with it.\n        `rounded-t` rather than `rounded` for the same reason the accent is at the bottom — a\n        rounded bottom edge would clip it.\n\n        ⚠ **The font weight deliberately does NOT change.** `font-medium` to `font-semibold` widens\n        the text, which moves every sibling along the bar on each navigation — a jitter that reads\n        as the page settling badly.\n\n        🔴 **`ariaCurrentWhenActive` is not decoration.** Three visual cues say nothing to a screen\n        reader; `aria-current=\"page\"` is what makes the active module obvious without sight of it,\n        and it was missing entirely.\n\n        🔴 **The active style keys off that same attribute, never off `routerLinkActive` classes**\n        (#545's clean room, measured in a host's production build). Applied as plain classes, the\n        active text colour and border lost to the inactive `text-slate-600` / `border-transparent`\n        in the same attribute: equal specificity, and the inactive rules happen to be emitted later\n        in the stylesheet. So the active module showed only a faint tint, and before the `cws:`\n        prefix, nothing at all. `aria-[current=page]:` variants are emitted after the base utilities,\n        so they win. `routerLinkActive=\"\"` stays only to drive `ariaCurrentWhenActive`.\n      -->\n      <nav aria-label=\"Modules\" class=\"cws:flex cws:items-center cws:gap-1\">\n        @for (entry of modules(); track entry.module) {\n          <a\n            [routerLink]=\"entry.commands\"\n            routerLinkActive=\"\"\n            [routerLinkActiveOptions]=\"{ exact: entry.exact }\"\n            ariaCurrentWhenActive=\"page\"\n            class=\"cws:rounded-t cws:border-b-2 cws:border-transparent cws:px-3 cws:py-1.5 cws:text-[15px] cws:font-medium cws:text-slate-600 cws:transition-colors cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60 cws:aria-[current=page]:border-scoular-blue cws:aria-[current=page]:bg-slate-100 cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:border-sky-400 cws:dark:aria-[current=page]:bg-slate-700 cws:dark:aria-[current=page]:text-sky-300\"\n          >\n            {{ entry.label }}\n          </a>\n        }\n      </nav>\n\n      <!-- CONTEXT: what you are operating as. Pushed right of the modules, left of identity. -->\n      <div class=\"cws:ml-auto cws:flex cws:items-center cws:gap-3\">\n        <cms-trade-unit-picker />\n\n        <!--\n          No CTRM availability light here, deliberately.\n\n          docs/02a §5 handles unavailability with *gates*, not a status dot: CTRM down is a\n          full-screen block page, the night run is a persistent amber banner with mutations\n          disabled. Both are far louder than a dot, so the dot's only remaining job would be saying\n          \"fine\" during the normal case — the least informative thing a control can do. There is\n          also no signal to bind it to: `operation/statuses` reports only the night run, so\n          reachability has to be inferred from a call succeeding (#40 finding 5).\n        -->\n      </div>\n\n      <!--\n        IDENTITY: who you are, and how to stop being them — collapsed into one control.\n\n        Role, name and sign-out were three separate items here and crowded out the things people\n        actually navigate with. The exception is the \"No role\" warning, which the menu deliberately\n        keeps outside itself; see user-menu.component.html.\n\n        🔴 Sign in beside it while sign-in is BLOCKED (D-15): the account is still known, but a token\n        could not be had without an interaction, which may only come from a gesture. This button is\n        that gesture; without it every request would fail with nothing on screen saying why.\n      -->\n      @if (auth.signInBlocked()) {\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:mr-4\"\n          (click)=\"auth.signIn()\"\n        >\n          Sign in\n        </button>\n      }\n      <div class=\"cws:flex cws:items-center cws:border-l cws:border-slate-200 cws:pl-4 cws:dark:border-slate-700\">\n        <cms-user-menu />\n        <!--\n          #1204: the once-per-deploy release notes, standalone only. The account menu renders under a host\n          too (without Sign out, D-18), so this is gated on its own: the host announces its own releases.\n        -->\n        @if (!embedded) {\n          <cms-whats-new-announcer />\n        }\n      </div>\n    } @else {\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:ml-auto\"\n        (click)=\"auth.signIn()\"\n      >\n        Sign in\n      </button>\n    }\n  </div>\n</header>\n\n<!--\n  F1.4 — the availability banner, on every screen.\n\n  🔴 **It NAMES the state rather than collapsing the five into \"CTRM is unavailable\".** They mean\n  different things to whoever reads this: a night run ends on its own, a closed CTRM is an\n  administrative decision, unreachable is an incident somebody should be told about, and unknown\n  means we cannot say. One sentence for all of them tells a trader nothing about whether to wait,\n  retry or call someone.\n\n  ⚠ Rendered in the SHELL rather than per screen, because the gate applies to every write in the\n  application and a banner a feature had to remember to add is one a feature will forget.\n\n  ⚠ Hidden only while CTRM is available — a permanent green bar is chrome nobody reads, and it\n  would make the states that matter less visible rather than more.\n-->\n@if (availability.notice(); as notice) {\n  @if (availability.state() !== 'Available') {\n    <!--\n      🔴 `role=\"status\"` even when it blocks writes, and that is this repository's own rule rather\n      than a concession: the panel convention is that an ALERT is the outcome of something the user\n      just did, and a STATUS is a standing condition of the screen. CTRM being closed is a standing\n      condition — it was true before they arrived and will be true after they leave.\n\n      ⚠ It was written as a conditional `alert` first, and the shell's access-notice tests caught it\n      immediately: two `role=\"alert\"` regions on one screen, so `getByRole('alert')` became\n      ambiguous. The collision is what surfaced it; the convention is why it stays `status`.\n    -->\n    <!--\n      ⚠ #485: a night run blocks CTRM writes now, and it stays AMBER. It is scheduled and ends on its\n      own, which is what docs/02a calls the soft gate; red is for a CTRM that is closed, unreachable\n      or unknown, where somebody may need to act.\n    -->\n    @let soft = !notice.blocksWrites || availability.state() === 'NightRun';\n    <div class=\"cws:mx-auto cws:max-w-[1800px] cws:px-6 cws:pt-4\" role=\"status\">\n      <div\n        class=\"cws:rounded-lg cws:border cws:px-4 cws:py-3 cws:text-sm\"\n        [class.cws:border-red-300]=\"!soft\"\n        [class.cws:bg-red-50]=\"!soft\"\n        [class.cws:text-red-900]=\"!soft\"\n        [class.cws:border-amber-300]=\"soft\"\n        [class.cws:bg-amber-50]=\"soft\"\n        [class.cws:text-amber-900]=\"soft\"\n      >\n        <p class=\"cws:font-semibold\">{{ notice.title }}</p>\n        <p class=\"cws:mt-0.5\">{{ notice.detail }}</p>\n        @if (availability.message(); as ctrmMessage) {\n          <!-- CTRM's own sentence, quoted rather than parsed: two producers share this channel. -->\n          <p class=\"cws:mt-0.5 cws:italic\">{{ ctrmMessage }}</p>\n        }\n      </div>\n    </div>\n  }\n}\n\n<!--\n  #411 — the permissions could not be read, so no write can be authorized. A standing condition, so\n  `role=\"status\"` like the banner above, and amber: reading still works. Each screen also disables its\n  CTRM writes at the control.\n  #1157: it says what to do. `HttpMeSource` also reads /me again a few times over about a minute, and\n  an Available answer removes this note and re-enables writes without a reload; after that, refreshing\n  is the way to try again, which is what the sentence tells the user.\n-->\n@if (permissionsUnavailable()) {\n  <div class=\"cws:mx-auto cws:max-w-[1800px] cws:px-6 cws:pt-4\" role=\"status\">\n    <div\n      class=\"cws:rounded-lg cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:text-sm cws:text-amber-900\"\n    >\n      <p class=\"cws:font-semibold\">Permissions could not be read</p>\n      <p class=\"cws:mt-0.5\">\n        Refresh the page to try again. Until then, changes to CTRM are unavailable; contracts can still be read.\n      </p>\n    </div>\n  </div>\n}\n\n<!--\n  Same 1800px cap as the top bar — see the note there for why they have to match.\n  `flex-1` fills the shell's full-height column, so the shortcut strip sits on the viewport's bottom\n  edge even when a screen is shorter than the window; `w-full`, because a flex item with auto margins\n  otherwise shrinks to its content.\n-->\n<main class=\"cws:mx-auto cws:w-full cws:max-w-[1800px] cws:flex-1 cws:px-6 cws:py-8\">\n  <!--\n    🔴 A refused navigation, stated once and then cleared — see AccessNotice for why this is a\n    banner rather than a line in cms-notices-panel. That panel is for STANDING conditions of a\n    screen; being bounced out of Admin is an EVENT, and it belongs to the shell that refused it\n    rather than to the workspace that happens to be where you land.\n\n    role=\"alert\" rather than \"status\": the user asked to go somewhere and did not arrive, so it\n    should interrupt. That is the opposite call from the record screen's Save gate, which is a\n    standing property of a screen you meant to be on.\n  -->\n  @if (accessMessage(); as message) {\n    <div class=\"scoular-alert scoular-alert-warning cws:mb-6\" role=\"alert\">\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\n        <div>\n          <div class=\"scoular-alert-title\">That module is not available to your account</div>\n          <div class=\"scoular-alert-description\">{{ message }}</div>\n        </div>\n\n        <!--\n          Dismissible as well as self-clearing: the automatic clear happens on the NEXT navigation,\n          so a user who stays put has no other way to put it down.\n        -->\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary cws:shrink-0\"\n          (click)=\"dismissAccessNotice()\"\n        >\n          Dismiss\n        </button>\n      </div>\n    </div>\n  }\n\n  <!--\n    #889: a choice the browser refused to store (the theme, saved views). The chrome's rather than\n    a screen's, because the refusal outlives the screen it happened on. It stays until dismissed.\n  -->\n  @if (storageRefusals.notice(); as refusal) {\n    <div class=\"cws:mb-6\">\n      <cms-status-message [outcome]=\"refusal\" (dismissed)=\"storageRefusals.dismiss()\" />\n    </div>\n  }\n\n  <router-outlet />\n</main>\n\n<!--\n  The line-23 equivalent and the cheat-sheet behind `?`, both rendered by the workspace rather than by a\n  feature.\n\n  Rendered by the workspace in both delivery models (ADR-18); the bindings are scoped `within` the\n  workspace element so a host's own inputs never trigger them.\n\n  ⚠ The strip is after `<main>` rather than inside it, and it is `sticky bottom-0` (its own host\n  class), so it does not scroll with the content — the green screen's own line 23 does not scroll\n  either, and a legend that leaves the viewport is a legend nobody reads. Being after `<main>` was\n  never enough on its own: in normal flow it simply sat at the end of the page and scrolled away\n  with a long grid (JFrisbie, 2026-09-29).\n-->\n<cms-shortcut-hints />\n<cms-shortcut-overlay />\n"
		}]
	}],
	ctorParameters: () => []
});
function environmentLabelOf(name) {
	return name === "prod" ? null : name;
}
const LAZY_SOURCES_LOADER = new InjectionToken("LAZY_SOURCES_LOADER", {
	providedIn: "root",
	factory: () => () => import("./cws-workspace-lazy-sources-CD3IP7LA.mjs")
});
function lazySource(token, pick, methods) {
	return {
		provide: token,
		useFactory: () => {
			const injector = inject(Injector);
			const loader = inject(LAZY_SOURCES_LOADER);
			const instance$ = defer(() => loader()).pipe(map((sources) => {
				const type = pick(sources);
				return Injector.create({
					providers: [type],
					parent: injector
				}).get(type);
			}), shareReplay({
				bufferSize: 1,
				refCount: false
			}));
			const standIn = {};
			for (const method of Object.keys(methods)) standIn[method] = (...args) => instance$.pipe(switchMap((instance) => instance[method](...args)));
			return standIn;
		}
	};
}
function cwsRoutes() {
	return [
		{
			path: "",
			pathMatch: "full",
			title: "Contracts",
			canActivate: [canUseContractsGuard],
			loadComponent: () => import("@cws/features-home").then((m) => m.HomePageComponent)
		},
		{
			path: "contracts/new",
			title: "New contract",
			canActivate: [canUseContractsGuard],
			data: {
				tradeUnitLocked: true,
				mode: "create"
			},
			loadChildren: () => import("./cws-workspace-record.routes-C2E-uh4c.mjs").then((m) => m.CREATE_RECORD_ROUTES)
		},
		{
			path: "contracts/:contractNumber/edit",
			title: "Edit contract",
			canActivate: [canUseContractsGuard],
			data: {
				tradeUnitLocked: true,
				mode: "edit"
			},
			loadChildren: () => import("./cws-workspace-record.routes-C2E-uh4c.mjs").then((m) => m.EDIT_RECORD_ROUTES)
		},
		{
			path: "contracts/:contractNumber",
			title: "Contract",
			canActivate: [canUseContractsGuard],
			data: {
				tradeUnitLocked: true,
				mode: "view"
			},
			loadChildren: () => import("./cws-workspace-record.routes-C2E-uh4c.mjs").then((m) => m.VIEW_RECORD_ROUTES)
		},
		{
			path: "approvals",
			title: "Approvals",
			canActivate: [canUseContractsGuard],
			loadComponent: () => import("@cws/features-approvals").then((m) => m.ApprovalsPageComponent)
		},
		{
			path: "approvals/:contractNumber",
			title: "Approve contract",
			canActivate: [canUseContractsGuard],
			providers: [lazySource(CONTRACT_DOCUMENTS_SOURCE, (m) => m.HttpContractDocumentsSource, {
				list: true,
				content: true,
				requestDraft: true
			})],
			loadComponent: () => import("@cws/features-approvals").then((m) => m.ApprovalDetailPageComponent)
		},
		{
			path: "pricing",
			title: "Pricing",
			canActivate: [canUseContractsGuard],
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PricingPageComponent)
		},
		{
			path: "pricing/approvals",
			title: "Pricing approvals",
			canActivate: [canUseContractsGuard],
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PricingApprovalsPageComponent)
		},
		{
			path: "pricing/:contractNumber/sequences/new",
			title: "New price sequence",
			canActivate: [canUseContractsGuard],
			canDeactivate: [confirmNavigationGuard],
			data: { mode: "new" },
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PriceSequenceDetailPageComponent)
		},
		{
			path: "pricing/:contractNumber/sequences/:seq/edit",
			title: "Edit price sequence",
			canActivate: [canUseContractsGuard],
			canDeactivate: [confirmNavigationGuard],
			data: { mode: "edit" },
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PriceSequenceDetailPageComponent)
		},
		{
			path: "pricing/:contractNumber/sequences/:seq",
			title: "Price sequence",
			canActivate: [canUseContractsGuard],
			data: { mode: "view" },
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PriceSequenceDetailPageComponent)
		},
		{
			path: "pricing/:contractNumber",
			title: "Price sequences",
			canActivate: [canUseContractsGuard],
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PricingDetailPageComponent)
		},
		{
			path: "admin",
			title: "Admin",
			canActivate: [canUseContractsGuard, canAccessAdminGuard],
			loadChildren: () => import("./cws-workspace-record.routes-C2E-uh4c.mjs").then((m) => m.ADMIN_ROUTES)
		},
		{
			path: ACCESS_NOTICE_PATH,
			title: "Contracts access",
			loadComponent: () => Promise.resolve().then(() => access_notice_page_component_exports).then((m) => m.AccessNoticePageComponent)
		}
	];
}
function cwsStandaloneRoutes() {
	return [...cwsRoutes(), {
		path: WHATS_NEW_PATH,
		title: "What's new",
		canActivate: [canUseContractsGuard],
		loadComponent: () => import("./cws-workspace-whats-new-page.component-DXsgI7Ud.mjs").then((m) => m.WhatsNewPageComponent)
	}];
}
const FORM_CONFIG_SOURCE_LOADER = new InjectionToken("FORM_CONFIG_SOURCE_LOADER", {
	providedIn: "root",
	factory: () => () => import("@cws/features-contract-entry").then((m) => m.HttpFormConfigSource)
});
var LazyFormConfigSource = class LazyFormConfigSource {
	injector = inject(Injector);
	loader = inject(FORM_CONFIG_SOURCE_LOADER);
	source$ = defer(() => this.loader()).pipe(map((type) => Injector.create({
		providers: [type],
		parent: this.injector
	}).get(type)), shareReplay({
		bufferSize: 1,
		refCount: false
	}));
	load(key) {
		return this.source$.pipe(switchMap((source) => source.load(key)));
	}
	preview(key, document) {
		return this.source$.pipe(switchMap((source) => source.preview === void 0 ? of(remoteLoaded({ kind: "not-built" })) : source.preview(key, document)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LazyFormConfigSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LazyFormConfigSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LazyFormConfigSource,
	decorators: [{ type: Injectable }]
});
const MAX_BUFFERED = 50;
function provideMsalTelemetry() {
	return makeEnvironmentProviders([provideEnvironmentInitializer(() => {
		const msal = inject(CWS_MSAL_INSTANCE, { optional: true });
		if (msal === null) return;
		const injector = inject(Injector);
		const buffered = [];
		let forward = null;
		const id = msal.addEventCallback((message) => {
			if (forward !== null) forward(message);
			else if (buffered.length < MAX_BUFFERED) buffered.push(message);
		});
		if (id === null) return;
		inject(DestroyRef).onDestroy(() => msal.removeEventCallback(id));
		import("./cws-workspace-msal-telemetry-DkNK51ac.mjs").then(({ forwardMsalEvent }) => {
			let insights = null;
			forward = (message) => forwardMsalEvent(message, insights ??= injector.get(AppInsightsService));
			buffered.splice(0).forEach(forward);
		}, () => {
			buffered.length = 0;
			msal.removeEventCallback(id);
		});
	})]);
}
function provideCwsWorkspace(config) {
	return makeEnvironmentProviders([
		...authProvidersFor(config),
		provideHttpClient(withInterceptors([cwsTokenInterceptor, problemDetailsInterceptor])),
		{
			provide: CONTRACTS_API_URL,
			useValue: config.apiUrl
		},
		...config.telemetry ? [
			{
				provide: APP_INSIGHTS_CONNECTION_STRING,
				useValue: config.telemetry.connectionString
			},
			{
				provide: APP_INSIGHTS_ROLE_NAME,
				useValue: config.telemetry.roleName
			},
			{
				provide: ErrorHandler,
				useClass: AppInsightsErrorHandler
			},
			...config.auth.tokenProvider ? [] : [provideMsalTelemetry()]
		] : [],
		{
			provide: CONTRACT_LIST_SOURCE,
			useClass: HttpContractListSource
		},
		{
			provide: AVAILABILITY_SOURCE,
			useClass: HttpAvailabilitySource
		},
		{
			provide: ME_SOURCE,
			useClass: HttpMeSource
		},
		{
			provide: CUSTOMER_SOURCE,
			useClass: HttpCustomerSource
		},
		lazySource(CONTRACT_STATE_SOURCE, (m) => m.HttpContractStateSource, {
			close: true,
			reopen: true
		}),
		lazySource(CONTRACT_LOG_SOURCE, (m) => m.HttpContractLogSource, {
			audit: true,
			notes: true,
			addNote: true,
			notifyTrader: true
		}),
		lazySource(CONTRACT_TEMPLATE_SOURCE, (m) => m.HttpContractTemplateSource, {
			list: true,
			save: true,
			rename: true,
			remove: true,
			markUsed: true
		}),
		lazySource(CONTRACT_EXPORT_SOURCE, (m) => m.HttpContractExportSource, { export: true }),
		lazySource(PRICING_SOURCE, (m) => m.HttpPricingSource, {
			contractPrices: true,
			unapproved: true,
			save: true,
			remove: true,
			approve: true
		}),
		lazySource(MARKET_REFERENCE_SOURCE, (m) => m.HttpMarketReferenceSource, {
			marketCodes: true,
			marketMonths: true
		}),
		lazySource(ORIGIN_DESTINATION_SOURCE, (m) => m.HttpOriginDestinationSource, { search: true }),
		lazySource(CUSTOMER_SEARCH_SOURCE, (m) => m.HttpCustomerSearchSource, { search: true }),
		lazySource(BASIS_LOCATION_OPTIONS_SOURCE, (m) => m.HttpBasisLocationSource, { options: true }),
		lazySource(BASIS_LOCATION_ADMIN_SOURCE, (m) => m.HttpBasisLocationAdminSource, {
			terms: true,
			places: true,
			regions: true,
			addTerm: true,
			addPlace: true,
			addRegion: true,
			retireTerm: true,
			retirePlace: true,
			retireRegion: true,
			setting: true,
			putSetting: true,
			htaSpecialTypes: true,
			putHtaSpecialTypes: true
		}),
		CODE_SEARCH_SOURCES_PROVIDER,
		lazySource(TRADE_UNIT_VALUES_SOURCE, (m) => m.HttpTradeUnitValuesSource, {
			values: true,
			marketMonths: true
		}),
		lazySource(PERMISSION_CATALOG_SOURCE, (m) => m.HttpPermissionCatalogSource, { get: true }),
		lazySource(ROLE_ADMIN_SOURCE, (m) => m.HttpRoleAdminSource, {
			listRoles: true,
			createRole: true,
			updateRole: true,
			deleteRole: true,
			listAssignments: true,
			assign: true,
			setDefault: true,
			revoke: true,
			revokePending: true
		}),
		lazySource(USER_DIRECTORY_SOURCE, (m) => m.HttpUserDirectorySource, { lookUpByUpn: true }),
		{
			provide: TRADE_UNIT_CONTEXT,
			useExisting: TradeUnitStore
		},
		MePermissionContext,
		{
			provide: PERMISSION_CONTEXT,
			useExisting: MePermissionContext
		},
		{
			provide: LOCATION_SOURCE,
			useClass: HttpLocationSource
		},
		{
			provide: CMS_HOST_CONTEXT,
			useFactory: () => {
				const base = inject(CwsMountBase);
				return workspaceHostContext(inject(Router), inject(CmsAuthService), inject(TradeUnitStore), inject(ThemeStore), () => base.path());
			}
		},
		CwsMountBase,
		ThemeStore,
		AvailabilityGate,
		TradeUnitVisibilityStore,
		WhatsNewStore,
		{
			provide: CWS_THEME_MODE,
			useValue: config.theme
		},
		{
			provide: CWS_ENVIRONMENT_NAME,
			useValue: config.environmentName
		},
		{
			provide: CWS_EMBEDDED,
			useValue: config.embedded ?? false
		},
		{
			provide: CWS_EXTERNAL_LINKS,
			useValue: checkExternalLinks(config.links)
		},
		lazySource(CONTRACT_DETAIL_SOURCE, (m) => m.HttpContractDetailSource, { get: true }),
		lazySource(APPROVAL_CONTRACT_SOURCE, (m) => m.HttpApprovalContractSource, { get: true }),
		LazyFormConfigSource,
		{
			provide: FORM_CONFIG_SOURCE,
			useExisting: LazyFormConfigSource
		},
		lazySource(CONTRACT_WRITE_SOURCE, (m) => m.HttpContractWriteSource, {
			fields: true,
			create: true,
			update: true
		}),
		lazySource(CONTRACT_NUMBER_SOURCE, (m) => m.HttpContractNumberSource, {
			issue: true,
			check: true
		}),
		lazySource(FORM_CONFIG_ADMIN_SOURCE, (m) => m.HttpFormConfigAdminSource, {
			list: true,
			auditTrail: true,
			registry: true,
			get: true,
			preview: true,
			create: true,
			update: true,
			deactivate: true
		}),
		lazySource(APPROVAL_ACTION_SOURCE, (m) => m.HttpApprovalActionSource, {
			ecmRouting: true,
			approve: true,
			reject: true
		}),
		lazySource(APPROVAL_QUEUE_SOURCE, (m) => m.HttpApprovalQueueSource, { read: true }),
		lazySource(PRICING_APPROVAL_QUEUE_SOURCE, (m) => m.HttpPricingApprovalQueueSource, { read: true }),
		lazySource(WEIGHT_LIMIT_CHECK_SOURCE, (m) => m.HttpWeightLimitCheckSource, { check: true }),
		lazySource(TRADE_UNIT_VISIBILITY_SOURCE, (m) => m.HttpTradeUnitVisibilitySource, {
			get: true,
			save: true
		}),
		lazySource(WHATS_NEW_SOURCE, (m) => m.HttpWhatsNewSource, {
			releases: true,
			build: true
		}),
		lazySource(DEFAULT_TRADE_UNIT_SOURCE, (m) => m.LocalFirstDefaultTradeUnitSource, {
			get: true,
			save: true
		}),
		lazySource(HOME_GRID_COLUMNS_SOURCE, (m) => m.HttpHomeGridColumnsSource, { forTradeUnit: true }),
		lazySource(GRID_COLUMN_SERVER_SOURCE, (m) => m.HttpGridColumnPreferenceSource, {
			get: true,
			save: true
		}),
		lazySource(GRID_COLUMN_PREFERENCE_SOURCE, (m) => m.LocalFirstGridColumnPreferenceSource, {
			get: true,
			save: true
		}),
		{
			provide: GRID_COLUMN_OWNER,
			useFactory: () => {
				const auth = inject(CmsAuthService);
				return () => auth.userId();
			}
		},
		{
			provide: GRID_COLUMN_STORE,
			useFactory: () => new BrowserGridColumnStore(inject(GRID_COLUMN_OWNER))
		},
		{
			provide: SAVED_FILTER_STORE,
			useClass: LocalSavedFilterStore
		},
		{
			provide: SAVED_FILTER_OWNER,
			useFactory: () => {
				const auth = inject(CmsAuthService);
				return () => auth.username() ?? "anonymous";
			}
		}
	]);
}
function authProvidersFor(config) {
	const auth = config.auth;
	if (auth.tokenProvider) return [provideCwsHostTokenAuth({
		apiUrl: config.apiUrl,
		apiScopes: auth.apiScopes,
		tokenProvider: auth.tokenProvider
	})];
	return [provideCmsAuth({
		...auth,
		apiUrl: config.apiUrl
	})];
}
export { ACCESS_NOTICE_PATH, ADMIN_REFUSAL, AccessNoticePageComponent, CWS_EMBEDDED, CWS_ENVIRONMENT_NAME, CWS_THEME_MODE, CwsMountBase, CwsWorkspaceComponent, MODULE_PATHS, MODULE_SEGMENTS, MePermissionContext, ThemeStore, TradeUnitPickerComponent, TradeUnitVisibilityStore, UserMenuComponent, WHATS_NEW_LAST_SEEN_KEY, WhatsNewStore, buildLine, canAccessAdminGuard, canUseContractsGuard, cwsRoutes, cwsStandaloneRoutes, mountBaseOf, provideCwsWorkspace, workspaceHostContext, workspaceRoutes };

//# sourceMappingURL=cws-workspace.mjs.map
import { TradeUnitVisibilityStore } from "./cws-workspace.mjs";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, inject, signal } from "@angular/core";
import { StatusMessageComponent, remoteLoading } from "@cws/shared-ui";
import { LOCATION_SOURCE } from "@cws/domain-contracts";
import { toSignal } from "@angular/core/rxjs-interop";
var TradeUnitCurationComponent = class TradeUnitCurationComponent {
	visibility = inject(TradeUnitVisibilityStore);
	data = toSignal(inject(LOCATION_SOURCE).list(), { initialValue: remoteLoading() });
	term = signal("", ...ngDevMode ? [{ debugName: "term" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const data = this.data();
		const term = this.term().trim().toLowerCase();
		const locations = data.status === "loaded" ? data.value.locations : [];
		return term === "" ? locations : locations.filter((location) => [
			location.code,
			location.name,
			location.companyCode,
			location.companyName
		].some((text) => (text ?? "").toLowerCase().includes(term)));
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	failed = computed(() => this.data().status === "error", ...ngDevMode ? [{ debugName: "failed" }] : /* istanbul ignore next */ []);
	constructor() {
		this.visibility.load();
	}
	toggle(code, shown) {
		this.visibility.setHidden(code, !shown);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TradeUnitCurationComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TradeUnitCurationComponent,
		isStandalone: true,
		selector: "cms-trade-unit-curation",
		ngImport: i0,
		template: "<div class=\"cws:space-y-2 cws:px-4 cws:pb-3\">\n  <!--\n    🔴 The preference-not-permission sentence (C-14, C-15 a). Without it a hidden unit reads as one\n    you are not allowed to use, and someone goes to ask for access they already hold.\n  -->\n  <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n    Untick the trade units you never use to shorten the picker. Hidden units stay one click away\n    under <strong>Show all</strong>, and links to their contracts still open.\n  </p>\n\n  @if (visibility.loading()) {\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading your list…</p>\n  } @else if (!visibility.available()) {\n    <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\" role=\"status\">\n      Your list can't be loaded or saved right now, so the picker shows every trade unit.\n    </p>\n  }\n\n  <!-- #803: the last save of the list, or why not with the server reference. -->\n  <cms-status-message [outcome]=\"visibility.saveOutcome()\" (dismissed)=\"visibility.dismissSaveOutcome()\" />\n\n  <input\n    type=\"search\"\n    class=\"scoular-form-input\"\n    placeholder=\"Search code, name or company\"\n    aria-label=\"Search trade units to show\"\n    [value]=\"term()\"\n    (input)=\"term.set($any($event.target).value)\"\n  />\n\n  <div class=\"cws:flex cws:items-center cws:justify-between cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n    <span>{{ visibility.hiddenCount() }} hidden</span>\n    <!-- The way back to the full list from here, beside the picker's own Show all. -->\n    <button\n      type=\"button\"\n      class=\"cws:font-medium cws:text-scoular-blue cws:hover:underline cws:disabled:cursor-not-allowed cws:disabled:opacity-50 cws:disabled:no-underline\"\n      [disabled]=\"!visibility.available() || visibility.hiddenCount() === 0\"\n      (click)=\"visibility.unhideAll()\"\n    >\n      Unhide all\n    </button>\n  </div>\n\n  @if (failed()) {\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">The trade unit list could not be loaded.</p>\n  } @else {\n    <!-- Scrolls rather than growing: about 1,044 rows against live CTRM. -->\n    <ul class=\"cws:max-h-64 cws:overflow-y-auto cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\n      @for (location of rows(); track location.code) {\n        <li>\n          <label class=\"cws:flex cws:cursor-pointer cws:items-center cws:gap-2 cws:px-2 cws:py-1 cws:text-sm cws:hover:bg-slate-50 cws:dark:hover:bg-slate-700/60\">\n            <input\n              type=\"checkbox\"\n              [attr.aria-label]=\"'Show ' + location.code + ' ' + (location.name ?? '') + ' in the picker'\"\n              [checked]=\"!visibility.isHidden(location.code)\"\n              [disabled]=\"!visibility.available()\"\n              (change)=\"toggle(location.code, $any($event.target).checked)\"\n            />\n            <span class=\"cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ location.code }}</span>\n            <span class=\"truncate\">{{ location.name }}</span>\n          </label>\n        </li>\n      }\n    </ul>\n  }\n</div>\n",
		dependencies: [{
			kind: "component",
			type: StatusMessageComponent,
			selector: "cms-status-message",
			inputs: ["outcome", "dismissMs"],
			outputs: ["dismissed"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TradeUnitCurationComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-trade-unit-curation",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [StatusMessageComponent],
			template: "<div class=\"cws:space-y-2 cws:px-4 cws:pb-3\">\n  <!--\n    🔴 The preference-not-permission sentence (C-14, C-15 a). Without it a hidden unit reads as one\n    you are not allowed to use, and someone goes to ask for access they already hold.\n  -->\n  <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n    Untick the trade units you never use to shorten the picker. Hidden units stay one click away\n    under <strong>Show all</strong>, and links to their contracts still open.\n  </p>\n\n  @if (visibility.loading()) {\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading your list…</p>\n  } @else if (!visibility.available()) {\n    <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\" role=\"status\">\n      Your list can't be loaded or saved right now, so the picker shows every trade unit.\n    </p>\n  }\n\n  <!-- #803: the last save of the list, or why not with the server reference. -->\n  <cms-status-message [outcome]=\"visibility.saveOutcome()\" (dismissed)=\"visibility.dismissSaveOutcome()\" />\n\n  <input\n    type=\"search\"\n    class=\"scoular-form-input\"\n    placeholder=\"Search code, name or company\"\n    aria-label=\"Search trade units to show\"\n    [value]=\"term()\"\n    (input)=\"term.set($any($event.target).value)\"\n  />\n\n  <div class=\"cws:flex cws:items-center cws:justify-between cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n    <span>{{ visibility.hiddenCount() }} hidden</span>\n    <!-- The way back to the full list from here, beside the picker's own Show all. -->\n    <button\n      type=\"button\"\n      class=\"cws:font-medium cws:text-scoular-blue cws:hover:underline cws:disabled:cursor-not-allowed cws:disabled:opacity-50 cws:disabled:no-underline\"\n      [disabled]=\"!visibility.available() || visibility.hiddenCount() === 0\"\n      (click)=\"visibility.unhideAll()\"\n    >\n      Unhide all\n    </button>\n  </div>\n\n  @if (failed()) {\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">The trade unit list could not be loaded.</p>\n  } @else {\n    <!-- Scrolls rather than growing: about 1,044 rows against live CTRM. -->\n    <ul class=\"cws:max-h-64 cws:overflow-y-auto cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\n      @for (location of rows(); track location.code) {\n        <li>\n          <label class=\"cws:flex cws:cursor-pointer cws:items-center cws:gap-2 cws:px-2 cws:py-1 cws:text-sm cws:hover:bg-slate-50 cws:dark:hover:bg-slate-700/60\">\n            <input\n              type=\"checkbox\"\n              [attr.aria-label]=\"'Show ' + location.code + ' ' + (location.name ?? '') + ' in the picker'\"\n              [checked]=\"!visibility.isHidden(location.code)\"\n              [disabled]=\"!visibility.available()\"\n              (change)=\"toggle(location.code, $any($event.target).checked)\"\n            />\n            <span class=\"cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ location.code }}</span>\n            <span class=\"truncate\">{{ location.name }}</span>\n          </label>\n        </li>\n      }\n    </ul>\n  }\n</div>\n"
		}]
	}],
	ctorParameters: () => []
});
export { TradeUnitCurationComponent };

//# sourceMappingURL=cws-workspace-trade-unit-curation.component-B2DB3rgZ.mjs.map
import { t as WhatsNewReleaseListComponent } from "./cws-workspace-whats-new-release-list.component-DsD_Vkbo.mjs";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, inject } from "@angular/core";
import { RouterLink } from "@angular/router";
import { DIALOG_DATA, Dialog, DialogRef } from "@angular/cdk/dialog";
var WhatsNewDialogComponent = class WhatsNewDialogComponent {
	releases = inject(DIALOG_DATA);
	ref = inject(DialogRef);
	close() {
		this.ref.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WhatsNewDialogComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: WhatsNewDialogComponent,
		isStandalone: true,
		selector: "cms-whats-new-dialog",
		host: { classAttribute: "cws:flex cws:max-h-[85vh] cws:w-[min(36rem,calc(100vw-2rem))] cws:flex-col cws:rounded-lg cws:bg-white cws:shadow-xl cws:dark:bg-slate-800" },
		ngImport: i0,
		template: `
    <div class="cws:flex cws:items-start cws:justify-between cws:gap-4 cws:border-b cws:border-slate-200 cws:px-6 cws:py-4 cws:dark:border-slate-700">
      <div>
        <h2 id="whats-new-dialog-title" class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white">
          What's new in Contract Workspace
        </h2>
        <p id="whats-new-dialog-description" class="cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-400">
          Here's what changed since you were last here.
        </p>
      </div>
      <button
        type="button"
        class="cws:-mr-2 cws:rounded cws:p-1.5 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-700 cws:dark:text-slate-400 cws:dark:hover:bg-slate-700"
        aria-label="Close"
        (click)="close()"
      >
        <svg class="cws:size-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z" />
        </svg>
      </button>
    </div>

    <!-- The body scrolls, so several releases since a long absence never push the buttons off screen. -->
    <div class="cws:min-h-0 cws:flex-1 cws:overflow-y-auto cws:px-6 cws:py-5">
      <cms-whats-new-release-list [releases]="releases" variant="compact" />
    </div>

    <div class="cws:flex cws:items-center cws:justify-end cws:gap-4 cws:border-t cws:border-slate-200 cws:px-6 cws:py-3 cws:dark:border-slate-700">
      <a routerLink="/whats-new" class="cws:text-sm cws:font-medium cws:text-scoular-blue cws:hover:underline cws:dark:text-sky-300" (click)="close()">
        See all updates
      </a>
      <button type="button" class="scoular-btn scoular-btn-primary" cdkFocusInitial (click)="close()">Got it</button>
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}, {
			kind: "component",
			type: WhatsNewReleaseListComponent,
			selector: "cms-whats-new-release-list",
			inputs: ["releases", "variant"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WhatsNewDialogComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-whats-new-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [RouterLink, WhatsNewReleaseListComponent],
			host: { class: "cws:flex cws:max-h-[85vh] cws:w-[min(36rem,calc(100vw-2rem))] cws:flex-col cws:rounded-lg cws:bg-white cws:shadow-xl cws:dark:bg-slate-800" },
			template: `
    <div class="cws:flex cws:items-start cws:justify-between cws:gap-4 cws:border-b cws:border-slate-200 cws:px-6 cws:py-4 cws:dark:border-slate-700">
      <div>
        <h2 id="whats-new-dialog-title" class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white">
          What's new in Contract Workspace
        </h2>
        <p id="whats-new-dialog-description" class="cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-400">
          Here's what changed since you were last here.
        </p>
      </div>
      <button
        type="button"
        class="cws:-mr-2 cws:rounded cws:p-1.5 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-700 cws:dark:text-slate-400 cws:dark:hover:bg-slate-700"
        aria-label="Close"
        (click)="close()"
      >
        <svg class="cws:size-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z" />
        </svg>
      </button>
    </div>

    <!-- The body scrolls, so several releases since a long absence never push the buttons off screen. -->
    <div class="cws:min-h-0 cws:flex-1 cws:overflow-y-auto cws:px-6 cws:py-5">
      <cms-whats-new-release-list [releases]="releases" variant="compact" />
    </div>

    <div class="cws:flex cws:items-center cws:justify-end cws:gap-4 cws:border-t cws:border-slate-200 cws:px-6 cws:py-3 cws:dark:border-slate-700">
      <a routerLink="/whats-new" class="cws:text-sm cws:font-medium cws:text-scoular-blue cws:hover:underline cws:dark:text-sky-300" (click)="close()">
        See all updates
      </a>
      <button type="button" class="scoular-btn scoular-btn-primary" cdkFocusInitial (click)="close()">Got it</button>
    </div>
  `
		}]
	}]
});
function openWhatsNewDialog(injector, releases) {
	return injector.get(Dialog).open(WhatsNewDialogComponent, {
		data: releases,
		injector,
		autoFocus: "first-tabbable",
		ariaLabelledBy: "whats-new-dialog-title",
		ariaDescribedBy: "whats-new-dialog-description",
		ariaModal: true
	}).closed;
}
export { openWhatsNewDialog };

//# sourceMappingURL=cws-workspace-whats-new-dialog.component-BSJXKOOV.mjs.map
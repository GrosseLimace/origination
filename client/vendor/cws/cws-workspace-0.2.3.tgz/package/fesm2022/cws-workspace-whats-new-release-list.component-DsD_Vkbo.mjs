import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, input } from "@angular/core";
import { StatusBadgeComponent } from "@cws/shared-ui";
import { NgTemplateOutlet } from "@angular/common";
const WHATS_NEW_KIND_LABELS = {
	added: "New",
	changed: "Improved",
	fixed: "Fixed"
};
const WHATS_NEW_KIND_TONES = {
	added: "positive",
	changed: "info",
	fixed: "neutral"
};
function groupReleases(releases) {
	return releases.map((release) => ({
		release,
		groups: groupItems(release.items),
		displayDate: formatReleaseDate(release.releasedOn)
	}));
}
function groupItems(items) {
	const groups = [];
	for (const item of items) {
		const heading = item.group?.trim() || null;
		const current = groups.at(-1);
		if (current !== void 0 && current.heading === heading) current.items.push(item);
		else groups.push({
			heading,
			items: [item]
		});
	}
	return groups;
}
const MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
function formatReleaseDate(releasedOn) {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(releasedOn);
	if (match === null) return releasedOn;
	const [, year, month, day] = match;
	const name = MONTHS[Number(month) - 1];
	return name === void 0 ? releasedOn : `${name} ${Number(day)}, ${year}`;
}
var WhatsNewReleaseListComponent = class WhatsNewReleaseListComponent {
	releases = input.required(...ngDevMode ? [{ debugName: "releases" }] : /* istanbul ignore next */ []);
	variant = input("timeline", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	grouped = computed(() => groupReleases(this.releases()), ...ngDevMode ? [{ debugName: "grouped" }] : /* istanbul ignore next */ []);
	label(kind) {
		return WHATS_NEW_KIND_LABELS[kind];
	}
	tone(kind) {
		return WHATS_NEW_KIND_TONES[kind];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WhatsNewReleaseListComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: WhatsNewReleaseListComponent,
		isStandalone: true,
		selector: "cms-whats-new-release-list",
		inputs: {
			releases: {
				classPropertyName: "releases",
				publicName: "releases",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <ng-template #itemGroups let-groups>
      <div class="cws:space-y-5">
        @for (group of groups; track $index) {
          <div>
            @if (group.heading) {
              <h4 class="cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wider cws:text-slate-500 cws:dark:text-slate-400">
                {{ group.heading }}
              </h4>
            }
            <ul class="cws:space-y-2.5" [class.cws:mt-2.5]="group.heading">
              @for (item of group.items; track $index) {
                <li class="cws:flex cws:items-start cws:gap-2.5">
                  <!-- A fixed width, so the text of every item starts on one line down the list. -->
                  <span class="cws:w-20 cws:shrink-0">
                    <cms-status-badge [tone]="tone(item.kind)" [small]="true">{{ label(item.kind) }}</cms-status-badge>
                  </span>
                  <span class="cws:text-sm cws:leading-relaxed cws:text-slate-700 cws:dark:text-slate-300">{{ item.text }}</span>
                </li>
              }
            </ul>
          </div>
        }
      </div>
    </ng-template>

    @if (variant() === 'compact') {
      <div class="cws:space-y-6">
        @for (entry of grouped(); track entry.release.version) {
          <section>
            @if (grouped().length > 1) {
              <p class="cws:mb-2.5 cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400">{{ entry.displayDate }}</p>
            }
            <ng-container [ngTemplateOutlet]="itemGroups" [ngTemplateOutletContext]="{ $implicit: entry.groups }" />
          </section>
        }
      </div>
    } @else {
      <ol>
        @for (entry of grouped(); track entry.release.version; let first = $first; let last = $last) {
          <li class="cws:flex cws:gap-4 cws:sm:gap-6">
            <!-- The dated rail. Below sm it is hidden and the date moves under the title. -->
            <div class="cws:hidden cws:w-40 cws:shrink-0 cws:pt-0.5 cws:text-right cws:sm:block">
              <p class="cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white">{{ entry.displayDate }}</p>
              <p class="cws:mt-0.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">Version {{ entry.release.version }}</p>
              @if (first) {
                <span class="cws:mt-2 cws:inline-block"><cms-status-badge tone="positive" [small]="true">Current</cms-status-badge></span>
              }
            </div>

            <!-- A marker per release, joined by a line that stops at the last. -->
            <div class="cws:flex cws:shrink-0 cws:flex-col cws:items-center" aria-hidden="true">
              <span
                class="cws:mt-1.5 cws:size-3 cws:shrink-0 cws:rounded-full cws:ring-4 cws:ring-white cws:dark:ring-slate-800"
                [class.cws:bg-scoular-blue]="first"
                [class.cws:bg-slate-300]="!first"
                [class.cws:dark:bg-slate-600]="!first"
              ></span>
              @if (!last) {
                <span class="cws:mt-1 cws:w-px cws:flex-1 cws:bg-slate-200 cws:dark:bg-slate-700"></span>
              }
            </div>

            <div class="cws:min-w-0 cws:flex-1" [class.cws:pb-10]="!last">
              <h3 class="cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white">{{ entry.release.title }}</h3>
              <p class="cws:mt-0.5 cws:text-xs cws:text-slate-500 cws:sm:hidden cws:dark:text-slate-400">
                {{ entry.displayDate }} · Version {{ entry.release.version }}
              </p>
              @if (entry.release.summary) {
                <p class="cws:mt-1.5 cws:text-sm cws:leading-relaxed cws:text-slate-600 cws:dark:text-slate-400">{{ entry.release.summary }}</p>
              }
              <div class="cws:mt-4">
                <ng-container [ngTemplateOutlet]="itemGroups" [ngTemplateOutletContext]="{ $implicit: entry.groups }" />
              </div>
            </div>
          </li>
        }
      </ol>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}, {
			kind: "component",
			type: StatusBadgeComponent,
			selector: "cms-status-badge",
			inputs: ["tone", "small"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WhatsNewReleaseListComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-whats-new-release-list",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet, StatusBadgeComponent],
			template: `
    <ng-template #itemGroups let-groups>
      <div class="cws:space-y-5">
        @for (group of groups; track $index) {
          <div>
            @if (group.heading) {
              <h4 class="cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wider cws:text-slate-500 cws:dark:text-slate-400">
                {{ group.heading }}
              </h4>
            }
            <ul class="cws:space-y-2.5" [class.cws:mt-2.5]="group.heading">
              @for (item of group.items; track $index) {
                <li class="cws:flex cws:items-start cws:gap-2.5">
                  <!-- A fixed width, so the text of every item starts on one line down the list. -->
                  <span class="cws:w-20 cws:shrink-0">
                    <cms-status-badge [tone]="tone(item.kind)" [small]="true">{{ label(item.kind) }}</cms-status-badge>
                  </span>
                  <span class="cws:text-sm cws:leading-relaxed cws:text-slate-700 cws:dark:text-slate-300">{{ item.text }}</span>
                </li>
              }
            </ul>
          </div>
        }
      </div>
    </ng-template>

    @if (variant() === 'compact') {
      <div class="cws:space-y-6">
        @for (entry of grouped(); track entry.release.version) {
          <section>
            @if (grouped().length > 1) {
              <p class="cws:mb-2.5 cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400">{{ entry.displayDate }}</p>
            }
            <ng-container [ngTemplateOutlet]="itemGroups" [ngTemplateOutletContext]="{ $implicit: entry.groups }" />
          </section>
        }
      </div>
    } @else {
      <ol>
        @for (entry of grouped(); track entry.release.version; let first = $first; let last = $last) {
          <li class="cws:flex cws:gap-4 cws:sm:gap-6">
            <!-- The dated rail. Below sm it is hidden and the date moves under the title. -->
            <div class="cws:hidden cws:w-40 cws:shrink-0 cws:pt-0.5 cws:text-right cws:sm:block">
              <p class="cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white">{{ entry.displayDate }}</p>
              <p class="cws:mt-0.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">Version {{ entry.release.version }}</p>
              @if (first) {
                <span class="cws:mt-2 cws:inline-block"><cms-status-badge tone="positive" [small]="true">Current</cms-status-badge></span>
              }
            </div>

            <!-- A marker per release, joined by a line that stops at the last. -->
            <div class="cws:flex cws:shrink-0 cws:flex-col cws:items-center" aria-hidden="true">
              <span
                class="cws:mt-1.5 cws:size-3 cws:shrink-0 cws:rounded-full cws:ring-4 cws:ring-white cws:dark:ring-slate-800"
                [class.cws:bg-scoular-blue]="first"
                [class.cws:bg-slate-300]="!first"
                [class.cws:dark:bg-slate-600]="!first"
              ></span>
              @if (!last) {
                <span class="cws:mt-1 cws:w-px cws:flex-1 cws:bg-slate-200 cws:dark:bg-slate-700"></span>
              }
            </div>

            <div class="cws:min-w-0 cws:flex-1" [class.cws:pb-10]="!last">
              <h3 class="cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white">{{ entry.release.title }}</h3>
              <p class="cws:mt-0.5 cws:text-xs cws:text-slate-500 cws:sm:hidden cws:dark:text-slate-400">
                {{ entry.displayDate }} · Version {{ entry.release.version }}
              </p>
              @if (entry.release.summary) {
                <p class="cws:mt-1.5 cws:text-sm cws:leading-relaxed cws:text-slate-600 cws:dark:text-slate-400">{{ entry.release.summary }}</p>
              }
              <div class="cws:mt-4">
                <ng-container [ngTemplateOutlet]="itemGroups" [ngTemplateOutletContext]="{ $implicit: entry.groups }" />
              </div>
            </div>
          </li>
        }
      </ol>
    }
  `
		}]
	}],
	propDecorators: {
		releases: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "releases",
				required: true
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}]
	}
});
export { WhatsNewReleaseListComponent as t };

//# sourceMappingURL=cws-workspace-whats-new-release-list.component-DsD_Vkbo.mjs.map
import { CWS_ENVIRONMENT_NAME, WhatsNewStore, buildLine } from "./cws-workspace.mjs";
import { t as WhatsNewReleaseListComponent } from "./cws-workspace-whats-new-release-list.component-DsD_Vkbo.mjs";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, effect, inject } from "@angular/core";
var WhatsNewPageComponent = class WhatsNewPageComponent {
	store = inject(WhatsNewStore);
	environmentName = inject(CWS_ENVIRONMENT_NAME, { optional: true });
	buildLine = computed(() => buildLine(this.store.currentVersion(), this.store.build(), this.environmentName), ...ngDevMode ? [{ debugName: "buildLine" }] : /* istanbul ignore next */ []);
	constructor() {
		this.store.load();
		effect(() => {
			if (this.store.loaded()) this.store.markCurrentAsSeen();
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WhatsNewPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: WhatsNewPageComponent,
		isStandalone: true,
		selector: "cms-whats-new-page",
		ngImport: i0,
		template: `
    <div class="cws:mx-auto cws:w-full cws:max-w-4xl cws:px-4 cws:py-8">
      <div class="cws:text-center">
        <h1 class="cws:text-2xl cws:font-bold cws:tracking-tight cws:text-slate-900 cws:dark:text-white">What's new</h1>
        <p class="cws:mt-2 cws:text-sm cws:text-slate-600 cws:dark:text-slate-400">
          Everything we have shipped to Contract Workspace, newest first.
        </p>
      </div>

      @if (store.loading()) {
        <p class="cws:mt-10 cws:text-center cws:text-sm cws:text-slate-500 cws:dark:text-slate-400" role="status">Loading release notes…</p>
      } @else if (store.unavailable()) {
        <p class="cws:mt-10 cws:text-center cws:text-sm cws:text-red-700 cws:dark:text-red-400" role="alert">
          Release notes could not be loaded. Refresh to try again.
        </p>
      } @else if (store.releases().length === 0) {
        <p class="cws:mt-10 cws:text-center cws:text-sm cws:text-slate-500 cws:dark:text-slate-400">No updates have been published yet.</p>
      } @else {
        <div class="cws:mt-8 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800">
          <div class="cws:p-6 cws:sm:p-8">
            <cms-whats-new-release-list [releases]="store.releases()" />
          </div>

          @if (buildLine(); as line) {
            <!-- Quote this line in a support ticket and we can tell exactly which build you were on. -->
            <div class="cws:border-t cws:border-slate-200 cws:px-6 cws:py-3 cws:text-center cws:dark:border-slate-700">
              <span class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ line }}</span>
            </div>
          }
        </div>
      }
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: WhatsNewReleaseListComponent,
			selector: "cms-whats-new-release-list",
			inputs: ["releases", "variant"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WhatsNewPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-whats-new-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [WhatsNewReleaseListComponent],
			template: `
    <div class="cws:mx-auto cws:w-full cws:max-w-4xl cws:px-4 cws:py-8">
      <div class="cws:text-center">
        <h1 class="cws:text-2xl cws:font-bold cws:tracking-tight cws:text-slate-900 cws:dark:text-white">What's new</h1>
        <p class="cws:mt-2 cws:text-sm cws:text-slate-600 cws:dark:text-slate-400">
          Everything we have shipped to Contract Workspace, newest first.
        </p>
      </div>

      @if (store.loading()) {
        <p class="cws:mt-10 cws:text-center cws:text-sm cws:text-slate-500 cws:dark:text-slate-400" role="status">Loading release notes…</p>
      } @else if (store.unavailable()) {
        <p class="cws:mt-10 cws:text-center cws:text-sm cws:text-red-700 cws:dark:text-red-400" role="alert">
          Release notes could not be loaded. Refresh to try again.
        </p>
      } @else if (store.releases().length === 0) {
        <p class="cws:mt-10 cws:text-center cws:text-sm cws:text-slate-500 cws:dark:text-slate-400">No updates have been published yet.</p>
      } @else {
        <div class="cws:mt-8 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800">
          <div class="cws:p-6 cws:sm:p-8">
            <cms-whats-new-release-list [releases]="store.releases()" />
          </div>

          @if (buildLine(); as line) {
            <!-- Quote this line in a support ticket and we can tell exactly which build you were on. -->
            <div class="cws:border-t cws:border-slate-200 cws:px-6 cws:py-3 cws:text-center cws:dark:border-slate-700">
              <span class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ line }}</span>
            </div>
          }
        </div>
      }
    </div>
  `
		}]
	}],
	ctorParameters: () => []
});
export { WhatsNewPageComponent };

//# sourceMappingURL=cws-workspace-whats-new-page.component-DXsgI7Ud.mjs.map
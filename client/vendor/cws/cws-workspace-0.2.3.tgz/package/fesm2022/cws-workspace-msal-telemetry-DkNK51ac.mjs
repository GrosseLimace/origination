import { TelemetrySeverity } from "@cws/core-telemetry";
function msalEventTelemetry(message) {
	const error = message.error;
	return {
		name: `MSAL.${message.eventType}`,
		properties: {
			interactionType: message.interactionType ?? void 0,
			msalCorrelationId: message.correlationId || void 0,
			errorName: error?.name,
			errorCode: error?.errorCode,
			errorSubcode: error?.subError || void 0,
			errorMessage: error?.message
		}
	};
}
function forwardMsalEvent(message, insights) {
	const event = msalEventTelemetry(message);
	insights.trackEvent(event.name, event.properties);
	if (message.error) insights.trackException(message.error, TelemetrySeverity.Warning, { msalEventType: message.eventType });
}
export { forwardMsalEvent };

//# sourceMappingURL=cws-workspace-msal-telemetry-DkNK51ac.mjs.map
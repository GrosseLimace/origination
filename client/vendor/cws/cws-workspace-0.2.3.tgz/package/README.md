# @cws/workspace

The whole Contract Workspace as one mountable package (ADR-18, E9 F9.8). It holds the chrome (top bar,
module nav, trade-unit picker, user menu, availability banner, shortcut layer), the route table
`cwsRoutes()`, and `provideCwsWorkspace(config)`, which wires every seam the screens read. The
standalone shell is a bootstrap of `CwsWorkspaceComponent` from this package, and a host such as
Originations mounts the same component and routes under a prefix of its choosing. What a host must
provide, and the two ways it can supply authentication, are in `docs/HOST-CONTRACT.md`.

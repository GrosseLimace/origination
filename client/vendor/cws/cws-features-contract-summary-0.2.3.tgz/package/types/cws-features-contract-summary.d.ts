import { AddendumCall, AddendumTemplate, AddendumType, AttachmentOptions, BasisLocationOptions, BasisLocationOptionsSource, BasisLocationSelection, CollectionCopyPlan, ContractAttachment, ContractCreateAttachment, ContractDetail, ContractDetailResponse, ContractFieldKind, ContractLayoutField, ContractLayoutSection, ContractLmsFlag, ContractPrice, ContractShipPeriod, ContractTab, ContractTabId, ContractTemplate, ContractTextAnswer, ContractTextCode, ContractWriteAddendum, ContractWriteCollections, ContractWriteResult, CwsContractField, FormConfigBundle, PriceCopyRun, PricingSource, StoredAddendum, remarkKey } from "@cws/domain-contracts";
import { ContractForm, FieldVerdict, MarketCascade, ResolvedFormConfig, ShipPeriodIssue, ShipPeriodReconciliation, ShipPeriodRow, ValidationSummaryEntry, ValidationSummaryItem } from "@cws/shared-form-engine";
import * as i0 from "@angular/core";
import { Signal } from "@angular/core";
import { WriteFailureOutcome } from "@cws/core-http";
import { CmsNavigationIntent } from "@cws/core-host-context";
import { BreadcrumbCrumb, ConfirmsNavigation, GridBadge, GridColumn, GridSort, MutationOutcome, RemoteData } from "@cws/shared-ui";
import { Observable } from "rxjs";
/**
 * The detail screen's field layout — **now the shared one**, not a second copy.
 *
 * 🔴 This file used to declare its own six sections and 34 fields, written to mirror the add/edit
 * screen's table. The two drifted, as two hand-maintained copies of one decision do: they disagreed on
 * where Incoterms sat, on what sat at position 2 of the Contract section, and most of all on *which
 * fields exist* — 70 of the 104 editable fields had no row here at all, so a field could be changed on
 * one screen and be unfindable on the other. That is what this file no longer is.
 *
 * `CONTRACT_LAYOUT_SECTIONS` in `@cws/domain-contracts` is the layout for both screens. What remains
 * here is the part that is genuinely this screen's: how a value is *found* for a contract, which
 * differs because this screen reads a mapped aggregate and the entry screen reads raw writable values.
 *
 * ### Where a value comes from, and why it takes two sources
 *
 * `GET /contracts/{number}` returns a **mapped aggregate** modelling roughly 40 scalars — it cannot
 * supply the other 70. `GET /contracts/{number}/fields` returns all 104 **writable** values keyed by
 * CTRM field name, and strips the read-only ones. Neither is a superset, so the screen reads both:
 *
 * | Source | Supplies |
 * |---|---|
 * | `/fields` | every writable field, by CTRM field name |
 * | the aggregate | the read-only fields `/fields` strips, **and** the writable ones it already models |
 *
 * ⚠ **The aggregate wins where both carry a value, and that overlap is deliberate.** An earlier version
 * of this file mapped only the read-only fields, on the reasoning that two sources for one value is
 * Known Issue 23's shape. It made the screen strictly worse: `/fields` is a supplementary read that can
 * fail, and with nothing beneath it a failure blanked contract date, currency and quantity — fields
 * this screen has always rendered from the aggregate. The overlap is what makes the new fields additive
 * rather than a trade. See {@link mergeContractValues}.
 */
export type FieldKind = ContractFieldKind;
/** Re-exported so the component's imports stay one deep; the definition lives in the shared layout. */
export type DetailField = ContractLayoutField;
/** Re-exported for the same reason. */
export type DetailSection = ContractLayoutSection;
/** The sections, in display order — one table, shared with the add/edit screen. */
export declare const CONTRACT_DETAIL_SECTIONS: readonly ContractLayoutSection[];
/** Why a field is permanently blank, by component name. */
export declare const DETAIL_EMPTY_NOTES: Readonly<Record<string, string>>;
/**
 * Everything the aggregate models, keyed by CTRM field name.
 *
 * ⚠ **Only fields whose CTRM name is unambiguous.** `header.commodity` is deliberately absent: `ConDS`
 * carries three commodity fields and this one has already been the wrong one once — the detail screen
 * rendered a blank commodity while the grid rendered `YELLOW CORN`, which is Known Issue 23 biting
 * through the mapper. `commodity_code` comes from `/fields`, where CTRM names it itself.
 *
 * 🔴 **`contract_number` is absent for exactly the same reason, and it was the second instance.**
 * `header.contractNumber` is the *composed key* — `ComposeNumber` concatenates
 * `prefixType + prefixCommodity + number` and appends `-suffix` when present — while CTRM's
 * `contract_number` field is only the **7-character middle component**. Mapping one onto the other
 * handed the control `SCW227618` where `constraints.json` declares `maxLength: 7`, so the screen
 * displayed `SCW2276`: a truncated key, which under CTRM's positional scheme names a *different
 * contract*. Found in QA on 2026-09-08 (F-04). `contract_number` now comes from `/fields`, where CTRM
 * names it itself — the same resolution as `commodity_code`.
 *
 * The read-only entries at the end are the ones `/fields` can never supply, because `upsertContract`
 * refuses them and the endpoint strips them.
 */
export declare function aggregateValues(contract: ContractDetail): Readonly<Record<string, string | number | null>>;
/**
 * Joins CTRM's resolved trader NAME onto the trader-initials control, for display only (#199, F-15).
 *
 * The screen used to carry two rows: `trader_initials`, which CTRM accepts, and `trader`, which CTRM
 * derives and refuses on a write. The second was `readOnly` and could only ever mirror the first, so
 * it is gone from the layout and its value is folded into the surviving control here — one row
 * rendering `GME — GISSELLE M. ESTEVEZ`, with the form model still holding `GME`.
 *
 * 🔴 **The combo is an UPGRADE applied only when a name is actually in hand, never the default.**
 * `cms-code-combo` is a closed list: it discards anything typed that matches no option. With one
 * option that is exactly right for viewing and editing a contract whose trader CTRM has already
 * resolved — and it would be a trap on the create screen, where there is no aggregate, no name, and
 * therefore no options at all. A user would face a control that silently refused every keystroke.
 * So the layout's default is a plain text input and this function upgrades it or leaves it alone.
 *
 * ⚠ **It never fabricates.** Initials with no name stay a text input showing the initials, which is
 * #199's third criterion — the alternative, rendering `GME — GME`, would assert a resolution CTRM did
 * not make.
 *
 * 🔑 **This is also why the 1,099-row `TR` code table is not fetched.** #219 criterion 8 rules out
 * shipping an unfiltered 87 KB trader list, and the only trader this screen ever needs to *display* is
 * the one on the contract in front of it. Picking a different trader on create is still typed, and
 * scoping that list to a location remains CTRM's open question rather than ours.
 */
export declare function withResolvedTrader(config: ResolvedFormConfig, contract: ContractDetail | null): ResolvedFormConfig;
/**
 * Turns the two market-month text boxes into combos filtered to the contract's own market — #201.
 *
 * The months come from `reference/market-months`, which takes the location, the commodity **and the
 * market code**. That last one is what makes the list meaningful: CTRM validates the month against
 * `FHMM01`–`FHMM15` on the Grain Factors row for that market (`wnr051e:5202-5216`), so an unfiltered
 * list would offer months a save then refuses.
 *
 * 🔴 **An upgrade applied only when the list has settled with rows, exactly like
 * {@link withResolvedTrader}.** A combo is a closed list and discards anything typed that matches no
 * option, so filling one from an in-flight or empty fetch would block entry on a screen that looks
 * entirely functional — #219 criterion 7, which cost a session to find the first time.
 *
 * | `months` | what this does |
 * |---|---|
 * | `null` — in flight | nothing; the control stays a text box |
 * | `[]` — settled, no rows | nothing; there is no market month for this commodity and location |
 * | rows | upgrade both controls to combos |
 */
export declare function withMarketMonths(config: ResolvedFormConfig, months: readonly {
  readonly code: string;
  readonly description: string;
}[] | null): ResolvedFormConfig;
/**
 * Every value the screen can show for a contract, by CTRM field name.
 *
 * 🔴 **`/fields` first, the aggregate on top — the aggregate wins where both have a value.** The
 * ordering is load-bearing in two directions:
 *
 * - **Robustness.** `/fields` is a supplementary read that can fail. With the aggregate merely filling
 *   gaps, a failure would blank fields the screen has always rendered — contract date, currency,
 *   quantity — because they would have had no other source. Layered this way, a failed `/fields` costs
 *   only the ~70 fields the aggregate never modelled, and the screen still shows what it always did.
 * - **Types.** The aggregate arrives typed: numbers as numbers, dates as `DateOnly` strings that
 *   `formatContractDate` already handles. `/fields` is CTRM's raw `base_data`, where they are strings
 *   in CTRM's own shapes. Preferring the aggregate keeps the values that were already rendering
 *   correctly rendering identically, so this change adds fields without moving any existing one.
 *
 * Where the two disagree on a field both carry, that is a defect in one of them rather than a
 * preference — Known Issue 23's shape — and the aggregate winning means the screen keeps showing what
 * it showed before anyone noticed.
 */
export declare function mergeContractValues(contract: ContractDetail | null, writableValues: Readonly<Record<string, unknown>> | null): Readonly<Record<string, unknown>>;
/**
 * The three confirmation statuses, rendered as the progress indicator docs/02 §4.4 specifies.
 *
 * **Order is the workflow order and is load-bearing**: approved → customer confirmed → broker
 * confirmed. BR-065 makes each of these *derived from a populated field* rather than a workflow state,
 * so this is a display of three independent fields that happen to progress — not a state machine, and
 * a later stage can be populated with an earlier one blank.
 *
 * Not layout rows: they are a progress indicator rather than three labelled values, which is also why
 * the shared layout deliberately has no row for `trader_approval_status` and its two siblings.
 */
export declare const CONFIRMATION_STAGES: readonly {
  readonly label: string;
  readonly value: (contract: ContractDetail) => string | null;
  readonly emptyNote?: string;
}[];
/** Formats a field for display. Dates use the long, unambiguous form — this screen has the room. */
export declare function formatFieldValue(value: unknown, kind?: FieldKind): string;
/**
 * **The record screen's basis location: a price term and a place, chosen rather than typed (#1218;
 * the server half #598, merged in #1214).**
 *
 * In its own file so the record screen gains a handful of lines rather than a section, and so the
 * rules here can be read without the other 7,000.
 *
 * ### What the screen does with the field
 *
 * - **The text field stays, read-only.** It shows CTRM's `basis_location`, which is the record
 *   (ruled 2026-10-26, Q-F). It is never sent: the save carries the selection as `basisLocation`
 *   and the server composes the text, refusing typed `fields.basis_location` once the unit enforces.
 * - **On an edit, the selection is read back from the text** through `options?text=`: recognised
 *   is preselected, `null` is legacy text, and a retired term or place asks for a re-pick.
 * - **A copy and a template carry the text they hold**, which is recognised the same way, so the
 *   create sends the selection rather than the text.
 * - 🔴 **A BCO unit (`CtrmBuilt`) sends NOTHING.** CTRM builds the text from the incoterm and the
 *   named place; the server refuses a selection there, and refuses typed text once the unit enforces.
 */
/** Under the field on a BCO unit (ruled 2026-10-26): the issue's sentence, word for word. */
declare const BASIS_LOCATION_CTRM_BUILT_MESSAGE = "Set by CTRM for this trade unit from the incoterm and named place.";
/**
 * Added on a BCO create, where the field is still blank. 🔴 **No preview of the text, deliberately:**
 * CTRM composes it from the incoterm and the named place's CITY (`wnr051e:5265-5266`), and the screen
 * has the named place's code, not its city, so any preview here would be a guess.
 */
declare const BASIS_LOCATION_CTRM_BUILT_CREATE_MESSAGE = "CTRM fills it in when the contract is saved.";
/** Under the field when the contract's text is not a composition of the lists (`recognised: null`). */
declare const BASIS_LOCATION_LEGACY_MESSAGE = "Legacy text, will be replaced when you choose a price term and place below.";
/** Under the field when the text names a retired term, place or region. */
declare const BASIS_LOCATION_RETIRED_MESSAGE = "This basis location uses a retired price term or place. Re-pick it below.";
/** Under the field when the options could not be read. */
declare const BASIS_LOCATION_FAILED_MESSAGE = "The price term and place lists could not be loaded, so the basis location cannot be chosen right now.";
/** Under the field when the host provides no options source. */
declare const BASIS_LOCATION_UNOFFERED_MESSAGE = "The basis location is chosen from price term and place lists, which are not offered here.";
/** Beside the pickers while the unit reports rather than enforces. */
declare const BASIS_LOCATION_OPTIONAL_MESSAGE = "Optional for now: this trade unit does not require a basis location yet.";
/** Under the place pickers when a term is chosen alone on a special type that is not hedge-to-arrive. */
declare const BASIS_LOCATION_PLACE_NEEDED_MESSAGE = "Choose a place too. Only a hedge-to-arrive special type may leave it out.";
/** The ids the pickers carry, so a refusal's summary line can focus them. */
declare const BASIS_LOCATION_TERM_ID = "BasisLocationTerm";
declare const BASIS_LOCATION_PLACE_ID = "BasisLocationPlace";
declare const BASIS_LOCATION_REGION_ID = "BasisLocationRegion";
/** What the screen has read for the unit. */
type BasisLocationLoad = {
  readonly status: 'idle';
} | {
  readonly status: 'unoffered';
} | {
  readonly status: 'loading';
} | {
  readonly status: 'failed';
} | {
  readonly status: 'loaded';
  readonly options: BasisLocationOptions;
  readonly text: string | null;
};
/** The pickers' values. Any member may be unpicked; at most one of place and region is set. */
interface BasisLocationPick {
  readonly termId: number | null;
  readonly placeId: number | null;
  readonly regionId: number | null;
}
/** A save's refusals of the selection, split by the control each one belongs to. */
interface BasisLocationErrors {
  readonly general: readonly string[];
  readonly term: readonly string[];
  readonly place: readonly string[];
}
declare const NO_BASIS_LOCATION_ERRORS: BasisLocationErrors;
/** What the record screen hands over. Every member is a signal the screen already has. */
interface BasisLocationInputs {
  readonly source: BasisLocationOptionsSource | null;
  /** Whether the screen is editing (edit or create). Nothing is read in view mode. */
  readonly active: Signal<boolean>;
  readonly isCreate: Signal<boolean>;
  /** The contract's trade unit: CTRM's on an edit, the Location control's on a create. */
  readonly tradeUnit: Signal<string | null>;
  /**
   * The BasisLocation control's text. `undefined` until the form is built, so the options are read
   * once, with the text, rather than once without it and again with it.
   */
  readonly text: Signal<string | null | undefined>;
  /** The special type, for the hedge-to-arrive allowance. */
  readonly specialType: Signal<string | null>;
}
/**
 * The basis location's state for one record screen. Built in a field initializer, so its
 * `toSignal` runs in the screen's injection context and is torn down with it.
 */
declare class BasisLocationState {
  private readonly inputs;
  /** The unit's options, read again when the unit or the text changes (a template applied, say). */
  readonly load: Signal<BasisLocationLoad>;
  /** The loaded options, or `null`. */
  readonly options: Signal<BasisLocationOptions | null>;
  /** 🔴 A BCO unit: CTRM builds the text, the field is read-only and nothing is sent. */
  readonly ctrmBuilt: Signal<boolean>;
  /** Whether the pickers are drawn: loaded, editing, and not a BCO unit. */
  readonly offered: Signal<boolean>;
  /** Which place pickers the unit's rule shows. */
  readonly offers: Signal<{
    readonly places: boolean;
    readonly regions: boolean;
  }>;
  /** "Optional for now": the unit reports rather than enforces. */
  readonly optional: Signal<boolean>;
  /**
   * What the screen preselects: the recognised selection, each half only while it is live, because a
   * retired term or place is not in the lists the pickers offer.
   */
  private readonly preselected;
  /**
   * What a change is measured against: the preselection, and after a save that stays here, what was
   * saved. Never the full recognised selection, so a record opened on a retired value and saved
   * untouched sends nothing rather than half a selection.
   */
  private readonly baseline;
  /** The pickers' values, reset whenever the options are read again. */
  readonly pick: import("@angular/core").WritableSignal<BasisLocationPick>;
  /** Whether the user changed a picker. */
  readonly changed: Signal<boolean>;
  /**
   * The `basisLocation` member a save carries, or `undefined` for none.
   *
   * - 🔴 Never on a BCO unit, and never before the options are read.
   * - A create sends whatever is picked; an edit only a change, as every other edit field is (#229).
   * - A place picked with no term goes as term `0`, which the server refuses on `basisLocation.term`
   *   ("Choose a price term") rather than the pick being dropped without a word.
   */
  readonly selectionToSend: Signal<BasisLocationSelection | undefined>;
  /** The text the server will compose from the pick, shown beside the pickers; `null` with no term. */
  readonly preview: Signal<string | null>;
  /** A term picked alone, on a special type the server will not let go without a place. */
  readonly placeNeeded: Signal<boolean>;
  /**
   * The sentence under the field, or `null`: what the text is (legacy, retired), who sets it (BCO), or
   * why it cannot be chosen.
   */
  readonly note: Signal<string | null>;
  constructor(inputs: BasisLocationInputs);
  /** Chooses a term; the empty value clears it. */
  setTerm(value: string): void;
  /** Chooses a city and state, clearing any region: a selection names at most one. */
  setPlace(value: string): void;
  /** Chooses a region, clearing any city and state. */
  setRegion(value: string): void;
  /** After a save that stays on this screen, what was saved is the new baseline. */
  markSaved(): void;
}
/** A save's refusals of the selection, by the control each belongs to. */
declare function basisLocationErrorsOf(fieldErrors: Readonly<Record<string, readonly string[]>>): BasisLocationErrors;
/** Whether a key is one of CWS's own selection refusals (CTRM's `basis_location` is a field). */
declare function isBasisLocationKey(name: string): boolean;
/**
 * What a list read of the addendum types or templates is doing. `unavailable` is a host whose API
 * does not offer the route, or no source at all.
 *
 * #1043: read ONCE by the record screen, which decides from the types whether the record has an
 * Addendum section, and handed to the section, which offers the templates. One read of each, not two.
 */
type ListState$1<T> = {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
  readonly items: readonly T[];
} | {
  readonly status: 'unavailable';
  readonly reason: string;
} | {
  readonly status: 'failed';
  readonly message: string;
};
declare function listStateOf<T>(answer: AddendumCall<readonly T[]>): ListState$1<T>;
/** Said when no type source is wired: nothing can be offered without knowing what Legal approved. */
declare const NO_TYPE_SOURCE = "Addendum types are not offered here, so no template can be offered: whether Legal has approved this type is unknown.";
/**
 * A source's list as a stream of states, starting at `loading`. A source that throws reads `failed`,
 * never a crash; no source reads `unavailable` with `absent`.
 */
declare function listStates<T>(source: {
  list(): Observable<AddendumCall<readonly T[]>>;
} | null, absent: string): Observable<ListState$1<T>>;
/**
 * What the record screen hands Preview: the contract half of what its save would send (#830).
 * `contractNumber` is `null` on a create.
 */
interface AddendumPreviewContract {
  readonly contractNumber: string | null;
  readonly fields: Readonly<Record<string, unknown>>;
  readonly collections?: ContractWriteCollections;
}
/** The outcome of pressing Preview. */
type PreviewState = {
  readonly status: 'idle';
} | {
  readonly status: 'previewing';
} | {
  readonly status: 'open';
  readonly blob: Blob;
} | {
  readonly status: 'unavailable';
  readonly reason: string;
} | {
  readonly status: 'failed';
  readonly message: string;
  readonly correlationId?: string;
};
/**
 * **The Addendum section of the record screen (F10.3b; Preview and save, #830)**, for every special
 * type with an addendum type.
 *
 * The record screen renders this when the server lists an addendum type for the contract's special
 * type (#1043), and hands it that type, the code and the two lists it read. It shows a picker over the
 * templates the server says serve that special type (#676: `specialTypes`, for a type Legal has made
 * `available`, through `addendumTemplatesFor`), the picked template's `addendum_*` fields, and Preview.
 *
 * ### 🔴 The fields come from the picked TEMPLATE (#1043), never from a frontend list
 *
 * Exactly its `addendum_*` mappings (`addendumEntryFieldsOf`), so a template Legal adds or revises is
 * fillable with no frontend release. Its other mappings print without the originator: CTRM fields
 * from the contract, `customer.*` from the customer master and `generated.addendumDate` from the
 * server. And the draft sends only the picked template's fields: a value typed under another template
 * is kept on screen but never sent, because the server refuses a key the template does not use.
 *
 * ### The addendum is stored by the SAVE, not by this section (ruled by GEstevez, 2026-10-13)
 *
 * Preview renders what a save would store, watermarked `DRAFT - NOT SAVED`, and stores nothing. The
 * record screen's Save reads {@link draft} and sends it with the contract when {@link edited} says the
 * user changed something here, so CTRM pulls the stored document inside that save (ADR-20).
 *
 * ### 🔴 The field values live HERE, and never in the contract form
 *
 * The contract form is the CTRM payload: the save path builds the upsert's `fields` by walking the
 * writable CTRM fields and reading each control. These values are CWS's, so they stay in this
 * component's own state and reach the server only as the save's separate `addendum` member. The
 * record screen's spec pins that no addendum value ever appears in `fields`.
 *
 * ⚠ **The sources are injected optionally**, so a host embedding the record screen without them gets
 * the section with a sentence saying the addendum is not offered, and its provider list does not
 * change.
 */
declare class ContractAddendumSectionComponent {
  private readonly previewSource;
  private readonly destroyRef;
  /**
   * The addendum type the server lists for the contract's special type (#1043). `null` only when the
   * record shows the section for a refused save's addendum reasons without having read the types.
   */
  readonly addendumType: import("@angular/core").InputSignal<AddendumType | null>;
  /** The contract's CTRM special type, which the templates' `specialTypes` must include. */
  readonly specialType: import("@angular/core").InputSignal<string | null>;
  /**
   * The templates, as the record screen read them (#1043: once, by the screen). `null` is a host with
   * no template source, which gets the section with a sentence saying the addendum is not offered.
   */
  readonly templatesState: import("@angular/core").InputSignal<ListState$1<AddendumTemplate> | null>;
  /** The addendum types, as the record screen read them. */
  readonly typesState: import("@angular/core").InputSignal<ListState$1<AddendumType>>;
  /** The contract's trade unit, for templates restricted to some trade units. */
  readonly tradeUnit: import("@angular/core").InputSignal<string | null>;
  /**
   * Whether this user may change the addendum here: the record is in edit or create mode, and the
   * account holds the write grant. 🔴 Never the CTRM gate (#485): the addendum is CWS's.
   */
  readonly canEdit: import("@angular/core").InputSignal<boolean>;
  /** The contract half of a preview request, from the record screen's own save path. */
  readonly previewContract: import("@angular/core").InputSignal<(() => AddendumPreviewContract | null) | null>;
  /** The save's refusals under `addendum.*`, said beside the fields they concern (#830). */
  readonly saveErrors: import("@angular/core").InputSignal<readonly string[]>;
  /** #818: the addendum CWS currently holds for the contract (#858's list), offered to open. `null` shows nothing. */
  readonly storedAddendum: import("@angular/core").InputSignal<StoredAddendum | null>;
  /** #818: how many earlier addendums the contract has besides the current one (or all of them, with none current). */
  readonly earlierAddendums: import("@angular/core").InputSignal<number>;
  /** #818: why the list of stored addendums could not be read, said beside the section. `null` shows nothing. */
  readonly addendumListProblem: import("@angular/core").InputSignal<string | null>;
  /** The contract's required fields still blank, by label (JFrisbie, 2026-10-23): no preview until filled. */
  readonly missingRequired: import("@angular/core").InputSignal<readonly string[]>;
  protected readonly offered: import("@angular/core").Signal<boolean>;
  /** The special type as the section compares it: trimmed, as CTRM pads codes. */
  private readonly code;
  /**
   * The typed values, keyed by CWS storage name. Reset when the special type changes, so a value
   * typed for one addendum cannot be sent under another.
   */
  protected readonly values: import("@angular/core").WritableSignal<Readonly<Record<string, string>>>;
  /**
   * Whether the user changed a value or the template since the special type was chosen. The save
   * sends the addendum only then (or when the special type changed), because omitting it keeps the
   * stored one, and this section cannot read the stored values back yet (#858): sending its blank
   * fields would replace them.
   */
  private readonly touched;
  readonly edited: import("@angular/core").Signal<boolean>;
  /**
   * The templates on offer: active, serving this contract's special type, for an available type, in
   * this trade unit. 🔴 Nothing while the types are unknown: an unapproved type must not be offered
   * because its availability could not be read.
   */
  protected readonly templates: import("@angular/core").Signal<readonly AddendumTemplate[]>;
  /** Set when the types are loaded and this special type is not available, so the screen says why. */
  protected readonly typeNotAvailable: import("@angular/core").Signal<boolean>;
  /** The picked template. Defaults to the first on offer, and follows the list when it changes. */
  protected readonly selectedTemplateId: import("@angular/core").WritableSignal<number | null>;
  /** The picked template, or `null` when none is on offer. */
  protected readonly selectedTemplate: import("@angular/core").Signal<AddendumTemplate | null>;
  /**
   * **The fields the originator fills in: exactly the picked template's `addendum_*` mappings (#1043).**
   * A different template, or a new version of this one, is a different list, with no frontend release.
   */
  readonly entryFields: import("@angular/core").Signal<readonly CwsContractField[]>;
  /**
   * The fields the picked template prints, so the section can mark them as required (#818). Since
   * #1043 every field shown is one, so every field is marked.
   *
   * 🔴 Presentation only. The server is the authority: it refuses a blank used field on save, and
   * the section adds no refusal of its own, because a second rule would drift from it. Only this
   * section's own `addendum_*` inputs can be marked: a placeholder mapped to a CTRM field that is
   * blank in CTRM is still refused only at save.
   */
  protected readonly usedFields: import("@angular/core").Signal<Set<string>>;
  protected readonly preview: import("@angular/core").WritableSignal<PreviewState>;
  protected readonly canPressPreview: import("@angular/core").Signal<boolean>;
  /**
   * **What the preview waits for** (JFrisbie, 2026-10-23): every required field filled, the contract's
   * on any tab and this addendum's own. Every field the template prints is required here (#818).
   */
  protected readonly previewHold: import("@angular/core").Signal<readonly string[]>;
  protected readonly unavailableReason: import("@angular/core").Signal<string | null>;
  /**
   * The addendum as a save or a preview sends it: the picked template and the filled-in values.
   * Blank fields are left out rather than sent empty, so the server names a field nobody filled in.
   *
   * 🔴 **Only the picked template's fields** (#1043). A value typed before the template changed stays
   * on screen for if the user goes back, but is never sent: the server refuses an entered key the
   * template does not use, which is the refusal that stopped every Legal template on QA.
   */
  draft(): ContractWriteAddendum;
  /** Called by the record screen once a save carrying this addendum was accepted. */
  markSaved(): void;
  protected inputType(field: CwsContractField): string;
  protected inputMode(field: CwsContractField): string | null;
  protected valueOf(field: CwsContractField): string;
  protected setValue(field: CwsContractField, value: string): void;
  protected selectTemplate(value: string): void;
  /** Posts what the save would carry to the preview route, and shows the draft PDF it answers. */
  protected runPreview(): void;
  protected readonly previewBlob: import("@angular/core").Signal<Blob | null>;
  /** A refused preview, with the server's reference (#803). Preview writes nothing, so no success. */
  protected readonly previewOutcome: import("@angular/core").Signal<MutationOutcome | null>;
  protected closePreview(): void;
  protected readonly templatesFailure: import("@angular/core").Signal<string | null>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractAddendumSectionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractAddendumSectionComponent, "cws-contract-addendum-section", never, {
    "addendumType": {
      "alias": "addendumType";
      "required": false;
      "isSignal": true;
    };
    "specialType": {
      "alias": "specialType";
      "required": false;
      "isSignal": true;
    };
    "templatesState": {
      "alias": "templatesState";
      "required": false;
      "isSignal": true;
    };
    "typesState": {
      "alias": "typesState";
      "required": false;
      "isSignal": true;
    };
    "tradeUnit": {
      "alias": "tradeUnit";
      "required": false;
      "isSignal": true;
    };
    "canEdit": {
      "alias": "canEdit";
      "required": false;
      "isSignal": true;
    };
    "previewContract": {
      "alias": "previewContract";
      "required": false;
      "isSignal": true;
    };
    "saveErrors": {
      "alias": "saveErrors";
      "required": false;
      "isSignal": true;
    };
    "storedAddendum": {
      "alias": "storedAddendum";
      "required": false;
      "isSignal": true;
    };
    "earlierAddendums": {
      "alias": "earlierAddendums";
      "required": false;
      "isSignal": true;
    };
    "addendumListProblem": {
      "alias": "addendumListProblem";
      "required": false;
      "isSignal": true;
    };
    "missingRequired": {
      "alias": "missingRequired";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The sentence every upload, replace and removal on an existing contract says first (#915). */
declare const ATTACHMENT_SAVES_CONTRACT = "This saves the contract: the version bumps and approval is required again.";
/** Added when the contract's addendum is not CWS's while its special type now takes a CWS one (pull brief 4.8). */
declare const ATTACHMENT_EXPIRES_CARA = "Saving will also store a CWS addendum and expire the Cara one.";
type OptionsState = {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
  readonly options: AttachmentOptions;
} | {
  readonly status: 'failed';
  readonly message: string;
  readonly correlationId: string | null;
};
/** 🔴 `failed` is never rendered as an empty list. */
type ListState = {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
  readonly attachments: readonly ContractAttachment[];
} | {
  readonly status: 'failed';
  readonly message: string;
  readonly correlationId: string | null;
};
type ViewerState = {
  readonly status: 'idle';
} | {
  readonly status: 'loading';
  readonly documentId: string;
} | {
  readonly status: 'open';
  readonly documentId: string;
  readonly blob: Blob;
  readonly fileName: string;
} | {
  readonly status: 'failed';
  readonly documentId: string;
  readonly message: string;
  readonly correlationId: string | null;
};
/** What {@link ContractAttachmentsComponent.saved} carries. */
interface AttachmentSaved {
  readonly result: ContractWriteResult;
  readonly message: string;
}
/** A file picked on a create, waiting for the first Save. */
interface PendingAttachment extends ContractCreateAttachment {
  readonly key: number;
}
/**
 * **The contract's CWS attachments on the record screen (#915, F10.6; #499's routes, ADR-23).**
 *
 * ### On an existing contract
 *
 * The list (every status, newest first) with each version openable in the PDF viewer, and, for a user
 * who may write, Attach, Replace and Remove. 🔴 **Each of the three is its own contract update**: the
 * version bumps and approval is required again, so each asks first, in those words, and adds the Cara
 * sentence when the record says so ({@link caraWarning}). A `409` says the server's `detail` verbatim,
 * and Continue repeats the same request with `confirmResend`; Cancel sends nothing.
 *
 * ### On a create
 *
 * No list and no request. Files picked here wait for the first Save, which sends them with the create
 * as multipart ({@link pendingChange}); the save's own refusals of them come back through
 * {@link saveErrors}.
 *
 * ### Nothing is hard-coded
 *
 * The `accept` attribute, the type picker and the size hint come from `GET /attachment-options`. If
 * that read fails, nothing can be attached, and the panel says so rather than guessing.
 *
 * ### 🔴 A refused file leaves the panel as it was
 *
 * A refusal changes only the message: the list is not touched, and the picked file and type stay so
 * the user can change the type or pick another file. Only a `saved` answer clears the picker and
 * re-reads the list. A lost CTRM answer re-reads the list too, because the change may have landed.
 */
declare class ContractAttachmentsComponent {
  private readonly source;
  private readonly confirm;
  /** The contract, or `null` on a create, which has no list and sends nothing itself. */
  readonly contractNumber: import("@angular/core").InputSignal<string | null>;
  /** Whether this user may change the contract now (grant, mode, CTRM availability). */
  readonly canWrite: import("@angular/core").InputSignal<boolean>;
  /** Adds {@link ATTACHMENT_EXPIRES_CARA} to the confirmation. */
  readonly caraWarning: import("@angular/core").InputSignal<boolean>;
  /** On a create: the save's refusals of the picked files, said under them. */
  readonly saveErrors: import("@angular/core").InputSignal<readonly string[]>;
  /**
   * Whether this panel says a saved write itself. The record screen passes `false` and says it at the
   * top instead, because it re-reads the contract (whose version moved), and that re-read unmounts
   * this panel with whatever message it was showing.
   */
  readonly announcesSaves: import("@angular/core").InputSignal<boolean>;
  /** An attachment write was saved, with the sentence that says so in our words (never CTRM's, #967). */
  readonly saved: import("@angular/core").OutputEmitterRef<AttachmentSaved>;
  /** On a create: the files picked so far, for the first Save to send. */
  readonly pendingChange: import("@angular/core").OutputEmitterRef<readonly ContractCreateAttachment[]>;
  protected readonly offered: boolean;
  protected readonly isCreate: import("@angular/core").Signal<boolean>;
  protected readonly optionsState: import("@angular/core").WritableSignal<OptionsState>;
  protected readonly listState: import("@angular/core").WritableSignal<ListState>;
  protected readonly viewer: import("@angular/core").WritableSignal<ViewerState>;
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  protected readonly picked: import("@angular/core").WritableSignal<File | null>;
  protected readonly documentType: import("@angular/core").WritableSignal<string>;
  protected readonly replacing: import("@angular/core").WritableSignal<ContractAttachment | null>;
  protected readonly pending: import("@angular/core").WritableSignal<readonly PendingAttachment[]>;
  private pendingKey;
  private listSubscription;
  private contentSubscription;
  private writeSubscription;
  protected readonly options: import("@angular/core").Signal<AttachmentOptions | null>;
  protected readonly accept: import("@angular/core").Signal<string>;
  /** *"PDF only, up to 10 MB a file."* */
  protected readonly hint: import("@angular/core").Signal<string | null>;
  protected readonly attachments: import("@angular/core").Signal<readonly ContractAttachment[]>;
  /** The picker is offered only with the options read and a user who may write. */
  protected readonly canPick: import("@angular/core").Signal<boolean>;
  protected readonly canSend: import("@angular/core").Signal<boolean>;
  constructor();
  protected statusLabel(attachment: ContractAttachment): string;
  protected typeLabel(code: string): string;
  protected size(bytes: number): string;
  /** Reads the picked file, and refuses it here when it cannot go: a Word file by name, say. */
  protected onPick(event: Event): void;
  protected onType(event: Event): void;
  /** Starts a replace of one current version: the type is preset to its own. */
  protected startReplace(attachment: ContractAttachment): void;
  protected cancelReplace(): void;
  /** Attach or Replace, after the confirmation. On a create, adds the file to the pending set instead. */
  protected send(): void;
  protected remove(attachment: ContractAttachment): void;
  protected removePending(key: number): void;
  protected open(attachment: ContractAttachment): void;
  protected closeViewer(): void;
  protected retryList(): void;
  protected retryOptions(): void;
  /** The confirmation every write on an existing contract asks, in the ruled words (#915). */
  private askToSave;
  /**
   * Sends one write, and on a `409` asks whether to send it again. Continue repeats the SAME call with
   * `confirmResend`; Cancel sends nothing and leaves the panel as it was.
   */
  private run;
  /**
   * Adds a picked file to the create's set, refusing a second copy of the same bytes under the same
   * type (the server's `400 cws-attachment-malformed`) and a set over CTRM's caps.
   */
  private addPending;
  private readOptions;
  private readList;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractAttachmentsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractAttachmentsComponent, "cws-contract-attachments", never, {
    "contractNumber": {
      "alias": "contractNumber";
      "required": false;
      "isSignal": true;
    };
    "canWrite": {
      "alias": "canWrite";
      "required": false;
      "isSignal": true;
    };
    "caraWarning": {
      "alias": "caraWarning";
      "required": false;
      "isSignal": true;
    };
    "saveErrors": {
      "alias": "saveErrors";
      "required": false;
      "isSignal": true;
    };
    "announcesSaves": {
      "alias": "announcesSaves";
      "required": false;
      "isSignal": true;
    };
  }, {
    "saved": "saved";
    "pendingChange": "pendingChange";
  }, never, never, true, never>;
}
/** One code as the section renders it. */
interface ContractTextRow {
  readonly code: ContractTextCode;
  readonly label: string;
  readonly text: string;
  /** True when what would be printed is the template's text: no override, or one equal to it. */
  readonly showsTemplate: boolean;
  readonly canEdit: boolean;
  readonly remaining: number;
}
/** A text the user typed, for one code. */
interface ContractTextChange {
  readonly code: string;
  readonly text: string;
}
/**
 * **The Contract Text section (#907): the contract's archetype's codes, one field per code, showing the
 * template text until the user changes it.**
 *
 * Presentational. The record screen owns the values, decides what a save sends
 * (`contractTextNotesPayload`) and whether the change re-confirms the contract; this renders them.
 *
 * - **Which codes, in what order, and whether each can be changed come from the answer**, never from a
 *   list in this file (BR-001a; the lesson of the BIO/FOG tabs in docs/01).
 * - **A code the answer marks not editable is shown, never offered for editing.**
 * - **Clearing a field returns it to the template**: CTRM deletes a note only by its code with blank
 *   text, so a blank override cannot be stored and the template is what would print.
 */
declare class ContractTextSectionComponent {
  readonly answer: import("@angular/core").InputSignal<ContractTextAnswer>;
  readonly values: import("@angular/core").InputSignal<Readonly<Record<string, string>>>;
  /** Edit or create with the write grant. False renders the text read-only. */
  readonly editing: import("@angular/core").InputSignal<boolean>;
  /** Why editing is refused though the screen is editing (notes CTRM could not read), or `null`. */
  readonly locked: import("@angular/core").InputSignal<string | null>;
  /** Why the text cannot be saved as it stands, or `null`. */
  readonly refusal: import("@angular/core").InputSignal<string | null>;
  /** Whether the edits on screen would re-confirm the contract when saved. */
  readonly reconfirms: import("@angular/core").InputSignal<boolean>;
  readonly textChange: import("@angular/core").OutputEmitterRef<ContractTextChange>;
  protected readonly rows: import("@angular/core").Signal<readonly ContractTextRow[]>;
  protected readonly anyEditable: import("@angular/core").Signal<boolean>;
  protected change(code: string, text: string): void;
  protected restore(row: ContractTextRow): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractTextSectionComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractTextSectionComponent, "cws-contract-text-section", never, {
    "answer": {
      "alias": "answer";
      "required": true;
      "isSignal": true;
    };
    "values": {
      "alias": "values";
      "required": true;
      "isSignal": true;
    };
    "editing": {
      "alias": "editing";
      "required": false;
      "isSignal": true;
    };
    "locked": {
      "alias": "locked";
      "required": false;
      "isSignal": true;
    };
    "refusal": {
      "alias": "refusal";
      "required": false;
      "isSignal": true;
    };
    "reconfirms": {
      "alias": "reconfirms";
      "required": false;
      "isSignal": true;
    };
  }, {
    "textChange": "textChange";
  }, never, never, true, never>;
}
/**
 * One row of the Log tab's timeline (F3.7).
 *
 * `kind` keeps a form-configuration change visually distinct from a change to the contract itself —
 * they are interleaved because both answer "why does this contract look like this?", but reading a
 * configuration edit as somebody having changed the contract would be worse than not showing it.
 */
interface TimelineRow {
  /** `note` is a CWS log note with its words (#912); the audit's own "Note added" row it replaces is dropped. */
  readonly kind: 'contract' | 'configuration' | 'note';
  /** A note's words, as stored. `null` on every other row. */
  readonly text: string | null;
  readonly key: string;
  readonly at: string;
  readonly actor: string;
  readonly what: string;
  readonly detail: string | null;
  /** The instant as the reader's clock shows it (#567); `at` stays the machine-readable value. */
  readonly atLabel: string;
  /** Each changed field, labelled as the form labels it. Empty when the entry carries none (#567). */
  readonly changes: readonly {
    readonly label: string;
    readonly from: string | null;
    readonly to: string | null;
  }[];
  /** Collections the write replaced whole, by CTRM name. */
  readonly collectionsReplaced: readonly string[];
  /** What the entry did to the contract's attachments, by document id and type, never a file name (#915). */
  readonly attachments: readonly string[];
}
/**
 * Which of the record screen's three jobs this instance is doing.
 *
 * Not three components and not three templates — see the class remarks. Everything conditional reads
 * {@link ContractRecordPageComponent.mode}, and the conditions are deliberately few: the controls'
 * activity, the toolbar, and which reads are issued.
 */
export type ContractRecordMode = 'view' | 'edit' | 'create';
/** How a save ended, for the screen to report. */
interface SaveState {
  readonly status: 'idle' | 'saving' | 'saved' | 'failed';
  readonly result?: ContractWriteResult;
  /** Field name to reasons, straight from the API's RFC 7807 `errors`. */
  readonly fieldErrors?: Readonly<Record<string, readonly string[]>>;
  readonly formErrors?: readonly string[];
  /**
   * What the failure means for the contract (#556). Only `refused` carries reasons; the other two
   * are CTRM not answering, and the banner says what that does and does not tell us.
   */
  readonly failure?: WriteFailureOutcome;
  /** The server's reference for a failed save (#803), or `null` when it returned none. */
  readonly correlationId?: string | null;
  /**
   * #951: what the server says happened to a write whose answer was lost (`not-applied` or
   * `outcome-unknown`), or `null` when it said nothing. Shown as said; the retry advice beside it is
   * keyed on {@link failure} and never on this text (#556).
   */
  readonly lostDetail?: string | null;
}
export declare class ContractRecordPageComponent implements ConfirmsNavigation {
  private readonly details;
  private readonly writes;
  private readonly mintIdempotencyKey;
  /**
   * **This create's idempotency key** (#557), minted on first use and then held for the life of the
   * create: every retry sends the same one, so a create whose answer was lost cannot become a second
   * contract once the server honours it (#558). A restored draft brings its own key back; a
   * discarded draft or a completed create retires it, because what follows is a different contract.
   *
   * ⚠ Null in edit and view, and never sent on an update: an update re-applies the same values onto a
   * freshly read merge base, so a repeat does not compound.
   */
  private createKey;
  private readonly numbers;
  private readonly configs;
  private readonly tradeUnit;
  private readonly permissions;
  /**
   * Where this screen goes when it leaves, and how it records its own position (F9.1, #416).
   *
   * 🔴 **This used to be `inject(Router)`, and the screen navigated to ABSOLUTE paths** —
   * `/contracts/{n}`, `/`, `/approvals`. Embedded, that escapes the host's outlet entirely and lands
   * the user somewhere the host never routed. The 2026-09-18 host-workspace spike found it (#335
   * finding 3) and this library's own `public-api.ts` claimed the opposite was already true.
   *
   * The screen now states an intent and the host decides what it means. Standalone that is
   * `routerHostContext`, which reproduces exactly the five calls this replaced.
   */
  private readonly hostContext;
  /** Where this screen tells its host what happened (F9.5). */
  private readonly events;
  /**
   * Hands the host an intent, and publishes it as a `navigation-requested` event (F9.5).
   *
   * 🔴 **Every navigation goes through here, never through `hostContext.navigate` directly.** The
   * event is the host's record of where the user went, so a call site that bypassed this would
   * navigate with no event, and a host keeping the user in its own outlet would never know.
   */
  private requestNavigation;
  /**
   * The customer lookup (F4.3b), or `null` where the host provides none — in which case blurring
   * the Customer id confirms nothing and the screen behaves as it did before the lookup existed.
   */
  private readonly customers;
  /**
   * What the last Customer id blur found: the id asked about, the note to show under the field, and
   * the name to write into the read-only Customer name field (`null` clears it).
   *
   * 🔴 Redacted is a note that says so, never a blank and never the literal in the name field —
   * the same rule as the grid's customer-names verdict, because a blank is indistinguishable from
   * the gap the screen had before the directory existed.
   */
  private readonly customerConfirmation;
  /** Leads the breadcrumb — the same `CODE · Name` the shell's picker shows, so the two agree. */
  protected readonly tradeUnitLabel: import("@angular/core").Signal<string | null>;
  /**
   * The contract this screen is showing, or empty when creating.
   *
   * Bound from the route by `withComponentInputBinding()` rather than read from `ActivatedRoute`: a
   * snapshot read would leave one contract's data sitting under another contract's URL when
   * navigating between them.
   *
   * 🔴 **The transform is not defensive tidying — without it the create screen does not render.**
   * `withComponentInputBinding()` does not leave an unmatched parameter alone; it *sets* the input, to
   * `undefined`. A default value only applies when nothing ever writes the input, and the router
   * writes it on every navigation — so on `/contracts/new`, which has no `:contractNumber` segment,
   * this is `undefined`, and the first `.trim()` threw during change detection. Add mode was broken in
   * the browser and green in every test, because a component input set directly is not the same thing
   * as a bound route parameter.
   */
  readonly contractNumber: import("@angular/core").InputSignalWithTransform<string, string | null | undefined>;
  /**
   * Which mode to render in, supplied by the route's `data`.
   *
   * `withComponentInputBinding()` binds `data` to inputs as well as path parameters, so each route
   * states its own mode and no component here infers one from the URL shape.
   *
   * ⚠ **The transform exists for the same reason as `contractNumber`'s**, and it is the same trap:
   * route `data` that omits `mode` does not leave this input alone, it sets it to `undefined`. All
   * three routes set it explicitly *and* this defaults — belt and braces, because the failure mode is
   * an edit screen that silently renders as a view (or worse, the reverse).
   */
  readonly mode: import("@angular/core").InputSignalWithTransform<ContractRecordMode, ContractRecordMode | null | undefined>;
  protected readonly isCreate: import("@angular/core").Signal<boolean>;
  protected readonly isView: import("@angular/core").Signal<boolean>;
  /**
   * FileBound's archive for this contract (docs/02 §8, #756), or `null`, which renders nothing: no
   * template configured, or a create, which has no number until CTRM issues one. Only the contract
   * number is interpolated, URL-encoded.
   */
  private readonly externalLinks;
  protected readonly fileBoundUrl: import("@angular/core").Signal<string | null>;
  /** Every CTRM location code, for BR-002a branch 3. Joins an already-cached set (F2.3c, #423). */
  private readonly locationCodes;
  /**
   * **BR-002a** — whether this contract's customer is intercompany.
   *
   * Read from the contract as **loaded** rather than from the live form. The lock exists to stop
   * someone editing an intercompany purchase they opened; re-evaluating it as the customer control
   * changes would let the screen lock itself mid-edit and discard work in progress without warning,
   * which is a worse outcome than the under-lock — and CTRM enforces the write server-side either
   * way. ⚠ Stated as a limit rather than left to be discovered: changing the customer to an
   * intercompany one during an edit does **not** lock the form.
   */
  protected readonly intercompany: import("@angular/core").Signal<import("@cws/domain-contracts").IntercompanyVerdict>;
  /**
   * **BR-002** — the whole form read-only because this is an intercompany *purchase*.
   *
   * 🔴 **Fails OPEN.** Every uncertain input — no customer, a customer too short to slice, a
   * locations set that has not loaded, an unknown prefix — leaves this `false` and the form
   * editable. A false positive here blocks a trader from work they are entitled to do with no way
   * round it from the screen, which is strictly worse than an under-lock CTRM may still refuse.
   */
  protected readonly intercompanyLock: import("@angular/core").Signal<boolean>;
  /**
   * A CTRM field's value on the contract as loaded, or `null`.
   *
   * ⚠ The **loaded** values, not the live form — see {@link intercompany}. Blank is normalised to
   * `null` so "present but empty" cannot read as a value.
   */
  private ctrmFieldValue;
  /**
   * True when the controls accept input. The one thing the whole mode distinction comes down to.
   *
   * 🔴 **BR-002's intercompany-purchase lock is part of it** (F2.3c, #423). It was `!isView()`
   * alone, so an intercompany purchase rendered fully editable — the read-only rule existed in the
   * requirements and nowhere in the code.
   */
  protected readonly isEditable: import("@angular/core").Signal<boolean>;
  /**
   * **A read-only contract** (JFrisbie, 2026-10-23): closed, or an intercompany purchase (BR-002). The
   * screen offers no Edit and no Save for it, as the grid offers no Edit, rather than buttons that
   * refuse. The same two reasons, in the same words, as the grid's `editRefusalFor`.
   */
  protected readonly contractReadOnly: import("@angular/core").Signal<boolean>;
  /** Why the contract is read-only, said where Edit would be, or `null`. */
  protected readonly readOnlyReason: import("@angular/core").Signal<"This contract is closed" | "Intercompany purchase contracts are read-only" | null>;
  /**
   * The grid state to return to, packed by the home screen into one opaque parameter.
   *
   * Read from the snapshot: it describes the journey that reached this screen, so it cannot change
   * while the screen is open.
   *
   * Absent when the contract was reached by a direct link or a refresh, in which case the breadcrumb
   * still works and simply lands on an unfiltered workspace. That fallback matters — a breadcrumb that
   * only functioned when you arrived a particular way would be worse than none.
   */
  private readonly route;
  private readonly returnTo;
  /**
   * The contract this create is a copy of, from `?copyFrom=`, or `null` for an ordinary create.
   *
   * **A query parameter on `/contracts/new` rather than a route of its own**, because a copy is not a
   * fourth mode — it is a create with a seed source. Every mode-dependent branch on this screen stays
   * as it is, and the copy inherits the create journey whole: the trade-unit default, the number
   * issuance, the save path, the create-versus-update discriminator.
   *
   * It also makes a copy linkable and refresh-proof, which docs/02 §1.3 asks of every route — reload
   * `/contracts/new?copyFrom=SCW227618` and you get the same screen rather than an empty form.
   *
   * Read from the **snapshot**, like `returnTo` and for the same reason: it describes the journey that
   * reached this screen, so it cannot change while the screen is open. The form seeds once, so a
   * mid-life change to the seed source would have nowhere to go even if it could happen.
   */
  protected readonly copyFrom: string | null;
  /** `?customer=`: seeded into the Customer id, then confirmed exactly as a typed id is on blur. */
  private readonly linkCustomer;
  /** `?template=`: a template id or name, applied once through {@link onApplyTemplate}. */
  protected readonly linkTemplate: string | null;
  /** `?tradeUnit=`: the trade unit the link asked for. */
  protected readonly linkTradeUnit: string | null;
  /**
   * True when the link named a trade unit this create is not working under: the caller does not hold
   * it, or `/me` could not say. The active unit was kept, and the banner says so rather than letting a
   * contract be created quietly under a unit the link did not ask for.
   */
  protected readonly linkTradeUnitRefused: import("@angular/core").Signal<boolean>;
  /** The unit this create is working under, for the banner when the link's was not applied. */
  protected readonly activeTradeUnit: import("@angular/core").Signal<string | null>;
  /** Why `?template=` was not applied, or `null` when it was or none was asked for. */
  protected readonly linkTemplateRefusal: import("@angular/core").WritableSignal<"missing" | "unreadable" | "unsupported" | null>;
  /** Set once the link's template has been applied or refused, so a rebuild cannot re-apply it. */
  private linkTemplateSettled;
  /**
   * Applies `?template=` once the form exists and the trade unit's templates have answered.
   *
   * ⚠ By id first, then by name ignoring case: an id is what the picker holds, a name is what a person
   * types into a link. A name two templates share applies the first, as the picker lists them.
   */
  private readonly applyLinkTemplate;
  /** The pricing seam. Optional: a host without it offers no copy-with-pricing, and says so. */
  private readonly pricing;
  /** Holds each run across the navigation from this create to the contract it makes. */
  private readonly pricingCopies;
  /** #818 on #858: the addendums CWS stored for this contract, read from the server. Optional seam. */
  private readonly addendumLists;
  /** Bumped after an accepted save, so a save that stays on this screen lists what it stored. */
  private readonly addendumListAttempt;
  /**
   * Whether the Addendum section is on this record, the only place the list shows. A boolean of its
   * own so the read below re-runs when the section comes or goes, and not each time a change of
   * special type selects another addendum type.
   *
   * #1043: the server's addendum types decide it ({@link addendumType}). ⚠ Also while a refused save
   * names the addendum: a save the server refused for its addendum has to have somewhere to say why
   * and to be fixed, even when the types read failed and the screen could not tell it needed one.
   */
  protected readonly hasAddendumSection: import("@angular/core").Signal<boolean>;
  /**
   * Re-read when the contract, the page's {@link attempt} (Retry/Refresh) or {@link addendumListAttempt}
   * moves, or when the section appears. `null` with no source, on a create (blank number), and on a
   * record with no Addendum section, which then asks nothing. A source that throws reads `failed`.
   *
   * 🔴 **Each read carries the number it was made for.** `toSignal` holds the last answer while the
   * next is in flight, so when the router reuses this screen for another contract the previous
   * contract's list is still here until the new one answers. {@link currentAddendumListRead} ignores
   * it, rather than a `startWith(null)` that would also blank the list on a same-contract re-read.
   */
  private readonly addendumListRead;
  /** The last list read, but only when it was made for the contract on screen now. */
  private readonly currentAddendumListRead;
  private readonly addendumSummary;
  /** #818: the addendum CWS currently holds for this contract, or `null`. */
  protected readonly storedAddendum: import("@angular/core").Signal<import("@cws/domain-contracts").StoredAddendum | null>;
  /** #818: how many addendums the contract had besides the current one (all of them, with none current). */
  protected readonly earlierAddendums: import("@angular/core").Signal<number>;
  /**
   * The list's own failure, said in the section. `null` while loading, when listed, with no source,
   * and when the route is `unavailable`: a passive read on a host without the route says nothing,
   * rather than a permanent problem line on every addendum-typed record.
   */
  protected readonly addendumListProblem: import("@angular/core").Signal<string | null>;
  /** #803: a save's success, left by the edit screen and taken once by the view it navigates to. */
  private readonly saveAnnouncements;
  /** The save this screen arrived after, announced here because the screen that made it is gone. */
  protected readonly arrivedAfterSave: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly pricingCopyOffered: boolean;
  /**
   * True on a copy reached through "Copy contract w/ pricing" (`?withPricing=true`, beside
   * `copyFrom`). Read from the snapshot, like `copyFrom`, for the same reason.
   */
  protected readonly isCopyWithPricing: import("@angular/core").Signal<boolean>;
  /** The inline confirm in the copy menu. */
  protected readonly copyPricingConfirm: import("@angular/core").WritableSignal<boolean>;
  /** How many price sequences this contract holds, for the confirm (ruled: named above ten). */
  protected readonly sourcePriceCount: import("@angular/core").Signal<number>;
  protected readonly copyWithPricingIntent: import("@angular/core").Signal<CmsNavigationIntent>;
  protected confirmCopyWithPricing(): void;
  /**
   * The breadcrumb's target, as router `queryParams`.
   *
   * Unpacked into an object rather than navigated as a URL string so the crumb can be a real
   * `routerLink` anchor: it gets an `href`, so middle-click and "open in new tab" work, and a keyboard
   * user reaches it with Tab. A `(click)` handler calling `navigateByUrl` would look identical and be
   * none of those things.
   */
  protected readonly returnParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * Which screen the breadcrumb goes back to, and what it is called there.
   *
   * 🔴 **This crumb used to be a hard-coded "Contracts" pointing at `/`.** That was right while the
   * workspace was the only way in, and the approvals and pricing queues made it wrong in the worst
   * way — it still *worked*, so an approver who opened a row, read the contract and pressed the
   * crumb was quietly moved to a different screen, losing the queue's filters, its sort and their
   * place in it. Read from the URL so a reload or a pasted link renders the same crumb as a click.
   */
  /**
   * The `from` parameter exactly as the URL carried it — unnormalised, possibly `null`.
   *
   * Held separately because the **host** is what turns a logical origin into a route (F9.1): a
   * `navigate` intent carries this raw value, and the host's own resolver normalises it. Passing
   * `origin().path` instead would put an absolute path back into the intent, which is the defect
   * this replaced.
   *
   * ⚠ **Read from `snapshot` once, and both consumers must stay on this one field.** Until #1052
   * `paramsForTab` dropped `from` on every tab switch; it now carries it, but a later read of
   * `queryParamMap` would still describe the current URL rather than the journey that arrived, and
   * a host that rewrites the query string could still make the two disagree.
   */
  private readonly originParam;
  protected readonly origin: import("@angular/core").Signal<import("@cws/domain-contracts").RecordOriginDescriptor>;
  /**
   * Every screen behind this one, as links — not just the one the journey started on.
   *
   * 🔴 **One crumb was wrong for the approvals journey, and wrong the way that is hardest to see: it
   * worked.** "View full record" on the review screen left a trail reading `Approvals › SS1242898`,
   * so the only way back went *past* the screen the user had actually come from. They opened the
   * record in order to decide on the contract, and the trail offered them the queue instead — losing
   * the decision they were in the middle of, with nothing appearing broken.
   *
   * The middle crumb is **derived** rather than passed: `from=approvals` is set in exactly one place,
   * so its presence already says the review screen is behind you. See {@link recordTrail}.
   */
  protected readonly trail: import("@angular/core").Signal<readonly import("@cws/domain-contracts").RecordCrumb[]>;
  protected readonly editIntent: import("@angular/core").Signal<CmsNavigationIntent>;
  /** The journey as an intent's `state`, for a navigation that stays on this record (#1148). */
  private journeyState;
  protected readonly newIntent: CmsNavigationIntent;
  protected readonly copyIntent: import("@angular/core").Signal<CmsNavigationIntent>;
  /** A create cancels to the workspace; an edit cancels back to this record, on its tab. */
  protected readonly cancelIntent: import("@angular/core").Signal<CmsNavigationIntent>;
  /** The breadcrumb, each crumb carrying its host-resolved link. */
  protected readonly crumbs: import("@angular/core").Signal<readonly BreadcrumbCrumb[]>;
  protected hrefFor(intent: CmsNavigationIntent): string;
  /**
   * A click on one of the links above.
   *
   * A plain left click is handed to the host and published as `navigation-requested`. A modified or
   * middle click is left to the browser, which opens the host's href in a new tab or window: that is
   * why these stay real anchors rather than buttons.
   */
  /**
   * #967: Cancel while a save is in flight (the typed-number check included) would leave with the write
   * outstanding: CTRM may still apply it, and its outcome would have no screen to report on. Cancel is
   * an `<a>`, so `disabled` does nothing; it is `aria-disabled` and this refuses the click, which is also
   * what Enter on a focused link raises. It comes back when the save answers, either way.
   */
  protected readonly cancelDisabled: import("@angular/core").Signal<boolean>;
  /** The in-page save panel's title (#967): the same sentence as the announcement, in our words. */
  protected readonly savedPanelTitle: import("@angular/core").Signal<string>;
  protected followCancel(event: MouseEvent): void;
  protected follow(event: MouseEvent, intent: CmsNavigationIntent): void;
  /**
   * The last crumb — the page you are on, which is never a link.
   *
   * ⚠ **Mode-dependent, which is why it is computed here rather than left to the breadcrumb.** The
   * shared component renders a trail; what the current page is CALLED is this screen's business,
   * and this is the only screen where it is not simply the contract number.
   */
  protected readonly currentCrumb: import("@angular/core").Signal<string>;
  /** Bumped by Retry so a retry genuinely re-issues every request. */
  private readonly attempt;
  /**
   * The driver values the user has chosen on a create, which re-resolve the configuration (§10.2).
   *
   * Only create mode: on an existing contract the dimensions come from the contract itself, and
   * re-resolving mid-edit because someone changed the commodity is a v2 question (the screen says so
   * when the commodity is dirty).
   */
  private readonly createDrivers;
  /**
   * What to resolve the configuration for (ADR-17 D1).
   *
   * 🔴 **View and edit resolve by CONTRACT NUMBER, not by trade unit**, and that is the whole reason
   * the resolve endpoint takes one. The most significant dimension is the contract type class, which
   * is CTRM's `text_description` — a *read-only, derived* field. It is present in the raw aggregate
   * and stripped from `GET /contracts/{n}/fields`, so a client that tried to assemble the key itself
   * would silently lose the dimension that outranks the other two. The server derives all three from
   * a fresh read instead.
   *
   * Create has no contract yet, so it passes what it knows: the shell's trade unit, plus whatever
   * driver fields the user has filled in.
   */
  private readonly resolutionKey;
  /**
   * The form configuration, and the state the async container renders.
   *
   * 🔴 **The configuration is what gates the screen, in every mode — including view.** That is a real
   * change: the read-only screen used to render as soon as the aggregate arrived. It cannot any more,
   * because the fields are controls now and the controls come from the configuration; rendering
   * without it would show a record with no fields at all.
   */
  protected readonly configState: import("@angular/core").Signal<RemoteData<FormConfigBundle>>;
  /**
   * The configuration to render, holding the LAST loaded one while a re-resolve is in flight (#197).
   *
   * 🔴 **This is what stops a driver change tearing the screen down.** Changing commodity or trade unit
   * re-resolves the configuration, and `configState` correctly goes back to `loading` — but the screen
   * was gated on that state directly, so all 111 controls unmounted and the page dropped to "Loading
   * contract" until the fetch returned. QA finding F-09 reported it as the *form rebuild*; it is not,
   * and the rebuild is unavoidable anyway — a different driver genuinely is a different set of
   * controls. What is avoidable is blanking the screen while waiting.
   *
   * ⚠ **The retained value must be the LAST LOADED one, never a stale-and-wrong one.** It is replaced
   * the moment a new configuration arrives, and `formKey()` keys the rebuild on the configuration's own
   * version — so the fields swap in place when the answer comes back, and a re-resolve that wins the
   * same row does not churn the form at all.
   *
   * `linkedSignal` rather than an effect: this is a derivation with memory, and an effect writing a
   * signal is the shape that produces a second source of truth nobody can find.
   */
  private readonly retainedBundle;
  /**
   * The resolved configuration, with the trader name joined onto the initials control (#199).
   *
   * 🔴 **Overlaid HERE rather than in the config source, because this is the only place that holds
   * both halves.** `HttpFormConfigSource` resolves a configuration for a trade unit and has never
   * seen the contract; the trader's name is a property of the contract. Pushing the contract into the
   * config source to satisfy one field would make every configuration fetch depend on a record read.
   *
   * Every consumer of `bundle()` — the rendered form, `visibleSections`, the tab counts — reads the
   * overlaid copy, so the control, the badge and the payload cannot disagree about what is on screen.
   */
  protected readonly bundle: import("@angular/core").Signal<FormConfigBundle | null>;
  /**
   * The code — description pairs as CTRM holds them, from the record's raw `base_data` (#595).
   *
   * 🔴 **The raw `/fields` read, not the aggregate**, because the descriptions are not modelled on the
   * aggregate at all: they are no longer rows (the combo IS the pair), and `/fields` is the one read
   * that still carries them. View mode shows a legacy hand-typed description through this exactly as it
   * was saved; a create has nothing saved, so nothing is overlaid.
   */
  private readonly savedCodePairs;
  /**
   * Every control the user has CHANGED, by component name, with its current value (#595, #143).
   *
   * Changed means dirty AND different from the value it was seeded with, so typing a value and then
   * putting it back is no change. Pristine controls are never here, so a seeded value can never raise
   * a hint or a warning. Snapshotted on `valueChanges` the way the cascade's facts are, never read
   * from the engine's value signal (see {@link cascadeFacts}).
   */
  private readonly changedValues;
  private watchChangedValues;
  /**
   * The code controls the user has changed (#595). The server keeps a description beside an
   * unchanged code (#613), so only these can raise the "Saving replaces …" hint.
   */
  private readonly changedCodes;
  /**
   * 🔴 **Saving re-opens confirmation** (BR-066, #143): the labels of the changed fields CTRM's
   * `ConfirmChg` diffs, on a customer-confirmed contract, or `null` when there is nothing to say.
   *
   * CTRM bumps the confirmation version and reissues the confirmation when any of them differs
   * (`$ChkCfmChg`, see {@link confirmChgComponents}), so on a confirmed contract the save starts a new
   * confirmation round. It used to be stated only in a code comment, which no trader reads.
   *
   * ⚠ "Confirmed" is `confirmationProgress`'s allow-list, so an unrecognised status never counts. The
   * price type is the LIVE one, because CTRM compares the basis market and month only when the session
   * record is unpriced (`U`).
   */
  protected readonly confirmChgChanges: import("@angular/core").Signal<readonly string[] | null>;
  /**
   * What the async container renders — the two reads the record cannot be shown without, combined.
   *
   * 🔴 **There are two of them now and there used to be one, so this cannot just be the config's
   * state.** The old read-only screen was gated on the aggregate alone; the old edit screen on the
   * configuration alone. This screen needs both — the configuration because the fields *are* its
   * controls, and the aggregate (outside create mode) because it carries the collections, the
   * quantities and the confirmation statuses.
   *
   * Errors win over loading, and the configuration wins over the aggregate where both are in the same
   * state. That ordering is deliberate: a failed configuration means there is no record layout at all,
   * which is a different and more total failure than a contract that could not be read, and reporting
   * the more specific one first would send someone looking at the wrong thing.
   */
  protected readonly containerState: import("@angular/core").Signal<RemoteData<unknown>>;
  /**
   * The contract aggregate — the collections, the quantity breakdown, the confirmations.
   *
   * `null` **only** while creating, where there is no contract to read. Anything else is a real
   * `RemoteData`, errors included.
   *
   * ⚠ **Deliberately NOT caught into a "degrade to the fields" state, and that was a wrong turn worth
   * recording.** The first version of this screen swallowed the failure and rendered the record with an
   * alert, on the reasoning that losing the collections beats losing the record. It is wrong for the
   * case that actually happens: `Contract not found.` is an *error about the record*, and answering it
   * with a full set of empty controls plus a banner is strictly worse than the error state the previous
   * screen showed — a user would read the blanks as the contract. The `/fields` read still degrades
   * gracefully, because that one genuinely is supplementary.
   */
  private readonly aggregate;
  protected readonly response: import("@angular/core").Signal<ContractDetailResponse | null>;
  /** The last load outcome announced, so a re-render never repeats an event (F9.5). */
  private lastAnnouncedLoad;
  /**
   * Tells the host a record opened, or failed to (F9.5).
   *
   * Keyed on the attempt, the number and the outcome, so each real load announces exactly once: a
   * retry is a new attempt and announces again, a re-render is not. A close or re-open answers a
   * re-read without a new load, so it opens nothing new.
   */
  private readonly announceLoad;
  protected readonly contract: import("@angular/core").Signal<ContractDetail | null>;
  /**
   * The contract's current writable values, from `GET /contracts/{number}/fields`.
   *
   * **Its own request, and deliberately not the aggregate.** That response models 47 of `base_data`'s
   * 146 fields, so filling the form from it would leave ~70 controls blank while CTRM holds values for
   * them — and a blank control is indistinguishable from an empty value. In view mode that is a lie;
   * in edit mode it is worse, because a user would fill in a field that was never empty and the typed
   * value would be written.
   */
  private readonly prefill;
  /**
   * The source contract's writable values, when this create is a copy (BR-041).
   *
   * **The same read the edit screen prefills from** — `GET /contracts/{number}/fields` — and
   * deliberately not the aggregate, for the reason recorded on {@link prefill}: the aggregate models
   * 47 of `base_data`'s 146 fields, so copying from it would leave ~70 controls blank while CTRM holds
   * values for them. On an edit that is a lie about the record; on a copy it is a contract quietly
   * missing three quarters of what it was copied from.
   *
   * ⚠ **A failed read is `failed`, not an empty copy.** It gates the screen (see
   * {@link valuesReady}) and raises {@link copyFailed}, because the alternative is a form that looks
   * like a deliberately blank new contract — and the user asked for a copy, so they would reasonably
   * read those blanks as the source contract's values and save them.
   */
  private readonly copySource;
  /** True when this create was reached by Copy contract. */
  protected readonly isCopy: import("@angular/core").Signal<boolean>;
  /** True when this is a copy whose source could not be read. */
  protected readonly copyFailed: import("@angular/core").Signal<boolean>;
  /**
   * The source contract's AGGREGATE, when this create is a copy (#960): where its collections are.
   *
   * `/fields` is `base_data` only, so the ship periods and remarks a copy carries come from here.
   * ⚠ **A failed read does not fail the copy.** The fields still copy, and {@link collectionCopy}
   * reports the collections as not read, so the banner says they were not copied rather than implying
   * the source had none.
   */
  private readonly copySourceDetail;
  /**
   * What this copy carries of the source's collections, and why it leaves out the rest (#960).
   *
   * `null` until both the source's values and its aggregate have settled. The collection list and caps
   * are `constraints.json`'s, from the configuration bundle (ADR-7); the exclusions are the resolved
   * configuration's `collections` flags (#959). Against a server without #991 there are no flags, so
   * nothing is excluded and every collection this screen can carry is carried: the ruled default.
   */
  protected readonly collectionCopy: import("@angular/core").Signal<CollectionCopyPlan | null>;
  /**
   * The copy's notice summary (#960): what it is a copy of, and which collections came across. The
   * panel counts summaries rather than rendering them; the banner it projects says the rest.
   */
  protected readonly copySummary: import("@angular/core").Signal<string>;
  /** The copy banner's sentences about collections (#960), or none outside a copy. */
  protected readonly collectionCopySentences: import("@angular/core").Signal<readonly string[]>;
  /**
   * The ship periods a copy carried, as rows (#960). Held so #839's past-date rule treats them as the
   * source's own periods rather than as ones the user added: see {@link shipPeriodValidation}.
   */
  private readonly copiedShipPeriods;
  /** Set once the copied collections are on the screen, so a re-resolve cannot overwrite user edits. */
  private copiedCollectionsSeeded;
  /**
   * Puts the copied ship periods and remarks on the screen, once (#960).
   *
   * 🔴 **As new rows, marked changed, so the create sends them.** The create's baseline is empty (a
   * new contract holds no periods and no remarks), so rows seeded here differ from it, and
   * {@link writeCollections} sends both collections whole. Nothing from the source's identity rides
   * along: ship periods carry dates and a quantity, remarks a type and a note.
   */
  private readonly seedCopiedCollections;
  /**
   * The copied values, keyed by component name and ready for `defaultValues`.
   *
   * The exclusions come from {@link copyExclusions} over the **resolved configuration**, so BR-041's
   * per-field flags are honoured per trade unit rather than hard-coded here — and the contract's own
   * identity is excluded structurally, inside `copyableValues`, where no configuration can reach it.
   * Read that function's remarks before changing either layer: one of them is what stops a copy
   * overwriting the contract it was copied from.
   */
  private readonly copiedValues;
  /**
   * The source's typed descriptions beside blank codes, by CTRM description field (#1179). Sent on the
   * copy's create by {@link payloadFor}, so a legacy contract copies the way Contract Portal copies it.
   */
  private readonly copiedDescriptions;
  /**
   * Whether the form may be built yet.
   *
   * 🔴 **The form seeds ONCE, in the child's `ngOnInit`.** The configuration and the values are
   * separate requests, and the screen renders on the configuration alone — so whenever the values were
   * the slower of the two, which over HTTP they usually are (the configuration is three cacheable
   * reads against one contract-specific one), the form was built with nothing and never re-seeded. The
   * screen then showed 111 empty controls for a contract CTRM holds values for, which is
   * indistinguishable from a contract that is genuinely empty.
   *
   * Gating rather than re-seeding is deliberate: a late re-seed would overwrite whatever the user had
   * already typed into a form they were shown and invited to edit.
   *
   * ⚠ **This now gates the view mode too**, which the old read-only screen had no equivalent of. Same
   * reasoning, and it is if anything more important there: the whole screen is those values.
   */
  protected readonly valuesReady: import("@angular/core").Signal<boolean>;
  private readonly ctrmValues;
  /** Every value the screen can show, by CTRM field name — both sources merged, aggregate winning. */
  private readonly values;
  /**
   * The values the controls are seeded with, keyed by component name.
   *
   * 🔴 **Coerced, not passed through.** `/fields` returns CTRM's raw `base_data`, where a quantity is
   * a string and a date may be packed or the `0001-01-01` sentinel. The old detail screen never met
   * this because it formatted every value itself on the way into a `<dd>`; controls do not, so
   * `seedFromCtrmValues` does the translation — including mapping CTRM's unset-date sentinel to
   * nothing, which this project has already once rendered as *the year 1*.
   */
  protected readonly initialValues: import("@angular/core").Signal<Readonly<Record<string, unknown>>>;
  /**
   * What this screen fills in for a create, before the user types anything.
   *
   * 🔴 **The trade unit, and it is not a convenience.** The contract list is scoped by trade unit —
   * CTRM has no unfiltered list — so a contract created without a `location` is accepted, reports a
   * number, and is then **missing from the grid the user created it from**. It is not lost; this screen
   * still finds it by number. But a create that disappears from the list reads as a failed save, which
   * is the worst possible outcome for a write that actually succeeded.
   *
   * ⚠ **Create only.** On an edit the contract already has a trade unit and it is CTRM's to state, not
   * this screen's — seeding one there could move a contract between units on a save meant to change
   * something else entirely.
   */
  protected readonly defaultValues: import("@angular/core").Signal<Readonly<Record<string, unknown>>>;
  /**
   * True when the values could not be read — the form would otherwise look like an empty contract.
   *
   * Keyed on the `failed` status rather than on the values being null. "No values yet" and "the read
   * failed" were the same condition once, so the warning showed while the request was in flight and
   * then vanished — an alarm that fires on every load is one nobody reads.
   */
  protected readonly prefillFailed: import("@angular/core").Signal<boolean>;
  /** Shown when the rows did not come from CTRM, exactly as the grid does. */
  protected readonly isSimulated: import("@angular/core").Signal<boolean>;
  /** CTRM warnings, surfaced rather than dropped (correction C-2). Rare on a read. */
  protected readonly warnings: import("@angular/core").Signal<readonly string[]>;
  /** Reference sets that returned nothing, named on screen rather than rendered as empty combos. */
  protected readonly unavailableLists: import("@angular/core").Signal<readonly string[]>;
  /**
   * One line per **standing** notice, in the order the panel projects them.
   *
   * 🔴 **The membership rule is what matters here, not the wording: standing conditions of the
   * screen go in, outcomes of something the user just did stay out.** This screen produces a lot of
   * the second kind — a save result, a save failure, a copy that could not read its source, a
   * contract number that could not be issued, a prefill that failed — and every one of them stays a
   * full-width banner. Behind a collapsed panel they would be messages nobody sees, and two of them
   * carry `role="alert"` precisely because they must interrupt. {@link NoticesPanelComponent}'s own
   * remarks state the rule; this is the screen where it is easiest to get wrong, because both kinds
   * were rendered identically before.
   *
   * ⚠ **The order has to match the projected content**, since these are the lines a reader uses to
   * decide whether to expand. Nothing enforces it — keep the two in step by hand.
   */
  protected readonly noticeSummaries: import("@angular/core").Signal<string[]>;
  /** #1223: the environment and system caveats are the Entra Admin role's only. */
  protected readonly showSystemNotices: import("@angular/core").Signal<boolean>;
  /**
   * The child collections CTRM returns that CMS does not read yet.
   *
   * Rendered rather than hidden — the difference between *"this contract has no quality factors"* and
   * *"CMS does not read quality factors"*, which the endpoint goes out of its way to make expressible.
   * Underscores become spaces for reading; the wire names stay in the `title` so the list is greppable
   * against the API.
   */
  protected readonly unmodelled: import("@angular/core").Signal<readonly string[]>;
  protected readonly stages: readonly {
    readonly label: string;
    readonly value: (contract: ContractDetail) => string | null;
    readonly emptyNote?: string;
  }[];
  /**
   * Help text per field, and the merge in it is not cosmetic.
   *
   * 🔴 **`CONTRACT_LAYOUT_EMPTY_NOTES` had no home once the fields became controls, and it carries the
   * answer to a question a blank field cannot.** The old `<dl>` rendered `Not set — <reason>` in place
   * of a missing value, which is how the screen distinguished *"CTRM holds nothing"* from *"no CTRM
   * route returns this"* — #47's whole point, and the reason `customer_name` is permanently blank. An
   * empty read-only input says neither.
   *
   * So the reasons move into the control's help text — but they are passed **separately** from
   * ordinary notes and rendered only while the field is empty.
   *
   * 🔴 **They used to be merged here, and that made the screen assert something false.** Folded into
   * one record, an `emptyNote` rendered whether or not the field had a value, so a contract at version
   * `009` carried "CTRM has not versioned this contract" directly beside the `009` — #195, QA finding
   * F-03. It was recorded at the time as "a small loss of precision"; it is not, because a note that
   * contradicts the value next to it is worse than silence rather than better than it.
   *
   * A field's own `note` still wins where it has both — that one is guidance for filling the field in
   * and is the more actionable of the two. There are exactly two `emptyNote` rows today and neither
   * has a `note`, so nothing is being dropped — the precedence is stated for whoever adds the third.
   */
  protected readonly fieldNotes: import("@angular/core").Signal<Readonly<Record<string, string>>>;
  /**
   * The notes this screen computes, which stay ON SCREEN under their field rather than behind the "i"
   * (2026-10-13). Each is something to read before acting, or the result of an action just taken, and a
   * user cannot be expected to ask for either.
   */
  protected readonly pinnedNotes: import("@angular/core").Signal<Readonly<Record<string, string>>>;
  /**
   * The Quantity caption for a contract whose shipment periods already allocate a total — or `null`
   * when there is nothing to say (#139, QA finding from the 2026-09-01 live probe).
   *
   * 🔴 **The rule this states is one CTRM enforces and this screen cannot currently satisfy.** CTRM
   * requires the ship-period quantities to sum to the header quantity, so changing Quantity alone is
   * refused — and **every contract this application creates has one ship period**, so it is the normal
   * case rather than an edge one.
   *
   * 🔑 **Why a caption rather than letting the save fail: the refusal has nowhere to land.** CTRM scopes
   * it to `ship_periods(1).ship_quantity`, and F2.4 binds a field-scoped error to the matching control.
   * There is no ship-period control on this screen, so a correctly formed, correctly delivered error is
   * dropped — and the user who typed in **Quantity** is told nothing about Quantity. That is the
   * everything-worked-and-the-user-sees-nothing shape this repository keeps recording.
   *
   * This is #139's option 1 — *surface the constraint*, deliberately not option 2 (*disable Quantity*).
   * Disabling would be the honest thing only if the field could never be saved, and it can: a contract
   * with no periods is unconstrained, and the backend guard re-scopes the refusal to `quantity` anyway.
   * Offering a field that states its own precondition beats removing one that sometimes works.
   *
   * ⚠ **View mode is deliberately included.** The caption explains the arithmetic on screen, and that
   * is worth reading before pressing Edit rather than after.
   */
  protected readonly shipPeriodAllocation: import("@angular/core").Signal<string | null>;
  /**
   * The contract quantity as the **control** currently holds it — the live left-hand side of BR-021.
   *
   * 🔴 **Read from the control, never from `ContractForm.value`.** This screen seeds all 111 of its
   * fields with `emitEvent: false`, and although #364 made the engine's value signal reflect a seeded
   * contract through `ContractForm.seed()`, the market-cascade patch and the draft restore still
   * write silently. `market-cascade.ts` snapshots controls for exactly this reason and is the pattern
   * mirrored here. A gate reading the signal would evaluate an empty form and pass everything.
   */
  private readonly headerQuantity;
  /**
   * The ship periods **as loaded**, for deciding whether the collection changed (F2.3b, #372).
   *
   * 🔴 This is what keeps the save non-destructive. `upsertContract` REPLACES a supplied collection
   * entirely — an omitted row is a deleted row, answered `202` either way — so the payload must
   * carry `ship_periods` only when it differs from this. See {@link shipPeriodsChanged}.
   */
  private readonly seededShipPeriods;
  /**
   * The editable ship-period collection.
   *
   * ⚠ **A signal rather than a `FormArray`**, and the reason is scope rather than taste: the rows
   * are not part of `ContractForm`'s configuration-driven scalar group, so a `FormArray` would mean
   * changing the shared form component for every screen that mounts it. The save path's `dirty`
   * discriminator is scalar-only too, so the collection needs its own changed-test regardless —
   * {@link shipPeriodsChanged} — and that is cheaper to write against a signal than against a
   * control tree.
   */
  protected readonly shipPeriodRows: import("@angular/core").WritableSignal<readonly ShipPeriodRow[]>;
  /** Whether the collection differs from what CTRM gave us. Drives whether it is sent at all. */
  protected readonly shipPeriodsChanged: import("@angular/core").Signal<boolean>;
  /** **BR-022** — the next period to propose, or `null` at CTRM's 12-row cap. */
  /** CTRMs ship-period cap, for the template. */
  protected readonly maxShipPeriods = 12;
  protected readonly nextShipPeriodProposal: import("@angular/core").Signal<ShipPeriodRow | null>;
  /**
   * **BR-020** — every problem the collection currently has, rows and collection alike.
   *
   * 🔴 **"The begin date cannot be in the past" only on a period the user changed or added** (#839,
   * walk s1 to s3). A contract's own historical periods are in the past by definition, and flagging
   * the ones nobody touched told the user to fix something they had not done. CTRM refuses a past
   * begin date only on a new period of an INDEX provisional contract (`wnr051e`, "Ship Begin Date must
   * be greater than or equal to today"), so this stays stricter than CTRM on every row it shows.
   */
  private readonly shipPeriodValidation;
  /**
   * Whether a ship-period error holds the save (#839).
   *
   * #791's rule: an error on a period that WILL BE WRITTEN holds Save. The collection is written
   * whole, and only when it changed ({@link shipPeriodsChanged}), so an unchanged collection with an
   * error CTRM already holds is never sent and does not hold anything.
   */
  protected readonly shipPeriodRowsBlock: import("@angular/core").Signal<boolean>;
  /** Why Save is held by the ship periods, said beside Save (#839), or `null`. */
  protected readonly shipPeriodHoldReason: import("@angular/core").Signal<string | null>;
  /** **BR-020** — per-row problems, by row index. */
  protected readonly shipPeriodIssues: import("@angular/core").Signal<ReadonlyMap<number, readonly ShipPeriodIssue[]>>;
  /**
   * **BR-020** — problems about the collection rather than a row, chiefly the 12-period cap.
   *
   * Kept separate because they have nowhere to render inside the table: a `rowIndex` of `null` means
   * there is no row to attach to, and dropping them would leave the cap silently unenforced.
   */
  protected readonly shipPeriodCollectionIssues: import("@angular/core").Signal<ShipPeriodIssue[]>;
  /** **BR-022** — overlapping periods are a warning, not a refusal: CTRM permits them. */
  protected readonly shipPeriodsOverlap: import("@angular/core").Signal<boolean>;
  /**
   * Seeds the editable collection from the loaded contract, once per contract.
   *
   * ⚠ Seeded from the aggregate rather than from the write prefill, because the prefill carries
   * scalars only — `ContractWriteFields.fields` is `Record<string, unknown>` and has never had a
   * collection in it.
   */
  private readonly seedShipPeriods;
  /**
   * **BR-022** — adds the next period, auto-chained from the last one's end date.
   *
   * The action is disabled at the cap rather than silently doing nothing, which is why
   * {@link nextShipPeriodProposal} returns `null` there instead of a blank row.
   */
  protected addShipPeriod(): void;
  /**
   * The collections to send, or **`undefined` to leave CTRM's own rows alone**.
   *
   * ### 🔴 This returning `undefined` is the safety property, not an optimisation
   *
   * `upsertContract` replaces a supplied collection **entirely** — an omitted row is a deleted row —
   * and answers `202` either way (correction C-4), so the destructive request and the harmless one
   * look identical from the response. Sending the current rows on every save would therefore put a
   * full replace on the save path of every contract edit, and a grid that had failed to seed would
   * clear the contract's periods and report success.
   *
   * So: **the key is absent unless a period actually changed**, which is asserted by a test that
   * reads the payload rather than the screen.
   */
  private shipPeriodCollections;
  /**
   * The flag as the API read it. A create (a copy included) starts with none: the new contract has no
   * notes of its own yet, and a source contract's manual flag is not carried by a copy. An aggregate
   * without the member (a host's own source, or an API older than #985) reads as `unknown`, so the
   * screen says it cannot show the flag rather than showing an unticked box that may be wrong.
   */
  protected readonly lmsFlagRead: import("@angular/core").Signal<ContractLmsFlag>;
  /**
   * Whether the flag is set, as last read or saved: the baseline a change is measured against.
   * Writable so a save that stays on this screen can move it to what was saved, as the remarks do.
   */
  private readonly savedLmsFlag;
  /** The box's value, reset whenever the baseline moves. */
  protected readonly lmsFlagValue: import("@angular/core").WritableSignal<boolean>;
  /**
   * Whether the box is offered: edit or create, with the write grant, on a flag the API says may be
   * changed. `automatic` (CTRM's own) and `unknown` are never editable, whatever `editable` says.
   */
  protected readonly canEditLmsFlag: import("@angular/core").Signal<boolean>;
  /** Whether the user changed the box. Only then does a save carry `lmsFlag`. */
  protected readonly lmsFlagChanged: import("@angular/core").Signal<boolean>;
  protected readonly lmsFlagUnknownMessage = "The LMS flag cannot be shown right now, because CTRM could not read this contract’s notes. Try again later.";
  protected setLmsFlag(value: boolean): void;
  /** Optional: without it the field stays read-only and says the lists are not offered here. */
  private readonly basisLocationSource;
  /**
   * The BasisLocation control's text, live; `undefined` until the form is built.
   *
   * ⚠ **From the form's value signal, never `valueChanges`.** A copy's values and a template arrive
   * through `seed`, which writes silently, so a `valueChanges` watcher would never see the text a
   * template carries. With no BasisLocation control (a configuration that hides it) an edit still
   * recognises CTRM's own text, so a BCO unit's note and a refusal read right.
   */
  private readonly liveBasisLocation;
  /** The Location control's value, live: on a create, the trade unit the contract will be in. */
  private readonly liveLocation;
  /**
   * The price term and place that compose the basis location (`contract-basis-location.ts`).
   *
   * 🔴 **The text field is never sent** ({@link payloadFor} skips `basis_location`): the save carries the
   * selection, and never anything on a BCO unit. Each input is read through a function, so a signal
   * declared further down this class is read when it is needed rather than when this one is built.
   */
  protected readonly basisLocation: BasisLocationState;
  /** A save's refusals of the selection, beside the pickers. CTRM's `basis_location` lands on the field. */
  protected readonly basisLocationErrors: import("@angular/core").Signal<BasisLocationErrors>;
  /** Every refusal of the selection, for the banner. */
  protected readonly basisLocationReasons: import("@angular/core").Signal<string[]>;
  /** Goes to the basis location's term picker, from the refused save's banner. */
  protected goToBasisLocation(): void;
  /** #907: the archetype's contract-text codes. Optional seam: with none, there is no section. */
  private readonly contractTexts;
  /** Bumped after an accepted save that carried contract text, so a save that stays here reads it again. */
  private readonly contractTextAttempt;
  /**
   * The read, carrying the number it was made for, as the addendum list's does. `null` with no source
   * and on a create: a contract not yet saved has no archetype on record to read.
   */
  private readonly contractTextRead;
  /** The last read, only when it was made for the contract on screen now. */
  private readonly contractTextCall;
  /**
   * The contract's contract text, or `null`. 🔴 **`null` for `unavailable`, and that is today's server**:
   * the route is proposed (#907), so the section is simply absent, with no banner.
   */
  protected readonly contractText: import("@angular/core").Signal<ContractTextAnswer | null>;
  /** The route answered and could not complete: said on the Remarks tab, nowhere else. */
  protected readonly contractTextFailure: import("@angular/core").Signal<string | null>;
  /** What each code shows today. Writable so an accepted save can move it to what was saved. */
  private readonly savedContractText;
  /** The section's values, reset whenever the baseline moves. */
  protected readonly contractTextValues: import("@angular/core").WritableSignal<Readonly<Record<string, string>>>;
  /**
   * 🔴 Why editing is refused: CTRM could not read the contract's notes (#331), by the answer's own
   * word or the contract read's (`incompleteCollections`, or an `unknown` LMS flag). An override may
   * then exist that nobody can see, and a save would write over it.
   */
  protected readonly contractTextLocked: import("@angular/core").Signal<string | null>;
  /** Edit with the write grant, over notes CTRM fully read. */
  protected readonly canEditContractText: import("@angular/core").Signal<boolean>;
  /** The `notes` a save sends for the contract text, or `undefined` when nothing would change. */
  private readonly contractTextNotes;
  protected readonly contractTextDirty: import("@angular/core").Signal<boolean>;
  /** Why the contract text cannot be saved as it stands (the 4,000-byte note limit, the 50-row cap). */
  protected readonly contractTextRefusalMessage: import("@angular/core").Signal<string | null>;
  /**
   * #907, business question 1, as a PROPOSAL pending the business's answer: a non-blocking warning
   * while the edits on screen would re-confirm the contract. Whether they would is the server's word
   * (`reconfirmsOnChange`, CTRM's BCO/FI rule), never an archetype list here.
   */
  protected readonly contractTextReconfirms: import("@angular/core").Signal<boolean>;
  protected setContractText(change: ContractTextChange): void;
  /**
   * What CTRM holds, by type: the baseline a change is measured against. Blank on a create, which
   * holds none yet; a copy's remarks go onto the editor instead, so they differ from this blank
   * baseline and the create sends them (#960). Writable so an accepted save can move it to what was saved.
   */
  private readonly savedRemarks;
  /** The editor's values, one note per type, reset whenever the baseline moves. */
  protected readonly remarkValues: import("@angular/core").WritableSignal<Readonly<Record<string, string>>>;
  /**
   * #1006: each remark type's Visible and Required from the resolved configuration (#1022), or `{}`
   * when the server sent none, which reads as every type shown and none required, as under #789.
   */
  private readonly remarkTypeConfig;
  /**
   * The types the editor offers: CTRM's 11, less any the configuration hides (#1006).
   *
   * 🔴 **Hiding is presentation only.** {@link remarkValues} still holds every type's note, so a hidden
   * type's stored remark goes back in the write: the collection is a full replace, and dropping it
   * would delete it in CTRM.
   */
  protected readonly remarkTypes: import("@angular/core").Signal<import("@cws/domain-contracts").RemarkType[]>;
  /** Required by the configuration, and offered: a hidden type cannot be filled in here (#1006). */
  protected remarkRequired(code: string): boolean;
  /** The types the user has left (blurred) at least once, or a held save marked, so their message shows. */
  private readonly remarksTouched;
  protected touchRemark(code: string): void;
  /**
   * The remark types' lines for the validation summary (#791, #1006), keyed `remarks.<code>`.
   *
   * - **Client:** a required, offered type with a blank note. It blocks only where the editor can fix
   *   it ({@link canEditRemarks}); over remarks CTRM could not read, a blank proves nothing.
   * - **Server:** a refused save's `remarks.<code>` (#1022's proposed `422` key), said under that type.
   *   It never blocks a retry, as no server error does.
   */
  private readonly remarkSummaryItems;
  /** The message under a remark type's input, once it is noticed (#1006), or `null`. */
  protected remarkMessage(code: string): string | null;
  protected readonly remarkKey: typeof remarkKey;
  protected readonly remarkMaxLength = 72;
  /**
   * 🔴 #788: CTRM failed to read this contract's remarks (#819's `incompleteCollections`), so the
   * empty list on screen proves nothing. Saving remarks is a full replace, so the editor is refused:
   * opening it on nothing would delete what CTRM still holds.
   */
  protected readonly remarksUnread: import("@angular/core").Signal<boolean>;
  /** In edit and create, with the write grant, and only over a remarks list CTRM fully read. */
  protected readonly canEditRemarks: import("@angular/core").Signal<boolean>;
  protected readonly remarksDirty: import("@angular/core").Signal<boolean>;
  protected remarkOf(code: string): string;
  /** One note, held to 72 characters even if a paste ignores `maxlength`. */
  protected setRemark(code: string, value: string): void;
  /**
   * The child collections a save sends: ship periods, remarks and notes, each only when it changed, or
   * `undefined` when none did. Remarks go whole and packed (#789); notes go whole, with the contract-text
   * edits applied (#907).
   */
  private writeCollections;
  /**
   * The carried collections this screen has no editor for (#1190): truck logistics, quality factors, ship
   * documents and adjustment-calculator lines, as the copy plan built them. Only a copy's create sends
   * them; nothing else holds rows for them, and each is a full replace.
   */
  private copiedUneditedCollections;
  /**
   * A carried late pickup or early delivery date as the editor shows it, read-only (#1018), or a dash.
   *
   * ⚠ **Shown, not edited.** No requirement asks for them to be edited here (BR-020 to BR-023 name
   * only the begin and end dates and the quantity), so the editor keeps and re-sends what CTRM holds.
   * Formatted as the read-only grid formats them.
   */
  protected carriedShipPeriodDate(value: string | null | undefined): string;
  /** Removes one period. */
  protected removeShipPeriod(index: number): void;
  /**
   * **BR-020** — accepts a date in any of CTRM's three entry forms and stores it canonically.
   *
   * `parseShipPeriodDate` handles `MMDDYYYY`, `MMDDYY` (1930–2029 pivot) and `MM/DD/YYYY`. A value
   * that does not parse is kept as `null` rather than guessed at, and the row's issue list says so.
   */
  protected setShipPeriodDate(index: number, edge: 'beginDate' | 'endDate', input: string): void;
  /** Sets one row's quantity. Blank is `null`, which BR-020 reports rather than treating as zero. */
  protected setShipPeriodQuantity(index: number, input: string): void;
  /**
   * **BR-023** — regenerates `ship_period_description` from the span the periods now cover.
   *
   * 🔴 **One description for the whole contract, not one per row.** `ship_period_description` is a
   * `base_data` scalar (Known Issue 18) and the `ship_periods` collection has no description member
   * at all, so the generated text describes the span from the earliest begin to the latest end.
   * With a single period that is just that period, which is the common case and the shape
   * `buildShipPeriodDescription`'s three formats were written for.
   *
   * ⚠ **It overwrites a hand-typed description on the next date edit**, deliberately: BR-023 says
   * the description is auto-generated, and a screen that silently stopped regenerating after one
   * manual edit would leave the text disagreeing with the dates beside it.
   */
  private regenerateShipPeriodDescription;
  /**
   * **BR-021 — Σ ship-period quantities must equal the contract quantity** (#371, F3.2d).
   *
   * `null` when the contract has no ship periods, which is *unconstrained* rather than balanced:
   * CTRM only enforces the sum where periods exist, and gating there would invent a rule and block
   * every contract this screen can currently create.
   *
   * ⚠ **Only the header side is live.** The periods come from the loaded aggregate because the grid
   * is read-only; editing a period is #372, and this computed will pick it up unchanged when the
   * rows become a form collection.
   */
  protected readonly shipPeriodReconciliation: import("@angular/core").Signal<ShipPeriodReconciliation | null>;
  /**
   * Whether BR-021 blocks the save.
   *
   * 🔴 **This PREVENTS a CTRM refusal; it does not replace one.** CTRM scopes the refusal to
   * `ship_periods(1).ship_quantity` and the backend re-scopes it to `quantity` (#140) — that server
   * guard stays and is the authority. What this removes is a user reaching it and being told
   * nothing they can act on, because there is no ship-period control for the error to land against.
   */
  protected readonly shipPeriodGateBlocks: import("@angular/core").Signal<boolean>;
  /** Keeps {@link headerQuantity} in step with the Quantity control. */
  private watchHeaderQuantity;
  /** Why a field is permanently blank. Shown only while it *is* blank — see {@link fieldNotes}. */
  protected readonly emptyNotes: Readonly<Record<string, string>>;
  protected readonly sectionNotes: Readonly<Record<string, string>>;
  protected readonly wideFields: Readonly<Record<string, boolean>>;
  /**
   * #221: the layout's half widths, headings and notes with the resolved configuration's
   * presentation laid over them. A field with no `presentation` block keeps the layout's values
   * exactly, so a configuration that predates #705 renders as it always did.
   */
  private readonly presentation;
  /** Half-width fields, paired into one cell. Their notes move into the "i" tooltip. */
  protected readonly halfFields: import("@angular/core").Signal<Readonly<Record<string, boolean>>>;
  /** The visible heading a field introduces, covering the grouped fields below it (#196). */
  protected readonly groupHeadings: Readonly<Record<string, string>>;
  /** Fields under a group heading, so their own heading is suppressed. */
  protected readonly hiddenLabelFields: import("@angular/core").Signal<Readonly<Record<string, boolean>>>;
  /** componentName -> CTRM field name, shown in the tooltip so an ambiguous label is resolvable. */
  protected readonly fieldCtrmNames: Readonly<Record<string, string>>;
  /**
   * Fields the user may not type into: CTRM's 38 refused ones, plus whatever the market cascade is
   * deciding right now (#201).
   *
   * 🔴 **The cascade's half is dynamic and the other half is not**, which is why this became a
   * computed. `price_market_code` is CTRM's to assign under price types `P`, `U` and blank
   * (`wnr051e:5157-5166`) and the *user's* under `D`/`V`, so a control that is locked on one contract
   * is editable on the next — and locking it unconditionally would stop a deferred contract from
   * being priced at all.
   */
  protected readonly readOnlyFields: import("@angular/core").Signal<Readonly<Record<string, boolean>>>;
  /**
   * #920: on an existing contract the four parts ARE its key. They were editable here, and the API
   * refuses a key edit on an update (`ContractWritePolicy.KeyFields`), so a changed prefix could only
   * end in a refusal the user had no way to act on. Create and Copy compose a new key, so they edit.
   */
  protected readonly lockedFields: import("@angular/core").Signal<Readonly<Record<string, boolean>>>;
  /**
   * The active tab, from the `tab` query parameter.
   *
   * 🔴 **In the URL, not in a signal, and that is this repository's own rule rather than a preference.**
   * docs/02 §1.3 asks every route to be addressable and refresh-proof, and the home workspace was
   * rebuilt to put its filters, sort and page in the query string for exactly this reason. A tab held
   * only in component state would mean a refresh silently returns you to Contract Info, a link to "the
   * shipping fields of this contract" cannot be sent, and the browser Back button does nothing after
   * three tab clicks.
   *
   * ⚠ Read through `toContractTabId`, which narrows an unknown value to `contract` rather than
   * rendering an empty screen. `?tab=nonsense` is a hand-edited URL, a stale bookmark, or a renamed
   * tab — none of which should produce a record with no fields on it.
   */
  private readonly tabParam;
  /**
   * The tabs to render — **from the resolved configuration, with the layout constant as fallback**
   * (ADR-17 D7).
   *
   * This is what retires the legacy app's hard-coded per-location tabs: its BIO tab was an
   * `If(location = 4090)` conditional in the template, and here it is a location-dimension
   * configuration row whose `tabs[]` differs. Hidden tabs are dropped rather than rendered disabled —
   * a tab a trade unit does not use should not be on its screen at all.
   *
   * 🔴 **And a tab whose every section has been hidden is dropped too** (F8.3, ruled 2026-09-24).
   * This used to filter on `tab.visible` alone, so hiding the last section on a tab left the tab
   * rendering with nothing on it — the administrator had turned the content off and the shell
   * stayed. {@link tabsAfterCascade} is shared with the admin preview so the two cannot disagree,
   * and it carries the Remarks guard: a tab the layout never gave sections to is left alone.
   */
  protected readonly configuredTabs: import("@angular/core").Signal<readonly ContractTab[]>;
  /**
   * The active tab, narrowed against the **resolved** tab set.
   *
   * 🔴 **Not against the `CONTRACT_TABS` constant**, which is the subtle half: a `?tab=shipping`
   * bookmark for a trade unit whose configuration hides Shipping would otherwise select a tab with
   * no sections on it and render an empty record. An unknown or now-hidden tab falls to the first
   * visible one.
   */
  protected readonly activeTab: import("@angular/core").Signal<ContractTabId>;
  /**
   * The tab strip, with the count of what is on each one.
   *
   * The count is fields plus collections, so a tab never reads as empty when it carries a grid — the
   * Remarks tab has **no fields at all** (remarks and notes are CTRM collections, not `base_data`
   * scalars) and would otherwise show `0` beside two populated tables.
   */
  protected readonly tabs: import("@angular/core").Signal<{
    count: number | null;
    current: boolean;
    id: ContractTabId;
    label: string;
  }[]>;
  /**
   * Which tab each section belongs on, by section id — **from the resolved configuration**.
   *
   * A `computed` rather than a constant map, because section→tab assignment is configuration now
   * (D7): the same section can sit on different tabs for different trade units. The layout's own
   * assignment is the fallback, which is what keeps the offline harness and the
   * configuration-unavailable path rendering a sensible screen.
   */
  private readonly tabOfSection;
  /**
   * Section ids on the active tab — what the form is told to render.
   *
   * 🔴 **Derived from the CONFIGURATION's sections, not from the layout constant, and an unrecognised
   * section falls through to the first tab rather than disappearing.**
   *
   * The first version of this filtered `CONTRACT_LAYOUT_SECTIONS` directly and produced a screen with
   * **no fields at all** the moment the two disagreed. They agree in production — `buildConfig` sets
   * each section's `componentName` from the layout's `id` — and they do not agree for
   * `MockFormConfigSource`, the offline harness whose section names predate the shared layout. So the
   * naive version worked in the app and rendered an empty record everywhere else, which is the wrong
   * way round for a defect to behave.
   *
   * Failing open is the deliberate choice: a field on the wrong tab is findable and a field on no tab
   * is not, and a configuration this screen does not recognise is exactly the case where losing fields
   * silently would be worst. That also means F2.1's eventual payload cannot hide a section by naming it
   * something new.
   */
  /**
   * View mode's "Hide empty fields" (2026-10-13). Held for the visit, across tabs and refreshes of the
   * contract, and not persisted: it is a way of reading this record now, not a setting.
   */
  protected readonly hideEmptyFields: import("@angular/core").WritableSignal<boolean>;
  protected readonly visibleSections: import("@angular/core").Signal<readonly string[]>;
  /** The tab a section renders on. Unknown sections land on the first tab — see `visibleSections`. */
  private tabFor;
  /**
   * Which collections belong to the active tab.
   *
   * Ship periods sit with the shipping fields and prices with the pricing fields, which is where the
   * Power App puts them (its `Ship Period` component is inside `Shipping Info`) and what removes the
   * long tail this screen used to have — the grids were after all 111 fields, which was the specific
   * complaint. Remarks and notes get the tab named after them.
   */
  protected readonly showShipPeriods: import("@angular/core").Signal<boolean>;
  /**
   * The tab a collection's block sits on (the form builder, 2026-10-28): the configuration's `tab` when a
   * row placed it, otherwise the tab it has always sat on. With nothing placed, the screen is unchanged.
   */
  private collectionTab;
  protected readonly showPrices: import("@angular/core").Signal<boolean>;
  protected readonly showRemarks: import("@angular/core").Signal<boolean>;
  /**
   * Field count per tab, plus one per collection the tab carries.
   *
   * Counted off the **configuration** for the same reason `visibleSections` filters it: the badge has to
   * agree with what the tab actually shows, and a count taken from the layout would keep saying 63 on a
   * configuration that renders something else entirely.
   *
   * 🔴 **Invisible fields are excluded** (JFrisbie, 2026-09-08), because as of the same change the form
   * no longer renders a cell for them: counting them would make a tab read "64" while showing 60, which
   * is the disagreement this count was written to avoid in the first place.
   *
   * ⚠ **Configuration visibility only.** A field hidden by a *rule* at runtime still counts here — that
   * state lives in the form engine's `EffectiveFieldState`, which this page does not have and should not
   * reach for (it would mean lifting the whole rules pipeline onto the page to render a badge). So the
   * badge is exact for the configured case, which is the one an admin controls, and can over-count by
   * however many fields a rule hides. Worth knowing before treating the number as authoritative.
   */
  private countFor;
  /**
   * Query parameters for a tab link: the tab, and the journey parameters the URL arrived with.
   *
   * `returnTo` has to be preserved or clicking a tab would quietly discard the journey back to the
   * grid — the breadcrumb would still work and would land on an unfiltered workspace, which is the
   * failure the `returnTo` parameter exists to prevent in the first place.
   *
   * 🔴 **`copyFrom` has to be preserved for a worse reason (#1052).** This used to keep `returnTo`
   * alone, so the first tab click on a copy turned `?copyFrom=…` into `?tab=shipping`. The open screen
   * did not notice (the router reuses it, and `copyFrom` is read once), but a reload or a tab opened in
   * a new window built an ordinary blank create from that URL, and nothing said the copy was gone.
   *
   * One method feeds the tab links, both `view-state` intents and Edit/Cancel, so the shell's router
   * and an embedding host receive the same set. See {@link JOURNEY_PARAMS} for why it is a list.
   */
  protected paramsForTab(tab: ContractTabId): Record<string, string>;
  /** The {@link JOURNEY_PARAMS} the URL arrived with, read from the snapshot like `copyFrom`. */
  private readonly journeyParams;
  /**
   * Where **Edit contract** goes, carrying the tab.
   *
   * So opening the shipping fields, pressing Edit and pressing Cancel returns you to the shipping
   * fields rather than to Contract Info. A record screen that resets its own position on every mode
   * change is the thing that makes a tabbed form annoying to use.
   */
  protected readonly editParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * Query parameters for **Cancel**, which is not the same as Edit's.
   *
   * An edit cancels back to this record and should land on the tab it was editing, so it carries the
   * tab. A create cancels to the **workspace**, where a `tab` parameter means nothing — it would sit in
   * the grid's URL as noise, and the grid packs its own state into `returnTo`, so a stray parameter
   * there is the sort of thing that gets copied into a shared link and then has to be explained.
   */
  protected readonly cancelParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * CTRM's quantity breakdown as KPI cards (JFrisbie, 2026-09-15 — UX brief item 3).
   *
   * These were label/value pairs in a flex row, which read as six captions rather than as the six
   * numbers a trader opens a contract to see. They are among the most important values on the page
   * and were the most visually understated.
   *
   * 🔴 **The unit travels with the number, and that is a defect fix rather than decoration.** They
   * rendered as bare figures, and this project has the receipts: CTRM stores one TESTING contract's quantity as
   * **105,280,000 pounds** where the API returns **1,880,000 bushels** — a factor of 56 — and the
   * 2026-09-02 DB2 verification recorded the missing unit as *"worth fixing"* on a grain contract at
   * that moment. A bare number invites the reader to supply the wrong unit.
   *
   * ⚠ **`accent` is a thin left border, and the VALUE stays neutral on purpose.** The brief offers
   * colour-coding as optional; a coloured *number* reads as a status, and these are quantities — a
   * settled figure of 0 is not "good" and an open figure is not "bad". Colour here separates the cards
   * at a glance without asserting a judgement the data does not carry. That is the same correction the
   * workspace grid's row tints already took, where a solid band *"competed with the status pill that
   * says the same thing in words"*.
   */
  /**
   * The contract date for the header, as `MM/DD/YYYY` (#774).
   *
   * The view-mode form was ruled on #198 (JFrisbie, 2026-09-25), so the header reads the date the way
   * the date field below it does, through the same `formatDisplayDate` the control uses. ⚠ The
   * remark that stood here said to use the long `19 Aug 2026` form because `08/21` and `21/08` are
   * ambiguous across US and Canadian readers; that cost was accepted by the ruling, not overlooked.
   * Still never the grid's `formatShortDate` (`8/19/26`), which is a grid-density decision.
   */
  protected readonly contractDateLabel: import("@angular/core").Signal<string | null>;
  /**
   * The trader, as `GME — GISSELLE M. ESTEVEZ` where CTRM supplies both.
   *
   * ⚠ **Never fabricates the half it does not have.** CTRM derives the full name from the initials and
   * returns it on the aggregate; on a contract where it holds no name this renders the initials alone
   * rather than inventing an expansion. Same rule as the customer, one field along.
   */
  protected readonly traderLabel: import("@angular/core").Signal<string | null>;
  /**
   * Commodity and market zone as `C, Corn` and `OMA, Omaha` (#1124), either half alone when the server
   * sends only one, `null` when it sends neither. The server never repeats a code as its description.
   */
  protected readonly commodityLabel: import("@angular/core").Signal<string | null>;
  protected readonly marketZoneLabel: import("@angular/core").Signal<string | null>;
  protected readonly quantityBreakdown: import("@angular/core").Signal<{
    label: string;
    value: number | null;
    uom: string | null;
  }[]>;
  /**
   * The status pills, using the grid's own mapping so the two screens cannot disagree.
   *
   * Rendered in every mode, including create, where every stage is unset. That is deliberate: the
   * screen keeps its shape, and {@link pendingNote} says why the pills are empty rather than leaving
   * six blanks that read as a failed load.
   */
  protected readonly confirmations: import("@angular/core").Signal<{
    label: string;
    badge: GridBadge | null;
    style: {
      chip: string;
      dot: string;
      text: string;
    };
    emptyNote: string | undefined;
  }[]>;
  /**
   * What an empty section means on a create.
   *
   * One string, used everywhere a collection or a derived value is empty because the contract does not
   * exist yet. Stated rather than left blank: six empty boxes on a create screen read as "failed to
   * load", which is the exact ambiguity the record screen's `Not set — <reason>` text exists to kill.
   */
  protected readonly pendingNote = "available once the contract is saved";
  /**
   * The sort chain for each sub-grid, held separately so sorting one leaves the other alone.
   *
   * **These sorts are complete, unlike the contract grid's.** The home grid pages — it holds 50 of 880
   * rows, so a client-side sort orders the page and has to say so. These collections arrive *whole* on
   * the aggregate: CTRM caps ship periods at 12 (BR-020…BR-023) and the prices come with the contract.
   * So sorting in the browser here orders every row there is, and needs no caveat and no server
   * parameter.
   */
  protected readonly shipPeriodSorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  protected readonly priceSorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  protected readonly sortedShipPeriods: import("@angular/core").Signal<readonly ContractShipPeriod[]>;
  protected readonly sortedPrices: import("@angular/core").Signal<readonly ContractPrice[]>;
  /** Copies before sorting: the rows belong to the loaded response, which nothing here may reorder. */
  private sortCollection;
  /**
   * Ship periods as a C8 grid.
   *
   * docs/02a §3 names ship periods and price sequences as C8 consumers, so this is the documented
   * pattern rather than a second table implementation — and it means both sub-tables inherit column
   * resizing and cell-level `Ctrl+C` copy for free.
   */
  protected readonly shipPeriodColumns: readonly GridColumn<ContractShipPeriod>[];
  protected readonly priceColumns: readonly GridColumn<ContractPrice>[];
  /** Underscored wire names read badly in a sentence; the `title` keeps the real one. */
  protected readable(name: string): string;
  protected readonly save: import("@angular/core").WritableSignal<SaveState>;
  /** The built form, handed over by the child so this page can read values and validity. */
  private form;
  /** The field-left handler: the contract number's check (#962) and the Customer id's confirmation. */
  protected onFieldBlur(componentName: string): void;
  /** The lookup in flight for {@link confirmCustomerId}, cancelled when a newer one starts. */
  private customerLookup;
  /**
   * Confirms whatever the Customer id control holds NOW (F4.3b — docs/02 §2.3).
   *
   * A confirmation, not a picker: the customer master has 123,155 rows, so the screen answers "who
   * is this account" for the id the form holds and offers nothing to browse. The outcome becomes the
   * field's note through {@link pinnedNotes}, and a resolved name is seeded into the read-only
   * Customer name field.
   *
   * 🔴 **Called wherever an id ARRIVES, not only where one is typed (#1225).** The blur was the only
   * caller, so a form that opened with an id (a copy, an edit, a restored draft) showed a blank name
   * until the user touched the field. Two moments put an id on the form without a blur: the form
   * being built ({@link onFormReady}, which covers copy, edit and the #813 deep link, since each
   * arrives as the form's starting values) and a draft being restored, which patches the controls
   * silently. Both call this; nothing listens to keystrokes.
   *
   * 🔴 **View mode looks up too (#1273).** CTRM's contract read carries no customer name, so without
   * the lookup the details screen showed `—` beside every id. {@link pinnedNotes} keeps the
   * "Confirmed" note off the view, where the name is already beside the id.
   *
   * 🔴 **A blank id never looks up**, a control in the spec. The same id is not asked about twice in
   * a row, and an answer that arrives after the id has changed again is dropped rather than shown
   * against the wrong id: the older lookup is cancelled, and the id check in the subscriber stays as
   * the second guard.
   */
  private confirmCustomerId;
  protected onFormReady(form: ContractForm): void;
  /**
   * The special type as the SpecialType control holds it, or `undefined` when the configuration
   * gives this trade unit no such control.
   *
   * ⚠ Read from the control rather than the loaded values so the section follows the user: choosing
   * `MNC` on a create, or changing the type on an edit, shows or hides the section at once.
   */
  private readonly liveSpecialType;
  private watchSpecialType;
  private readonly addendumTemplateSource;
  private readonly addendumTypeSource;
  /**
   * The addendum types, read once (#1043). They decide whether this record has an Addendum section,
   * and the section offers templates from the same read, so the two can never disagree.
   *
   * ⚠ **Fails soft.** No source, a missing route or a failed read is a record with no Addendum
   * section, never an error banner on the contract: the screen cannot tell which special types need
   * one. The server still refuses a save that needs an addendum, and that refusal brings the section
   * back ({@link hasAddendumSection}) with the failure said inside it.
   */
  protected readonly addendumTypesState: import("@angular/core").Signal<ListState$1<AddendumType>>;
  /**
   * The addendum templates, read once (#1043), for the section. `null` with no template source, which
   * the section says as "not offered here".
   */
  protected readonly addendumTemplatesState: import("@angular/core").Signal<ListState$1<AddendumTemplate> | null>;
  /**
   * The addendum type the server lists for this contract's special type, or `null` (#1043, criteria 1
   * and 3).
   *
   * 🔴 **The server decides, not a frontend list.** It mirrors the server's own rule: a save needs an
   * addendum iff the special type has an addendum type, available or not (`AddendumTemplateResolver`).
   * `null` while the types are still being read, or could not be. With no SpecialType control the
   * loaded CTRM value decides, so a trade unit whose configuration hides the field still gets the
   * section its contracts need.
   */
  protected readonly addendumType: import("@angular/core").Signal<AddendumType | null>;
  /**
   * The special type the Addendum section offers templates for (#676): the live control's value, or
   * with no SpecialType control the loaded CTRM value. The same source as {@link addendumType}, so
   * the section and its templates can never follow two different codes.
   */
  protected readonly addendumSpecialType: import("@angular/core").Signal<string | null>;
  /**
   * The Addendum section has its own tab (#923, ruled 2026-10-19). It used to sit at the bottom of the
   * tab carrying the special type, and on the #917 walk it was missed twice: a user who picks MNC looks
   * for a tab. The tab is in {@link configuredTabs} only while there is a section, so this is never
   * true without one.
   */
  protected readonly showAddendum: import("@angular/core").Signal<boolean>;
  /** The Addendum section, kept mounted off its tab so Save can read it (#830). */
  private readonly addendumSection;
  /**
   * Whether leaving would lose something: the contract form, or the addendum's values (#830). The
   * addendum's are in the section, outside the form, so the form's dirty flag cannot see them.
   */
  private readonly hasUnsavedWork;
  /**
   * The addendum this save carries, or `null` to keep the stored one (#830).
   *
   * - **A create** with an addendum type always sends it: there is no stored one to keep, and the
   *   server refuses a contract that needs one and has none.
   * - **An update** sends it when the user changed the section, or when the special type changed,
   *   because then the server needs the new type's template (#828's final review, F3).
   * - Otherwise nothing: omitting it keeps the stored template and values (BR-096). 🔴 Sending the
   *   section's fields regardless would replace the stored values with blanks, since the section
   *   cannot read them back yet (#858).
   */
  private addendumForSave;
  /**
   * The contract half of a Preview: exactly what Save would send, so the draft shows the addendum the
   * save would store (#830). `null` until the form exists.
   */
  protected readonly addendumPreviewContract: () => AddendumPreviewContract | null;
  /** The trade unit the contract belongs to, for templates restricted to some trade units. */
  protected readonly addendumTradeUnit: import("@angular/core").Signal<string | null>;
  private readonly markets;
  /**
   * The built form as a signal, so the cascade can read its live values.
   *
   * ⚠ A second handle on the same object rather than a replacement for {@link form}, which a dozen
   * call sites read synchronously during a save. Narrowing that to a signal read would be a wider
   * change than this one needs.
   */
  private readonly builtForm;
  /**
   * **Every field with an error, for the validation summary panel** (#791, docs/02 §3.1).
   *
   * One source for client and server errors: a refused save's field errors are put on their controls
   * (`applyFieldErrors`), so reading the controls lists both. Control errors and touched state are
   * not signals, so this also reads `form.value()` (edits), {@link formRevision} (touched changes)
   * and `save()` (a refusal landing). Edit and create only: view mode renders no controls.
   */
  protected readonly summaryItems: import("@angular/core").Signal<readonly ValidationSummaryItem[]>;
  /** Bumped when any control's touched state changes, so {@link summaryItems} sees a blur. */
  private readonly formRevision;
  /** The panel's lines: each item with its tab's label as where it is. */
  protected readonly summaryEntries: import("@angular/core").Signal<readonly ValidationSummaryEntry[]>;
  /** Open by default; a held save opens it again if the user collapsed it. */
  protected readonly summaryExpanded: import("@angular/core").WritableSignal<boolean>;
  private readonly summaryPanel;
  /** A panel entry was chosen: go to its field, or to its tab when the field is hidden. */
  protected chooseSummaryEntry(entry: ValidationSummaryEntry): void;
  /**
   * The tab a summary line sits on: its section's, or Remarks for a remark type (#1006), which has no
   * section because remarks are a CTRM collection, not `base_data` fields.
   */
  private tabOfSummaryItem;
  private focusSummaryItem;
  /**
   * What the cascade reads  snapshotted from the controls, not from the engine's value signal.
   *
   * =4 **`ContractForm.value` does not see a control seeded with `emitEvent: false`, and this screen
   * seeds every one of them that way.** `FormBuilderService` sets its value signal once at build time
   * and thereafter only from `valueChanges`; the record screen's prefill runs *after* the build and
   * suppresses the event deliberately, so that the value can be told apart from one the user typed.
   * The consequence is that `form.value()` reports an empty form for an existing contract  measured,
   * not assumed: every fact came back `null` while the rendered inputs held the contract's values.
   *
   * � **That is wider than this cascade**  the rule engine reads the same signal, so BR-003's price
   * blanking and BR-005's requiredness are evaluating against an empty form on a loaded record too.
   * Raised rather than fixed here: changing what the engine's value signal reflects is a change to
   * every rule on both screens, and it belongs with the lane that owns the engine.
   */
  private readonly cascadeFacts;
  /**
   * Keeps {@link cascadeFacts} in step with the controls.
   *
   * Seeded once from the built form  which is what makes a loaded contract cascade at all  and then
   * updated on every value change, which is what makes it follow the user.
   */
  private watchCascadeInputs;
  /**
   * The Grain Factors market for this contract's location and commodity.
   *
   * ⚠ **`undefined` until both drivers are known**, which is the in-flight state rather than
   * "there is no market" — see `MarketCascadeInput.grainFactorsMarketCode`. A create form with no
   * commodity chosen yet has nothing to look up, and must not be told the Grain Factors file is empty.
   */
  private readonly grainFactorsMarketCode;
  /** The cascade's answer, recomputed on every relevant keystroke. */
  protected readonly cascade: import("@angular/core").Signal<MarketCascade>;
  /**
   * #1063: the cascade's requirement redirect, as the engine's requirements.
   *
   * Under `P` with a hedge price and no price market code the hedge month is locked blank, and BR-005
   * would require it anyway: a field required and impossible to fill. The month follows the price
   * market code, so that is what is asked for, with a sentence that says why.
   *
   * 🔴 **Through `setRequirements`, never by touching validators here.** `applyRequired` replaces a
   * control's validator list whenever a rule re-evaluates the field, so a validator the page attached
   * would be dropped on the next keystroke. The engine attaches and removes these itself.
   *
   * ⚠ On edit, the server's BR-005 mirror reads the hedge month from what is sent, so this holds on
   * the wire only once the cascade-derived components are sent too (#1062). On create it holds alone.
   */
  private readonly requirementRedirect;
  private readonly applyRequirementRedirect;
  /**
   * The months valid for the derived market — `reference/market-months`.
   *
   * ⚠ **Keyed on the cascade's market code, not the form's.** Under price types `P`, `U` and blank
   * CTRM overwrites what the form holds, so filtering on the form's copy would list the months of a
   * market this contract is not on.
   */
  private readonly marketMonths;
  /**
   * Writes the cascade's derived values back onto the form.
   *
   * 🔴 **Patched PRISTINE, and that is what keeps the save honest.** `dirtyValues()` is what the
   * update path sends, so marking a derived value dirty would push CTRM's own answer back at it as if
   * the user had typed it. On a full-replace upsert that is indistinguishable from an edit.
   *
   * ⚠ **`emitEvent: false` plus an equality guard, or this loops**: the patch would fire
   * `valueChanges`, which feeds {@link cascadeFacts}, which recomputes the cascade, which patches
   * again. The guard is what terminates it — the same one `FormBuilderService.applyValue` uses, and
   * for the same reason.
   *
   * ⚠ **Create mode is included deliberately.** #229 is that a create sends only dirty controls, so a
   * pristine derived value would be dropped from the payload — but the fix for that belongs to the
   * create path (send the full resolved set), not here. Marking these dirty to work around it would
   * make every *update* re-send CTRM's own derivation. Noted rather than duplicated.
   */
  private readonly applyCascade;
  /**
   * Issues a contract number on entering create or copy, once per journey (#631).
   *
   * 🔴 **Ruled 2026-10-02 (GEstevez, #204): the number fills in as soon as the user clicks Create or
   * Copy, before any prefix is chosen**, as Contract Portal and the green screen do. The explicit click
   * is the safeguard: this screen is only reached by it, so browsing never spends a number. No
   * prefixes are sent (`{}`): CTRM's `getNextContract` takes no input and checks uniqueness on the
   * 7-character number alone, so the prefixes never changed which number is issued, and since #632
   * the API answers `{}` with the component and `null` composed forms.
   *
   * ⚠ **A cancelled create still spends a number.** That is the accepted cost, the same as Contract
   * Portal's. There is no release route (F3.1b is ⬜).
   *
   * 🔴 **Every trade unit, whatever `pendingContractsEnabled` says** (ruled 2026-10-19, #919, replacing
   * the 2026-10-05 gate). A create with no number is refused for a blank key, so a trade unit that
   * skipped issuance could not create from this screen at all. The attribute still means something,
   * whether the trade unit uses Pending Contracts (01 §6.1): without them a create is a real contract
   * straight away, and the issued number is still its suggestion. It just no longer decides issuance.
   *
   * 🔴 **F-10's protections (#213) are unchanged, and each is the difference between one number and
   * several:** the number is held OUTSIDE the form (`issuedNumber`, re-applied by `defaultValues` on a
   * rebuild); the guard is set BEFORE the request, so a rebuild while the reply is in flight cannot
   * issue again; and a rebuild or a driver change re-runs this method and finds the guard set.
   */
  private issueNumberOnEntry;
  /** A control's value when it is exactly one non-blank character, else null. */
  private singleCharacter;
  /**
   * Turns a failed issuance into something the user can act on.
   *
   * 🔴 **Three failures, three sentences.** Collapsing them into "could not get a number" would tell a
   * user with no entitlement to keep retrying, and would hide a configuration fault that needs an
   * administrator rather than a user.
   *
   * The two status branches describe *this caller* and *this environment*: no entitlement, and
   * issuance simulated while writes are Live. Everything else is CTRM's one issuance failure, which
   * carries no classified cause (#666): a `condition` on the body is not read, because issuance cannot
   * produce one.
   */
  private numberIssueMessageFor;
  /** The issued number, held outside the form so a rebuild re-applies it rather than re-requesting. */
  private readonly issuedNumber;
  /** Set before the request rather than after it, so two emissions cannot spend two numbers. */
  private hasRequestedNumber;
  /**
   * 🔴 **C-16: the commodity prefix follows the commodity's group** (#204, F-12 frontend half).
   *
   * `contract_prefix_commodity` is character 2 of the key: the commodity's CAK group, many-to-one
   * (`YC` and `WC` are both `C`), so it cannot be computed from the code and travels with the
   * commodity list as `group` (`ReferenceItem.GroupCode`, #189). Without this a user hand-types a
   * one-character code they have no reason to know, and a wrong one composes a valid-looking key for
   * the wrong contract family, which `upsertContract` creates rather than refusing.
   *
   * ⚠ **The user can still override.** The prefix is replaced only while it is empty or still the
   * value this method last derived; anything else is the user's own and stands. A commodity with no
   * group leaves the prefix alone: absence means "no group", never "a blank group".
   *
   * Create and copy only: on an existing contract the prefixes are part of its key.
   */
  private watchCommodityPrefix;
  /**
   * 🔴 **#962 (ruled 2026-10-20): a typed contract number is checked as soon as it is complete.**
   *
   * Before this, a taken number was found only at Save, after the whole form was filled in. Now the
   * composed key is checked when the user leaves the number, or after a pause in typing any of the four
   * key parts, and the verdict is drawn on the number's outline with its sentence under the key.
   *
   * - **Any change to a key part clears the verdict at once**, before the new check, so a verdict never
   *   stands beside a key it is not about. CTRM checks the combination (04 §checkContractNumber).
   * - **One check in flight** (`switchMap`): a newer key cancels an older check, so a slow answer for an
   *   old key cannot land against the new one.
   * - **The issued number is never checked** (`typedNumber` is `null` for it), nor a key missing a prefix.
   * - **A short number** is said on leaving the field, not while typing, which would flash red per key.
   * - **A failed check** says so and never blocks typing; Save still checks, and still refuses.
   * - 🔴 **The Save-time check in {@link onSave} is unchanged and stays the gate**: a number can be taken
   *   between this check and the save. A verdict never touches the control's errors, so it holds nothing.
   *
   * Re-subscribed on every form rebuild (a driver change rebuilds the controls), dropping the old one.
   */
  private watchTypedNumber;
  /** The on-entry check's subscription, replaced when the form is rebuilt (#962). */
  private typedNumberWatch;
  /** The user left the number field (#962). */
  private readonly numberLeft;
  /** The on-entry verdict on a typed number, and the key it is about (#962). */
  private readonly typedNumberVerdict;
  /**
   * The verdicts as the form draws them: outline and sentence. The typed number's beside the number
   * (#962); the weight limit's on Transportation type, and, when outside, on the inputs that drive it
   * (#965).
   */
  protected readonly fieldVerdicts: import("@angular/core").Signal<Readonly<Record<string, FieldVerdict>>>;
  /**
   * 🔴 **#965 (ruled 2026-10-20): CTRM's transportation weight limit is checked while the user types.**
   *
   * CTRM refuses a save whose weight per unit of equipment is outside `GNP084`'s limits for the
   * transportation type, but only when Buyers equipment is `Y` and the type is not truck, so the rule
   * was invisible until Save. Now, when it is armed, the inputs are sent to #964's check after a pause
   * in typing, and the answer is drawn on Transportation type, where CTRM reports it.
   *
   * - **The arithmetic is the server's** (`WeightLimitCheckSource`): the conversion to the company's
   *   standard unit must match CTRM exactly, so the screen decides only WHEN to ask.
   * - **Any change to an input clears the verdict at once**, so a verdict never stands beside inputs it
   *   is not about, and a held Save is released the moment the user starts fixing it.
   * - **One check in flight** (`switchMap`): a newer input cancels an older check.
   * - **Nothing is asked** while the rule is not armed (Buyers equipment `N`, type `T` or blank) or while
   *   an input is incomplete, nor in view mode.
   * - 🔴 **Only an answered `outside` holds Save** (through {@link summaryItems}). No source, a failed
   *   check, or the server declining to check shows nothing and holds nothing: CTRM still enforces the
   *   rule, and CWS never refuses on a limit it could not confirm.
   *
   * Re-subscribed on every form rebuild, dropping the old one.
   */
  private watchWeightLimit;
  /**
   * The check's inputs, or `null` when the rule is not armed or an input is incomplete (#965).
   *
   * ⚠ Transportation units must be entered (zero is a value: CTRM then does not divide), and the
   * quantity must be above zero. The trade unit falls back to the active one when the form has no
   * Location value. The equipment unit size is not sent: no CWS screen carries it, and the server takes
   * 0 for it on a create and an edit alike (#964). The commodity prefix is sent beside the commodity
   * (#1089), because CTRM keys pounds per bushel on the pair; `null` when the form has none.
   */
  private weightLimitRequest;
  /**
   * The validation summary's line for an out-of-limit weight (#965), on Transportation type, which is
   * where CTRM reports it. Only an ANSWERED `outside` adds one; it blocks unless the field is hidden,
   * as every client error does (#791). A blocking error the field already carries is left in place.
   */
  private withWeightLimitItem;
  /** The weight-limit check's subscription, replaced when the form is rebuilt (#965). */
  private weightLimitWatch;
  /** The weight-limit check's latest answer, `checking` while one is in flight, or `null` (#965). */
  private readonly weightLimitVerdict;
  /** #964's check. Optional: a host without one gets no pre-check, which is the screen before #965. */
  private readonly weightLimits;
  /** The prefix this screen last derived, held outside the form so a rebuild can tell it from the user's. */
  private lastDerivedPrefix;
  /** The CAK group of a commodity in the resolved list, or `null` when it has none or is not listed. */
  private commodityGroup;
  private readonly numberIssue;
  /** #803: the reference shown with a number that was not issued, or why there is none. */
  protected readonly numberIssueReference: import("@angular/core").Signal<string | null>;
  /** Rendered on the create screen when a number could not be issued — never on view or edit. */
  protected readonly numberIssueFailure: import("@angular/core").Signal<string | null>;
  /**
   * Re-resolves the configuration when a driver field changes, carrying typed values across.
   *
   * 🔴 **The rebuild is what makes this dangerous, and why it snapshots first.** The form seeds once
   * in `ngOnInit`, so a new configuration means a new form — and a naive rebuild discards everything
   * typed and resets the `dirty` flags the save path reads, which is the same trap the tab
   * implementation hit and is pinned by *"should NOT discard a typed edit when the tab changes"*.
   * Here it cannot be avoided the way tabs avoid it (a display filter): a different configuration is
   * genuinely a different set of controls. So the values are snapshotted out of the old form and
   * re-applied to the new one **as dirty**, which is what keeps them in the save payload.
   *
   * The carried values ride in through `defaultValues`, which marks what it applies dirty and skips
   * controls that already hold something — exactly the semantics needed, and already tested.
   */
  private watchDrivers;
  private lastTextCode;
  private lastCommodity;
  private readonly destroyRef;
  /**
   * Values typed before a driver change, re-applied to the rebuilt form as dirty.
   *
   * Merged over the screen's own defaults rather than replacing them, so a carried value wins where
   * both have an opinion — the user's typing outranks a default.
   */
  private readonly carried;
  /** Every dirty control's value, keyed by component name. */
  private dirtyValues;
  /**
   * A key that changes when the resolved configuration does, so the form is rebuilt against it.
   *
   * Rebuilding is unavoidable here — see {@link watchDrivers} — and this is how the template forces
   * it: `@for (key of [formKey()]; track key)` around the form. Keyed on the configuration's own
   * version rather than on a counter, so a re-resolve that returns the *same* configuration does not
   * churn the form (a driver change that does not change which row wins is common: most contracts
   * resolve to the same global default).
   */
  protected readonly formKey: import("@angular/core").Signal<string>;
  /**
   * Which provenance to show, and only when there is something to say.
   *
   * A muted line rather than a banner: it is the admin's debugging thread — the thing that answers
   * "why is this field required here and not there?" — and it is noise to a trader. The
   * defaults-only case IS worth a visible warning, and that is separate (see the template).
   */
  protected readonly provenanceLabel: import("@angular/core").Signal<string | null>;
  /** True when the configuration could not be resolved and the screen is on layout defaults. */
  protected readonly configDefaultsOnly: import("@angular/core").Signal<boolean>;
  /**
   * Why the field limits need mentioning, or `null` (#732). Only while typing: in view mode nothing is
   * entered, so the limits answer a question nobody is asking.
   */
  protected readonly constraintsNotice: import("@angular/core").Signal<"unavailable" | "bundled" | null>;
  protected retry(): void;
  /**
   * Re-read this contract — the header's refresh, view mode only.
   *
   * Bumping `attempt` re-issues **both** reads this screen makes, the aggregate and
   * `GET /contracts/{n}/fields`, which is what a refresh has to mean here: the two are merged into one
   * view and re-reading only the typed half would leave 70-odd fields showing values from the previous
   * read, with nothing on screen saying they disagree.
   *
   * Shares {@link reissue} with Retry for the same reason the workspace does — they are two
   * affordances on one behaviour, and a second copy is how one of them later grows a difference.
   *
   * ⚠ The form is seeded once from the values that arrive, so a refresh mid-edit would fight whatever
   * is typed. That is not guarded here because it cannot happen: the button is only rendered in view
   * mode. If it is ever offered while editing, it needs the dirty-value question answered first.
   */
  protected refresh(): void;
  /** A read is in flight — spins the refresh icon and refuses a second press. */
  protected readonly isRefreshing: import("@angular/core").Signal<boolean>;
  /** The single input to both reads besides the contract number. */
  private reissue;
  /**
   * Whether the signed-in caller may write at all — `Admin`, matching the API's own gate (#155).
   *
   * ⚠ **Not the same question as whether the screen may be READ.** Reads are deliberately not
   * admin-gated and not trade-unit scoped (correction C-14), so this must gate the *button* and
   * never the screen. Hiding the record from a `User` would be a regression, not a stricter fix.
   */
  /**
   * F1.4 — the availability half of the write gate.
   *
   * Root-provided, so this is the same instance the shell's banner reads. The two must agree: a
   * banner saying CTRM is closed beside an enabled Save is worse than either failure alone.
   */
  private readonly availability;
  /**
   * 🔴 **TWO independent gates, and both must be open.** The permission gate asks whether this
   * caller may write; the availability gate asks whether CTRM will accept a write from anyone. They
   * fail for different reasons and are fixed by different people, so they are `&&`-ed here rather
   * than folded into one flag — and the screen says which one is closed.
   *
   * ⚠ `writesBlocked()` is true under `Unknown`, which is the case this gate exists for: not knowing
   * whether CTRM is accepting work is not the same as it being fine (correction C-7).
   */
  protected readonly canWrite: import("@angular/core").Signal<boolean>;
  /**
   * #411, C-15 — why every CTRM write is refused in this trade unit whatever the caller holds: not
   * onboarded, or permissions unreadable. A THIRD gate, about the trade unit rather than the account
   * or CTRM, so a granted control is shown disabled with this sentence rather than hidden.
   */
  protected readonly writeRefusal: import("@angular/core").Signal<import("@cws/core-state").PermissionWriteRefusal | null>;
  /**
   * Why a CTRM write the caller IS granted cannot be made right now: the trade unit's refusal first,
   * then CTRM's availability. `null` when only the grant decides. For a control's `title`.
   */
  protected readonly ctrmWriteBlock: import("@angular/core").Signal<string | null>;
  /**
   * Whether the caller may make a write that lands only in **CWS's own SQL** (#485) — Save as a
   * template, today.
   *
   * 🔴 **Permissions only, never the availability gate.** The gate is for CTRM writes: a night run or
   * a closed CTRM says nothing about whether CWS can store a template, and the ruling on #485 keeps
   * those writable. Reading {@link canWrite} here made the template panel tell an Admin they "need
   * the Admin role" whenever CTRM was closed.
   */
  protected readonly canWriteCws: import("@angular/core").Signal<boolean>;
  /** Whether the write refusal is CTRM's rather than the caller's, so the screen says the right thing. */
  protected readonly blockedByAvailability: import("@angular/core").Signal<boolean>;
  /** The banner's own title, so the reason under Save names the same state the banner does. */
  protected readonly availabilityTitle: import("@angular/core").Signal<string>;
  /**
   * Optional, so a host that mounts this screen without the action gets a screen with no Close
   * button rather than an injection failure. The shell always provides it.
   */
  private readonly contractState;
  /** The sentence the confirmation must carry. */
  protected readonly closeProvenanceWarning = "closing rewrites pricing-approval provenance and cannot be undone";
  /**
   * The re-read the close/re-open route answered, which supersedes the loaded aggregate.
   *
   * 🔴 **Keyed on the contract number when it is read, not merely stored.** An override left behind
   * by one contract and applied to the next would tell the user a different contract's state — and
   * under a screen that can navigate between records without remounting, that is reachable rather
   * than theoretical.
   */
  private readonly stateOverride;
  protected readonly stateAction: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "working" | "failed";
    readonly message?: string;
  }>;
  /** The last close or re-open, said once CTRM's re-read answers (#803), or why not, with its reference. */
  protected readonly stateOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /** Whether the contract is closed, as the server last reported it. */
  protected readonly isClosed: import("@angular/core").Signal<boolean>;
  /** Whether either action may be offered at all. */
  protected readonly canChangeState: import("@angular/core").Signal<boolean>;
  /** Optional: a host without templates gets a screen without the actions. */
  private readonly templates;
  protected readonly templateName: import("@angular/core").WritableSignal<string>;
  protected readonly templateState: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "saving" | "failed" | "saved";
    readonly message?: string;
  }>;
  private readonly templateReload;
  /** The last template save or delete (#803): a success, or why not with its reference. */
  protected readonly templateOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /** The trade unit's templates. Re-read after a save so a new one is immediately selectable. */
  private readonly templateList;
  protected readonly availableTemplates: import("@angular/core").Signal<readonly ContractTemplate[]>;
  protected readonly templatesFailed: import("@angular/core").Signal<boolean>;
  protected readonly canUseTemplates: import("@angular/core").Signal<boolean>;
  protected readonly canSaveTemplate: import("@angular/core").Signal<boolean>;
  protected onTemplateNameInput(value: string): void;
  /**
   * Saves the contract on screen as a template.
   *
   * 🔴 **The FULL resolved set, not the fields somebody edited.** A template built from dirty controls
   * alone carries whatever happened to be touched and drops everything the form resolved — which is
   * the defect recorded against create-from-template, where a fix for one field generalised to forty.
   * {@link resolvedValues} therefore reads every writable control regardless of dirtiness.
   *
   * ⚠ Read-only fields are excluded by iterating the writable set: `upsertContract` refuses those 38,
   * so a template carrying one would produce a rejection on every contract created from it.
   */
  protected onSaveTemplate(): void;
  /**
   * The saved message, naming the fields the server did not keep (#872 D21, #1232), by the label
   * this form shows them under. The server owns BR-041's exclusion list, so this screen learns what
   * was dropped only from the answer; saying "saved" alone would let a user believe a template carries
   * a field it does not.
   */
  private templateSavedMessage;
  /**
   * T13: after a save as template, the link to finish it in Admin, where the fields a trader is asked
   * to complete are chosen. To the Admin section: a module intent has no sub-path, and adding one would
   * change the host contract every host implements, so the sentence names the area within it.
   */
  protected readonly templateFinishLink: import("@angular/core").WritableSignal<boolean>;
  protected readonly adminIntent: CmsNavigationIntent;
  /**
   * #457 — deletes one of the trade unit's templates, after confirming.
   *
   * 🔴 **Confirms first, naming the template.** A delete cannot be undone and a template belongs to
   * the whole trade unit, so one stray click must not be enough. A failed delete says so and leaves
   * the list as it was; only a successful one re-reads it.
   *
   * ⚠ CWS SQL, so the write grant alone gates it, not CTRM's availability (#485).
   *
   * 🔴 **Under `If-Match` of the version listed (#872, #1232).** A `409` means someone changed or
   * deleted it since the list was read: the screen says so and re-reads the list, and never retries,
   * because a retry would delete a version this user has not seen.
   */
  protected onDeleteTemplate(template: ContractTemplate): void;
  /**
   * Applies a template to the create form.
   *
   * 🔴 **Through `seed`, and across the FULL set the template carries.** The payload is keyed by CTRM
   * field name — the same names everything else on this wire uses — so it is mapped back to component
   * names here. A key the layout does not know is skipped rather than seeded blindly: the server owns
   * the exclusion list and may drop or add fields, and seeding an unknown control name silently does
   * nothing while looking like it worked.
   */
  protected onApplyTemplate(templateId: string): void;
  protected readonly appliedTemplate: import("@angular/core").WritableSignal<string | null>;
  /** The applied template's fields to complete, as component names. Empty for none (T8). */
  private readonly appliedPrompts;
  /** How many of the applied template's values seeded a control: the N of "which set N fields". */
  protected readonly appliedSetCount: import("@angular/core").WritableSignal<number>;
  /** Show all fields was pressed (T6). Page state only, never persisted. */
  protected readonly showingAllFields: import("@angular/core").WritableSignal<boolean>;
  /**
   * **"Complete this contract"** (T5): a create from a template with fields to complete, until Show
   * all fields. An empty list never gets here, so such a template opens the full form as before (T8).
   */
  protected readonly reducedView: import("@angular/core").Signal<boolean>;
  /**
   * The required fields still blank, by component name: the same computation that holds Save
   * ({@link missingRequired}), so this view cannot ask for less than Save will demand. Remark types are
   * left out, because they are not fields of the form.
   */
  private readonly missingRequiredFields;
  /**
   * Required-and-blank fields the view has shown. A field joins as soon as it is required and blank,
   * so a rule that makes a fourth field required surfaces it at once, and it leaves only when a field
   * is left (see {@link onFieldBlur}): dropping it on the keystroke that filled it would take the
   * field away from under the cursor.
   */
  private readonly requiredShown;
  private readonly surfaceRequiredFields;
  /** What the form renders in the reduced view, or `null` (everything) outside it. */
  protected readonly visibleFields: import("@angular/core").Signal<readonly string[] | null>;
  /**
   * T7: the applied template's fields to complete are required on this create, through the engine's
   * own requirement overrides. Kept after Show all fields: the trader is still completing this template.
   */
  private readonly promptRequirements;
  /** Show all fields (T6): every tab and field, the values kept, because the form is never rebuilt. */
  protected onShowAllFields(): void;
  /** The template last applied to this create, so its use is recorded once the contract exists (#1232). */
  private appliedTemplateId;
  /**
   * Records that the applied template was used, once CTRM has created the contract (`POST …/uses`,
   * #872 D13). After the create rather than on apply, so a template a user tried and abandoned is not
   * counted as used.
   *
   * ⚠ **Fire and forget.** It is a usage statistic: a failure here must never fail, delay or colour
   * a create that has already succeeded, so its error is swallowed and nothing is shown.
   */
  private recordTemplateUse;
  /**
   * Every writable control's current value, keyed by CTRM field name (`templateValuesFromForm`, shared
   * with the Admin template editor since 2026-10-28).
   *
   * Deliberately NOT {@link payloadFor}: that one sends only what changed on an edit, which is right
   * for a full-replace upsert and wrong for a template, where the point is to capture the whole
   * contract as it stands.
   */
  private resolvedValues;
  /** Optional: a host without a log backend gets a screen with no Log tab. */
  private readonly logSource;
  /** #865: `/me`, for who may notify the trader. Optional, so a host without it keeps the action offered. */
  private readonly meSource;
  /**
   * Whether the Log tab has anything to put on it.
   *
   * ⚠ **Either source will do, and that is a correction rather than convenience.** The tab first
   * required a log source, which made Save-as-template unreachable for a host that offered templates
   * and no audit backend — a coupling between two unrelated capabilities, found by a test that
   * provided one and not the other. The tab carries what the contract *records*: its history, a note,
   * a message about it, and a template taken from it.
   *
   * Absent on a create either way: there is no contract yet to have a history, and nothing saved to
   * take a template from.
   */
  protected readonly canReadLog: import("@angular/core").Signal<boolean>;
  protected readonly showLog: import("@angular/core").Signal<boolean>;
  /**
   * Optional: a host without a documents source gets a screen with no Documents tab, and the
   * embedding host's provider list does not change. The shell provides it on the record ROUTES,
   * not in `app.config.ts`, so the HTTP source stays out of the initial bundle.
   */
  private readonly documentsSource;
  /** Only for an existing contract, never on a create. */
  protected readonly canReadDocuments: import("@angular/core").Signal<boolean>;
  protected readonly showDocuments: import("@angular/core").Signal<boolean>;
  /**
   * Optional, like the documents seam, and provided on the record ROUTES so the HTTP source stays in
   * this screen's lazy chunk. Absent, the screen shows no Attachments panel.
   */
  private readonly attachmentsSource;
  protected readonly attachmentsOffered: boolean;
  /**
   * Whether an attachment may be attached, replaced or removed now: each is a contract update, so the
   * write grant, CTRM's availability and the intercompany lock all apply. **View mode only**: the
   * update bumps the version and the record re-reads afterwards, which would fight an edit in progress.
   */
  protected readonly canWriteAttachments: import("@angular/core").Signal<boolean>;
  /** On a create, whether files may be picked to ride the first Save. */
  protected readonly canPickCreateAttachments: import("@angular/core").Signal<boolean>;
  /**
   * Whether an attachment save will also store a CWS addendum and expire the Cara one (pull brief
   * 4.8): the special type now takes an in-house addendum, and this session has not stored one.
   *
   * ⚠ **An approximation, said rather than hidden.** The screen does not yet read which addendum the
   * contract currently carries (the server-side list is #858's route, PR #958), so a contract whose CWS
   * addendum was stored in an earlier session also gets the sentence. It is a warning, not a block.
   */
  protected readonly attachmentsCaraWarning: import("@angular/core").Signal<boolean>;
  /** On a create: the files picked so far, sent with the first Save. */
  protected readonly pendingAttachments: import("@angular/core").WritableSignal<readonly ContractCreateAttachment[]>;
  /**
   * An attachment write was saved: the contract's version moved, so both reads are issued again. The
   * success is said at the top (#803), because the re-read unmounts the panel that would say it.
   */
  protected onAttachmentSaved(saved: AttachmentSaved): void;
  /** Whether the audit backend is present, which the history, Add Note and Notify Trader all need. */
  protected readonly logAvailable: import("@angular/core").Signal<boolean>;
  /**
   * The contract's audit trail.
   *
   * Re-read when {@link attempt} moves, so Refresh reloads the history with the record rather than
   * leaving a timeline that predates whatever the user just did.
   */
  /**
   * #912: moves after a note is added, so the history and the notes are read again from the server
   * without re-reading the whole contract from CTRM, which a CWS note does not touch.
   */
  private readonly logAttempt;
  private readonly logReadKey;
  private readonly auditTrail;
  /**
   * #912: the contract's CWS log notes, over `GET /contracts/{n}/notes`, never CTRM's notes
   * collection (that is contract text, #907, and stays on the Remarks tab).
   *
   * A host whose log source predates #912 has no `notes`, and reads as "no words", not as a failure:
   * the audit's own "Note added" rows still show.
   */
  private readonly logNotes;
  /** The notes were asked for and could not be read (#912). */
  protected readonly logNotesFailed: import("@angular/core").Signal<boolean>;
  /**
   * The timeline: contract audit rows, CWS log notes and form-configuration changes in one list,
   * newest first.
   *
   * 🔴 **They are interleaved rather than shown side by side**, because the question a reader has
   * is *"why does this contract look like this?"* — and a configuration change that altered the form
   * is part of that answer. They stay distinguishable by `kind`, so nobody reads a configuration edit
   * as somebody having changed the contract.
   *
   * #912: a note's audit row carries `{ noteId, byteCount }` and never the words, so where the note
   * itself was read its row stands in for the audit's "Note added" row rather than beside it. A note
   * whose list could not be read keeps the audit row, so the history still says a note was added.
   */
  protected readonly timeline: import("@angular/core").Signal<readonly TimelineRow[]>;
  protected readonly timelineState: import("@angular/core").Signal<"loading" | "loaded" | "error" | "idle">;
  /**
   * The label a changed field is shown under on the Log tab (#567): the one the form shows it
   * under, then the layout's, then CTRM's own name. The last is still worth showing, because a
   * field this layout does not render can still be changed by a write and the user can recognise it.
   */
  private labelForCtrmField;
  /**
   * #458 — the audit trail of the form-configuration row that resolved this contract's form, over
   * `GET /form-configurations/{id}/audit` (the resolve payload's `provenance.configId`).
   *
   * ⚠ **Optional and Admin-only on the server.** A screen with no admin source shows the contract's
   * own entries alone; a refused or failed read says so in one line and lists the rest, because a
   * missing configuration history must not be read as "the form never changed". The seed default has
   * no row, so nothing is asked for.
   */
  private readonly formConfigAdmin;
  private readonly configAuditState;
  private readonly configAudit;
  /** The configuration history was asked for and could not be read. */
  protected readonly configAuditFailed: import("@angular/core").Signal<boolean>;
  protected readonly noteText: import("@angular/core").WritableSignal<string>;
  protected readonly noteBytesRemaining: import("@angular/core").Signal<number>;
  /**
   * Why this note cannot be saved, or `null`.
   *
   * Refused before sending, at the same 4,000 UTF-8 bytes the notes route refuses (#912, ruled
   * 2026-10-18), so the user is told at the control rather than by a 400 after pressing.
   */
  protected readonly noteRefusal: import("@angular/core").Signal<string | null>;
  protected readonly noteState: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "saving" | "failed" | "saved";
    readonly message?: string;
  }>;
  /** The last Add note (#803): a success, or why not with its reference. */
  protected readonly noteOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected onNoteInput(value: string): void;
  /**
   * #912: whether this host's log source can keep a CWS note at all. One written before #912 has no
   * `addNote`, and then no Add Note is offered, rather than one that writes to CTRM.
   */
  protected readonly canKeepLogNotes: boolean;
  /**
   * #912: who may add a note, as the notes route rules it: the grant, and the trade unit's
   * onboarding refusal (C-15, kept for notes by ruling Q12).
   *
   * 🔴 **Not the CTRM availability gate.** Nothing is written to CTRM, so a night run says nothing
   * about a CWS note, as with templates (#485).
   *
   * 🔴 **The #331 refusal is removed from here, deliberately.** It refused Add Note when CTRM's notes
   * collection could not be read, because adding a note REPLACED that collection whole and would have
   * deleted the notes CTRM still held. A log note is CWS's own row now and never touches CTRM's notes,
   * which are contract text (#907), so there is nothing to replace and nothing to refuse.
   */
  protected readonly canWriteLogNote: import("@angular/core").Signal<boolean>;
  protected readonly canAddNote: import("@angular/core").Signal<boolean>;
  /**
   * The note being added and the id it is sent under (#912). Kept after a failure, so pressing Add
   * note again for the SAME words re-sends the same id; new words are a new note and get a new one.
   */
  private noteInFlight;
  /**
   * #912: `POST /contracts/{n}/notes`, CWS's own log. 🔴 **Never the contract save**, which used to
   * carry it into CTRM's notes collection, where TESTING refused it every time (#905).
   */
  protected onAddNote(): void;
  protected readonly notifyText: import("@angular/core").WritableSignal<string>;
  protected readonly notifyState: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "sending" | "failed" | "accepted";
    readonly message?: string;
  }>;
  /** The last Notify trader (#803): accepted, or why not with its reference. */
  protected readonly notifyOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /**
   * #865: who may notify, as the server rules it since #847 (GEstevez, 2026-10-15): any permission in
   * the contract's trade unit, or the Admin role. `null` while `/me` is unknown, and then the action
   * stays offered and the server decides.
   */
  private readonly me;
  protected readonly mayNotify: import("@angular/core").Signal<boolean | null>;
  protected readonly canNotify: import("@angular/core").Signal<boolean>;
  private readonly traderEmails;
  private readonly traderInitials;
  private readonly traderEmail;
  /** The chosen recipients: the trader when known, then whatever the user adds or removes. */
  protected readonly recipients: import("@angular/core").WritableSignal<readonly string[]>;
  /** The trader's initials when their address is not known, so the screen can say whose is missing. */
  protected readonly unresolvedTrader: import("@angular/core").Signal<string | null>;
  protected readonly recipientDraft: import("@angular/core").WritableSignal<string>;
  /** Why the typed address was refused, shown at the control. */
  protected readonly recipientError: import("@angular/core").WritableSignal<string | null>;
  protected onRecipientInput(value: string): void;
  protected addRecipient(): void;
  protected removeRecipient(address: string): void;
  protected onNotifyInput(value: string): void;
  protected onNotifyTrader(): void;
  protected onCloseContract(): void;
  protected onReopenContract(): void;
  /**
   * Confirms, calls, and renders what came back.
   *
   * 🔴 **The response replaces the rendered contract; nothing is flipped optimistically.** Every CTRM
   * write answers `202` regardless of outcome (correction C-4), so the action completing is not
   * evidence it happened — the re-read the route returns is. A screen that toggled its own flag would
   * show "Closed" for a close CTRM refused, which is the exact failure the `202` convention creates.
   */
  private changeState;
  /**
   * Whether Save may be pressed. Kept separate from the click handler so the template can bind it.
   *
   * 🔴 `canWrite()` is part of it because the two ends disagreed otherwise: the form was editable by
   * any assigned CWS user while `CwsContractWriter` accepts **`Admin` alone**, so a `User` could fill
   * all 104 writable scalars and learn it could not save only on pressing Save — a `403` against real
   * CTRM on QA, where `ContractWrites=Live` (#155).
   */
  protected readonly canSave: import("@angular/core").Signal<boolean>;
  /**
   * **Required fields still blank, on any tab** (JFrisbie, 2026-10-23), in form order, with the tab
   * each is on. Save looks greyed out while there are any and its hover names them; pressing it still
   * runs the hold below, which opens the summary and takes the user to the first one.
   */
  protected readonly missingRequired: import("@angular/core").Signal<{
    label: string;
    where: string | null;
  }[]>;
  /** The labels alone, for the addendum preview, which waits for the same fields. */
  protected readonly missingRequiredLabels: import("@angular/core").Signal<string[]>;
  /** Save's hover text while required fields are blank, or `null`. */
  protected readonly saveHoldText: import("@angular/core").Signal<string | null>;
  /**
   * Collects the changed controls and sends them.
   *
   * **`dirty` is the discriminator, not "has a value".** A control the user never touched is pristine
   * even when it holds a prefilled value, so it stays out of the payload and CTRM's own stored value
   * survives the merge untouched. Reading "has a value" instead would re-send all 111 fields on every
   * save, which is how a lossy numeric gets rewritten (Known Issue 17) and how a value CMS displayed
   * imperfectly becomes the value CTRM holds.
   *
   * ⚠ **It refuses outright in view mode.** The template renders no Save button there, so this is a
   * second lock rather than the only one — and worth having, because the form is now built in view
   * mode too, which it never used to be.
   */
  protected onSave(notify?: boolean): void;
  /**
   * The full CTRM key for a contract number the user TYPED on a create, or `null` when there is none
   * to check (#204).
   *
   * `null` for the number CTRM issued (free by construction), for an empty field, and when either
   * prefix is missing: `GET /contract-numbers/{key}` takes the whole positional key, and without both
   * prefixes there is no key, while the save itself is refused for the missing prefix.
   *
   * The number fills all seven positions: {@link onSave} refuses a shorter one first (#770), so the
   * key is the prefixes, the number and the suffix run together, with no padding to choose. ⚠ The
   * right-justification this used to apply (#702) checked one of the two contracts a short number can
   * name. The tail is trimmed, as `ContractNumber.FromCtrmKey` restores trailing blanks.
   */
  private typedNumberKey;
  /**
   * The contract number the user TYPED on a create, trimmed, or `null`: not a create, an empty field,
   * or the number CTRM issued (free by construction, so never checked).
   */
  private typedNumber;
  /** Why a typed number was not saved (#204), or `null`. Rendered on the create screen. */
  protected readonly numberCheck: import("@angular/core").WritableSignal<string | null>;
  /** Whether the save under way is Save & Notify (#812). Read for the two buttons' labels. */
  protected readonly notifying: import("@angular/core").WritableSignal<boolean>;
  /**
   * The write itself, once any typed number is known to be free.
   *
   * `notify` is Save & Notify (#812): the request then carries `sendNotification`. A plain Save sends
   * nothing extra, not even `false`, so it is the same request it always was.
   */
  private submit;
  /**
   * The values to send, and the two modes send DIFFERENT sets — #229.
   *
   * | mode | sends | why |
   * |---|---|---|
   * | create | every writable control, pristine included | there is nothing at CTRM to preserve |
   * | edit | dirty controls only | `upsertContract` is a FULL REPLACE over the raw aggregate |
   *
   * ### 🔴 Why widening edit would be a data-loss bug rather than a tidier rule
   *
   * The update path merges what it is sent onto CTRM's **raw** `base_data` (ADR-4), so a field the
   * user did not touch keeps CTRM's own value by being absent. Sending every control instead would
   * push this screen's copy of all 104 writable fields back at CTRM — including the ones it read
   * through a lossy conversion. `quantity` reads at five decimal places and writes at two, so an
   * untouched quantity would be re-sent rounded, accepted, and stored DIFFERENT, with a `202` and no
   * message (Known Issue 17). That is the silent-rewrite class, caused by us.
   *
   * ### 🔴 And why create had to widen
   *
   * A create has no merge base. Anything patched pristine never reached CTRM at all: the prefilled
   * contract number, a template's defaults, and the market codes the cascade derives — all visible on
   * screen, none of them sent. The contract number is the sharpest, because CTRM would then issue a
   * different one and the user would have watched a number they were never given.
   *
   * ⚠ **NOT fixed by marking those values dirty**, which was the obvious route and is the wrong one.
   * Six derived descriptions sit on CTRM's `ConfirmChg` list, so a spurious edit re-confirms the
   * contract — a new confirmation version, and a document reissued to the counterparty.
   *
   * ⚠ Read-only fields are excluded by iterating {@link CONTRACT_WRITABLE_FIELDS} rather than the
   * layout: `upsertContract` REFUSES those 38 rather than ignoring them, so one in the payload turns
   * a good save into a rejection the user cannot act on.
   *
   * ### 🔴 The two pristine values an edit DOES send (#1062)
   *
   * Dirty is the rule, and two engine writes are the exceptions, each narrow enough to stay off the
   * `ConfirmChg` path on a record nobody changed: a blank BR-003 applied over a loaded value
   * ({@link ruleBlankedSinceLoad}), and a market field the cascade derived differently from the loaded
   * one ({@link cascadeChangedSinceLoad}). Dirty semantics are untouched, so the leave-page guard and
   * the draft autosave still see a viewed record as unchanged.
   */
  private payloadFor;
  /**
   * Whether a pristine field holds a blank a rule applied over a value the record was loaded with
   * (#1062). All three must hold:
   *
   * 1. the engine's state for the field carries the authoritative **blank** intent (BR-003's price
   *    components under `D`/`V`). Computed values and defaults are excluded: they are suggestions or
   *    CTRM's own answers, and re-sending them is the `ConfirmChg` risk {@link payloadFor} describes;
   * 2. the box is blank, which is what the user sees;
   * 3. the loaded value is **not zero-or-blank**, read by the engine's own `isZeroOrBlank`. CTRM reads
   *    a never-entered packed numeric back as `0` (#651), so a loaded `0` is already blank to the
   *    server's `IsZeroOrBlank`, and sending a blank over it would change a record the user did not.
   *
   * ⚠ **Only an intent that persists at the engine's fixed point is seen here.** BR-003's is
   * unconditional. BR-007's freight-UM blank is not: it is proposed only while the UM holds a value,
   * so once applied the state reads `none` again, and a loaded freight UM is not sent by this path.
   *
   * Read from the engine's state, never re-derived, so this follows the rules wherever they change
   * (U's Hedge price follows automatically once #1039's engine change lands).
   */
  private ruleBlankedSinceLoad;
  /**
   * Whether a market field the cascade derived now differs from the value the record was loaded with
   * (#1062), blank and `null` counting as equal and text trimmed.
   *
   * Without this an edit that types a hedge price and a price market code under `P` reaches the server
   * with the hedge month still blank in the merge base, and `MarketMonthRequirednessRule` refuses the
   * save the screen showed as complete. CTRM overwrites these fields under `P`/`U` anyway, so sending
   * the screen's copy of CTRM's own derivation changes nothing CTRM would not. A derived value equal
   * to the loaded one is not sent, so a record opened and saved unchanged sends none of them.
   */
  private cascadeChangedSinceLoad;
  /**
   * CTRM field name to the tab its control sits on, built once from the layout.
   *
   * ⚠ **Derived from the layout rather than hand-listed**, so a field that moves between tabs cannot
   * leave a refusal pointing at the tab it used to be on — which would badge the wrong tab and focus
   * nothing, while looking entirely correct.
   */
  private readonly tabByCtrmField;
  /**
   * How many refusals landed on each tab, for the badge.
   *
   * ⚠ Counts only the fields this layout HAS. A refusal naming something the screen does not render
   * cannot be badged anywhere and stays in the summary — see {@link unmappedErrors}.
   */
  protected readonly errorsByTab: import("@angular/core").Signal<ReadonlyMap<string, number>>;
  /**
   * Refusals naming a field this screen does not render.
   *
   * 🔴 **Kept visible rather than dropped.** CTRM validates 109 fields and this layout renders 111
   * rows, but the sets are not identical — and a refusal the screen silently swallowed would leave
   * the user with a save that failed for no stated reason. The summary is where these live.
   */
  protected readonly unmappedErrors: import("@angular/core").Signal<readonly {
    field: string;
    reasons: readonly string[];
  }[]>;
  /**
   * A refused save's reasons, split by what they concern (#830).
   *
   * - `addendum`: `addendum`, `addendum.*` (CWS's own refusals) and CTRM's `addendum_document`. Not
   *   form fields, so they are said beside the Addendum section, and the banner links to its tab.
   * - `save`: another save of this contract is still running. Nothing of this one ran.
   * - `documents`: CTRM could not list or fetch CWS's documents. A system problem, said as one.
   * - `contract`: everything else, classified as before.
   */
  protected readonly saveErrorGroups: import("@angular/core").Signal<{
    addendum: string[];
    remarks: string[];
    save: string[];
    documents: string[];
    attachments: string[];
    lmsFlag: string[];
    basisLocation: Record<string, readonly string[]>;
    contract: Record<string, readonly string[]>;
  }>;
  /** Goes to the Remarks tab, from the refused save's banner (#789). */
  protected goToRemarks(): void;
  /** Goes to the Addendum tab, from the refused save's banner (#830) or on its own refusal (#923). */
  protected goToAddendum(): void;
  /**
   * Everything that addresses no control: the API's own `formErrors`, plus the refusals whose
   * `invalid_params[].name` is not a field name at all (F2.4, #373).
   *
   * 🔴 **The second half is the fix.** CTRM answers with procedure names and composites
   * (docs/04 §8.2), and the API's `CtrmFieldError.IsFieldName` — which decides what reaches
   * `errors` rather than `formErrors` — rejects only `*`, names containing `:` and names starting
   * with `sp`, and documents itself as *"a weak heuristic on purpose … not to be authoritative"*.
   * So `getContract` and `ContractProcedure` arrived in `errors` and this screen rendered them in
   * the summary under a bolded field name, inventing a field and sending the user to look for it.
   *
   * ⚠ **Appended rather than merged into `formErrors`**, so the API's own form-level text keeps its
   * order and reads first. Nothing is dropped on either path — `classifyInvalidParams` returns every
   * input in exactly one of its three sets, which is the documented fallback F2.4 asks for.
   */
  protected readonly formLevelReasons: import("@angular/core").Signal<readonly string[]>;
  /** Refusals this screen can point at, in layout order so the summary reads down the form. */
  protected readonly mappedErrors: import("@angular/core").Signal<readonly MappedFieldError[]>;
  /**
   * Puts each refusal on its own control, switches to the first one and focuses it.
   *
   * 🔴 **The tab switch is the half that matters.** The screen has four tabs and a refusal names a
   * field that is very likely not on the one being looked at — the old summary said so in its own
   * words, admitting the field "may be on a tab you are not looking at". A message the user has to
   * go hunting for is barely better than no message.
   *
   * ⚠ **Marked touched as well as errored.** `DynamicFieldComponent` holds its message back until a
   * control has been touched, deliberately — otherwise a blank form shouts at every empty field on
   * first paint. A server error set on an untouched control would be stored and never rendered.
   */
  private applyFieldErrors;
  /**
   * The last refused save's field refusals, with the form they were put on (#1061). Replaced by the
   * next refusal and dropped when a new save starts; a rebuilt form is a different form, so they never
   * carry over to it.
   */
  private serverRefusals;
  /**
   * 🔴 **#1061: puts a refusal back on its control after anything revalidated it away.**
   *
   * A refusal is an error set by hand on the control (`applyFieldErrors`), because no validator can
   * know what CTRM said. Anything that re-runs the control's validators recomputes its errors from
   * those validators alone and drops it, silently:
   *
   * - **leaving the field's tab and coming back.** The tab's fields are destroyed and re-created, and
   *   re-binding `[formControl]` revalidates (`FormControlDirective.ngOnChanges`, with no event). The
   *   box came back clean while the summary still listed the refusal;
   * - **a rule changing the field's requiredness**, because `FormBuilderService.applyRequired`
   *   replaces the validators and revalidates.
   *
   * So after each render that could have done that, a refusal whose control **still holds the value
   * it was refused with** goes back on, outline, sentence and summary alike, from the same `server`
   * key as before. A different value means the user has acted on it, so it stays off. A new save
   * clears them all, and the server's answer to that save decides again.
   *
   * ⚠ **Not a validator, deliberately.** A validator added by this page is exactly what
   * `applyRequired` replaces, so it would vanish the same way the error did. And not a verdict either
   * (`fieldVerdicts`): that draws its sentence beside the box under its own id, so a same-tab refusal
   * would show its sentence twice, and the summary and Save's hold read control errors, not verdicts.
   */
  private readonly reassertRefusals;
  /** Re-applies each refusal still holding its value that its control has lost (#1061). */
  private restoreRefusals;
  /**
   * Switches to a field’s tab and puts the caret in it.
   *
   * ⚠ **The focus waits for the tab to render** — see {@link focusWhenRendered}.
   */
  protected focusField(error: MappedFieldError): void;
  /**
   * Switches to a tab and, when given a component name, focuses that control and scrolls it into
   * view. Shared by a refused save's banner and the validation summary panel (#791).
   */
  private focusControl;
  /** The control to focus once its tab is the one rendered (#1003). */
  private readonly pendingFocus;
  /**
   * Puts the caret in {@link pendingFocus} after the render that shows its tab (#1003).
   *
   * 🔴 **This used to be a microtask after the navigation, and on another tab that found nothing.**
   * The tab switch is a router navigation, which finishes several turns later, and the control is not
   * in the DOM until the screen has rendered the new tab. So a refused create, or a summary link, left
   * the user on the right tab with the caret nowhere, and looked like the feature working.
   *
   * ⚠ **One attempt, on the first render of the target tab, found or not.** A target the tab does not
   * render (a hidden field) is dropped rather than kept, so a later visit to that tab cannot steal the
   * caret. While the host has not yet moved the tab, the target waits.
   */
  private readonly focusWhenRendered;
  /**
   * The contract to show after a save, or `null` to stay on the form.
   *
   * A saved contract belongs on the record it just wrote, so the normal path leaves edit mode
   * immediately for `/contracts/{number}` — the same screen, inactive, showing the collections this
   * form cannot edit.
   *
   * 🔴 **It deliberately does NOT navigate when CTRM disagrees with what we intended.** The response
   * says which of upsert's two paths ran, and that discriminator is the only thing standing between a
   * silent mistake and a caught one (docs/04e — it is what demotes "upsert creates when the key does
   * not match" from unguardable to detective). An edit reporting `Created` made a new contract; a
   * create reporting `Updated` overwrote an existing one; `Unknown` means the wording was not
   * recognised and we cannot say which happened. Navigating away would replace that warning with a
   * record screen that looks entirely normal — which is exactly how the risk goes back to being
   * silent. Those cases stay put so the alert is read.
   */
  private destinationAfter;
  /**
   * **Escape goes where the breadcrumb goes** — the screen this record was opened from.
   *
   * The same destination *and the same query parameters* — so Escape restores the workspace's filters,
   * sort, page and focused row rather than dumping the user on an unfiltered grid. A shortcut that
   * lost the journey would be worse than no shortcut, because the breadcrumb beside it visibly does
   * the right thing.
   *
   * ⚠ **View mode only, and that is new.** Escape in edit or create mode would discard typed changes
   * with no confirmation, on a keystroke people press to dismiss things. The breadcrumb and Cancel are
   * both still there and both say what they do.
   *
   * ### Why the `defaultPrevented` guard is the whole design
   *
   * This is a *document* listener, so it fires wherever focus is. `DropdownDirective` also listens on
   * the document, and the shell's identity menu and trade-unit picker are both open-able from this
   * screen — so without the guard, pressing Escape to close a menu would close it **and** navigate off
   * the record. The directive marks the event handled when it actually dismissed something, and this
   * stands down when it sees that.
   *
   * ⚠ **This relies on the shell's listeners being registered before this one**, which holds because
   * the shell renders before the router activates a route into it. Document listeners on the same
   * phase fire in registration order, so the dropdown always gets first refusal. If a future overlay
   * is created *after* the routed component, it has to mark its own Escape handled too — that is the
   * contract, not the ordering.
   */
  private readonly drafts;
  /**
   * Whether anything would be lost by leaving.
   *
   * ⚠ **Mirrored from the form's own dirty flag rather than maintained independently.** Angular
   * already tracks it and the save path already reads it; a second, separately-computed copy is one
   * more thing that can disagree with the payload — which on this screen means prompting about work
   * that will not be sent, or worse, not prompting about work that will.
   */
  protected readonly isDirty: import("@angular/core").WritableSignal<boolean>;
  /**
   * The draft identity. Null while the screen has nothing to key on, and in view mode.
   *
   * 🔴 **The contract number is in the key, and it is the part that would do real damage without
   * it.** Restoring one contract's values onto another, under a full-replace upsert, writes the
   * first contract over the second — and every field would look deliberately filled in.
   */
  private readonly draftKey;
  /** A recoverable draft found on arrival. Cleared once restored or discarded. */
  protected readonly recoverableDraft: import("@angular/core").WritableSignal<{
    readonly at: string;
  } | null>;
  /** The time to show in the restore prompt, as the user reads a clock. */
  protected readonly recoverableAt: import("@angular/core").Signal<string | null>;
  /**
   * The router hook. Answers true unless leaving would lose something.
   *
   * ⚠ **Returns a plain true in the common case rather than an observable**, so an unguarded
   * navigation resolves without a microtask and stays exactly as immediate as it was before this
   * existed. Every route change on this screen goes through here — the breadcrumb, Cancel, the
   * shell's module nav and the browser Back button — which is what makes it one code path rather
   * than four handlers that can drift apart.
   *
   * 🔴 **A user who cannot write must not be prompted.** #155 hides Save for a non-admin, so anything
   * they typed was never going anywhere — asking them to confirm discarding it would be asking about
   * a loss that had already happened. Their draft is cleared, so it is not offered back later (#839).
   *
   * 🔴 **A HELD Save is not "cannot save"** (#839, walk s3). This used to read `canSave()`, so a user
   * whose Save was held by an error they were still fixing left without being asked and with the
   * draft kept, and the cancelled edit came back as "Unsaved changes were recovered".
   */
  confirmNavigation(): Observable<boolean> | boolean;
  /**
   * The browser-native prompt, for the one exit the router cannot see.
   *
   * ⚠ **The wording is the browser's, not ours** — every current browser ignores the supplied string
   * and shows its own. Setting returnValue is the whole of the API that still works, which is why
   * this is a bare flag rather than a message worth composing.
   */
  protected onBeforeUnload(event: BeforeUnloadEvent): void;
  /** Restores a recovered draft onto the form, marked DIRTY because these were user edits. */
  protected restoreDraft(): void;
  /** Set by {@link reloadAfterUnknownSave}, so the leave guard neither prompts nor clears. */
  private leavingWithDraftKept;
  /**
   * **Reload, after a save whose outcome is unknown** (#556).
   *
   * Nobody knows whether CTRM applied the change, so the only safe next step is to look. An edit goes
   * to the record itself, which re-reads what CTRM holds; pressing Edit there offers this draft back,
   * so nothing typed is lost either way. A create has no record to look at yet, so it goes back to
   * where it was opened from, where the new contract will be if the create landed.
   *
   * 🔴 **The draft is written NOW rather than left to the debounce**, and the leave guard is told not
   * to ask. Its ordinary job is to offer "discard your changes?" and to clear the draft on yes, which
   * is precisely what this button promises not to do.
   *
   * ⚠ Navigation rather than a page reload: under an embedding host a `location.reload()` would
   * reload the host, and the host context is the one way this screen is allowed to move (E9).
   */
  protected reloadAfterUnknownSave(): void;
  /** Throws the recovered draft away, on the user's say-so. */
  protected discardDraft(): void;
  /** This create's idempotency key, minting it on first use (#557). */
  private keyForCreate;
  /** Writes the draft, carrying the create's key so a reload that restores it retries the same create. */
  private writeDraft;
  private clearDraft;
  /**
   * Offers a waiting draft, and keeps writing one as the user types.
   *
   * ⚠ **The offer is read BEFORE any write is wired**, or the screen would immediately overwrite the
   * draft it is about to offer with an empty one.
   *
   * ⚠ **Two subscriptions on purpose.** The write is debounced, because it runs on every keystroke
   * across 111 controls and serialising the dirty set is not free; the dirty flag is not, because the
   * guard and the Save button both read it and a 500 ms window in which a dirty form reports itself
   * clean is a window in which leaving loses work silently.
   */
  private watchDraft;
  /**
   * Opens the leave prompt.
   *
   * ⚠ **Injected in a field initialiser, not reached for inline.** The router invokes
   * confirmNavigation outside any injection context, so a helper that injected in its own body
   * would throw precisely when the form was dirty — the path least likely to be hit by accident.
   */
  private readonly confirm;
  private confirmLeave;
  protected onEscape(event: Event): void;
  private readonly host;
  /**
   * ‹ › over the grid this record was opened from (#1148), in the mode and on the tab it is in, with
   * `from` and `returnTo` carried so Back still returns to the grid's page and state.
   *
   * - **The leave guard runs exactly as on Back**: an arrow is a router navigation, and the edit
   *   route's `canDeactivate` runs when only `:contractNumber` changes (the router reuses this screen,
   *   which reloads every read keyed on the number).
   * - **Held while a save is in flight**, like Cancel (#967): its outcome would land on the next record.
   * - **Create has no journey**: a new contract is not in any grid.
   */
  protected readonly journey: import("@cws/domain-contracts").RecordJourneyControl & {
    leave(): void;
  };
  constructor();
  /**
   * Registers this screen's keys.
   *
   * ### ⚠ Escape is deliberately NOT moved into the registry
   *
   * It stays an `@HostListener` above. Two reasons, and the second is the one that decides it:
   * its `defaultPrevented` guard is the documented contract the shell's dropdowns rely on and is
   * covered by a spec that must keep passing unmodified (criterion 5), and the registry calls
   * `preventDefault()` *before* running a handler — which would mark the event handled for every
   * listener downstream, changing behaviour the guard exists to preserve. It is listed in the
   * overlay as a legend-only shell entry instead, so a user still discovers it.
   *
   * ### 🔴 `allowInTextInput` is true on every binding here, and that is the point
   *
   * These are the keys a person presses **while typing**. A save shortcut that only worked after
   * clicking out of the field would be a save shortcut nobody uses — and all four carry `Ctrl`, so
   * none of them can be produced by ordinary typing.
   */
  private registerRecordShortcuts;
  /**
   * Focuses the field after `from`, in the order the form renders them.
   *
   * ⚠ The same stops Tab makes, minus buttons: `[tabindex="-1"]` is how a read-only field leaves the
   * tab order while editing, so Enter and Tab skip the same fields. At the last field it stays put.
   */
  private advanceField;
  /**
   * Saves, then returns to where the record was opened from.
   *
   * ⚠ **It does not navigate until the save has actually landed.** Leaving optimistically would drop
   * the user on a grid while a `202` was still outstanding — and on this estate a `202` says nothing
   * about the outcome, so a failure would have no screen left to report itself on.
   */
  protected saveAndClose(): void;
  /** Set by {@link saveAndClose}, read by the save subscription. */
  private closeAfterSave;
  /**
   * Moves focus to the next or previous **section**, crossing tabs at the ends.
   *
   * ### 🔴 Sections, not tabs, because that is what §4.2 asks for — and crossing at the ends is what
   * makes it honest
   *
   * This screen groups sections onto tabs, and every section of the active tab is on screen at once.
   * Stepping only within the tab would make `Ctrl+PgDn` stop dead at the last section with 60 more
   * fields one tab away, which reads as the key being broken rather than as a boundary.
   *
   * ⚠ **Focus goes to the section's first ENABLED control, not to the section box.** A heading is not
   * focusable, and scrolling a heading into view while focus stays where it was means the next
   * keystroke types into the field the user just left — the failure mode being avoided is silent.
   * Read-only view mode has no enabled control, so it falls back to scrolling the section into view.
   */
  private stepSection;
  private sectionHasFocus;
  private focusSection;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractRecordPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractRecordPageComponent, "cms-contract-record-page", never, {
    "contractNumber": {
      "alias": "contractNumber";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** #865: what a Notify Trader `202` says, by whether the mail service took it. */
export declare const NOTIFY_TRADER_DELIVERED_MESSAGE = "The email was handed to the mail service. That is not confirmation that it arrived.";
export declare const NOTIFY_TRADER_RECORDED_MESSAGE = "The message was recorded on this contract’s log and was NOT sent: email is not switched on in this environment.";
export declare const NOTIFY_TRADER_ACCEPTED_MESSAGE = "The message was accepted for sending. Acceptance is not confirmation that it arrived.";
/** #912: a CWS log note the server stored. The list is read again after it, so the note shows from there. */
export declare const LOG_NOTE_ADDED_MESSAGE = "Note added.";
/** #812: Save & Notify asked CTRM. Worded as a condition: CTRM emails only when approval is needed. */
export declare const NOTIFY_REQUESTED_MESSAGE = "The trader will be emailed if this contract needs approval.";
/**
 * #812: CTRM's answer could not be used and the save was read back, so its notification step is
 * unknown. #951: worded without "CTRM did not answer", because a database-error answer is read back
 * too (#929); the success carries no `detail` of its own to show instead.
 */
export declare const NOTIFY_UNKNOWN_MESSAGE = "CTRM’s answer could not be used and the save was confirmed by reading the contract back, so whether the trader was emailed is not known.";
/** #812: Save & Notify with nothing changed. Nothing went to CTRM. */
export declare const NOTIFY_NOT_SENT_MESSAGE = "Nothing had changed, so nothing was sent to CTRM and the trader was not emailed.";
/**
 * #973: CTRM accepted the save with its LMS warning (`wnr051e` `$EditBas`; source-read in #985, not
 * yet seen on the wire). Said in our words, and it stays, because it asks the user to check something.
 */
export declare const LMS_WARNING_MESSAGE = "CTRM asks you to verify whether or not this is an LMS contract.";
/** #973: the flag the API could not read, or did not send. */
export declare const LMS_FLAG_UNKNOWN_MESSAGE = "The LMS flag cannot be shown right now, because CTRM could not read this contract’s notes. Try again later.";
/** #812: saved, but CTRM's notification step failed. The server's own sentence (#835). */
export declare const NOTIFY_FAILED_MESSAGE = "The contract was saved, but CTRM could not notify the trader. Tell the trader directly.";
/** #830: a new addendum document went to CTRM, so the contract goes back for approval (BR-066). */
export declare const ADDENDUM_STORED_MESSAGE = "A new addendum document was stored and sent to CTRM, so the contract goes back for approval and signature.";
/**
 * #1115 (ruled 2026-10-22): `Stored` with `templateChanged`, the addendum re-issued under a newer
 * template. The ruling's sentence, word for word; it stays until dismissed.
 */
export declare const ADDENDUM_REISSUED_MESSAGE = "This contract's addendum was re-issued using the current template; it goes back through approval and signature.";
/** #830: the save carried the addendum and its printed text did not change. */
export declare const ADDENDUM_REUSED_MESSAGE = "The addendum’s text did not change, so no new document was issued.";
/** #830: the special type no longer takes an addendum. */
export declare const ADDENDUM_WITHDRAWN_MESSAGE = "The addendum was withdrawn, because this special type takes none.";
/** One refusal, resolved onto the control and tab that can show it. */
interface MappedFieldError {
  readonly ctrmField: string;
  readonly componentName: string;
  readonly label: string;
  readonly tab: string;
  readonly reasons: readonly string[];
}
/** One copy-with-pricing, keyed by the contract it created. */
export interface PricingCopyEntry {
  /** The contract the prices were copied from. */
  readonly source: string;
  /** The new contract. */
  readonly target: string;
  /** The per-sequence run; `null` until the source's prices are read, or when they could not be. */
  readonly run: PriceCopyRun | null;
  /** Why no price was copied at all, when that is the case. */
  readonly failure: string | null;
}
/**
 * Copy-with-pricing's runs, kept across the navigation from the create to the new contract (#459).
 *
 * 🔴 **Root-provided on purpose, and it holds no seam of its own.** The create screen starts a run
 * and then navigates to the new contract, whose record screen is a different component instance;
 * the run has to outlive the first and be found by the second. The pricing source is passed in by
 * the caller rather than injected here, so a host's own `PRICING_SOURCE` is always the one used,
 * which is the trap a root-provided seam fell into before (D-16).
 *
 * ⚠ **In memory only.** A reload loses the panel, never the prices: what was copied is on the new
 * contract's pricing page either way.
 */
export declare class PricingCopyStore {
  private readonly entries;
  /** The run for `target`, or `null` when no copy was made to it in this session. */
  entry(target: string): PricingCopyEntry | null;
  /**
   * Reads `source`'s price sequences and copies them to `target`, one at a time.
   *
   * ⚠ Called only once the create has succeeded: `target` exists and its number is spent, so
   * whatever happens here the contract stands (ruled 2026-10-07).
   */
  start(pricing: PricingSource, source: string, target: string): void;
  /**
   * The ruled second action: posts again **only** the rows that were `not copied`.
   *
   * 🔴 `unconfirmed` rows are deliberately left alone: the first post may have landed and been read
   * back too early, so posting again could duplicate a price. The user settles those on the pricing
   * page.
   */
  retryNotCopied(pricing: PricingSource, target: string): void;
  dismiss(target: string): void;
  private put;
  static ɵfac: i0.ɵɵFactoryDeclaration<PricingCopyStore, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
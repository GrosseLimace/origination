import { AddendumFieldSet, ContractDetail, ContractDetailResponse, ContractFieldKind, ContractLayoutField, ContractLayoutSection, ContractPrice, ContractShipPeriod, ContractTab, ContractTabId, ContractTemplate, ContractWriteResult, FormConfigBundle } from "@cws/domain-contracts";
import { ContractForm, MarketCascade, ResolvedFormConfig, ShipPeriodIssue, ShipPeriodReconciliation, ShipPeriodRow } from "@cws/shared-form-engine";
import { WriteFailureOutcome } from "@cws/core-http";
import { CmsNavigationIntent } from "@cws/core-host-context";
import { BreadcrumbCrumb, ConfirmsNavigation, GridBadge, GridColumn, GridSort, RemoteData } from "@cws/shared-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * The detail screen's field layout — **now the shared one**, not a second copy.
 *
 * 🔴 This file used to declare its own six sections and 34 fields, written to mirror the add/edit
 * screen's table. The two drifted, as two hand-maintained copies of one decision do: they disagreed on
 * where Incoterms sat, on what sat at position 2 of the Contract section, and most of all on *which
 * fields exist* — 70 of the 104 editable fields had no row here at all, so a field could be changed on
 * one screen and be unfindable on the other. That is what this file no longer is.
 *
 * `CONTRACT_LAYOUT_SECTIONS` in `@cws/domain-contracts` is the layout for both screens. What remains
 * here is the part that is genuinely this screen's: how a value is *found* for a contract, which
 * differs because this screen reads a mapped aggregate and the entry screen reads raw writable values.
 *
 * ### Where a value comes from, and why it takes two sources
 *
 * `GET /contracts/{number}` returns a **mapped aggregate** modelling roughly 40 scalars — it cannot
 * supply the other 70. `GET /contracts/{number}/fields` returns all 104 **writable** values keyed by
 * CTRM field name, and strips the read-only ones. Neither is a superset, so the screen reads both:
 *
 * | Source | Supplies |
 * |---|---|
 * | `/fields` | every writable field, by CTRM field name |
 * | the aggregate | the read-only fields `/fields` strips, **and** the writable ones it already models |
 *
 * ⚠ **The aggregate wins where both carry a value, and that overlap is deliberate.** An earlier version
 * of this file mapped only the read-only fields, on the reasoning that two sources for one value is
 * Known Issue 23's shape. It made the screen strictly worse: `/fields` is a supplementary read that can
 * fail, and with nothing beneath it a failure blanked contract date, currency and quantity — fields
 * this screen has always rendered from the aggregate. The overlap is what makes the new fields additive
 * rather than a trade. See {@link mergeContractValues}.
 */
export type FieldKind = ContractFieldKind;
/** Re-exported so the component's imports stay one deep; the definition lives in the shared layout. */
export type DetailField = ContractLayoutField;
/** Re-exported for the same reason. */
export type DetailSection = ContractLayoutSection;
/** The sections, in display order — one table, shared with the add/edit screen. */
export declare const CONTRACT_DETAIL_SECTIONS: readonly ContractLayoutSection[];
/** Why a field is permanently blank, by component name. */
export declare const DETAIL_EMPTY_NOTES: Readonly<Record<string, string>>;
/**
 * Everything the aggregate models, keyed by CTRM field name.
 *
 * ⚠ **Only fields whose CTRM name is unambiguous.** `header.commodity` is deliberately absent: `ConDS`
 * carries three commodity fields and this one has already been the wrong one once — the detail screen
 * rendered a blank commodity while the grid rendered `YELLOW CORN`, which is Known Issue 23 biting
 * through the mapper. `commodity_code` comes from `/fields`, where CTRM names it itself.
 *
 * 🔴 **`contract_number` is absent for exactly the same reason, and it was the second instance.**
 * `header.contractNumber` is the *composed key* — `ComposeNumber` concatenates
 * `prefixType + prefixCommodity + number` and appends `-suffix` when present — while CTRM's
 * `contract_number` field is only the **7-character middle component**. Mapping one onto the other
 * handed the control `SCW227618` where `constraints.json` declares `maxLength: 7`, so the screen
 * displayed `SCW2276`: a truncated key, which under CTRM's positional scheme names a *different
 * contract*. Found in QA on 2026-09-08 (F-04). `contract_number` now comes from `/fields`, where CTRM
 * names it itself — the same resolution as `commodity_code`.
 *
 * The read-only entries at the end are the ones `/fields` can never supply, because `upsertContract`
 * refuses them and the endpoint strips them.
 */
export declare function aggregateValues(contract: ContractDetail): Readonly<Record<string, string | number | null>>;
/**
 * Joins CTRM's resolved trader NAME onto the trader-initials control, for display only (#199, F-15).
 *
 * The screen used to carry two rows: `trader_initials`, which CTRM accepts, and `trader`, which CTRM
 * derives and refuses on a write. The second was `readOnly` and could only ever mirror the first, so
 * it is gone from the layout and its value is folded into the surviving control here — one row
 * rendering `GME — GISSELLE M. ESTEVEZ`, with the form model still holding `GME`.
 *
 * 🔴 **The combo is an UPGRADE applied only when a name is actually in hand, never the default.**
 * `cms-code-combo` is a closed list: it discards anything typed that matches no option. With one
 * option that is exactly right for viewing and editing a contract whose trader CTRM has already
 * resolved — and it would be a trap on the create screen, where there is no aggregate, no name, and
 * therefore no options at all. A user would face a control that silently refused every keystroke.
 * So the layout's default is a plain text input and this function upgrades it or leaves it alone.
 *
 * ⚠ **It never fabricates.** Initials with no name stay a text input showing the initials, which is
 * #199's third criterion — the alternative, rendering `GME — GME`, would assert a resolution CTRM did
 * not make.
 *
 * 🔑 **This is also why the 1,099-row `TR` code table is not fetched.** #219 criterion 8 rules out
 * shipping an unfiltered 87 KB trader list, and the only trader this screen ever needs to *display* is
 * the one on the contract in front of it. Picking a different trader on create is still typed, and
 * scoping that list to a location remains CTRM's open question rather than ours.
 */
export declare function withResolvedTrader(config: ResolvedFormConfig, contract: ContractDetail | null): ResolvedFormConfig;
/**
 * Turns the two market-month text boxes into combos filtered to the contract's own market — #201.
 *
 * The months come from `reference/market-months`, which takes the location, the commodity **and the
 * market code**. That last one is what makes the list meaningful: CTRM validates the month against
 * `FHMM01`–`FHMM15` on the Grain Factors row for that market (`wnr051e:5202-5216`), so an unfiltered
 * list would offer months a save then refuses.
 *
 * 🔴 **An upgrade applied only when the list has settled with rows, exactly like
 * {@link withResolvedTrader}.** A combo is a closed list and discards anything typed that matches no
 * option, so filling one from an in-flight or empty fetch would block entry on a screen that looks
 * entirely functional — #219 criterion 7, which cost a session to find the first time.
 *
 * | `months` | what this does |
 * |---|---|
 * | `null` — in flight | nothing; the control stays a text box |
 * | `[]` — settled, no rows | nothing; there is no market month for this commodity and location |
 * | rows | upgrade both controls to combos |
 */
export declare function withMarketMonths(config: ResolvedFormConfig, months: readonly {
  readonly code: string;
  readonly description: string;
}[] | null): ResolvedFormConfig;
/**
 * Every value the screen can show for a contract, by CTRM field name.
 *
 * 🔴 **`/fields` first, the aggregate on top — the aggregate wins where both have a value.** The
 * ordering is load-bearing in two directions:
 *
 * - **Robustness.** `/fields` is a supplementary read that can fail. With the aggregate merely filling
 *   gaps, a failure would blank fields the screen has always rendered — contract date, currency,
 *   quantity — because they would have had no other source. Layered this way, a failed `/fields` costs
 *   only the ~70 fields the aggregate never modelled, and the screen still shows what it always did.
 * - **Types.** The aggregate arrives typed: numbers as numbers, dates as `DateOnly` strings that
 *   `formatContractDate` already handles. `/fields` is CTRM's raw `base_data`, where they are strings
 *   in CTRM's own shapes. Preferring the aggregate keeps the values that were already rendering
 *   correctly rendering identically, so this change adds fields without moving any existing one.
 *
 * Where the two disagree on a field both carry, that is a defect in one of them rather than a
 * preference — Known Issue 23's shape — and the aggregate winning means the screen keeps showing what
 * it showed before anyone noticed.
 */
export declare function mergeContractValues(contract: ContractDetail | null, writableValues: Readonly<Record<string, unknown>> | null): Readonly<Record<string, unknown>>;
/**
 * The three confirmation statuses, rendered as the progress indicator docs/02 §4.4 specifies.
 *
 * **Order is the workflow order and is load-bearing**: approved → customer confirmed → broker
 * confirmed. BR-065 makes each of these *derived from a populated field* rather than a workflow state,
 * so this is a display of three independent fields that happen to progress — not a state machine, and
 * a later stage can be populated with an earlier one blank.
 *
 * Not layout rows: they are a progress indicator rather than three labelled values, which is also why
 * the shared layout deliberately has no row for `trader_approval_status` and its two siblings.
 */
export declare const CONFIRMATION_STAGES: readonly {
  readonly label: string;
  readonly value: (contract: ContractDetail) => string | null;
  readonly emptyNote?: string;
}[];
/** Formats a field for display. Dates use the long, unambiguous form — this screen has the room. */
export declare function formatFieldValue(value: unknown, kind?: FieldKind): string;
/**
 * One row of the Log tab's timeline (F3.7).
 *
 * `kind` keeps a form-configuration change visually distinct from a change to the contract itself —
 * they are interleaved because both answer "why does this contract look like this?", but reading a
 * configuration edit as somebody having changed the contract would be worse than not showing it.
 */
interface TimelineRow {
  readonly kind: 'contract' | 'configuration';
  readonly key: string;
  readonly at: string;
  readonly actor: string;
  readonly what: string;
  readonly detail: string | null;
  /** The instant as the reader's clock shows it (#567); `at` stays the machine-readable value. */
  readonly atLabel: string;
  /** Each changed field, labelled as the form labels it. Empty when the entry carries none (#567). */
  readonly changes: readonly {
    readonly label: string;
    readonly from: string | null;
    readonly to: string | null;
  }[];
  /** Collections the write replaced whole, by CTRM name. */
  readonly collectionsReplaced: readonly string[];
}
/**
 * Which of the record screen's three jobs this instance is doing.
 *
 * Not three components and not three templates — see the class remarks. Everything conditional reads
 * {@link ContractRecordPageComponent.mode}, and the conditions are deliberately few: the controls'
 * activity, the toolbar, and which reads are issued.
 */
export type ContractRecordMode = 'view' | 'edit' | 'create';
/** How a save ended, for the screen to report. */
interface SaveState {
  readonly status: 'idle' | 'saving' | 'saved' | 'failed';
  readonly result?: ContractWriteResult;
  /** Field name to reasons, straight from the API's RFC 7807 `errors`. */
  readonly fieldErrors?: Readonly<Record<string, readonly string[]>>;
  readonly formErrors?: readonly string[];
  /**
   * What the failure means for the contract (#556). Only `refused` carries reasons; the other two
   * are CTRM not answering, and the banner says what that does and does not tell us.
   */
  readonly failure?: WriteFailureOutcome;
}
export declare class ContractRecordPageComponent implements ConfirmsNavigation {
  private readonly details;
  private readonly writes;
  private readonly mintIdempotencyKey;
  /**
   * **This create's idempotency key** (#557), minted on first use and then held for the life of the
   * create: every retry sends the same one, so a create whose answer was lost cannot become a second
   * contract once the server honours it (#558). A restored draft brings its own key back; a
   * discarded draft or a completed create retires it, because what follows is a different contract.
   *
   * ⚠ Null in edit and view, and never sent on an update: an update re-applies the same values onto a
   * freshly read merge base, so a repeat does not compound.
   */
  private createKey;
  private readonly numbers;
  private readonly configs;
  private readonly tradeUnit;
  private readonly permissions;
  /**
   * Where this screen goes when it leaves, and how it records its own position (F9.1, #416).
   *
   * 🔴 **This used to be `inject(Router)`, and the screen navigated to ABSOLUTE paths** —
   * `/contracts/{n}`, `/`, `/approvals`. Embedded, that escapes the host's outlet entirely and lands
   * the user somewhere the host never routed. The 2026-09-18 host-workspace spike found it (#335
   * finding 3) and this library's own `public-api.ts` claimed the opposite was already true.
   *
   * The screen now states an intent and the host decides what it means. Standalone that is
   * `routerHostContext`, which reproduces exactly the five calls this replaced.
   */
  private readonly hostContext;
  /** Where this screen tells its host what happened (F9.5). */
  private readonly events;
  /**
   * Hands the host an intent, and publishes it as a `navigation-requested` event (F9.5).
   *
   * 🔴 **Every navigation goes through here, never through `hostContext.navigate` directly.** The
   * event is the host's record of where the user went, so a call site that bypassed this would
   * navigate with no event, and a host keeping the user in its own outlet would never know.
   */
  private requestNavigation;
  /**
   * The customer lookup (F4.3b), or `null` where the host provides none — in which case blurring
   * the Customer id confirms nothing and the screen behaves as it did before the lookup existed.
   */
  private readonly customers;
  /**
   * What the last Customer id blur found: the id asked about, the note to show under the field, and
   * the name to write into the read-only Customer name field (`null` clears it).
   *
   * 🔴 Redacted is a note that says so, never a blank and never the literal in the name field —
   * the same rule as the grid's customer-names verdict, because a blank is indistinguishable from
   * the gap the screen had before the directory existed.
   */
  private readonly customerConfirmation;
  /** Leads the breadcrumb — the same `CODE · Name` the shell's picker shows, so the two agree. */
  protected readonly tradeUnitLabel: import("@angular/core").Signal<string | null>;
  /**
   * The contract this screen is showing, or empty when creating.
   *
   * Bound from the route by `withComponentInputBinding()` rather than read from `ActivatedRoute`: a
   * snapshot read would leave one contract's data sitting under another contract's URL when
   * navigating between them.
   *
   * 🔴 **The transform is not defensive tidying — without it the create screen does not render.**
   * `withComponentInputBinding()` does not leave an unmatched parameter alone; it *sets* the input, to
   * `undefined`. A default value only applies when nothing ever writes the input, and the router
   * writes it on every navigation — so on `/contracts/new`, which has no `:contractNumber` segment,
   * this is `undefined`, and the first `.trim()` threw during change detection. Add mode was broken in
   * the browser and green in every test, because a component input set directly is not the same thing
   * as a bound route parameter.
   */
  readonly contractNumber: import("@angular/core").InputSignalWithTransform<string, string | null | undefined>;
  /**
   * Which mode to render in, supplied by the route's `data`.
   *
   * `withComponentInputBinding()` binds `data` to inputs as well as path parameters, so each route
   * states its own mode and no component here infers one from the URL shape.
   *
   * ⚠ **The transform exists for the same reason as `contractNumber`'s**, and it is the same trap:
   * route `data` that omits `mode` does not leave this input alone, it sets it to `undefined`. All
   * three routes set it explicitly *and* this defaults — belt and braces, because the failure mode is
   * an edit screen that silently renders as a view (or worse, the reverse).
   */
  readonly mode: import("@angular/core").InputSignalWithTransform<ContractRecordMode, ContractRecordMode | null | undefined>;
  protected readonly isCreate: import("@angular/core").Signal<boolean>;
  protected readonly isView: import("@angular/core").Signal<boolean>;
  /** Every CTRM location code, for BR-002a branch 3. Joins an already-cached set (F2.3c, #423). */
  private readonly locationCodes;
  /**
   * **BR-002a** — whether this contract's customer is intercompany.
   *
   * Read from the contract as **loaded** rather than from the live form. The lock exists to stop
   * someone editing an intercompany purchase they opened; re-evaluating it as the customer control
   * changes would let the screen lock itself mid-edit and discard work in progress without warning,
   * which is a worse outcome than the under-lock — and CTRM enforces the write server-side either
   * way. ⚠ Stated as a limit rather than left to be discovered: changing the customer to an
   * intercompany one during an edit does **not** lock the form.
   */
  protected readonly intercompany: import("@angular/core").Signal<import("@cws/domain-contracts").IntercompanyVerdict>;
  /**
   * **BR-002** — the whole form read-only because this is an intercompany *purchase*.
   *
   * 🔴 **Fails OPEN.** Every uncertain input — no customer, a customer too short to slice, a
   * locations set that has not loaded, an unknown prefix — leaves this `false` and the form
   * editable. A false positive here blocks a trader from work they are entitled to do with no way
   * round it from the screen, which is strictly worse than an under-lock CTRM may still refuse.
   */
  protected readonly intercompanyLock: import("@angular/core").Signal<boolean>;
  /**
   * A CTRM field's value on the contract as loaded, or `null`.
   *
   * ⚠ The **loaded** values, not the live form — see {@link intercompany}. Blank is normalised to
   * `null` so "present but empty" cannot read as a value.
   */
  private ctrmFieldValue;
  /**
   * True when the controls accept input. The one thing the whole mode distinction comes down to.
   *
   * 🔴 **BR-002's intercompany-purchase lock is part of it** (F2.3c, #423). It was `!isView()`
   * alone, so an intercompany purchase rendered fully editable — the read-only rule existed in the
   * requirements and nowhere in the code.
   */
  protected readonly isEditable: import("@angular/core").Signal<boolean>;
  /**
   * The grid state to return to, packed by the home screen into one opaque parameter.
   *
   * Read from the snapshot: it describes the journey that reached this screen, so it cannot change
   * while the screen is open.
   *
   * Absent when the contract was reached by a direct link or a refresh, in which case the breadcrumb
   * still works and simply lands on an unfiltered workspace. That fallback matters — a breadcrumb that
   * only functioned when you arrived a particular way would be worse than none.
   */
  private readonly route;
  private readonly returnTo;
  /**
   * The contract this create is a copy of, from `?copyFrom=`, or `null` for an ordinary create.
   *
   * **A query parameter on `/contracts/new` rather than a route of its own**, because a copy is not a
   * fourth mode — it is a create with a seed source. Every mode-dependent branch on this screen stays
   * as it is, and the copy inherits the create journey whole: the trade-unit default, the number
   * issuance, the save path, the create-versus-update discriminator.
   *
   * It also makes a copy linkable and refresh-proof, which docs/02 §1.3 asks of every route — reload
   * `/contracts/new?copyFrom=SCW227618` and you get the same screen rather than an empty form.
   *
   * Read from the **snapshot**, like `returnTo` and for the same reason: it describes the journey that
   * reached this screen, so it cannot change while the screen is open. The form seeds once, so a
   * mid-life change to the seed source would have nowhere to go even if it could happen.
   */
  protected readonly copyFrom: string | null;
  /**
   * The breadcrumb's target, as router `queryParams`.
   *
   * Unpacked into an object rather than navigated as a URL string so the crumb can be a real
   * `routerLink` anchor: it gets an `href`, so middle-click and "open in new tab" work, and a keyboard
   * user reaches it with Tab. A `(click)` handler calling `navigateByUrl` would look identical and be
   * none of those things.
   */
  protected readonly returnParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * Which screen the breadcrumb goes back to, and what it is called there.
   *
   * 🔴 **This crumb used to be a hard-coded "Contracts" pointing at `/`.** That was right while the
   * workspace was the only way in, and the approvals and pricing queues made it wrong in the worst
   * way — it still *worked*, so an approver who opened a row, read the contract and pressed the
   * crumb was quietly moved to a different screen, losing the queue's filters, its sort and their
   * place in it. Read from the URL so a reload or a pasted link renders the same crumb as a click.
   */
  /**
   * The `from` parameter exactly as the URL carried it — unnormalised, possibly `null`.
   *
   * Held separately because the **host** is what turns a logical origin into a route (F9.1): a
   * `navigate` intent carries this raw value, and the host's own resolver normalises it. Passing
   * `origin().path` instead would put an absolute path back into the intent, which is the defect
   * this replaced.
   *
   * ⚠ **Read from `snapshot` once, and both consumers must stay on this one field.**
   * `paramsForTab` rebuilds the query string from `tab` and `returnTo` only, so switching a tab
   * drops `from` out of the URL. A second, later read of `queryParamMap` would therefore disagree
   * with this one and silently downgrade an approvals journey to the default crumb.
   */
  private readonly originParam;
  protected readonly origin: import("@angular/core").Signal<import("@cws/domain-contracts").RecordOriginDescriptor>;
  /**
   * Every screen behind this one, as links — not just the one the journey started on.
   *
   * 🔴 **One crumb was wrong for the approvals journey, and wrong the way that is hardest to see: it
   * worked.** "View full record" on the review screen left a trail reading `Approvals › SS1242898`,
   * so the only way back went *past* the screen the user had actually come from. They opened the
   * record in order to decide on the contract, and the trail offered them the queue instead — losing
   * the decision they were in the middle of, with nothing appearing broken.
   *
   * The middle crumb is **derived** rather than passed: `from=approvals` is set in exactly one place,
   * so its presence already says the review screen is behind you. See {@link recordTrail}.
   */
  protected readonly trail: import("@angular/core").Signal<readonly import("@cws/domain-contracts").RecordCrumb[]>;
  protected readonly editIntent: import("@angular/core").Signal<CmsNavigationIntent>;
  protected readonly newIntent: CmsNavigationIntent;
  protected readonly copyIntent: import("@angular/core").Signal<CmsNavigationIntent>;
  /** A create cancels to the workspace; an edit cancels back to this record, on its tab. */
  protected readonly cancelIntent: import("@angular/core").Signal<CmsNavigationIntent>;
  /** The breadcrumb, each crumb carrying its host-resolved link. */
  protected readonly crumbs: import("@angular/core").Signal<readonly BreadcrumbCrumb[]>;
  protected hrefFor(intent: CmsNavigationIntent): string;
  /**
   * A click on one of the links above.
   *
   * A plain left click is handed to the host and published as `navigation-requested`. A modified or
   * middle click is left to the browser, which opens the host's href in a new tab or window: that is
   * why these stay real anchors rather than buttons.
   */
  protected follow(event: MouseEvent, intent: CmsNavigationIntent): void;
  /**
   * The last crumb — the page you are on, which is never a link.
   *
   * ⚠ **Mode-dependent, which is why it is computed here rather than left to the breadcrumb.** The
   * shared component renders a trail; what the current page is CALLED is this screen's business,
   * and this is the only screen where it is not simply the contract number.
   */
  protected readonly currentCrumb: import("@angular/core").Signal<string>;
  /** Bumped by Retry so a retry genuinely re-issues every request. */
  private readonly attempt;
  /**
   * The driver values the user has chosen on a create, which re-resolve the configuration (§10.2).
   *
   * Only create mode: on an existing contract the dimensions come from the contract itself, and
   * re-resolving mid-edit because someone changed the commodity is a v2 question (the screen says so
   * when the commodity is dirty).
   */
  private readonly createDrivers;
  /**
   * What to resolve the configuration for (ADR-17 D1).
   *
   * 🔴 **View and edit resolve by CONTRACT NUMBER, not by trade unit**, and that is the whole reason
   * the resolve endpoint takes one. The most significant dimension is the contract type class, which
   * is CTRM's `text_description` — a *read-only, derived* field. It is present in the raw aggregate
   * and stripped from `GET /contracts/{n}/fields`, so a client that tried to assemble the key itself
   * would silently lose the dimension that outranks the other two. The server derives all three from
   * a fresh read instead.
   *
   * Create has no contract yet, so it passes what it knows: the shell's trade unit, plus whatever
   * driver fields the user has filled in.
   */
  private readonly resolutionKey;
  /**
   * The form configuration, and the state the async container renders.
   *
   * 🔴 **The configuration is what gates the screen, in every mode — including view.** That is a real
   * change: the read-only screen used to render as soon as the aggregate arrived. It cannot any more,
   * because the fields are controls now and the controls come from the configuration; rendering
   * without it would show a record with no fields at all.
   */
  protected readonly configState: import("@angular/core").Signal<RemoteData<FormConfigBundle>>;
  /**
   * The configuration to render, holding the LAST loaded one while a re-resolve is in flight (#197).
   *
   * 🔴 **This is what stops a driver change tearing the screen down.** Changing commodity or trade unit
   * re-resolves the configuration, and `configState` correctly goes back to `loading` — but the screen
   * was gated on that state directly, so all 111 controls unmounted and the page dropped to "Loading
   * contract" until the fetch returned. QA finding F-09 reported it as the *form rebuild*; it is not,
   * and the rebuild is unavoidable anyway — a different driver genuinely is a different set of
   * controls. What is avoidable is blanking the screen while waiting.
   *
   * ⚠ **The retained value must be the LAST LOADED one, never a stale-and-wrong one.** It is replaced
   * the moment a new configuration arrives, and `formKey()` keys the rebuild on the configuration's own
   * version — so the fields swap in place when the answer comes back, and a re-resolve that wins the
   * same row does not churn the form at all.
   *
   * `linkedSignal` rather than an effect: this is a derivation with memory, and an effect writing a
   * signal is the shape that produces a second source of truth nobody can find.
   */
  private readonly retainedBundle;
  /**
   * The resolved configuration, with the trader name joined onto the initials control (#199).
   *
   * 🔴 **Overlaid HERE rather than in the config source, because this is the only place that holds
   * both halves.** `HttpFormConfigSource` resolves a configuration for a trade unit and has never
   * seen the contract; the trader's name is a property of the contract. Pushing the contract into the
   * config source to satisfy one field would make every configuration fetch depend on a record read.
   *
   * Every consumer of `bundle()` — the rendered form, `visibleSections`, the tab counts — reads the
   * overlaid copy, so the control, the badge and the payload cannot disagree about what is on screen.
   */
  protected readonly bundle: import("@angular/core").Signal<FormConfigBundle | null>;
  /**
   * What the async container renders — the two reads the record cannot be shown without, combined.
   *
   * 🔴 **There are two of them now and there used to be one, so this cannot just be the config's
   * state.** The old read-only screen was gated on the aggregate alone; the old edit screen on the
   * configuration alone. This screen needs both — the configuration because the fields *are* its
   * controls, and the aggregate (outside create mode) because it carries the collections, the
   * quantities and the confirmation statuses.
   *
   * Errors win over loading, and the configuration wins over the aggregate where both are in the same
   * state. That ordering is deliberate: a failed configuration means there is no record layout at all,
   * which is a different and more total failure than a contract that could not be read, and reporting
   * the more specific one first would send someone looking at the wrong thing.
   */
  protected readonly containerState: import("@angular/core").Signal<RemoteData<unknown>>;
  /**
   * The contract aggregate — the collections, the quantity breakdown, the confirmations.
   *
   * `null` **only** while creating, where there is no contract to read. Anything else is a real
   * `RemoteData`, errors included.
   *
   * ⚠ **Deliberately NOT caught into a "degrade to the fields" state, and that was a wrong turn worth
   * recording.** The first version of this screen swallowed the failure and rendered the record with an
   * alert, on the reasoning that losing the collections beats losing the record. It is wrong for the
   * case that actually happens: `Contract not found.` is an *error about the record*, and answering it
   * with a full set of empty controls plus a banner is strictly worse than the error state the previous
   * screen showed — a user would read the blanks as the contract. The `/fields` read still degrades
   * gracefully, because that one genuinely is supplementary.
   */
  private readonly aggregate;
  protected readonly response: import("@angular/core").Signal<ContractDetailResponse | null>;
  /** The last load outcome announced, so a re-render never repeats an event (F9.5). */
  private lastAnnouncedLoad;
  /**
   * Tells the host a record opened, or failed to (F9.5).
   *
   * Keyed on the attempt, the number and the outcome, so each real load announces exactly once: a
   * retry is a new attempt and announces again, a re-render is not. A close or re-open answers a
   * re-read without a new load, so it opens nothing new.
   */
  private readonly announceLoad;
  protected readonly contract: import("@angular/core").Signal<ContractDetail | null>;
  /**
   * The contract's current writable values, from `GET /contracts/{number}/fields`.
   *
   * **Its own request, and deliberately not the aggregate.** That response models 47 of `base_data`'s
   * 146 fields, so filling the form from it would leave ~70 controls blank while CTRM holds values for
   * them — and a blank control is indistinguishable from an empty value. In view mode that is a lie;
   * in edit mode it is worse, because a user would fill in a field that was never empty and the typed
   * value would be written.
   */
  private readonly prefill;
  /**
   * The source contract's writable values, when this create is a copy (BR-041).
   *
   * **The same read the edit screen prefills from** — `GET /contracts/{number}/fields` — and
   * deliberately not the aggregate, for the reason recorded on {@link prefill}: the aggregate models
   * 47 of `base_data`'s 146 fields, so copying from it would leave ~70 controls blank while CTRM holds
   * values for them. On an edit that is a lie about the record; on a copy it is a contract quietly
   * missing three quarters of what it was copied from.
   *
   * ⚠ **A failed read is `failed`, not an empty copy.** It gates the screen (see
   * {@link valuesReady}) and raises {@link copyFailed}, because the alternative is a form that looks
   * like a deliberately blank new contract — and the user asked for a copy, so they would reasonably
   * read those blanks as the source contract's values and save them.
   */
  private readonly copySource;
  /** True when this create was reached by Copy contract. */
  protected readonly isCopy: import("@angular/core").Signal<boolean>;
  /** True when this is a copy whose source could not be read. */
  protected readonly copyFailed: import("@angular/core").Signal<boolean>;
  /**
   * The copied values, keyed by component name and ready for `defaultValues`.
   *
   * The exclusions come from {@link copyExclusions} over the **resolved configuration**, so BR-041's
   * per-field flags are honoured per trade unit rather than hard-coded here — and the contract's own
   * identity is excluded structurally, inside `copyableValues`, where no configuration can reach it.
   * Read that function's remarks before changing either layer: one of them is what stops a copy
   * overwriting the contract it was copied from.
   */
  private readonly copiedValues;
  /**
   * Whether the form may be built yet.
   *
   * 🔴 **The form seeds ONCE, in the child's `ngOnInit`.** The configuration and the values are
   * separate requests, and the screen renders on the configuration alone — so whenever the values were
   * the slower of the two, which over HTTP they usually are (the configuration is three cacheable
   * reads against one contract-specific one), the form was built with nothing and never re-seeded. The
   * screen then showed 111 empty controls for a contract CTRM holds values for, which is
   * indistinguishable from a contract that is genuinely empty.
   *
   * Gating rather than re-seeding is deliberate: a late re-seed would overwrite whatever the user had
   * already typed into a form they were shown and invited to edit.
   *
   * ⚠ **This now gates the view mode too**, which the old read-only screen had no equivalent of. Same
   * reasoning, and it is if anything more important there: the whole screen is those values.
   */
  protected readonly valuesReady: import("@angular/core").Signal<boolean>;
  private readonly ctrmValues;
  /** Every value the screen can show, by CTRM field name — both sources merged, aggregate winning. */
  private readonly values;
  /**
   * The values the controls are seeded with, keyed by component name.
   *
   * 🔴 **Coerced, not passed through.** `/fields` returns CTRM's raw `base_data`, where a quantity is
   * a string and a date may be packed or the `0001-01-01` sentinel. The old detail screen never met
   * this because it formatted every value itself on the way into a `<dd>`; controls do not, so
   * `seedFromCtrmValues` does the translation — including mapping CTRM's unset-date sentinel to
   * nothing, which this project has already once rendered as *the year 1*.
   */
  protected readonly initialValues: import("@angular/core").Signal<Readonly<Record<string, unknown>>>;
  /**
   * What this screen fills in for a create, before the user types anything.
   *
   * 🔴 **The trade unit, and it is not a convenience.** The contract list is scoped by trade unit —
   * CTRM has no unfiltered list — so a contract created without a `location` is accepted, reports a
   * number, and is then **missing from the grid the user created it from**. It is not lost; this screen
   * still finds it by number. But a create that disappears from the list reads as a failed save, which
   * is the worst possible outcome for a write that actually succeeded.
   *
   * ⚠ **Create only.** On an edit the contract already has a trade unit and it is CTRM's to state, not
   * this screen's — seeding one there could move a contract between units on a save meant to change
   * something else entirely.
   */
  protected readonly defaultValues: import("@angular/core").Signal<Readonly<Record<string, unknown>>>;
  /**
   * True when the values could not be read — the form would otherwise look like an empty contract.
   *
   * Keyed on the `failed` status rather than on the values being null. "No values yet" and "the read
   * failed" were the same condition once, so the warning showed while the request was in flight and
   * then vanished — an alarm that fires on every load is one nobody reads.
   */
  protected readonly prefillFailed: import("@angular/core").Signal<boolean>;
  /** Shown when the rows did not come from CTRM, exactly as the grid does. */
  protected readonly isSimulated: import("@angular/core").Signal<boolean>;
  /** CTRM warnings, surfaced rather than dropped (correction C-2). Rare on a read. */
  protected readonly warnings: import("@angular/core").Signal<readonly string[]>;
  /** Reference sets that returned nothing, named on screen rather than rendered as empty combos. */
  protected readonly unavailableLists: import("@angular/core").Signal<readonly string[]>;
  /**
   * One line per **standing** notice, in the order the panel projects them.
   *
   * 🔴 **The membership rule is what matters here, not the wording: standing conditions of the
   * screen go in, outcomes of something the user just did stay out.** This screen produces a lot of
   * the second kind — a save result, a save failure, a copy that could not read its source, a
   * contract number that could not be issued, a prefill that failed — and every one of them stays a
   * full-width banner. Behind a collapsed panel they would be messages nobody sees, and two of them
   * carry `role="alert"` precisely because they must interrupt. {@link NoticesPanelComponent}'s own
   * remarks state the rule; this is the screen where it is easiest to get wrong, because both kinds
   * were rendered identically before.
   *
   * ⚠ **The order has to match the projected content**, since these are the lines a reader uses to
   * decide whether to expand. Nothing enforces it — keep the two in step by hand.
   */
  protected readonly noticeSummaries: import("@angular/core").Signal<string[]>;
  /**
   * The child collections CTRM returns that CMS does not read yet.
   *
   * Rendered rather than hidden — the difference between *"this contract has no quality factors"* and
   * *"CMS does not read quality factors"*, which the endpoint goes out of its way to make expressible.
   * Underscores become spaces for reading; the wire names stay in the `title` so the list is greppable
   * against the API.
   */
  protected readonly unmodelled: import("@angular/core").Signal<readonly string[]>;
  protected readonly stages: readonly {
    readonly label: string;
    readonly value: (contract: ContractDetail) => string | null;
    readonly emptyNote?: string;
  }[];
  /**
   * Help text per field, and the merge in it is not cosmetic.
   *
   * 🔴 **`CONTRACT_LAYOUT_EMPTY_NOTES` had no home once the fields became controls, and it carries the
   * answer to a question a blank field cannot.** The old `<dl>` rendered `Not set — <reason>` in place
   * of a missing value, which is how the screen distinguished *"CTRM holds nothing"* from *"no CTRM
   * route returns this"* — #47's whole point, and the reason `customer_name` is permanently blank. An
   * empty read-only input says neither.
   *
   * So the reasons move into the control's help text — but they are passed **separately** from
   * ordinary notes and rendered only while the field is empty.
   *
   * 🔴 **They used to be merged here, and that made the screen assert something false.** Folded into
   * one record, an `emptyNote` rendered whether or not the field had a value, so a contract at version
   * `009` carried "CTRM has not versioned this contract" directly beside the `009` — #195, QA finding
   * F-03. It was recorded at the time as "a small loss of precision"; it is not, because a note that
   * contradicts the value next to it is worse than silence rather than better than it.
   *
   * A field's own `note` still wins where it has both — that one is guidance for filling the field in
   * and is the more actionable of the two. There are exactly two `emptyNote` rows today and neither
   * has a `note`, so nothing is being dropped — the precedence is stated for whoever adds the third.
   */
  protected readonly fieldNotes: import("@angular/core").Signal<Readonly<Record<string, string>>>;
  /**
   * The Quantity caption for a contract whose shipment periods already allocate a total — or `null`
   * when there is nothing to say (#139, QA finding from the 2026-09-01 live probe).
   *
   * 🔴 **The rule this states is one CTRM enforces and this screen cannot currently satisfy.** CTRM
   * requires the ship-period quantities to sum to the header quantity, so changing Quantity alone is
   * refused — and **every contract this application creates has one ship period**, so it is the normal
   * case rather than an edge one.
   *
   * 🔑 **Why a caption rather than letting the save fail: the refusal has nowhere to land.** CTRM scopes
   * it to `ship_periods(1).ship_quantity`, and F2.4 binds a field-scoped error to the matching control.
   * There is no ship-period control on this screen, so a correctly formed, correctly delivered error is
   * dropped — and the user who typed in **Quantity** is told nothing about Quantity. That is the
   * everything-worked-and-the-user-sees-nothing shape this repository keeps recording.
   *
   * This is #139's option 1 — *surface the constraint*, deliberately not option 2 (*disable Quantity*).
   * Disabling would be the honest thing only if the field could never be saved, and it can: a contract
   * with no periods is unconstrained, and the backend guard re-scopes the refusal to `quantity` anyway.
   * Offering a field that states its own precondition beats removing one that sometimes works.
   *
   * ⚠ **View mode is deliberately included.** The caption explains the arithmetic on screen, and that
   * is worth reading before pressing Edit rather than after.
   */
  protected readonly shipPeriodAllocation: import("@angular/core").Signal<string | null>;
  /**
   * The contract quantity as the **control** currently holds it — the live left-hand side of BR-021.
   *
   * 🔴 **Read from the control, never from `ContractForm.value`.** This screen seeds all 111 of its
   * fields with `emitEvent: false`, and although #364 made the engine's value signal reflect a seeded
   * contract through `ContractForm.seed()`, the market-cascade patch and the draft restore still
   * write silently. `market-cascade.ts` snapshots controls for exactly this reason and is the pattern
   * mirrored here. A gate reading the signal would evaluate an empty form and pass everything.
   */
  private readonly headerQuantity;
  /**
   * The ship periods **as loaded**, for deciding whether the collection changed (F2.3b, #372).
   *
   * 🔴 This is what keeps the save non-destructive. `upsertContract` REPLACES a supplied collection
   * entirely — an omitted row is a deleted row, answered `202` either way — so the payload must
   * carry `ship_periods` only when it differs from this. See {@link shipPeriodsChanged}.
   */
  private readonly seededShipPeriods;
  /**
   * The editable ship-period collection.
   *
   * ⚠ **A signal rather than a `FormArray`**, and the reason is scope rather than taste: the rows
   * are not part of `ContractForm`'s configuration-driven scalar group, so a `FormArray` would mean
   * changing the shared form component for every screen that mounts it. The save path's `dirty`
   * discriminator is scalar-only too, so the collection needs its own changed-test regardless —
   * {@link shipPeriodsChanged} — and that is cheaper to write against a signal than against a
   * control tree.
   */
  protected readonly shipPeriodRows: import("@angular/core").WritableSignal<readonly ShipPeriodRow[]>;
  /** Whether the collection differs from what CTRM gave us. Drives whether it is sent at all. */
  protected readonly shipPeriodsChanged: import("@angular/core").Signal<boolean>;
  /** **BR-022** — the next period to propose, or `null` at CTRM's 12-row cap. */
  /** CTRMs ship-period cap, for the template. */
  protected readonly maxShipPeriods = 12;
  protected readonly nextShipPeriodProposal: import("@angular/core").Signal<ShipPeriodRow | null>;
  /** **BR-020** — every problem the collection currently has, rows and collection alike. */
  private readonly shipPeriodValidation;
  /** **BR-020** — per-row problems, by row index. */
  protected readonly shipPeriodIssues: import("@angular/core").Signal<ReadonlyMap<number, readonly ShipPeriodIssue[]>>;
  /**
   * **BR-020** — problems about the collection rather than a row, chiefly the 12-period cap.
   *
   * Kept separate because they have nowhere to render inside the table: a `rowIndex` of `null` means
   * there is no row to attach to, and dropping them would leave the cap silently unenforced.
   */
  protected readonly shipPeriodCollectionIssues: import("@angular/core").Signal<ShipPeriodIssue[]>;
  /** **BR-022** — overlapping periods are a warning, not a refusal: CTRM permits them. */
  protected readonly shipPeriodsOverlap: import("@angular/core").Signal<boolean>;
  /**
   * Seeds the editable collection from the loaded contract, once per contract.
   *
   * ⚠ Seeded from the aggregate rather than from the write prefill, because the prefill carries
   * scalars only — `ContractWriteFields.fields` is `Record<string, unknown>` and has never had a
   * collection in it.
   */
  private readonly seedShipPeriods;
  /**
   * **BR-022** — adds the next period, auto-chained from the last one's end date.
   *
   * The action is disabled at the cap rather than silently doing nothing, which is why
   * {@link nextShipPeriodProposal} returns `null` there instead of a blank row.
   */
  protected addShipPeriod(): void;
  /**
   * The collections to send, or **`undefined` to leave CTRM's own rows alone**.
   *
   * ### 🔴 This returning `undefined` is the safety property, not an optimisation
   *
   * `upsertContract` replaces a supplied collection **entirely** — an omitted row is a deleted row —
   * and answers `202` either way (correction C-4), so the destructive request and the harmless one
   * look identical from the response. Sending the current rows on every save would therefore put a
   * full replace on the save path of every contract edit, and a grid that had failed to seed would
   * clear the contract's periods and report success.
   *
   * So: **the key is absent unless a period actually changed**, which is asserted by a test that
   * reads the payload rather than the screen.
   */
  private shipPeriodCollections;
  /** Removes one period. */
  protected removeShipPeriod(index: number): void;
  /**
   * **BR-020** — accepts a date in any of CTRM's three entry forms and stores it canonically.
   *
   * `parseShipPeriodDate` handles `MMDDYYYY`, `MMDDYY` (1930–2029 pivot) and `MM/DD/YYYY`. A value
   * that does not parse is kept as `null` rather than guessed at, and the row's issue list says so.
   */
  protected setShipPeriodDate(index: number, edge: 'beginDate' | 'endDate', input: string): void;
  /** Sets one row's quantity. Blank is `null`, which BR-020 reports rather than treating as zero. */
  protected setShipPeriodQuantity(index: number, input: string): void;
  /**
   * **BR-023** — regenerates `ship_period_description` from the span the periods now cover.
   *
   * 🔴 **One description for the whole contract, not one per row.** `ship_period_description` is a
   * `base_data` scalar (Known Issue 18) and the `ship_periods` collection has no description member
   * at all, so the generated text describes the span from the earliest begin to the latest end.
   * With a single period that is just that period, which is the common case and the shape
   * `buildShipPeriodDescription`'s three formats were written for.
   *
   * ⚠ **It overwrites a hand-typed description on the next date edit**, deliberately: BR-023 says
   * the description is auto-generated, and a screen that silently stopped regenerating after one
   * manual edit would leave the text disagreeing with the dates beside it.
   */
  private regenerateShipPeriodDescription;
  /**
   * **BR-021 — Σ ship-period quantities must equal the contract quantity** (#371, F3.2d).
   *
   * `null` when the contract has no ship periods, which is *unconstrained* rather than balanced:
   * CTRM only enforces the sum where periods exist, and gating there would invent a rule and block
   * every contract this screen can currently create.
   *
   * ⚠ **Only the header side is live.** The periods come from the loaded aggregate because the grid
   * is read-only; editing a period is #372, and this computed will pick it up unchanged when the
   * rows become a form collection.
   */
  protected readonly shipPeriodReconciliation: import("@angular/core").Signal<ShipPeriodReconciliation | null>;
  /**
   * Whether BR-021 blocks the save.
   *
   * 🔴 **This PREVENTS a CTRM refusal; it does not replace one.** CTRM scopes the refusal to
   * `ship_periods(1).ship_quantity` and the backend re-scopes it to `quantity` (#140) — that server
   * guard stays and is the authority. What this removes is a user reaching it and being told
   * nothing they can act on, because there is no ship-period control for the error to land against.
   */
  protected readonly shipPeriodGateBlocks: import("@angular/core").Signal<boolean>;
  /** Keeps {@link headerQuantity} in step with the Quantity control. */
  private watchHeaderQuantity;
  /** Why a field is permanently blank. Shown only while it *is* blank — see {@link fieldNotes}. */
  protected readonly emptyNotes: Readonly<Record<string, string>>;
  protected readonly sectionNotes: Readonly<Record<string, string>>;
  protected readonly wideFields: Readonly<Record<string, boolean>>;
  /** Half-width fields, paired into one cell. Their notes move into the "i" tooltip. */
  protected readonly halfFields: Readonly<Record<string, boolean>>;
  /** The visible heading a field introduces, covering the grouped fields below it (#196). */
  protected readonly groupHeadings: Readonly<Record<string, string>>;
  /** Fields under a group heading, so their own heading is suppressed. */
  protected readonly hiddenLabelFields: Readonly<Record<string, boolean>>;
  /** componentName -> CTRM field name, shown in the tooltip so an ambiguous label is resolvable. */
  protected readonly fieldCtrmNames: Readonly<Record<string, string>>;
  /**
   * Fields the user may not type into: CTRM's 38 refused ones, plus whatever the market cascade is
   * deciding right now (#201).
   *
   * 🔴 **The cascade's half is dynamic and the other half is not**, which is why this became a
   * computed. `price_market_code` is CTRM's to assign under price types `P`, `U` and blank
   * (`wnr051e:5157-5166`) and the *user's* under `D`/`V`, so a control that is locked on one contract
   * is editable on the next — and locking it unconditionally would stop a deferred contract from
   * being priced at all.
   */
  protected readonly readOnlyFields: import("@angular/core").Signal<Readonly<Record<string, boolean>>>;
  /**
   * The active tab, from the `tab` query parameter.
   *
   * 🔴 **In the URL, not in a signal, and that is this repository's own rule rather than a preference.**
   * docs/02 §1.3 asks every route to be addressable and refresh-proof, and the home workspace was
   * rebuilt to put its filters, sort and page in the query string for exactly this reason. A tab held
   * only in component state would mean a refresh silently returns you to Contract Info, a link to "the
   * shipping fields of this contract" cannot be sent, and the browser Back button does nothing after
   * three tab clicks.
   *
   * ⚠ Read through `toContractTabId`, which narrows an unknown value to `contract` rather than
   * rendering an empty screen. `?tab=nonsense` is a hand-edited URL, a stale bookmark, or a renamed
   * tab — none of which should produce a record with no fields on it.
   */
  private readonly tabParam;
  /**
   * The tabs to render — **from the resolved configuration, with the layout constant as fallback**
   * (ADR-17 D7).
   *
   * This is what retires the legacy app's hard-coded per-location tabs: its BIO tab was an
   * `If(location = 4090)` conditional in the template, and here it is a location-dimension
   * configuration row whose `tabs[]` differs. Hidden tabs are dropped rather than rendered disabled —
   * a tab a trade unit does not use should not be on its screen at all.
   *
   * 🔴 **And a tab whose every section has been hidden is dropped too** (F8.3, ruled 2026-09-24).
   * This used to filter on `tab.visible` alone, so hiding the last section on a tab left the tab
   * rendering with nothing on it — the administrator had turned the content off and the shell
   * stayed. {@link tabsAfterCascade} is shared with the admin preview so the two cannot disagree,
   * and it carries the Remarks guard: a tab the layout never gave sections to is left alone.
   */
  protected readonly configuredTabs: import("@angular/core").Signal<readonly ContractTab[]>;
  /**
   * The active tab, narrowed against the **resolved** tab set.
   *
   * 🔴 **Not against the `CONTRACT_TABS` constant**, which is the subtle half: a `?tab=shipping`
   * bookmark for a trade unit whose configuration hides Shipping would otherwise select a tab with
   * no sections on it and render an empty record. An unknown or now-hidden tab falls to the first
   * visible one.
   */
  protected readonly activeTab: import("@angular/core").Signal<ContractTabId>;
  /**
   * The tab strip, with the count of what is on each one.
   *
   * The count is fields plus collections, so a tab never reads as empty when it carries a grid — the
   * Remarks tab has **no fields at all** (remarks and notes are CTRM collections, not `base_data`
   * scalars) and would otherwise show `0` beside two populated tables.
   */
  protected readonly tabs: import("@angular/core").Signal<{
    count: number | null;
    current: boolean;
    id: ContractTabId;
    label: string;
  }[]>;
  /**
   * Which tab each section belongs on, by section id — **from the resolved configuration**.
   *
   * A `computed` rather than a constant map, because section→tab assignment is configuration now
   * (D7): the same section can sit on different tabs for different trade units. The layout's own
   * assignment is the fallback, which is what keeps the offline harness and the
   * configuration-unavailable path rendering a sensible screen.
   */
  private readonly tabOfSection;
  /**
   * Section ids on the active tab — what the form is told to render.
   *
   * 🔴 **Derived from the CONFIGURATION's sections, not from the layout constant, and an unrecognised
   * section falls through to the first tab rather than disappearing.**
   *
   * The first version of this filtered `CONTRACT_LAYOUT_SECTIONS` directly and produced a screen with
   * **no fields at all** the moment the two disagreed. They agree in production — `buildConfig` sets
   * each section's `componentName` from the layout's `id` — and they do not agree for
   * `MockFormConfigSource`, the offline harness whose section names predate the shared layout. So the
   * naive version worked in the app and rendered an empty record everywhere else, which is the wrong
   * way round for a defect to behave.
   *
   * Failing open is the deliberate choice: a field on the wrong tab is findable and a field on no tab
   * is not, and a configuration this screen does not recognise is exactly the case where losing fields
   * silently would be worst. That also means F2.1's eventual payload cannot hide a section by naming it
   * something new.
   */
  protected readonly visibleSections: import("@angular/core").Signal<readonly string[]>;
  /** The tab a section renders on. Unknown sections land on the first tab — see `visibleSections`. */
  private tabFor;
  /**
   * Which collections belong to the active tab.
   *
   * Ship periods sit with the shipping fields and prices with the pricing fields, which is where the
   * Power App puts them (its `Ship Period` component is inside `Shipping Info`) and what removes the
   * long tail this screen used to have — the grids were after all 111 fields, which was the specific
   * complaint. Remarks and notes get the tab named after them.
   */
  protected readonly showShipPeriods: import("@angular/core").Signal<boolean>;
  protected readonly showPrices: import("@angular/core").Signal<boolean>;
  protected readonly showRemarks: import("@angular/core").Signal<boolean>;
  /**
   * Field count per tab, plus one per collection the tab carries.
   *
   * Counted off the **configuration** for the same reason `visibleSections` filters it: the badge has to
   * agree with what the tab actually shows, and a count taken from the layout would keep saying 63 on a
   * configuration that renders something else entirely.
   *
   * 🔴 **Invisible fields are excluded** (JFrisbie, 2026-09-08), because as of the same change the form
   * no longer renders a cell for them: counting them would make a tab read "64" while showing 60, which
   * is the disagreement this count was written to avoid in the first place.
   *
   * ⚠ **Configuration visibility only.** A field hidden by a *rule* at runtime still counts here — that
   * state lives in the form engine's `EffectiveFieldState`, which this page does not have and should not
   * reach for (it would mean lifting the whole rules pipeline onto the page to render a badge). So the
   * badge is exact for the configured case, which is the one an admin controls, and can over-count by
   * however many fields a rule hides. Worth knowing before treating the number as authoritative.
   */
  private countFor;
  /**
   * Query parameters for a tab link: the tab, and whatever else the URL already carried.
   *
   * `returnTo` has to be preserved or clicking a tab would quietly discard the journey back to the
   * grid — the breadcrumb would still work and would land on an unfiltered workspace, which is the
   * failure the `returnTo` parameter exists to prevent in the first place.
   */
  protected paramsForTab(tab: ContractTabId): Record<string, string>;
  /**
   * Where **Edit contract** goes, carrying the tab.
   *
   * So opening the shipping fields, pressing Edit and pressing Cancel returns you to the shipping
   * fields rather than to Contract Info. A record screen that resets its own position on every mode
   * change is the thing that makes a tabbed form annoying to use.
   */
  protected readonly editParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * Query parameters for **Cancel**, which is not the same as Edit's.
   *
   * An edit cancels back to this record and should land on the tab it was editing, so it carries the
   * tab. A create cancels to the **workspace**, where a `tab` parameter means nothing — it would sit in
   * the grid's URL as noise, and the grid packs its own state into `returnTo`, so a stray parameter
   * there is the sort of thing that gets copied into a shared link and then has to be explained.
   */
  protected readonly cancelParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * CTRM's quantity breakdown as KPI cards (JFrisbie, 2026-09-15 — UX brief item 3).
   *
   * These were label/value pairs in a flex row, which read as six captions rather than as the six
   * numbers a trader opens a contract to see. They are among the most important values on the page
   * and were the most visually understated.
   *
   * 🔴 **The unit travels with the number, and that is a defect fix rather than decoration.** They
   * rendered as bare figures, and this project has the receipts: CTRM stores `SCW227620`'s quantity as
   * **105,280,000 pounds** where the API returns **1,880,000 bushels** — a factor of 56 — and the
   * 2026-09-02 DB2 verification recorded the missing unit as *"worth fixing"* on a grain contract at
   * that moment. A bare number invites the reader to supply the wrong unit.
   *
   * ⚠ **`accent` is a thin left border, and the VALUE stays neutral on purpose.** The brief offers
   * colour-coding as optional; a coloured *number* reads as a status, and these are quantities — a
   * settled figure of 0 is not "good" and an open figure is not "bad". Colour here separates the cards
   * at a glance without asserting a judgement the data does not carry. That is the same correction the
   * workspace grid's row tints already took, where a solid band *"competed with the status pill that
   * says the same thing in words"*.
   */
  /**
   * The contract date for the header, in the unambiguous form (UX brief item 1).
   *
   * ⚠ `formatContractDate`, never the grid's `formatShortDate`. The short numeric form is a *grid
   * density* decision — `08/21` and `21/08` are indistinguishable for the first twelve days of any
   * month and this application is read in the US and Canada — and its own remarks say not to propagate
   * it to screens that are not width-constrained. This header is not.
   */
  protected readonly contractDateLabel: import("@angular/core").Signal<string | null>;
  /**
   * The trader, as `GME — GISSELLE M. ESTEVEZ` where CTRM supplies both.
   *
   * ⚠ **Never fabricates the half it does not have.** CTRM derives the full name from the initials and
   * returns it on the aggregate; on a contract where it holds no name this renders the initials alone
   * rather than inventing an expansion. Same rule as the customer, one field along.
   */
  protected readonly traderLabel: import("@angular/core").Signal<string | null>;
  protected readonly quantityBreakdown: import("@angular/core").Signal<{
    label: string;
    value: number | null;
    uom: string | null;
  }[]>;
  /**
   * The status pills, using the grid's own mapping so the two screens cannot disagree.
   *
   * Rendered in every mode, including create, where every stage is unset. That is deliberate: the
   * screen keeps its shape, and {@link pendingNote} says why the pills are empty rather than leaving
   * six blanks that read as a failed load.
   */
  protected readonly confirmations: import("@angular/core").Signal<{
    label: string;
    badge: GridBadge | null;
    style: {
      chip: string;
      dot: string;
      text: string;
    };
    emptyNote: string | undefined;
  }[]>;
  /**
   * What an empty section means on a create.
   *
   * One string, used everywhere a collection or a derived value is empty because the contract does not
   * exist yet. Stated rather than left blank: six empty boxes on a create screen read as "failed to
   * load", which is the exact ambiguity the record screen's `Not set — <reason>` text exists to kill.
   */
  protected readonly pendingNote = "available once the contract is saved";
  /**
   * The sort chain for each sub-grid, held separately so sorting one leaves the other alone.
   *
   * **These sorts are complete, unlike the contract grid's.** The home grid pages — it holds 50 of 880
   * rows, so a client-side sort orders the page and has to say so. These collections arrive *whole* on
   * the aggregate: CTRM caps ship periods at 12 (BR-020…BR-023) and the prices come with the contract.
   * So sorting in the browser here orders every row there is, and needs no caveat and no server
   * parameter.
   */
  protected readonly shipPeriodSorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  protected readonly priceSorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  protected readonly sortedShipPeriods: import("@angular/core").Signal<readonly ContractShipPeriod[]>;
  protected readonly sortedPrices: import("@angular/core").Signal<readonly ContractPrice[]>;
  /** Copies before sorting: the rows belong to the loaded response, which nothing here may reorder. */
  private sortCollection;
  /**
   * Ship periods as a C8 grid.
   *
   * docs/02a §3 names ship periods and price sequences as C8 consumers, so this is the documented
   * pattern rather than a second table implementation — and it means both sub-tables inherit column
   * resizing and cell-level `Ctrl+C` copy for free.
   */
  protected readonly shipPeriodColumns: readonly GridColumn<ContractShipPeriod>[];
  protected readonly priceColumns: readonly GridColumn<ContractPrice>[];
  /** Underscored wire names read badly in a sentence; the `title` keeps the real one. */
  protected readable(name: string): string;
  protected readonly save: import("@angular/core").WritableSignal<SaveState>;
  /** The built form, handed over by the child so this page can read values and validity. */
  private form;
  /**
   * Confirms the Customer id when its field loses focus (F4.3b — docs/02 §2.3).
   *
   * A confirmation, not a picker: the customer master has 123,155 rows, so the screen answers "who
   * is this account" for the id the user typed and offers nothing to browse. The outcome becomes the
   * field's note through {@link fieldNotes}, and a resolved name is seeded into the read-only
   * Customer name field.
   *
   * 🔴 **View mode never looks up, and a blank id never looks up.** Both are controls in the spec.
   * The same id is not asked about twice in a row, and an answer that arrives after the id has
   * changed again is dropped rather than shown against the wrong id.
   */
  protected onFieldBlur(componentName: string): void;
  protected onFormReady(form: ContractForm): void;
  /**
   * The special type as the SpecialType control holds it, or `undefined` when the configuration
   * gives this trade unit no such control.
   *
   * ⚠ Read from the control rather than the loaded values so the section follows the user: choosing
   * `MNC` on a create, or changing the type on an edit, shows or hides the section at once.
   */
  private readonly liveSpecialType;
  private watchSpecialType;
  /**
   * The Family B field set this contract's special type selects, or `null` (criterion 2).
   *
   * 🔴 `null` for every special type off the list, blank included, and the section renders on
   * nothing else. With no SpecialType control the loaded CTRM value decides, so a trade unit whose
   * configuration hides the field still gets the section its contracts need.
   */
  protected readonly addendumFieldSet: import("@angular/core").Signal<AddendumFieldSet | null>;
  /**
   * The Addendum section sits on the tab that carries the special type, because that is the field
   * that summons it. From the configuration first and the layout second, like every other tab lookup.
   */
  private readonly addendumTab;
  protected readonly showAddendum: import("@angular/core").Signal<boolean>;
  /** The trade unit the contract belongs to, for templates restricted to some trade units. */
  protected readonly addendumTradeUnit: import("@angular/core").Signal<string | null>;
  private readonly markets;
  /**
   * The built form as a signal, so the cascade can read its live values.
   *
   * ⚠ A second handle on the same object rather than a replacement for {@link form}, which a dozen
   * call sites read synchronously during a save. Narrowing that to a signal read would be a wider
   * change than this one needs.
   */
  private readonly builtForm;
  /**
   * What the cascade reads  snapshotted from the controls, not from the engine's value signal.
   *
   * =4 **`ContractForm.value` does not see a control seeded with `emitEvent: false`, and this screen
   * seeds every one of them that way.** `FormBuilderService` sets its value signal once at build time
   * and thereafter only from `valueChanges`; the record screen's prefill runs *after* the build and
   * suppresses the event deliberately, so that the value can be told apart from one the user typed.
   * The consequence is that `form.value()` reports an empty form for an existing contract  measured,
   * not assumed: every fact came back `null` while the rendered inputs held the contract's values.
   *
   * � **That is wider than this cascade**  the rule engine reads the same signal, so BR-003's price
   * blanking and BR-005's requiredness are evaluating against an empty form on a loaded record too.
   * Raised rather than fixed here: changing what the engine's value signal reflects is a change to
   * every rule on both screens, and it belongs with the lane that owns the engine.
   */
  private readonly cascadeFacts;
  /**
   * Keeps {@link cascadeFacts} in step with the controls.
   *
   * Seeded once from the built form  which is what makes a loaded contract cascade at all  and then
   * updated on every value change, which is what makes it follow the user.
   */
  private watchCascadeInputs;
  /**
   * The Grain Factors market for this contract's location and commodity.
   *
   * ⚠ **`undefined` until both drivers are known**, which is the in-flight state rather than
   * "there is no market" — see `MarketCascadeInput.grainFactorsMarketCode`. A create form with no
   * commodity chosen yet has nothing to look up, and must not be told the Grain Factors file is empty.
   */
  private readonly grainFactorsMarketCode;
  /** The cascade's answer, recomputed on every relevant keystroke. */
  protected readonly cascade: import("@angular/core").Signal<MarketCascade>;
  /**
   * The months valid for the derived market — `reference/market-months`.
   *
   * ⚠ **Keyed on the cascade's market code, not the form's.** Under price types `P`, `U` and blank
   * CTRM overwrites what the form holds, so filtering on the form's copy would list the months of a
   * market this contract is not on.
   */
  private readonly marketMonths;
  /**
   * Writes the cascade's derived values back onto the form.
   *
   * 🔴 **Patched PRISTINE, and that is what keeps the save honest.** `dirtyValues()` is what the
   * update path sends, so marking a derived value dirty would push CTRM's own answer back at it as if
   * the user had typed it. On a full-replace upsert that is indistinguishable from an edit.
   *
   * ⚠ **`emitEvent: false` plus an equality guard, or this loops**: the patch would fire
   * `valueChanges`, which feeds {@link cascadeFacts}, which recomputes the cascade, which patches
   * again. The guard is what terminates it — the same one `FormBuilderService.applyValue` uses, and
   * for the same reason.
   *
   * ⚠ **Create mode is included deliberately.** #229 is that a create sends only dirty controls, so a
   * pristine derived value would be dropped from the payload — but the fix for that belongs to the
   * create path (send the full resolved set), not here. Marking these dirty to work around it would
   * make every *update* re-send CTRM's own derivation. Noted rather than duplicated.
   */
  private readonly applyCascade;
  /**
   * Issues a contract number once both prefixes are known, on create only.
   *
   * 🔴 **This cannot fire on page load, and that is a property of CTRM rather than a shortcut.** The
   * API requires `prefixType` and `prefixCommodity` — both single characters — and refuses the call
   * without them, deliberately: on this estate an omitted field means *"choose for me"*, so a
   * defaulted prefix would compose a perfectly valid number for the **wrong contract type**. A fresh
   * create form seeds only the trade unit, so at first paint neither prefix has a value and there is
   * nothing to compose a number from. The number therefore appears as soon as the form knows enough
   * to ask for the right one — which is the earliest moment it *can* be correct.
   *
   * ⚠ **Until C-16 is actioned this waits on a hand-typed CAK code.** `contract_prefix_commodity` is
   * the commodity's CAK group code, and `GET /reference/commodities` already returns
   * `CAKCommodityCode` on all 3,251 rows while `ReferenceItem` discards it (F-12, backend). Once the
   * prefix derives from the commodity the user already picks, this fires without anyone typing a code
   * they should not need to know.
   *
   * ⚠ **Gated on `pendingContractsEnabled`.** Reuse of that attribute is a decision, not an
   * accident: issuance *is* CTRM's PendingContracts API (03 §2.6 — "the pending record **is** the
   * reservation"), so a trade unit that does not use Pending has no business advancing the counter.
   * Its documented meaning is broader than this, though, so if the two ever need to diverge the answer
   * is a distinct `autoPopulateContractNumber` attribute — the three readings are recorded on #204.
   */
  private watchPrefixesForNumber;
  /**
   * Issues at most one number per journey.
   *
   * ⚠ **The guard is set BEFORE the request, not in its callback.** Both prefix controls emit, and a
   * paste or a programmatic patch can emit twice in the same tick — so a guard set on success would
   * let two requests through and **spend two numbers**. There is no way to hand one back.
   */
  private issueNumberIfReady;
  /** A control's value when it is exactly one non-blank character, else null. */
  private singleCharacter;
  /**
   * Turns a failed issuance into something the user can act on.
   *
   * 🔴 **Three failures, three sentences.** Collapsing them into "could not get a number" would tell a
   * user with no entitlement to keep retrying, and would hide a configuration fault that needs an
   * administrator rather than a user.
   *
   * 🔴 **The two status branches are tested FIRST and deliberately outrank the classified condition
   * (F3.1d).** They describe *this caller* and *this environment* — no entitlement, and issuance
   * simulated while writes are Live — so they are true regardless of what CTRM would have said about
   * the number, and they are the only two the user can do something structural about. A `403` that
   * fell through to a condition would tell someone who cannot issue at all to ask again for the next
   * number.
   *
   * Below them, the classified `condition` names which of CTRM's five refusals it was. An issuance
   * that carries no condition — today's server, or any body shaped differently — keeps the generic
   * sentence rather than being described as `'unknown'`, because those are different facts.
   */
  private numberIssueMessageFor;
  /** The issued number, held outside the form so a rebuild re-applies it rather than re-requesting. */
  private readonly issuedNumber;
  /** Set before the request rather than after it, so two emissions cannot spend two numbers. */
  private hasRequestedNumber;
  /** Whether this trade unit autopopulates the number — see {@link watchPrefixesForNumber}. */
  private readonly tradeUnitPendingEnabled;
  private readonly numberIssue;
  /** Rendered on the create screen when a number could not be issued — never on view or edit. */
  protected readonly numberIssueFailure: import("@angular/core").Signal<string | null>;
  /**
   * Re-resolves the configuration when a driver field changes, carrying typed values across.
   *
   * 🔴 **The rebuild is what makes this dangerous, and why it snapshots first.** The form seeds once
   * in `ngOnInit`, so a new configuration means a new form — and a naive rebuild discards everything
   * typed and resets the `dirty` flags the save path reads, which is the same trap the tab
   * implementation hit and is pinned by *"should NOT discard a typed edit when the tab changes"*.
   * Here it cannot be avoided the way tabs avoid it (a display filter): a different configuration is
   * genuinely a different set of controls. So the values are snapshotted out of the old form and
   * re-applied to the new one **as dirty**, which is what keeps them in the save payload.
   *
   * The carried values ride in through `defaultValues`, which marks what it applies dirty and skips
   * controls that already hold something — exactly the semantics needed, and already tested.
   */
  private watchDrivers;
  private lastTextCode;
  private lastCommodity;
  private readonly destroyRef;
  /**
   * Values typed before a driver change, re-applied to the rebuilt form as dirty.
   *
   * Merged over the screen's own defaults rather than replacing them, so a carried value wins where
   * both have an opinion — the user's typing outranks a default.
   */
  private readonly carried;
  /** Every dirty control's value, keyed by component name. */
  private dirtyValues;
  /**
   * A key that changes when the resolved configuration does, so the form is rebuilt against it.
   *
   * Rebuilding is unavoidable here — see {@link watchDrivers} — and this is how the template forces
   * it: `@for (key of [formKey()]; track key)` around the form. Keyed on the configuration's own
   * version rather than on a counter, so a re-resolve that returns the *same* configuration does not
   * churn the form (a driver change that does not change which row wins is common: most contracts
   * resolve to the same global default).
   */
  protected readonly formKey: import("@angular/core").Signal<string>;
  /**
   * Which provenance to show, and only when there is something to say.
   *
   * A muted line rather than a banner: it is the admin's debugging thread — the thing that answers
   * "why is this field required here and not there?" — and it is noise to a trader. The
   * defaults-only case IS worth a visible warning, and that is separate (see the template).
   */
  protected readonly provenanceLabel: import("@angular/core").Signal<string | null>;
  /** True when the configuration could not be resolved and the screen is on layout defaults. */
  protected readonly configDefaultsOnly: import("@angular/core").Signal<boolean>;
  protected retry(): void;
  /**
   * Re-read this contract — the header's refresh, view mode only.
   *
   * Bumping `attempt` re-issues **both** reads this screen makes, the aggregate and
   * `GET /contracts/{n}/fields`, which is what a refresh has to mean here: the two are merged into one
   * view and re-reading only the typed half would leave 70-odd fields showing values from the previous
   * read, with nothing on screen saying they disagree.
   *
   * Shares {@link reissue} with Retry for the same reason the workspace does — they are two
   * affordances on one behaviour, and a second copy is how one of them later grows a difference.
   *
   * ⚠ The form is seeded once from the values that arrive, so a refresh mid-edit would fight whatever
   * is typed. That is not guarded here because it cannot happen: the button is only rendered in view
   * mode. If it is ever offered while editing, it needs the dirty-value question answered first.
   */
  protected refresh(): void;
  /** A read is in flight — spins the refresh icon and refuses a second press. */
  protected readonly isRefreshing: import("@angular/core").Signal<boolean>;
  /** The single input to both reads besides the contract number. */
  private reissue;
  /**
   * Whether the signed-in caller may write at all — `Admin`, matching the API's own gate (#155).
   *
   * ⚠ **Not the same question as whether the screen may be READ.** Reads are deliberately not
   * admin-gated and not trade-unit scoped (correction C-14), so this must gate the *button* and
   * never the screen. Hiding the record from a `User` would be a regression, not a stricter fix.
   */
  /**
   * F1.4 — the availability half of the write gate.
   *
   * Root-provided, so this is the same instance the shell's banner reads. The two must agree: a
   * banner saying CTRM is closed beside an enabled Save is worse than either failure alone.
   */
  private readonly availability;
  /**
   * 🔴 **TWO independent gates, and both must be open.** The permission gate asks whether this
   * caller may write; the availability gate asks whether CTRM will accept a write from anyone. They
   * fail for different reasons and are fixed by different people, so they are `&&`-ed here rather
   * than folded into one flag — and the screen says which one is closed.
   *
   * ⚠ `writesBlocked()` is true under `Unknown`, which is the case this gate exists for: not knowing
   * whether CTRM is accepting work is not the same as it being fine (correction C-7).
   */
  protected readonly canWrite: import("@angular/core").Signal<boolean>;
  /**
   * Whether the caller may make a write that lands only in **CWS's own SQL** (#485) — Save as a
   * template, today.
   *
   * 🔴 **Permissions only, never the availability gate.** The gate is for CTRM writes: a night run or
   * a closed CTRM says nothing about whether CWS can store a template, and the ruling on #485 keeps
   * those writable. Reading {@link canWrite} here made the template panel tell an Admin they "need
   * the Admin role" whenever CTRM was closed.
   */
  protected readonly canWriteCws: import("@angular/core").Signal<boolean>;
  /** Whether the write refusal is CTRM's rather than the caller's, so the screen says the right thing. */
  protected readonly blockedByAvailability: import("@angular/core").Signal<boolean>;
  /** The banner's own title, so the reason under Save names the same state the banner does. */
  protected readonly availabilityTitle: import("@angular/core").Signal<string>;
  /**
   * Optional, so a host that mounts this screen without the action gets a screen with no Close
   * button rather than an injection failure. The shell always provides it.
   */
  private readonly contractState;
  /** The sentence the confirmation must carry. */
  protected readonly closeProvenanceWarning = "closing rewrites pricing-approval provenance and cannot be undone";
  /**
   * The re-read the close/re-open route answered, which supersedes the loaded aggregate.
   *
   * 🔴 **Keyed on the contract number when it is read, not merely stored.** An override left behind
   * by one contract and applied to the next would tell the user a different contract's state — and
   * under a screen that can navigate between records without remounting, that is reachable rather
   * than theoretical.
   */
  private readonly stateOverride;
  protected readonly stateAction: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "working" | "failed";
    readonly message?: string;
  }>;
  /** Whether the contract is closed, as the server last reported it. */
  protected readonly isClosed: import("@angular/core").Signal<boolean>;
  /** Whether either action may be offered at all. */
  protected readonly canChangeState: import("@angular/core").Signal<boolean>;
  /** Optional: a host without templates gets a screen without the actions. */
  private readonly templates;
  protected readonly templateName: import("@angular/core").WritableSignal<string>;
  protected readonly templateState: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "saving" | "failed" | "saved";
    readonly message?: string;
  }>;
  private readonly templateReload;
  /** The trade unit's templates. Re-read after a save so a new one is immediately selectable. */
  private readonly templateList;
  protected readonly availableTemplates: import("@angular/core").Signal<readonly ContractTemplate[]>;
  protected readonly templatesFailed: import("@angular/core").Signal<boolean>;
  protected readonly canUseTemplates: import("@angular/core").Signal<boolean>;
  protected readonly canSaveTemplate: import("@angular/core").Signal<boolean>;
  protected onTemplateNameInput(value: string): void;
  /**
   * Saves the contract on screen as a template.
   *
   * 🔴 **The FULL resolved set, not the fields somebody edited.** A template built from dirty controls
   * alone carries whatever happened to be touched and drops everything the form resolved — which is
   * the defect recorded against create-from-template, where a fix for one field generalised to forty.
   * {@link resolvedValues} therefore reads every writable control regardless of dirtiness.
   *
   * ⚠ Read-only fields are excluded by iterating the writable set: `upsertContract` refuses those 38,
   * so a template carrying one would produce a rejection on every contract created from it.
   */
  protected onSaveTemplate(): void;
  /**
   * Applies a template to the create form.
   *
   * 🔴 **Through `seed`, and across the FULL set the template carries.** The payload is keyed by CTRM
   * field name — the same names everything else on this wire uses — so it is mapped back to component
   * names here. A key the layout does not know is skipped rather than seeded blindly: the server owns
   * the exclusion list and may drop or add fields, and seeding an unknown control name silently does
   * nothing while looking like it worked.
   */
  protected onApplyTemplate(templateId: string): void;
  protected readonly appliedTemplate: import("@angular/core").WritableSignal<string | null>;
  /**
   * Every writable control's current value, keyed by CTRM field name.
   *
   * Deliberately NOT {@link payloadFor}: that one sends only what changed on an edit, which is right
   * for a full-replace upsert and wrong for a template, where the point is to capture the whole
   * contract as it stands.
   */
  private resolvedValues;
  /** Optional: a host without a log backend gets a screen with no Log tab. */
  private readonly logSource;
  /**
   * Whether the Log tab has anything to put on it.
   *
   * ⚠ **Either source will do, and that is a correction rather than convenience.** The tab first
   * required a log source, which made Save-as-template unreachable for a host that offered templates
   * and no audit backend — a coupling between two unrelated capabilities, found by a test that
   * provided one and not the other. The tab carries what the contract *records*: its history, a note,
   * a message about it, and a template taken from it.
   *
   * Absent on a create either way: there is no contract yet to have a history, and nothing saved to
   * take a template from.
   */
  protected readonly canReadLog: import("@angular/core").Signal<boolean>;
  protected readonly showLog: import("@angular/core").Signal<boolean>;
  /**
   * Optional: a host without a documents source gets a screen with no Documents tab, and the
   * embedding host's provider list does not change. The shell provides it on the record ROUTES,
   * not in `app.config.ts`, so the HTTP source stays out of the initial bundle.
   */
  private readonly documentsSource;
  /** Only for an existing contract, never on a create. */
  protected readonly canReadDocuments: import("@angular/core").Signal<boolean>;
  protected readonly showDocuments: import("@angular/core").Signal<boolean>;
  /** Whether the audit backend is present, which the history, Add Note and Notify Trader all need. */
  protected readonly logAvailable: import("@angular/core").Signal<boolean>;
  /**
   * The contract's audit trail.
   *
   * Re-read when {@link attempt} moves, so Refresh reloads the history with the record rather than
   * leaving a timeline that predates whatever the user just did.
   */
  private readonly auditTrail;
  /**
   * The timeline: contract audit rows and form-configuration changes in one list, newest first.
   *
   * 🔴 **The two are interleaved rather than shown side by side**, because the question a reader has
   * is *"why does this contract look like this?"* — and a configuration change that altered the form
   * is part of that answer. They stay distinguishable by `kind`, so nobody reads a configuration edit
   * as somebody having changed the contract.
   */
  protected readonly timeline: import("@angular/core").Signal<readonly TimelineRow[]>;
  protected readonly timelineState: import("@angular/core").Signal<"loading" | "loaded" | "idle" | "error">;
  /**
   * The Log tab's badge: how many entries the timeline shows (#567).
   *
   * It used to go through `countFor`, which counts visible FIELDS, so a tab with none read `Log 0`
   * above its own entries. ⚠ **No badge until the history has loaded.** A `0` during a failed read
   * would claim the contract has no history, which is exactly what the failure banner says we cannot
   * know.
   */
  private readonly logCount;
  /**
   * The label a changed field is shown under on the Log tab (#567): the one the form shows it
   * under, then the layout's, then CTRM's own name. The last is still worth showing, because a
   * field this layout does not render can still be changed by a write and the user can recognise it.
   */
  private labelForCtrmField;
  /** The form-configuration audit rows, when the bundle carried any. Empty is the honest default. */
  private readonly configAudit;
  protected readonly noteText: import("@angular/core").WritableSignal<string>;
  protected readonly noteBytesRemaining: import("@angular/core").Signal<number>;
  /**
   * Why this note cannot be saved, or `null`.
   *
   * 🔴 **Refused before sending, not after.** CTRM stores an oversized note perfectly well; it is
   * `getContract` that then returns ZERO notes for the whole contract. A save that "succeeded" and
   * silently emptied the note history would be found much later by somebody looking for a note that
   * is still there and no longer readable.
   */
  protected readonly noteRefusal: import("@angular/core").Signal<string | null>;
  protected readonly noteState: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "saving" | "failed" | "saved";
    readonly message?: string;
  }>;
  protected onNoteInput(value: string): void;
  /**
   * 🔴 **Whether the notes we read can be trusted to be all of them.**
   *
   * `getContract` answers `200` with an EMPTY notes array whenever reassembly overflows — one note
   * over 4,000 bytes voids the whole cursor — and says so only in a response header, which the API
   * surfaces as a warning on the aggregate. Adding a note is a **full replace** of the collection, so
   * appending to an array we believe is empty would delete every note CTRM actually holds, and CTRM
   * would answer `202`.
   *
   * ⚠ **The API's own guard does not cover this path, deliberately.** It refuses a write that *relies*
   * on the merge base, but lets a caller that supplies `notes` through — because that is the only
   * route by which an unreadable note could be repaired. Supplying `notes` is exactly what Add Note
   * does, so the refusal has to be here.
   */
  protected readonly notesAreComplete: import("@angular/core").Signal<boolean>;
  protected readonly canAddNote: import("@angular/core").Signal<boolean>;
  protected onAddNote(): void;
  protected readonly notifyText: import("@angular/core").WritableSignal<string>;
  protected readonly notifyState: import("@angular/core").WritableSignal<{
    readonly status: "idle" | "sending" | "failed" | "accepted";
    readonly message?: string;
  }>;
  protected readonly canNotify: import("@angular/core").Signal<boolean>;
  protected onNotifyInput(value: string): void;
  protected onNotifyTrader(): void;
  protected onCloseContract(): void;
  protected onReopenContract(): void;
  /**
   * Confirms, calls, and renders what came back.
   *
   * 🔴 **The response replaces the rendered contract; nothing is flipped optimistically.** Every CTRM
   * write answers `202` regardless of outcome (correction C-4), so the action completing is not
   * evidence it happened — the re-read the route returns is. A screen that toggled its own flag would
   * show "Closed" for a close CTRM refused, which is the exact failure the `202` convention creates.
   */
  private changeState;
  /**
   * Whether Save may be pressed. Kept separate from the click handler so the template can bind it.
   *
   * 🔴 `canWrite()` is part of it because the two ends disagreed otherwise: the form was editable by
   * any assigned CWS user while `CwsContractWriter` accepts **`Admin` alone**, so a `User` could fill
   * all 104 writable scalars and learn it could not save only on pressing Save — a `403` against real
   * CTRM on QA, where `ContractWrites=Live` (#155).
   */
  protected readonly canSave: import("@angular/core").Signal<boolean>;
  /**
   * Collects the changed controls and sends them.
   *
   * **`dirty` is the discriminator, not "has a value".** A control the user never touched is pristine
   * even when it holds a prefilled value, so it stays out of the payload and CTRM's own stored value
   * survives the merge untouched. Reading "has a value" instead would re-send all 111 fields on every
   * save, which is how a lossy numeric gets rewritten (Known Issue 17) and how a value CMS displayed
   * imperfectly becomes the value CTRM holds.
   *
   * ⚠ **It refuses outright in view mode.** The template renders no Save button there, so this is a
   * second lock rather than the only one — and worth having, because the form is now built in view
   * mode too, which it never used to be.
   */
  protected onSave(): void;
  /**
   * The values to send, and the two modes send DIFFERENT sets — #229.
   *
   * | mode | sends | why |
   * |---|---|---|
   * | create | every writable control, pristine included | there is nothing at CTRM to preserve |
   * | edit | dirty controls only | `upsertContract` is a FULL REPLACE over the raw aggregate |
   *
   * ### 🔴 Why widening edit would be a data-loss bug rather than a tidier rule
   *
   * The update path merges what it is sent onto CTRM's **raw** `base_data` (ADR-4), so a field the
   * user did not touch keeps CTRM's own value by being absent. Sending every control instead would
   * push this screen's copy of all 104 writable fields back at CTRM — including the ones it read
   * through a lossy conversion. `quantity` reads at five decimal places and writes at two, so an
   * untouched quantity would be re-sent rounded, accepted, and stored DIFFERENT, with a `202` and no
   * message (Known Issue 17). That is the silent-rewrite class, caused by us.
   *
   * ### 🔴 And why create had to widen
   *
   * A create has no merge base. Anything patched pristine never reached CTRM at all: the prefilled
   * contract number, a template's defaults, and the market codes the cascade derives — all visible on
   * screen, none of them sent. The contract number is the sharpest, because CTRM would then issue a
   * different one and the user would have watched a number they were never given.
   *
   * ⚠ **NOT fixed by marking those values dirty**, which was the obvious route and is the wrong one.
   * Six derived descriptions sit on CTRM's `ConfirmChg` list, so a spurious edit re-confirms the
   * contract — a new confirmation version, and a document reissued to the counterparty.
   *
   * ⚠ Read-only fields are excluded by iterating {@link CONTRACT_WRITABLE_FIELDS} rather than the
   * layout: `upsertContract` REFUSES those 38 rather than ignoring them, so one in the payload turns
   * a good save into a rejection the user cannot act on.
   */
  private payloadFor;
  /**
   * CTRM field name to the tab its control sits on, built once from the layout.
   *
   * ⚠ **Derived from the layout rather than hand-listed**, so a field that moves between tabs cannot
   * leave a refusal pointing at the tab it used to be on — which would badge the wrong tab and focus
   * nothing, while looking entirely correct.
   */
  private readonly tabByCtrmField;
  /**
   * How many refusals landed on each tab, for the badge.
   *
   * ⚠ Counts only the fields this layout HAS. A refusal naming something the screen does not render
   * cannot be badged anywhere and stays in the summary — see {@link unmappedErrors}.
   */
  protected readonly errorsByTab: import("@angular/core").Signal<ReadonlyMap<string, number>>;
  /**
   * Refusals naming a field this screen does not render.
   *
   * 🔴 **Kept visible rather than dropped.** CTRM validates 109 fields and this layout renders 111
   * rows, but the sets are not identical — and a refusal the screen silently swallowed would leave
   * the user with a save that failed for no stated reason. The summary is where these live.
   */
  protected readonly unmappedErrors: import("@angular/core").Signal<readonly {
    field: string;
    reasons: readonly string[];
  }[]>;
  /**
   * Everything that addresses no control: the API's own `formErrors`, plus the refusals whose
   * `invalid_params[].name` is not a field name at all (F2.4, #373).
   *
   * 🔴 **The second half is the fix.** CTRM answers with procedure names and composites
   * (docs/04 §8.2), and the API's `CtrmFieldError.IsFieldName` — which decides what reaches
   * `errors` rather than `formErrors` — rejects only `*`, names containing `:` and names starting
   * with `sp`, and documents itself as *"a weak heuristic on purpose … not to be authoritative"*.
   * So `getContract` and `ContractProcedure` arrived in `errors` and this screen rendered them in
   * the summary under a bolded field name, inventing a field and sending the user to look for it.
   *
   * ⚠ **Appended rather than merged into `formErrors`**, so the API's own form-level text keeps its
   * order and reads first. Nothing is dropped on either path — `classifyInvalidParams` returns every
   * input in exactly one of its three sets, which is the documented fallback F2.4 asks for.
   */
  protected readonly formLevelReasons: import("@angular/core").Signal<readonly string[]>;
  /** Refusals this screen can point at, in layout order so the summary reads down the form. */
  protected readonly mappedErrors: import("@angular/core").Signal<readonly MappedFieldError[]>;
  /**
   * Puts each refusal on its own control, switches to the first one and focuses it.
   *
   * 🔴 **The tab switch is the half that matters.** The screen has four tabs and a refusal names a
   * field that is very likely not on the one being looked at — the old summary said so in its own
   * words, admitting the field "may be on a tab you are not looking at". A message the user has to
   * go hunting for is barely better than no message.
   *
   * ⚠ **Marked touched as well as errored.** `DynamicFieldComponent` holds its message back until a
   * control has been touched, deliberately — otherwise a blank form shouts at every empty field on
   * first paint. A server error set on an untouched control would be stored and never rendered.
   */
  private applyFieldErrors;
  /**
   * Switches to a field’s tab and puts the caret in it.
   *
   * ⚠ **The focus is deferred to a microtask**, because the control is not in the DOM until the tab
   * switch has rendered. Focusing before that finds nothing and silently does nothing — which is the
   * failure that looks like the feature working, since the tab did change.
   */
  protected focusField(error: MappedFieldError): void;
  /**
   * The contract to show after a save, or `null` to stay on the form.
   *
   * A saved contract belongs on the record it just wrote, so the normal path leaves edit mode
   * immediately for `/contracts/{number}` — the same screen, inactive, showing the collections this
   * form cannot edit.
   *
   * 🔴 **It deliberately does NOT navigate when CTRM disagrees with what we intended.** The response
   * says which of upsert's two paths ran, and that discriminator is the only thing standing between a
   * silent mistake and a caught one (docs/04e — it is what demotes "upsert creates when the key does
   * not match" from unguardable to detective). An edit reporting `Created` made a new contract; a
   * create reporting `Updated` overwrote an existing one; `Unknown` means the wording was not
   * recognised and we cannot say which happened. Navigating away would replace that warning with a
   * record screen that looks entirely normal — which is exactly how the risk goes back to being
   * silent. Those cases stay put so the alert is read.
   */
  private destinationAfter;
  /**
   * **Escape goes where the breadcrumb goes** — the screen this record was opened from.
   *
   * The same destination *and the same query parameters* — so Escape restores the workspace's filters,
   * sort, page and focused row rather than dumping the user on an unfiltered grid. A shortcut that
   * lost the journey would be worse than no shortcut, because the breadcrumb beside it visibly does
   * the right thing.
   *
   * ⚠ **View mode only, and that is new.** Escape in edit or create mode would discard typed changes
   * with no confirmation, on a keystroke people press to dismiss things. The breadcrumb and Cancel are
   * both still there and both say what they do.
   *
   * ### Why the `defaultPrevented` guard is the whole design
   *
   * This is a *document* listener, so it fires wherever focus is. `DropdownDirective` also listens on
   * the document, and the shell's identity menu and trade-unit picker are both open-able from this
   * screen — so without the guard, pressing Escape to close a menu would close it **and** navigate off
   * the record. The directive marks the event handled when it actually dismissed something, and this
   * stands down when it sees that.
   *
   * ⚠ **This relies on the shell's listeners being registered before this one**, which holds because
   * the shell renders before the router activates a route into it. Document listeners on the same
   * phase fire in registration order, so the dropdown always gets first refusal. If a future overlay
   * is created *after* the routed component, it has to mark its own Escape handled too — that is the
   * contract, not the ordering.
   */
  private readonly drafts;
  /**
   * Whether anything would be lost by leaving.
   *
   * ⚠ **Mirrored from the form's own dirty flag rather than maintained independently.** Angular
   * already tracks it and the save path already reads it; a second, separately-computed copy is one
   * more thing that can disagree with the payload — which on this screen means prompting about work
   * that will not be sent, or worse, not prompting about work that will.
   */
  protected readonly isDirty: import("@angular/core").WritableSignal<boolean>;
  /**
   * The draft identity. Null while the screen has nothing to key on, and in view mode.
   *
   * 🔴 **The contract number is in the key, and it is the part that would do real damage without
   * it.** Restoring one contract's values onto another, under a full-replace upsert, writes the
   * first contract over the second — and every field would look deliberately filled in.
   */
  private readonly draftKey;
  /** A recoverable draft found on arrival. Cleared once restored or discarded. */
  protected readonly recoverableDraft: import("@angular/core").WritableSignal<{
    readonly at: string;
  } | null>;
  /** The time to show in the restore prompt, as the user reads a clock. */
  protected readonly recoverableAt: import("@angular/core").Signal<string | null>;
  /**
   * The router hook. Answers true unless leaving would lose something.
   *
   * ⚠ **Returns a plain true in the common case rather than an observable**, so an unguarded
   * navigation resolves without a microtask and stays exactly as immediate as it was before this
   * existed. Every route change on this screen goes through here — the breadcrumb, Cancel, the
   * shell's module nav and the browser Back button — which is what makes it one code path rather
   * than four handlers that can drift apart.
   *
   * 🔴 **A user who cannot save must not be prompted.** #155 hides Save for a non-admin, so anything
   * they typed was never going anywhere — asking them to confirm discarding it would be asking about
   * a loss that had already happened.
   */
  confirmNavigation(): Observable<boolean> | boolean;
  /**
   * The browser-native prompt, for the one exit the router cannot see.
   *
   * ⚠ **The wording is the browser's, not ours** — every current browser ignores the supplied string
   * and shows its own. Setting returnValue is the whole of the API that still works, which is why
   * this is a bare flag rather than a message worth composing.
   */
  protected onBeforeUnload(event: BeforeUnloadEvent): void;
  /** Restores a recovered draft onto the form, marked DIRTY because these were user edits. */
  protected restoreDraft(): void;
  /** Set by {@link reloadAfterUnknownSave}, so the leave guard neither prompts nor clears. */
  private leavingWithDraftKept;
  /**
   * **Reload, after a save whose outcome is unknown** (#556).
   *
   * Nobody knows whether CTRM applied the change, so the only safe next step is to look. An edit goes
   * to the record itself, which re-reads what CTRM holds; pressing Edit there offers this draft back,
   * so nothing typed is lost either way. A create has no record to look at yet, so it goes back to
   * where it was opened from, where the new contract will be if the create landed.
   *
   * 🔴 **The draft is written NOW rather than left to the debounce**, and the leave guard is told not
   * to ask. Its ordinary job is to offer "discard your changes?" and to clear the draft on yes, which
   * is precisely what this button promises not to do.
   *
   * ⚠ Navigation rather than a page reload: under an embedding host a `location.reload()` would
   * reload the host, and the host context is the one way this screen is allowed to move (E9).
   */
  protected reloadAfterUnknownSave(): void;
  /** Throws the recovered draft away, on the user's say-so. */
  protected discardDraft(): void;
  /** This create's idempotency key, minting it on first use (#557). */
  private keyForCreate;
  /** Writes the draft, carrying the create's key so a reload that restores it retries the same create. */
  private writeDraft;
  private clearDraft;
  /**
   * Offers a waiting draft, and keeps writing one as the user types.
   *
   * ⚠ **The offer is read BEFORE any write is wired**, or the screen would immediately overwrite the
   * draft it is about to offer with an empty one.
   *
   * ⚠ **Two subscriptions on purpose.** The write is debounced, because it runs on every keystroke
   * across 111 controls and serialising the dirty set is not free; the dirty flag is not, because the
   * guard and the Save button both read it and a 500 ms window in which a dirty form reports itself
   * clean is a window in which leaving loses work silently.
   */
  private watchDraft;
  /**
   * Opens the leave prompt.
   *
   * ⚠ **Injected in a field initialiser, not reached for inline.** The router invokes
   * confirmNavigation outside any injection context, so a helper that injected in its own body
   * would throw precisely when the form was dirty — the path least likely to be hit by accident.
   */
  private readonly confirm;
  private confirmLeave;
  protected onEscape(event: Event): void;
  private readonly host;
  constructor();
  /**
   * Registers this screen's keys.
   *
   * ### ⚠ Escape is deliberately NOT moved into the registry
   *
   * It stays an `@HostListener` above. Two reasons, and the second is the one that decides it:
   * its `defaultPrevented` guard is the documented contract the shell's dropdowns rely on and is
   * covered by a spec that must keep passing unmodified (criterion 5), and the registry calls
   * `preventDefault()` *before* running a handler — which would mark the event handled for every
   * listener downstream, changing behaviour the guard exists to preserve. It is listed in the
   * overlay as a legend-only shell entry instead, so a user still discovers it.
   *
   * ### 🔴 `allowInTextInput` is true on every binding here, and that is the point
   *
   * These are the keys a person presses **while typing**. A save shortcut that only worked after
   * clicking out of the field would be a save shortcut nobody uses — and all four carry `Ctrl`, so
   * none of them can be produced by ordinary typing.
   */
  private registerRecordShortcuts;
  /**
   * Saves, then returns to where the record was opened from.
   *
   * ⚠ **It does not navigate until the save has actually landed.** Leaving optimistically would drop
   * the user on a grid while a `202` was still outstanding — and on this estate a `202` says nothing
   * about the outcome, so a failure would have no screen left to report itself on.
   */
  protected saveAndClose(): void;
  /** Set by {@link saveAndClose}, read by the save subscription. */
  private closeAfterSave;
  /**
   * Moves focus to the next or previous **section**, crossing tabs at the ends.
   *
   * ### 🔴 Sections, not tabs, because that is what §4.2 asks for — and crossing at the ends is what
   * makes it honest
   *
   * This screen groups sections onto tabs, and every section of the active tab is on screen at once.
   * Stepping only within the tab would make `Ctrl+PgDn` stop dead at the last section with 60 more
   * fields one tab away, which reads as the key being broken rather than as a boundary.
   *
   * ⚠ **Focus goes to the section's first ENABLED control, not to the section box.** A heading is not
   * focusable, and scrolling a heading into view while focus stays where it was means the next
   * keystroke types into the field the user just left — the failure mode being avoided is silent.
   * Read-only view mode has no enabled control, so it falls back to scrolling the section into view.
   */
  private stepSection;
  private sectionHasFocus;
  private focusSection;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractRecordPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractRecordPageComponent, "cms-contract-record-page", never, {
    "contractNumber": {
      "alias": "contractNumber";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** One refusal, resolved onto the control and tab that can show it. */
interface MappedFieldError {
  readonly ctrmField: string;
  readonly componentName: string;
  readonly label: string;
  readonly tab: string;
  readonly reasons: readonly string[];
}
import { ADDENDUM_GENERATION_SOURCE, ADDENDUM_TEMPLATE_SOURCE, AvailabilityGate, CLOSE_PROVENANCE_WARNING, CONTRACT_DETAIL_SOURCE, CONTRACT_DOCUMENTS_SOURCE, CONTRACT_IDEMPOTENCY_KEY, CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT, CONTRACT_LAYOUT_EMPTY_NOTES, CONTRACT_LAYOUT_FIELDS, CONTRACT_LAYOUT_FIELD_NOTES, CONTRACT_LAYOUT_GROUP_HEADINGS, CONTRACT_LAYOUT_HALF_FIELDS, CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS, CONTRACT_LAYOUT_SECTIONS, CONTRACT_LAYOUT_SECTION_NOTES, CONTRACT_LAYOUT_WIDE_FIELDS, CONTRACT_LOG_SOURCE, CONTRACT_NUMBER_SOURCE, CONTRACT_READ_ONLY_FIELDS, CONTRACT_STATE_SOURCE, CONTRACT_TABS, CONTRACT_TEMPLATE_SOURCE, CONTRACT_WRITABLE_FIELDS, CONTRACT_WRITE_SOURCE, CUSTOMER_SOURCE, ContractFormComponent, CwsContractEvents, DOCUMENTS_TAB, FORM_CONFIG_SOURCE, LOG_TAB, MARKET_REFERENCE_SOURCE, NOTES_WARNING, NUMBER_ISSUE_GENERIC_MESSAGE, RECORD_DRAFT_STORE, RECORD_ORIGIN_PARAM, addendumFieldSetFor, addendumFieldSetOf, auditChangesOf, classifyIntercompany, classifyInvalidParams, contractDocumentName, contractStatusBadge, copyExclusions, copyableValues, describeAuditAction, formatContractDate, groupContractDocuments, injectLocationCodes, injectTradeUnitLabel, isIntercompanyPurchase, isRedactedName, messageForNumberIssueCondition, noteSizeRefusal, numberIssueConditionOf, recordOrigin, recordTrail, remainingNoteBytes, seedFromCtrmValues, tabsAfterCascade, templateValuesOf } from "@cws/domain-contracts";
import { ControlPattern, MAX_SHIP_PERIODS, ReconciliationState, buildShipPeriodDescription, hasOverlappingPeriods, marketCascade, nextShipPeriod, reconcileShipPeriods, validateShipPeriods } from "@cws/shared-form-engine";
import { problemFrom, writeOutcomeOf } from "@cws/core-http";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, HostListener, afterRenderEffect, computed, effect, inject, input, linkedSignal, signal, untracked, viewChild } from "@angular/core";
import { takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { ActivatedRoute, RouterLink } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { parseShipPeriodDate } from "@cws/shared-utils";
import { AsyncContainerComponent, BreadcrumbComponent, DataGridComponent, DropdownDirective, NoticesPanelComponent, RefreshButtonComponent, StatusBadgeComponent, compareBySorts, downloadBlob, injectConfirm, registerShortcuts, remoteLoaded, remoteLoading } from "@cws/shared-ui";
import { catchError, debounceTime, map, of, startWith, switchMap, take, timer } from "rxjs";
const CONTRACT_DETAIL_SECTIONS = CONTRACT_LAYOUT_SECTIONS;
const DETAIL_EMPTY_NOTES = CONTRACT_LAYOUT_EMPTY_NOTES;
function aggregateValues(contract) {
	const header = contract.header;
	return {
		contract_date: header.contractDate ?? null,
		location: header.tradeUnit ?? null,
		trader_initials: header.traderInitials ?? null,
		customer_id: header.customerId ?? null,
		customer_contract: header.customerContract ?? null,
		customer_merchant: contract.customerMerchant ?? null,
		payment_terms_code: header.paymentTerms ?? null,
		price_type_code: header.priceTypeCode ?? null,
		price: header.price ?? null,
		basis_price: header.basisPrice ?? null,
		hedge_price: contract.hedgePrice ?? null,
		freight_adj: contract.freightAdjustment ?? null,
		contract_currency: contract.currency ?? null,
		market_zone: header.marketZone ?? null,
		basis_location: contract.basisLocation ?? null,
		quantity: header.quantity ?? null,
		quantity_uom: header.quantityUom ?? null,
		descriptive_quantity: contract.descriptiveQuantity ?? null,
		origin_code: contract.originCode ?? null,
		destination_code: contract.destinationCode ?? null,
		ship_period_description: contract.shipPeriodDescription ?? null,
		broker_id: contract.brokerId ?? null,
		broker_contract: contract.brokerContract ?? null,
		customer_name: isRedactedName(header.customerName) ? null : header.customerName ?? null,
		origin_name: header.originName ?? null,
		destination_name: header.destinationName ?? null,
		inco_terms_description: contract.incoTermsDescription ?? null,
		named_place: contract.namedPlace ?? null
	};
}
function withResolvedTrader(config, contract) {
	const initials = contract?.header.traderInitials?.trim() ?? "";
	const name = contract?.header.trader?.trim() ?? "";
	if (initials === "" || name === "") return config;
	return {
		...config,
		sections: config.sections.map((section) => ({
			...section,
			fields: section.fields.map((field) => field.componentName === TRADER_INITIALS_COMPONENT ? {
				...field,
				controlPattern: ControlPattern.SearchableCodeCombo,
				allowedValues: [{
					code: initials,
					description: name
				}]
			} : field)
		}))
	};
}
const TRADER_INITIALS_COMPONENT = "TraderInitials";
const MARKET_MONTH_COMPONENTS = ["BasisMarketMonth", "HedgeMarketMonth"];
function withMarketMonths(config, months) {
	if (months === null || months.length === 0) return config;
	const upgraded = new Set(MARKET_MONTH_COMPONENTS);
	return {
		...config,
		sections: config.sections.map((section) => ({
			...section,
			fields: section.fields.map((field) => upgraded.has(field.componentName) ? {
				...field,
				controlPattern: ControlPattern.SearchableCodeCombo,
				allowedValues: months
			} : field)
		}))
	};
}
function mergeContractValues(contract, writableValues) {
	const supplementary = writableValues ?? {};
	if (contract === null) return supplementary;
	const modelled = Object.fromEntries(Object.entries(aggregateValues(contract)).filter(([, value]) => value !== null));
	return {
		...supplementary,
		...modelled
	};
}
const CONFIRMATION_STAGES = [
	{
		label: "Trader approval",
		value: (c) => c.header.traderApprovalStatus
	},
	{
		label: "Customer confirmation",
		value: (c) => c.header.customerConfirmStatus
	},
	{
		label: "Broker confirmation",
		value: (c) => c.header.brokerConfirmStatus,
		emptyNote: "Populates on the detail route only"
	}
];
function formatFieldValue(value, kind) {
	if (value === null || value === void 0 || value === "") return "";
	switch (kind) {
		case "date": return formatContractDate(String(value));
		case "price": return formatNumeric(value, price);
		case "quantity":
		case "number": return formatNumeric(value, quantity);
		default: return String(value);
	}
}
function formatNumeric(value, formatter) {
	const numeric = typeof value === "number" ? value : Number(value);
	return Number.isFinite(numeric) ? formatter.format(numeric) : String(value);
}
const price = new Intl.NumberFormat("en-US", {
	minimumFractionDigits: 4,
	maximumFractionDigits: 4
});
const quantity = new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 });
var ContractAddendumSectionComponent = class ContractAddendumSectionComponent {
	templateSource = inject(ADDENDUM_TEMPLATE_SOURCE, { optional: true });
	generationSource = inject(ADDENDUM_GENERATION_SOURCE, { optional: true });
	destroyRef = inject(DestroyRef);
	fieldSet = input.required(...ngDevMode ? [{ debugName: "fieldSet" }] : /* istanbul ignore next */ []);
	contractNumber = input("", ...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	tradeUnit = input(null, ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	canGenerate = input(false, ...ngDevMode ? [{ debugName: "canGenerate" }] : /* istanbul ignore next */ []);
	offered = this.templateSource !== null && this.generationSource !== null;
	values = linkedSignal({
		...ngDevMode ? { debugName: "values" } : /* istanbul ignore next */ {},
		source: () => this.fieldSet(),
		computation: () => ({})
	});
	templatesState = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "templatesState" }] : /* istanbul ignore next */ []);
	templates = computed(() => {
		const state = this.templatesState();
		if (state.status !== "loaded") return [];
		const set = this.fieldSet().id;
		const unit = (this.tradeUnit() ?? "").trim();
		return state.templates.filter((template) => template.active && template.family === "B" && addendumFieldSetOf(template) === set && (template.tradeUnits.length === 0 || template.tradeUnits.includes(unit)));
	}, ...ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []);
	selectedTemplateId = linkedSignal({
		...ngDevMode ? { debugName: "selectedTemplateId" } : /* istanbul ignore next */ {},
		source: () => this.templates(),
		computation: (templates, previous) => previous !== void 0 && templates.some((template) => template.id === previous.value) ? previous.value : templates[0]?.id ?? null
	});
	generation = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "generation" }] : /* istanbul ignore next */ []);
	hasContract = computed(() => this.contractNumber().trim() !== "", ...ngDevMode ? [{ debugName: "hasContract" }] : /* istanbul ignore next */ []);
	canPressGenerate = computed(() => this.offered && this.canGenerate() && this.hasContract() && this.selectedTemplateId() !== null && this.generation().status !== "generating", ...ngDevMode ? [{ debugName: "canPressGenerate" }] : /* istanbul ignore next */ []);
	unavailableReason = computed(() => {
		const templates = this.templatesState();
		const generation = this.generation();
		if (generation.status === "unavailable") return generation.reason;
		return templates.status === "unavailable" ? templates.reason : null;
	}, ...ngDevMode ? [{ debugName: "unavailableReason" }] : /* istanbul ignore next */ []);
	constructor() {
		this.templateSource?.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") this.templatesState.set({
				status: "loaded",
				templates: answer.value
			});
			else if (answer.kind === "unavailable") this.templatesState.set({
				status: "unavailable",
				reason: answer.reason
			});
			else this.templatesState.set({
				status: "failed",
				message: answer.message
			});
		});
	}
	inputType(field) {
		return field.controlPattern === ControlPattern.MaskedDate ? "date" : "text";
	}
	inputMode(field) {
		return field.controlPattern === ControlPattern.QuantityDecimal ? "decimal" : null;
	}
	valueOf(field) {
		return this.values()[field.cwsField] ?? "";
	}
	setValue(field, value) {
		this.values.update((values) => ({
			...values,
			[field.cwsField]: value
		}));
	}
	selectTemplate(value) {
		const id = Number(value);
		this.selectedTemplateId.set(Number.isFinite(id) ? id : null);
	}
	generate() {
		const source = this.generationSource;
		const templateId = this.selectedTemplateId();
		if (source === null || templateId === null || !this.canPressGenerate()) return;
		const fields = Object.fromEntries(Object.entries(this.values()).map(([name, value]) => [name, value.trim()]).filter(([, value]) => value !== ""));
		this.generation.set({ status: "generating" });
		source.generate(this.contractNumber().trim(), {
			templateId,
			fields
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") this.generation.set({
				status: "generated",
				addendum: answer.value
			});
			else if (answer.kind === "unavailable") this.generation.set({
				status: "unavailable",
				reason: answer.reason
			});
			else this.generation.set({
				status: "failed",
				message: answer.message,
				...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
			});
		});
	}
	generated = computed(() => {
		const state = this.generation();
		return state.status === "generated" ? state.addendum : null;
	}, ...ngDevMode ? [{ debugName: "generated" }] : /* istanbul ignore next */ []);
	generationFailure = computed(() => {
		const state = this.generation();
		return state.status === "failed" ? state : null;
	}, ...ngDevMode ? [{ debugName: "generationFailure" }] : /* istanbul ignore next */ []);
	templatesFailure = computed(() => {
		const state = this.templatesState();
		return state.status === "failed" ? state.message : null;
	}, ...ngDevMode ? [{ debugName: "templatesFailure" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ContractAddendumSectionComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ContractAddendumSectionComponent,
		isStandalone: true,
		selector: "cws-contract-addendum-section",
		inputs: {
			fieldSet: {
				classPropertyName: "fieldSet",
				publicName: "fieldSet",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			contractNumber: {
				classPropertyName: "contractNumber",
				publicName: "contractNumber",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tradeUnit: {
				classPropertyName: "tradeUnit",
				publicName: "tradeUnit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canGenerate: {
				classPropertyName: "canGenerate",
				publicName: "canGenerate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<section class=\"scoular-card cws:space-y-4 cws:p-4\" aria-labelledby=\"contract-addendum-heading\" data-testid=\"addendum-section\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 id=\"contract-addendum-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      Addendum: {{ fieldSet().title }}\r\n    </h3>\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      These values are kept by the Contract Workspace for the addendum document. They are not part of\r\n      the contract and are never sent to CTRM when the contract is saved.\r\n    </p>\r\n  </header>\r\n\r\n  <!--\r\n    🔴 The no-signature-image caveat, as visible text and never a title attribute. Who signs a\r\n    CWS-generated addendum once Cara is retired is an open question (tracked on #245 and #330), and\r\n    until it is answered the generated PDF carries the anchors and nothing else. The issue numbers\r\n    stay in this comment: the user-facing-copy guard refuses them on screen, and a trader cannot open\r\n    an issue anyway.\r\n\r\n    ⚠ Deliberately not role=\"alert\": it is a standing condition of every addendum generated here, not\r\n    something that just happened.\r\n  -->\r\n  <div class=\"scoular-alert scoular-alert-warning\" data-testid=\"addendum-signature-caveat\">\r\n    <div class=\"scoular-alert-title\">No signature image</div>\r\n    <div class=\"scoular-alert-description\">\r\n      Who signs an addendum generated here, now that Cara is being retired, has not been decided yet.\r\n      The generated document carries the signature, date and initials anchors, but no signature image.\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"cws:grid cws:grid-cols-1 cws:gap-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\r\n    @for (field of fieldSet().fields; track field.cwsField) {\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ field.label }}</span>\r\n        <input\r\n          class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n          [attr.name]=\"field.cwsField\"\r\n          [type]=\"inputType(field)\"\r\n          [attr.inputmode]=\"inputMode(field)\"\r\n          [value]=\"valueOf(field)\"\r\n          [disabled]=\"!canGenerate() || !hasContract()\"\r\n          (input)=\"setValue(field, $any($event.target).value)\"\r\n        />\r\n      </label>\r\n    }\r\n  </div>\r\n\r\n  @if (!offered) {\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-not-offered\">\r\n      Generating an addendum is not offered here.\r\n    </p>\r\n  } @else {\r\n    @if (unavailableReason(); as reason) {\r\n      <!-- The route is wired before the backend publishes it. Said, never a crash or a silent blank. -->\r\n      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"addendum-unavailable\">\r\n        <div class=\"scoular-alert-title\">Not available yet</div>\r\n        <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n      </div>\r\n    }\r\n\r\n    @if (templatesFailure(); as message) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ message }}\r\n      </p>\r\n    }\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template</span>\r\n        <select\r\n          class=\"scoular-form-input cws:mt-1 cws:w-72\"\r\n          name=\"addendumTemplate\"\r\n          [disabled]=\"templates().length === 0\"\r\n          (change)=\"selectTemplate($any($event.target).value)\"\r\n        >\r\n          @for (template of templates(); track template.id) {\r\n            <option [value]=\"template.id\" [selected]=\"template.id === selectedTemplateId()\">\r\n              {{ template.name }} (version {{ template.version }})\r\n            </option>\r\n          } @empty {\r\n            <option value=\"\">No active template for this addendum</option>\r\n          }\r\n        </select>\r\n      </label>\r\n\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"!canPressGenerate()\" (click)=\"generate()\">\r\n        @if (generation().status === 'generating') { Generating… } @else { Generate addendum }\r\n      </button>\r\n    </div>\r\n\r\n    @if (!hasContract()) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        An addendum can be generated once the contract has been saved.\r\n      </p>\r\n    } @else if (!canGenerate()) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Your account cannot generate addendums.\r\n      </p>\r\n    }\r\n\r\n    @if (generated(); as addendum) {\r\n      <div class=\"scoular-alert scoular-alert-success\" role=\"status\" data-testid=\"addendum-generated\">\r\n        <div class=\"scoular-alert-title\">Addendum generated</div>\r\n        <div class=\"scoular-alert-description\">\r\n          Status: {{ addendum.status }}.\r\n          @if (addendum.documentId) { Document {{ addendum.documentId }}. }\r\n          It carries no signature image.\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (generationFailure(); as failure) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ failure.message }}\r\n        @if (failure.correlationId; as id) {\r\n          <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n        }\r\n      </p>\r\n    }\r\n  }\r\n</section>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ContractAddendumSectionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-addendum-section",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<section class=\"scoular-card cws:space-y-4 cws:p-4\" aria-labelledby=\"contract-addendum-heading\" data-testid=\"addendum-section\">\r\n  <header class=\"cws:space-y-1\">\r\n    <h3 id=\"contract-addendum-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n      Addendum: {{ fieldSet().title }}\r\n    </h3>\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n      These values are kept by the Contract Workspace for the addendum document. They are not part of\r\n      the contract and are never sent to CTRM when the contract is saved.\r\n    </p>\r\n  </header>\r\n\r\n  <!--\r\n    🔴 The no-signature-image caveat, as visible text and never a title attribute. Who signs a\r\n    CWS-generated addendum once Cara is retired is an open question (tracked on #245 and #330), and\r\n    until it is answered the generated PDF carries the anchors and nothing else. The issue numbers\r\n    stay in this comment: the user-facing-copy guard refuses them on screen, and a trader cannot open\r\n    an issue anyway.\r\n\r\n    ⚠ Deliberately not role=\"alert\": it is a standing condition of every addendum generated here, not\r\n    something that just happened.\r\n  -->\r\n  <div class=\"scoular-alert scoular-alert-warning\" data-testid=\"addendum-signature-caveat\">\r\n    <div class=\"scoular-alert-title\">No signature image</div>\r\n    <div class=\"scoular-alert-description\">\r\n      Who signs an addendum generated here, now that Cara is being retired, has not been decided yet.\r\n      The generated document carries the signature, date and initials anchors, but no signature image.\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"cws:grid cws:grid-cols-1 cws:gap-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\r\n    @for (field of fieldSet().fields; track field.cwsField) {\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ field.label }}</span>\r\n        <input\r\n          class=\"scoular-form-input cws:mt-1 cws:w-full\"\r\n          [attr.name]=\"field.cwsField\"\r\n          [type]=\"inputType(field)\"\r\n          [attr.inputmode]=\"inputMode(field)\"\r\n          [value]=\"valueOf(field)\"\r\n          [disabled]=\"!canGenerate() || !hasContract()\"\r\n          (input)=\"setValue(field, $any($event.target).value)\"\r\n        />\r\n      </label>\r\n    }\r\n  </div>\r\n\r\n  @if (!offered) {\r\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"addendum-not-offered\">\r\n      Generating an addendum is not offered here.\r\n    </p>\r\n  } @else {\r\n    @if (unavailableReason(); as reason) {\r\n      <!-- The route is wired before the backend publishes it. Said, never a crash or a silent blank. -->\r\n      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"addendum-unavailable\">\r\n        <div class=\"scoular-alert-title\">Not available yet</div>\r\n        <div class=\"scoular-alert-description\">{{ reason }}</div>\r\n      </div>\r\n    }\r\n\r\n    @if (templatesFailure(); as message) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ message }}\r\n      </p>\r\n    }\r\n\r\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\r\n      <label class=\"cws:space-y-1\">\r\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template</span>\r\n        <select\r\n          class=\"scoular-form-input cws:mt-1 cws:w-72\"\r\n          name=\"addendumTemplate\"\r\n          [disabled]=\"templates().length === 0\"\r\n          (change)=\"selectTemplate($any($event.target).value)\"\r\n        >\r\n          @for (template of templates(); track template.id) {\r\n            <option [value]=\"template.id\" [selected]=\"template.id === selectedTemplateId()\">\r\n              {{ template.name }} (version {{ template.version }})\r\n            </option>\r\n          } @empty {\r\n            <option value=\"\">No active template for this addendum</option>\r\n          }\r\n        </select>\r\n      </label>\r\n\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"!canPressGenerate()\" (click)=\"generate()\">\r\n        @if (generation().status === 'generating') { Generating… } @else { Generate addendum }\r\n      </button>\r\n    </div>\r\n\r\n    @if (!hasContract()) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        An addendum can be generated once the contract has been saved.\r\n      </p>\r\n    } @else if (!canGenerate()) {\r\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n        Your account cannot generate addendums.\r\n      </p>\r\n    }\r\n\r\n    @if (generated(); as addendum) {\r\n      <div class=\"scoular-alert scoular-alert-success\" role=\"status\" data-testid=\"addendum-generated\">\r\n        <div class=\"scoular-alert-title\">Addendum generated</div>\r\n        <div class=\"scoular-alert-description\">\r\n          Status: {{ addendum.status }}.\r\n          @if (addendum.documentId) { Document {{ addendum.documentId }}. }\r\n          It carries no signature image.\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @if (generationFailure(); as failure) {\r\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\r\n        {{ failure.message }}\r\n        @if (failure.correlationId; as id) {\r\n          <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\r\n        }\r\n      </p>\r\n    }\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		fieldSet: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldSet",
				required: true
			}]
		}],
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: false
			}]
		}],
		tradeUnit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tradeUnit",
				required: false
			}]
		}],
		canGenerate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canGenerate",
				required: false
			}]
		}]
	}
});
const STATUS_LABELS = {
	available: "Ready",
	pending: "Generating…",
	expired: "Expired",
	notStored: "File not kept",
	unknown: "Status not recognised"
};
const CANNOT_OPEN = {
	pending: "This document is still being generated, so it cannot be opened yet.",
	expired: "This document has expired, so it can no longer be opened.",
	notStored: "CTRM still lists this document, but no longer holds its file, so it cannot be opened.",
	unknown: "CTRM reported a status this screen does not recognise, so the document is not opened rather than guessed at."
};
const ROLE_BADGES = {
	draft: "Draft",
	approved: "Approved",
	confirmed: "Confirmed"
};
var ContractDocumentsTabComponent = class ContractDocumentsTabComponent {
	source = inject(CONTRACT_DOCUMENTS_SOURCE, { optional: true });
	host = inject(ElementRef);
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	offered = this.source !== null;
	listState = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "listState" }] : /* istanbul ignore next */ []);
	viewer = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "viewer" }] : /* istanbul ignore next */ []);
	selectedEntry = signal(null, ...ngDevMode ? [{ debugName: "selectedEntry" }] : /* istanbul ignore next */ []);
	recheckIn = signal(null, ...ngDevMode ? [{ debugName: "recheckIn" }] : /* istanbul ignore next */ []);
	recheckExhausted = signal(false, ...ngDevMode ? [{ debugName: "recheckExhausted" }] : /* istanbul ignore next */ []);
	rechecks = 0;
	listSubscription = null;
	recheckSubscription = null;
	contentSubscription = null;
	frame = viewChild("viewerFrame", ...ngDevMode ? [{ debugName: "frame" }] : /* istanbul ignore next */ []);
	grouping = computed(() => {
		const state = this.listState();
		return groupContractDocuments(state.status === "loaded" ? state.response.documents : []);
	}, ...ngDevMode ? [{ debugName: "grouping" }] : /* istanbul ignore next */ []);
	isEmpty = computed(() => {
		const state = this.listState();
		return state.status === "loaded" && state.response.documents.length === 0;
	}, ...ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => {
		const state = this.listState();
		return state.status === "loaded" && state.response.dataOrigin === "Simulated";
	}, ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.response.warnings : [];
	}, ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	visibleDocuments = computed(() => this.grouping().groups.flatMap((group) => group.documents), ...ngDevMode ? [{ debugName: "visibleDocuments" }] : /* istanbul ignore next */ []);
	selected = computed(() => this.visibleDocuments().find((document) => document.documentEntry === this.selectedEntry()) ?? null, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	selectedViewer = computed(() => {
		const state = this.viewer();
		return state.status !== "idle" && state.entry === this.selectedEntry() ? state : { status: "idle" };
	}, ...ngDevMode ? [{ debugName: "selectedViewer" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			this.contractNumber();
			untracked(() => {
				this.selectedEntry.set(null);
				this.setViewer({ status: "idle" });
				this.retry();
			});
		});
		afterRenderEffect(() => {
			const state = this.selectedViewer();
			const frame = this.frame()?.nativeElement;
			if (frame !== void 0 && state.status === "open" && state.url.startsWith("blob:") && frame.src !== state.url) frame.src = state.url;
		});
		inject(DestroyRef).onDestroy(() => {
			this.listSubscription?.unsubscribe();
			this.recheckSubscription?.unsubscribe();
			this.contentSubscription?.unsubscribe();
			this.revoke(this.viewer());
		});
	}
	retry() {
		this.rechecks = 0;
		this.recheckExhausted.set(false);
		this.load(false);
	}
	statusLabel(document) {
		return STATUS_LABELS[document.status];
	}
	roleBadge(document) {
		return ROLE_BADGES[document.role] ?? null;
	}
	nameOf(document) {
		return contractDocumentName(document);
	}
	cannotOpenReason(document) {
		return document.status === "available" ? null : CANNOT_OPEN[document.status];
	}
	open(document) {
		this.selectedEntry.set(document.documentEntry);
		const current = this.viewer();
		if (document.status !== "available" || this.source === null) {
			this.contentSubscription?.unsubscribe();
			this.setViewer({ status: "idle" });
			return;
		}
		if (current.status !== "idle" && current.entry === document.documentEntry && current.status !== "failed") return;
		const entry = document.documentEntry;
		this.contentSubscription?.unsubscribe();
		this.setViewer({
			status: "loading",
			entry
		});
		this.contentSubscription = this.source.content(this.contractNumber(), entry).subscribe((content) => {
			switch (content.kind) {
				case "done":
					this.setViewer({
						status: "open",
						entry,
						url: URL.createObjectURL(content.blob),
						blob: content.blob
					});
					break;
				case "unavailable":
					this.setViewer({
						status: "unavailable",
						entry,
						reason: content.reason
					});
					break;
				case "failed": this.setViewer({
					status: "failed",
					entry,
					message: content.message
				});
			}
		});
	}
	print() {
		this.frame()?.nativeElement.contentWindow?.print();
	}
	download() {
		const state = this.selectedViewer();
		const document = this.selected();
		if (state.status !== "open" || document === null) return;
		downloadBlob(document.fileName?.trim() || `${contractDocumentName(document)}.pdf`, state.blob);
	}
	onKeydown(event) {
		if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "p") {
			if (this.selectedViewer().status === "open") {
				event.preventDefault();
				this.print();
			}
			return;
		}
		if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
		const items = Array.from(this.host.nativeElement.querySelectorAll("button[data-document-entry]"));
		const index = items.indexOf(event.target);
		if (index === -1) return;
		event.preventDefault();
		items[event.key === "ArrowDown" ? Math.min(index + 1, items.length - 1) : Math.max(index - 1, 0)].focus();
	}
	load(silent) {
		this.listSubscription?.unsubscribe();
		this.stopRecheck();
		const number = this.contractNumber().trim();
		if (!silent) this.listState.set({ status: "loading" });
		if (this.source === null || number === "") return;
		this.listSubscription = this.source.list(number).subscribe((read) => {
			switch (read.kind) {
				case "loaded":
					this.listState.set({
						status: "loaded",
						response: read.response
					});
					break;
				case "refused":
					this.listState.set({
						status: "refused",
						title: read.title,
						detail: read.detail
					});
					break;
				case "failed": this.listState.set({
					status: "failed",
					message: read.message,
					...read.correlationId === void 0 ? {} : { correlationId: read.correlationId }
				});
			}
			this.scheduleRecheck();
		});
	}
	scheduleRecheck() {
		if (!this.visibleDocuments().some((document) => document.status === "pending")) return;
		if (this.rechecks >= 20) {
			this.recheckExhausted.set(true);
			return;
		}
		this.recheckSubscription = timer(0, 1e3).pipe(take(16)).subscribe((tick) => {
			const left = 15 - tick;
			if (left > 0) this.recheckIn.set(left);
			else {
				this.rechecks++;
				this.load(true);
			}
		});
	}
	stopRecheck() {
		this.recheckSubscription?.unsubscribe();
		this.recheckSubscription = null;
		this.recheckIn.set(null);
	}
	setViewer(next) {
		const current = this.viewer();
		if (current.status === "open" && (next.status !== "open" || next.url !== current.url)) this.revoke(current);
		this.viewer.set(next);
	}
	revoke(state) {
		if (state.status === "open") URL.revokeObjectURL(state.url);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ContractDocumentsTabComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ContractDocumentsTabComponent,
		isStandalone: true,
		selector: "cws-contract-documents-tab",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: { "keydown": "onKeydown($event)" } },
		viewQueries: [{
			propertyName: "frame",
			first: true,
			predicate: ["viewerFrame"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<section class=\"cws:space-y-3\" aria-label=\"Documents\" data-testid=\"documents-tab\">\r\n  @if (!offered) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-not-offered\">\r\n      Documents are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (listState().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the documents…</p>\r\n      }\r\n\r\n      @case ('refused') {\r\n        <!--\r\n          A 403. For `ctrm-user-ambiguous` and `ctrm-user-not-found` the server's `detail` says what to\r\n          do (ask the Help Desk), so it is shown as it came rather than paraphrased here.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'refused') {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-testid=\"documents-refused\">\r\n              <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n              <div class=\"scoular-alert-description\">{{ state.detail }}</div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('failed') {\r\n        <!--\r\n          🔴 Criterion 4: a failed read says so and offers Retry. It must never fall through to the\r\n          list, whose empty state would tell the user this contract has no documents.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'failed') {\r\n            <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-failed\">\r\n              <div class=\"scoular-alert-title\">The documents could not be loaded</div>\r\n              <div class=\"scoular-alert-description cws:space-y-2\">\r\n                <p>{{ state.message }}</p>\r\n                @if (state.correlationId) {\r\n                  <p class=\"cws:text-xs\">Reference: <span class=\"cws:font-mono\">{{ state.correlationId }}</span></p>\r\n                }\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"retry()\">Retry</button>\r\n              </div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('loaded') {\r\n        @if (isSimulated()) {\r\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-simulated\">\r\n            These documents are simulated: the CTRM documents service is not connected yet.\r\n          </p>\r\n        }\r\n\r\n        @for (warning of warnings(); track $index) {\r\n          <div class=\"scoular-alert scoular-alert-warning\">\r\n            <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n          </div>\r\n        }\r\n\r\n        @if (isEmpty()) {\r\n          <!-- docs/02a §6.4a's empty state. Reached only from a SUCCESSFUL read of zero rows. -->\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-empty\">\r\n            No documents yet — generated when the contract is saved or approved.\r\n          </p>\r\n        } @else {\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-[18rem_1fr]\">\r\n            <!--\r\n              The left rail. Each document is a button, so Enter and a click open it natively; ↑/↓ are\r\n              handled on the host and move focus between these buttons only.\r\n            -->\r\n            <nav aria-label=\"Contract documents\" class=\"cws:space-y-4\" data-testid=\"documents-list\">\r\n              @if (grouping().heldBack > 0 && !grouping().approved) {\r\n                <!--\r\n                  The first-approval rule: the contract document is held back until the contract's first\r\n                  approval. Said, so the Contract group is not silently missing.\r\n                -->\r\n                <div class=\"cws:space-y-1\" data-testid=\"documents-held-back\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">Contract</h3>\r\n                  <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    The contract document is shown here once the contract has been approved.\r\n                  </p>\r\n                </div>\r\n              }\r\n\r\n              @for (group of grouping().groups; track group.id) {\r\n                <div class=\"cws:space-y-1\" [attr.data-testid]=\"'documents-group-' + group.id\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    {{ group.title }}\r\n                  </h3>\r\n                  <ul class=\"cws:space-y-1\">\r\n                    @for (document of group.documents; track document.documentEntry) {\r\n                      <li>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"cws:flex cws:w-full cws:items-center cws:gap-2 cws:rounded-md cws:px-2 cws:py-1.5 cws:text-left cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                          [class.cws:bg-slate-100]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:dark:bg-slate-700]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:hover:bg-slate-50]=\"document.documentEntry !== selectedEntry()\"\r\n                          [class.cws:dark:hover:bg-slate-800]=\"document.documentEntry !== selectedEntry()\"\r\n                          [attr.aria-current]=\"document.documentEntry === selectedEntry() ? 'true' : null\"\r\n                          [attr.data-document-entry]=\"document.documentEntry\"\r\n                          (click)=\"open(document)\"\r\n                        >\r\n                          <span class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-slate-900 cws:dark:text-white\">{{ nameOf(document) }}</span>\r\n                          @if (roleBadge(document); as badge) {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-sky-50 cws:text-sky-800 cws:dark:bg-sky-500/10 cws:dark:text-sky-200\">{{ badge }}</span>\r\n                          }\r\n                          @if (document.status !== 'available') {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-slate-100 cws:text-slate-700 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ statusLabel(document) }}</span>\r\n                          }\r\n                        </button>\r\n                      </li>\r\n                    }\r\n                  </ul>\r\n                </div>\r\n              }\r\n\r\n              @if (recheckIn(); as seconds) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\" data-testid=\"documents-recheck\">\r\n                  Generating… checking again in {{ seconds }}s.\r\n                </p>\r\n              }\r\n              @if (recheckExhausted()) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-recheck-stopped\">\r\n                  A document is still being generated. Use Retry to check again.\r\n                  <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:ml-1\" (click)=\"retry()\">Retry</button>\r\n                </p>\r\n              }\r\n            </nav>\r\n\r\n            <!-- The right pane: the inline viewer (C11), or why the selected document cannot be opened. -->\r\n            <div\r\n              class=\"cws:min-h-96 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              data-testid=\"documents-viewer\"\r\n            >\r\n              @if (selected(); as document) {\r\n                <div class=\"cws:mb-3 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n                  <h3 class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    {{ nameOf(document) }}\r\n                  </h3>\r\n                  @if (document.createdStamp) {\r\n                    <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Created {{ document.createdStamp }}</span>\r\n                  }\r\n                  @if (selectedViewer().status === 'open') {\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"print()\">Print</button>\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"download()\">Download</button>\r\n                  }\r\n                </div>\r\n\r\n                @if (cannotOpenReason(document); as reason) {\r\n                  <!--\r\n                    C11: a pending document is never a raw error. It and the other unopenable states say\r\n                    why in plain words, and none of them asks the server for content.\r\n                  -->\r\n                  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"documents-cannot-open\">{{ reason }}</p>\r\n                  @if (document.status === 'pending') {\r\n                    <div class=\"cws:mt-3 cws:h-64 cws:animate-pulse cws:rounded-md cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></div>\r\n                  }\r\n                } @else {\r\n                  @switch (selectedViewer().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the document…</p>\r\n                    }\r\n                    @case ('open') {\r\n                      <iframe\r\n                        #viewerFrame\r\n                        class=\"cws:h-[70vh] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700\"\r\n                        [title]=\"nameOf(document)\"\r\n                        data-testid=\"documents-frame\"\r\n                      ></iframe>\r\n                    }\r\n                    @case ('unavailable') {\r\n                      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"documents-content-unavailable\">\r\n                        <div class=\"scoular-alert-title\">Can't be opened here yet</div>\r\n                        <div class=\"scoular-alert-description\">\r\n                          @if (selectedViewer(); as state) {\r\n                            @if (state.status === 'unavailable') { {{ state.reason }} }\r\n                          }\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @case ('failed') {\r\n                      <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-content-failed\">\r\n                        <div class=\"scoular-alert-description cws:space-y-2\">\r\n                          @if (selectedViewer(); as state) {\r\n                            @if (state.status === 'failed') { <p>{{ state.message }}</p> }\r\n                          }\r\n                          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"open(document)\">Try again</button>\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @default {\r\n                      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"open(document)\">Open</button>\r\n                    }\r\n                  }\r\n                }\r\n              } @else {\r\n                <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Select a document to view it.</p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n      }\r\n    }\r\n  }\r\n</section>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ContractDocumentsTabComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-documents-tab",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "(keydown)": "onKeydown($event)" },
			template: "<section class=\"cws:space-y-3\" aria-label=\"Documents\" data-testid=\"documents-tab\">\r\n  @if (!offered) {\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-not-offered\">\r\n      Documents are not offered here.\r\n    </p>\r\n  } @else {\r\n    @switch (listState().status) {\r\n      @case ('loading') {\r\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the documents…</p>\r\n      }\r\n\r\n      @case ('refused') {\r\n        <!--\r\n          A 403. For `ctrm-user-ambiguous` and `ctrm-user-not-found` the server's `detail` says what to\r\n          do (ask the Help Desk), so it is shown as it came rather than paraphrased here.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'refused') {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-testid=\"documents-refused\">\r\n              <div class=\"scoular-alert-title\">{{ state.title }}</div>\r\n              <div class=\"scoular-alert-description\">{{ state.detail }}</div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('failed') {\r\n        <!--\r\n          🔴 Criterion 4: a failed read says so and offers Retry. It must never fall through to the\r\n          list, whose empty state would tell the user this contract has no documents.\r\n        -->\r\n        @if (listState(); as state) {\r\n          @if (state.status === 'failed') {\r\n            <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-failed\">\r\n              <div class=\"scoular-alert-title\">The documents could not be loaded</div>\r\n              <div class=\"scoular-alert-description cws:space-y-2\">\r\n                <p>{{ state.message }}</p>\r\n                @if (state.correlationId) {\r\n                  <p class=\"cws:text-xs\">Reference: <span class=\"cws:font-mono\">{{ state.correlationId }}</span></p>\r\n                }\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"retry()\">Retry</button>\r\n              </div>\r\n            </div>\r\n          }\r\n        }\r\n      }\r\n\r\n      @case ('loaded') {\r\n        @if (isSimulated()) {\r\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-simulated\">\r\n            These documents are simulated: the CTRM documents service is not connected yet.\r\n          </p>\r\n        }\r\n\r\n        @for (warning of warnings(); track $index) {\r\n          <div class=\"scoular-alert scoular-alert-warning\">\r\n            <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n          </div>\r\n        }\r\n\r\n        @if (isEmpty()) {\r\n          <!-- docs/02a §6.4a's empty state. Reached only from a SUCCESSFUL read of zero rows. -->\r\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-empty\">\r\n            No documents yet — generated when the contract is saved or approved.\r\n          </p>\r\n        } @else {\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-[18rem_1fr]\">\r\n            <!--\r\n              The left rail. Each document is a button, so Enter and a click open it natively; ↑/↓ are\r\n              handled on the host and move focus between these buttons only.\r\n            -->\r\n            <nav aria-label=\"Contract documents\" class=\"cws:space-y-4\" data-testid=\"documents-list\">\r\n              @if (grouping().heldBack > 0 && !grouping().approved) {\r\n                <!--\r\n                  The first-approval rule: the contract document is held back until the contract's first\r\n                  approval. Said, so the Contract group is not silently missing.\r\n                -->\r\n                <div class=\"cws:space-y-1\" data-testid=\"documents-held-back\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">Contract</h3>\r\n                  <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    The contract document is shown here once the contract has been approved.\r\n                  </p>\r\n                </div>\r\n              }\r\n\r\n              @for (group of grouping().groups; track group.id) {\r\n                <div class=\"cws:space-y-1\" [attr.data-testid]=\"'documents-group-' + group.id\">\r\n                  <h3 class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    {{ group.title }}\r\n                  </h3>\r\n                  <ul class=\"cws:space-y-1\">\r\n                    @for (document of group.documents; track document.documentEntry) {\r\n                      <li>\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"cws:flex cws:w-full cws:items-center cws:gap-2 cws:rounded-md cws:px-2 cws:py-1.5 cws:text-left cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                          [class.cws:bg-slate-100]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:dark:bg-slate-700]=\"document.documentEntry === selectedEntry()\"\r\n                          [class.cws:hover:bg-slate-50]=\"document.documentEntry !== selectedEntry()\"\r\n                          [class.cws:dark:hover:bg-slate-800]=\"document.documentEntry !== selectedEntry()\"\r\n                          [attr.aria-current]=\"document.documentEntry === selectedEntry() ? 'true' : null\"\r\n                          [attr.data-document-entry]=\"document.documentEntry\"\r\n                          (click)=\"open(document)\"\r\n                        >\r\n                          <span class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-slate-900 cws:dark:text-white\">{{ nameOf(document) }}</span>\r\n                          @if (roleBadge(document); as badge) {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-sky-50 cws:text-sky-800 cws:dark:bg-sky-500/10 cws:dark:text-sky-200\">{{ badge }}</span>\r\n                          }\r\n                          @if (document.status !== 'available') {\r\n                            <span class=\"scoular-badge scoular-badge-sm cws:bg-slate-100 cws:text-slate-700 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ statusLabel(document) }}</span>\r\n                          }\r\n                        </button>\r\n                      </li>\r\n                    }\r\n                  </ul>\r\n                </div>\r\n              }\r\n\r\n              @if (recheckIn(); as seconds) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\" data-testid=\"documents-recheck\">\r\n                  Generating… checking again in {{ seconds }}s.\r\n                </p>\r\n              }\r\n              @if (recheckExhausted()) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"documents-recheck-stopped\">\r\n                  A document is still being generated. Use Retry to check again.\r\n                  <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:ml-1\" (click)=\"retry()\">Retry</button>\r\n                </p>\r\n              }\r\n            </nav>\r\n\r\n            <!-- The right pane: the inline viewer (C11), or why the selected document cannot be opened. -->\r\n            <div\r\n              class=\"cws:min-h-96 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              data-testid=\"documents-viewer\"\r\n            >\r\n              @if (selected(); as document) {\r\n                <div class=\"cws:mb-3 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n                  <h3 class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    {{ nameOf(document) }}\r\n                  </h3>\r\n                  @if (document.createdStamp) {\r\n                    <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Created {{ document.createdStamp }}</span>\r\n                  }\r\n                  @if (selectedViewer().status === 'open') {\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"print()\">Print</button>\r\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"download()\">Download</button>\r\n                  }\r\n                </div>\r\n\r\n                @if (cannotOpenReason(document); as reason) {\r\n                  <!--\r\n                    C11: a pending document is never a raw error. It and the other unopenable states say\r\n                    why in plain words, and none of them asks the server for content.\r\n                  -->\r\n                  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"documents-cannot-open\">{{ reason }}</p>\r\n                  @if (document.status === 'pending') {\r\n                    <div class=\"cws:mt-3 cws:h-64 cws:animate-pulse cws:rounded-md cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></div>\r\n                  }\r\n                } @else {\r\n                  @switch (selectedViewer().status) {\r\n                    @case ('loading') {\r\n                      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the document…</p>\r\n                    }\r\n                    @case ('open') {\r\n                      <iframe\r\n                        #viewerFrame\r\n                        class=\"cws:h-[70vh] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700\"\r\n                        [title]=\"nameOf(document)\"\r\n                        data-testid=\"documents-frame\"\r\n                      ></iframe>\r\n                    }\r\n                    @case ('unavailable') {\r\n                      <div class=\"scoular-alert scoular-alert-info\" data-testid=\"documents-content-unavailable\">\r\n                        <div class=\"scoular-alert-title\">Can't be opened here yet</div>\r\n                        <div class=\"scoular-alert-description\">\r\n                          @if (selectedViewer(); as state) {\r\n                            @if (state.status === 'unavailable') { {{ state.reason }} }\r\n                          }\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @case ('failed') {\r\n                      <div class=\"scoular-alert scoular-alert-error\" role=\"alert\" data-testid=\"documents-content-failed\">\r\n                        <div class=\"scoular-alert-description cws:space-y-2\">\r\n                          @if (selectedViewer(); as state) {\r\n                            @if (state.status === 'failed') { <p>{{ state.message }}</p> }\r\n                          }\r\n                          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"open(document)\">Try again</button>\r\n                        </div>\r\n                      </div>\r\n                    }\r\n                    @default {\r\n                      <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"open(document)\">Open</button>\r\n                    }\r\n                  }\r\n                }\r\n              } @else {\r\n                <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Select a document to view it.</p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n      }\r\n    }\r\n  }\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}],
		frame: [{
			type: i0.ViewChild,
			args: ["viewerFrame", { isSignal: true }]
		}]
	}
});
const CONFIRMATION_STYLE = {
	positive: {
		chip: "cws:bg-emerald-50 cws:dark:bg-emerald-500/10",
		dot: "cws:bg-emerald-500",
		text: "cws:text-emerald-700 cws:dark:text-emerald-300"
	},
	caution: {
		chip: "cws:bg-amber-50 cws:dark:bg-amber-500/10",
		dot: "cws:bg-amber-500",
		text: "cws:text-amber-700 cws:dark:text-amber-300"
	},
	negative: {
		chip: "cws:bg-rose-50 cws:dark:bg-rose-500/10",
		dot: "cws:bg-rose-500",
		text: "cws:text-rose-700 cws:dark:text-rose-300"
	},
	info: {
		chip: "cws:bg-sky-50 cws:dark:bg-sky-500/10",
		dot: "cws:bg-sky-500",
		text: "cws:text-sky-700 cws:dark:text-sky-300"
	},
	neutral: {
		chip: "cws:bg-slate-100 cws:dark:bg-slate-700/40",
		dot: "cws:bg-slate-400 cws:dark:bg-slate-500",
		text: "cws:text-slate-600 cws:dark:text-slate-300"
	}
};
var ContractRecordPageComponent = class ContractRecordPageComponent {
	details = inject(CONTRACT_DETAIL_SOURCE);
	writes = inject(CONTRACT_WRITE_SOURCE);
	mintIdempotencyKey = inject(CONTRACT_IDEMPOTENCY_KEY);
	createKey = null;
	numbers = inject(CONTRACT_NUMBER_SOURCE);
	configs = inject(FORM_CONFIG_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	events = inject(CwsContractEvents);
	requestNavigation(intent) {
		this.hostContext.navigate(intent);
		this.events.emit({
			type: "navigation-requested",
			intent
		});
	}
	customers = inject(CUSTOMER_SOURCE, { optional: true });
	customerConfirmation = signal(null, ...ngDevMode ? [{ debugName: "customerConfirmation" }] : /* istanbul ignore next */ []);
	tradeUnitLabel = injectTradeUnitLabel();
	contractNumber = input("", {
		...ngDevMode ? { debugName: "contractNumber" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? ""
	});
	mode = input("view", {
		...ngDevMode ? { debugName: "mode" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "view"
	});
	isCreate = computed(() => this.mode() === "create", ...ngDevMode ? [{ debugName: "isCreate" }] : /* istanbul ignore next */ []);
	isView = computed(() => this.mode() === "view", ...ngDevMode ? [{ debugName: "isView" }] : /* istanbul ignore next */ []);
	locationCodes = injectLocationCodes();
	intercompany = computed(() => classifyIntercompany({
		customerId: this.ctrmFieldValue("customer_id"),
		locationCodes: this.locationCodes()
	}), ...ngDevMode ? [{ debugName: "intercompany" }] : /* istanbul ignore next */ []);
	intercompanyLock = computed(() => isIntercompanyPurchase(this.intercompany(), this.ctrmFieldValue("contract_prefix_type")), ...ngDevMode ? [{ debugName: "intercompanyLock" }] : /* istanbul ignore next */ []);
	ctrmFieldValue(ctrmField) {
		const held = this.ctrmValues()?.[ctrmField];
		return typeof held === "string" && held.trim() !== "" ? held : null;
	}
	isEditable = computed(() => !this.isView() && !this.intercompanyLock(), ...ngDevMode ? [{ debugName: "isEditable" }] : /* istanbul ignore next */ []);
	route = inject(ActivatedRoute);
	returnTo = this.route.snapshot.queryParamMap.get("returnTo");
	copyFrom = this.route.snapshot.queryParamMap.get("copyFrom");
	returnParams = computed(() => Object.fromEntries(new URLSearchParams(this.returnTo ?? "")), ...ngDevMode ? [{ debugName: "returnParams" }] : /* istanbul ignore next */ []);
	originParam = this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM);
	origin = computed(() => recordOrigin(this.originParam), ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	trail = computed(() => recordTrail(this.origin(), this.contractNumber()), ...ngDevMode ? [{ debugName: "trail" }] : /* istanbul ignore next */ []);
	editIntent = computed(() => ({
		kind: "contract",
		contractNumber: this.contractNumber(),
		mode: "edit",
		params: this.editParams()
	}), ...ngDevMode ? [{ debugName: "editIntent" }] : /* istanbul ignore next */ []);
	newIntent = {
		kind: "new-contract",
		params: {}
	};
	copyIntent = computed(() => ({
		kind: "new-contract",
		params: { copyFrom: this.contractNumber() }
	}), ...ngDevMode ? [{ debugName: "copyIntent" }] : /* istanbul ignore next */ []);
	cancelIntent = computed(() => this.isCreate() ? {
		kind: "origin",
		origin: "contracts",
		params: {}
	} : {
		kind: "contract",
		contractNumber: this.contractNumber(),
		params: this.cancelParams()
	}, ...ngDevMode ? [{ debugName: "cancelIntent" }] : /* istanbul ignore next */ []);
	crumbs = computed(() => this.trail().map((crumb, index) => {
		const intent = index === 0 ? {
			kind: "origin",
			origin: this.originParam ?? "",
			params: this.returnParams()
		} : {
			kind: "review",
			origin: this.originParam ?? "",
			contractNumber: this.contractNumber(),
			params: this.returnParams()
		};
		return {
			...crumb,
			link: {
				href: this.hrefFor(intent),
				follow: (event) => this.follow(event, intent)
			}
		};
	}), ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	hrefFor(intent) {
		return this.hostContext.hrefFor(intent);
	}
	follow(event, intent) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.requestNavigation(intent);
	}
	currentCrumb = computed(() => {
		switch (this.mode()) {
			case "create": return "New contract";
			case "edit": return `${this.contractNumber()} — editing`;
			default: return this.contractNumber();
		}
	}, ...ngDevMode ? [{ debugName: "currentCrumb" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	createDrivers = signal({}, ...ngDevMode ? [{ debugName: "createDrivers" }] : /* istanbul ignore next */ []);
	resolutionKey = computed(() => {
		this.attempt();
		if (!this.isCreate() && this.contractNumber() !== "") return { contractNumber: this.contractNumber() };
		const drivers = this.createDrivers();
		return {
			...this.tradeUnit.code() !== null ? { locationCode: this.tradeUnit.code() } : {},
			...drivers.textClass !== void 0 ? { contractTypeClass: drivers.textClass } : {},
			...drivers.commodity !== void 0 ? { commodityCode: drivers.commodity } : {}
		};
	}, ...ngDevMode ? [{ debugName: "resolutionKey" }] : /* istanbul ignore next */ []);
	configState = toSignal(toObservable(this.resolutionKey).pipe(switchMap((key) => this.configs.load(key))), { initialValue: remoteLoading() });
	retainedBundle = linkedSignal({
		...ngDevMode ? { debugName: "retainedBundle" } : /* istanbul ignore next */ {},
		source: this.configState,
		computation: (state, previous) => state.status === "loaded" ? state.value : previous?.value ?? null
	});
	bundle = computed(() => {
		const retained = this.retainedBundle();
		return retained === null ? null : {
			...retained,
			config: withMarketMonths(withResolvedTrader(retained.config, this.contract()), this.marketMonths())
		};
	}, ...ngDevMode ? [{ debugName: "bundle" }] : /* istanbul ignore next */ []);
	containerState = computed(() => {
		const config = this.configState();
		const retained = this.retainedBundle();
		if (config.status === "error" || config.status !== "loaded" && retained === null) return config;
		const aggregate = this.aggregate();
		if (aggregate !== null && aggregate.status !== "loaded") return aggregate;
		return config.status === "loaded" ? config : remoteLoaded(retained);
	}, ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	aggregate = toSignal(toObservable(computed(() => ({
		number: this.contractNumber(),
		create: this.isCreate(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ number, create }) => create || number.trim().length === 0 ? of(null) : this.details.get(number))), { initialValue: null });
	response = computed(() => {
		const override = this.stateOverride();
		if (override !== null && override.contract.header.contractNumber === this.contractNumber()) return override;
		const state = this.aggregate();
		return state !== null && state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "response" }] : /* istanbul ignore next */ []);
	lastAnnouncedLoad = null;
	announceLoad = effect(() => {
		const state = this.aggregate();
		const mode = this.mode();
		const contractNumber = this.contractNumber();
		if (state === null || mode === "create" || state.status !== "loaded" && state.status !== "error") return;
		const key = `${this.attempt()}|${contractNumber}|${state.status}`;
		if (key === this.lastAnnouncedLoad) return;
		this.lastAnnouncedLoad = key;
		untracked(() => this.events.emit(state.status === "loaded" ? {
			type: "contract-opened",
			contractNumber,
			mode
		} : {
			type: "error",
			operation: "load",
			contractNumber,
			message: state.error.message,
			...state.error.correlationId === void 0 ? {} : { correlationId: state.error.correlationId }
		}));
	}, ...ngDevMode ? [{ debugName: "announceLoad" }] : /* istanbul ignore next */ []);
	contract = computed(() => this.response()?.contract ?? null, ...ngDevMode ? [{ debugName: "contract" }] : /* istanbul ignore next */ []);
	prefill = toSignal(toObservable(computed(() => ({
		number: this.contractNumber(),
		create: this.isCreate(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ number, create }) => create || number.trim().length === 0 ? of({ status: "absent" }) : this.writes.fields(number).pipe(map((value) => ({
		status: "loaded",
		fields: value.fields
	})), catchError(() => of({ status: "failed" })), startWith({ status: "loading" })))), { initialValue: { status: "loading" } });
	copySource = toSignal(toObservable(computed(() => ({
		source: this.copyFrom,
		create: this.isCreate(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ source, create }) => !create || source === null || source.trim().length === 0 ? of({ status: "absent" }) : this.writes.fields(source).pipe(map((value) => ({
		status: "loaded",
		fields: value.fields
	})), catchError(() => of({ status: "failed" })), startWith({ status: "loading" })))), { initialValue: { status: "loading" } });
	isCopy = computed(() => this.isCreate() && this.copyFrom !== null && this.copyFrom.trim().length > 0, ...ngDevMode ? [{ debugName: "isCopy" }] : /* istanbul ignore next */ []);
	copyFailed = computed(() => this.isCopy() && this.copySource().status === "failed", ...ngDevMode ? [{ debugName: "copyFailed" }] : /* istanbul ignore next */ []);
	copiedValues = computed(() => {
		const state = this.copySource();
		if (state.status !== "loaded") return {};
		return copyableValues(state.fields, copyExclusions(this.bundle()?.config ?? null));
	}, ...ngDevMode ? [{ debugName: "copiedValues" }] : /* istanbul ignore next */ []);
	valuesReady = computed(() => {
		if (this.isCreate()) {
			const copy = this.copySource().status;
			return !this.isCopy() || copy === "loaded" || copy === "failed";
		}
		const status = this.prefill().status;
		return status === "loaded" || status === "failed";
	}, ...ngDevMode ? [{ debugName: "valuesReady" }] : /* istanbul ignore next */ []);
	ctrmValues = computed(() => {
		const state = this.prefill();
		return state.status === "loaded" ? state.fields : null;
	}, ...ngDevMode ? [{ debugName: "ctrmValues" }] : /* istanbul ignore next */ []);
	values = computed(() => mergeContractValues(this.contract(), this.ctrmValues()), ...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	initialValues = computed(() => seedFromCtrmValues(this.values()), ...ngDevMode ? [{ debugName: "initialValues" }] : /* istanbul ignore next */ []);
	defaultValues = computed(() => {
		if (!this.isCreate()) return {};
		const code = this.tradeUnit.code();
		const issued = this.issuedNumber();
		return {
			...code === null || code === "" ? {} : { Location: code },
			...this.copiedValues(),
			...issued === null ? {} : { ContractNumber: issued },
			...this.carried()
		};
	}, ...ngDevMode ? [{ debugName: "defaultValues" }] : /* istanbul ignore next */ []);
	prefillFailed = computed(() => !this.isCreate() && this.bundle() !== null && this.prefill().status === "failed", ...ngDevMode ? [{ debugName: "prefillFailed" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => this.response()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.response()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	unavailableLists = computed(() => this.bundle()?.unavailableLists ?? [], ...ngDevMode ? [{ debugName: "unavailableLists" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [
		...this.isSimulated() ? ["Simulated contract, not read from CTRM"] : [],
		...this.isCopy() && !this.copyFailed() ? [`Copied from ${this.copyFrom} — pricing and collections were not carried across`] : [],
		...this.isCreate() ? ["Confirmations and quantities appear once this contract is saved"] : [],
		...this.isEditable() ? ["Shipment dates are optional on this contract"] : [],
		...this.configDefaultsOnly() ? ["Showing default field settings"] : [],
		...this.isEditable() && this.unavailableLists().length > 0 ? ["Some code lists are unavailable"] : [],
		...this.unmodelled().length > 0 ? [`${this.unmodelled().length} CTRM collections on this contract are not read by CMS`] : [],
		...this.provenanceLabel() !== null ? [this.provenanceLabel()] : [],
		...this.warnings()
	], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	unmodelled = computed(() => this.response()?.unmodelledCollections ?? [], ...ngDevMode ? [{ debugName: "unmodelled" }] : /* istanbul ignore next */ []);
	stages = CONFIRMATION_STAGES;
	fieldNotes = computed(() => {
		const allocation = this.shipPeriodAllocation();
		const confirmation = this.customerConfirmation();
		return {
			...CONTRACT_LAYOUT_FIELD_NOTES,
			...allocation === null ? {} : { Quantity: allocation },
			...confirmation === null ? {} : { CustomerId: confirmation.note }
		};
	}, ...ngDevMode ? [{ debugName: "fieldNotes" }] : /* istanbul ignore next */ []);
	shipPeriodAllocation = computed(() => {
		const periods = this.contract()?.shipPeriods ?? [];
		if (periods.length === 0) return null;
		const allocated = periods.reduce((total, period) => total + (period.quantity ?? 0), 0);
		const lead = `This contract’s ${periods.length === 1 ? "shipment period allocates" : `${periods.length} shipment periods allocate`} ${allocated.toLocaleString("en-US")}.`;
		if (this.shipPeriodGateBlocks()) return `${lead} That no longer matches the quantity entered, so this cannot be saved: ${this.shipPeriodReconciliation()?.summary ?? ""}. CTRM requires them to sum, and the periods have to change with it — which this screen cannot do yet.`;
		return `${lead} CTRM requires them to sum to the contract quantity, so changing this on its own is refused — the periods have to change with it, and this screen cannot edit them yet.`;
	}, ...ngDevMode ? [{ debugName: "shipPeriodAllocation" }] : /* istanbul ignore next */ []);
	headerQuantity = signal(null, ...ngDevMode ? [{ debugName: "headerQuantity" }] : /* istanbul ignore next */ []);
	seededShipPeriods = signal([], ...ngDevMode ? [{ debugName: "seededShipPeriods" }] : /* istanbul ignore next */ []);
	shipPeriodRows = signal([], ...ngDevMode ? [{ debugName: "shipPeriodRows" }] : /* istanbul ignore next */ []);
	shipPeriodsChanged = computed(() => !sameShipPeriods(this.shipPeriodRows(), this.seededShipPeriods()), ...ngDevMode ? [{ debugName: "shipPeriodsChanged" }] : /* istanbul ignore next */ []);
	maxShipPeriods = MAX_SHIP_PERIODS;
	nextShipPeriodProposal = computed(() => nextShipPeriod(this.shipPeriodRows()), ...ngDevMode ? [{ debugName: "nextShipPeriodProposal" }] : /* istanbul ignore next */ []);
	shipPeriodValidation = computed(() => validateShipPeriods(this.shipPeriodRows(), todayIso()), ...ngDevMode ? [{ debugName: "shipPeriodValidation" }] : /* istanbul ignore next */ []);
	shipPeriodIssues = computed(() => {
		const issues = /* @__PURE__ */ new Map();
		for (const issue of this.shipPeriodValidation()) {
			if (issue.rowIndex === null) continue;
			const held = issues.get(issue.rowIndex);
			if (held === void 0) issues.set(issue.rowIndex, [issue]);
			else held.push(issue);
		}
		return issues;
	}, ...ngDevMode ? [{ debugName: "shipPeriodIssues" }] : /* istanbul ignore next */ []);
	shipPeriodCollectionIssues = computed(() => this.shipPeriodValidation().filter((issue) => issue.rowIndex === null), ...ngDevMode ? [{ debugName: "shipPeriodCollectionIssues" }] : /* istanbul ignore next */ []);
	shipPeriodsOverlap = computed(() => hasOverlappingPeriods(this.shipPeriodRows()), ...ngDevMode ? [{ debugName: "shipPeriodsOverlap" }] : /* istanbul ignore next */ []);
	seedShipPeriods = effect(() => {
		const periods = this.contract()?.shipPeriods;
		if (periods === void 0) return;
		const rows = periods.map((period) => ({
			beginDate: period.begin,
			endDate: period.end,
			quantity: period.quantity
		}));
		untracked(() => {
			this.seededShipPeriods.set(rows);
			this.shipPeriodRows.set(rows);
		});
	}, ...ngDevMode ? [{ debugName: "seedShipPeriods" }] : /* istanbul ignore next */ []);
	addShipPeriod() {
		const proposal = this.nextShipPeriodProposal();
		if (proposal === null) return;
		this.shipPeriodRows.update((rows) => [...rows, proposal]);
		this.regenerateShipPeriodDescription();
	}
	shipPeriodCollections() {
		if (!this.shipPeriodsChanged()) return;
		return { ship_periods: this.shipPeriodRows().map((row) => ({
			begin_ship_date: row.beginDate,
			end_ship_date: row.endDate,
			ship_quantity: row.quantity
		})) };
	}
	removeShipPeriod(index) {
		this.shipPeriodRows.update((rows) => rows.filter((_, position) => position !== index));
		this.regenerateShipPeriodDescription();
	}
	setShipPeriodDate(index, edge, input) {
		const parsed = parseShipPeriodDate(input, (/* @__PURE__ */ new Date()).getFullYear());
		this.shipPeriodRows.update((rows) => rows.map((row, position) => position === index ? {
			...row,
			[edge]: parsed
		} : row));
		this.regenerateShipPeriodDescription();
	}
	setShipPeriodQuantity(index, input) {
		const trimmed = input.trim();
		const parsed = trimmed === "" ? null : Number(trimmed);
		const quantity = parsed === null || Number.isNaN(parsed) ? null : parsed;
		this.shipPeriodRows.update((rows) => rows.map((row, position) => position === index ? {
			...row,
			quantity
		} : row));
	}
	regenerateShipPeriodDescription() {
		const control = this.form?.control("ShipPeriodDescription");
		if (control === void 0) return;
		const description = buildShipPeriodDescription(overallShipPeriod(this.shipPeriodRows()));
		control.setValue(description ?? "");
		control.markAsDirty();
	}
	shipPeriodReconciliation = computed(() => {
		const periods = this.shipPeriodRows();
		if (periods.length === 0) return null;
		return reconcileShipPeriods(periods, this.headerQuantity());
	}, ...ngDevMode ? [{ debugName: "shipPeriodReconciliation" }] : /* istanbul ignore next */ []);
	shipPeriodGateBlocks = computed(() => {
		const reconciliation = this.shipPeriodReconciliation();
		return reconciliation !== null && reconciliation.state !== ReconciliationState.Balanced;
	}, ...ngDevMode ? [{ debugName: "shipPeriodGateBlocks" }] : /* istanbul ignore next */ []);
	watchHeaderQuantity(form) {
		const control = form.control("Quantity");
		if (control === void 0) {
			this.headerQuantity.set(this.contract()?.header.quantity ?? null);
			return;
		}
		const read = () => {
			const held = control.value;
			if (held === null || held === void 0 || held === "") return null;
			const parsed = typeof held === "number" ? held : Number(held);
			return Number.isFinite(parsed) ? parsed : null;
		};
		this.headerQuantity.set(read());
		control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.headerQuantity.set(read()));
	}
	emptyNotes = CONTRACT_LAYOUT_EMPTY_NOTES;
	sectionNotes = CONTRACT_LAYOUT_SECTION_NOTES;
	wideFields = CONTRACT_LAYOUT_WIDE_FIELDS;
	halfFields = CONTRACT_LAYOUT_HALF_FIELDS;
	groupHeadings = CONTRACT_LAYOUT_GROUP_HEADINGS;
	hiddenLabelFields = CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS;
	fieldCtrmNames = CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT;
	readOnlyFields = computed(() => ({
		...CONTRACT_READ_ONLY_FIELDS,
		...Object.fromEntries(this.cascade().derived.map((field) => [CASCADE_COMPONENTS[field], true]))
	}), ...ngDevMode ? [{ debugName: "readOnlyFields" }] : /* istanbul ignore next */ []);
	tabParam = toSignal(this.route.queryParamMap, { initialValue: null });
	configuredTabs = computed(() => {
		const resolved = this.bundle()?.config;
		const configured = [...tabsAfterCascade(resolved?.tabs ?? [], resolved?.sections ?? [])].sort((left, right) => left.order - right.order).map((tab) => ({
			id: tab.id,
			label: tab.label
		}));
		const tabs = configured.length > 0 ? configured : CONTRACT_TABS;
		const withDocuments = this.canReadDocuments() ? [...tabs, DOCUMENTS_TAB] : tabs;
		return this.canReadLog() ? [...withDocuments, LOG_TAB] : withDocuments;
	}, ...ngDevMode ? [{ debugName: "configuredTabs" }] : /* istanbul ignore next */ []);
	activeTab = computed(() => {
		const requested = this.tabParam()?.get("tab");
		const available = this.configuredTabs();
		return available.some((tab) => tab.id === requested) ? requested : available[0].id;
	}, ...ngDevMode ? [{ debugName: "activeTab" }] : /* istanbul ignore next */ []);
	tabs = computed(() => this.configuredTabs().map((tab) => ({
		...tab,
		count: tab.id === DOCUMENTS_TAB.id ? null : tab.id === LOG_TAB.id ? this.logCount() : this.countFor(tab.id),
		current: tab.id === this.activeTab()
	})), ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	tabOfSection = computed(() => {
		const configured = this.bundle()?.config.sections ?? [];
		if (configured.length === 0) return new Map(CONTRACT_LAYOUT_SECTIONS.map((section) => [section.id, section.tab]));
		return new Map(configured.map((section) => [section.componentName, section.tab]));
	}, ...ngDevMode ? [{ debugName: "tabOfSection" }] : /* istanbul ignore next */ []);
	visibleSections = computed(() => {
		const active = this.activeTab();
		return (this.bundle()?.config.sections ?? []).filter((section) => this.tabFor(section.componentName) === active).map((section) => section.componentName);
	}, ...ngDevMode ? [{ debugName: "visibleSections" }] : /* istanbul ignore next */ []);
	tabFor(sectionId) {
		return this.tabOfSection().get(sectionId) ?? this.configuredTabs()[0].id;
	}
	showShipPeriods = computed(() => this.activeTab() === "shipping", ...ngDevMode ? [{ debugName: "showShipPeriods" }] : /* istanbul ignore next */ []);
	showPrices = computed(() => this.activeTab() === "pricing", ...ngDevMode ? [{ debugName: "showPrices" }] : /* istanbul ignore next */ []);
	showRemarks = computed(() => this.activeTab() === "remarks", ...ngDevMode ? [{ debugName: "showRemarks" }] : /* istanbul ignore next */ []);
	countFor(tab) {
		return (this.bundle()?.config.sections ?? []).filter((section) => this.tabFor(section.componentName) === tab).reduce((total, section) => total + section.fields.filter((field) => field.behaviour.visible).length, 0) + (tab === "remarks" ? 2 : tab === "shipping" || tab === "pricing" ? 1 : 0);
	}
	paramsForTab(tab) {
		return this.returnTo === null ? { tab } : {
			tab,
			returnTo: this.returnTo
		};
	}
	editParams = computed(() => this.paramsForTab(this.activeTab()), ...ngDevMode ? [{ debugName: "editParams" }] : /* istanbul ignore next */ []);
	cancelParams = computed(() => this.isCreate() ? {} : this.paramsForTab(this.activeTab()), ...ngDevMode ? [{ debugName: "cancelParams" }] : /* istanbul ignore next */ []);
	contractDateLabel = computed(() => {
		const date = this.contract()?.header.contractDate ?? null;
		return date === null ? null : formatContractDate(date);
	}, ...ngDevMode ? [{ debugName: "contractDateLabel" }] : /* istanbul ignore next */ []);
	traderLabel = computed(() => {
		const header = this.contract()?.header;
		const initials = header?.traderInitials?.trim() || null;
		const name = header?.trader?.trim() || null;
		if (initials && name) return `${initials} — ${name}`;
		return initials ?? name;
	}, ...ngDevMode ? [{ debugName: "traderLabel" }] : /* istanbul ignore next */ []);
	quantityBreakdown = computed(() => {
		const q = this.contract()?.quantities ?? null;
		const uom = this.contract()?.header.quantityUom ?? null;
		return [
			{
				label: "Unpriced",
				value: q?.unpriced ?? null,
				uom
			},
			{
				label: "Priced",
				value: q?.priced ?? null,
				uom
			},
			{
				label: "Unshipped",
				value: q?.unshipped ?? null,
				uom
			},
			{
				label: "Applied",
				value: q?.applied ?? null,
				uom
			},
			{
				label: "Settled",
				value: q?.settled ?? null,
				uom
			},
			{
				label: "Open",
				value: q?.open ?? null,
				uom
			}
		];
	}, ...ngDevMode ? [{ debugName: "quantityBreakdown" }] : /* istanbul ignore next */ []);
	confirmations = computed(() => {
		const contract = this.contract();
		return this.stages.map((stage) => {
			const badge = contract === null ? null : contractStatusBadge(stage.value(contract));
			return {
				label: stage.label,
				badge,
				style: CONFIRMATION_STYLE[badge?.tone ?? "neutral"],
				emptyNote: this.isCreate() ? this.pendingNote : stage.emptyNote
			};
		});
	}, ...ngDevMode ? [{ debugName: "confirmations" }] : /* istanbul ignore next */ []);
	pendingNote = "available once the contract is saved";
	shipPeriodSorts = signal([], ...ngDevMode ? [{ debugName: "shipPeriodSorts" }] : /* istanbul ignore next */ []);
	priceSorts = signal([], ...ngDevMode ? [{ debugName: "priceSorts" }] : /* istanbul ignore next */ []);
	sortedShipPeriods = computed(() => this.sortCollection(this.contract()?.shipPeriods ?? [], this.shipPeriodSorts(), this.shipPeriodColumns), ...ngDevMode ? [{ debugName: "sortedShipPeriods" }] : /* istanbul ignore next */ []);
	sortedPrices = computed(() => this.sortCollection(this.contract()?.prices ?? [], this.priceSorts(), this.priceColumns), ...ngDevMode ? [{ debugName: "sortedPrices" }] : /* istanbul ignore next */ []);
	sortCollection(rows, sorts, columns) {
		if (sorts.length === 0) return rows;
		return [...rows].sort((left, right) => compareBySorts(columns, sorts, left, right));
	}
	shipPeriodColumns = [
		{
			key: "order",
			header: "#",
			width: 60,
			format: (row) => String(row.order),
			sortValue: (row) => row.order,
			sortable: true
		},
		{
			key: "begin",
			header: "Begins",
			width: 150,
			format: (row) => formatFieldValue(row.begin, "date"),
			sortValue: (row) => row.begin ?? "",
			sortable: true
		},
		{
			key: "end",
			header: "Ends",
			width: 150,
			format: (row) => formatFieldValue(row.end, "date"),
			sortValue: (row) => row.end ?? "",
			sortable: true
		},
		{
			key: "quantity",
			header: "Quantity",
			align: "end",
			width: 130,
			format: (row) => formatFieldValue(row.quantity, "quantity"),
			sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "latePickup",
			header: "Late pickup",
			width: 150,
			format: (row) => formatFieldValue(row.latePickup, "date"),
			sortValue: (row) => row.latePickup ?? "",
			sortable: true
		},
		{
			key: "earlyDelivery",
			header: "Early delivery",
			width: 150,
			format: (row) => formatFieldValue(row.earlyDelivery, "date"),
			sortValue: (row) => row.earlyDelivery ?? "",
			sortable: true
		}
	];
	priceColumns = [
		{
			key: "sequence",
			header: "Seq",
			width: 70,
			format: (row) => row.sequence === null ? "" : String(row.sequence),
			sortValue: (row) => row.sequence ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "quantity",
			header: "Quantity",
			align: "end",
			width: 130,
			format: (row) => formatFieldValue(row.quantity, "quantity"),
			sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "flatPrice",
			header: "Flat price",
			align: "end",
			width: 120,
			format: (row) => formatFieldValue(row.flatPrice, "price"),
			sortValue: (row) => row.flatPrice ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "basisPrice",
			header: "Basis",
			align: "end",
			width: 110,
			format: (row) => formatFieldValue(row.basisPrice, "price"),
			sortValue: (row) => row.basisPrice ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "hedgePrice",
			header: "Hedge",
			align: "end",
			width: 110,
			format: (row) => formatFieldValue(row.hedgePrice, "price"),
			sortValue: (row) => row.hedgePrice ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "freightAdjustment",
			header: "Freight adj",
			align: "end",
			width: 120,
			format: (row) => formatFieldValue(row.freightAdjustment, "price"),
			sortValue: (row) => row.freightAdjustment ?? Number.NEGATIVE_INFINITY,
			sortable: true
		},
		{
			key: "marketMonth",
			header: "Market month",
			width: 150,
			format: (row) => row.marketMonthDescription ?? row.marketMonth ?? ""
		},
		{
			key: "priceDate",
			header: "Price date",
			width: 150,
			format: (row) => formatFieldValue(row.priceDate, "date"),
			sortValue: (row) => row.priceDate ?? "",
			sortable: true
		},
		{
			key: "remark",
			header: "Remark",
			width: 220,
			format: (row) => row.remark ?? "",
			sortable: true
		}
	];
	readable(name) {
		return name.replace(/_/g, " ");
	}
	save = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "save" }] : /* istanbul ignore next */ []);
	form = null;
	onFieldBlur(componentName) {
		if (componentName !== "CustomerId" || this.isView() || this.customers === null) return;
		const form = this.form;
		if (form === null) return;
		const raw = form.control("CustomerId")?.value;
		const id = typeof raw === "string" ? raw.trim() : "";
		if (id === "") {
			this.customerConfirmation.set(null);
			return;
		}
		if (this.customerConfirmation()?.id === id) return;
		this.customerConfirmation.set({
			id,
			note: "Looking up the customer…",
			name: null
		});
		this.customers.lookup(id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => {
			if (this.customerConfirmation()?.id !== id || state.status === "loading") return;
			if (state.status === "error") {
				this.customerConfirmation.set({
					id,
					note: state.error.message,
					name: null
				});
				return;
			}
			if (state.status !== "loaded") return;
			const { availability, name: rawName } = state.value;
			const name = isRedactedName(rawName) ? null : rawName?.trim() || null;
			switch (availability) {
				case "Resolved":
					this.customerConfirmation.set({
						id,
						note: name === null ? "The customer directory returned no usable name for this account." : `Confirmed: ${name}`,
						name
					});
					break;
				case "Redacted":
					this.customerConfirmation.set({
						id,
						note: "The customer's name is withheld for this application. The account number is still correct; showing the name needs a person to enable it.",
						name: null
					});
					break;
				case "Unknown": this.customerConfirmation.set({
					id,
					note: "No customer record matches this account number.",
					name: null
				});
			}
			form.seed({ CustomerName: this.customerConfirmation()?.name ?? null });
		});
	}
	onFormReady(form) {
		this.form = form;
		this.builtForm.set(form);
		this.watchCascadeInputs(form);
		this.watchHeaderQuantity(form);
		this.watchDraft(form);
		this.watchSpecialType(form);
		if (this.isCreate()) {
			this.watchDrivers(form);
			this.watchPrefixesForNumber(form);
		}
	}
	liveSpecialType = signal(void 0, ...ngDevMode ? [{ debugName: "liveSpecialType" }] : /* istanbul ignore next */ []);
	watchSpecialType(form) {
		const control = form.control("SpecialType");
		if (control === void 0) {
			this.liveSpecialType.set(void 0);
			return;
		}
		const read = () => typeof control.value === "string" ? control.value : null;
		this.liveSpecialType.set(read());
		control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.liveSpecialType.set(read()));
	}
	addendumFieldSet = computed(() => {
		const live = this.liveSpecialType();
		return addendumFieldSetFor(live !== void 0 ? live : this.ctrmFieldValue("special_type"));
	}, ...ngDevMode ? [{ debugName: "addendumFieldSet" }] : /* istanbul ignore next */ []);
	addendumTab = computed(() => {
		const section = (this.bundle()?.config.sections ?? []).find((candidate) => candidate.fields.some((field) => field.componentName === "SpecialType"))?.componentName ?? CONTRACT_LAYOUT_SECTIONS.find((candidate) => candidate.fields.some((field) => field.componentName === "SpecialType"))?.id;
		return section === void 0 ? this.configuredTabs()[0].id : this.tabFor(section);
	}, ...ngDevMode ? [{ debugName: "addendumTab" }] : /* istanbul ignore next */ []);
	showAddendum = computed(() => this.addendumFieldSet() !== null && this.activeTab() === this.addendumTab(), ...ngDevMode ? [{ debugName: "showAddendum" }] : /* istanbul ignore next */ []);
	addendumTradeUnit = computed(() => this.contract()?.header.tradeUnit ?? this.tradeUnit.code() ?? null, ...ngDevMode ? [{ debugName: "addendumTradeUnit" }] : /* istanbul ignore next */ []);
	markets = inject(MARKET_REFERENCE_SOURCE);
	builtForm = signal(null, ...ngDevMode ? [{ debugName: "builtForm" }] : /* istanbul ignore next */ []);
	cascadeFacts = signal(null, ...ngDevMode ? [{ debugName: "cascadeFacts" }] : /* istanbul ignore next */ []);
	watchCascadeInputs(form) {
		const snapshot = () => {
			const read = (componentName) => {
				const held = form.control(componentName)?.value;
				return typeof held === "string" && held.trim() !== "" ? held.trim() : null;
			};
			return {
				location: read("Location"),
				commodityCode: read("CommodityCode"),
				priceType: read(CASCADE_COMPONENTS.priceType),
				priceMarketCode: read(CASCADE_COMPONENTS.priceMarketCode),
				priceMarketMonth: read(CASCADE_COMPONENTS.priceMarketMonth),
				hedgeMarketCode: read(CASCADE_COMPONENTS.hedgeMarketCode),
				hedgeMarketMonth: read(CASCADE_COMPONENTS.hedgeMarketMonth)
			};
		};
		this.cascadeFacts.set(snapshot());
		form.group.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.cascadeFacts.set(snapshot()));
	}
	grainFactorsMarketCode = toSignal(toObservable(computed(() => {
		const facts = this.cascadeFacts();
		return facts === null || facts.location === null || facts.commodityCode === null ? null : {
			location: facts.location,
			commodityCode: facts.commodityCode
		};
	})).pipe(switchMap((key) => key === null ? of(void 0) : this.markets.marketCodes(key.location, key.commodityCode).pipe(map((rows) => rows === null ? void 0 : rows[0]?.code ?? null)))), { initialValue: void 0 });
	cascade = computed(() => {
		const facts = this.cascadeFacts();
		if (facts === null) return EMPTY_CASCADE;
		return marketCascade({
			priceType: facts.priceType,
			grainFactorsMarketCode: this.grainFactorsMarketCode(),
			priceMarketCode: facts.priceMarketCode,
			priceMarketMonth: facts.priceMarketMonth,
			hedgeMarketCode: facts.hedgeMarketCode,
			hedgeMarketMonth: facts.hedgeMarketMonth
		});
	}, ...ngDevMode ? [{ debugName: "cascade" }] : /* istanbul ignore next */ []);
	marketMonths = toSignal(toObservable(computed(() => {
		const facts = this.cascadeFacts();
		const marketCode = this.cascade().priceMarketCode;
		return facts === null || facts.location === null || facts.commodityCode === null || marketCode === null ? null : {
			location: facts.location,
			commodityCode: facts.commodityCode,
			marketCode
		};
	})).pipe(switchMap((key) => key === null ? of(null) : this.markets.marketMonths(key.location, key.commodityCode, key.marketCode))), { initialValue: null });
	applyCascade = effect(() => {
		const form = this.builtForm();
		const derived = this.cascade();
		if (form === null || this.isView()) return;
		for (const field of derived.derived) {
			const control = form.control(CASCADE_COMPONENTS[field]);
			const next = derived[field];
			if (control === void 0 || control.value === next) continue;
			control.setValue(next, { emitEvent: false });
			control.markAsPristine();
		}
	}, ...ngDevMode ? [{ debugName: "applyCascade" }] : /* istanbul ignore next */ []);
	watchPrefixesForNumber(form) {
		const controls = ["ContractPrefixType", "ContractPrefixCommodity"].map((componentName) => form.control(componentName)).filter((control) => control !== void 0);
		if (controls.length !== 2) return;
		for (const control of controls) control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.issueNumberIfReady(form));
		this.issueNumberIfReady(form);
	}
	issueNumberIfReady(form) {
		if (this.hasRequestedNumber || !this.tradeUnitPendingEnabled()) return;
		const prefixType = this.singleCharacter(form, "ContractPrefixType");
		const prefixCommodity = this.singleCharacter(form, "ContractPrefixCommodity");
		if (prefixType === null || prefixCommodity === null) return;
		const existing = form.control("ContractNumber");
		if (typeof existing?.value === "string" && existing.value.trim() !== "") return;
		this.hasRequestedNumber = true;
		this.numberIssue.set({ status: "issuing" });
		const suffix = this.singleCharacter(form, "ContractSuffix");
		this.numbers.issue({
			prefixType,
			prefixCommodity,
			...suffix === null ? {} : { suffix }
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (issued) => {
				this.issuedNumber.set(issued.numberComponent);
				this.numberIssue.set({ status: "issued" });
				const control = form.control("ContractNumber");
				if (control === void 0) return;
				control.setValue(issued.numberComponent);
				control.markAsDirty();
			},
			error: (error) => {
				this.numberIssue.set({
					status: "failed",
					message: this.numberIssueMessageFor(error)
				});
			}
		});
	}
	singleCharacter(form, componentName) {
		const value = form.control(componentName)?.value;
		const text = typeof value === "string" ? value.trim() : "";
		return text.length === 1 ? text : null;
	}
	numberIssueMessageFor(error) {
		const status = error?.status;
		if (status === 403) return "You do not have permission to issue a contract number. Type one, or ask for the contract-writer role.";
		if (status === 503) return "This environment cannot issue a real contract number, so none was requested. Type one instead — a simulated number would look real and would be saved against a real contract.";
		const condition = numberIssueConditionOf(error);
		return condition === null ? NUMBER_ISSUE_GENERIC_MESSAGE : messageForNumberIssueCondition(condition);
	}
	issuedNumber = signal(null, ...ngDevMode ? [{ debugName: "issuedNumber" }] : /* istanbul ignore next */ []);
	hasRequestedNumber = false;
	tradeUnitPendingEnabled = computed(() => this.bundle()?.tradeUnit.pendingContractsEnabled === true, ...ngDevMode ? [{ debugName: "tradeUnitPendingEnabled" }] : /* istanbul ignore next */ []);
	numberIssue = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "numberIssue" }] : /* istanbul ignore next */ []);
	numberIssueFailure = computed(() => this.isCreate() && this.numberIssue().status === "failed" ? this.numberIssue().message ?? null : null, ...ngDevMode ? [{ debugName: "numberIssueFailure" }] : /* istanbul ignore next */ []);
	watchDrivers(form) {
		for (const [componentName, apply] of DRIVER_COMPONENTS) {
			const control = form.control(componentName);
			if (control === void 0) continue;
			control.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((value) => {
				const next = typeof value === "string" ? value.trim() : "";
				if (next === (apply === "textClass" ? this.lastTextCode : this.lastCommodity)) return;
				if (apply === "textClass") this.lastTextCode = next;
				else this.lastCommodity = next;
				this.carried.set(this.dirtyValues(form));
				this.createDrivers.update((drivers) => ({
					...drivers,
					[apply === "textClass" ? "textClass" : "commodity"]: next === "" ? void 0 : next
				}));
			});
		}
	}
	lastTextCode = "";
	lastCommodity = "";
	destroyRef = inject(DestroyRef);
	carried = signal({}, ...ngDevMode ? [{ debugName: "carried" }] : /* istanbul ignore next */ []);
	dirtyValues(form) {
		const values = {};
		for (const field of CONTRACT_WRITABLE_FIELDS) {
			const control = form.control(field.componentName);
			if (control !== void 0 && control.dirty) values[field.componentName] = control.value;
		}
		return values;
	}
	formKey = computed(() => this.bundle()?.config.version ?? "none", ...ngDevMode ? [{ debugName: "formKey" }] : /* istanbul ignore next */ []);
	provenanceLabel = computed(() => {
		const provenance = this.bundle()?.provenance;
		if (provenance === void 0) return null;
		return `Configuration: ${provenance.matchedDimensions.length === 0 ? "any type · any location · any commodity" : provenance.matchedDimensions.map(DIMENSION_LABELS).join(" · ")}${provenance.version === null ? "" : ` · v${provenance.version}`}${provenance.effectiveFrom === null ? "" : ` · effective ${provenance.effectiveFrom}`}`;
	}, ...ngDevMode ? [{ debugName: "provenanceLabel" }] : /* istanbul ignore next */ []);
	configDefaultsOnly = computed(() => this.bundle()?.defaultsOnly === true, ...ngDevMode ? [{ debugName: "configDefaultsOnly" }] : /* istanbul ignore next */ []);
	retry() {
		this.reissue();
	}
	refresh() {
		this.reissue();
	}
	isRefreshing = computed(() => this.containerState().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	reissue() {
		this.attempt.update((attempt) => attempt + 1);
	}
	availability = inject(AvailabilityGate);
	canWrite = computed(() => this.permissions.canWriteContracts() && !this.availability.writesBlocked(), ...ngDevMode ? [{ debugName: "canWrite" }] : /* istanbul ignore next */ []);
	canWriteCws = computed(() => this.permissions.canWriteContracts(), ...ngDevMode ? [{ debugName: "canWriteCws" }] : /* istanbul ignore next */ []);
	blockedByAvailability = computed(() => this.availability.writesBlocked(), ...ngDevMode ? [{ debugName: "blockedByAvailability" }] : /* istanbul ignore next */ []);
	availabilityTitle = computed(() => this.availability.notice().title, ...ngDevMode ? [{ debugName: "availabilityTitle" }] : /* istanbul ignore next */ []);
	contractState = inject(CONTRACT_STATE_SOURCE, { optional: true });
	closeProvenanceWarning = CLOSE_PROVENANCE_WARNING;
	stateOverride = signal(null, ...ngDevMode ? [{ debugName: "stateOverride" }] : /* istanbul ignore next */ []);
	stateAction = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "stateAction" }] : /* istanbul ignore next */ []);
	isClosed = computed(() => this.contract()?.header.isClosed === true, ...ngDevMode ? [{ debugName: "isClosed" }] : /* istanbul ignore next */ []);
	canChangeState = computed(() => !this.isCreate() && this.contractState !== null && this.contract() !== null, ...ngDevMode ? [{ debugName: "canChangeState" }] : /* istanbul ignore next */ []);
	templates = inject(CONTRACT_TEMPLATE_SOURCE, { optional: true });
	templateName = signal("", ...ngDevMode ? [{ debugName: "templateName" }] : /* istanbul ignore next */ []);
	templateState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "templateState" }] : /* istanbul ignore next */ []);
	templateReload = signal(0, ...ngDevMode ? [{ debugName: "templateReload" }] : /* istanbul ignore next */ []);
	templateList = toSignal(toObservable(computed(() => ({
		unit: this.tradeUnit.code(),
		reload: this.templateReload()
	}))).pipe(switchMap(({ unit }) => this.templates === null || unit === null || unit === "" ? of(remoteLoaded([])) : this.templates.list(unit))), { initialValue: remoteLoaded([]) });
	availableTemplates = computed(() => {
		const state = this.templateList();
		return state.status === "loaded" ? state.value : [];
	}, ...ngDevMode ? [{ debugName: "availableTemplates" }] : /* istanbul ignore next */ []);
	templatesFailed = computed(() => this.templateList().status === "error", ...ngDevMode ? [{ debugName: "templatesFailed" }] : /* istanbul ignore next */ []);
	canUseTemplates = computed(() => this.templates !== null, ...ngDevMode ? [{ debugName: "canUseTemplates" }] : /* istanbul ignore next */ []);
	canSaveTemplate = computed(() => this.canUseTemplates() && this.canWriteCws() && !this.isCreate() && this.templateName().trim().length > 0 && this.templateState().status !== "saving", ...ngDevMode ? [{ debugName: "canSaveTemplate" }] : /* istanbul ignore next */ []);
	onTemplateNameInput(value) {
		this.templateName.set(value);
		if (this.templateState().status !== "idle") this.templateState.set({ status: "idle" });
	}
	onSaveTemplate() {
		const form = this.form;
		const unit = this.tradeUnit.code();
		if (this.templates === null || form === null || unit === null || !this.canSaveTemplate()) return;
		this.templateState.set({ status: "saving" });
		this.templates.save(unit, this.templateName().trim(), this.resolvedValues(form)).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: () => {
				this.templateName.set("");
				this.templateState.set({ status: "saved" });
				this.templateReload.update((count) => count + 1);
			},
			error: () => {
				this.templateState.set({
					status: "failed",
					message: "That template could not be saved. Try again."
				});
			}
		});
	}
	onApplyTemplate(templateId) {
		const template = this.availableTemplates().find((each) => String(each.id) === templateId);
		const form = this.form;
		if (template === void 0 || form === null) return;
		const values = templateValuesOf(template);
		const byCtrmField = new Map(CONTRACT_WRITABLE_FIELDS.map((field) => [field.ctrmField, field.componentName]));
		const seed = {};
		for (const [ctrmField, value] of Object.entries(values)) {
			const componentName = byCtrmField.get(ctrmField);
			if (componentName !== void 0 && (value === null || [
				"string",
				"number",
				"boolean"
			].includes(typeof value))) seed[componentName] = value;
		}
		form.seed(seed);
		this.appliedTemplate.set(template.name);
	}
	appliedTemplate = signal(null, ...ngDevMode ? [{ debugName: "appliedTemplate" }] : /* istanbul ignore next */ []);
	resolvedValues(form) {
		const values = {};
		for (const field of CONTRACT_WRITABLE_FIELDS) {
			const value = form.control(field.componentName)?.value;
			if (value === null || value === void 0 || value === "") continue;
			values[field.ctrmField] = value;
		}
		return values;
	}
	logSource = inject(CONTRACT_LOG_SOURCE, { optional: true });
	canReadLog = computed(() => !this.isCreate() && (this.logSource !== null || this.templates !== null), ...ngDevMode ? [{ debugName: "canReadLog" }] : /* istanbul ignore next */ []);
	showLog = computed(() => this.activeTab() === "log", ...ngDevMode ? [{ debugName: "showLog" }] : /* istanbul ignore next */ []);
	documentsSource = inject(CONTRACT_DOCUMENTS_SOURCE, { optional: true });
	canReadDocuments = computed(() => !this.isCreate() && this.documentsSource !== null, ...ngDevMode ? [{ debugName: "canReadDocuments" }] : /* istanbul ignore next */ []);
	showDocuments = computed(() => this.activeTab() === DOCUMENTS_TAB.id, ...ngDevMode ? [{ debugName: "showDocuments" }] : /* istanbul ignore next */ []);
	logAvailable = computed(() => this.logSource !== null, ...ngDevMode ? [{ debugName: "logAvailable" }] : /* istanbul ignore next */ []);
	auditTrail = toSignal(toObservable(computed(() => ({
		number: this.contractNumber(),
		attempt: this.attempt(),
		can: this.canReadLog()
	}))).pipe(switchMap(({ number, can }) => !can || this.logSource === null || number.trim().length === 0 ? of(remoteLoaded([])) : this.logSource.audit(number))), { initialValue: remoteLoading() });
	timeline = computed(() => {
		const trail = this.auditTrail();
		const contractRows = trail.status === "loaded" ? trail.value.map((entry) => {
			const summary = auditChangesOf(entry.detailsJson);
			return {
				kind: "contract",
				key: `c-${entry.id}`,
				at: entry.timestampUtc,
				atLabel: readableTimestamp(entry.timestampUtc),
				actor: entry.actorUpn,
				what: describeAuditAction(entry.action),
				detail: entry.detailsJson,
				changes: (summary?.changes ?? []).map((change) => ({
					label: this.labelForCtrmField(change.field),
					from: change.from,
					to: change.to
				})),
				collectionsReplaced: summary?.collectionsReplaced ?? []
			};
		}) : [];
		const configRows = this.configAudit().map((entry) => ({
			kind: "configuration",
			key: `f-${entry.auditId}`,
			at: entry.timestampUtc,
			atLabel: readableTimestamp(entry.timestampUtc),
			actor: entry.actorUpn,
			what: `Form configuration ${entry.changeType.toLowerCase()}`,
			detail: null,
			changes: [],
			collectionsReplaced: []
		}));
		return [...contractRows, ...configRows].sort((left, right) => right.at.localeCompare(left.at));
	}, ...ngDevMode ? [{ debugName: "timeline" }] : /* istanbul ignore next */ []);
	timelineState = computed(() => this.auditTrail().status, ...ngDevMode ? [{ debugName: "timelineState" }] : /* istanbul ignore next */ []);
	logCount = computed(() => this.auditTrail().status === "loaded" ? this.timeline().length : null, ...ngDevMode ? [{ debugName: "logCount" }] : /* istanbul ignore next */ []);
	labelForCtrmField(ctrmField) {
		const layoutField = CONTRACT_LAYOUT_FIELDS.find((field) => field.ctrmField === ctrmField);
		if (layoutField === void 0) return ctrmField;
		return (this.bundle()?.config.sections ?? []).flatMap((section) => section.fields).find((field) => field.componentName === layoutField.componentName)?.label ?? layoutField.label;
	}
	configAudit = signal([], ...ngDevMode ? [{ debugName: "configAudit" }] : /* istanbul ignore next */ []);
	noteText = signal("", ...ngDevMode ? [{ debugName: "noteText" }] : /* istanbul ignore next */ []);
	noteBytesRemaining = computed(() => remainingNoteBytes(this.noteText()), ...ngDevMode ? [{ debugName: "noteBytesRemaining" }] : /* istanbul ignore next */ []);
	noteRefusal = computed(() => noteSizeRefusal(this.noteText()), ...ngDevMode ? [{ debugName: "noteRefusal" }] : /* istanbul ignore next */ []);
	noteState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "noteState" }] : /* istanbul ignore next */ []);
	onNoteInput(value) {
		this.noteText.set(value);
		if (this.noteState().status !== "idle") this.noteState.set({ status: "idle" });
	}
	notesAreComplete = computed(() => !(this.response()?.warnings ?? []).some((warning) => warning.startsWith(NOTES_WARNING)), ...ngDevMode ? [{ debugName: "notesAreComplete" }] : /* istanbul ignore next */ []);
	canAddNote = computed(() => this.canWrite() && this.notesAreComplete() && this.noteText().trim().length > 0 && this.noteRefusal() === null && this.noteState().status !== "saving", ...ngDevMode ? [{ debugName: "canAddNote" }] : /* istanbul ignore next */ []);
	onAddNote() {
		if (!this.canAddNote()) return;
		const number = this.contractNumber();
		const existing = this.contract()?.notes ?? [];
		this.noteState.set({ status: "saving" });
		const notes = [...existing.map((note) => ({
			note_prefix: note.prefix,
			note_code: note.code,
			note: note.text
		})), {
			note_prefix: null,
			note_code: null,
			note: this.noteText().trim()
		}];
		this.writes.update(number, {}, { notes }).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: () => {
				this.noteText.set("");
				this.noteState.set({ status: "saved" });
				this.reissue();
			},
			error: () => {
				this.noteState.set({
					status: "failed",
					message: "That note could not be saved, and nothing on the contract has changed."
				});
			}
		});
	}
	notifyText = signal("", ...ngDevMode ? [{ debugName: "notifyText" }] : /* istanbul ignore next */ []);
	notifyState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "notifyState" }] : /* istanbul ignore next */ []);
	canNotify = computed(() => this.notifyText().trim().length > 0 && this.notifyState().status !== "sending", ...ngDevMode ? [{ debugName: "canNotify" }] : /* istanbul ignore next */ []);
	onNotifyInput(value) {
		this.notifyText.set(value);
		if (this.notifyState().status !== "idle") this.notifyState.set({ status: "idle" });
	}
	onNotifyTrader() {
		const source = this.logSource;
		const number = this.contractNumber();
		if (source === null || !this.canNotify()) return;
		this.notifyState.set({ status: "sending" });
		source.notifyTrader(number, this.notifyText().trim()).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: () => {
				this.notifyState.set({ status: "accepted" });
				this.notifyText.set("");
			},
			error: () => {
				this.notifyState.set({
					status: "failed",
					message: "That message could not be sent, and nobody has been notified. Try again."
				});
			}
		});
	}
	onCloseContract() {
		this.changeState("close", {
			title: "Close this contract?",
			message: `This contract will be closed in CTRM, and ${CLOSE_PROVENANCE_WARNING}. Re-opening it later does not restore what closing rewrote.`,
			confirmLabel: "Close contract",
			cancelLabel: "Keep it open",
			destructive: true
		});
	}
	onReopenContract() {
		this.changeState("reopen", {
			title: "Re-open this contract?",
			message: "This contract will be re-opened in CTRM. It does not restore the pricing-approval provenance that closing rewrote.",
			confirmLabel: "Re-open contract",
			cancelLabel: "Leave it closed"
		});
	}
	changeState(action, request) {
		const source = this.contractState;
		const number = this.contractNumber();
		if (source === null || number.trim().length === 0) return;
		this.confirm(request).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (!confirmed) return;
			this.stateAction.set({ status: "working" });
			(action === "close" ? source.close(number) : source.reopen(number)).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
				next: (response) => {
					this.stateOverride.set(response);
					this.stateAction.set({ status: "idle" });
				},
				error: () => {
					this.stateAction.set({
						status: "failed",
						message: action === "close" ? "This contract could not be closed, and it has not changed. Try again, or ask someone who can check CTRM." : "This contract could not be re-opened, and it has not changed. Try again, or ask someone who can check CTRM."
					});
				}
			});
		});
	}
	canSave = computed(() => this.isEditable() && this.canWrite() && this.save().status !== "saving" && this.bundle() !== null && !this.shipPeriodGateBlocks(), ...ngDevMode ? [{ debugName: "canSave" }] : /* istanbul ignore next */ []);
	onSave() {
		const form = this.form;
		if (form === null || !this.canSave()) return;
		const changed = this.payloadFor(form);
		const collections = this.shipPeriodCollections();
		this.leavingWithDraftKept = false;
		this.save.set({ status: "saving" });
		(this.isCreate() ? this.writes.create(changed, collections, { idempotencyKey: this.keyForCreate() }) : this.writes.update(this.contractNumber(), changed, collections)).subscribe({
			next: (result) => {
				this.save.set({
					status: "saved",
					result
				});
				this.events.emit({
					type: "contract-saved",
					contractNumber: result.contractNumber,
					action: result.action,
					warnings: result.warnings
				});
				this.clearDraft();
				this.isDirty.set(false);
				this.createKey = null;
				const closing = this.closeAfterSave;
				this.closeAfterSave = false;
				const destination = this.destinationAfter(result);
				if (closing) this.requestNavigation({
					kind: "origin",
					origin: this.originParam ?? "",
					params: this.returnParams()
				});
				else if (destination !== null) this.requestNavigation({
					kind: "contract",
					contractNumber: destination
				});
			},
			error: (error) => {
				this.closeAfterSave = false;
				const failed = readProblem(error);
				this.save.set({
					status: "failed",
					...failed
				});
				this.events.emit({
					type: "error",
					operation: "save",
					contractNumber: this.isCreate() ? null : this.contractNumber(),
					message: failed.failure === "outcome-unknown" ? "The contract may have been saved" : "The contract was not saved"
				});
				this.applyFieldErrors();
			}
		});
	}
	payloadFor(form) {
		const sendEverything = this.isCreate();
		const payload = {};
		for (const field of CONTRACT_WRITABLE_FIELDS) {
			const control = form.control(field.componentName);
			if (control === void 0 || !sendEverything && !control.dirty) continue;
			if (sendEverything && (control.value === null || control.value === void 0 || control.value === "")) continue;
			payload[field.ctrmField] = control.value;
		}
		return payload;
	}
	tabByCtrmField = TAB_BY_CTRM_FIELD;
	errorsByTab = computed(() => {
		const counts = /* @__PURE__ */ new Map();
		for (const ctrmField of Object.keys(this.save().fieldErrors ?? {})) {
			const tab = this.tabByCtrmField[ctrmField];
			if (tab !== void 0) counts.set(tab, (counts.get(tab) ?? 0) + 1);
		}
		return counts;
	}, ...ngDevMode ? [{ debugName: "errorsByTab" }] : /* istanbul ignore next */ []);
	unmappedErrors = computed(() => classifyInvalidParams(this.save().fieldErrors ?? {}).unrenderedFields.map(({ ctrmField, reasons }) => ({
		field: ctrmField,
		reasons
	})), ...ngDevMode ? [{ debugName: "unmappedErrors" }] : /* istanbul ignore next */ []);
	formLevelReasons = computed(() => [...this.save().formErrors ?? [], ...classifyInvalidParams(this.save().fieldErrors ?? {}).formReasons], ...ngDevMode ? [{ debugName: "formLevelReasons" }] : /* istanbul ignore next */ []);
	mappedErrors = computed(() => {
		const errors = this.save().fieldErrors ?? {};
		return CONTRACT_LAYOUT_FIELDS.flatMap((layoutField) => {
			const reasons = errors[layoutField.ctrmField];
			return reasons === void 0 ? [] : [{
				ctrmField: layoutField.ctrmField,
				componentName: layoutField.componentName,
				label: layoutField.label,
				tab: this.tabByCtrmField[layoutField.ctrmField] ?? CONTRACT_TABS[0].id,
				reasons
			}];
		});
	}, ...ngDevMode ? [{ debugName: "mappedErrors" }] : /* istanbul ignore next */ []);
	applyFieldErrors() {
		const form = this.form;
		const mapped = this.mappedErrors();
		if (form === null || mapped.length === 0) return;
		for (const error of mapped) {
			const control = form.control(error.componentName);
			if (control !== void 0) {
				control.markAsTouched();
				control.setErrors({
					...control.errors ?? {},
					server: error.reasons[0]
				});
			}
		}
		this.focusField(mapped[0]);
	}
	focusField(error) {
		this.requestNavigation({
			kind: "view-state",
			params: this.paramsForTab(error.tab)
		});
		queueMicrotask(() => {
			const element = document.getElementById(error.componentName);
			if (element !== null) element.focus();
		});
	}
	destinationAfter(result) {
		const expected = this.isCreate() ? "Created" : "Updated";
		if (result.action !== expected) return null;
		const number = result.contractNumber.trim().length > 0 ? result.contractNumber.trim() : this.contractNumber().trim();
		return number.length > 0 ? number : null;
	}
	drafts = inject(RECORD_DRAFT_STORE);
	isDirty = signal(false, ...ngDevMode ? [{ debugName: "isDirty" }] : /* istanbul ignore next */ []);
	draftKey = computed(() => {
		if (this.isView()) return null;
		const tradeUnit = this.tradeUnit.code();
		return tradeUnit === null || tradeUnit === "" ? null : {
			mode: this.mode(),
			contractNumber: this.contractNumber(),
			tradeUnit
		};
	}, ...ngDevMode ? [{ debugName: "draftKey" }] : /* istanbul ignore next */ []);
	recoverableDraft = signal(null, ...ngDevMode ? [{ debugName: "recoverableDraft" }] : /* istanbul ignore next */ []);
	recoverableAt = computed(() => {
		const draft = this.recoverableDraft();
		if (draft === null) return null;
		const at = new Date(draft.at);
		return Number.isNaN(at.getTime()) ? null : at.toLocaleTimeString(void 0, {
			hour: "2-digit",
			minute: "2-digit"
		});
	}, ...ngDevMode ? [{ debugName: "recoverableAt" }] : /* istanbul ignore next */ []);
	confirmNavigation() {
		if (this.leavingWithDraftKept) return true;
		if (!this.isDirty() || !this.canSave()) return true;
		return this.confirmLeave().pipe(map((leaving) => {
			if (leaving) this.clearDraft();
			return leaving;
		}));
	}
	onBeforeUnload(event) {
		if (this.isDirty() && this.canSave()) {
			event.preventDefault();
			event.returnValue = "";
		}
	}
	restoreDraft() {
		const form = this.form;
		const key = this.draftKey();
		if (form === null || key === null) {
			this.recoverableDraft.set(null);
			return;
		}
		const draft = this.drafts.read(key);
		if (draft !== null) {
			if (this.isCreate() && draft.idempotencyKey !== void 0) this.createKey = draft.idempotencyKey;
			for (const [componentName, value] of Object.entries(draft.values)) {
				const control = form.control(componentName);
				if (control !== void 0) {
					control.setValue(value, { emitEvent: false });
					control.markAsDirty();
				}
			}
			form.group.markAsDirty();
			this.isDirty.set(true);
		}
		this.recoverableDraft.set(null);
	}
	leavingWithDraftKept = false;
	reloadAfterUnknownSave() {
		const form = this.form;
		const key = this.draftKey();
		if (form !== null && key !== null) this.writeDraft(key, form);
		this.leavingWithDraftKept = true;
		if (this.isCreate()) this.requestNavigation({
			kind: "origin",
			origin: this.originParam ?? "",
			params: this.returnParams()
		});
		else this.requestNavigation({
			kind: "contract",
			contractNumber: this.contractNumber()
		});
	}
	discardDraft() {
		this.clearDraft();
		this.recoverableDraft.set(null);
		this.createKey = null;
	}
	keyForCreate() {
		this.createKey ??= this.mintIdempotencyKey();
		return this.createKey;
	}
	writeDraft(key, form) {
		this.drafts.write(key, this.dirtyValues(form), this.isCreate() ? this.keyForCreate() : void 0);
	}
	clearDraft() {
		const key = this.draftKey();
		if (key !== null) this.drafts.clear(key);
	}
	watchDraft(form) {
		const key = this.draftKey();
		if (key === null) return;
		const existing = this.drafts.read(key);
		if (existing !== null && Object.keys(existing.values).length > 0) this.recoverableDraft.set({ at: existing.savedAt });
		form.group.valueChanges.pipe(debounceTime(DRAFT_DEBOUNCE_MS), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
			const current = this.draftKey();
			if (current !== null) this.writeDraft(current, form);
		});
		form.group.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.isDirty.set(form.group.dirty));
	}
	confirm = injectConfirm();
	confirmLeave() {
		return this.confirm({
			title: "Leave without saving?",
			message: "This contract has changes that have not been sent to CTRM. Leaving now discards them.",
			confirmLabel: "Discard changes",
			cancelLabel: "Keep editing",
			destructive: true
		});
	}
	onEscape(event) {
		if (event.defaultPrevented || !this.isView()) return;
		this.requestNavigation({
			kind: "origin",
			origin: this.originParam ?? "",
			params: this.returnParams()
		});
	}
	host = inject(ElementRef);
	constructor() {
		this.registerRecordShortcuts();
	}
	registerRecordShortcuts() {
		registerShortcuts([
			{
				keys: "ctrl+s",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Save",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.canSave(),
				run: () => this.onSave()
			},
			{
				keys: "ctrl+shift+s",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Save and close",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.canSave(),
				run: () => this.saveAndClose()
			},
			{
				keys: "ctrl+pagedown",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Next section",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.bundle() !== null,
				run: () => this.stepSection(1)
			},
			{
				keys: "ctrl+pageup",
				scope: "feature",
				within: () => this.host.nativeElement,
				label: "Previous section",
				group: "This contract",
				allowInTextInput: true,
				available: () => this.bundle() !== null,
				run: () => this.stepSection(-1)
			}
		]);
	}
	saveAndClose() {
		if (!this.canSave()) return;
		this.closeAfterSave = true;
		this.onSave();
	}
	closeAfterSave = false;
	stepSection(direction) {
		const sections = this.visibleSections();
		const element = this.host.nativeElement;
		const current = sections.findIndex((name) => this.sectionHasFocus(element, name));
		const next = current === -1 ? direction === 1 ? 0 : sections.length - 1 : current + direction;
		if (next >= 0 && next < sections.length) {
			this.focusSection(element, sections[next]);
			return;
		}
		const tabs = this.configuredTabs();
		const target = tabs.findIndex((tab) => tab.id === this.activeTab()) + direction;
		if (target < 0 || target >= tabs.length) return;
		this.requestNavigation({
			kind: "view-state",
			params: this.paramsForTab(tabs[target].id)
		});
	}
	sectionHasFocus(host, section) {
		const box = host.querySelector(`[data-section="${section}"]`);
		return box !== null && document.activeElement !== null && box.contains(document.activeElement);
	}
	focusSection(host, section) {
		const box = host.querySelector(`[data-section="${section}"]`);
		if (box === null) return;
		const focusable = box.querySelector("input:not([disabled]):not([readonly]), select:not([disabled]), textarea:not([disabled]):not([readonly]), button:not([disabled])");
		if (focusable === null) {
			box.scrollIntoView({ block: "start" });
			return;
		}
		focusable.focus();
		box.scrollIntoView({ block: "start" });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ContractRecordPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ContractRecordPageComponent,
		isStandalone: true,
		selector: "cms-contract-record-page",
		inputs: {
			contractNumber: {
				classPropertyName: "contractNumber",
				publicName: "contractNumber",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { listeners: {
			"window:beforeunload": "onBeforeUnload($event)",
			"document:keydown.escape": "onEscape($event)"
		} },
		ngImport: i0,
		template: "<!--\r\n  The contract record screen — viewing, editing and creating, from one template.\r\n\r\n  🔴 THE SHAPE, and read this before adding anything to it (JFrisbie, 2026-09-01).\r\n\r\n  This page is four bands and nothing else:\r\n\r\n    1. breadcrumb + actions  where you are, and what you can do to this record\r\n    2. header                what this record IS\r\n    3. summary strip         the at-a-glance state — always visible, every tab, every mode\r\n    4. tabs + body           the fields of ONE tab, then that tab's collections\r\n\r\n  It used to be eleven full-width section cards stacked down the page with all four child grids after\r\n  them, which is \"so many fields prior to the child grids that it's just too much\" — 111 controls before\r\n  the first table. The tabs come from the Power App traders use today (`fxTabOptions`), so the grouping\r\n  is the business's rather than a fourth opinion from this lane. See `CONTRACT_TABS`.\r\n\r\n  The mode is still allowed to change exactly three things — whether the controls accept input, which\r\n  buttons are in the toolbar, and which contextual alerts apply. It must never change the SHAPE, or\r\n  add/edit stops looking like view, which is the whole point of one component.\r\n-->\r\n<section class=\"cws:space-y-4\">\r\n  <!--\r\n    `containerState()`, not the configuration's state alone: the record needs two reads, and gating on\r\n    the configuration rendered a full set of empty controls when the contract read had failed. See the\r\n    component.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    loadingLabel=\"Loading contract\"\r\n    (retry)=\"retry()\"\r\n  >\r\n    @if (bundle(); as loaded) {\r\n      <div class=\"cws:space-y-4\">\r\n        <!--\r\n          🔴 THE TOP ROW — breadcrumb left, record actions hard right (JFrisbie, 2026-09-02).\r\n\r\n          The actions used to sit inside the header card, level with the contract number. They belong\r\n          ABOVE it, for the same reason the workspace grid puts *Add Contract* on its own header row:\r\n          they act on the whole record, so they read as page-level actions rather than as something\r\n          attached to the title. One placement across both screens is the point — nobody should have\r\n          to look somewhere different for the primary action depending on which screen they are on.\r\n\r\n          ⚠ The actions are a SIBLING of the `<nav>`, never inside it. A breadcrumb is navigation and\r\n          the ARIA pattern is what tells a screen-reader user so; anchors dropped in would be\r\n          announced as extra crumbs. The view spec pins the nav at exactly one anchor, so nesting\r\n          them here fails a test rather than shipping quietly.\r\n\r\n          **`items-end`, so the BOTTOM of the buttons meets the bottom of the breadcrumb text**\r\n          (JFrisbie, 2026-09-02). The buttons are ~38px against the crumb's 20px line box, so\r\n          `items-center` left them straddling it and neither edge lined up with anything.\r\n\r\n          ⚠ Not `items-baseline`, which is the tempting one and is wrong here: it would align the\r\n          button's *label* baseline with the crumb's, pushing the button's padding and border below\r\n          the text and putting the bottoms further out than `items-center` had them. The request is\r\n          about the buttons' bottom EDGE, which is a box alignment, not a text one.\r\n\r\n          The grid's header row is also `items-end`; it carries `self-start` on its action block only\r\n          because its left column is a heading over a description and the button was wanted level\r\n          with the top of that. Here the left column is one line, so the row's own alignment stands.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n          <!--\r\n            The trail back — one definition, shared with the approval review and pricing screens.\r\n\r\n            🔴 **This markup was the original and is now `cms-breadcrumb`.** It was correct here and\r\n            copied almost-correctly elsewhere: the pricing screen had grown an anchor and two spans\r\n            with no list and no `aria-current`, so the same control announced itself as navigation on\r\n            two screens out of three. Extracting the version that was right, rather than writing a\r\n            fourth, is what makes this change a no-op on this screen.\r\n\r\n            ⚠ **`trail()` still owns the JOURNEY** — which screens are behind you, and whether the\r\n            approvals review sits between the queue and here. The component owns only how a trail is\r\n            drawn. Those are different questions and they stayed in different places deliberately.\r\n\r\n            ⚠ `returnParams()` rides on every crumb; see the component for the silent failure that\r\n            guards against.\r\n          -->\r\n          <cms-breadcrumb\r\n            [crumbs]=\"crumbs()\"\r\n            [current]=\"currentCrumb()\"\r\n            [context]=\"tradeUnitLabel()\"\r\n            [queryParams]=\"returnParams()\"\r\n          />\r\n\r\n          <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n            @if (isView()) {\r\n              <!--\r\n                Refresh, to the LEFT of Edit and in view mode only (JFrisbie, 2026-09-03).\r\n\r\n                Re-reads this contract — both reads, the aggregate and `/fields` — without touching the\r\n                route, so the tab you are on and the journey back to the workspace both survive. It\r\n                sits inside the `isView()` branch rather than being rendered disabled in the other\r\n                modes, which is what \"only usable in view/idle\" asks for: while editing, the control\r\n                that re-reads from CTRM would compete with unsaved changes, and a disabled button is an\r\n                invitation to wonder why.\r\n\r\n                ⚠ So this is the one thing on this row that does NOT hold the same position in all\r\n                three modes. That is a deliberate exception to the invariant noted above: Save and\r\n                Cancel still occupy the place Edit and New occupy, and refresh is additive to the view\r\n                mode rather than a fourth mode-dependent slot.\r\n              -->\r\n              <cms-refresh-button\r\n                label=\"Refresh this contract\"\r\n                [busy]=\"isRefreshing()\"\r\n                (refresh)=\"refresh()\"\r\n              />\r\n\r\n            <!--\r\n              🔴 The three WRITE controls, together, gated as one (F4.3a, extending #155).\r\n\r\n              Copy, Edit and New all end at a screen whose Save requires the Admin role, so showing\r\n              them to a reader is an invitation to fill in 111 fields and be refused — the defect\r\n              #155 removed at the Save button, met three steps earlier.\r\n\r\n              ⚠ **Refresh stays outside this gate.** It re-reads the contract, which any signed-in\r\n              user may do (correction C-14 keeps reads un-scoped), and it is the one control on this\r\n              row a reader genuinely wants.\r\n\r\n              🔴 **Hidden, not disabled** — the opposite call from \"Copy contract w/ pricing\" three\r\n              lines down, and the difference is worth stating because both are deliberate. That item\r\n              is disabled because the capability does not exist for ANYONE and naming its blocker is\r\n              useful to every reader. These are absent because they do not exist for THIS ACCOUNT,\r\n              and a row of greyed buttons tells a user nothing they can act on. One sentence below\r\n              says why, once, instead of three disabled promises.\r\n            -->\r\n            @if (canWrite()) {\r\n                <!--\r\n                  Copy, immediately right of Refresh (JFrisbie, 2026-09-10). BR-041.\r\n\r\n                  **One icon trigger opening a menu of two, rather than two buttons** (JFrisbie,\r\n                  2026-09-10). The first revision put both on the row, which made five controls and\r\n                  629px of toolbar for what is one decision with two answers — and it gave the rarer,\r\n                  currently-unavailable option exactly as much prominence as the ordinary one.\r\n\r\n                  Same shape as the workspace's Export menu: `cmsDropdown` for the open/close\r\n                  behaviour, `role=\"menu\"` markup owned here. The directive is deliberately behaviour\r\n                  and not a component, because a shared component would have had to pick between\r\n                  `role=\"menu\"` and `role=\"listbox\"` for every caller.\r\n\r\n                  ⚠ **The directive's Escape handling matters more on this screen than anywhere else.**\r\n                  This record screen binds Escape to navigate back to the contract list, and\r\n                  `DropdownDirective` calls `preventDefault()` when Escape actually dismissed a panel —\r\n                  so closing this menu with Escape does not also throw the user off the record. That\r\n                  interaction is already handled; do not add a local Escape listener.\r\n                -->\r\n                <div cmsDropdown #copyMenu=\"cmsDropdown\" class=\"cws:relative\">\r\n                  <!--\r\n                    Icon-only, so it needs both an `aria-label` and the 20px line box.\r\n\r\n                    🔴 **`h-5` on the icon wrapper is load-bearing, not decoration.** A `scoular-btn`\r\n                    is 38px only while it contains *text*: `py-2` plus a `text-sm` line box plus a 1px\r\n                    border. An icon has no line box, so an icon-only button renders **36px** and sits\r\n                    two pixels short of Edit and New beside it. The wrapper restores the line box the\r\n                    missing text would have occupied — and `h-5` is chosen because **height is\r\n                    uncontested**: the design system compiles unlayered and would beat a utility\r\n                    fighting its `py-2`, but it never declares a height. Measured at 38px against the\r\n                    other three controls across five viewport widths.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    aria-label=\"Copy this contract\"\r\n                    title=\"Copy this contract\"\r\n                    aria-haspopup=\"menu\"\r\n                    [attr.aria-expanded]=\"copyMenu.open()\"\r\n                    (click)=\"copyMenu.toggle()\"\r\n                  >\r\n                    <span class=\"cws:flex cws:h-5 cws:items-center\" aria-hidden=\"true\">\r\n                      <!--\r\n                        Two offset rounded rectangles — the conventional duplicate mark. Stroked in\r\n                        currentColor so it inherits the button's text colour in both themes, and\r\n                        `size-4` to match the refresh mark immediately left of it.\r\n                      -->\r\n                      <svg\r\n                        viewBox=\"0 0 24 24\"\r\n                        fill=\"none\"\r\n                        stroke=\"currentColor\"\r\n                        stroke-width=\"2\"\r\n                        stroke-linecap=\"round\"\r\n                        stroke-linejoin=\"round\"\r\n                        class=\"cws:size-4 cws:shrink-0\"\r\n                      >\r\n                        <rect x=\"8\" y=\"8\" width=\"14\" height=\"14\" rx=\"2\" ry=\"2\" />\r\n                        <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\" />\r\n                      </svg>\r\n                    </span>\r\n                  </button>\r\n\r\n                  @if (copyMenu.open()) {\r\n                    <!--\r\n                      `w-80` because the second item's subtext explains why it is unavailable, and the\r\n                      panel's own `min-w-[12rem]` would wrap it into four lines.\r\n\r\n                      Left-anchored (`right-0`) like every other menu on this row's side of the page,\r\n                      so it opens inward rather than off the edge of the viewport.\r\n                    -->\r\n                    <div\r\n                      class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\"\r\n                      role=\"menu\"\r\n                      aria-label=\"Copy contract\"\r\n                    >\r\n                      <div class=\"scoular-dropdown-header\">Create a copy of {{ contractNumber() }}</div>\r\n\r\n                      <!--\r\n                        An anchor rather than a button, so middle-click and \"open in new tab\" work and\r\n                        it carries a real `href` — the same reasoning the breadcrumb crumbs carry. It\r\n                        addresses the ordinary create route with a seed parameter, so a copy is a\r\n                        linkable URL rather than transient in-memory state: reload it and you still\r\n                        get the copy.\r\n\r\n                        ⚠ It carries no `returnTo`. The copy's Cancel goes to the workspace, exactly as\r\n                        an ordinary create's does, because abandoning a create should not land the user\r\n                        back on someone else's contract as though they had been editing it.\r\n\r\n                        `text-left` on the item is load-bearing for the same reason the Export menu\r\n                        records: `.scoular-dropdown-item` inherits `text-align: center` from `<button>`,\r\n                        and a subtext long enough to wrap centres its second line.\r\n                      -->\r\n                      <a\r\n                        role=\"menuitem\"\r\n                        class=\"scoular-dropdown-item cws:text-left\"\r\n                        [attr.href]=\"hrefFor(copyIntent())\"\r\n                        (click)=\"copyMenu.close(); follow($event, copyIntent())\"\r\n                      >\r\n                        <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                          <span>Copy contract</span>\r\n                          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            Every field, a new contract number, no pricing\r\n                          </span>\r\n                        </span>\r\n                      </a>\r\n\r\n                      <!--\r\n                        🔴 **Present and DISABLED, naming its blocker** — the precedent this screen\r\n                        already set for Edit before the upsert existed. It is not a placeholder for\r\n                        unfinished work: the pricing half cannot be written from this application at\r\n                        all today, for two independent reasons, both upstream of anything the SPA can\r\n                        do.\r\n\r\n                        1. **`prices` is not writable on `upsertContract`.** `constraints.json` — the\r\n                           generated single source for field metadata — declares\r\n                           `\"prices\": { \"writable\": false }`, because the collection is not a\r\n                           `ContractDS` member. `CtrmContractMerge` strips it deliberately, and sending\r\n                           it risks the origin `500` Tier 2 measured for an undeclared field. So prices\r\n                           cannot ride the create that copies the contract, however the payload is\r\n                           shaped.\r\n                        2. ~~**The API exposes no pricing route.**~~ **No longer true, and struck rather\r\n                           than deleted because it was half the stated reason this item is disabled.**\r\n                           `PricingEndpoints` shipped in PR #254, so the SPA *can* send prices as a\r\n                           second call. The item stays disabled on reason 1 alone — plus the partial\r\n                           failure below, which is the harder half and was always the real objection.\r\n\r\n                        ⚠ A working version is a **sequenced two-step write** — create the contract,\r\n                        then post its prices — whose second step can fail after the first has succeeded\r\n                        and spent an unreclaimable contract number. That is a real decision about\r\n                        partial failure, not plumbing, which is why this is disabled rather than\r\n                        half-built.\r\n\r\n                        Disabled rather than hidden **on purpose**: both options were asked for, and a\r\n                        silently absent one reads as an oversight where this states why. The subtext\r\n                        carries the reason visually and `aria-describedby` carries it to a screen\r\n                        reader — the `sr-only` span is the fuller sentence, because \"CTRM cannot\r\n                        receive prices on a create\" is the actionable half.\r\n                      -->\r\n                      <button\r\n                        type=\"button\"\r\n                        role=\"menuitem\"\r\n                        disabled\r\n                        class=\"scoular-dropdown-item cws:text-left\"\r\n                        aria-describedby=\"copy-with-pricing-blocker\"\r\n                      >\r\n                        <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                          <span>Copy contract w/ pricing</span>\r\n                          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            Not available yet — CTRM cannot receive prices on a contract create\r\n                          </span>\r\n                        </span>\r\n                      </button>\r\n\r\n                      <!--\r\n                        The disabled item's full reason, for a screen reader. `sr-only` positions\r\n                        absolutely, so it is out of flow and cannot affect the menu's layout — which is\r\n                        the trap that lifted a grid row by 28px on 2026-09-09, when `sr-only` went on a\r\n                        label row instead of on the label text.\r\n                      -->\r\n                      <span id=\"copy-with-pricing-blocker\" class=\"sr-only\">\r\n                        Copying with pricing is not available yet. CTRM cannot receive prices on a\r\n                        contract create. Copy the contract, then add its price sequences on the pricing\r\n                        screen once it is saved.\r\n                      </span>\r\n                    </div>\r\n                  }\r\n                </div>\r\n\r\n                <!--\r\n                  F3.5 — close / re-open, offered only where the host provided the action and the\r\n                  contract has loaded. Gated on `canWrite()` with the rest of this block.\r\n\r\n                  🔴 **Close CONFIRMS, and the confirmation carries the provenance sentence** — closing\r\n                  rewrites pricing-approval provenance and re-opening does not put it back, so the pair\r\n                  is not symmetric and the dialog says so rather than implying an undo.\r\n                -->\r\n                @if (canChangeState()) {\r\n                  @if (isClosed()) {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working'\"\r\n                      (click)=\"onReopenContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Re-opening… } @else { Re-open contract }\r\n                    </button>\r\n                  } @else {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working'\"\r\n                      (click)=\"onCloseContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Closing… } @else { Close contract }\r\n                    </button>\r\n                  }\r\n                }\r\n\r\n                <!-- Carries the tab, so Edit → Cancel returns you to the tab you were reading. -->\r\n                <a\r\n                  [attr.href]=\"hrefFor(editIntent())\"\r\n                  (click)=\"follow($event, editIntent())\"\r\n                  class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                >\r\n                  Edit contract\r\n                </a>\r\n\r\n                <a\r\n                  [attr.href]=\"hrefFor(newIntent)\"\r\n                  (click)=\"follow($event, newIntent)\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                >\r\n                  New contract\r\n                </a>\r\n            } @else {\r\n              <!--\r\n                The reason, once — matching the wording the Save gate already uses so a user who\r\n                meets both does not read them as two different problems.\r\n\r\n                `role=\"status\"` rather than `alert`: it is a standing property of the screen, not\r\n                something that just happened.\r\n              -->\r\n              <p role=\"status\" class=\"cws:self-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                Editing needs the <strong>Admin</strong> role on this application.\r\n              </p>\r\n            }\r\n            } @else {\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                [disabled]=\"!canSave()\"\r\n                (click)=\"onSave()\"\r\n              >\r\n                @if (save().status === 'saving') {\r\n                  Saving…\r\n                } @else {\r\n                  <!--\r\n                    **One label in both modes** — \"Save contract\" whether adding or editing (JFrisbie,\r\n                    2026-09-03). It read \"Create contract\" on a create and \"Save changes\" on an edit.\r\n                    One verb for one action: the button does the same thing to the same record either\r\n                    way, and the mode is already unmistakable from the heading, the breadcrumb and the\r\n                    URL.\r\n\r\n                    ⚠ It therefore stops being the thing that tells the two modes apart, which two\r\n                    tests were using it for. Those now discriminate on the **heading** — \"New contract\"\r\n                    against the contract number — which is the more honest signal anyway: it is what a\r\n                    user reads to know which record they are on.\r\n                  -->\r\n                  Save contract\r\n                }\r\n              </button>\r\n\r\n              @if (!canWrite()) {\r\n                <!--\r\n                  🔴 The REASON, not just a grey button (#155). Writing contracts needs the Admin app\r\n                  role — `CwsContractWriter` — while reading needs only Admin or User, so a perfectly\r\n                  legitimate user reaches this screen, fills it in and is refused at Save with nothing\r\n                  having said why.\r\n\r\n                  ⚠ Worded as what the account lacks rather than \"you do not have permission\", because\r\n                  the fix is an Entra app-role assignment someone has to request by name — the same\r\n                  reason the trade-unit picker names the role rather than saying access denied (#65).\r\n\r\n                  `role=\"status\"` rather than `alert`: it is a standing condition of the screen, not an\r\n                  event, and an assertive announcement on every render of a read-only record is noise.\r\n                -->\r\n                <!--\r\n                  #485: a night run now closes the availability gate every night, and an Admin was told\r\n                  they lacked the Admin role. The two gates have two sentences; the role one wins when\r\n                  both are closed, because it is the one the user can act on.\r\n                -->\r\n                @if (canWriteCws() && blockedByAvailability()) {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving to CTRM is paused: {{ availabilityTitle() }}. Your changes stay on this\r\n                    screen.\r\n                  </p>\r\n                } @else {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving needs the <strong>Admin</strong> role on this application. Your account can\r\n                    view contracts but not write them.\r\n                  </p>\r\n                }\r\n              }\r\n\r\n              <!--\r\n                Cancel carries its OWN parameters, not Edit's. An edit returns to this record on the tab\r\n                it was editing; a create returns to the workspace, where a `tab` parameter would be\r\n                meaningless noise in a URL people copy and share.\r\n              -->\r\n              <a\r\n                [attr.href]=\"hrefFor(cancelIntent())\"\r\n                (click)=\"follow($event, cancelIntent())\"\r\n                class=\"scoular-btn scoular-btn-secondary\"\r\n              >\r\n                Cancel\r\n              </a>\r\n            }\r\n          </div>\r\n\r\n          @if (stateAction().status === 'failed') {\r\n            <!--\r\n              An alert, not a status: this DID just happen, and it needs to interrupt. It also states\r\n              that nothing changed, because the failure a user most fears here is a half-applied one.\r\n            -->\r\n            <p\r\n              role=\"alert\"\r\n              class=\"cws:mt-2 cws:rounded cws:border cws:border-red-300 cws:bg-red-50 cws:px-3 cws:py-2 cws:text-xs cws:text-red-900 cws:dark:border-red-700 cws:dark:bg-red-950 cws:dark:text-red-100\"\r\n            >\r\n              {{ stateAction().message }}\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        <!--\r\n          Header band. The contract number is the page's identity, so it is the h2 — the shell owns the\r\n          only h1.\r\n\r\n          The actions moved out of this card onto the row above it; see the comment there. What has NOT\r\n          changed is that they occupy the same place in all three modes, so the toolbar does not move\r\n          under the pointer when the mode changes — that invariant is why the whole block moved rather\r\n          than only the two view-mode buttons.\r\n        -->\r\n        <header\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <div class=\"cws:space-y-1\">\r\n            <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n              <!--\r\n                The same heading in view and edit, on purpose: a record's identity does not change\r\n                because it is being edited. A create has no number yet — CTRM issues it at reservation\r\n                (03 §2.6) — so the heading says what is being made.\r\n              -->\r\n              <h2 class=\"cws:text-xl cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                {{ isCreate() ? 'New contract' : contractNumber() }}\r\n              </h2>\r\n              @if (contract()?.version; as version) {\r\n                <!-- CTRM's version, not a CMS revision. Muted so it cannot be read as part of the key. -->\r\n                <span\r\n                  class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n                  title=\"CTRM contract version\"\r\n                >\r\n                  v{{ version }}\r\n                </span>\r\n              }\r\n            </div>\r\n            <!--\r\n              🔴 The header as an executive summary (JFrisbie, 2026-09-15 — UX brief item 1): what\r\n              contract this is, and the business context, without scrolling.\r\n\r\n              ⚠ **Status and the key quantities are deliberately NOT repeated here.** The brief's\r\n              sketch puts them in this block; they already sit in the summary band immediately below,\r\n              which is always visible in every mode and on every tab. Two copies of \"Priced 9,000 BU\"\r\n              one line apart is a number that can disagree with itself, which this repository has paid\r\n              for more than once — and the band is not a scroll away, it is the next element.\r\n\r\n              ⚠ **\"Last Modified\" is absent because CTRM does not send one.** Nothing on the aggregate\r\n              carries it; `version` is the nearest thing CTRM has and it is already beside the number.\r\n              Inventing a timestamp from the read would be a fact about our request, not the contract.\r\n\r\n              ⚠ **The CUSTOMER here is the id.** `getContract` carries no customer-name field and\r\n              never will; the name comes from the customer directory and is shown on the Customer\r\n              name field below, where the record screen also confirms a typed id on blur (F4.3b).\r\n              The header keeps the id because the id is the fact CTRM holds.\r\n            -->\r\n            <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n              @if (contract(); as detail) {\r\n                <!--\r\n                  Both the code and the name where we have them, for the same reason the grid's heading\r\n                  carries both: a code identifies a trade unit to CTRM, a name identifies it to a trader.\r\n                -->\r\n                {{ detail.header.commodity ?? 'Commodity not set' }}\r\n                @if (detail.header.tradeUnit) {\r\n                  · Trade unit {{ detail.header.tradeUnit }}\r\n                }\r\n                @if (detail.header.customerId) {\r\n                  · Customer {{ detail.header.customerId }}\r\n                }\r\n                @if (contractDateLabel(); as date) {\r\n                  · {{ date }}\r\n                }\r\n                @if (traderLabel(); as trader) {\r\n                  · Trader {{ trader }}\r\n                }\r\n              } @else {\r\n                Trade unit {{ loaded.config.tradeUnit }} · Field definitions from CTRM\r\n              }\r\n            </p>\r\n          </div>\r\n\r\n        </header>\r\n\r\n        <!--\r\n          🔴 THE SUMMARY STRIP — the at-a-glance state, above the tabs and outside them.\r\n\r\n          Confirmations (docs/02 §4.4) and CTRM's computed quantity breakdown (docs/04 §6) were two\r\n          full-width cards stacked before any field, and then invisible from wherever you scrolled to.\r\n          They are the answers to \"is this approved\" and \"what is left to price\", which are the two\r\n          questions somebody opens a contract to ask — so they sit in one compact band that never\r\n          scrolls away behind a tab.\r\n\r\n          ⚠ **These are NOT form fields and must not become inputs.** All six quantities are\r\n          `access: readOnly` in the constraint dictionary — CTRM refuses them on a write — and all three\r\n          confirmation statuses are derived by BR-065 from a populated field. An input box here would\r\n          invite an edit that cannot exist.\r\n        -->\r\n        <!--\r\n          🔴 **ONE ROW, and the height is the requirement** (JFrisbie, 2026-09-15, from a screenshot).\r\n\r\n          This briefly stacked — confirmations above, a six-card quantity grid below — which gave the\r\n          cards room and cost roughly three times the vertical space on a band whose whole job is to be\r\n          glanceable without scrolling. The boxes are kept and made compact instead: label and value on\r\n          ONE line rather than stacked, so each is a chip rather than a tile.\r\n\r\n          ⚠ `items-center` and `gap-x-8`, not `justify-between` alone — the two groups wrap\r\n          independently at narrow widths, and without a row gap they collide before they wrap.\r\n        -->\r\n        <!--\r\n          🔴 **No border and no shadow on the band itself** (2026-09-21 restyle).\r\n\r\n          The card sat inside a page that already separates it — white on slate-50 in light, slate-800\r\n          on slate-900 in dark — so the border and the shadow were the outermost of THREE nested\r\n          borders around the same information. Removing it costs 2px of height and one visual edge.\r\n\r\n          ⚠ **The fill and the rounding stay.** Without them the band stops being an object and the\r\n          chips read as loose text under the header, which is the failure the original card was\r\n          solving. What is gone is the chrome, not the container.\r\n        -->\r\n        <div\r\n          class=\"cws:flex cws:flex-col cws:gap-3 cws:rounded-lg cws:bg-white cws:px-4 cws:py-3 cws:lg:flex-row cws:lg:flex-wrap cws:lg:items-center cws:lg:justify-between cws:lg:gap-x-8 cws:dark:bg-slate-800\"\r\n        >\r\n          <!--\r\n            🔴 WORKFLOW CARDS, not inline pills (JFrisbie, 2026-09-15 — UX brief item 2).\r\n\r\n            The three statuses read as disconnected captions in a row. As cards they read as what they\r\n            are: three checkpoints on one contract, each with a state.\r\n\r\n            ⚠ **Three independent fields that happen to progress, NOT a state machine.** BR-065 derives\r\n            each from a populated field, so a later stage can be set with an earlier one blank — which\r\n            is why these stay three separate cards rather than becoming a connected stepper. A stepper\r\n            would assert an ordering the data does not have, and would render a contract whose broker\r\n            confirmed before its trader approved as though something had gone wrong.\r\n\r\n            The pill keeps the colour. It carries the state in a word as well as a hue, which is what\r\n            makes the card readable without relying on colour at all.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Contract confirmations\">\r\n            @for (stage of confirmations(); track stage.label) {\r\n              <!--\r\n                🔴 **The chip IS the status now — no pill inside it.** The tint, the dot and the word\r\n                are one box.\r\n\r\n                🔴 **`items-baseline` + an explicit `/5` leading on every text node, and this is the\r\n                whole alignment story for the band** (JFrisbie, 2026-09-21, from a screenshot of the\r\n                running app).\r\n\r\n                The first version of this restyle used `items-center` here and `items-baseline` on the\r\n                quantity chips, with `h-7` fixing the box height. Every box lined up — measured at a\r\n                uniform 28px, which is why the geometry pass called it done — and **the TEXT inside\r\n                them sat on four different baselines**: 46, 47, 48.8 and 51, a 5px spread. `Rejected`\r\n                floated against its own label, and the six metrics sat on a different line from the\r\n                three statuses.\r\n\r\n                🔑 **`items-center` centres each flex item independently**, so an 11px label and a 14px\r\n                value in the same chip are centred separately and their baselines cannot agree. And a\r\n                fixed `h-7` hid it: the boxes were identical, so nothing about the geometry looked\r\n                wrong.\r\n\r\n                The fix is to let the LINE BOX set the height instead. Both text nodes carry `/5`\r\n                (20px), padding is `py-1`, so every chip is 4 + 20 + 4 = **28px — exactly what `h-7`\r\n                was giving** — but now derived from a shared line box, so all eighteen pieces of text\r\n                in the ribbon rest on one baseline.\r\n\r\n                ⚠ **Do not reintroduce `h-7`, and do not drop the `/5`.** Either one restores a height\r\n                that is correct while the text inside drifts, which is the failure a box measurement\r\n                cannot see.\r\n              -->\r\n              <!--\r\n                (The chips were previously 36/34/30 tall depending on whether a badge was inside;\r\n                that raggedness is what the uniform line box removed.)\r\n\r\n                🔑 **The dot is not decoration.** Roughly 1 in 12 men has a colour vision deficiency\r\n                (docs/02a §4), and the state is already carried by the WORD — the dot adds a second\r\n                non-colour cue of position and presence, so the three stages are distinguishable at a\r\n                glance even where the hues are not.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-2 cws:rounded-md cws:px-2.5 cws:py-1\"\r\n                [class]=\"stage.style.chip\"\r\n              >\r\n                <!--\r\n                  ⚠ `self-center`, because an empty inline box has its baseline at its BOTTOM edge —\r\n                  under `items-baseline` the dot would otherwise sit on the text baseline rather than\r\n                  beside the middle of the word.\r\n                -->\r\n                <span\r\n                  class=\"cws:size-1.5 cws:shrink-0 cws:self-center cws:rounded-full\"\r\n                  [class]=\"stage.style.dot\"\r\n                ></span>\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  {{ stage.label }}\r\n                </dt>\r\n                <dd class=\"cws:shrink-0 cws:text-sm/5 cws:font-semibold\" [class]=\"stage.style.text\">\r\n                  @if (stage.badge; as badge) {\r\n                    {{ badge.label }}\r\n                  } @else {\r\n                    <!--\r\n                      ⚠ Still visibly DIFFERENT from a set status rather than an empty pill — the\r\n                      neutral tone plus a lighter weight. An empty pill reads as a status; this reads\r\n                      as no status, which is the truth.\r\n                    -->\r\n                    <span class=\"cws:font-normal\" [title]=\"stage.emptyNote ?? ''\">Not set</span>\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n\r\n          <!--\r\n            🔴 KPI CARDS, not label/value pairs (JFrisbie, 2026-09-15 — UX brief item 3).\r\n\r\n            These were six captions in a flex row, which is how the most important numbers on the page\r\n            ended up the most visually understated. As cards the figure leads and the label supports\r\n            it, which is the reading order a trader actually wants.\r\n\r\n            CTRM's numbers, never recalculated here: disagreeing with the system of record about a\r\n            settled quantity would be worse than not showing it. `tabular-nums` so the figures line up\r\n            as a column of numbers rather than drifting with their digit widths.\r\n\r\n            ⚠ **The unit travels with the number** — see `quantityBreakdown`. A bare grain quantity is a\r\n            recorded defect on this project, not a nicety.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Quantity breakdown\">\r\n            @for (measure of quantityBreakdown(); track measure.label) {\r\n              <!--\r\n                🔴 **A fill, not a border, and no left accent.** These were bordered pills carrying a\r\n                4px coloured edge each — six of them, which was the densest chrome in the band. A flat\r\n                tint separates a chip from the card just as well and draws no lines.\r\n\r\n                ⚠ **Uniformly slate, deliberately.** Colour in this band means status; these are\r\n                arithmetic. The removed accent and the reasoning are on `quantityBreakdown`.\r\n\r\n                The hierarchy is carried by weight and size instead: the label drops to 11px and the\r\n                figure stays `font-semibold`, so the number leads its chip without either growing.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-1.5 cws:rounded-md cws:bg-slate-100 cws:px-2.5 cws:py-1 cws:dark:bg-slate-700/40\"\r\n              >\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  {{ measure.label }}\r\n                </dt>\r\n                <dd class=\"cws:text-sm/5 cws:font-semibold cws:tabular-nums cws:text-slate-900 cws:dark:text-white\">\r\n                  @if (measure.value === null) {\r\n                    <!-- An em dash, never 0: CTRM holding no figure is not a quantity of nothing. -->\r\n                    <span class=\"cws:font-normal cws:text-slate-400 cws:dark:text-slate-500\">—</span>\r\n                  } @else {\r\n                    {{ measure.value.toLocaleString('en-US') }}\r\n                    @if (measure.uom; as uom) {\r\n                      <span class=\"cws:text-[11px]/5 cws:font-normal cws:text-slate-600 cws:dark:text-slate-400\">\r\n                        {{ uom }}\r\n                      </span>\r\n                    }\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n        </div>\r\n\r\n        <!--\r\n          🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\r\n          workspace grid and the approval screens. Up to five full-width banners used to sit between\r\n          the summary strip and the tabs, so on a create the form began below the fold.\r\n\r\n          ⚠ **Widened 2026-09-17 to nine, and four of them came from OUTSIDE this stack** — the copy\r\n          provenance, the create-pending note, the configuration provenance line under the tabs, and\r\n          the unmodelled-collections note that sat at the very bottom of the record. They were not\r\n          part of the original five because they were not full-width banners between the strip and\r\n          the tabs; they were still standing conditions, and scattering them was costing more than\r\n          their individual size suggested.\r\n\r\n          🔴 **What is in here and what is NOT is the load-bearing decision, and it is not about\r\n          length.** Standing conditions of the screen go in; **the outcome of something the user just\r\n          did stays out** — every banner below this point is the second kind (a save result, a save\r\n          failure, a copy whose source could not be read, a contract number that was not issued, a\r\n          prefill that failed). Two of those carry `role=\"alert\"` because they must interrupt, and\r\n          behind a collapsed panel they would be messages nobody sees. Before this change both kinds\r\n          rendered identically, which is exactly why the distinction needs stating.\r\n\r\n          ⚠ **The summaries live in `noticeSummaries` and must stay in this order.** Nothing enforces\r\n          it.\r\n        -->\r\n        <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n          @if (isSimulated()) {\r\n            <!--\r\n              Same banner and the same reason as the grid: a demo that silently shows generated data is\r\n              how generated data gets quoted as a production readout.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Simulated data</div>\r\n              <div class=\"scoular-alert-description\">\r\n                This contract is generated locally, not read from CTRM.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCopy() && !copyFailed()) {\r\n            <!--\r\n              A copy says what it is a copy of, and says what it did NOT bring with it.\r\n\r\n              🔴 The second half is the load-bearing half. A user who pressed \"Copy contract\" has every\r\n              reason to believe the new contract carries everything the old one did, and three things it\r\n              cannot carry are invisible on this screen: the number (deliberately — see\r\n              `CONTRACT_COPY_IDENTITY_FIELDS`, it is what stops the copy overwriting its source), the\r\n              prices (CTRM cannot receive them on a create at all), and the child collections (this\r\n              screen has no way to send them yet — see issue 187's frontend half). Stating them here is\r\n              the difference between a copy the user can trust and one they have to audit.\r\n\r\n              ⚠ **In the panel, where the copy FAILURE three blocks below is not, and the split is the\r\n              membership rule rather than a judgement about length.** \"This record is a copy of X\" is\r\n              true for the whole life of the screen — a standing condition of what the user is looking\r\n              at. \"X could not be read\" is the outcome of the action they just took, it carries\r\n              `role=\"alert\"`, and behind a disclosure it would be a message nobody sees.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Copied from {{ copyFrom }}</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Every writable field was carried across and can be changed before saving. A\r\n                <strong>new contract number</strong> has been issued — this will create a new contract\r\n                and cannot alter {{ copyFrom }}.\r\n                <strong>Pricing, ship periods, remarks and notes were not copied</strong> and need\r\n                entering separately once this contract is saved.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate() && canUseTemplates()) {\r\n            <!--\r\n              F3.3 — create from a template.\r\n\r\n              🔴 **Applying a template seeds the FULL set it carries, not the fields somebody typed.**\r\n              A template is captured whole precisely so applying it is whole; carrying only part of it\r\n              across is the defect that generalised from one field to forty.\r\n\r\n              ⚠ Through `seed`, so the values arrive as defaults rather than as edits — the same\r\n              distinction the customer-name confirmation makes, and it matters because six derived\r\n              descriptions sit on CTRM's re-confirmation list.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Start from a template</div>\r\n              <div class=\"scoular-alert-description\">\r\n                @if (templatesFailed()) {\r\n                  <!-- Not the same as \"this trade unit has none\", which would be a claim. -->\r\n                  <span>The templates for this trade unit could not be loaded.</span>\r\n                } @else if (availableTemplates().length === 0) {\r\n                  <span>This trade unit has no saved templates yet.</span>\r\n                } @else {\r\n                  <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n                    <span>Apply a template</span>\r\n                    <select\r\n                      class=\"cws:rounded cws:border cws:border-slate-300 cws:p-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      (change)=\"onApplyTemplate($any($event.target).value)\"\r\n                    >\r\n                      <option value=\"\">Choose…</option>\r\n                      @for (template of availableTemplates(); track template.id) {\r\n                        <option [value]=\"template.id\">{{ template.name }}</option>\r\n                      }\r\n                    </select>\r\n                  </label>\r\n\r\n                  @if (appliedTemplate(); as applied) {\r\n                    <p class=\"cws:mt-1\">\r\n                      Applied <strong>{{ applied }}</strong>. Every value it carried can be changed\r\n                      before saving.\r\n                    </p>\r\n                  }\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate()) {\r\n            <!--\r\n              Why the confirmation pills and the quantity breakdown are empty on a create.\r\n\r\n              ⚠ **The per-stage `emptyNote` is a `title` attribute only**, so it is a tooltip and not a\r\n              visible statement — this is the only place the reason is readable. It moved in here rather\r\n              than being deleted: a panel summary renders in BOTH states, so it is still on screen.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some values appear once this contract is saved</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Confirmations and CTRM’s computed quantity breakdown are {{ pendingNote }}, so those\r\n                panels are empty rather than failing to load.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable()) {\r\n            <!--\r\n              The standing caveat about what can be ENTERED — one of the three things the mode may\r\n              change, which is why it is gated on the mode rather than shown always.\r\n\r\n              ⚠ **This is the notice in here with the strongest claim to being left out**, and it is\r\n              the one to pull back up if the panel proves too quiet. Known Issue 30's instruction is\r\n              that anyone shown this screen reads it as the agreed field set, and unlike the approval\r\n              screen's CTRM caveat **there is no restatement of this at the point of action** — no\r\n              message appears at Save saying the contract has no ship periods. What makes collapsing\r\n              it defensible rather than a loss: the omission is *recoverable* (ship periods can be\r\n              added in CTRM afterwards) and the fields are optional, so a contract saved without them\r\n              is valid rather than wrong.\r\n            -->\r\n            <!--\r\n              🔴 **REWORDED 2026-09-25 (ruled by JFrisbie on #226). The previous text said shipment\r\n              dates \"cannot be entered here\", and that stopped being true when F2.3b built the\r\n              editable ship-period table** — which is available in create mode, since the editable\r\n              branch is gated on the form being writable rather than on the record existing.\r\n\r\n              ⚠ **What is kept is the half #226 was actually about**: they are OPTIONAL, a contract\r\n              saved without them genuinely has NONE, and CTRM derives none of its own. That was\r\n              settled from CTRM source rather than by spending a contract number — ship periods are\r\n              twelve positional slots and the read unpivots them on a non-sentinel begin date, so a\r\n              slot nobody filled never becomes a row. A user who assumes CTRM fills them in gets a\r\n              contract with zero ship periods and does not know it.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <!--\r\n                ⚠ Deliberately NOT word-for-word the panel summary. They render together when the\r\n                panel is open, and two identical lines read as a rendering fault; the summary states\r\n                the fact and the title states the consequence.\r\n              -->\r\n              <div class=\"scoular-alert-title\">Shipment dates are optional, not missing</div>\r\n              <div class=\"scoular-alert-description\">\r\n                All 108 of CTRM’s writable contract fields are here, and\r\n                <strong>ship periods can be entered on the Shipping tab</strong>. They are\r\n                <strong>optional</strong>, not missing: a contract saved without them genuinely has none,\r\n                because CTRM derives no shipment dates of its own. If you do enter them, CTRM refuses a\r\n                contract whose ship quantities do not sum to the header quantity — this screen states\r\n                the running total and blocks Save while they disagree, so that refusal is not reached.\r\n                Fields, widths and decimal places are read from CTRM’s own definitions, so what\r\n                you type is validated exactly as CTRM would; the tab grouping follows the Power App, and\r\n                the <em>Additional fields</em> tab holds the CTRM fields it never surfaced.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (configDefaultsOnly()) {\r\n            <!--\r\n              The configuration could not be resolved, so this record is on the layout's defaults.\r\n\r\n              The consequence is actionable and invisible otherwise: a field an admin marked required\r\n              may not be marked required here, and one they hid may be showing. The save still enforces\r\n              the real configuration server-side, so the failure a user would otherwise meet is a\r\n              refusal naming a field the form never asked for — which reads as a bug in the form.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Showing default field settings</div>\r\n              <div class=\"scoular-alert-description\">\r\n                The form configuration could not be loaded, so this record shows every field with default\r\n                settings. Anything an administrator has configured for this trade unit — hidden fields,\r\n                extra required fields, custom tabs — is not reflected here. Saving still applies the real\r\n                configuration, so a save may be refused for a field this form did not mark as required.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable() && unavailableLists().length > 0) {\r\n            <!--\r\n              Which dropdowns have no values, and why. A combo rendering an empty list looks like a bug in\r\n              this screen; it is a known gap in the reference route (issues 44 and 83).\r\n\r\n              ⚠ The description names no issue number: a trader cannot open one, and the sentence has to\r\n              stand on its own as \"typed, not picked, and that is expected\".\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some lists are unavailable</div>\r\n              <div class=\"scoular-alert-description\">\r\n                {{ unavailableLists().join(', ') }} returned no values, so those fields accept a typed code\r\n                instead of offering a list. The reference routes they need are parameterised and not\r\n                callable yet.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (unmodelled().length > 0) {\r\n            <!--\r\n              🔑 Shown deliberately, and the endpoint goes out of its way to make it possible.\r\n\r\n              These are child collections CTRM DOES return and CMS does not read yet. Hiding them would\r\n              make this screen answer \"this contract has no quality factors\" when the truth is \"CMS does\r\n              not read quality factors\" — a difference that matters to anyone using this screen to check\r\n              data, and one nobody could detect from the outside.\r\n\r\n              ⚠ **It used to sit at the very bottom of the record, below every tab's content.** That is\r\n              the one place a statement about the WHOLE record is least likely to be read, and it was\r\n              below the fold on every contract. In the panel it keeps its scope and gains a reader.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-title\">Not read by CMS yet</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM returns {{ unmodelled().length }} further collections on this contract that this\r\n                application does not read:\r\n                <span class=\"cws:font-medium\">\r\n                  @for (name of unmodelled(); track name; let last = $last) {\r\n                    <span [title]=\"name\">{{ readable(name) }}</span>{{ last ? '' : ', ' }}\r\n                  }\r\n                </span>\r\n                — so an empty section means “not read”, not “not present”.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (provenanceLabel() !== null) {\r\n            <!--\r\n              Which configuration row is in force.\r\n\r\n              It answers the question nobody could otherwise answer from the screen: \"why is this field\r\n              required here and not on the contract I looked at before?\" It is the admin's debugging\r\n              thread — which is exactly why it belongs behind the disclosure rather than as a permanent\r\n              muted line under the tabs, where it was one more thing between the user and the fields.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-description\">{{ provenanceLabel() }}</div>\r\n            </div>\r\n          }\r\n\r\n          @for (warning of warnings(); track warning) {\r\n            <!-- CTRM warnings are surfaced, not dropped (correction C-2). Rare on a read, never silent. -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n            </div>\r\n          }\r\n        </cms-notices-panel>\r\n\r\n        <!--\r\n          A number that could not be issued is stated rather than left as an empty field, because the\r\n          three causes need three different actions and none of them is \"wait\". The field stays\r\n          editable throughout, so this is a notice and not a blocker.\r\n        -->\r\n        @if (numberIssueFailure()) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">A contract number was not issued</div>\r\n            <div class=\"scoular-alert-description\">{{ numberIssueFailure() }}</div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          A copy whose source could not be read is an ERROR, not a notice, and it must not look like\r\n          an ordinary blank create. The user asked for a copy; blank fields here would read as the\r\n          source contract's values and get saved.\r\n        -->\r\n        @if (copyFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">{{ copyFrom }} could not be read, so nothing was copied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is blank because the read of {{ copyFrom }} failed — <strong>not</strong>\r\n              because that contract is empty. <strong>Do not save from this state</strong> expecting a\r\n              copy: it would create a new contract carrying only what you type here. Reload to try\r\n              again, or start from {{ copyFrom }} and press Copy contract once it loads.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The values failing to load is stated, never absorbed. In view mode it stops an empty record\r\n          reading as an empty contract; in edit mode it is worse than that and the text says so.\r\n        -->\r\n        @if (prefillFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">This contract’s current values could not be loaded</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is showing blank because the read failed — <strong>not</strong> because the\r\n              contract is empty.\r\n              @if (isEditable()) {\r\n                <strong>Do not save from this state</strong>: a field you fill in here would be written\r\n                over whatever CTRM currently holds.\r\n              }\r\n              Reload the page, and if it keeps failing the contract can still be worked on the green\r\n              screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The save outcome, including WHICH of upsert's two paths CTRM took. A create that reports\r\n          \"Updated\" overwrote an existing contract and an update that reports \"Created\" made a new one;\r\n          both are shown rather than folded into a plain success, because that discriminator is the only\r\n          thing standing between a silent mistake and a caught one (docs/04e).\r\n        -->\r\n        @if (save().result; as result) {\r\n          <div class=\"scoular-alert scoular-alert-success\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">\r\n              {{ result.action === 'Created' ? 'Contract created' : 'Contract updated' }}\r\n              @if (result.contractNumber) {\r\n                — {{ result.contractNumber }}\r\n              }\r\n            </div>\r\n            <div class=\"scoular-alert-description\">\r\n              {{ result.detail }}\r\n              @if (!isCreate() && result.action === 'Created') {\r\n                <strong>\r\n                  ⚠ This was expected to update an existing contract and CTRM reports it created a new\r\n                  one. Check the contract number before continuing.\r\n                </strong>\r\n              }\r\n              @if (isCreate() && result.action === 'Updated') {\r\n                <strong>\r\n                  ⚠ This was expected to create a contract and CTRM reports it updated an existing one.\r\n                  An existing contract may have been overwritten.\r\n                </strong>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n\r\n        @if (recoverableDraft() !== null) {\r\n          <!--\r\n            🔴 An OFFER, never an automatic restore — F3.2f.\r\n\r\n            Silently repopulating a form would be indistinguishable from the contract genuinely\r\n            holding those values, and the user has no way to tell which they are looking at. Worse\r\n            under a full-replace upsert: a restored draft that the user does not notice is a set of\r\n            edits they never made, sent as if they had.\r\n\r\n            ⚠ `role=\"status\"` rather than `alert`: it is waiting for them, not interrupting them.\r\n          -->\r\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">Unsaved changes were recovered</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <p>\r\n                This form had unsaved changes when it was last open\r\n                @if (recoverableAt(); as at) {\r\n                  <span>, at {{ at }}</span>\r\n                }.\r\n              </p>\r\n              <div class=\"cws:mt-2 cws:flex cws:gap-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-primary\" (click)=\"restoreDraft()\">\r\n                  Restore them\r\n                </button>\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"discardDraft()\">\r\n                  Discard\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 #556: a failed save is THREE different things, and only one of them is a refusal.\r\n\r\n          A 422 is CTRM or the API saying no, with reasons. A lost CTRM answer is not a refusal at all:\r\n          the API reads the contract back to settle it (#513), and either the change is not there\r\n          (`not-applied`: safe to save again) or nobody can tell (`outcome-unknown`, and a status 0).\r\n          Saying \"not saved\" about the last case is how a retry becomes a duplicate write, and on a\r\n          create a second contract. The draft is kept in all three; only a success clears it.\r\n        -->\r\n        @if (save().status === 'failed' && save().failure === 'outcome-unknown') {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract may have been saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <p>\r\n                CTRM did not answer, so it is not known whether the change was applied. Your edits are\r\n                kept on this screen.\r\n                @if (isCreate()) {\r\n                  Check the contract list for the new contract before saving again, or a second\r\n                  contract may be created and the change applied twice.\r\n                } @else {\r\n                  Reload the contract to see what CTRM holds before saving again, or the change may be\r\n                  applied twice. Pressing Edit there offers these edits back.\r\n                }\r\n              </p>\r\n              <div class=\"cws:mt-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"reloadAfterUnknownSave()\">\r\n                  {{ isCreate() ? 'Check the contract list' : 'Reload the contract' }}\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        } @else if (save().status === 'failed' && save().failure === 'not-applied') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              CTRM did not answer, and reading the contract back shows the change is not there. Your\r\n              edits are kept, and it is safe to save again.\r\n            </div>\r\n          </div>\r\n        } @else if (save().status === 'failed') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5\">\r\n                <!--\r\n                  The API's own form-level text, plus any refusal whose `invalid_params[].name` is\r\n                  not a field name at all — a CTRM procedure name or composite (docs/04 §8.2). Those\r\n                  used to render below as a bolded field, which invented a field that does not exist.\r\n                -->\r\n                @for (reason of formLevelReasons(); track reason) {\r\n                  <li>{{ reason }}</li>\r\n                }\r\n\r\n                <!--\r\n                  🔴 Each field reason is now a BUTTON that goes to its control, and the reason is also\r\n                  on the control itself. This list used to admit, in its own words, that the field a\r\n                  reason named \"may be on a tab you are not looking at\" — which is a message the user\r\n                  has to go hunting for, barely better than none.\r\n\r\n                  ⚠ A button rather than an anchor: it switches tab AND moves focus, and the focus move\r\n                  is the half that makes it useful. An anchor would advertise an href that does only\r\n                  half the job.\r\n                -->\r\n                @for (error of mappedErrors(); track error.ctrmField) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                        (click)=\"focusField(error)\"\r\n                      >\r\n                        <strong>{{ error.label }}</strong>\r\n                      </button>\r\n                      — {{ reason }}\r\n                    </li>\r\n                  }\r\n                }\r\n\r\n                <!--\r\n                  ⚠ Refusals naming a field this screen does not render. Kept visible rather than\r\n                  dropped: CTRM validates a set that is not identical to what this layout shows, and a\r\n                  swallowed reason leaves a save that failed for no stated cause. Named by the CTRM\r\n                  field, because that is the only name we have for it.\r\n                -->\r\n                @for (error of unmappedErrors(); track error.field) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li><strong>{{ error.field }}</strong> — {{ reason }}</li>\r\n                  }\r\n                }\r\n              </ul>\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 THE TABS, and they are ANCHORS rather than buttons.\r\n\r\n          Each tab is a real link to this same record with a different `tab` query parameter, which buys\r\n          three things a click handler would not: the tab is in the URL so a refresh keeps it and a link\r\n          to \"the shipping fields of this contract\" can be sent (docs/02 §1.3 asks this of every route);\r\n          middle-click and open-in-new-tab work; and the browser Back button walks the tabs. It is the\r\n          same reasoning the breadcrumb and Cancel already carry.\r\n\r\n          `aria-current=\"page\"` marks the active one — the correct ARIA for a set of links, where\r\n          `role=\"tab\"` would be a promise of keyboard semantics these are not implementing. Tab/Shift+Tab\r\n          moves between them because they are links, which is what a keyboard user expects of links.\r\n\r\n          ⚠ `queryParamsHandling` is deliberately NOT used. `paramsForTab` states every parameter it\r\n          keeps, so a future parameter has to be added on purpose — `merge` would silently carry\r\n          anything, including a stale `focus` from the grid.\r\n        -->\r\n        <nav aria-label=\"Contract sections\" class=\"cws:border-b cws:border-slate-200 cws:dark:border-slate-700\">\r\n          <ul class=\"cws:-mb-px cws:flex cws:flex-wrap cws:gap-1\">\r\n            @for (tab of tabs(); track tab.id) {\r\n              <li>\r\n                <a\r\n                  [routerLink]=\"[]\"\r\n                  [queryParams]=\"paramsForTab(tab.id)\"\r\n                  [attr.aria-current]=\"tab.current ? 'page' : null\"\r\n                  class=\"cws:flex cws:items-center cws:gap-2 cws:rounded-t-lg cws:border-b-2 cws:px-4 cws:py-2.5 cws:text-sm cws:font-medium cws:transition-colors cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                  [class.cws:border-scoular-blue]=\"tab.current\"\r\n                  [class.cws:text-scoular-blue]=\"tab.current\"\r\n                  [class.cws:dark:text-sky-400]=\"tab.current\"\r\n                  [class.cws:border-transparent]=\"!tab.current\"\r\n                  [class.cws:text-slate-500]=\"!tab.current\"\r\n                  [class.cws:hover:border-slate-300]=\"!tab.current\"\r\n                  [class.cws:hover:text-slate-700]=\"!tab.current\"\r\n                  [class.cws:dark:text-slate-400]=\"!tab.current\"\r\n                  [class.cws:dark:hover:text-slate-200]=\"!tab.current\"\r\n                >\r\n                  {{ tab.label }}\r\n\r\n                  <!--\r\n                    🔴 How many refusals landed on this tab. Without it a save that failed on a field\r\n                    two tabs away shows an error banner and four tabs that look identical — the user\r\n                    has to open each one to find what CTRM objected to.\r\n\r\n                    ⚠ The count is in the accessible name too, not only the glyph: a screen-reader user\r\n                    gets \"Shipping Info, 2 problems\" rather than \"Shipping Info, 2\".\r\n                  -->\r\n                  @if (errorsByTab().get(tab.id); as problems) {\r\n                    <span\r\n                      class=\"scoular-badge scoular-badge-sm cws:bg-red-100 cws:text-red-800 cws:dark:bg-red-900/40 cws:dark:text-red-200\"\r\n                      [attr.aria-label]=\"problems + (problems === 1 ? ' problem' : ' problems')\"\r\n                    >\r\n                      {{ problems }}\r\n                    </span>\r\n                  }\r\n                  <!--\r\n                    The count is fields PLUS collections. The Remarks tab has no fields at all — remarks\r\n                    and notes are CTRM collections rather than `base_data` scalars — and would otherwise\r\n                    read `0` beside two populated tables. The Documents tab has no count at all (null),\r\n                    because a `0` beside it would read as \"this contract has no documents\".\r\n                  -->\r\n                  @if (tab.count !== null) {\r\n                  <span\r\n                    class=\"cws:rounded-full cws:px-1.5 cws:py-0.5 cws:text-xs cws:tabular-nums\"\r\n                    [class.cws:bg-scoular-blue]=\"tab.current\"\r\n                    [class.cws:text-white]=\"tab.current\"\r\n                    [class.cws:bg-slate-100]=\"!tab.current\"\r\n                    [class.cws:text-slate-600]=\"!tab.current\"\r\n                    [class.cws:dark:bg-slate-700]=\"!tab.current\"\r\n                    [class.cws:dark:text-slate-300]=\"!tab.current\"\r\n                  >\r\n                    {{ tab.count }}\r\n                  </span>\r\n                  }\r\n                </a>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </nav>\r\n\r\n        <!--\r\n          🔴 THE FIELDS. One form, always mounted, showing one tab's sections.\r\n\r\n          `[visibleSections]` narrows what RENDERS. The form group is always built from the whole\r\n          configuration — see the input's own remarks. Wrapping this in `@if (activeTab() === …)` would\r\n          destroy and rebuild the component on every tab click, discarding everything typed and resetting\r\n          the `dirty` flags the save path reads. That is the trap here, and it looks like the obvious\r\n          implementation.\r\n\r\n          `[readOnly]` is the entire difference between reading a contract and editing one.\r\n\r\n          🔴 It binds `!isEditable()`, not `isView()` (F2.3c, #423). BR-002 makes the WHOLE form\r\n          read-only for an intercompany purchase, and this binding is the one place that decision\r\n          lands — bound to the mode alone, an intercompany purchase opened in edit mode rendered\r\n          fully editable and the rule existed only in the requirements.\r\n\r\n          Gated on `valuesReady()`: the form seeds ONCE in `ngOnInit`, so rendering before this\r\n          contract's values arrive builds it from nothing and never re-seeds.\r\n        -->\r\n        <!--\r\n          BR-002's read-only reason, which docs/02a §6.2 requires a banner for: \"read-only … banner\r\n          explains why\". A locked form with no explanation reads as a broken screen, and this one\r\n          cannot be unlocked from here.\r\n\r\n          ⚠ **Deliberately NOT `role=\"alert\"`.** It is a standing condition of the contract, not an\r\n          event that just happened — the same distinction the save outcome above observes in the\r\n          other direction. An alert role would interrupt a screen-reader user on arrival to announce\r\n          something that has always been true of this record.\r\n        -->\r\n        @if (intercompanyLock()) {\r\n          <div class=\"scoular-alert scoular-alert-info\">\r\n            <div class=\"scoular-alert-title\">This contract is read-only</div>\r\n            <!--\r\n              ⚠ No rule number in the copy. `user-facing-copy.spec.ts` refused \"(BR-002)\" here and\r\n              was right: a business-rule identifier names something only the development team can\r\n              act on, and the trader reading this needs to know what to do instead.\r\n            -->\r\n            <div class=\"scoular-alert-description\">\r\n              It is an intercompany purchase, and those are not editable here. The contract can\r\n              still be worked on the green screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (valuesReady()) {\r\n          <!--\r\n            🔴 `@for (… of [formKey()]; track key)` — the ONE place this screen rebuilds the form on\r\n            purpose, and it is not the tab switch.\r\n\r\n            A driver change (contract type, commodity) re-resolves the configuration, and a different\r\n            configuration is genuinely a different set of controls — so unlike tabs, this cannot be a\r\n            display filter. Re-keying rebuilds it; `watchDrivers` snapshots the dirty values first and\r\n            they come back through `[defaultValues]` marked dirty, so nothing typed is lost and the\r\n            save payload is unchanged. Keyed on the configuration's own version, so a re-resolve that\r\n            wins the same row does not churn the form.\r\n          -->\r\n          @for (key of [formKey()]; track key) {\r\n            <cms-contract-form\r\n              [config]=\"loaded.config\"\r\n              [tradeUnit]=\"loaded.tradeUnit\"\r\n              [readOnly]=\"!isEditable()\"\r\n              [visibleSections]=\"visibleSections()\"\r\n              [fieldNotes]=\"fieldNotes()\"\r\n              [emptyNotes]=\"emptyNotes\"\r\n              [sectionNotes]=\"sectionNotes\"\r\n              [wideFields]=\"wideFields\"\r\n              [halfFields]=\"halfFields\"\r\n              [hiddenLabelFields]=\"hiddenLabelFields\"\r\n              [groupHeadings]=\"groupHeadings\"\r\n              [fieldCtrmNames]=\"fieldCtrmNames\"\r\n              [readOnlyFields]=\"readOnlyFields()\"\r\n              [initialValues]=\"initialValues()\"\r\n              [defaultValues]=\"defaultValues()\"\r\n              (ready)=\"onFormReady($event)\"\r\n              (fieldBlur)=\"onFieldBlur($event)\"\r\n            />\r\n          }\r\n        } @else {\r\n          <div class=\"scoular-card cws:p-6\" role=\"status\" aria-live=\"polite\">\r\n            Loading this contract’s current values…\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          F10.3b — the Addendum section, for the three in-house addendums only (MNC/MNP, XPC, PREM).\r\n\r\n          🔴 OUTSIDE `cms-contract-form`, and that is how an addendum field is kept out of the save.\r\n          The form is the CTRM\r\n          payload; these values are CWS's and live in the section's own state, so the save path has no\r\n          control to read them from. `addendumFieldSet()` is null for every other special type, blank\r\n          included, and the section does not render at all.\r\n        -->\r\n        @if (showAddendum()) {\r\n          @if (addendumFieldSet(); as set) {\r\n            <cws-contract-addendum-section\r\n              [fieldSet]=\"set\"\r\n              [contractNumber]=\"isCreate() ? '' : contractNumber()\"\r\n              [tradeUnit]=\"addendumTradeUnit()\"\r\n              [canGenerate]=\"canWrite()\"\r\n            />\r\n          }\r\n        }\r\n\r\n        <!--\r\n          The child collections, each on the tab whose fields describe it — ship periods with the\r\n          shipping fields, prices with the pricing fields, remarks and notes on the tab named after them.\r\n          That is what the Power App does (its `Ship Period` component is inside `Shipping Info`) and it\r\n          is what removes the long tail: nothing here sits after 111 controls any more.\r\n\r\n          ⚠ The grids themselves are UNCHANGED — same columns, sort behaviour, resizing and cell-level\r\n          Ctrl+C. Only where they appear has moved.\r\n        -->\r\n        @if (showPrices()) {\r\n          <!--\r\n            Price sequences, read-only on this aggregate — prices are written through the pricing API,\r\n            never through the contract upsert (C-8). So this stays a table in edit mode too.\r\n\r\n            ⚠ These are NOT the pricing API's price records. Known Issue 34: two CTRM routes both return\r\n            \"a price\" and disagree on names (`flat_price` vs `price`, 12 members vs 36). Do not reuse\r\n            this table's columns on the pricing screen.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Price sequences\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ contract()?.prices?.length ?? 0 }})\r\n              </span>\r\n            </h3>\r\n            @if (contract()?.prices?.length) {\r\n              <cms-data-grid\r\n                [rows]=\"sortedPrices()\"\r\n                [columns]=\"priceColumns\"\r\n                label=\"Price sequences\"\r\n                [sorts]=\"priceSorts()\"\r\n                (sortChange)=\"priceSorts.set($event)\"\r\n              />\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                {{\r\n                  isCreate()\r\n                    ? 'Prices are added on the pricing screen, ' + pendingNote + '.'\r\n                    : 'This contract has no priced sequences.'\r\n                }}\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showShipPeriods()) {\r\n          <!--\r\n            Ship periods (BR-020…BR-023). Max 12, CTRM's cap.\r\n\r\n            🔴 **EDITABLE in edit mode as of F2.3b (#372).** This block carried the opposite claim —\r\n            \"read-only in EVERY mode … `ship_periods` is one of the 11 child collections the contract\r\n            upsert path does not carry, so there is nothing this screen could save\". The API's\r\n            `ContractWriteBody.Collections` does carry all seven, so the sentence was describing a\r\n            limit that had been lifted.\r\n\r\n            ⚠ Read-only still, whenever the form is: view mode, and BR-002's intercompany lock.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Ship periods\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ shipPeriodRows().length }})\r\n              </span>\r\n            </h3>\r\n\r\n            @if (isEditable()) {\r\n              <!--\r\n                The editable collection. A plain table rather than `cms-data-grid`, which renders\r\n                values and has no cell-editing affordance — and rather than a `FormArray`, which\r\n                would mean changing the shared `ContractForm` for every screen that mounts it.\r\n              -->\r\n              <table class=\"cws:w-full cws:text-left cws:text-sm\">\r\n                <caption class=\"sr-only\">Ship periods, editable</caption>\r\n                <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  <tr>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Begin</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">End</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Quantity</th>\r\n                    <th scope=\"col\" class=\"cws:py-1\"><span class=\"sr-only\">Actions</span></th>\r\n                  </tr>\r\n                </thead>\r\n                <tbody>\r\n                  @for (row of shipPeriodRows(); track $index) {\r\n                    <tr class=\"cws:border-t cws:border-slate-200 cws:dark:border-slate-700\">\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <!--\r\n                          BR-020 — the three entry forms CTRM accepts (`MMDDYYYY`, `MMDDYY` with a\r\n                          1930–2029 pivot, `MM/DD/YYYY`) are parsed on change by\r\n                          `parseShipPeriodDate`. A text input rather than `type=\"date\"` for exactly\r\n                          that reason: a native date picker would refuse the shorthand a trader types.\r\n                        -->\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'Begin date, period ' + ($index + 1)\"\r\n                          [value]=\"row.beginDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'beginDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'End date, period ' + ($index + 1)\"\r\n                          [value]=\"row.endDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'endDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          inputmode=\"decimal\"\r\n                          class=\"scoular-form-input cws:w-32 cws:text-right cws:tabular-nums\"\r\n                          [attr.aria-label]=\"'Quantity, period ' + ($index + 1)\"\r\n                          [value]=\"row.quantity ?? ''\"\r\n                          (change)=\"setShipPeriodQuantity($index, $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1\">\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\"\r\n                          (click)=\"removeShipPeriod($index)\"\r\n                        >\r\n                          Remove<span class=\"sr-only\"> period {{ $index + 1 }}</span>\r\n                        </button>\r\n                      </td>\r\n                    </tr>\r\n                    @if (shipPeriodIssues().get($index); as issues) {\r\n                      <tr>\r\n                        <td colspan=\"4\" class=\"cws:pb-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                          @for (issue of issues; track issue.code) {\r\n                            <span class=\"cws:mr-3\">{{ issue.message }}</span>\r\n                          }\r\n                        </td>\r\n                      </tr>\r\n                    }\r\n                  }\r\n                </tbody>\r\n              </table>\r\n\r\n              <!--\r\n                BR-022. The action DISABLES at CTRM's 12-period cap rather than silently doing\r\n                nothing — `nextShipPeriod` returns null there, which is the whole reason it does.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-sm scoular-btn-outline\"\r\n                [disabled]=\"nextShipPeriodProposal() === null\"\r\n                (click)=\"addShipPeriod()\"\r\n              >\r\n                Add period\r\n              </button>\r\n\r\n              @if (nextShipPeriodProposal() === null) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  A contract may have at most {{ maxShipPeriods }} ship periods.\r\n                </p>\r\n              }\r\n\r\n              @for (issue of shipPeriodCollectionIssues(); track issue.code) {\r\n                <p class=\"cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ issue.message }}</p>\r\n              }\r\n\r\n              <!--\r\n                BR-022's overlap test is a WARNING, not a refusal: CTRM permits overlapping periods,\r\n                so blocking the save here would invent a rule the system of record does not have.\r\n              -->\r\n              @if (shipPeriodsOverlap()) {\r\n                <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-300\">\r\n                  Two periods overlap. CTRM allows this — check it is what you meant.\r\n                </p>\r\n              }\r\n            } @else if (shipPeriodRows().length) {\r\n              <!--\r\n                No \"sorted within this page\" caveat here, unlike the contract grid: this collection\r\n                arrives whole (CTRM caps ship periods at 12), so the sort covers every row there is.\r\n              -->\r\n              <cms-data-grid\r\n                [rows]=\"sortedShipPeriods()\"\r\n                [columns]=\"shipPeriodColumns\"\r\n                label=\"Ship periods\"\r\n                [sorts]=\"shipPeriodSorts()\"\r\n                (sortChange)=\"shipPeriodSorts.set($event)\"\r\n              />\r\n\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                This contract has no ship periods. That is valid — CTRM neither requires shipment\r\n                dates nor supplies a default for them.\r\n              </p>\r\n            }\r\n\r\n            <!--\r\n              BR-021 — the running Σ against the contract quantity (#371, 02a §6.2).\r\n\r\n              🔴 **Outside the read-only branch as of F2.3b.** It used to sit inside the grid's `@if`,\r\n              so it rendered only where the periods could not be changed — and disappeared in edit\r\n              mode, which is the only mode in which a user can unbalance it. A gate that hides itself\r\n              exactly when it becomes reachable is worse than not having one.\r\n\r\n              Pinned under the collection rather than beside the Quantity field, because it is a\r\n              statement about the collection. It states the DELTA, not merely that something is\r\n              wrong: a gate that blocks without saying by how much leaves the user to redo arithmetic\r\n              the screen has already done.\r\n\r\n              `role=\"status\"` so a screen reader hears the total resolve as the quantity is typed,\r\n              rather than discovering it on pressing Save.\r\n            -->\r\n            @if (shipPeriodReconciliation(); as reconciliation) {\r\n              <p\r\n                data-testid=\"ship-period-reconciliation\"\r\n                role=\"status\"\r\n                class=\"cws:rounded-md cws:border cws:px-3 cws:py-2 cws:text-sm\"\r\n                [class.cws:border-emerald-300]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:bg-emerald-50]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:text-emerald-900]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:border-red-300]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:bg-red-50]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:text-red-900]=\"shipPeriodGateBlocks()\"\r\n              >\r\n                {{ reconciliation.summary }}\r\n                @if (shipPeriodGateBlocks()) {\r\n                  <span class=\"cws:block cws:font-medium\">\r\n                    CTRM requires the shipment periods to sum to the contract quantity, so this\r\n                    cannot be saved until they match.\r\n                  </span>\r\n                }\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showRemarks()) {\r\n          <!--\r\n            The Remarks tab carries no FIELDS — remarks and notes are CTRM collections (`RmkDS`,\r\n            `NoteDS`), not `base_data` scalars, so there is nothing for the form to render here. The\r\n            Power App's Remarks tab is ten discrete remark inputs plus final-settle and additional\r\n            terms; ours is read-only until the collections are writable, and it says so rather than\r\n            leaving the tab looking broken.\r\n          -->\r\n          <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n            <div class=\"scoular-alert-description\">\r\n              Remarks and notes are CTRM child collections rather than contract fields, so they are\r\n              <strong>read-only here</strong>. The legacy Power App edits ten remark lines on this tab;\r\n              that needs the collections on the write path, which is not built.\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- Remarks (BR-030). Max 11, 72 characters each. -->\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Remarks\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.remarks?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.remarks?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-2\">\r\n                  @for (remark of contract()?.remarks ?? []; track remark.order) {\r\n                    <li class=\"cws:flex cws:gap-3 cws:text-sm\">\r\n                      <!--\r\n                        The number is CMS's, not CTRM's — RmkDS has no sequence subfield, so it is array\r\n                        position. Muted rather than labelled \"seq\" so it is not mistaken for a CTRM id.\r\n                      -->\r\n                      <span\r\n                        class=\"cws:w-5 cws:shrink-0 cws:text-right cws:tabular-nums cws:text-slate-400 cws:dark:text-slate-500\"\r\n                        title=\"Position in CTRM’s array — not a CTRM sequence number\"\r\n                      >\r\n                        {{ remark.order }}\r\n                      </span>\r\n                      <span class=\"cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        @if (remark.type) {\r\n                          <span class=\"cws:mr-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            [{{ remark.type }}]\r\n                          </span>\r\n                        }\r\n                        {{ remark.text }}\r\n                      </span>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Remarks are ' + pendingNote + '.' : 'No remarks.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n\r\n            <!--\r\n              Notes. `whitespace-pre-line` because a note runs to 32 000 characters and will contain its\r\n              own line breaks — collapsing them would turn a structured note into one unreadable\r\n              paragraph.\r\n            -->\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Notes\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.notes?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.notes?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (note of contract()?.notes ?? []; track note.order) {\r\n                    <li class=\"cws:text-sm\">\r\n                      @if (note.prefix || note.code) {\r\n                        <div class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          {{ note.prefix }}{{ note.prefix && note.code ? ' · ' : '' }}{{ note.code }}\r\n                        </div>\r\n                      }\r\n                      <p class=\"cws:whitespace-pre-line cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        {{ note.text }}\r\n                      </p>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Notes are ' + pendingNote + '.' : 'No notes.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (showDocuments()) {\r\n          <!--\r\n            F10.2 — the Documents tab. It reads its own list and content, so the record's own reads are\r\n            untouched by it, and it is appended by this screen rather than configured (see DOCUMENTS_TAB).\r\n          -->\r\n          <cws-contract-documents-tab [contractNumber]=\"contractNumber()\" />\r\n        }\r\n\r\n        @if (showLog()) {\r\n          <!--\r\n            F3.7 — the Log tab: what happened to this contract, a note to add to it, and a message to\r\n            its trader. It carries no form fields, which is why it is appended by this screen rather\r\n            than coming from the resolved configuration (see `LOG_TAB`).\r\n          -->\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- The timeline. Absent where the host offered no audit backend. -->\r\n            @if (logAvailable()) {\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">History</h3>\r\n\r\n              @if (timelineState() === 'loading') {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Loading the history…</p>\r\n              } @else if (timelineState() === 'error') {\r\n                <!--\r\n                  🔴 An unreadable history and an empty one must not look the same. \"Nothing has\r\n                  happened to this contract\" is a claim, and this screen cannot make it here.\r\n                -->\r\n                <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\r\n                  The history for this contract could not be loaded, so what is shown may be\r\n                  incomplete.\r\n                </p>\r\n              } @else if (timeline().length === 0) {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  Nothing has been recorded against this contract yet.\r\n                </p>\r\n              } @else {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (row of timeline(); track row.key) {\r\n                    <li class=\"cws:border-l-2 cws:pl-3\"\r\n                        [class.cws:border-slate-300]=\"row.kind === 'contract'\"\r\n                        [class.cws:border-amber-400]=\"row.kind === 'configuration'\">\r\n                      <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\">\r\n                        {{ row.what }}\r\n                        @if (row.kind === 'configuration') {\r\n                          <!-- Distinguishable, so a configuration edit is never read as a contract change. -->\r\n                          <span\r\n                            class=\"cws:ml-1 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\r\n                          >Configuration</span>\r\n                        }\r\n                      </p>\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        <!-- #567: the reader's local time; the exact instant stays in `datetime`. -->\r\n                        {{ row.actor || 'Unattributed' }} · <time [attr.datetime]=\"row.at\">{{ row.atLabel }}</time>\r\n                      </p>\r\n                      <!--\r\n                        #567: what the write changed, from the entry's detailsJson. Rendered only when\r\n                        it parses and names something, so every other entry reads exactly as before.\r\n                      -->\r\n                      @if (row.changes.length > 0 || row.collectionsReplaced.length > 0) {\r\n                        <dl class=\"cws:mt-1 cws:space-y-0.5 cws:text-xs cws:text-slate-700 cws:dark:text-slate-300\">\r\n                          @for (change of row.changes; track $index) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">{{ change.label }}</dt>\r\n                              <dd>\r\n                                <span>{{ change.from ?? '(empty)' }}</span>\r\n                                <span aria-hidden=\"true\"> → </span>\r\n                                <span class=\"cws:sr-only\"> changed to </span>\r\n                                <span>{{ change.to ?? '(empty)' }}</span>\r\n                              </dd>\r\n                            </div>\r\n                          }\r\n                          @if (row.collectionsReplaced.length > 0) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">Replaced whole</dt>\r\n                              <dd>{{ row.collectionsReplaced.join(', ') }}</dd>\r\n                            </div>\r\n                          }\r\n                        </dl>\r\n                      }\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              }\r\n            </div>\r\n\r\n            }\r\n\r\n            <div class=\"cws:space-y-4\">\r\n              <!-- Add Note. Needs the log backend, which owns the notes write path. -->\r\n              @if (logAvailable()) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Add a note</h3>\r\n\r\n                @if (!notesAreComplete()) {\r\n                  <!--\r\n                    🔴 THE REFUSAL THAT PREVENTS DATA LOSS. Adding a note replaces the whole notes\r\n                    collection, and CTRM returned none of the existing ones — so appending here would\r\n                    delete notes CTRM is holding, and answer 202.\r\n                  -->\r\n                  <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\r\n                    This contract's existing notes could not be read, so a new one cannot be added\r\n                    safely — saving would replace the notes CTRM still holds. Someone needs to shorten\r\n                    the oversized note in CTRM first.\r\n                  </p>\r\n                } @else if (!canWrite()) {\r\n                  <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    Adding a note needs the <strong>Admin</strong> role on this application.\r\n                  </p>\r\n                } @else {\r\n                  <label class=\"cws:mt-2 cws:block\">\r\n                    <span class=\"sr-only\">Note</span>\r\n                    <textarea\r\n                      rows=\"4\"\r\n                      class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      [value]=\"noteText()\"\r\n                      (input)=\"onNoteInput($any($event.target).value)\"\r\n                    ></textarea>\r\n                  </label>\r\n\r\n                  @if (noteRefusal(); as refusal) {\r\n                    <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ refusal }}</p>\r\n                  } @else {\r\n                    <!-- The budget at the control, not only a refusal at save. -->\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      {{ noteBytesRemaining() }} characters remaining\r\n                    </p>\r\n                  }\r\n\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-primary cws:mt-2\"\r\n                    [disabled]=\"!canAddNote()\"\r\n                    (click)=\"onAddNote()\"\r\n                  >\r\n                    @if (noteState().status === 'saving') { Saving… } @else { Add note }\r\n                  </button>\r\n\r\n                  @if (noteState().status === 'failed') {\r\n                    <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                      {{ noteState().message }}\r\n                    </p>\r\n                  }\r\n                }\r\n              </div>\r\n\r\n              }\r\n\r\n              <!-- Save as template (F3.3). -->\r\n              @if (canUseTemplates() && !isCreate()) {\r\n                <div\r\n                  class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n                >\r\n                  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    Save as a template\r\n                  </h3>\r\n\r\n                  <!-- #485: CWS SQL, so permissions only; the CTRM availability gate does not apply. -->\r\n                  @if (!canWriteCws()) {\r\n                    <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      Saving a template needs the <strong>Admin</strong> role on this application.\r\n                    </p>\r\n                  } @else {\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      <!--\r\n                        Says what is captured and what the server removes, because a user who does not\r\n                        know the exclusions exist will expect the template to reproduce the contract\r\n                        exactly and will read the difference as a defect.\r\n                      -->\r\n                      Captures every writable field on this contract as it stands. Fields excluded from\r\n                      copying are removed when the template is read back.\r\n                    </p>\r\n\r\n                    <label class=\"cws:mt-2 cws:block\">\r\n                      <span class=\"sr-only\">Template name</span>\r\n                      <input\r\n                        type=\"text\"\r\n                        class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                        placeholder=\"Template name\"\r\n                        [value]=\"templateName()\"\r\n                        (input)=\"onTemplateNameInput($any($event.target).value)\"\r\n                      />\r\n                    </label>\r\n\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                      [disabled]=\"!canSaveTemplate()\"\r\n                      (click)=\"onSaveTemplate()\"\r\n                    >\r\n                      @if (templateState().status === 'saving') { Saving… } @else { Save as template }\r\n                    </button>\r\n\r\n                    @if (templateState().status === 'saved') {\r\n                      <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n                        Template saved.\r\n                      </p>\r\n                    }\r\n\r\n                    @if (templateState().status === 'failed') {\r\n                      <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                        {{ templateState().message }}\r\n                      </p>\r\n                    }\r\n                  }\r\n                </div>\r\n              }\r\n\r\n              <!-- Notify Trader. Needs the log backend, which owns the route. -->\r\n              @if (logAvailable()) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Notify the trader</h3>\r\n\r\n                <label class=\"cws:mt-2 cws:block\">\r\n                  <span class=\"sr-only\">Message to the trader</span>\r\n                  <textarea\r\n                    rows=\"3\"\r\n                    class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                    [value]=\"notifyText()\"\r\n                    (input)=\"onNotifyInput($any($event.target).value)\"\r\n                  ></textarea>\r\n                </label>\r\n\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                  [disabled]=\"!canNotify()\"\r\n                  (click)=\"onNotifyTrader()\"\r\n                >\r\n                  @if (notifyState().status === 'sending') { Sending… } @else { Notify trader }\r\n                </button>\r\n\r\n                @if (notifyState().status === 'accepted') {\r\n                  <!--\r\n                    🔴 \"Accepted\", never \"sent\". The route answers 202, which on this estate says the\r\n                    request was taken and nothing about whether it reached anybody.\r\n                  -->\r\n                  <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n                    The message was accepted for sending. Acceptance is not confirmation that it\r\n                    arrived.\r\n                  </p>\r\n                }\r\n\r\n                @if (notifyState().status === 'failed') {\r\n                  <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                    {{ notifyState().message }}\r\n                  </p>\r\n                }\r\n              </div>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n      </div>\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: BreadcrumbComponent,
				selector: "cms-breadcrumb",
				inputs: [
					"crumbs",
					"current",
					"context",
					"queryParams"
				]
			},
			{
				kind: "component",
				type: ContractAddendumSectionComponent,
				selector: "cws-contract-addendum-section",
				inputs: [
					"fieldSet",
					"contractNumber",
					"tradeUnit",
					"canGenerate"
				]
			},
			{
				kind: "component",
				type: ContractDocumentsTabComponent,
				selector: "cws-contract-documents-tab",
				inputs: ["contractNumber"]
			},
			{
				kind: "component",
				type: ContractFormComponent,
				selector: "cms-contract-form",
				inputs: [
					"config",
					"tradeUnit",
					"facts",
					"readOnly",
					"instanceId",
					"visibleSections",
					"fieldNotes",
					"emptyNotes",
					"sectionNotes",
					"wideFields",
					"halfFields",
					"fieldCtrmNames",
					"hiddenLabelFields",
					"groupHeadings",
					"readOnlyFields",
					"initialValues",
					"defaultValues"
				],
				outputs: ["ready", "fieldBlur"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep"
				]
			},
			{
				kind: "directive",
				type: DropdownDirective,
				selector: "[cmsDropdown]",
				exportAs: ["cmsDropdown"]
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ContractRecordPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-contract-record-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				BreadcrumbComponent,
				ContractAddendumSectionComponent,
				ContractDocumentsTabComponent,
				ContractFormComponent,
				DataGridComponent,
				DropdownDirective,
				NoticesPanelComponent,
				RefreshButtonComponent,
				RouterLink,
				StatusBadgeComponent
			],
			template: "<!--\r\n  The contract record screen — viewing, editing and creating, from one template.\r\n\r\n  🔴 THE SHAPE, and read this before adding anything to it (JFrisbie, 2026-09-01).\r\n\r\n  This page is four bands and nothing else:\r\n\r\n    1. breadcrumb + actions  where you are, and what you can do to this record\r\n    2. header                what this record IS\r\n    3. summary strip         the at-a-glance state — always visible, every tab, every mode\r\n    4. tabs + body           the fields of ONE tab, then that tab's collections\r\n\r\n  It used to be eleven full-width section cards stacked down the page with all four child grids after\r\n  them, which is \"so many fields prior to the child grids that it's just too much\" — 111 controls before\r\n  the first table. The tabs come from the Power App traders use today (`fxTabOptions`), so the grouping\r\n  is the business's rather than a fourth opinion from this lane. See `CONTRACT_TABS`.\r\n\r\n  The mode is still allowed to change exactly three things — whether the controls accept input, which\r\n  buttons are in the toolbar, and which contextual alerts apply. It must never change the SHAPE, or\r\n  add/edit stops looking like view, which is the whole point of one component.\r\n-->\r\n<section class=\"cws:space-y-4\">\r\n  <!--\r\n    `containerState()`, not the configuration's state alone: the record needs two reads, and gating on\r\n    the configuration rendered a full set of empty controls when the contract read had failed. See the\r\n    component.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    loadingLabel=\"Loading contract\"\r\n    (retry)=\"retry()\"\r\n  >\r\n    @if (bundle(); as loaded) {\r\n      <div class=\"cws:space-y-4\">\r\n        <!--\r\n          🔴 THE TOP ROW — breadcrumb left, record actions hard right (JFrisbie, 2026-09-02).\r\n\r\n          The actions used to sit inside the header card, level with the contract number. They belong\r\n          ABOVE it, for the same reason the workspace grid puts *Add Contract* on its own header row:\r\n          they act on the whole record, so they read as page-level actions rather than as something\r\n          attached to the title. One placement across both screens is the point — nobody should have\r\n          to look somewhere different for the primary action depending on which screen they are on.\r\n\r\n          ⚠ The actions are a SIBLING of the `<nav>`, never inside it. A breadcrumb is navigation and\r\n          the ARIA pattern is what tells a screen-reader user so; anchors dropped in would be\r\n          announced as extra crumbs. The view spec pins the nav at exactly one anchor, so nesting\r\n          them here fails a test rather than shipping quietly.\r\n\r\n          **`items-end`, so the BOTTOM of the buttons meets the bottom of the breadcrumb text**\r\n          (JFrisbie, 2026-09-02). The buttons are ~38px against the crumb's 20px line box, so\r\n          `items-center` left them straddling it and neither edge lined up with anything.\r\n\r\n          ⚠ Not `items-baseline`, which is the tempting one and is wrong here: it would align the\r\n          button's *label* baseline with the crumb's, pushing the button's padding and border below\r\n          the text and putting the bottoms further out than `items-center` had them. The request is\r\n          about the buttons' bottom EDGE, which is a box alignment, not a text one.\r\n\r\n          The grid's header row is also `items-end`; it carries `self-start` on its action block only\r\n          because its left column is a heading over a description and the button was wanted level\r\n          with the top of that. Here the left column is one line, so the row's own alignment stands.\r\n        -->\r\n        <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n          <!--\r\n            The trail back — one definition, shared with the approval review and pricing screens.\r\n\r\n            🔴 **This markup was the original and is now `cms-breadcrumb`.** It was correct here and\r\n            copied almost-correctly elsewhere: the pricing screen had grown an anchor and two spans\r\n            with no list and no `aria-current`, so the same control announced itself as navigation on\r\n            two screens out of three. Extracting the version that was right, rather than writing a\r\n            fourth, is what makes this change a no-op on this screen.\r\n\r\n            ⚠ **`trail()` still owns the JOURNEY** — which screens are behind you, and whether the\r\n            approvals review sits between the queue and here. The component owns only how a trail is\r\n            drawn. Those are different questions and they stayed in different places deliberately.\r\n\r\n            ⚠ `returnParams()` rides on every crumb; see the component for the silent failure that\r\n            guards against.\r\n          -->\r\n          <cms-breadcrumb\r\n            [crumbs]=\"crumbs()\"\r\n            [current]=\"currentCrumb()\"\r\n            [context]=\"tradeUnitLabel()\"\r\n            [queryParams]=\"returnParams()\"\r\n          />\r\n\r\n          <div class=\"cws:flex cws:items-start cws:gap-2\">\r\n            @if (isView()) {\r\n              <!--\r\n                Refresh, to the LEFT of Edit and in view mode only (JFrisbie, 2026-09-03).\r\n\r\n                Re-reads this contract — both reads, the aggregate and `/fields` — without touching the\r\n                route, so the tab you are on and the journey back to the workspace both survive. It\r\n                sits inside the `isView()` branch rather than being rendered disabled in the other\r\n                modes, which is what \"only usable in view/idle\" asks for: while editing, the control\r\n                that re-reads from CTRM would compete with unsaved changes, and a disabled button is an\r\n                invitation to wonder why.\r\n\r\n                ⚠ So this is the one thing on this row that does NOT hold the same position in all\r\n                three modes. That is a deliberate exception to the invariant noted above: Save and\r\n                Cancel still occupy the place Edit and New occupy, and refresh is additive to the view\r\n                mode rather than a fourth mode-dependent slot.\r\n              -->\r\n              <cms-refresh-button\r\n                label=\"Refresh this contract\"\r\n                [busy]=\"isRefreshing()\"\r\n                (refresh)=\"refresh()\"\r\n              />\r\n\r\n            <!--\r\n              🔴 The three WRITE controls, together, gated as one (F4.3a, extending #155).\r\n\r\n              Copy, Edit and New all end at a screen whose Save requires the Admin role, so showing\r\n              them to a reader is an invitation to fill in 111 fields and be refused — the defect\r\n              #155 removed at the Save button, met three steps earlier.\r\n\r\n              ⚠ **Refresh stays outside this gate.** It re-reads the contract, which any signed-in\r\n              user may do (correction C-14 keeps reads un-scoped), and it is the one control on this\r\n              row a reader genuinely wants.\r\n\r\n              🔴 **Hidden, not disabled** — the opposite call from \"Copy contract w/ pricing\" three\r\n              lines down, and the difference is worth stating because both are deliberate. That item\r\n              is disabled because the capability does not exist for ANYONE and naming its blocker is\r\n              useful to every reader. These are absent because they do not exist for THIS ACCOUNT,\r\n              and a row of greyed buttons tells a user nothing they can act on. One sentence below\r\n              says why, once, instead of three disabled promises.\r\n            -->\r\n            @if (canWrite()) {\r\n                <!--\r\n                  Copy, immediately right of Refresh (JFrisbie, 2026-09-10). BR-041.\r\n\r\n                  **One icon trigger opening a menu of two, rather than two buttons** (JFrisbie,\r\n                  2026-09-10). The first revision put both on the row, which made five controls and\r\n                  629px of toolbar for what is one decision with two answers — and it gave the rarer,\r\n                  currently-unavailable option exactly as much prominence as the ordinary one.\r\n\r\n                  Same shape as the workspace's Export menu: `cmsDropdown` for the open/close\r\n                  behaviour, `role=\"menu\"` markup owned here. The directive is deliberately behaviour\r\n                  and not a component, because a shared component would have had to pick between\r\n                  `role=\"menu\"` and `role=\"listbox\"` for every caller.\r\n\r\n                  ⚠ **The directive's Escape handling matters more on this screen than anywhere else.**\r\n                  This record screen binds Escape to navigate back to the contract list, and\r\n                  `DropdownDirective` calls `preventDefault()` when Escape actually dismissed a panel —\r\n                  so closing this menu with Escape does not also throw the user off the record. That\r\n                  interaction is already handled; do not add a local Escape listener.\r\n                -->\r\n                <div cmsDropdown #copyMenu=\"cmsDropdown\" class=\"cws:relative\">\r\n                  <!--\r\n                    Icon-only, so it needs both an `aria-label` and the 20px line box.\r\n\r\n                    🔴 **`h-5` on the icon wrapper is load-bearing, not decoration.** A `scoular-btn`\r\n                    is 38px only while it contains *text*: `py-2` plus a `text-sm` line box plus a 1px\r\n                    border. An icon has no line box, so an icon-only button renders **36px** and sits\r\n                    two pixels short of Edit and New beside it. The wrapper restores the line box the\r\n                    missing text would have occupied — and `h-5` is chosen because **height is\r\n                    uncontested**: the design system compiles unlayered and would beat a utility\r\n                    fighting its `py-2`, but it never declares a height. Measured at 38px against the\r\n                    other three controls across five viewport widths.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-secondary\"\r\n                    aria-label=\"Copy this contract\"\r\n                    title=\"Copy this contract\"\r\n                    aria-haspopup=\"menu\"\r\n                    [attr.aria-expanded]=\"copyMenu.open()\"\r\n                    (click)=\"copyMenu.toggle()\"\r\n                  >\r\n                    <span class=\"cws:flex cws:h-5 cws:items-center\" aria-hidden=\"true\">\r\n                      <!--\r\n                        Two offset rounded rectangles — the conventional duplicate mark. Stroked in\r\n                        currentColor so it inherits the button's text colour in both themes, and\r\n                        `size-4` to match the refresh mark immediately left of it.\r\n                      -->\r\n                      <svg\r\n                        viewBox=\"0 0 24 24\"\r\n                        fill=\"none\"\r\n                        stroke=\"currentColor\"\r\n                        stroke-width=\"2\"\r\n                        stroke-linecap=\"round\"\r\n                        stroke-linejoin=\"round\"\r\n                        class=\"cws:size-4 cws:shrink-0\"\r\n                      >\r\n                        <rect x=\"8\" y=\"8\" width=\"14\" height=\"14\" rx=\"2\" ry=\"2\" />\r\n                        <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\" />\r\n                      </svg>\r\n                    </span>\r\n                  </button>\r\n\r\n                  @if (copyMenu.open()) {\r\n                    <!--\r\n                      `w-80` because the second item's subtext explains why it is unavailable, and the\r\n                      panel's own `min-w-[12rem]` would wrap it into four lines.\r\n\r\n                      Left-anchored (`right-0`) like every other menu on this row's side of the page,\r\n                      so it opens inward rather than off the edge of the viewport.\r\n                    -->\r\n                    <div\r\n                      class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\"\r\n                      role=\"menu\"\r\n                      aria-label=\"Copy contract\"\r\n                    >\r\n                      <div class=\"scoular-dropdown-header\">Create a copy of {{ contractNumber() }}</div>\r\n\r\n                      <!--\r\n                        An anchor rather than a button, so middle-click and \"open in new tab\" work and\r\n                        it carries a real `href` — the same reasoning the breadcrumb crumbs carry. It\r\n                        addresses the ordinary create route with a seed parameter, so a copy is a\r\n                        linkable URL rather than transient in-memory state: reload it and you still\r\n                        get the copy.\r\n\r\n                        ⚠ It carries no `returnTo`. The copy's Cancel goes to the workspace, exactly as\r\n                        an ordinary create's does, because abandoning a create should not land the user\r\n                        back on someone else's contract as though they had been editing it.\r\n\r\n                        `text-left` on the item is load-bearing for the same reason the Export menu\r\n                        records: `.scoular-dropdown-item` inherits `text-align: center` from `<button>`,\r\n                        and a subtext long enough to wrap centres its second line.\r\n                      -->\r\n                      <a\r\n                        role=\"menuitem\"\r\n                        class=\"scoular-dropdown-item cws:text-left\"\r\n                        [attr.href]=\"hrefFor(copyIntent())\"\r\n                        (click)=\"copyMenu.close(); follow($event, copyIntent())\"\r\n                      >\r\n                        <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                          <span>Copy contract</span>\r\n                          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            Every field, a new contract number, no pricing\r\n                          </span>\r\n                        </span>\r\n                      </a>\r\n\r\n                      <!--\r\n                        🔴 **Present and DISABLED, naming its blocker** — the precedent this screen\r\n                        already set for Edit before the upsert existed. It is not a placeholder for\r\n                        unfinished work: the pricing half cannot be written from this application at\r\n                        all today, for two independent reasons, both upstream of anything the SPA can\r\n                        do.\r\n\r\n                        1. **`prices` is not writable on `upsertContract`.** `constraints.json` — the\r\n                           generated single source for field metadata — declares\r\n                           `\"prices\": { \"writable\": false }`, because the collection is not a\r\n                           `ContractDS` member. `CtrmContractMerge` strips it deliberately, and sending\r\n                           it risks the origin `500` Tier 2 measured for an undeclared field. So prices\r\n                           cannot ride the create that copies the contract, however the payload is\r\n                           shaped.\r\n                        2. ~~**The API exposes no pricing route.**~~ **No longer true, and struck rather\r\n                           than deleted because it was half the stated reason this item is disabled.**\r\n                           `PricingEndpoints` shipped in PR #254, so the SPA *can* send prices as a\r\n                           second call. The item stays disabled on reason 1 alone — plus the partial\r\n                           failure below, which is the harder half and was always the real objection.\r\n\r\n                        ⚠ A working version is a **sequenced two-step write** — create the contract,\r\n                        then post its prices — whose second step can fail after the first has succeeded\r\n                        and spent an unreclaimable contract number. That is a real decision about\r\n                        partial failure, not plumbing, which is why this is disabled rather than\r\n                        half-built.\r\n\r\n                        Disabled rather than hidden **on purpose**: both options were asked for, and a\r\n                        silently absent one reads as an oversight where this states why. The subtext\r\n                        carries the reason visually and `aria-describedby` carries it to a screen\r\n                        reader — the `sr-only` span is the fuller sentence, because \"CTRM cannot\r\n                        receive prices on a create\" is the actionable half.\r\n                      -->\r\n                      <button\r\n                        type=\"button\"\r\n                        role=\"menuitem\"\r\n                        disabled\r\n                        class=\"scoular-dropdown-item cws:text-left\"\r\n                        aria-describedby=\"copy-with-pricing-blocker\"\r\n                      >\r\n                        <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n                          <span>Copy contract w/ pricing</span>\r\n                          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            Not available yet — CTRM cannot receive prices on a contract create\r\n                          </span>\r\n                        </span>\r\n                      </button>\r\n\r\n                      <!--\r\n                        The disabled item's full reason, for a screen reader. `sr-only` positions\r\n                        absolutely, so it is out of flow and cannot affect the menu's layout — which is\r\n                        the trap that lifted a grid row by 28px on 2026-09-09, when `sr-only` went on a\r\n                        label row instead of on the label text.\r\n                      -->\r\n                      <span id=\"copy-with-pricing-blocker\" class=\"sr-only\">\r\n                        Copying with pricing is not available yet. CTRM cannot receive prices on a\r\n                        contract create. Copy the contract, then add its price sequences on the pricing\r\n                        screen once it is saved.\r\n                      </span>\r\n                    </div>\r\n                  }\r\n                </div>\r\n\r\n                <!--\r\n                  F3.5 — close / re-open, offered only where the host provided the action and the\r\n                  contract has loaded. Gated on `canWrite()` with the rest of this block.\r\n\r\n                  🔴 **Close CONFIRMS, and the confirmation carries the provenance sentence** — closing\r\n                  rewrites pricing-approval provenance and re-opening does not put it back, so the pair\r\n                  is not symmetric and the dialog says so rather than implying an undo.\r\n                -->\r\n                @if (canChangeState()) {\r\n                  @if (isClosed()) {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working'\"\r\n                      (click)=\"onReopenContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Re-opening… } @else { Re-open contract }\r\n                    </button>\r\n                  } @else {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary\"\r\n                      [disabled]=\"stateAction().status === 'working'\"\r\n                      (click)=\"onCloseContract()\"\r\n                    >\r\n                      @if (stateAction().status === 'working') { Closing… } @else { Close contract }\r\n                    </button>\r\n                  }\r\n                }\r\n\r\n                <!-- Carries the tab, so Edit → Cancel returns you to the tab you were reading. -->\r\n                <a\r\n                  [attr.href]=\"hrefFor(editIntent())\"\r\n                  (click)=\"follow($event, editIntent())\"\r\n                  class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                >\r\n                  Edit contract\r\n                </a>\r\n\r\n                <a\r\n                  [attr.href]=\"hrefFor(newIntent)\"\r\n                  (click)=\"follow($event, newIntent)\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                >\r\n                  New contract\r\n                </a>\r\n            } @else {\r\n              <!--\r\n                The reason, once — matching the wording the Save gate already uses so a user who\r\n                meets both does not read them as two different problems.\r\n\r\n                `role=\"status\"` rather than `alert`: it is a standing property of the screen, not\r\n                something that just happened.\r\n              -->\r\n              <p role=\"status\" class=\"cws:self-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                Editing needs the <strong>Admin</strong> role on this application.\r\n              </p>\r\n            }\r\n            } @else {\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n                [disabled]=\"!canSave()\"\r\n                (click)=\"onSave()\"\r\n              >\r\n                @if (save().status === 'saving') {\r\n                  Saving…\r\n                } @else {\r\n                  <!--\r\n                    **One label in both modes** — \"Save contract\" whether adding or editing (JFrisbie,\r\n                    2026-09-03). It read \"Create contract\" on a create and \"Save changes\" on an edit.\r\n                    One verb for one action: the button does the same thing to the same record either\r\n                    way, and the mode is already unmistakable from the heading, the breadcrumb and the\r\n                    URL.\r\n\r\n                    ⚠ It therefore stops being the thing that tells the two modes apart, which two\r\n                    tests were using it for. Those now discriminate on the **heading** — \"New contract\"\r\n                    against the contract number — which is the more honest signal anyway: it is what a\r\n                    user reads to know which record they are on.\r\n                  -->\r\n                  Save contract\r\n                }\r\n              </button>\r\n\r\n              @if (!canWrite()) {\r\n                <!--\r\n                  🔴 The REASON, not just a grey button (#155). Writing contracts needs the Admin app\r\n                  role — `CwsContractWriter` — while reading needs only Admin or User, so a perfectly\r\n                  legitimate user reaches this screen, fills it in and is refused at Save with nothing\r\n                  having said why.\r\n\r\n                  ⚠ Worded as what the account lacks rather than \"you do not have permission\", because\r\n                  the fix is an Entra app-role assignment someone has to request by name — the same\r\n                  reason the trade-unit picker names the role rather than saying access denied (#65).\r\n\r\n                  `role=\"status\"` rather than `alert`: it is a standing condition of the screen, not an\r\n                  event, and an assertive announcement on every render of a read-only record is noise.\r\n                -->\r\n                <!--\r\n                  #485: a night run now closes the availability gate every night, and an Admin was told\r\n                  they lacked the Admin role. The two gates have two sentences; the role one wins when\r\n                  both are closed, because it is the one the user can act on.\r\n                -->\r\n                @if (canWriteCws() && blockedByAvailability()) {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving to CTRM is paused: {{ availabilityTitle() }}. Your changes stay on this\r\n                    screen.\r\n                  </p>\r\n                } @else {\r\n                  <p\r\n                    role=\"status\"\r\n                    class=\"cws:w-full cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\"\r\n                  >\r\n                    Saving needs the <strong>Admin</strong> role on this application. Your account can\r\n                    view contracts but not write them.\r\n                  </p>\r\n                }\r\n              }\r\n\r\n              <!--\r\n                Cancel carries its OWN parameters, not Edit's. An edit returns to this record on the tab\r\n                it was editing; a create returns to the workspace, where a `tab` parameter would be\r\n                meaningless noise in a URL people copy and share.\r\n              -->\r\n              <a\r\n                [attr.href]=\"hrefFor(cancelIntent())\"\r\n                (click)=\"follow($event, cancelIntent())\"\r\n                class=\"scoular-btn scoular-btn-secondary\"\r\n              >\r\n                Cancel\r\n              </a>\r\n            }\r\n          </div>\r\n\r\n          @if (stateAction().status === 'failed') {\r\n            <!--\r\n              An alert, not a status: this DID just happen, and it needs to interrupt. It also states\r\n              that nothing changed, because the failure a user most fears here is a half-applied one.\r\n            -->\r\n            <p\r\n              role=\"alert\"\r\n              class=\"cws:mt-2 cws:rounded cws:border cws:border-red-300 cws:bg-red-50 cws:px-3 cws:py-2 cws:text-xs cws:text-red-900 cws:dark:border-red-700 cws:dark:bg-red-950 cws:dark:text-red-100\"\r\n            >\r\n              {{ stateAction().message }}\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        <!--\r\n          Header band. The contract number is the page's identity, so it is the h2 — the shell owns the\r\n          only h1.\r\n\r\n          The actions moved out of this card onto the row above it; see the comment there. What has NOT\r\n          changed is that they occupy the same place in all three modes, so the toolbar does not move\r\n          under the pointer when the mode changes — that invariant is why the whole block moved rather\r\n          than only the two view-mode buttons.\r\n        -->\r\n        <header\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <div class=\"cws:space-y-1\">\r\n            <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n              <!--\r\n                The same heading in view and edit, on purpose: a record's identity does not change\r\n                because it is being edited. A create has no number yet — CTRM issues it at reservation\r\n                (03 §2.6) — so the heading says what is being made.\r\n              -->\r\n              <h2 class=\"cws:text-xl cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                {{ isCreate() ? 'New contract' : contractNumber() }}\r\n              </h2>\r\n              @if (contract()?.version; as version) {\r\n                <!-- CTRM's version, not a CMS revision. Muted so it cannot be read as part of the key. -->\r\n                <span\r\n                  class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n                  title=\"CTRM contract version\"\r\n                >\r\n                  v{{ version }}\r\n                </span>\r\n              }\r\n            </div>\r\n            <!--\r\n              🔴 The header as an executive summary (JFrisbie, 2026-09-15 — UX brief item 1): what\r\n              contract this is, and the business context, without scrolling.\r\n\r\n              ⚠ **Status and the key quantities are deliberately NOT repeated here.** The brief's\r\n              sketch puts them in this block; they already sit in the summary band immediately below,\r\n              which is always visible in every mode and on every tab. Two copies of \"Priced 9,000 BU\"\r\n              one line apart is a number that can disagree with itself, which this repository has paid\r\n              for more than once — and the band is not a scroll away, it is the next element.\r\n\r\n              ⚠ **\"Last Modified\" is absent because CTRM does not send one.** Nothing on the aggregate\r\n              carries it; `version` is the nearest thing CTRM has and it is already beside the number.\r\n              Inventing a timestamp from the read would be a fact about our request, not the contract.\r\n\r\n              ⚠ **The CUSTOMER here is the id.** `getContract` carries no customer-name field and\r\n              never will; the name comes from the customer directory and is shown on the Customer\r\n              name field below, where the record screen also confirms a typed id on blur (F4.3b).\r\n              The header keeps the id because the id is the fact CTRM holds.\r\n            -->\r\n            <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n              @if (contract(); as detail) {\r\n                <!--\r\n                  Both the code and the name where we have them, for the same reason the grid's heading\r\n                  carries both: a code identifies a trade unit to CTRM, a name identifies it to a trader.\r\n                -->\r\n                {{ detail.header.commodity ?? 'Commodity not set' }}\r\n                @if (detail.header.tradeUnit) {\r\n                  · Trade unit {{ detail.header.tradeUnit }}\r\n                }\r\n                @if (detail.header.customerId) {\r\n                  · Customer {{ detail.header.customerId }}\r\n                }\r\n                @if (contractDateLabel(); as date) {\r\n                  · {{ date }}\r\n                }\r\n                @if (traderLabel(); as trader) {\r\n                  · Trader {{ trader }}\r\n                }\r\n              } @else {\r\n                Trade unit {{ loaded.config.tradeUnit }} · Field definitions from CTRM\r\n              }\r\n            </p>\r\n          </div>\r\n\r\n        </header>\r\n\r\n        <!--\r\n          🔴 THE SUMMARY STRIP — the at-a-glance state, above the tabs and outside them.\r\n\r\n          Confirmations (docs/02 §4.4) and CTRM's computed quantity breakdown (docs/04 §6) were two\r\n          full-width cards stacked before any field, and then invisible from wherever you scrolled to.\r\n          They are the answers to \"is this approved\" and \"what is left to price\", which are the two\r\n          questions somebody opens a contract to ask — so they sit in one compact band that never\r\n          scrolls away behind a tab.\r\n\r\n          ⚠ **These are NOT form fields and must not become inputs.** All six quantities are\r\n          `access: readOnly` in the constraint dictionary — CTRM refuses them on a write — and all three\r\n          confirmation statuses are derived by BR-065 from a populated field. An input box here would\r\n          invite an edit that cannot exist.\r\n        -->\r\n        <!--\r\n          🔴 **ONE ROW, and the height is the requirement** (JFrisbie, 2026-09-15, from a screenshot).\r\n\r\n          This briefly stacked — confirmations above, a six-card quantity grid below — which gave the\r\n          cards room and cost roughly three times the vertical space on a band whose whole job is to be\r\n          glanceable without scrolling. The boxes are kept and made compact instead: label and value on\r\n          ONE line rather than stacked, so each is a chip rather than a tile.\r\n\r\n          ⚠ `items-center` and `gap-x-8`, not `justify-between` alone — the two groups wrap\r\n          independently at narrow widths, and without a row gap they collide before they wrap.\r\n        -->\r\n        <!--\r\n          🔴 **No border and no shadow on the band itself** (2026-09-21 restyle).\r\n\r\n          The card sat inside a page that already separates it — white on slate-50 in light, slate-800\r\n          on slate-900 in dark — so the border and the shadow were the outermost of THREE nested\r\n          borders around the same information. Removing it costs 2px of height and one visual edge.\r\n\r\n          ⚠ **The fill and the rounding stay.** Without them the band stops being an object and the\r\n          chips read as loose text under the header, which is the failure the original card was\r\n          solving. What is gone is the chrome, not the container.\r\n        -->\r\n        <div\r\n          class=\"cws:flex cws:flex-col cws:gap-3 cws:rounded-lg cws:bg-white cws:px-4 cws:py-3 cws:lg:flex-row cws:lg:flex-wrap cws:lg:items-center cws:lg:justify-between cws:lg:gap-x-8 cws:dark:bg-slate-800\"\r\n        >\r\n          <!--\r\n            🔴 WORKFLOW CARDS, not inline pills (JFrisbie, 2026-09-15 — UX brief item 2).\r\n\r\n            The three statuses read as disconnected captions in a row. As cards they read as what they\r\n            are: three checkpoints on one contract, each with a state.\r\n\r\n            ⚠ **Three independent fields that happen to progress, NOT a state machine.** BR-065 derives\r\n            each from a populated field, so a later stage can be set with an earlier one blank — which\r\n            is why these stay three separate cards rather than becoming a connected stepper. A stepper\r\n            would assert an ordering the data does not have, and would render a contract whose broker\r\n            confirmed before its trader approved as though something had gone wrong.\r\n\r\n            The pill keeps the colour. It carries the state in a word as well as a hue, which is what\r\n            makes the card readable without relying on colour at all.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Contract confirmations\">\r\n            @for (stage of confirmations(); track stage.label) {\r\n              <!--\r\n                🔴 **The chip IS the status now — no pill inside it.** The tint, the dot and the word\r\n                are one box.\r\n\r\n                🔴 **`items-baseline` + an explicit `/5` leading on every text node, and this is the\r\n                whole alignment story for the band** (JFrisbie, 2026-09-21, from a screenshot of the\r\n                running app).\r\n\r\n                The first version of this restyle used `items-center` here and `items-baseline` on the\r\n                quantity chips, with `h-7` fixing the box height. Every box lined up — measured at a\r\n                uniform 28px, which is why the geometry pass called it done — and **the TEXT inside\r\n                them sat on four different baselines**: 46, 47, 48.8 and 51, a 5px spread. `Rejected`\r\n                floated against its own label, and the six metrics sat on a different line from the\r\n                three statuses.\r\n\r\n                🔑 **`items-center` centres each flex item independently**, so an 11px label and a 14px\r\n                value in the same chip are centred separately and their baselines cannot agree. And a\r\n                fixed `h-7` hid it: the boxes were identical, so nothing about the geometry looked\r\n                wrong.\r\n\r\n                The fix is to let the LINE BOX set the height instead. Both text nodes carry `/5`\r\n                (20px), padding is `py-1`, so every chip is 4 + 20 + 4 = **28px — exactly what `h-7`\r\n                was giving** — but now derived from a shared line box, so all eighteen pieces of text\r\n                in the ribbon rest on one baseline.\r\n\r\n                ⚠ **Do not reintroduce `h-7`, and do not drop the `/5`.** Either one restores a height\r\n                that is correct while the text inside drifts, which is the failure a box measurement\r\n                cannot see.\r\n              -->\r\n              <!--\r\n                (The chips were previously 36/34/30 tall depending on whether a badge was inside;\r\n                that raggedness is what the uniform line box removed.)\r\n\r\n                🔑 **The dot is not decoration.** Roughly 1 in 12 men has a colour vision deficiency\r\n                (docs/02a §4), and the state is already carried by the WORD — the dot adds a second\r\n                non-colour cue of position and presence, so the three stages are distinguishable at a\r\n                glance even where the hues are not.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-2 cws:rounded-md cws:px-2.5 cws:py-1\"\r\n                [class]=\"stage.style.chip\"\r\n              >\r\n                <!--\r\n                  ⚠ `self-center`, because an empty inline box has its baseline at its BOTTOM edge —\r\n                  under `items-baseline` the dot would otherwise sit on the text baseline rather than\r\n                  beside the middle of the word.\r\n                -->\r\n                <span\r\n                  class=\"cws:size-1.5 cws:shrink-0 cws:self-center cws:rounded-full\"\r\n                  [class]=\"stage.style.dot\"\r\n                ></span>\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  {{ stage.label }}\r\n                </dt>\r\n                <dd class=\"cws:shrink-0 cws:text-sm/5 cws:font-semibold\" [class]=\"stage.style.text\">\r\n                  @if (stage.badge; as badge) {\r\n                    {{ badge.label }}\r\n                  } @else {\r\n                    <!--\r\n                      ⚠ Still visibly DIFFERENT from a set status rather than an empty pill — the\r\n                      neutral tone plus a lighter weight. An empty pill reads as a status; this reads\r\n                      as no status, which is the truth.\r\n                    -->\r\n                    <span class=\"cws:font-normal\" [title]=\"stage.emptyNote ?? ''\">Not set</span>\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n\r\n          <!--\r\n            🔴 KPI CARDS, not label/value pairs (JFrisbie, 2026-09-15 — UX brief item 3).\r\n\r\n            These were six captions in a flex row, which is how the most important numbers on the page\r\n            ended up the most visually understated. As cards the figure leads and the label supports\r\n            it, which is the reading order a trader actually wants.\r\n\r\n            CTRM's numbers, never recalculated here: disagreeing with the system of record about a\r\n            settled quantity would be worse than not showing it. `tabular-nums` so the figures line up\r\n            as a column of numbers rather than drifting with their digit widths.\r\n\r\n            ⚠ **The unit travels with the number** — see `quantityBreakdown`. A bare grain quantity is a\r\n            recorded defect on this project, not a nicety.\r\n          -->\r\n          <dl class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\" aria-label=\"Quantity breakdown\">\r\n            @for (measure of quantityBreakdown(); track measure.label) {\r\n              <!--\r\n                🔴 **A fill, not a border, and no left accent.** These were bordered pills carrying a\r\n                4px coloured edge each — six of them, which was the densest chrome in the band. A flat\r\n                tint separates a chip from the card just as well and draws no lines.\r\n\r\n                ⚠ **Uniformly slate, deliberately.** Colour in this band means status; these are\r\n                arithmetic. The removed accent and the reasoning are on `quantityBreakdown`.\r\n\r\n                The hierarchy is carried by weight and size instead: the label drops to 11px and the\r\n                figure stays `font-semibold`, so the number leads its chip without either growing.\r\n              -->\r\n              <div\r\n                class=\"cws:flex cws:items-baseline cws:gap-1.5 cws:rounded-md cws:bg-slate-100 cws:px-2.5 cws:py-1 cws:dark:bg-slate-700/40\"\r\n              >\r\n                <dt\r\n                  class=\"cws:text-[11px]/5 cws:font-medium cws:uppercase cws:tracking-wide cws:text-slate-600 cws:dark:text-slate-400\"\r\n                >\r\n                  {{ measure.label }}\r\n                </dt>\r\n                <dd class=\"cws:text-sm/5 cws:font-semibold cws:tabular-nums cws:text-slate-900 cws:dark:text-white\">\r\n                  @if (measure.value === null) {\r\n                    <!-- An em dash, never 0: CTRM holding no figure is not a quantity of nothing. -->\r\n                    <span class=\"cws:font-normal cws:text-slate-400 cws:dark:text-slate-500\">—</span>\r\n                  } @else {\r\n                    {{ measure.value.toLocaleString('en-US') }}\r\n                    @if (measure.uom; as uom) {\r\n                      <span class=\"cws:text-[11px]/5 cws:font-normal cws:text-slate-600 cws:dark:text-slate-400\">\r\n                        {{ uom }}\r\n                      </span>\r\n                    }\r\n                  }\r\n                </dd>\r\n              </div>\r\n            }\r\n          </dl>\r\n        </div>\r\n\r\n        <!--\r\n          🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\r\n          workspace grid and the approval screens. Up to five full-width banners used to sit between\r\n          the summary strip and the tabs, so on a create the form began below the fold.\r\n\r\n          ⚠ **Widened 2026-09-17 to nine, and four of them came from OUTSIDE this stack** — the copy\r\n          provenance, the create-pending note, the configuration provenance line under the tabs, and\r\n          the unmodelled-collections note that sat at the very bottom of the record. They were not\r\n          part of the original five because they were not full-width banners between the strip and\r\n          the tabs; they were still standing conditions, and scattering them was costing more than\r\n          their individual size suggested.\r\n\r\n          🔴 **What is in here and what is NOT is the load-bearing decision, and it is not about\r\n          length.** Standing conditions of the screen go in; **the outcome of something the user just\r\n          did stays out** — every banner below this point is the second kind (a save result, a save\r\n          failure, a copy whose source could not be read, a contract number that was not issued, a\r\n          prefill that failed). Two of those carry `role=\"alert\"` because they must interrupt, and\r\n          behind a collapsed panel they would be messages nobody sees. Before this change both kinds\r\n          rendered identically, which is exactly why the distinction needs stating.\r\n\r\n          ⚠ **The summaries live in `noticeSummaries` and must stay in this order.** Nothing enforces\r\n          it.\r\n        -->\r\n        <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n          @if (isSimulated()) {\r\n            <!--\r\n              Same banner and the same reason as the grid: a demo that silently shows generated data is\r\n              how generated data gets quoted as a production readout.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Simulated data</div>\r\n              <div class=\"scoular-alert-description\">\r\n                This contract is generated locally, not read from CTRM.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCopy() && !copyFailed()) {\r\n            <!--\r\n              A copy says what it is a copy of, and says what it did NOT bring with it.\r\n\r\n              🔴 The second half is the load-bearing half. A user who pressed \"Copy contract\" has every\r\n              reason to believe the new contract carries everything the old one did, and three things it\r\n              cannot carry are invisible on this screen: the number (deliberately — see\r\n              `CONTRACT_COPY_IDENTITY_FIELDS`, it is what stops the copy overwriting its source), the\r\n              prices (CTRM cannot receive them on a create at all), and the child collections (this\r\n              screen has no way to send them yet — see issue 187's frontend half). Stating them here is\r\n              the difference between a copy the user can trust and one they have to audit.\r\n\r\n              ⚠ **In the panel, where the copy FAILURE three blocks below is not, and the split is the\r\n              membership rule rather than a judgement about length.** \"This record is a copy of X\" is\r\n              true for the whole life of the screen — a standing condition of what the user is looking\r\n              at. \"X could not be read\" is the outcome of the action they just took, it carries\r\n              `role=\"alert\"`, and behind a disclosure it would be a message nobody sees.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Copied from {{ copyFrom }}</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Every writable field was carried across and can be changed before saving. A\r\n                <strong>new contract number</strong> has been issued — this will create a new contract\r\n                and cannot alter {{ copyFrom }}.\r\n                <strong>Pricing, ship periods, remarks and notes were not copied</strong> and need\r\n                entering separately once this contract is saved.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate() && canUseTemplates()) {\r\n            <!--\r\n              F3.3 — create from a template.\r\n\r\n              🔴 **Applying a template seeds the FULL set it carries, not the fields somebody typed.**\r\n              A template is captured whole precisely so applying it is whole; carrying only part of it\r\n              across is the defect that generalised from one field to forty.\r\n\r\n              ⚠ Through `seed`, so the values arrive as defaults rather than as edits — the same\r\n              distinction the customer-name confirmation makes, and it matters because six derived\r\n              descriptions sit on CTRM's re-confirmation list.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Start from a template</div>\r\n              <div class=\"scoular-alert-description\">\r\n                @if (templatesFailed()) {\r\n                  <!-- Not the same as \"this trade unit has none\", which would be a claim. -->\r\n                  <span>The templates for this trade unit could not be loaded.</span>\r\n                } @else if (availableTemplates().length === 0) {\r\n                  <span>This trade unit has no saved templates yet.</span>\r\n                } @else {\r\n                  <label class=\"cws:flex cws:items-center cws:gap-2\">\r\n                    <span>Apply a template</span>\r\n                    <select\r\n                      class=\"cws:rounded cws:border cws:border-slate-300 cws:p-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      (change)=\"onApplyTemplate($any($event.target).value)\"\r\n                    >\r\n                      <option value=\"\">Choose…</option>\r\n                      @for (template of availableTemplates(); track template.id) {\r\n                        <option [value]=\"template.id\">{{ template.name }}</option>\r\n                      }\r\n                    </select>\r\n                  </label>\r\n\r\n                  @if (appliedTemplate(); as applied) {\r\n                    <p class=\"cws:mt-1\">\r\n                      Applied <strong>{{ applied }}</strong>. Every value it carried can be changed\r\n                      before saving.\r\n                    </p>\r\n                  }\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isCreate()) {\r\n            <!--\r\n              Why the confirmation pills and the quantity breakdown are empty on a create.\r\n\r\n              ⚠ **The per-stage `emptyNote` is a `title` attribute only**, so it is a tooltip and not a\r\n              visible statement — this is the only place the reason is readable. It moved in here rather\r\n              than being deleted: a panel summary renders in BOTH states, so it is still on screen.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some values appear once this contract is saved</div>\r\n              <div class=\"scoular-alert-description\">\r\n                Confirmations and CTRM’s computed quantity breakdown are {{ pendingNote }}, so those\r\n                panels are empty rather than failing to load.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable()) {\r\n            <!--\r\n              The standing caveat about what can be ENTERED — one of the three things the mode may\r\n              change, which is why it is gated on the mode rather than shown always.\r\n\r\n              ⚠ **This is the notice in here with the strongest claim to being left out**, and it is\r\n              the one to pull back up if the panel proves too quiet. Known Issue 30's instruction is\r\n              that anyone shown this screen reads it as the agreed field set, and unlike the approval\r\n              screen's CTRM caveat **there is no restatement of this at the point of action** — no\r\n              message appears at Save saying the contract has no ship periods. What makes collapsing\r\n              it defensible rather than a loss: the omission is *recoverable* (ship periods can be\r\n              added in CTRM afterwards) and the fields are optional, so a contract saved without them\r\n              is valid rather than wrong.\r\n            -->\r\n            <!--\r\n              🔴 **REWORDED 2026-09-25 (ruled by JFrisbie on #226). The previous text said shipment\r\n              dates \"cannot be entered here\", and that stopped being true when F2.3b built the\r\n              editable ship-period table** — which is available in create mode, since the editable\r\n              branch is gated on the form being writable rather than on the record existing.\r\n\r\n              ⚠ **What is kept is the half #226 was actually about**: they are OPTIONAL, a contract\r\n              saved without them genuinely has NONE, and CTRM derives none of its own. That was\r\n              settled from CTRM source rather than by spending a contract number — ship periods are\r\n              twelve positional slots and the read unpivots them on a non-sentinel begin date, so a\r\n              slot nobody filled never becomes a row. A user who assumes CTRM fills them in gets a\r\n              contract with zero ship periods and does not know it.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <!--\r\n                ⚠ Deliberately NOT word-for-word the panel summary. They render together when the\r\n                panel is open, and two identical lines read as a rendering fault; the summary states\r\n                the fact and the title states the consequence.\r\n              -->\r\n              <div class=\"scoular-alert-title\">Shipment dates are optional, not missing</div>\r\n              <div class=\"scoular-alert-description\">\r\n                All 108 of CTRM’s writable contract fields are here, and\r\n                <strong>ship periods can be entered on the Shipping tab</strong>. They are\r\n                <strong>optional</strong>, not missing: a contract saved without them genuinely has none,\r\n                because CTRM derives no shipment dates of its own. If you do enter them, CTRM refuses a\r\n                contract whose ship quantities do not sum to the header quantity — this screen states\r\n                the running total and blocks Save while they disagree, so that refusal is not reached.\r\n                Fields, widths and decimal places are read from CTRM’s own definitions, so what\r\n                you type is validated exactly as CTRM would; the tab grouping follows the Power App, and\r\n                the <em>Additional fields</em> tab holds the CTRM fields it never surfaced.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (configDefaultsOnly()) {\r\n            <!--\r\n              The configuration could not be resolved, so this record is on the layout's defaults.\r\n\r\n              The consequence is actionable and invisible otherwise: a field an admin marked required\r\n              may not be marked required here, and one they hid may be showing. The save still enforces\r\n              the real configuration server-side, so the failure a user would otherwise meet is a\r\n              refusal naming a field the form never asked for — which reads as a bug in the form.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Showing default field settings</div>\r\n              <div class=\"scoular-alert-description\">\r\n                The form configuration could not be loaded, so this record shows every field with default\r\n                settings. Anything an administrator has configured for this trade unit — hidden fields,\r\n                extra required fields, custom tabs — is not reflected here. Saving still applies the real\r\n                configuration, so a save may be refused for a field this form did not mark as required.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (isEditable() && unavailableLists().length > 0) {\r\n            <!--\r\n              Which dropdowns have no values, and why. A combo rendering an empty list looks like a bug in\r\n              this screen; it is a known gap in the reference route (issues 44 and 83).\r\n\r\n              ⚠ The description names no issue number: a trader cannot open one, and the sentence has to\r\n              stand on its own as \"typed, not picked, and that is expected\".\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Some lists are unavailable</div>\r\n              <div class=\"scoular-alert-description\">\r\n                {{ unavailableLists().join(', ') }} returned no values, so those fields accept a typed code\r\n                instead of offering a list. The reference routes they need are parameterised and not\r\n                callable yet.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (unmodelled().length > 0) {\r\n            <!--\r\n              🔑 Shown deliberately, and the endpoint goes out of its way to make it possible.\r\n\r\n              These are child collections CTRM DOES return and CMS does not read yet. Hiding them would\r\n              make this screen answer \"this contract has no quality factors\" when the truth is \"CMS does\r\n              not read quality factors\" — a difference that matters to anyone using this screen to check\r\n              data, and one nobody could detect from the outside.\r\n\r\n              ⚠ **It used to sit at the very bottom of the record, below every tab's content.** That is\r\n              the one place a statement about the WHOLE record is least likely to be read, and it was\r\n              below the fold on every contract. In the panel it keeps its scope and gains a reader.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-title\">Not read by CMS yet</div>\r\n              <div class=\"scoular-alert-description\">\r\n                CTRM returns {{ unmodelled().length }} further collections on this contract that this\r\n                application does not read:\r\n                <span class=\"cws:font-medium\">\r\n                  @for (name of unmodelled(); track name; let last = $last) {\r\n                    <span [title]=\"name\">{{ readable(name) }}</span>{{ last ? '' : ', ' }}\r\n                  }\r\n                </span>\r\n                — so an empty section means “not read”, not “not present”.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (provenanceLabel() !== null) {\r\n            <!--\r\n              Which configuration row is in force.\r\n\r\n              It answers the question nobody could otherwise answer from the screen: \"why is this field\r\n              required here and not on the contract I looked at before?\" It is the admin's debugging\r\n              thread — which is exactly why it belongs behind the disclosure rather than as a permanent\r\n              muted line under the tabs, where it was one more thing between the user and the fields.\r\n            -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n              <div class=\"scoular-alert-description\">{{ provenanceLabel() }}</div>\r\n            </div>\r\n          }\r\n\r\n          @for (warning of warnings(); track warning) {\r\n            <!-- CTRM warnings are surfaced, not dropped (correction C-2). Rare on a read, never silent. -->\r\n            <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n            </div>\r\n          }\r\n        </cms-notices-panel>\r\n\r\n        <!--\r\n          A number that could not be issued is stated rather than left as an empty field, because the\r\n          three causes need three different actions and none of them is \"wait\". The field stays\r\n          editable throughout, so this is a notice and not a blocker.\r\n        -->\r\n        @if (numberIssueFailure()) {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">A contract number was not issued</div>\r\n            <div class=\"scoular-alert-description\">{{ numberIssueFailure() }}</div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          A copy whose source could not be read is an ERROR, not a notice, and it must not look like\r\n          an ordinary blank create. The user asked for a copy; blank fields here would read as the\r\n          source contract's values and get saved.\r\n        -->\r\n        @if (copyFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">{{ copyFrom }} could not be read, so nothing was copied</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is blank because the read of {{ copyFrom }} failed — <strong>not</strong>\r\n              because that contract is empty. <strong>Do not save from this state</strong> expecting a\r\n              copy: it would create a new contract carrying only what you type here. Reload to try\r\n              again, or start from {{ copyFrom }} and press Copy contract once it loads.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The values failing to load is stated, never absorbed. In view mode it stops an empty record\r\n          reading as an empty contract; in edit mode it is worse than that and the text says so.\r\n        -->\r\n        @if (prefillFailed()) {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">This contract’s current values could not be loaded</div>\r\n            <div class=\"scoular-alert-description\">\r\n              Every field is showing blank because the read failed — <strong>not</strong> because the\r\n              contract is empty.\r\n              @if (isEditable()) {\r\n                <strong>Do not save from this state</strong>: a field you fill in here would be written\r\n                over whatever CTRM currently holds.\r\n              }\r\n              Reload the page, and if it keeps failing the contract can still be worked on the green\r\n              screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          The save outcome, including WHICH of upsert's two paths CTRM took. A create that reports\r\n          \"Updated\" overwrote an existing contract and an update that reports \"Created\" made a new one;\r\n          both are shown rather than folded into a plain success, because that discriminator is the only\r\n          thing standing between a silent mistake and a caught one (docs/04e).\r\n        -->\r\n        @if (save().result; as result) {\r\n          <div class=\"scoular-alert scoular-alert-success\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">\r\n              {{ result.action === 'Created' ? 'Contract created' : 'Contract updated' }}\r\n              @if (result.contractNumber) {\r\n                — {{ result.contractNumber }}\r\n              }\r\n            </div>\r\n            <div class=\"scoular-alert-description\">\r\n              {{ result.detail }}\r\n              @if (!isCreate() && result.action === 'Created') {\r\n                <strong>\r\n                  ⚠ This was expected to update an existing contract and CTRM reports it created a new\r\n                  one. Check the contract number before continuing.\r\n                </strong>\r\n              }\r\n              @if (isCreate() && result.action === 'Updated') {\r\n                <strong>\r\n                  ⚠ This was expected to create a contract and CTRM reports it updated an existing one.\r\n                  An existing contract may have been overwritten.\r\n                </strong>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n\r\n        @if (recoverableDraft() !== null) {\r\n          <!--\r\n            🔴 An OFFER, never an automatic restore — F3.2f.\r\n\r\n            Silently repopulating a form would be indistinguishable from the contract genuinely\r\n            holding those values, and the user has no way to tell which they are looking at. Worse\r\n            under a full-replace upsert: a restored draft that the user does not notice is a set of\r\n            edits they never made, sent as if they had.\r\n\r\n            ⚠ `role=\"status\"` rather than `alert`: it is waiting for them, not interrupting them.\r\n          -->\r\n          <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">Unsaved changes were recovered</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <p>\r\n                This form had unsaved changes when it was last open\r\n                @if (recoverableAt(); as at) {\r\n                  <span>, at {{ at }}</span>\r\n                }.\r\n              </p>\r\n              <div class=\"cws:mt-2 cws:flex cws:gap-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-primary\" (click)=\"restoreDraft()\">\r\n                  Restore them\r\n                </button>\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"discardDraft()\">\r\n                  Discard\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 #556: a failed save is THREE different things, and only one of them is a refusal.\r\n\r\n          A 422 is CTRM or the API saying no, with reasons. A lost CTRM answer is not a refusal at all:\r\n          the API reads the contract back to settle it (#513), and either the change is not there\r\n          (`not-applied`: safe to save again) or nobody can tell (`outcome-unknown`, and a status 0).\r\n          Saying \"not saved\" about the last case is how a retry becomes a duplicate write, and on a\r\n          create a second contract. The draft is kept in all three; only a success clears it.\r\n        -->\r\n        @if (save().status === 'failed' && save().failure === 'outcome-unknown') {\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract may have been saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <p>\r\n                CTRM did not answer, so it is not known whether the change was applied. Your edits are\r\n                kept on this screen.\r\n                @if (isCreate()) {\r\n                  Check the contract list for the new contract before saving again, or a second\r\n                  contract may be created and the change applied twice.\r\n                } @else {\r\n                  Reload the contract to see what CTRM holds before saving again, or the change may be\r\n                  applied twice. Pressing Edit there offers these edits back.\r\n                }\r\n              </p>\r\n              <div class=\"cws:mt-2\">\r\n                <button type=\"button\" class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\" (click)=\"reloadAfterUnknownSave()\">\r\n                  {{ isCreate() ? 'Check the contract list' : 'Reload the contract' }}\r\n                </button>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        } @else if (save().status === 'failed' && save().failure === 'not-applied') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              CTRM did not answer, and reading the contract back shows the change is not there. Your\r\n              edits are kept, and it is safe to save again.\r\n            </div>\r\n          </div>\r\n        } @else if (save().status === 'failed') {\r\n          <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n            <div class=\"scoular-alert-title\">The contract was not saved</div>\r\n            <div class=\"scoular-alert-description\">\r\n              <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5\">\r\n                <!--\r\n                  The API's own form-level text, plus any refusal whose `invalid_params[].name` is\r\n                  not a field name at all — a CTRM procedure name or composite (docs/04 §8.2). Those\r\n                  used to render below as a bolded field, which invented a field that does not exist.\r\n                -->\r\n                @for (reason of formLevelReasons(); track reason) {\r\n                  <li>{{ reason }}</li>\r\n                }\r\n\r\n                <!--\r\n                  🔴 Each field reason is now a BUTTON that goes to its control, and the reason is also\r\n                  on the control itself. This list used to admit, in its own words, that the field a\r\n                  reason named \"may be on a tab you are not looking at\" — which is a message the user\r\n                  has to go hunting for, barely better than none.\r\n\r\n                  ⚠ A button rather than an anchor: it switches tab AND moves focus, and the focus move\r\n                  is the half that makes it useful. An anchor would advertise an href that does only\r\n                  half the job.\r\n                -->\r\n                @for (error of mappedErrors(); track error.ctrmField) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li>\r\n                      <button\r\n                        type=\"button\"\r\n                        class=\"cws:text-left cws:underline cws:underline-offset-2 cws:hover:no-underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2\"\r\n                        (click)=\"focusField(error)\"\r\n                      >\r\n                        <strong>{{ error.label }}</strong>\r\n                      </button>\r\n                      — {{ reason }}\r\n                    </li>\r\n                  }\r\n                }\r\n\r\n                <!--\r\n                  ⚠ Refusals naming a field this screen does not render. Kept visible rather than\r\n                  dropped: CTRM validates a set that is not identical to what this layout shows, and a\r\n                  swallowed reason leaves a save that failed for no stated cause. Named by the CTRM\r\n                  field, because that is the only name we have for it.\r\n                -->\r\n                @for (error of unmappedErrors(); track error.field) {\r\n                  @for (reason of error.reasons; track reason) {\r\n                    <li><strong>{{ error.field }}</strong> — {{ reason }}</li>\r\n                  }\r\n                }\r\n              </ul>\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          🔴 THE TABS, and they are ANCHORS rather than buttons.\r\n\r\n          Each tab is a real link to this same record with a different `tab` query parameter, which buys\r\n          three things a click handler would not: the tab is in the URL so a refresh keeps it and a link\r\n          to \"the shipping fields of this contract\" can be sent (docs/02 §1.3 asks this of every route);\r\n          middle-click and open-in-new-tab work; and the browser Back button walks the tabs. It is the\r\n          same reasoning the breadcrumb and Cancel already carry.\r\n\r\n          `aria-current=\"page\"` marks the active one — the correct ARIA for a set of links, where\r\n          `role=\"tab\"` would be a promise of keyboard semantics these are not implementing. Tab/Shift+Tab\r\n          moves between them because they are links, which is what a keyboard user expects of links.\r\n\r\n          ⚠ `queryParamsHandling` is deliberately NOT used. `paramsForTab` states every parameter it\r\n          keeps, so a future parameter has to be added on purpose — `merge` would silently carry\r\n          anything, including a stale `focus` from the grid.\r\n        -->\r\n        <nav aria-label=\"Contract sections\" class=\"cws:border-b cws:border-slate-200 cws:dark:border-slate-700\">\r\n          <ul class=\"cws:-mb-px cws:flex cws:flex-wrap cws:gap-1\">\r\n            @for (tab of tabs(); track tab.id) {\r\n              <li>\r\n                <a\r\n                  [routerLink]=\"[]\"\r\n                  [queryParams]=\"paramsForTab(tab.id)\"\r\n                  [attr.aria-current]=\"tab.current ? 'page' : null\"\r\n                  class=\"cws:flex cws:items-center cws:gap-2 cws:rounded-t-lg cws:border-b-2 cws:px-4 cws:py-2.5 cws:text-sm cws:font-medium cws:transition-colors cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n                  [class.cws:border-scoular-blue]=\"tab.current\"\r\n                  [class.cws:text-scoular-blue]=\"tab.current\"\r\n                  [class.cws:dark:text-sky-400]=\"tab.current\"\r\n                  [class.cws:border-transparent]=\"!tab.current\"\r\n                  [class.cws:text-slate-500]=\"!tab.current\"\r\n                  [class.cws:hover:border-slate-300]=\"!tab.current\"\r\n                  [class.cws:hover:text-slate-700]=\"!tab.current\"\r\n                  [class.cws:dark:text-slate-400]=\"!tab.current\"\r\n                  [class.cws:dark:hover:text-slate-200]=\"!tab.current\"\r\n                >\r\n                  {{ tab.label }}\r\n\r\n                  <!--\r\n                    🔴 How many refusals landed on this tab. Without it a save that failed on a field\r\n                    two tabs away shows an error banner and four tabs that look identical — the user\r\n                    has to open each one to find what CTRM objected to.\r\n\r\n                    ⚠ The count is in the accessible name too, not only the glyph: a screen-reader user\r\n                    gets \"Shipping Info, 2 problems\" rather than \"Shipping Info, 2\".\r\n                  -->\r\n                  @if (errorsByTab().get(tab.id); as problems) {\r\n                    <span\r\n                      class=\"scoular-badge scoular-badge-sm cws:bg-red-100 cws:text-red-800 cws:dark:bg-red-900/40 cws:dark:text-red-200\"\r\n                      [attr.aria-label]=\"problems + (problems === 1 ? ' problem' : ' problems')\"\r\n                    >\r\n                      {{ problems }}\r\n                    </span>\r\n                  }\r\n                  <!--\r\n                    The count is fields PLUS collections. The Remarks tab has no fields at all — remarks\r\n                    and notes are CTRM collections rather than `base_data` scalars — and would otherwise\r\n                    read `0` beside two populated tables. The Documents tab has no count at all (null),\r\n                    because a `0` beside it would read as \"this contract has no documents\".\r\n                  -->\r\n                  @if (tab.count !== null) {\r\n                  <span\r\n                    class=\"cws:rounded-full cws:px-1.5 cws:py-0.5 cws:text-xs cws:tabular-nums\"\r\n                    [class.cws:bg-scoular-blue]=\"tab.current\"\r\n                    [class.cws:text-white]=\"tab.current\"\r\n                    [class.cws:bg-slate-100]=\"!tab.current\"\r\n                    [class.cws:text-slate-600]=\"!tab.current\"\r\n                    [class.cws:dark:bg-slate-700]=\"!tab.current\"\r\n                    [class.cws:dark:text-slate-300]=\"!tab.current\"\r\n                  >\r\n                    {{ tab.count }}\r\n                  </span>\r\n                  }\r\n                </a>\r\n              </li>\r\n            }\r\n          </ul>\r\n        </nav>\r\n\r\n        <!--\r\n          🔴 THE FIELDS. One form, always mounted, showing one tab's sections.\r\n\r\n          `[visibleSections]` narrows what RENDERS. The form group is always built from the whole\r\n          configuration — see the input's own remarks. Wrapping this in `@if (activeTab() === …)` would\r\n          destroy and rebuild the component on every tab click, discarding everything typed and resetting\r\n          the `dirty` flags the save path reads. That is the trap here, and it looks like the obvious\r\n          implementation.\r\n\r\n          `[readOnly]` is the entire difference between reading a contract and editing one.\r\n\r\n          🔴 It binds `!isEditable()`, not `isView()` (F2.3c, #423). BR-002 makes the WHOLE form\r\n          read-only for an intercompany purchase, and this binding is the one place that decision\r\n          lands — bound to the mode alone, an intercompany purchase opened in edit mode rendered\r\n          fully editable and the rule existed only in the requirements.\r\n\r\n          Gated on `valuesReady()`: the form seeds ONCE in `ngOnInit`, so rendering before this\r\n          contract's values arrive builds it from nothing and never re-seeds.\r\n        -->\r\n        <!--\r\n          BR-002's read-only reason, which docs/02a §6.2 requires a banner for: \"read-only … banner\r\n          explains why\". A locked form with no explanation reads as a broken screen, and this one\r\n          cannot be unlocked from here.\r\n\r\n          ⚠ **Deliberately NOT `role=\"alert\"`.** It is a standing condition of the contract, not an\r\n          event that just happened — the same distinction the save outcome above observes in the\r\n          other direction. An alert role would interrupt a screen-reader user on arrival to announce\r\n          something that has always been true of this record.\r\n        -->\r\n        @if (intercompanyLock()) {\r\n          <div class=\"scoular-alert scoular-alert-info\">\r\n            <div class=\"scoular-alert-title\">This contract is read-only</div>\r\n            <!--\r\n              ⚠ No rule number in the copy. `user-facing-copy.spec.ts` refused \"(BR-002)\" here and\r\n              was right: a business-rule identifier names something only the development team can\r\n              act on, and the trader reading this needs to know what to do instead.\r\n            -->\r\n            <div class=\"scoular-alert-description\">\r\n              It is an intercompany purchase, and those are not editable here. The contract can\r\n              still be worked on the green screen.\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (valuesReady()) {\r\n          <!--\r\n            🔴 `@for (… of [formKey()]; track key)` — the ONE place this screen rebuilds the form on\r\n            purpose, and it is not the tab switch.\r\n\r\n            A driver change (contract type, commodity) re-resolves the configuration, and a different\r\n            configuration is genuinely a different set of controls — so unlike tabs, this cannot be a\r\n            display filter. Re-keying rebuilds it; `watchDrivers` snapshots the dirty values first and\r\n            they come back through `[defaultValues]` marked dirty, so nothing typed is lost and the\r\n            save payload is unchanged. Keyed on the configuration's own version, so a re-resolve that\r\n            wins the same row does not churn the form.\r\n          -->\r\n          @for (key of [formKey()]; track key) {\r\n            <cms-contract-form\r\n              [config]=\"loaded.config\"\r\n              [tradeUnit]=\"loaded.tradeUnit\"\r\n              [readOnly]=\"!isEditable()\"\r\n              [visibleSections]=\"visibleSections()\"\r\n              [fieldNotes]=\"fieldNotes()\"\r\n              [emptyNotes]=\"emptyNotes\"\r\n              [sectionNotes]=\"sectionNotes\"\r\n              [wideFields]=\"wideFields\"\r\n              [halfFields]=\"halfFields\"\r\n              [hiddenLabelFields]=\"hiddenLabelFields\"\r\n              [groupHeadings]=\"groupHeadings\"\r\n              [fieldCtrmNames]=\"fieldCtrmNames\"\r\n              [readOnlyFields]=\"readOnlyFields()\"\r\n              [initialValues]=\"initialValues()\"\r\n              [defaultValues]=\"defaultValues()\"\r\n              (ready)=\"onFormReady($event)\"\r\n              (fieldBlur)=\"onFieldBlur($event)\"\r\n            />\r\n          }\r\n        } @else {\r\n          <div class=\"scoular-card cws:p-6\" role=\"status\" aria-live=\"polite\">\r\n            Loading this contract’s current values…\r\n          </div>\r\n        }\r\n\r\n        <!--\r\n          F10.3b — the Addendum section, for the three in-house addendums only (MNC/MNP, XPC, PREM).\r\n\r\n          🔴 OUTSIDE `cms-contract-form`, and that is how an addendum field is kept out of the save.\r\n          The form is the CTRM\r\n          payload; these values are CWS's and live in the section's own state, so the save path has no\r\n          control to read them from. `addendumFieldSet()` is null for every other special type, blank\r\n          included, and the section does not render at all.\r\n        -->\r\n        @if (showAddendum()) {\r\n          @if (addendumFieldSet(); as set) {\r\n            <cws-contract-addendum-section\r\n              [fieldSet]=\"set\"\r\n              [contractNumber]=\"isCreate() ? '' : contractNumber()\"\r\n              [tradeUnit]=\"addendumTradeUnit()\"\r\n              [canGenerate]=\"canWrite()\"\r\n            />\r\n          }\r\n        }\r\n\r\n        <!--\r\n          The child collections, each on the tab whose fields describe it — ship periods with the\r\n          shipping fields, prices with the pricing fields, remarks and notes on the tab named after them.\r\n          That is what the Power App does (its `Ship Period` component is inside `Shipping Info`) and it\r\n          is what removes the long tail: nothing here sits after 111 controls any more.\r\n\r\n          ⚠ The grids themselves are UNCHANGED — same columns, sort behaviour, resizing and cell-level\r\n          Ctrl+C. Only where they appear has moved.\r\n        -->\r\n        @if (showPrices()) {\r\n          <!--\r\n            Price sequences, read-only on this aggregate — prices are written through the pricing API,\r\n            never through the contract upsert (C-8). So this stays a table in edit mode too.\r\n\r\n            ⚠ These are NOT the pricing API's price records. Known Issue 34: two CTRM routes both return\r\n            \"a price\" and disagree on names (`flat_price` vs `price`, 12 members vs 36). Do not reuse\r\n            this table's columns on the pricing screen.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Price sequences\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ contract()?.prices?.length ?? 0 }})\r\n              </span>\r\n            </h3>\r\n            @if (contract()?.prices?.length) {\r\n              <cms-data-grid\r\n                [rows]=\"sortedPrices()\"\r\n                [columns]=\"priceColumns\"\r\n                label=\"Price sequences\"\r\n                [sorts]=\"priceSorts()\"\r\n                (sortChange)=\"priceSorts.set($event)\"\r\n              />\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                {{\r\n                  isCreate()\r\n                    ? 'Prices are added on the pricing screen, ' + pendingNote + '.'\r\n                    : 'This contract has no priced sequences.'\r\n                }}\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showShipPeriods()) {\r\n          <!--\r\n            Ship periods (BR-020…BR-023). Max 12, CTRM's cap.\r\n\r\n            🔴 **EDITABLE in edit mode as of F2.3b (#372).** This block carried the opposite claim —\r\n            \"read-only in EVERY mode … `ship_periods` is one of the 11 child collections the contract\r\n            upsert path does not carry, so there is nothing this screen could save\". The API's\r\n            `ContractWriteBody.Collections` does carry all seven, so the sentence was describing a\r\n            limit that had been lifted.\r\n\r\n            ⚠ Read-only still, whenever the form is: view mode, and BR-002's intercompany lock.\r\n          -->\r\n          <div class=\"cws:space-y-3\">\r\n            <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n              Ship periods\r\n              <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                ({{ shipPeriodRows().length }})\r\n              </span>\r\n            </h3>\r\n\r\n            @if (isEditable()) {\r\n              <!--\r\n                The editable collection. A plain table rather than `cms-data-grid`, which renders\r\n                values and has no cell-editing affordance — and rather than a `FormArray`, which\r\n                would mean changing the shared `ContractForm` for every screen that mounts it.\r\n              -->\r\n              <table class=\"cws:w-full cws:text-left cws:text-sm\">\r\n                <caption class=\"sr-only\">Ship periods, editable</caption>\r\n                <thead class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  <tr>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Begin</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">End</th>\r\n                    <th scope=\"col\" class=\"cws:py-1 cws:pr-3 cws:font-medium\">Quantity</th>\r\n                    <th scope=\"col\" class=\"cws:py-1\"><span class=\"sr-only\">Actions</span></th>\r\n                  </tr>\r\n                </thead>\r\n                <tbody>\r\n                  @for (row of shipPeriodRows(); track $index) {\r\n                    <tr class=\"cws:border-t cws:border-slate-200 cws:dark:border-slate-700\">\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <!--\r\n                          BR-020 — the three entry forms CTRM accepts (`MMDDYYYY`, `MMDDYY` with a\r\n                          1930–2029 pivot, `MM/DD/YYYY`) are parsed on change by\r\n                          `parseShipPeriodDate`. A text input rather than `type=\"date\"` for exactly\r\n                          that reason: a native date picker would refuse the shorthand a trader types.\r\n                        -->\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'Begin date, period ' + ($index + 1)\"\r\n                          [value]=\"row.beginDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'beginDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          class=\"scoular-form-input cws:w-32\"\r\n                          [attr.aria-label]=\"'End date, period ' + ($index + 1)\"\r\n                          [value]=\"row.endDate ?? ''\"\r\n                          (change)=\"setShipPeriodDate($index, 'endDate', $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1 cws:pr-3\">\r\n                        <input\r\n                          type=\"text\"\r\n                          inputmode=\"decimal\"\r\n                          class=\"scoular-form-input cws:w-32 cws:text-right cws:tabular-nums\"\r\n                          [attr.aria-label]=\"'Quantity, period ' + ($index + 1)\"\r\n                          [value]=\"row.quantity ?? ''\"\r\n                          (change)=\"setShipPeriodQuantity($index, $any($event.target).value)\"\r\n                        />\r\n                      </td>\r\n                      <td class=\"cws:py-1\">\r\n                        <button\r\n                          type=\"button\"\r\n                          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary\"\r\n                          (click)=\"removeShipPeriod($index)\"\r\n                        >\r\n                          Remove<span class=\"sr-only\"> period {{ $index + 1 }}</span>\r\n                        </button>\r\n                      </td>\r\n                    </tr>\r\n                    @if (shipPeriodIssues().get($index); as issues) {\r\n                      <tr>\r\n                        <td colspan=\"4\" class=\"cws:pb-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                          @for (issue of issues; track issue.code) {\r\n                            <span class=\"cws:mr-3\">{{ issue.message }}</span>\r\n                          }\r\n                        </td>\r\n                      </tr>\r\n                    }\r\n                  }\r\n                </tbody>\r\n              </table>\r\n\r\n              <!--\r\n                BR-022. The action DISABLES at CTRM's 12-period cap rather than silently doing\r\n                nothing — `nextShipPeriod` returns null there, which is the whole reason it does.\r\n              -->\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-sm scoular-btn-outline\"\r\n                [disabled]=\"nextShipPeriodProposal() === null\"\r\n                (click)=\"addShipPeriod()\"\r\n              >\r\n                Add period\r\n              </button>\r\n\r\n              @if (nextShipPeriodProposal() === null) {\r\n                <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  A contract may have at most {{ maxShipPeriods }} ship periods.\r\n                </p>\r\n              }\r\n\r\n              @for (issue of shipPeriodCollectionIssues(); track issue.code) {\r\n                <p class=\"cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ issue.message }}</p>\r\n              }\r\n\r\n              <!--\r\n                BR-022's overlap test is a WARNING, not a refusal: CTRM permits overlapping periods,\r\n                so blocking the save here would invent a rule the system of record does not have.\r\n              -->\r\n              @if (shipPeriodsOverlap()) {\r\n                <p class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-300\">\r\n                  Two periods overlap. CTRM allows this — check it is what you meant.\r\n                </p>\r\n              }\r\n            } @else if (shipPeriodRows().length) {\r\n              <!--\r\n                No \"sorted within this page\" caveat here, unlike the contract grid: this collection\r\n                arrives whole (CTRM caps ship periods at 12), so the sort covers every row there is.\r\n              -->\r\n              <cms-data-grid\r\n                [rows]=\"sortedShipPeriods()\"\r\n                [columns]=\"shipPeriodColumns\"\r\n                label=\"Ship periods\"\r\n                [sorts]=\"shipPeriodSorts()\"\r\n                (sortChange)=\"shipPeriodSorts.set($event)\"\r\n              />\r\n\r\n            } @else {\r\n              <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                This contract has no ship periods. That is valid — CTRM neither requires shipment\r\n                dates nor supplies a default for them.\r\n              </p>\r\n            }\r\n\r\n            <!--\r\n              BR-021 — the running Σ against the contract quantity (#371, 02a §6.2).\r\n\r\n              🔴 **Outside the read-only branch as of F2.3b.** It used to sit inside the grid's `@if`,\r\n              so it rendered only where the periods could not be changed — and disappeared in edit\r\n              mode, which is the only mode in which a user can unbalance it. A gate that hides itself\r\n              exactly when it becomes reachable is worse than not having one.\r\n\r\n              Pinned under the collection rather than beside the Quantity field, because it is a\r\n              statement about the collection. It states the DELTA, not merely that something is\r\n              wrong: a gate that blocks without saying by how much leaves the user to redo arithmetic\r\n              the screen has already done.\r\n\r\n              `role=\"status\"` so a screen reader hears the total resolve as the quantity is typed,\r\n              rather than discovering it on pressing Save.\r\n            -->\r\n            @if (shipPeriodReconciliation(); as reconciliation) {\r\n              <p\r\n                data-testid=\"ship-period-reconciliation\"\r\n                role=\"status\"\r\n                class=\"cws:rounded-md cws:border cws:px-3 cws:py-2 cws:text-sm\"\r\n                [class.cws:border-emerald-300]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:bg-emerald-50]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:text-emerald-900]=\"!shipPeriodGateBlocks()\"\r\n                [class.cws:border-red-300]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:bg-red-50]=\"shipPeriodGateBlocks()\"\r\n                [class.cws:text-red-900]=\"shipPeriodGateBlocks()\"\r\n              >\r\n                {{ reconciliation.summary }}\r\n                @if (shipPeriodGateBlocks()) {\r\n                  <span class=\"cws:block cws:font-medium\">\r\n                    CTRM requires the shipment periods to sum to the contract quantity, so this\r\n                    cannot be saved until they match.\r\n                  </span>\r\n                }\r\n              </p>\r\n            }\r\n          </div>\r\n        }\r\n\r\n        @if (showRemarks()) {\r\n          <!--\r\n            The Remarks tab carries no FIELDS — remarks and notes are CTRM collections (`RmkDS`,\r\n            `NoteDS`), not `base_data` scalars, so there is nothing for the form to render here. The\r\n            Power App's Remarks tab is ten discrete remark inputs plus final-settle and additional\r\n            terms; ours is read-only until the collections are writable, and it says so rather than\r\n            leaving the tab looking broken.\r\n          -->\r\n          <div class=\"scoular-alert scoular-alert-info\" role=\"note\">\r\n            <div class=\"scoular-alert-description\">\r\n              Remarks and notes are CTRM child collections rather than contract fields, so they are\r\n              <strong>read-only here</strong>. The legacy Power App edits ten remark lines on this tab;\r\n              that needs the collections on the write path, which is not built.\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- Remarks (BR-030). Max 11, 72 characters each. -->\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Remarks\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.remarks?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.remarks?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-2\">\r\n                  @for (remark of contract()?.remarks ?? []; track remark.order) {\r\n                    <li class=\"cws:flex cws:gap-3 cws:text-sm\">\r\n                      <!--\r\n                        The number is CMS's, not CTRM's — RmkDS has no sequence subfield, so it is array\r\n                        position. Muted rather than labelled \"seq\" so it is not mistaken for a CTRM id.\r\n                      -->\r\n                      <span\r\n                        class=\"cws:w-5 cws:shrink-0 cws:text-right cws:tabular-nums cws:text-slate-400 cws:dark:text-slate-500\"\r\n                        title=\"Position in CTRM’s array — not a CTRM sequence number\"\r\n                      >\r\n                        {{ remark.order }}\r\n                      </span>\r\n                      <span class=\"cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        @if (remark.type) {\r\n                          <span class=\"cws:mr-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                            [{{ remark.type }}]\r\n                          </span>\r\n                        }\r\n                        {{ remark.text }}\r\n                      </span>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Remarks are ' + pendingNote + '.' : 'No remarks.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n\r\n            <!--\r\n              Notes. `whitespace-pre-line` because a note runs to 32 000 characters and will contain its\r\n              own line breaks — collapsing them would turn a structured note into one unreadable\r\n              paragraph.\r\n            -->\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                Notes\r\n                <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  ({{ contract()?.notes?.length ?? 0 }})\r\n                </span>\r\n              </h3>\r\n              @if (contract()?.notes?.length) {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (note of contract()?.notes ?? []; track note.order) {\r\n                    <li class=\"cws:text-sm\">\r\n                      @if (note.prefix || note.code) {\r\n                        <div class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                          {{ note.prefix }}{{ note.prefix && note.code ? ' · ' : '' }}{{ note.code }}\r\n                        </div>\r\n                      }\r\n                      <p class=\"cws:whitespace-pre-line cws:text-slate-900 cws:dark:text-slate-100\">\r\n                        {{ note.text }}\r\n                      </p>\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              } @else {\r\n                <p class=\"cws:mt-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ isCreate() ? 'Notes are ' + pendingNote + '.' : 'No notes.' }}\r\n                </p>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n        @if (showDocuments()) {\r\n          <!--\r\n            F10.2 — the Documents tab. It reads its own list and content, so the record's own reads are\r\n            untouched by it, and it is appended by this screen rather than configured (see DOCUMENTS_TAB).\r\n          -->\r\n          <cws-contract-documents-tab [contractNumber]=\"contractNumber()\" />\r\n        }\r\n\r\n        @if (showLog()) {\r\n          <!--\r\n            F3.7 — the Log tab: what happened to this contract, a note to add to it, and a message to\r\n            its trader. It carries no form fields, which is why it is appended by this screen rather\r\n            than coming from the resolved configuration (see `LOG_TAB`).\r\n          -->\r\n          <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-2\">\r\n            <!-- The timeline. Absent where the host offered no audit backend. -->\r\n            @if (logAvailable()) {\r\n            <div\r\n              class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n            >\r\n              <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">History</h3>\r\n\r\n              @if (timelineState() === 'loading') {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">Loading the history…</p>\r\n              } @else if (timelineState() === 'error') {\r\n                <!--\r\n                  🔴 An unreadable history and an empty one must not look the same. \"Nothing has\r\n                  happened to this contract\" is a claim, and this screen cannot make it here.\r\n                -->\r\n                <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\r\n                  The history for this contract could not be loaded, so what is shown may be\r\n                  incomplete.\r\n                </p>\r\n              } @else if (timeline().length === 0) {\r\n                <p class=\"cws:mt-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  Nothing has been recorded against this contract yet.\r\n                </p>\r\n              } @else {\r\n                <ol class=\"cws:mt-3 cws:space-y-3\">\r\n                  @for (row of timeline(); track row.key) {\r\n                    <li class=\"cws:border-l-2 cws:pl-3\"\r\n                        [class.cws:border-slate-300]=\"row.kind === 'contract'\"\r\n                        [class.cws:border-amber-400]=\"row.kind === 'configuration'\">\r\n                      <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\">\r\n                        {{ row.what }}\r\n                        @if (row.kind === 'configuration') {\r\n                          <!-- Distinguishable, so a configuration edit is never read as a contract change. -->\r\n                          <span\r\n                            class=\"cws:ml-1 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\r\n                          >Configuration</span>\r\n                        }\r\n                      </p>\r\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                        <!-- #567: the reader's local time; the exact instant stays in `datetime`. -->\r\n                        {{ row.actor || 'Unattributed' }} · <time [attr.datetime]=\"row.at\">{{ row.atLabel }}</time>\r\n                      </p>\r\n                      <!--\r\n                        #567: what the write changed, from the entry's detailsJson. Rendered only when\r\n                        it parses and names something, so every other entry reads exactly as before.\r\n                      -->\r\n                      @if (row.changes.length > 0 || row.collectionsReplaced.length > 0) {\r\n                        <dl class=\"cws:mt-1 cws:space-y-0.5 cws:text-xs cws:text-slate-700 cws:dark:text-slate-300\">\r\n                          @for (change of row.changes; track $index) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">{{ change.label }}</dt>\r\n                              <dd>\r\n                                <span>{{ change.from ?? '(empty)' }}</span>\r\n                                <span aria-hidden=\"true\"> → </span>\r\n                                <span class=\"cws:sr-only\"> changed to </span>\r\n                                <span>{{ change.to ?? '(empty)' }}</span>\r\n                              </dd>\r\n                            </div>\r\n                          }\r\n                          @if (row.collectionsReplaced.length > 0) {\r\n                            <div class=\"cws:flex cws:flex-wrap cws:gap-x-1\">\r\n                              <dt class=\"cws:font-medium\">Replaced whole</dt>\r\n                              <dd>{{ row.collectionsReplaced.join(', ') }}</dd>\r\n                            </div>\r\n                          }\r\n                        </dl>\r\n                      }\r\n                    </li>\r\n                  }\r\n                </ol>\r\n              }\r\n            </div>\r\n\r\n            }\r\n\r\n            <div class=\"cws:space-y-4\">\r\n              <!-- Add Note. Needs the log backend, which owns the notes write path. -->\r\n              @if (logAvailable()) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Add a note</h3>\r\n\r\n                @if (!notesAreComplete()) {\r\n                  <!--\r\n                    🔴 THE REFUSAL THAT PREVENTS DATA LOSS. Adding a note replaces the whole notes\r\n                    collection, and CTRM returned none of the existing ones — so appending here would\r\n                    delete notes CTRM is holding, and answer 202.\r\n                  -->\r\n                  <p role=\"alert\" class=\"cws:mt-2 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\r\n                    This contract's existing notes could not be read, so a new one cannot be added\r\n                    safely — saving would replace the notes CTRM still holds. Someone needs to shorten\r\n                    the oversized note in CTRM first.\r\n                  </p>\r\n                } @else if (!canWrite()) {\r\n                  <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                    Adding a note needs the <strong>Admin</strong> role on this application.\r\n                  </p>\r\n                } @else {\r\n                  <label class=\"cws:mt-2 cws:block\">\r\n                    <span class=\"sr-only\">Note</span>\r\n                    <textarea\r\n                      rows=\"4\"\r\n                      class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                      [value]=\"noteText()\"\r\n                      (input)=\"onNoteInput($any($event.target).value)\"\r\n                    ></textarea>\r\n                  </label>\r\n\r\n                  @if (noteRefusal(); as refusal) {\r\n                    <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">{{ refusal }}</p>\r\n                  } @else {\r\n                    <!-- The budget at the control, not only a refusal at save. -->\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      {{ noteBytesRemaining() }} characters remaining\r\n                    </p>\r\n                  }\r\n\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"scoular-btn scoular-btn-primary cws:mt-2\"\r\n                    [disabled]=\"!canAddNote()\"\r\n                    (click)=\"onAddNote()\"\r\n                  >\r\n                    @if (noteState().status === 'saving') { Saving… } @else { Add note }\r\n                  </button>\r\n\r\n                  @if (noteState().status === 'failed') {\r\n                    <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                      {{ noteState().message }}\r\n                    </p>\r\n                  }\r\n                }\r\n              </div>\r\n\r\n              }\r\n\r\n              <!-- Save as template (F3.3). -->\r\n              @if (canUseTemplates() && !isCreate()) {\r\n                <div\r\n                  class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n                >\r\n                  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n                    Save as a template\r\n                  </h3>\r\n\r\n                  <!-- #485: CWS SQL, so permissions only; the CTRM availability gate does not apply. -->\r\n                  @if (!canWriteCws()) {\r\n                    <p role=\"status\" class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      Saving a template needs the <strong>Admin</strong> role on this application.\r\n                    </p>\r\n                  } @else {\r\n                    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                      <!--\r\n                        Says what is captured and what the server removes, because a user who does not\r\n                        know the exclusions exist will expect the template to reproduce the contract\r\n                        exactly and will read the difference as a defect.\r\n                      -->\r\n                      Captures every writable field on this contract as it stands. Fields excluded from\r\n                      copying are removed when the template is read back.\r\n                    </p>\r\n\r\n                    <label class=\"cws:mt-2 cws:block\">\r\n                      <span class=\"sr-only\">Template name</span>\r\n                      <input\r\n                        type=\"text\"\r\n                        class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                        placeholder=\"Template name\"\r\n                        [value]=\"templateName()\"\r\n                        (input)=\"onTemplateNameInput($any($event.target).value)\"\r\n                      />\r\n                    </label>\r\n\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                      [disabled]=\"!canSaveTemplate()\"\r\n                      (click)=\"onSaveTemplate()\"\r\n                    >\r\n                      @if (templateState().status === 'saving') { Saving… } @else { Save as template }\r\n                    </button>\r\n\r\n                    @if (templateState().status === 'saved') {\r\n                      <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n                        Template saved.\r\n                      </p>\r\n                    }\r\n\r\n                    @if (templateState().status === 'failed') {\r\n                      <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                        {{ templateState().message }}\r\n                      </p>\r\n                    }\r\n                  }\r\n                </div>\r\n              }\r\n\r\n              <!-- Notify Trader. Needs the log backend, which owns the route. -->\r\n              @if (logAvailable()) {\r\n              <div\r\n                class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n              >\r\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Notify the trader</h3>\r\n\r\n                <label class=\"cws:mt-2 cws:block\">\r\n                  <span class=\"sr-only\">Message to the trader</span>\r\n                  <textarea\r\n                    rows=\"3\"\r\n                    class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:p-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                    [value]=\"notifyText()\"\r\n                    (input)=\"onNotifyInput($any($event.target).value)\"\r\n                  ></textarea>\r\n                </label>\r\n\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary cws:mt-2\"\r\n                  [disabled]=\"!canNotify()\"\r\n                  (click)=\"onNotifyTrader()\"\r\n                >\r\n                  @if (notifyState().status === 'sending') { Sending… } @else { Notify trader }\r\n                </button>\r\n\r\n                @if (notifyState().status === 'accepted') {\r\n                  <!--\r\n                    🔴 \"Accepted\", never \"sent\". The route answers 202, which on this estate says the\r\n                    request was taken and nothing about whether it reached anybody.\r\n                  -->\r\n                  <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n                    The message was accepted for sending. Acceptance is not confirmation that it\r\n                    arrived.\r\n                  </p>\r\n                }\r\n\r\n                @if (notifyState().status === 'failed') {\r\n                  <p role=\"alert\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-red-300\">\r\n                    {{ notifyState().message }}\r\n                  </p>\r\n                }\r\n              </div>\r\n              }\r\n            </div>\r\n          </div>\r\n        }\r\n\r\n      </div>\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		onBeforeUnload: [{
			type: HostListener,
			args: ["window:beforeunload", ["$event"]]
		}],
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	}
});
const DRIVER_COMPONENTS = [["TextCode", "textClass"], ["CommodityCode", "commodity"]];
function DIMENSION_LABELS(dimension) {
	switch (dimension) {
		case "contractTypeClass": return "contract type";
		case "locationCode": return "this trade unit";
		case "commodityCode": return "this commodity";
		default: return dimension;
	}
}
function readProblem(error) {
	const problem = problemFrom(error);
	const failure = writeOutcomeOf(problem);
	if (failure !== "refused") return {
		fieldErrors: {},
		formErrors: [],
		failure
	};
	const saidSomething = problem.formErrors.length > 0 || Object.keys(problem.errors).length > 0;
	return {
		failure,
		fieldErrors: problem.errors,
		formErrors: saidSomething ? problem.formErrors : ["The save was refused and no reason was given."]
	};
}
function readableTimestamp(at) {
	const parsed = new Date(at);
	return Number.isNaN(parsed.getTime()) ? at : parsed.toLocaleString(void 0, {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
}
function todayIso() {
	const now = /* @__PURE__ */ new Date();
	const month = `${now.getMonth() + 1}`.padStart(2, "0");
	const day = `${now.getDate()}`.padStart(2, "0");
	return `${now.getFullYear()}-${month}-${day}`;
}
function overallShipPeriod(rows) {
	const begins = rows.map((row) => row.beginDate).filter((date) => date !== null);
	const ends = rows.map((row) => row.endDate).filter((date) => date !== null);
	return {
		beginDate: begins.length === 0 ? null : begins.reduce((a, b) => a < b ? a : b),
		endDate: ends.length === 0 ? null : ends.reduce((a, b) => a > b ? a : b),
		quantity: null
	};
}
function sameShipPeriods(left, right) {
	return left.length === right.length && left.every((row, index) => row.beginDate === right[index].beginDate && row.endDate === right[index].endDate && row.quantity === right[index].quantity);
}
const CASCADE_COMPONENTS = {
	priceType: "PriceTypeCode",
	priceMarketCode: "PriceMarketCode",
	priceMarketMonth: "BasisMarketMonth",
	hedgeMarketCode: "HedgeMarketCode",
	hedgeMarketMonth: "HedgeMarketMonth"
};
const EMPTY_CASCADE = {
	priceMarketCode: null,
	priceMarketMonth: null,
	hedgeMarketCode: null,
	hedgeMarketMonth: null,
	derived: [],
	pricesForbidden: false
};
const DRAFT_DEBOUNCE_MS = 500;
const TAB_BY_CTRM_FIELD = Object.fromEntries(CONTRACT_LAYOUT_SECTIONS.flatMap((section) => section.fields.map((layoutField) => [layoutField.ctrmField, section.tab])));
export { CONFIRMATION_STAGES, CONTRACT_DETAIL_SECTIONS, ContractRecordPageComponent, DETAIL_EMPTY_NOTES, aggregateValues, formatFieldValue, mergeContractValues, withMarketMonths, withResolvedTrader };

//# sourceMappingURL=cws-features-contract-summary.mjs.map
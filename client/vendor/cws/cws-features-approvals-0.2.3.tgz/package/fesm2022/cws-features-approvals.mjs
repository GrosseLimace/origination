import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, HostListener, afterRenderEffect, computed, effect, inject, input, signal, untracked, viewChild } from "@angular/core";
import { takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { ActivatedRoute } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { APPROVAL_ACTION_SOURCE, APPROVAL_CONTRACT_SOURCE, APPROVAL_QUEUE_NOT_DEPLOYED, APPROVAL_QUEUE_SOURCE, APPROVAL_RECIPIENTS_TOO_LONG, CONTRACT_DOCUMENTS_SOURCE, CONTRACT_LIST_SOURCE, ConfirmationProgressComponent, DEFAULT_PAGE_SIZE, MAX_ECM_RECIPIENTS, MAX_PAGE_SIZE, RECORD_ORIGIN_PARAM, RecordJourneyStore, RecordStepperComponent, SaveAnnouncementStore, codeAndDescription, confirmationProgress, customerDisplayName, formatContractDate, formatPrice, formatQuantity, formatShipPeriod, formatShortDate, fromRouteParams, injectRecordJourney, injectTradeUnitLabel, isUnconfirmedApprovalAttempt, listEveryPage, recordJourneyState, recordOrigin, recordOriginKey, returnParamsAt, rowCapNotice, startRecordJourney, toRouteParams, toSortParam, unconfirmedWriterRefusalOf, wholeDaysBetween } from "@cws/domain-contracts";
import { AsyncContainerComponent, BreadcrumbComponent, ClearSortButtonComponent, DataGridComponent, EMPTY_FILTER, FilterBuilderComponent, FilterSelectComponent, GridColumnMenuComponent, GridExportComponent, GridToolbarComponent, NoticesPanelComponent, PageHeaderComponent, PagerComponent, ReferenceLineComponent, RefreshButtonComponent, SAVED_FILTER_SCOPES, SearchShortcutDirective, StatusMessageComponent, compareBySorts, correlationIdOf, downloadBlob, gridColumnChoice, matchesGroup, matchesSearch, mutationFailed, mutationSucceeded, remoteError, remoteIdle, remoteLoaded, remoteLoading } from "@cws/shared-ui";
import { EMPTY, Subject, distinctUntilChanged, filter, fromEvent, interval, map, merge, of, scan, startWith, switchMap, tap, timer } from "rxjs";
import { DecimalPipe } from "@angular/common";
function totalQuantity(rows) {
	const quantified = rows.filter((row) => row.quantity !== null);
	const units = new Set(quantified.map((row) => row.quantityUom ?? "").filter((unit) => unit !== ""));
	if (units.size > 1) return {
		value: "—",
		hint: `Mixed units (${[...units].sort().join(", ")}) — no single total`
	};
	const total = quantified.reduce((sum, row) => sum + (row.quantity ?? 0), 0);
	const unit = [...units][0] ?? "";
	return {
		value: `${formatQuantity(total)}${unit === "" ? "" : ` ${unit}`}`,
		hint: quantified.length === rows.length ? "Across the queue" : "Excludes unquantified contracts"
	};
}
function approvalMetrics(rows, today) {
	const quantity = totalQuantity(rows);
	const waiting = rows.filter((row) => {
		const age = wholeDaysBetween(row.contractDate, today);
		return age !== null && age > 7;
	}).length;
	const shipping = rows.filter((row) => {
		const until = wholeDaysBetween(row.shipPeriodBegin, today);
		return until !== null && until >= -14;
	}).length;
	return [
		{
			label: "Pending approvals",
			value: `${rows.length}`,
			hint: "Awaiting your decision"
		},
		{
			label: "Total quantity",
			value: quantity.value,
			hint: quantity.hint
		},
		{
			label: `Waiting over 7 days`,
			value: `${waiting}`,
			hint: "By contract date — CTRM has no priority field",
			urgent: waiting > 0
		},
		{
			label: `Shipping within 14 days`,
			value: `${shipping}`,
			hint: "Ship period opens soon or has opened",
			urgent: shipping > 0
		}
	];
}
function formatCustomer(row) {
	return customerDisplayName(row.customerName, row.customerId);
}
function formatOriginDestination(row) {
	const origin = row.originName ?? "";
	const destination = row.destinationName ?? "";
	if (origin && destination) return `${origin} → ${destination}`;
	return origin || destination;
}
const APPROVAL_GRID_COLUMNS = [
	{
		key: "tradeUnit",
		header: "Trade Unit",
		sortable: true,
		width: 120,
		format: (row) => row.tradeUnit ?? ""
	},
	{
		key: "contractNumber",
		header: "Contract",
		sortable: true,
		width: 130,
		format: (row) => row.contractNumber
	},
	{
		key: "contractDate",
		header: "Date",
		sortable: true,
		width: 90,
		format: (row) => formatShortDate(row.contractDate),
		sortValue: (row) => row.contractDate ?? "",
		tooltip: (row) => formatContractDate(row.contractDate)
	},
	{
		key: "customerName",
		header: "Customer",
		sortable: true,
		width: 200,
		format: formatCustomer
	},
	{
		key: "commodity",
		header: "Commodity",
		sortable: true,
		width: 150,
		format: (row) => row.commodity ?? ""
	},
	{
		key: "customerContract",
		header: "Customer Contract",
		sortable: true,
		width: 175,
		format: (row) => row.customerContract ?? ""
	},
	{
		key: "shipPeriodBegin",
		header: "Ship Period",
		sortable: true,
		width: 150,
		format: formatShipPeriod,
		sortValue: (row) => row.shipPeriodBegin ?? ""
	},
	{
		key: "originName",
		header: "Origin / Destination",
		sortable: true,
		width: 200,
		format: formatOriginDestination,
		sortValue: (row) => row.originName ?? ""
	},
	{
		key: "quantity",
		header: "Quantity",
		align: "end",
		sortable: true,
		width: 130,
		format: (row) => row.quantity === null ? "" : `${formatQuantity(row.quantity)} ${row.quantityUom ?? ""}`.trim(),
		sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "price",
		header: "Price",
		align: "end",
		sortable: true,
		width: 110,
		format: (row) => formatPrice(row.price),
		sortValue: (row) => row.price ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "basisPrice",
		header: "Basis Price",
		align: "end",
		sortable: true,
		width: 110,
		format: (row) => formatPrice(row.basisPrice),
		sortValue: (row) => row.basisPrice ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "paymentTerms",
		header: "Payment Terms",
		sortable: true,
		width: 150,
		format: (row) => row.paymentTerms ?? ""
	},
	{
		key: "marketZone",
		header: "Market Zone",
		sortable: true,
		width: 110,
		format: (row) => row.marketZone ?? ""
	},
	{
		key: "trader",
		header: "Trader",
		sortable: true,
		width: 140,
		format: (row) => row.trader ?? row.traderInitials ?? ""
	}
];
const DEFAULT_SORTS = [{
	key: "contractDate",
	direction: "asc"
}];
const POLL_INTERVAL_MS = 6e4;
var ApprovalsPageComponent = class ApprovalsPageComponent {
	source = inject(CONTRACT_LIST_SOURCE);
	arrivedAfterSave = signal(inject(SaveAnnouncementStore).takeForOrigin("approvals"), ...ngDevMode ? [{ debugName: "arrivedAfterSave" }] : /* istanbul ignore next */ []);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	queueSource = inject(APPROVAL_QUEUE_SOURCE, { optional: true });
	queueRouteAbsent = this.queueSource === null;
	columns = APPROVAL_GRID_COLUMNS;
	columnChoice = gridColumnChoice(APPROVAL_GRID_COLUMNS, "approvals.queue", ["contractNumber"]);
	initial = fromRouteParams(this.route.snapshot.queryParamMap);
	sorts = signal(this.route.snapshot.queryParamMap.get("sort") === null ? DEFAULT_SORTS : this.initial.sorts, ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	defaultSorts = DEFAULT_SORTS;
	searchTerm = signal(this.initial.query.search ?? "", ...ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []);
	page = signal(this.initial.query.page, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	focusKey = signal(this.initial.focus, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	pollTicks = new Subject();
	pollNote = signal("", ...ngDevMode ? [{ debugName: "pollNote" }] : /* istanbul ignore next */ []);
	document = inject(DOCUMENT);
	constructor() {
		const visible = () => this.document.visibilityState === "visible";
		fromEvent(this.document, "visibilitychange").pipe(map(visible), startWith(visible()), distinctUntilChanged(), switchMap((shown, index) => !shown ? EMPTY : index === 0 ? interval(POLL_INTERVAL_MS) : interval(POLL_INTERVAL_MS).pipe(startWith(-1))), takeUntilDestroyed()).subscribe(() => this.pollTicks.next());
	}
	query = computed(() => {
		return {
			status: "Unapproved",
			...this.tradeUnit.code() === null ? {} : { tradeUnit: this.tradeUnit.code() },
			sort: toSortParam(this.sorts()),
			page: 1,
			pageSize: MAX_PAGE_SIZE
		};
	}, ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	queueState = toSignal((this.queueSource === null ? of(APPROVAL_QUEUE_NOT_DEPLOYED) : this.queueReads(this.queueSource)).pipe(scan((state, next) => {
		if (next === "loading") return {
			...state,
			loading: true
		};
		if ("polled" in next) {
			if (next.polled.kind !== "loaded") return state;
			const previous = state.settled?.kind === "loaded" ? state.settled.page : null;
			return {
				settled: {
					...next.polled,
					page: this.applyPoll(previous, next.polled.page)
				},
				loading: false
			};
		}
		return {
			settled: next,
			loading: false
		};
	}, {
		settled: null,
		loading: true
	}), startWith({
		settled: null,
		loading: true
	})), { requireSync: true });
	queueReads(source) {
		const asked = toObservable(this.attempt).pipe(scan((previous, attempt) => ({
			attempt,
			refresh: attempt !== previous.attempt
		}), {
			attempt: 0,
			refresh: false
		}), map(({ refresh }) => ({
			refresh,
			quiet: false
		})));
		const polled = this.pollTicks.pipe(filter(() => this.mode() === "approver" && !this.queueState().loading), map(() => ({
			refresh: false,
			quiet: true
		})));
		return merge(asked, polled).pipe(switchMap(({ refresh, quiet }) => {
			if (this.queueRouteAbsent) return quiet ? EMPTY : of(APPROVAL_QUEUE_NOT_DEPLOYED);
			if (quiet) return source.read({ refresh: false }).pipe(map((read) => ({ polled: read })));
			return source.read({ refresh }).pipe(tap((read) => {
				if (read.kind === "notDeployed") this.queueRouteAbsent = true;
			}), startWith("loading"));
		}));
	}
	applyPoll(previous, next) {
		if (previous === null) return next;
		const before = new Map(previous.rows.map((row) => [row.contractNumber, row]));
		const after = new Set(next.rows.map((row) => row.contractNumber));
		const arrived = next.rows.filter((row) => !before.has(row.contractNumber)).length;
		const left = previous.rows.filter((row) => !after.has(row.contractNumber)).length;
		if (arrived > 0 || left > 0) this.pollNote.set(pollNoteFor(arrived, left));
		return {
			...next,
			rows: next.rows.map((row) => {
				const old = before.get(row.contractNumber);
				return old !== void 0 && sameValues(old, row) ? old : row;
			})
		};
	}
	mode = computed(() => {
		switch (this.queueState().settled?.kind) {
			case void 0: return "pending";
			case "notDeployed": return "tradeUnit";
			case "refused": return "refused";
			default: return "approver";
		}
	}, ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	approver = computed(() => {
		const settled = this.queueState().settled;
		return settled?.kind === "loaded" ? settled.approver : null;
	}, ...ngDevMode ? [{ debugName: "approver" }] : /* istanbul ignore next */ []);
	refusalDismissed = signal(false, ...ngDevMode ? [{ debugName: "refusalDismissed" }] : /* istanbul ignore next */ []);
	refusal = computed(() => {
		const settled = this.queueState().settled;
		return settled?.kind === "refused" && !this.refusalDismissed() ? {
			kind: "failure",
			message: `${settled.title}\n${settled.detail}`,
			sent: true,
			correlationId: settled.correlationId
		} : null;
	}, ...ngDevMode ? [{ debugName: "refusal" }] : /* istanbul ignore next */ []);
	refusalDetail = computed(() => {
		const settled = this.queueState().settled;
		return settled?.kind === "refused" ? settled.detail : "";
	}, ...ngDevMode ? [{ debugName: "refusalDetail" }] : /* istanbul ignore next */ []);
	dismissRefusal() {
		this.refusalDismissed.set(true);
	}
	listData = toSignal(merge(toObservable(computed(() => ({
		query: this.mode() === "tradeUnit" ? this.query() : null,
		attempt: this.attempt()
	}))).pipe(scan((previous, next) => ({
		...next,
		refresh: next.attempt !== previous.attempt
	}), {
		query: null,
		attempt: 0,
		refresh: false
	}), map(({ query, refresh }) => ({
		query,
		refresh,
		quiet: false
	}))), this.pollTicks.pipe(filter(() => this.mode() === "tradeUnit" && this.hasTradeUnit() && this.listData().status !== "loading"), map(() => ({
		query: this.query(),
		refresh: false,
		quiet: true
	})))).pipe(switchMap(({ query, refresh, quiet }) => {
		if (query === null) return of(remoteLoading());
		const read = listEveryPage(this.source, query, { refresh });
		return quiet ? read.pipe(filter((state) => state.status === "loaded"), map((state) => state.status === "loaded" ? remoteLoaded(this.applyPoll(this.result(), state.value)) : state)) : read;
	})), { initialValue: remoteLoading() });
	data = computed(() => {
		const { settled, loading } = this.queueState();
		if (this.mode() === "tradeUnit") return this.listData();
		if (loading || settled === null) return remoteLoading();
		switch (settled.kind) {
			case "loaded": return remoteLoaded(settled.page);
			case "failed": return remoteError({
				message: settled.message,
				...settled.correlationId === null ? {} : { correlationId: settled.correlationId }
			});
			default: return remoteIdle();
		}
	}, ...ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []);
	containerState = computed(() => {
		if (this.mode() === "pending") return remoteLoading();
		return this.hasScope() ? this.data() : remoteLoaded(emptyPage(this.query()));
	}, ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	result = computed(() => {
		const state = this.data();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "result" }] : /* istanbul ignore next */ []);
	queue = computed(() => {
		const term = this.searchTerm();
		const group = this.filter();
		const matched = (this.result()?.rows ?? []).filter((row) => matchesGroup(row, this.columns, group) && matchesSearch(row, this.columns, term));
		const sorts = this.sorts();
		return sorts.length === 0 ? matched : [...matched].sort((left, right) => compareBySorts(this.columns, sorts, left, right));
	}, ...ngDevMode ? [{ debugName: "queue" }] : /* istanbul ignore next */ []);
	metrics = computed(() => approvalMetrics(this.queue(), /* @__PURE__ */ new Date()), ...ngDevMode ? [{ debugName: "metrics" }] : /* istanbul ignore next */ []);
	pageSize = DEFAULT_PAGE_SIZE;
	emptyMessage = computed(() => {
		const settled = this.queueState().settled;
		if (settled?.kind === "refused") return settled.title;
		if (this.mode() === "approver") return this.approver()?.traderInitials === null ? "Your CTRM user has no trader initials, so no approval record names you." : "Nothing is awaiting your approval.";
		return this.hasTradeUnit() ? "Nothing is awaiting approval in this trade unit." : "Choose a trade unit in the top bar to load the approval queue.";
	}, ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	currentPage = computed(() => Math.min(Math.max(this.page(), 1), this.totalPages()), ...ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const start = (this.currentPage() - 1) * this.pageSize;
		return this.queue().slice(start, start + this.pageSize);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	moreThanOnePage = computed(() => {
		const result = this.result();
		return result !== null && result.rows.length < result.totalCount;
	}, ...ngDevMode ? [{ debugName: "moreThanOnePage" }] : /* istanbul ignore next */ []);
	isRefreshing = computed(() => this.data().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => this.result()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.result()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [this.scopeSummary(), ...this.showSystemNotices() ? [
		"Approvals do not update CTRM",
		...this.isSimulated() ? ["Simulated rows, not read from CTRM"] : [],
		...this.customerNamesRedacted() ? ["Customer names are unavailable"] : [],
		...this.rowCapMessage() ? ["CTRM may have sent fewer rows than exist"] : [],
		...this.warnings()
	] : []], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	showSystemNotices = computed(() => this.permissions.canSeeSystemNotices?.() ?? false, ...ngDevMode ? [{ debugName: "showSystemNotices" }] : /* istanbul ignore next */ []);
	rowCapMessage = computed(() => {
		const page = this.result();
		return page ? rowCapNotice(page.rowCapReached, page.rowCap) : null;
	}, ...ngDevMode ? [{ debugName: "rowCapMessage" }] : /* istanbul ignore next */ []);
	customerNamesRedacted = computed(() => this.result()?.customerNames === "Redacted", ...ngDevMode ? [{ debugName: "customerNamesRedacted" }] : /* istanbul ignore next */ []);
	serverSorted = computed(() => (this.result()?.appliedSort ?? null) !== null, ...ngDevMode ? [{ debugName: "serverSorted" }] : /* istanbul ignore next */ []);
	hasTradeUnit = computed(() => {
		const code = this.tradeUnit.code();
		return code !== null && code !== "";
	}, ...ngDevMode ? [{ debugName: "hasTradeUnit" }] : /* istanbul ignore next */ []);
	hasScope = computed(() => this.mode() === "approver" || this.mode() === "tradeUnit" && this.hasTradeUnit(), ...ngDevMode ? [{ debugName: "hasScope" }] : /* istanbul ignore next */ []);
	scopeSummary = computed(() => {
		switch (this.mode()) {
			case "approver": return "Your CTRM approval queue";
			case "refused": return "Your approval queue could not be shown";
			default: return "Scoped to one trade unit";
		}
	}, ...ngDevMode ? [{ debugName: "scopeSummary" }] : /* istanbul ignore next */ []);
	totalPages = computed(() => Math.max(1, Math.ceil(this.queue().length / DEFAULT_PAGE_SIZE)), ...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	trackByContract = (row) => row.contractNumber;
	openReview(row) {
		const params = toRouteParams(this.query(), this.sorts(), row.contractNumber);
		const search = this.searchTerm().trim();
		const returnTo = new URLSearchParams({
			...params,
			...search === "" ? {} : { search },
			...this.currentPage() > 1 ? { page: String(this.currentPage()) } : {}
		}).toString();
		const keys = this.queue().map((each) => each.contractNumber);
		const journey = this.journeys.begin(startRecordJourney({
			origin: "approvals",
			kind: "approval",
			label: "Approvals",
			keys,
			index: Math.max(0, keys.indexOf(row.contractNumber))
		}));
		this.hostContext.navigate({
			kind: "review",
			origin: "approvals",
			contractNumber: row.contractNumber,
			params: { returnTo },
			state: recordJourneyState(journey)
		});
	}
	journeys = inject(RecordJourneyStore);
	rereadAfterDecision = this.journeys.takeLeft("approvals") ? this.attempt.update((value) => value + 1) : void 0;
	rangeLabel = computed(() => {
		const total = this.queue().length;
		if (total === 0) return "";
		return `${(this.currentPage() - 1) * this.pageSize + 1}–${Math.min(this.currentPage() * this.pageSize, total)} of ${total}`;
	}, ...ngDevMode ? [{ debugName: "rangeLabel" }] : /* istanbul ignore next */ []);
	onSortChange(sorts) {
		this.sorts.set(sorts);
	}
	onSearch(term) {
		this.searchTerm.set(term);
		this.page.set(1);
	}
	filter = signal(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	savedFilterScope = SAVED_FILTER_SCOPES.approvals;
	onRulesChange(group) {
		this.filter.set(group);
		this.page.set(1);
	}
	onViewChange(view) {
		this.filter.set(view.group);
		this.columnChoice.applyView(view.columns);
		this.sorts.set(view.sort);
		this.page.set(1);
	}
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportFilename = (scope) => {
		return `approvals-${this.mode() === "approver" ? "my-queue" : this.tradeUnit.code() ?? "all"}-${scope === "page" ? `page-${this.currentPage()}` : "all"}`;
	};
	exportAllRows = () => Promise.resolve(this.queue());
	onPageStep(step) {
		this.page.set(Math.min(Math.max(this.currentPage() + step, 1), this.totalPages()));
	}
	onPage(page) {
		this.page.set(page);
	}
	refresh() {
		this.pollNote.set("");
		this.attempt.update((value) => value + 1);
	}
	retry() {
		this.refresh();
	}
	onRowActivate(row) {
		this.openReview(row);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ApprovalsPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ApprovalsPageComponent,
		isStandalone: true,
		selector: "cms-approvals-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Approvals\"\n    description=\"Contracts awaiting trader approval, oldest first.\"\n  />\n\n  <!-- #888: the save a Save-and-close from a record opened here came back with, said once. -->\n  <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\n\n  <!--\n    #101: the queue route could not tell who the user is in CTRM (#1021). The server's title and\n    detail say what to ask the Help Desk for, and the reference line carries its trace id.\n  -->\n  <cms-status-message [outcome]=\"refusal()\" (dismissed)=\"dismissRefusal()\" />\n\n  <!--\n    🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-14). This was three\n    full-width banners plus one per server warning, ahead of the first row of the work queue.\n\n    Every one of them is still here and still true — the panel states how many there are, summarises\n    each in a line, and shows them in full on demand. What changed is that the queue now opens with\n    the queue.\n\n    ⚠ **The CTRM-is-not-updated warning can be de-emphasised HERE only because the decision moved.**\n    It was unconditional and loud because Approve and Reject sat in the grid immediately below it,\n    and an approval falsely believed to be done is the worst outcome this screen can produce. The\n    decision now happens on the review screen, which states the same thing at the point of action\n    and in the result itself. Collapsing it here without that move would have been a real loss of\n    safety rather than a tidy-up.\n  -->\n  <cms-notices-panel [summaries]=\"noticeSummaries()\" [systemNotices]=\"showSystemNotices()\">\n    <!--\n      🔴 The scope statement, and it always says which scope is on screen (#101). CTRM's approval\n      queue is the contracts whose approval record names the user as the trader, in every trade unit\n      (GEstevez's 2026-10-20 probe on #217). When the route serving it answers (#1021) the queue is\n      that, and says whose; when the route is not on the server, what is on screen is ONE trade unit,\n      and the sentence says so.\n\n      An approver whose contracts sit in four trade units would otherwise see one unit's queue, find\n      it short, and reasonably conclude there was nothing to approve. A silently narrow work queue is\n      worse than an empty one.\n\n      ⚠ The backup sentence is driven by the approver type the route echoes. While CTRM's backup\n      lookup is broken the backend asks for PRIMARY (#993), and the screen says backups are not\n      included. When the server does not say, the screen says nothing about backups either way.\n    -->\n    @switch (mode()) {\n      @case ('approver') {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n          <div class=\"scoular-alert-title\">Showing your CTRM approval queue</div>\n          <div class=\"scoular-alert-description\">\n            @if (approver()?.traderInitials; as initials) {\n              CTRM lists the contracts whose approval record names you ({{ initials }}) as the\n              trader, in every trade unit. The trade unit selected above does not narrow it.\n            } @else if (approver()) {\n              Your CTRM user has no trader initials, so no approval record names you and CTRM lists\n              no contracts for you to approve.\n            } @else {\n              CTRM lists the contracts whose approval record names you as the trader, in every trade\n              unit. The trade unit selected above does not narrow it.\n            }\n            @if (approver()?.approverType === 'PRIMARY') {\n              Contracts you cover as a backup approver for another trader are not included yet.\n            } @else if (approver()?.approverType === 'BOTH') {\n              It also includes the contracts you cover as a backup approver.\n            }\n          </div>\n        </div>\n      }\n      @case ('refused') {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n          <div class=\"scoular-alert-title\">Your approval queue could not be shown</div>\n          <div class=\"scoular-alert-description\">\n            CTRM's approval queue is the contracts whose approval record names you as the trader, and\n            we could not match you to exactly one CTRM user. {{ refusalDetail() }}\n          </div>\n        </div>\n      }\n      @default {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n          <div class=\"scoular-alert-title\">Showing one trade unit, not your approval queue</div>\n          <div class=\"scoular-alert-description\">\n            CTRM's approval queue is the contracts whose approval record names you as the trader, in\n            every trade unit. That queue is not available here yet, so this screen shows the trade\n            unit selected above instead: <strong>contracts awaiting you in other trade units are not\n            listed here</strong>. Switch trade unit to see them.\n          </div>\n        </div>\n      }\n    }\n\n    <!-- #1223: everything below is a system caveat, the Admin role's only. -->\n    @if (showSystemNotices()) {\n      <!--\n        The capability warning. Two independent blockers, both checked against the authorities:\n\n          1. `approveContracts` has never succeeded through any transport — the origin OOMs building\n             its output parameters (issue 108) — and the API publishes no approval route.\n          2. `trader_approval_status` is `\"access\": \"readOnly\"` in `constraints.json`, so the proven\n             contract-upsert path refuses it rather than ignoring it.\n\n        ⚠ **The description below deliberately names NEITHER blocker.** It used to carry both CTRM\n        identifiers in `<code>` and a live link into our issue tracker, which is three things a trader\n        can neither act on nor reach — and the link implied a status they could go and check. What a\n        trader needs from this box is the consequence and the alternative; the mechanism is above, for\n        whoever maintains the screen.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">\n          Approvals are recorded in this session only — CTRM is not updated\n        </div>\n        <div class=\"scoular-alert-description\">\n          Decisions taken on the review screen <strong>do not reach CTRM</strong>, which cannot yet\n          accept an approval from this application. They are <strong>lost on reload</strong> and must\n          still be completed on the green screen. Use this queue to review and decide; record the\n          decision in CTRM as you do today.\n        </div>\n      </div>\n\n      @if (isSimulated()) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">Simulated data</div>\n          <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\n        </div>\n      }\n\n      @if (customerNamesRedacted()) {\n        <!--\n          🔴 The customer directory is refusing us (#328). Same notice as the workspace, and it belongs\n          here more than there: this is the one status whose CTRM projection carries a customer name\n          directly, so ids in this column are a column that worked yesterday.\n\n          ⚠ Names no internal identifier, per the 2026-09-17 copy guard, and leads with what is still\n          reliable — the contracts and the decisions are unaffected, only the label on the counterparty.\n        -->\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\n          <div class=\"scoular-alert-description\">\n            The customer directory is not answering for this application, so the Customer column falls\n            back to account numbers. The contracts awaiting you and their details are unaffected. This\n            will not clear by retrying — please report it.\n          </div>\n        </div>\n      }\n\n      @if (rowCapMessage(); as message) {\n        <!-- #662: CTRM truncates the queue silently; shown only on the server's explicit true. -->\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">This queue may be incomplete</div>\n          <div class=\"scoular-alert-description\">{{ message }}</div>\n        </div>\n      }\n\n      @for (warning of warnings(); track warning) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-description\">{{ warning }}</div>\n        </div>\n      }\n    }\n  </cms-notices-panel>\n\n  <!--\n    🔴 **The workload, before the rows** (JFrisbie, 2026-09-14). An approver arriving at this screen\n    had to read the grid to find out how much was waiting; these answer it in one glance.\n\n    ⚠ **Two of these are DERIVATIONS, not fields, and the cards say so.** CTRM has no priority field\n    and `ContractSummary` carries none — so \"high priority\" is `Waiting over 7 days` from the\n    contract date, and \"expiring soon\" is `Shipping within 14 days` from the ship period. The hint\n    line under each is what stops the number being taken to the business as though it were a CTRM\n    concept. See `approval-metrics.ts`.\n\n    ⚠ **Rendered only with a scope** (the approver's queue, or a trade unit chosen), because without one the queue has not been asked\n    for and four zeroes would read as \"nothing to approve\" rather than \"nothing requested\".\n  -->\n  @if (hasScope()) {\n    <dl class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:lg:grid-cols-4\">\n      @for (metric of metrics(); track metric.label) {\n        <!--\n          `scoular-card` for the surface, so these match the panels around them rather than\n          inventing a second card style.\n        -->\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\n\n          <!--\n            ⚠ Colour is never the only carrier — the urgent cards are distinguished by their LABEL\n            as much as by the tint, because roughly 1 in 12 men has a colour vision deficiency\n            (02a §4). \"Waiting over 7 days\" says what it is with the colour removed.\n          -->\n          <dd\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\n            [class]=\"\n              metric.urgent\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\n                : 'cws:text-slate-900 cws:dark:text-white'\n            \"\n          >\n            {{ metric.value }}\n          </dd>\n\n          <!-- A second `<dd>`, not a `<p>`: a `<div>` in a `<dl>` holds only `<dt>`/`<dd>` (#764). -->\n          <dd class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</dd>\n        </div>\n      }\n    </dl>\n  }\n\n  <!--\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto`.\n\n    🔴 This mirrors the workspace grid's own row exactly (JFrisbie, 2026-09-10) — same order, same\n    `ml-auto` split, same components — so the controls do not move as a user goes between the two\n    screens. The filters are inline rather than behind a Filters dropdown because there are four of\n    them and they fit; the workspace hides its behind a button because it has a search box competing\n    for the same row.\n  -->\n  <!--\n    🔴 **The width goes on the LABEL, never on the field** — seventh instance of this repo's\n    unlayered-CSS trap.\n\n    `.scoular-form-input` is `@apply w-full`, and the design system compiles unlayered while Tailwind\n    utilities land in `@layer utilities` — so a `w-28` on the input silently loses and the field\n    fills its wrapper instead. Measured: every filter here rendered **193px** regardless of the class\n    on it, which is what wrapped the refresh/pager block onto a second line.\n\n    The wrapper carries no design-system class, so a utility on it is uncontested — which is the\n    recorded remedy: put the declaration where there is no contest rather than fighting the layer.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <!--\n    🔴 **The toolbar is a card now** (JFrisbie, 2026-09-14), which is the only part of the requested\n    elevation that was actually missing.\n\n    ⚠ The other two targets already had it, and adding a shadow to either would have been a no-op\n    dressed as a change: `.scoular-card` is `@apply rounded-lg border bg-white shadow-sm`, so the\n    summary cards above already carry it, and the grid's own wrapper declares the same three. Worth\n    stating because a Tailwind `shadow-sm` layered on top of `.scoular-card` would also LOSE — the\n    design system compiles unlayered and utilities land in `@layer utilities` — so it would have\n    looked deliberate and done nothing.\n\n    `p-3` rather than the design system's own `p-6`: this is a control strip, and card padding meant\n    for content pushes the search box away from the grid it filters.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <cms-grid-toolbar>\n    <!--\n      One search box, replacing the Trader, Commodity and Customer boxes (JFrisbie, 2026-09-10).\n\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so all\n      three are still reachable, plus the eleven the boxes could not narrow on.\n\n      ⚠ **Applied CLIENT-SIDE, which is why this screen now asks for one large page.** A search\n      over rows we hold can only see the page it was given, so with a server page of 50 a term\n      matching a contract on page 3 would return nothing — and on a work queue “no matches” reads\n      as “nothing to approve”. See the query in the component.\n\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\n      move as a user goes between the screens.\n    -->\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        autocomplete=\"off\"\n        placeholder=\"Search every column\"\n        [value]=\"searchTerm()\"\n        (input)=\"onSearch($any($event.target).value)\"\n      />\n    </label>\n\n    <!--\n      Saved views and the filter builder, the same pair the workspace carries (JFrisbie, 2026-09-15).\n\n      ⚠ **Its own scope.** A workspace view has no meaning here — it would carry rules against columns\n      this grid does not render and match nothing, which on a work queue reads as \"nothing to\n      approve\". `SAVED_FILTER_SCOPES` declares all four keys together and a test asserts they differ.\n\n      🔴 The width is on this wrapper, not on the control: `.scoular-form-input` is `@apply w-full`\n      and the design system compiles unlayered, so a `w-*` on the control itself would lose.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [columnLayout]=\"columnChoice.layout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\n      (click)=\"builder.beginAdd()\"\n    >\n      + Add filter\n    </button>\n\n    <!--\n      🔴 **The Approver type dropdown that stood here is GONE (JFrisbie, 2026-09-17), and the\n      consequence is real rather than cosmetic.** The toolbar is now one standard set of controls on\n      every grid — search, view, add filter, clear sort, export, refresh, pager — and nothing else.\n\n      ⚠ What that costs, stated so nobody re-derives it from an empty space: `approverType` was a\n      **CTRM request parameter**, and this grid renders **no approver-type column**, so neither the\n      search nor a filter rule can express it. Primary-versus-Secondary narrowing is therefore\n      **unreachable from this screen** until a control returns. This is the same trade the status\n      dropdown made on the workspace, made deliberately and with the same reasoning on the record.\n\n      ✅ Nothing about the request plumbing was deleted: `ContractListQuery.approverType` still\n      exists and the API still accepts it, so restoring a control is a template change rather than a\n      rebuild.\n    -->\n\n    <!--\n      Clear sort, and it stays hidden until the queue is sorted some other way.\n\n      `defaultSorts` is what makes that true and is not decoration: this screen ARRIVES sorted\n      oldest-first, which is the queue's own meaning rather than anything the user did -- so a\n      button offering to undo it would be there from the moment they arrive, and pressing it would\n      discard the answer to \"what should I work on next\" rather than undoing a choice.\n    -->\n    <cms-clear-sort-button\n      [sorts]=\"sorts()\"\n      [defaultSorts]=\"defaultSorts\"\n      (clear)=\"onSortChange($event)\"\n    />\n\n    <!--\n      `ml-auto` puts refresh and the pager hard right, which is where the workspace keeps them. Note\n      this is the first element in the row with it, so everything before it stays left-aligned.\n    -->\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\n      <!-- Columns, beside the export it shapes, where Home has it (JFrisbie, 2026-10-23). -->\n      <cms-grid-column-menu\n        [fields]=\"columnChoice.fields()\"\n        [lockedKeys]=\"columnChoice.locked()\"\n        [keptIn]=\"columnChoice.keptIn()\"\n        [failure]=\"columnChoice.failure()\"\n        resetLabel=\"Show every column\"\n        (fieldsChange)=\"columnChoice.change($event)\"\n        (reset)=\"columnChoice.reset()\"\n      />\n      <!--\n        Export, the same control the workspace carries and the same component — see\n        `cms-grid-export` for why this is shared rather than the workspace's markup copied here.\n\n        ⚠ **Both scopes are cheap on this screen and the choice is still offered.** This queue fetches\n        one large page and slices it locally, so \"all pages\" is already in memory — but the question\n        it answers is \"what I am looking at\" versus \"everything the filter matched\", and those are\n        different files on a paged grid. Hiding the step where it happens to be cheap would make the\n        same control mean different things on different screens.\n      -->\n      <cms-grid-export\n        [columns]=\"columns\"\n        [visibleKeys]=\"columnChoice.shownKeys()\"\n        [pageRows]=\"rows()\"\n        [totalCount]=\"queue().length\"\n        [allRows]=\"exportAllRows\"\n        [filename]=\"exportFilename\"\n        [disabled]=\"!hasScope() || queue().length === 0\"\n        (failed)=\"exportError.set($event)\"\n      />\n\n      <cms-refresh-button\n        label=\"Refresh the approval queue\"\n        [busy]=\"isRefreshing()\"\n        [disabled]=\"!hasScope()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <!--\n        The top pager, so advancing a page does not mean scrolling past 50 rows first. Same\n        component as the footer's, not a copy.\n\n        🔴 **`currentPage()`, NEVER `query().page`.** This queue fetches ONE large server page and\n        slices it locally, so a search can see the whole matched set rather than one page of it —\n        which means `query().page` is pinned to `1` and is not the page the user is on.\n\n        Bound to `query().page` the pager read \"Page 1 of N\" forever, First and Previous were\n        permanently disabled, and Next emitted `1 + 1` — so page 2 was reachable and page 3 was not\n        (JFrisbie, 2026-09-14). ⚠ Note a single Next click still worked, which is why the one test\n        that existed here never caught it.\n\n        `currentPage()` is also the CLAMPED page, and the rows are sliced by the same value — so the\n        indicator and the grid cannot disagree after a search narrows the queue.\n      -->\n      <cms-pager\n        [page]=\"currentPage()\"\n        [totalPages]=\"totalPages()\"\n        position=\"top\"\n        (goTo)=\"onPage($event)\"\n      />\n    </div>\n  </cms-grid-toolbar>\n\n  <!--\n    The chips and the rule editor. Renders NOTHING when there are no rules and the editor is closed,\n    so it leaves no empty band above the queue. Its own \"+ Add filter\" button is suppressed because\n    the toolbar carries one — one owner for the editor's open state, as on the workspace.\n  -->\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onRulesChange($event)\"\n  />\n\n  <!--\n    ⚠ **Deliberately NOT in the notices panel**, which is for standing conditions of the screen. A\n    failed export is the outcome of something the user just did, and behind a collapsed panel it is a\n    message nobody sees — the same rule the workspace applies to its own export failure.\n  -->\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    #1159: what the last automatic re-read changed. Always in the page so a screen reader is already\n    listening when the text arrives; visually hidden while empty, and taken out of the flow by\n    `sr-only` so the empty region adds no gap.\n  -->\n  <p\n    data-testid=\"queue-poll-note\"\n    role=\"status\"\n    aria-live=\"polite\"\n    class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\"\n    [class.cws:sr-only]=\"pollNote() === ''\"\n  >{{ pollNote() }}</p>\n\n  <!--\n    ⚠ **The rejection-reason prompt and the decision outcomes used to sit here, and both moved with\n    the decision** (JFrisbie, 2026-09-14) rather than being kept beside a queue that no longer\n    decides anything.\n\n    BR-062's reason — the body of the denial email — is collected on the review screen, where the\n    contract being rejected is on screen while it is typed. A prompt here asked someone to justify\n    rejecting a contract they were looking at fourteen columns of.\n  -->\n\n  <!--\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\n\n    This screen used to render a `scoular-card` above the container and hide the container behind\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\n    read as a notice about the data rather than as the absence of any.\n\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\n    unit the request is certain to 422, which is why the screen never issues one.\n  -->\n  <cms-async-container\n    [data]=\"containerState()\"\n    [empty]=\"!hasScope() || rows().length === 0\"\n    [emptyMessage]=\"emptyMessage()\"\n    loadingLabel=\"Loading the approval queue\"\n    (retry)=\"retry()\"\n  >\n      <!--\n        ⚠ **`striped` is safe HERE specifically because this queue declares no `rowTone`.** A stripe\n        and a semantic tint are both a background on the `<tr>`, and together the tint stops meaning\n        anything — a shaded row could be \"rejected\" or just \"even\". The grid enforces the precedence\n        rather than trusting this binding, but a future tone on this queue would make the stripe the\n        wrong call rather than merely a redundant one.\n      -->\n      <cms-data-grid\n        [rows]=\"rows()\"\n        [columns]=\"columnChoice.shown()\"\n        label=\"Contracts awaiting approval\"\n        [columnMenu]=\"false\"\n        [striped]=\"true\"\n        [sorts]=\"sorts()\"\n        [trackBy]=\"trackByContract\"\n        [focusKey]=\"focusKey()\"\n        (sortChange)=\"onSortChange($event)\"\n        activateLabel=\"Review\"\n        (rowActivate)=\"onRowActivate($event)\"\n        (pageStep)=\"onPageStep($event)\"\n      />\n\n      <!--\n        The footer, matching the workspace grid: record count left, pager right. Same\n        `justify-between` row and the same `1–50 of 150` wording, so the two screens read alike.\n      -->\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          <p>{{ rangeLabel() }}</p>\n\n          @if (!serverSorted() && sorts().length > 0 && moreThanOnePage()) {\n            <!--\n              The sort caveat, and it is NOT the one this screen carried first.\n\n              It used to read \"Sorted within this page\" and was guarded on the LOCAL page count.\n              That stopped being true the moment this queue started fetching one large page and\n              paging in process: the sort runs over the whole matched set and the slice happens\n              after it, so the ordering already spans every page on screen.\n\n              What survives is the real limit, and it is the one worth saying: CTRM sent a capped\n              set (CR-4 / #31), so \"the oldest contract\" means the oldest of what was READ. On a\n              work queue that is exactly the distinction an approver relies on -- which is why the\n              guard is now the server's own truncation rather than a local page boundary.\n\n              Retires itself when the server echoes `appliedSort`.\n\n              #1147: the queue reads every page now, so the guard is a page that did not arrive.\n              CTRM's own cap has the row-cap notice.\n            -->\n            <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n              Sorted across everything read -- not every page arrived, so this is not the whole\n              queue.\n            </p>\n          }\n        </div>\n\n        <cms-pager\n          [page]=\"currentPage()\"\n          [totalPages]=\"totalPages()\"\n          position=\"bottom\"\n          (goTo)=\"onPage($event)\"\n        />\n      </footer>\n  </cms-async-container>\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel",
					"columnLayout"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"columnMenu",
					"columnsKey",
					"lockedColumns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"rowLabel",
					"activateLabel",
					"selectable",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep",
					"rowToggle",
					"selectAll"
				]
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"systemNotices",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridColumnMenuComponent,
				selector: "cms-grid-column-menu",
				inputs: [
					"fields",
					"lockedKeys",
					"keptIn",
					"failure",
					"disabled",
					"resetLabel"
				],
				outputs: ["fieldsChange", "reset"]
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"visibleKeys",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ApprovalsPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-approvals-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FilterBuilderComponent,
				FilterSelectComponent,
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				NoticesPanelComponent,
				StatusMessageComponent,
				SearchShortcutDirective,
				GridColumnMenuComponent,
				GridExportComponent,
				GridToolbarComponent,
				PagerComponent,
				RefreshButtonComponent,
				PageHeaderComponent
			],
			template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Approvals\"\n    description=\"Contracts awaiting trader approval, oldest first.\"\n  />\n\n  <!-- #888: the save a Save-and-close from a record opened here came back with, said once. -->\n  <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\n\n  <!--\n    #101: the queue route could not tell who the user is in CTRM (#1021). The server's title and\n    detail say what to ask the Help Desk for, and the reference line carries its trace id.\n  -->\n  <cms-status-message [outcome]=\"refusal()\" (dismissed)=\"dismissRefusal()\" />\n\n  <!--\n    🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-14). This was three\n    full-width banners plus one per server warning, ahead of the first row of the work queue.\n\n    Every one of them is still here and still true — the panel states how many there are, summarises\n    each in a line, and shows them in full on demand. What changed is that the queue now opens with\n    the queue.\n\n    ⚠ **The CTRM-is-not-updated warning can be de-emphasised HERE only because the decision moved.**\n    It was unconditional and loud because Approve and Reject sat in the grid immediately below it,\n    and an approval falsely believed to be done is the worst outcome this screen can produce. The\n    decision now happens on the review screen, which states the same thing at the point of action\n    and in the result itself. Collapsing it here without that move would have been a real loss of\n    safety rather than a tidy-up.\n  -->\n  <cms-notices-panel [summaries]=\"noticeSummaries()\" [systemNotices]=\"showSystemNotices()\">\n    <!--\n      🔴 The scope statement, and it always says which scope is on screen (#101). CTRM's approval\n      queue is the contracts whose approval record names the user as the trader, in every trade unit\n      (GEstevez's 2026-10-20 probe on #217). When the route serving it answers (#1021) the queue is\n      that, and says whose; when the route is not on the server, what is on screen is ONE trade unit,\n      and the sentence says so.\n\n      An approver whose contracts sit in four trade units would otherwise see one unit's queue, find\n      it short, and reasonably conclude there was nothing to approve. A silently narrow work queue is\n      worse than an empty one.\n\n      ⚠ The backup sentence is driven by the approver type the route echoes. While CTRM's backup\n      lookup is broken the backend asks for PRIMARY (#993), and the screen says backups are not\n      included. When the server does not say, the screen says nothing about backups either way.\n    -->\n    @switch (mode()) {\n      @case ('approver') {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n          <div class=\"scoular-alert-title\">Showing your CTRM approval queue</div>\n          <div class=\"scoular-alert-description\">\n            @if (approver()?.traderInitials; as initials) {\n              CTRM lists the contracts whose approval record names you ({{ initials }}) as the\n              trader, in every trade unit. The trade unit selected above does not narrow it.\n            } @else if (approver()) {\n              Your CTRM user has no trader initials, so no approval record names you and CTRM lists\n              no contracts for you to approve.\n            } @else {\n              CTRM lists the contracts whose approval record names you as the trader, in every trade\n              unit. The trade unit selected above does not narrow it.\n            }\n            @if (approver()?.approverType === 'PRIMARY') {\n              Contracts you cover as a backup approver for another trader are not included yet.\n            } @else if (approver()?.approverType === 'BOTH') {\n              It also includes the contracts you cover as a backup approver.\n            }\n          </div>\n        </div>\n      }\n      @case ('refused') {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n          <div class=\"scoular-alert-title\">Your approval queue could not be shown</div>\n          <div class=\"scoular-alert-description\">\n            CTRM's approval queue is the contracts whose approval record names you as the trader, and\n            we could not match you to exactly one CTRM user. {{ refusalDetail() }}\n          </div>\n        </div>\n      }\n      @default {\n        <div class=\"scoular-alert scoular-alert-info\" role=\"status\" data-testid=\"scope-notice\">\n          <div class=\"scoular-alert-title\">Showing one trade unit, not your approval queue</div>\n          <div class=\"scoular-alert-description\">\n            CTRM's approval queue is the contracts whose approval record names you as the trader, in\n            every trade unit. That queue is not available here yet, so this screen shows the trade\n            unit selected above instead: <strong>contracts awaiting you in other trade units are not\n            listed here</strong>. Switch trade unit to see them.\n          </div>\n        </div>\n      }\n    }\n\n    <!-- #1223: everything below is a system caveat, the Admin role's only. -->\n    @if (showSystemNotices()) {\n      <!--\n        The capability warning. Two independent blockers, both checked against the authorities:\n\n          1. `approveContracts` has never succeeded through any transport — the origin OOMs building\n             its output parameters (issue 108) — and the API publishes no approval route.\n          2. `trader_approval_status` is `\"access\": \"readOnly\"` in `constraints.json`, so the proven\n             contract-upsert path refuses it rather than ignoring it.\n\n        ⚠ **The description below deliberately names NEITHER blocker.** It used to carry both CTRM\n        identifiers in `<code>` and a live link into our issue tracker, which is three things a trader\n        can neither act on nor reach — and the link implied a status they could go and check. What a\n        trader needs from this box is the consequence and the alternative; the mechanism is above, for\n        whoever maintains the screen.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">\n          Approvals are recorded in this session only — CTRM is not updated\n        </div>\n        <div class=\"scoular-alert-description\">\n          Decisions taken on the review screen <strong>do not reach CTRM</strong>, which cannot yet\n          accept an approval from this application. They are <strong>lost on reload</strong> and must\n          still be completed on the green screen. Use this queue to review and decide; record the\n          decision in CTRM as you do today.\n        </div>\n      </div>\n\n      @if (isSimulated()) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">Simulated data</div>\n          <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\n        </div>\n      }\n\n      @if (customerNamesRedacted()) {\n        <!--\n          🔴 The customer directory is refusing us (#328). Same notice as the workspace, and it belongs\n          here more than there: this is the one status whose CTRM projection carries a customer name\n          directly, so ids in this column are a column that worked yesterday.\n\n          ⚠ Names no internal identifier, per the 2026-09-17 copy guard, and leads with what is still\n          reliable — the contracts and the decisions are unaffected, only the label on the counterparty.\n        -->\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\n          <div class=\"scoular-alert-description\">\n            The customer directory is not answering for this application, so the Customer column falls\n            back to account numbers. The contracts awaiting you and their details are unaffected. This\n            will not clear by retrying — please report it.\n          </div>\n        </div>\n      }\n\n      @if (rowCapMessage(); as message) {\n        <!-- #662: CTRM truncates the queue silently; shown only on the server's explicit true. -->\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-title\">This queue may be incomplete</div>\n          <div class=\"scoular-alert-description\">{{ message }}</div>\n        </div>\n      }\n\n      @for (warning of warnings(); track warning) {\n        <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n          <div class=\"scoular-alert-description\">{{ warning }}</div>\n        </div>\n      }\n    }\n  </cms-notices-panel>\n\n  <!--\n    🔴 **The workload, before the rows** (JFrisbie, 2026-09-14). An approver arriving at this screen\n    had to read the grid to find out how much was waiting; these answer it in one glance.\n\n    ⚠ **Two of these are DERIVATIONS, not fields, and the cards say so.** CTRM has no priority field\n    and `ContractSummary` carries none — so \"high priority\" is `Waiting over 7 days` from the\n    contract date, and \"expiring soon\" is `Shipping within 14 days` from the ship period. The hint\n    line under each is what stops the number being taken to the business as though it were a CTRM\n    concept. See `approval-metrics.ts`.\n\n    ⚠ **Rendered only with a scope** (the approver's queue, or a trade unit chosen), because without one the queue has not been asked\n    for and four zeroes would read as \"nothing to approve\" rather than \"nothing requested\".\n  -->\n  @if (hasScope()) {\n    <dl class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:lg:grid-cols-4\">\n      @for (metric of metrics(); track metric.label) {\n        <!--\n          `scoular-card` for the surface, so these match the panels around them rather than\n          inventing a second card style.\n        -->\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\n\n          <!--\n            ⚠ Colour is never the only carrier — the urgent cards are distinguished by their LABEL\n            as much as by the tint, because roughly 1 in 12 men has a colour vision deficiency\n            (02a §4). \"Waiting over 7 days\" says what it is with the colour removed.\n          -->\n          <dd\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\n            [class]=\"\n              metric.urgent\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\n                : 'cws:text-slate-900 cws:dark:text-white'\n            \"\n          >\n            {{ metric.value }}\n          </dd>\n\n          <!-- A second `<dd>`, not a `<p>`: a `<div>` in a `<dl>` holds only `<dt>`/`<dd>` (#764). -->\n          <dd class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</dd>\n        </div>\n      }\n    </dl>\n  }\n\n  <!--\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto`.\n\n    🔴 This mirrors the workspace grid's own row exactly (JFrisbie, 2026-09-10) — same order, same\n    `ml-auto` split, same components — so the controls do not move as a user goes between the two\n    screens. The filters are inline rather than behind a Filters dropdown because there are four of\n    them and they fit; the workspace hides its behind a button because it has a search box competing\n    for the same row.\n  -->\n  <!--\n    🔴 **The width goes on the LABEL, never on the field** — seventh instance of this repo's\n    unlayered-CSS trap.\n\n    `.scoular-form-input` is `@apply w-full`, and the design system compiles unlayered while Tailwind\n    utilities land in `@layer utilities` — so a `w-28` on the input silently loses and the field\n    fills its wrapper instead. Measured: every filter here rendered **193px** regardless of the class\n    on it, which is what wrapped the refresh/pager block onto a second line.\n\n    The wrapper carries no design-system class, so a utility on it is uncontested — which is the\n    recorded remedy: put the declaration where there is no contest rather than fighting the layer.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <!--\n    🔴 **The toolbar is a card now** (JFrisbie, 2026-09-14), which is the only part of the requested\n    elevation that was actually missing.\n\n    ⚠ The other two targets already had it, and adding a shadow to either would have been a no-op\n    dressed as a change: `.scoular-card` is `@apply rounded-lg border bg-white shadow-sm`, so the\n    summary cards above already carry it, and the grid's own wrapper declares the same three. Worth\n    stating because a Tailwind `shadow-sm` layered on top of `.scoular-card` would also LOSE — the\n    design system compiles unlayered and utilities land in `@layer utilities` — so it would have\n    looked deliberate and done nothing.\n\n    `p-3` rather than the design system's own `p-6`: this is a control strip, and card padding meant\n    for content pushes the search box away from the grid it filters.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n  -->\n  <cms-grid-toolbar>\n    <!--\n      One search box, replacing the Trader, Commodity and Customer boxes (JFrisbie, 2026-09-10).\n\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so all\n      three are still reachable, plus the eleven the boxes could not narrow on.\n\n      ⚠ **Applied CLIENT-SIDE, which is why this screen now asks for one large page.** A search\n      over rows we hold can only see the page it was given, so with a server page of 50 a term\n      matching a contract on page 3 would return nothing — and on a work queue “no matches” reads\n      as “nothing to approve”. See the query in the component.\n\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\n      move as a user goes between the screens.\n    -->\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        autocomplete=\"off\"\n        placeholder=\"Search every column\"\n        [value]=\"searchTerm()\"\n        (input)=\"onSearch($any($event.target).value)\"\n      />\n    </label>\n\n    <!--\n      Saved views and the filter builder, the same pair the workspace carries (JFrisbie, 2026-09-15).\n\n      ⚠ **Its own scope.** A workspace view has no meaning here — it would carry rules against columns\n      this grid does not render and match nothing, which on a work queue reads as \"nothing to\n      approve\". `SAVED_FILTER_SCOPES` declares all four keys together and a test asserts they differ.\n\n      🔴 The width is on this wrapper, not on the control: `.scoular-form-input` is `@apply w-full`\n      and the design system compiles unlayered, so a `w-*` on the control itself would lose.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [columnLayout]=\"columnChoice.layout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\n      (click)=\"builder.beginAdd()\"\n    >\n      + Add filter\n    </button>\n\n    <!--\n      🔴 **The Approver type dropdown that stood here is GONE (JFrisbie, 2026-09-17), and the\n      consequence is real rather than cosmetic.** The toolbar is now one standard set of controls on\n      every grid — search, view, add filter, clear sort, export, refresh, pager — and nothing else.\n\n      ⚠ What that costs, stated so nobody re-derives it from an empty space: `approverType` was a\n      **CTRM request parameter**, and this grid renders **no approver-type column**, so neither the\n      search nor a filter rule can express it. Primary-versus-Secondary narrowing is therefore\n      **unreachable from this screen** until a control returns. This is the same trade the status\n      dropdown made on the workspace, made deliberately and with the same reasoning on the record.\n\n      ✅ Nothing about the request plumbing was deleted: `ContractListQuery.approverType` still\n      exists and the API still accepts it, so restoring a control is a template change rather than a\n      rebuild.\n    -->\n\n    <!--\n      Clear sort, and it stays hidden until the queue is sorted some other way.\n\n      `defaultSorts` is what makes that true and is not decoration: this screen ARRIVES sorted\n      oldest-first, which is the queue's own meaning rather than anything the user did -- so a\n      button offering to undo it would be there from the moment they arrive, and pressing it would\n      discard the answer to \"what should I work on next\" rather than undoing a choice.\n    -->\n    <cms-clear-sort-button\n      [sorts]=\"sorts()\"\n      [defaultSorts]=\"defaultSorts\"\n      (clear)=\"onSortChange($event)\"\n    />\n\n    <!--\n      `ml-auto` puts refresh and the pager hard right, which is where the workspace keeps them. Note\n      this is the first element in the row with it, so everything before it stays left-aligned.\n    -->\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\n      <!-- Columns, beside the export it shapes, where Home has it (JFrisbie, 2026-10-23). -->\n      <cms-grid-column-menu\n        [fields]=\"columnChoice.fields()\"\n        [lockedKeys]=\"columnChoice.locked()\"\n        [keptIn]=\"columnChoice.keptIn()\"\n        [failure]=\"columnChoice.failure()\"\n        resetLabel=\"Show every column\"\n        (fieldsChange)=\"columnChoice.change($event)\"\n        (reset)=\"columnChoice.reset()\"\n      />\n      <!--\n        Export, the same control the workspace carries and the same component — see\n        `cms-grid-export` for why this is shared rather than the workspace's markup copied here.\n\n        ⚠ **Both scopes are cheap on this screen and the choice is still offered.** This queue fetches\n        one large page and slices it locally, so \"all pages\" is already in memory — but the question\n        it answers is \"what I am looking at\" versus \"everything the filter matched\", and those are\n        different files on a paged grid. Hiding the step where it happens to be cheap would make the\n        same control mean different things on different screens.\n      -->\n      <cms-grid-export\n        [columns]=\"columns\"\n        [visibleKeys]=\"columnChoice.shownKeys()\"\n        [pageRows]=\"rows()\"\n        [totalCount]=\"queue().length\"\n        [allRows]=\"exportAllRows\"\n        [filename]=\"exportFilename\"\n        [disabled]=\"!hasScope() || queue().length === 0\"\n        (failed)=\"exportError.set($event)\"\n      />\n\n      <cms-refresh-button\n        label=\"Refresh the approval queue\"\n        [busy]=\"isRefreshing()\"\n        [disabled]=\"!hasScope()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <!--\n        The top pager, so advancing a page does not mean scrolling past 50 rows first. Same\n        component as the footer's, not a copy.\n\n        🔴 **`currentPage()`, NEVER `query().page`.** This queue fetches ONE large server page and\n        slices it locally, so a search can see the whole matched set rather than one page of it —\n        which means `query().page` is pinned to `1` and is not the page the user is on.\n\n        Bound to `query().page` the pager read \"Page 1 of N\" forever, First and Previous were\n        permanently disabled, and Next emitted `1 + 1` — so page 2 was reachable and page 3 was not\n        (JFrisbie, 2026-09-14). ⚠ Note a single Next click still worked, which is why the one test\n        that existed here never caught it.\n\n        `currentPage()` is also the CLAMPED page, and the rows are sliced by the same value — so the\n        indicator and the grid cannot disagree after a search narrows the queue.\n      -->\n      <cms-pager\n        [page]=\"currentPage()\"\n        [totalPages]=\"totalPages()\"\n        position=\"top\"\n        (goTo)=\"onPage($event)\"\n      />\n    </div>\n  </cms-grid-toolbar>\n\n  <!--\n    The chips and the rule editor. Renders NOTHING when there are no rules and the editor is closed,\n    so it leaves no empty band above the queue. Its own \"+ Add filter\" button is suppressed because\n    the toolbar carries one — one owner for the editor's open state, as on the workspace.\n  -->\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onRulesChange($event)\"\n  />\n\n  <!--\n    ⚠ **Deliberately NOT in the notices panel**, which is for standing conditions of the screen. A\n    failed export is the outcome of something the user just did, and behind a collapsed panel it is a\n    message nobody sees — the same rule the workspace applies to its own export failure.\n  -->\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    #1159: what the last automatic re-read changed. Always in the page so a screen reader is already\n    listening when the text arrives; visually hidden while empty, and taken out of the flow by\n    `sr-only` so the empty region adds no gap.\n  -->\n  <p\n    data-testid=\"queue-poll-note\"\n    role=\"status\"\n    aria-live=\"polite\"\n    class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\"\n    [class.cws:sr-only]=\"pollNote() === ''\"\n  >{{ pollNote() }}</p>\n\n  <!--\n    ⚠ **The rejection-reason prompt and the decision outcomes used to sit here, and both moved with\n    the decision** (JFrisbie, 2026-09-14) rather than being kept beside a queue that no longer\n    decides anything.\n\n    BR-062's reason — the body of the denial email — is collected on the review screen, where the\n    contract being rejected is on screen while it is typed. A prompt here asked someone to justify\n    rejecting a contract they were looking at fourteen columns of.\n  -->\n\n  <!--\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\n\n    This screen used to render a `scoular-card` above the container and hide the container behind\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\n    read as a notice about the data rather than as the absence of any.\n\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\n    unit the request is certain to 422, which is why the screen never issues one.\n  -->\n  <cms-async-container\n    [data]=\"containerState()\"\n    [empty]=\"!hasScope() || rows().length === 0\"\n    [emptyMessage]=\"emptyMessage()\"\n    loadingLabel=\"Loading the approval queue\"\n    (retry)=\"retry()\"\n  >\n      <!--\n        ⚠ **`striped` is safe HERE specifically because this queue declares no `rowTone`.** A stripe\n        and a semantic tint are both a background on the `<tr>`, and together the tint stops meaning\n        anything — a shaded row could be \"rejected\" or just \"even\". The grid enforces the precedence\n        rather than trusting this binding, but a future tone on this queue would make the stripe the\n        wrong call rather than merely a redundant one.\n      -->\n      <cms-data-grid\n        [rows]=\"rows()\"\n        [columns]=\"columnChoice.shown()\"\n        label=\"Contracts awaiting approval\"\n        [columnMenu]=\"false\"\n        [striped]=\"true\"\n        [sorts]=\"sorts()\"\n        [trackBy]=\"trackByContract\"\n        [focusKey]=\"focusKey()\"\n        (sortChange)=\"onSortChange($event)\"\n        activateLabel=\"Review\"\n        (rowActivate)=\"onRowActivate($event)\"\n        (pageStep)=\"onPageStep($event)\"\n      />\n\n      <!--\n        The footer, matching the workspace grid: record count left, pager right. Same\n        `justify-between` row and the same `1–50 of 150` wording, so the two screens read alike.\n      -->\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n          <p>{{ rangeLabel() }}</p>\n\n          @if (!serverSorted() && sorts().length > 0 && moreThanOnePage()) {\n            <!--\n              The sort caveat, and it is NOT the one this screen carried first.\n\n              It used to read \"Sorted within this page\" and was guarded on the LOCAL page count.\n              That stopped being true the moment this queue started fetching one large page and\n              paging in process: the sort runs over the whole matched set and the slice happens\n              after it, so the ordering already spans every page on screen.\n\n              What survives is the real limit, and it is the one worth saying: CTRM sent a capped\n              set (CR-4 / #31), so \"the oldest contract\" means the oldest of what was READ. On a\n              work queue that is exactly the distinction an approver relies on -- which is why the\n              guard is now the server's own truncation rather than a local page boundary.\n\n              Retires itself when the server echoes `appliedSort`.\n\n              #1147: the queue reads every page now, so the guard is a page that did not arrive.\n              CTRM's own cap has the row-cap notice.\n            -->\n            <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n              Sorted across everything read -- not every page arrived, so this is not the whole\n              queue.\n            </p>\n          }\n        </div>\n\n        <cms-pager\n          [page]=\"currentPage()\"\n          [totalPages]=\"totalPages()\"\n          position=\"bottom\"\n          (goTo)=\"onPage($event)\"\n        />\n      </footer>\n  </cms-async-container>\n</section>\n"
		}]
	}],
	ctorParameters: () => []
});
function pollNoteFor(arrived, left) {
	return [...arrived > 0 ? [`${arrived} new ${arrived === 1 ? "contract" : "contracts"} awaiting approval.`] : [], ...left > 0 ? [`${left} ${left === 1 ? "contract" : "contracts"} left the queue.`] : []].join(" ");
}
function sameValues(left, right) {
	const a = left;
	const b = right;
	return [.../* @__PURE__ */ new Set([...Object.keys(a), ...Object.keys(b)])].every((key) => Object.is(a[key], b[key]));
}
function emptyPage(query) {
	return {
		rows: [],
		totalCount: 0,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: 1,
		dataOrigin: "Simulated",
		filteredInProcess: false,
		rowCapReached: null,
		rowCap: null,
		warnings: []
	};
}
const INLINE_TYPES = /* @__PURE__ */ new Set([
	"application/pdf",
	"image/png",
	"image/jpeg",
	"image/gif"
]);
function newestDraft(documents) {
	const entry = (document) => {
		const parsed = /^\d+$/.test(document.documentEntry) ? Number(document.documentEntry) : -1;
		return Number.isFinite(parsed) ? parsed : -1;
	};
	return [...documents].sort((left, right) => {
		const a = left.createdStamp ?? "";
		const b = right.createdStamp ?? "";
		return a === b ? entry(right) - entry(left) : a < b ? 1 : -1;
	})[0] ?? null;
}
var ApprovalDraftDocumentComponent = class ApprovalDraftDocumentComponent {
	source = inject(CONTRACT_DOCUMENTS_SOURCE, { optional: true });
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	state = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	viewer = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "viewer" }] : /* istanbul ignore next */ []);
	requested = false;
	rechecks = 0;
	listSubscription = null;
	requestSubscription = null;
	timerSubscription = null;
	contentSubscription = null;
	frame = viewChild("draftFrame", ...ngDevMode ? [{ debugName: "frame" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			this.contractNumber();
			untracked(() => this.start());
		});
		afterRenderEffect(() => {
			const state = this.viewer();
			const frame = this.frame()?.nativeElement;
			if (frame !== void 0 && state.status === "open" && state.url.startsWith("blob:") && frame.src !== state.url) frame.src = state.url;
		});
		inject(DestroyRef).onDestroy(() => {
			this.stop();
			this.contentSubscription?.unsubscribe();
			this.revoke(this.viewer());
		});
	}
	checkAgain() {
		this.rechecks = 0;
		this.state.set({ status: "loading" });
		this.read();
	}
	dismissProblem() {
		this.setViewer({ status: "idle" });
		this.state.set({ status: "dismissed" });
	}
	download() {
		const viewer = this.viewer();
		if (viewer.status === "open" || viewer.status === "downloadOnly") {
			const pdf = viewer.blob.type.toLowerCase().startsWith("application/pdf");
			downloadBlob(`Contract ${this.contractNumber().trim()} draft${pdf ? ".pdf" : ""}`, viewer.blob);
		}
	}
	print() {
		this.frame()?.nativeElement.contentWindow?.print();
	}
	start() {
		this.stop();
		this.requested = false;
		this.rechecks = 0;
		this.setViewer({ status: "idle" });
		this.state.set({ status: "loading" });
		if (this.source === null || this.contractNumber().trim() === "") {
			this.state.set({ status: "notOffered" });
			return;
		}
		this.read();
	}
	stop() {
		this.listSubscription?.unsubscribe();
		this.requestSubscription?.unsubscribe();
		this.timerSubscription?.unsubscribe();
		this.timerSubscription = null;
	}
	read() {
		this.listSubscription?.unsubscribe();
		this.listSubscription = this.source.list(this.contractNumber().trim()).subscribe((read) => this.onList(read));
	}
	onList(read) {
		if (read.kind === "refused") {
			this.state.set({
				status: "problem",
				outcome: mutationFailed({ message: read.detail }),
				retry: false
			});
			return;
		}
		if (read.kind === "failed") {
			this.state.set({
				status: "problem",
				outcome: mutationFailed({
					message: read.message,
					correlationId: read.correlationId
				}),
				retry: true
			});
			return;
		}
		const drafts = read.response.documents.filter((document) => document.role === "draft");
		const newest = newestDraft(drafts);
		const available = newestDraft(drafts.filter((document) => document.status === "available"));
		if (newest !== null && newest.status === "available") this.show(newest.documentEntry, newest.createdStamp);
		else if (drafts.some((document) => document.status === "pending")) this.recheck();
		else if (available !== null) this.show(available.documentEntry, available.createdStamp);
		else if (drafts.every((document) => document.status === "notStored")) {
			if (this.requested) this.recheck();
			else this.request();
		} else this.state.set({ status: "cannotOpen" });
	}
	request() {
		if (this.source?.requestDraft === void 0) {
			this.state.set({ status: "notBuilt" });
			return;
		}
		this.requested = true;
		this.state.set({
			status: "preparing",
			exhausted: false
		});
		this.requestSubscription = this.source.requestDraft(this.contractNumber().trim()).subscribe((answer) => this.onRequest(answer));
	}
	onRequest(answer) {
		switch (answer.kind) {
			case "requested":
				if (answer.requested === "Ready" && answer.draft?.status === "available") this.show(answer.draft.documentEntry, answer.draft.createdStamp);
				else this.recheck();
				break;
			case "notBuilt":
				this.state.set({ status: "notBuilt" });
				break;
			case "refused":
				this.state.set({
					status: "problem",
					outcome: mutationFailed({
						message: answer.detail,
						correlationId: answer.correlationId
					}),
					retry: false
				});
				break;
			case "failed": this.state.set({
				status: "problem",
				outcome: mutationFailed({
					message: answer.message,
					correlationId: answer.correlationId
				}),
				retry: true
			});
		}
	}
	recheck() {
		if (this.rechecks >= 24) {
			this.state.set({
				status: "preparing",
				exhausted: true
			});
			return;
		}
		this.state.set({
			status: "preparing",
			exhausted: false
		});
		this.timerSubscription?.unsubscribe();
		this.timerSubscription = timer(5e3).subscribe(() => {
			this.rechecks++;
			this.read();
		});
	}
	show(entry, createdStamp) {
		this.state.set({
			status: "shown",
			entry,
			createdStamp
		});
		this.contentSubscription?.unsubscribe();
		this.setViewer({ status: "loading" });
		this.contentSubscription = this.source.content(this.contractNumber().trim(), entry).subscribe((content) => {
			switch (content.kind) {
				case "done": {
					const type = content.blob.type.split(";")[0].trim().toLowerCase();
					this.setViewer(INLINE_TYPES.has(type) ? {
						status: "open",
						url: URL.createObjectURL(content.blob),
						blob: content.blob
					} : {
						status: "downloadOnly",
						blob: content.blob
					});
					break;
				}
				case "unavailable":
					this.setViewer({
						status: "unavailable",
						reason: content.reason
					});
					break;
				case "refused":
					this.setViewer({
						status: "problem",
						outcome: mutationFailed({
							message: content.detail,
							correlationId: content.correlationId
						})
					});
					break;
				case "failed": this.setViewer({
					status: "problem",
					outcome: mutationFailed({
						message: content.message,
						correlationId: content.correlationId
					})
				});
			}
		});
	}
	setViewer(next) {
		const current = this.viewer();
		if (current.status === "open" && (next.status !== "open" || next.url !== current.url)) this.revoke(current);
		this.viewer.set(next);
	}
	revoke(state) {
		if (state.status === "open") URL.revokeObjectURL(state.url);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ApprovalDraftDocumentComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ApprovalDraftDocumentComponent,
		isStandalone: true,
		selector: "cms-approval-draft-document",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		viewQueries: [{
			propertyName: "frame",
			first: true,
			predicate: ["draftFrame"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<!--\n  #1086: the contract's draft document. Every state says something; none renders an empty frame,\n  which would read as a contract with no content.\n-->\n<div data-testid=\"draft-document\">\n  @switch (state().status) {\n    @case ('loading') {\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the contract document…</p>\n    }\n\n    @case ('preparing') {\n      <div\n        class=\"cws:flex cws:min-h-48 cws:flex-col cws:items-center cws:justify-center cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-6 cws:text-center cws:dark:border-slate-600\"\n        role=\"status\"\n        data-testid=\"draft-preparing\"\n      >\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">Preparing the contract document…</p>\n        @if (state(); as current) {\n          @if (current.status === 'preparing' && current.exhausted) {\n            <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"draft-recheck-stopped\">\n              CTRM is still preparing it, so this screen has stopped checking. Check again in a moment;\n              that reads the list again and does not ask CTRM for another draft.\n            </p>\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"checkAgain()\">Check again</button>\n          } @else {\n            <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              CTRM is generating the draft. This screen checks again every few seconds.\n            </p>\n          }\n        }\n      </div>\n    }\n\n    @case ('shown') {\n      @if (state(); as current) {\n        @if (current.status === 'shown') {\n          <div class=\"cws:mb-3 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n            <p class=\"cws:min-w-0 cws:flex-1 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\n              {{ current.createdStamp ? 'Draft, created ' + current.createdStamp : 'Draft' }}\n            </p>\n            @if (viewer().status === 'open') {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"print()\">Print</button>\n            }\n            @if (viewer().status === 'open' || viewer().status === 'downloadOnly') {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"download()\">Download</button>\n            }\n          </div>\n        }\n      }\n\n      @switch (viewer().status) {\n        @case ('loading') {\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the contract document…</p>\n        }\n        @case ('open') {\n          <!--\n            70vh in the single column. From `xl` the approval screen holds this card in view beside the\n            decision (sticky, top-4), so the frame takes the viewport less the card's own heading and\n            Print/Download row, the 1rem offset and the shortcut strip pinned at the bottom.\n          -->\n          <iframe\n            #draftFrame\n            class=\"cws:h-[70vh] cws:xl:h-[calc(100vh-13rem)] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700\"\n            title=\"Contract document (draft)\"\n            data-testid=\"draft-frame\"\n          ></iframe>\n        }\n        @case ('downloadOnly') {\n          <div class=\"scoular-alert scoular-alert-info\" data-testid=\"draft-download-only\">\n            <div class=\"scoular-alert-description\">This file can't be shown here. Use Download to open it.</div>\n          </div>\n        }\n        @case ('unavailable') {\n          @if (viewer(); as current) {\n            @if (current.status === 'unavailable') {\n              <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">{{ current.reason }}</p>\n            }\n          }\n        }\n        @case ('problem') {\n          @if (viewer(); as current) {\n            @if (current.status === 'problem') {\n              <cms-status-message [outcome]=\"current.outcome\" (dismissed)=\"dismissProblem()\" />\n            }\n          }\n        }\n      }\n    }\n\n    @case ('notBuilt') {\n      <!-- A bare 404 from the draft route: this API predates it. Honest text, no error banner. -->\n      <div\n        class=\"cws:flex cws:min-h-48 cws:flex-col cws:items-center cws:justify-center cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-6 cws:text-center cws:dark:border-slate-600\"\n        role=\"status\"\n        data-testid=\"draft-not-built\"\n      >\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\n          The contract document can't be prepared here yet\n        </p>\n        <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          This environment cannot ask CTRM for the draft. Read the contract on the Contract Portal\n          before approving.\n        </p>\n      </div>\n    }\n\n    @case ('cannotOpen') {\n      <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"draft-cannot-open\">\n        CTRM lists this contract's draft document, but it can no longer be opened. Read the contract on\n        the Contract Portal before approving.\n      </p>\n    }\n\n    @case ('problem') {\n      @if (state(); as current) {\n        @if (current.status === 'problem') {\n          <cms-status-message [outcome]=\"current.outcome\" (dismissed)=\"dismissProblem()\">\n            @if (current.retry) {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"checkAgain()\">Try again</button>\n            }\n          </cms-status-message>\n        }\n      }\n    }\n\n    @case ('dismissed') {\n      <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"draft-dismissed\">\n        The contract document is not shown.\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1\" (click)=\"checkAgain()\">Try again</button>\n      </p>\n    }\n\n    @case ('notOffered') {\n      <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"draft-not-offered\">\n        The contract document is not offered here. Read the contract on the Contract Portal before\n        approving.\n      </p>\n    }\n  }\n</div>\n",
		dependencies: [{
			kind: "component",
			type: StatusMessageComponent,
			selector: "cms-status-message",
			inputs: ["outcome", "dismissMs"],
			outputs: ["dismissed"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ApprovalDraftDocumentComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-approval-draft-document",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [StatusMessageComponent],
			template: "<!--\n  #1086: the contract's draft document. Every state says something; none renders an empty frame,\n  which would read as a contract with no content.\n-->\n<div data-testid=\"draft-document\">\n  @switch (state().status) {\n    @case ('loading') {\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading the contract document…</p>\n    }\n\n    @case ('preparing') {\n      <div\n        class=\"cws:flex cws:min-h-48 cws:flex-col cws:items-center cws:justify-center cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-6 cws:text-center cws:dark:border-slate-600\"\n        role=\"status\"\n        data-testid=\"draft-preparing\"\n      >\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">Preparing the contract document…</p>\n        @if (state(); as current) {\n          @if (current.status === 'preparing' && current.exhausted) {\n            <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"draft-recheck-stopped\">\n              CTRM is still preparing it, so this screen has stopped checking. Check again in a moment;\n              that reads the list again and does not ask CTRM for another draft.\n            </p>\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"checkAgain()\">Check again</button>\n          } @else {\n            <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              CTRM is generating the draft. This screen checks again every few seconds.\n            </p>\n          }\n        }\n      </div>\n    }\n\n    @case ('shown') {\n      @if (state(); as current) {\n        @if (current.status === 'shown') {\n          <div class=\"cws:mb-3 cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n            <p class=\"cws:min-w-0 cws:flex-1 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\n              {{ current.createdStamp ? 'Draft, created ' + current.createdStamp : 'Draft' }}\n            </p>\n            @if (viewer().status === 'open') {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"print()\">Print</button>\n            }\n            @if (viewer().status === 'open' || viewer().status === 'downloadOnly') {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"download()\">Download</button>\n            }\n          </div>\n        }\n      }\n\n      @switch (viewer().status) {\n        @case ('loading') {\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Opening the contract document…</p>\n        }\n        @case ('open') {\n          <!--\n            70vh in the single column. From `xl` the approval screen holds this card in view beside the\n            decision (sticky, top-4), so the frame takes the viewport less the card's own heading and\n            Print/Download row, the 1rem offset and the shortcut strip pinned at the bottom.\n          -->\n          <iframe\n            #draftFrame\n            class=\"cws:h-[70vh] cws:xl:h-[calc(100vh-13rem)] cws:w-full cws:rounded-md cws:border cws:border-slate-200 cws:dark:border-slate-700\"\n            title=\"Contract document (draft)\"\n            data-testid=\"draft-frame\"\n          ></iframe>\n        }\n        @case ('downloadOnly') {\n          <div class=\"scoular-alert scoular-alert-info\" data-testid=\"draft-download-only\">\n            <div class=\"scoular-alert-description\">This file can't be shown here. Use Download to open it.</div>\n          </div>\n        }\n        @case ('unavailable') {\n          @if (viewer(); as current) {\n            @if (current.status === 'unavailable') {\n              <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">{{ current.reason }}</p>\n            }\n          }\n        }\n        @case ('problem') {\n          @if (viewer(); as current) {\n            @if (current.status === 'problem') {\n              <cms-status-message [outcome]=\"current.outcome\" (dismissed)=\"dismissProblem()\" />\n            }\n          }\n        }\n      }\n    }\n\n    @case ('notBuilt') {\n      <!-- A bare 404 from the draft route: this API predates it. Honest text, no error banner. -->\n      <div\n        class=\"cws:flex cws:min-h-48 cws:flex-col cws:items-center cws:justify-center cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-6 cws:text-center cws:dark:border-slate-600\"\n        role=\"status\"\n        data-testid=\"draft-not-built\"\n      >\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\n          The contract document can't be prepared here yet\n        </p>\n        <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          This environment cannot ask CTRM for the draft. Read the contract on the Contract Portal\n          before approving.\n        </p>\n      </div>\n    }\n\n    @case ('cannotOpen') {\n      <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"draft-cannot-open\">\n        CTRM lists this contract's draft document, but it can no longer be opened. Read the contract on\n        the Contract Portal before approving.\n      </p>\n    }\n\n    @case ('problem') {\n      @if (state(); as current) {\n        @if (current.status === 'problem') {\n          <cms-status-message [outcome]=\"current.outcome\" (dismissed)=\"dismissProblem()\">\n            @if (current.retry) {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\" (click)=\"checkAgain()\">Try again</button>\n            }\n          </cms-status-message>\n        }\n      }\n    }\n\n    @case ('dismissed') {\n      <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"draft-dismissed\">\n        The contract document is not shown.\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1\" (click)=\"checkAgain()\">Try again</button>\n      </p>\n    }\n\n    @case ('notOffered') {\n      <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"draft-not-offered\">\n        The contract document is not offered here. Read the contract on the Contract Portal before\n        approving.\n      </p>\n    }\n  }\n</div>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}],
		frame: [{
			type: i0.ViewChild,
			args: ["draftFrame", { isSignal: true }]
		}]
	}
});
const DEFAULT_EMAIL_MESSAGE = "Please sign and return the attached contract.";
function recipientsTooLong(error) {
	const body = error?.error;
	if (body?.type !== APPROVAL_RECIPIENTS_TOO_LONG) return null;
	const text = (value) => typeof value === "string" ? value.trim() : "";
	return [text(body.title), text(body.detail)].filter((part) => part !== "").join(" ") || "These recipients do not fit in one approval. Remove one and approve again. Nothing was sent.";
}
var ApprovalDetailPageComponent = class ApprovalDetailPageComponent {
	contracts = inject(APPROVAL_CONTRACT_SOURCE);
	approvals = inject(APPROVAL_ACTION_SOURCE);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	returnTo = this.route.snapshot.queryParamMap.get("returnTo");
	returnParams = computed(() => returnParamsAt(this.returnTo, this.contractNumber(), this.journey.position()), ...ngDevMode ? [{ debugName: "returnParams" }] : /* istanbul ignore next */ []);
	recordLinkParams = computed(() => ({
		[RECORD_ORIGIN_PARAM]: "approvals",
		...this.returnTo === null ? {} : { returnTo: this.returnTo }
	}), ...ngDevMode ? [{ debugName: "recordLinkParams" }] : /* istanbul ignore next */ []);
	origin = computed(() => recordOrigin(this.originKey(), "approvals"), ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	originKey = computed(() => recordOriginKey(this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM), "approvals"), ...ngDevMode ? [{ debugName: "originKey" }] : /* istanbul ignore next */ []);
	originIntent = computed(() => ({
		kind: "origin",
		origin: this.originKey(),
		params: this.returnParams()
	}), ...ngDevMode ? [{ debugName: "originIntent" }] : /* istanbul ignore next */ []);
	recordIntent = computed(() => ({
		kind: "contract",
		contractNumber: this.contractNumber(),
		params: this.recordLinkParams()
	}), ...ngDevMode ? [{ debugName: "recordIntent" }] : /* istanbul ignore next */ []);
	recordHref = computed(() => this.hostContext.hrefFor(this.recordIntent()), ...ngDevMode ? [{ debugName: "recordHref" }] : /* istanbul ignore next */ []);
	follow(event, intent) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(intent);
	}
	followRecord(event) {
		this.follow(event, this.recordIntent());
	}
	crumbs = computed(() => {
		const intent = this.originIntent();
		return [{
			label: this.origin().label,
			path: this.origin().path,
			link: {
				href: this.hostContext.hrefFor(intent),
				follow: (event) => this.follow(event, intent)
			}
		}];
	}, ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	tradeUnitLabel = injectTradeUnitLabel();
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	settledAttempt = signal(-1, ...ngDevMode ? [{ debugName: "settledAttempt" }] : /* istanbul ignore next */ []);
	loaded = toSignal(toObservable(computed(() => ({
		number: this.contractNumber(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ number, attempt }) => this.contracts.get(number).pipe(tap((state) => {
		if (state.status === "loaded") this.settledAttempt.set(attempt);
	})))), { initialValue: remoteLoading() });
	containerState = computed(() => this.loaded(), ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	contract = computed(() => {
		const state = this.loaded();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "contract" }] : /* istanbul ignore next */ []);
	header = computed(() => this.contract()?.header ?? null, ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	customerName = computed(() => {
		const name = customerDisplayName(this.header()?.customerName, null);
		return name === "" ? null : name;
	}, ...ngDevMode ? [{ debugName: "customerName" }] : /* istanbul ignore next */ []);
	customerFor(row) {
		return customerDisplayName(row.customerName, row.customerId, "—");
	}
	codeAndDescription(code, description) {
		return codeAndDescription(code, description, "—");
	}
	isSimulated = computed(() => this.contract()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.contract()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => this.permissions.canSeeSystemNotices?.() ? [
		...this.ecmSimulated() ? ["E-signature routing is simulated"] : [],
		...this.isSimulated() ? ["Simulated details, not read from CTRM"] : [],
		...this.warnings()
	] : [], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	isRefreshing = computed(() => this.loaded().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	canApprove = computed(() => this.permissions.canApproveContracts(), ...ngDevMode ? [{ debugName: "canApprove" }] : /* istanbul ignore next */ []);
	writeRefusal = computed(() => this.permissions.writeRefusal?.()?.message ?? null, ...ngDevMode ? [{ debugName: "writeRefusal" }] : /* istanbul ignore next */ []);
	confirmed = signal(false, ...ngDevMode ? [{ debugName: "confirmed" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	recorded = computed(() => {
		const result = this.outcome();
		return result !== null && result.origin !== "Simulated" ? mutationSucceeded(this.recordedSentence(result), { stays: true }) : null;
	}, ...ngDevMode ? [{ debugName: "recorded" }] : /* istanbul ignore next */ []);
	recordedSentence(result) {
		const number = result.contractNumber;
		if (result.decision === "Rejected") return `${result.decision} — ${result.origin}. Contract ${number} is rejected.`;
		const recipients = result.recipients ?? [];
		const sentTo = recipients.length === 0 ? "" : result.esign === true ? ` It is sent for e-signature to ${recipients.join(", ")}.` : ` It is sent to ${recipients.join(", ")}.`;
		return `${result.decision} — ${result.origin}. Contract ${number} is approved: reading it back from CTRM shows it approved.${sentTo}`;
	}
	failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	isDeciding = signal(false, ...ngDevMode ? [{ debugName: "isDeciding" }] : /* istanbul ignore next */ []);
	rejectOpen = signal(false, ...ngDevMode ? [{ debugName: "rejectOpen" }] : /* istanbul ignore next */ []);
	rejectReason = signal("", ...ngDevMode ? [{ debugName: "rejectReason" }] : /* istanbul ignore next */ []);
	recipients = computed(() => [], ...ngDevMode ? [{ debugName: "recipients" }] : /* istanbul ignore next */ []);
	ecmRecipients = signal([], ...ngDevMode ? [{ debugName: "ecmRecipients" }] : /* istanbul ignore next */ []);
	ecmCopies = signal(1, ...ngDevMode ? [{ debugName: "ecmCopies" }] : /* istanbul ignore next */ []);
	ecmMessage = signal(DEFAULT_EMAIL_MESSAGE, ...ngDevMode ? [{ debugName: "ecmMessage" }] : /* istanbul ignore next */ []);
	routing = toSignal(toObservable(this.contractNumber).pipe(switchMap((number) => this.approvals.ecmRouting(number).pipe(startWith(null)))), { initialValue: null });
	seedRecipients = effect(() => {
		const routing = this.routing();
		if (routing !== null) this.ecmRecipients.set(routing.recipients.slice(0, MAX_ECM_RECIPIENTS));
	}, ...ngDevMode ? [{ debugName: "seedRecipients" }] : /* istanbul ignore next */ []);
	ecmEsign = computed(() => this.routing()?.esign === true, ...ngDevMode ? [{ debugName: "ecmEsign" }] : /* istanbul ignore next */ []);
	ecmSimulated = computed(() => this.routing()?.origin === "Simulated", ...ngDevMode ? [{ debugName: "ecmSimulated" }] : /* istanbul ignore next */ []);
	ecmCase = computed(() => {
		const routing = this.routing();
		if (routing === null) return "Checking e-signature routing…";
		if (routing.esign === null) return routing.reason ?? "E-signature routing is unknown, so this contract cannot be approved here.";
		return routing.esign ? "This customer is set up for e-signature, so the distribution cannot be changed here." : "This customer is not set up for e-signature. The contract goes to the recipients listed here.";
	}, ...ngDevMode ? [{ debugName: "ecmCase" }] : /* istanbul ignore next */ []);
	ecmRefusal = computed(() => {
		const routing = this.routing();
		if (routing === null || routing.esign === null) return this.ecmCase();
		if (this.ecmRecipients().length === 0) return "Add at least one recipient. An approval with no distribution lets CTRM choose who receives the contract.";
		return null;
	}, ...ngDevMode ? [{ debugName: "ecmRefusal" }] : /* istanbul ignore next */ []);
	maxRecipients = MAX_ECM_RECIPIENTS;
	recipientDraft = signal("", ...ngDevMode ? [{ debugName: "recipientDraft" }] : /* istanbul ignore next */ []);
	journey = injectRecordJourney({
		kind: "approval",
		key: () => this.contractNumber(),
		held: () => this.isDeciding(),
		origin: () => this.originKey(),
		open: (contractNumber, state) => this.hostContext.navigate({
			kind: "review",
			origin: "approvals",
			contractNumber,
			params: {
				...this.fromParam === null ? {} : { [RECORD_ORIGIN_PARAM]: this.fromParam },
				...this.returnTo === null ? {} : { returnTo: this.returnTo }
			},
			state
		})
	});
	fromParam = this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM);
	approvedNumber = signal(null, ...ngDevMode ? [{ debugName: "approvedNumber" }] : /* istanbul ignore next */ []);
	locked = computed(() => this.approvedNumber() === this.contractNumber(), ...ngDevMode ? [{ debugName: "locked" }] : /* istanbul ignore next */ []);
	unconfirmedNumber = signal(null, ...ngDevMode ? [{ debugName: "unconfirmedNumber" }] : /* istanbul ignore next */ []);
	unconfirmedProblem = signal(null, ...ngDevMode ? [{ debugName: "unconfirmedProblem" }] : /* istanbul ignore next */ []);
	unconfirmed = computed(() => this.unconfirmedNumber() === this.contractNumber(), ...ngDevMode ? [{ debugName: "unconfirmed" }] : /* istanbul ignore next */ []);
	rereadAttempt = signal(null, ...ngDevMode ? [{ debugName: "rereadAttempt" }] : /* istanbul ignore next */ []);
	acknowledged = computed(() => this.unconfirmed() && this.rereadAttempt() !== null, ...ngDevMode ? [{ debugName: "acknowledged" }] : /* istanbul ignore next */ []);
	rereadSettled = computed(() => {
		const asked = this.rereadAttempt();
		return this.acknowledged() && asked !== null && this.settledAttempt() >= asked;
	}, ...ngDevMode ? [{ debugName: "rereadSettled" }] : /* istanbul ignore next */ []);
	rereadApproval = computed(() => {
		const header = this.header();
		return this.rereadSettled() && header !== null ? confirmationProgress(header)[0] : null;
	}, ...ngDevMode ? [{ debugName: "rereadApproval" }] : /* istanbul ignore next */ []);
	unconfirmedHold = computed(() => this.unconfirmed() && !this.rereadSettled(), ...ngDevMode ? [{ debugName: "unconfirmedHold" }] : /* istanbul ignore next */ []);
	settleFromReread = effect(() => {
		if (this.rereadApproval()?.state === "complete" && !this.locked()) untracked(() => {
			this.approvedNumber.set(this.contractNumber());
			this.confirmed.set(false);
			this.journey.leave();
		});
	}, ...ngDevMode ? [{ debugName: "settleFromReread" }] : /* istanbul ignore next */ []);
	acknowledgeUnconfirmed() {
		if (!this.unconfirmed() || this.rereadAttempt() !== null) return;
		this.rereadAttempt.set(this.attempt() + 1);
		this.refresh();
	}
	nextAfterDecision = computed(() => this.outcome() === null && !this.locked() ? null : this.journey.position().next, ...ngDevMode ? [{ debugName: "nextAfterDecision" }] : /* istanbul ignore next */ []);
	backToQueueAfterDecision = computed(() => this.locked() && this.journey.position().next === null, ...ngDevMode ? [{ debugName: "backToQueueAfterDecision" }] : /* istanbul ignore next */ []);
	backToQueue() {
		this.returnToQueue();
	}
	lastContract = null;
	resetForContract = effect(() => {
		const contractNumber = this.contractNumber();
		if (this.lastContract !== null && this.lastContract !== contractNumber) untracked(() => {
			this.confirmed.set(false);
			this.outcome.set(null);
			this.failure.set(null);
			this.recipientsFailure.set(null);
			this.rejectOpen.set(false);
			this.rejectReason.set("");
			this.ecmCopies.set(1);
			this.ecmMessage.set(DEFAULT_EMAIL_MESSAGE);
			this.recipientDraft.set("");
			this.unconfirmedNumber.set(null);
			this.unconfirmedProblem.set(null);
			this.rereadAttempt.set(null);
		});
		this.lastContract = contractNumber;
	}, ...ngDevMode ? [{ debugName: "resetForContract" }] : /* istanbul ignore next */ []);
	recipientRefusal = computed(() => {
		if (this.ecmRecipients().length >= MAX_ECM_RECIPIENTS) return `At most ${MAX_ECM_RECIPIENTS} recipients go on one approval, so no more can be added. Remove one first.`;
		const draft = this.recipientDraft().trim();
		if (draft !== "" && this.ecmRecipients().includes(draft)) return "That address is already on the list.";
		return null;
	}, ...ngDevMode ? [{ debugName: "recipientRefusal" }] : /* istanbul ignore next */ []);
	canAddRecipient = computed(() => this.recipientDraft().trim() !== "" && this.recipientRefusal() === null, ...ngDevMode ? [{ debugName: "canAddRecipient" }] : /* istanbul ignore next */ []);
	onRecipientDraft(value) {
		this.recipientDraft.set(value);
	}
	addRecipient() {
		if (!this.canAddRecipient()) return;
		this.ecmRecipients.update((list) => [...list, this.recipientDraft().trim()]);
		this.recipientDraft.set("");
	}
	removeRecipient(address) {
		this.ecmRecipients.update((list) => list.filter((entry) => entry !== address));
		this.recipientsFailure.set(null);
	}
	recipientsFailure = signal(null, ...ngDevMode ? [{ debugName: "recipientsFailure" }] : /* istanbul ignore next */ []);
	onEcmMessage(value) {
		this.ecmMessage.set(value);
	}
	onEcmCopies(value) {
		const parsed = Number.parseInt(value, 10);
		this.ecmCopies.set(Number.isFinite(parsed) && parsed > 0 ? parsed : 1);
	}
	ecmEditable = computed(() => this.routing()?.esign === false && this.canApprove() && !this.locked(), ...ngDevMode ? [{ debugName: "ecmEditable" }] : /* istanbul ignore next */ []);
	ecmRequest() {
		return {
			distribution_entry: this.ecmRecipients(),
			copies: this.ecmCopies(),
			email_message: this.ecmMessage(),
			esign: this.ecmEsign(),
			esign_override: null
		};
	}
	canSubmit = computed(() => this.canApprove() && this.writeRefusal() === null && this.ecmRefusal() === null && this.confirmed() && !this.isDeciding() && !this.unconfirmedHold() && !this.locked(), ...ngDevMode ? [{ debugName: "canSubmit" }] : /* istanbul ignore next */ []);
	refresh() {
		this.attempt.update((value) => value + 1);
	}
	retry() {
		this.refresh();
	}
	onEscape(event) {
		if (event.defaultPrevented) return;
		this.returnToQueue();
	}
	returnToQueue() {
		this.hostContext.navigate(this.originIntent());
	}
	openReject() {
		this.rejectOpen.set(true);
	}
	cancelReject() {
		this.rejectOpen.set(false);
		this.rejectReason.set("");
	}
	approve() {
		if (!this.canSubmit()) return;
		this.submit("Approved");
	}
	reject() {
		if (this.rejectReason().trim() === "" || this.isDeciding() || this.locked()) return;
		this.submit("Rejected", this.rejectReason().trim());
	}
	submit(decision, reason) {
		this.isDeciding.set(true);
		this.outcome.set(null);
		this.failure.set(null);
		this.recipientsFailure.set(null);
		const acknowledging = decision === "Approved" && this.unconfirmed();
		(decision === "Approved" ? acknowledging ? this.approvals.approve(this.contractNumber(), this.ecmRequest(), { acknowledgeUnconfirmedAttempt: true }) : this.approvals.approve(this.contractNumber(), this.ecmRequest()) : this.approvals.reject(this.contractNumber(), reason ?? "")).subscribe({
			next: (result) => {
				this.isDeciding.set(false);
				this.outcome.set(result);
				this.rejectOpen.set(false);
				if (acknowledging) {
					this.unconfirmedNumber.set(null);
					this.unconfirmedProblem.set(null);
					this.rereadAttempt.set(null);
				}
				if (result.decision === "Approved") {
					this.approvedNumber.set(this.contractNumber());
					this.journey.leave();
				}
				this.confirmed.set(false);
			},
			error: (error) => {
				this.isDeciding.set(false);
				const tooLong = recipientsTooLong(error);
				if (tooLong !== null) {
					this.recipientsFailure.set(mutationFailed({
						message: tooLong,
						correlationId: correlationIdOf(error)
					}));
					return;
				}
				if (decision === "Approved" && isUnconfirmedApprovalAttempt(error)) {
					const body = error?.error;
					const text = (value) => typeof value === "string" && value.trim() !== "" ? value.trim() : null;
					this.unconfirmedNumber.set(this.contractNumber());
					this.unconfirmedProblem.set({
						detail: text(body?.detail),
						reference: text(body?.reference) ?? correlationIdOf(error)
					});
					this.rereadAttempt.set(null);
					this.confirmed.set(false);
					return;
				}
				const unconfirmed = unconfirmedWriterRefusalOf(error);
				this.failure.set(mutationFailed({
					message: unconfirmed?.detail ?? this.describeFailure(error, decision),
					correlationId: unconfirmed?.reference ?? correlationIdOf(error)
				}));
			}
		});
	}
	describeFailure(error, decision) {
		const contractNumber = this.contractNumber();
		if (error?.status === 404) {
			const noun = decision === "Approved" ? "approval" : "rejection";
			return `The ${noun} endpoint is not published by the API yet, so nothing was sent for ${contractNumber}. Complete this ${noun} on the green screen.`;
		}
		const detail = error?.error?.detail;
		if (typeof detail === "string" && detail.trim() !== "") return detail;
		return `We could not record that decision on ${contractNumber}. Nothing was changed.`;
	}
	onConfirmChange(checked) {
		this.confirmed.set(checked);
	}
	onRejectReason(value) {
		this.rejectReason.set(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ApprovalDetailPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ApprovalDetailPageComponent,
		isStandalone: true,
		selector: "cms-approval-detail-page",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: { "document:keydown.escape": "onEscape($event)" } },
		ngImport: i0,
		template: "<section class=\"cws:flex cws:flex-col cws:gap-4\">\n  <!--\n    The breadcrumb is the only way back, and it goes to the QUEUE rather than to history: this screen\n    is reachable from one place by design, so a generic \"back\" would be less specific than the truth.\n  -->\n  <!--\n    ⚠ **`queryParams` carries the queue's own state back** (JFrisbie, 2026-09-15) — its search, its\n    sort, the page it was on and the row that was opened. Without it the crumb *worked*, which is the\n    failure worth naming: an approver returned to an unfiltered page 1 with their place gone, and\n    nothing looked broken.\n\n    🔑 **Still a real anchor rather than a click handler**, which is what `returnParams` being an\n    object rather than a URL string buys: it keeps its `href`, so middle-click and open-in-new-tab\n    work and Tab reaches it. Escape navigates to the same place from the same computed.\n  -->\n  <!--\n    🔴 The same breadcrumb shape as the record screen, deliberately (JFrisbie, 2026-09-15).\n\n    This was a single `&lsaquo; Approvals` back-link while the record screen carried a full trail, so\n    two screens one click apart disagreed about where the user was. Matching them is the point: an\n    approver moves between these constantly, and a crumb that changes shape mid-journey reads as a\n    different application.\n\n    The first crumb is the screen you came FROM, so it says `Pricing` and returns there when a pricing\n    queue links in with `?from=pricing`, rather than always claiming Approvals.\n  -->\n  <!--\n    ⚠ **The markup moved to `cms-breadcrumb`; nothing about this trail changed.** It was already the\n    ARIA-correct version, and the shared component was extracted from the record screen's identical\n    copy — so this is the same DOM rendered from one definition instead of three.\n  -->\n  <cms-breadcrumb\n    cmsPageHeaderBreadcrumb\n    [crumbs]=\"crumbs()\"\n    [current]=\"contractNumber()\"\n    [context]=\"tradeUnitLabel()\"\n    [queryParams]=\"returnParams()\"\n  />\n\n  <!--\n    🔴 An h2, not the h1 this screen used to open with. The shell owns the page's only h1, so this\n    was the one screen giving the document two top-level headings -- and its section headings were\n    h2s, one level above every other screen's h3s.\n\n    ⚠ The customer name is bound as the description rather than left as its own paragraph, so it\n    truncates and spaces the same way every other screen's does.\n  -->\n  <cms-page-header\n    [title]=\"'Approve contract ' + contractNumber()\"\n    [description]=\"customerName()\"\n  >\n    @if (contract()?.version; as version) {\n      <!-- The record screen's chip: CTRM's version, not a CMS revision, and muted so it cannot be read as part of the key. -->\n      <span\n        cmsPageHeaderTitleSuffix\n        class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\n        title=\"CTRM contract version\"\n      >\n        v{{ version }}\n      </span>\n    }\n    <ng-container cmsPageHeaderActions>\n      <!--\n        ⚠ The SHARED control, not a hand-rolled button (JFrisbie, 2026-09-14). The first version of\n        this screen used a text button reading \"Refresh\" / \"Refreshing…\", which is a second refresh\n        affordance for the app to keep in step with — exactly the drift the component exists to\n        prevent, and it also loses the 36-vs-38px height correction the icon-only form needs.\n      -->\n      <cms-refresh-button\n        label=\"Refresh this contract\"\n        [busy]=\"isRefreshing()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <!--\n        🔴 No Skip (#1148). It returned to the queue, which the crumb and Escape do; the › beside the\n        crumb moves through the queue's filtered order, which is what the Portal's Skip did.\n      -->\n\n      <!--\n        🔴 **`from` and `returnTo` are passed on, and without them the journey breaks one hop later.**\n\n        The record screen picks its breadcrumb from `from` and defaults to the workspace — so this\n        link, bare, sent an approver queue → review → record and then offered them a crumb reading\n        \"Contracts\" that moved them to a different screen entirely. That is the exact failure\n        `record-origin.ts` was written for, reproduced by the one link that had not been given the\n        parameters.\n\n        ⚠ The record's crumb returns to the **queue**, not to this screen — `RecordOrigin` names\n        queues, not intermediate screens. That is the right destination (it is where the journey\n        started and where the state lives) and it is worth knowing rather than discovering.\n      -->\n      <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\n      <a\n        [attr.href]=\"recordHref()\"\n        (click)=\"followRecord($event)\"\n        class=\"scoular-btn scoular-btn-secondary\"\n      >\n        View full record\n      </a>\n      <!-- ‹ Record 3 of 150 ›, last of the record actions on every details screen (JFrisbie, 2026-10-26). -->\n      <cms-record-stepper [journey]=\"journey\" />\n    </ng-container>\n  </cms-page-header>\n\n  <cms-async-container [data]=\"containerState()\" (retry)=\"retry()\">\n    @if (header(); as row) {\n      <!--\n        🔴 **The spacing wrapper, and it is required rather than decorative** (JFrisbie, 2026-09-15,\n        from a screenshot).\n\n        Measured in Edge before it existed: **0px between every block on this screen** — notices\n        panel, terms, document, distribution and decision all touching — against a uniform **16px**\n        on the approvals queue and the contract record. The screen read as one undifferentiated slab.\n\n        🔑 **The cause is that the root's `gap-4` cannot reach these.** It applies between the root's\n        own children — the breadcrumb, the header and `cms-async-container` — and every block here is\n        *inside* that container, which projects `<ng-content />` **bare, with no wrapper and no\n        spacing of its own**. So the gap stopped at the container's edge, which is exactly where it\n        looked like it was working. ⚠ The record screen has carried its own `space-y-4` wrapper for\n        this reason all along; this screen simply never got one.\n\n        ⚠ **`flex flex-col gap-4` rather than the `space-y-4` used elsewhere, deliberately, and they\n        are visually identical at 16px.** `space-y-*` works by putting `margin-block-end` on each\n        child, and **a vertical margin has no effect on an inline box** — which is what silently ate\n        the notices panel's spacing a day earlier and needed `host: { class: 'block' }` to fix. `gap`\n        is a property of the container and applies whatever the children's display is, so a future\n        component dropped in here cannot lose its spacing the same way.\n      -->\n      <!--\n        🔴 **Two columns from `xl`: the contract document on the right, every other block on the left**\n        (JFrisbie, 2026-10-28), so the approver reads the document beside the decision rather than\n        scrolling between them. Below `xl` it is the single column it always was.\n\n        ⚠ **A grid with explicit placement, not two wrapper columns, deliberately.** The DOM order is\n        unchanged, so a narrow screen and the tab order still run terms → document → distribution →\n        decision, and nothing had to be re-ordered with CSS to get there.\n\n        🔑 **`repeat(5,auto) 1fr` is load-bearing: 5 is the number of LEFT blocks.** The document spans\n        every row (`row-[1/-1]`), and when it is taller than the left column the extra height goes to\n        the final `1fr` row; without that row it would be shared out between the left blocks and pull\n        them apart. Adding or removing a left block means changing the 5, and the spec says so.\n\n        The document is `sticky` with `self-start`, so it stays in view while the left column scrolls;\n        a grid item that stretched to its area would have nothing to stick within.\n      -->\n      <div\n        class=\"cws:flex cws:flex-col cws:gap-4 cws:xl:grid cws:xl:grid-cols-2 cws:xl:grid-rows-[repeat(5,auto)_1fr]\"\n      >\n        <!--\n          F6.5 — the approved → customer → broker progression, first on this screen because it is\n          the one where somebody commits. A stage lit here is read as work already done, so the\n          broker caution travels with the component rather than being restated in a template.\n        -->\n        <section\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:xl:col-start-1 cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\n        >\n          <h2 class=\"cws:mb-2 cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n            Confirmation status\n          </h2>\n          <cms-confirmation-progress [header]=\"row\" />\n        </section>\n\n        <!--\n        🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\n        queue this screen is reached from. It was two full-width banners plus one per server warning\n        above the contract terms — on a screen whose entire job is to show six facts and take a\n        decision, the caveats outweighed the content.\n\n        Every notice is still here and still true; what changed is that the screen opens with the\n        contract. ⚠ **The same test the queue applied: is it restated where it bites?** The decision\n        outcome says <strong>CTRM was not updated</strong> in the result itself, so the data-origin\n        caveat is not the only thing carrying that. Collapsing these without that would have been a\n        loss of safety rather than a tidy-up.\n      -->\n        <cms-notices-panel class=\"cws:xl:col-start-1\" [summaries]=\"noticeSummaries()\">\n          <!--\n          #1086: only while the e-sign routing is SIMULATED. Against the live API the routing comes\n          from ECM (GET …/approval/ecm) and the distribution panel states its case, so this caveat\n          would contradict it.\n        -->\n          @if (ecmSimulated()) {\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n              <div class=\"scoular-alert-title\">E-signature routing is simulated</div>\n              <div class=\"scoular-alert-description\">\n                The e-signature answer below is generated locally, not read from the e-signature\n                service. Approving here does not send the contract for signature.\n              </div>\n            </div>\n          }\n\n          @if (isSimulated()) {\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n              <div class=\"scoular-alert-title\">Simulated data</div>\n              <div class=\"scoular-alert-description\">\n                These contract details are generated locally, not read from CTRM.\n              </div>\n            </div>\n          }\n\n          @for (warning of warnings(); track warning) {\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\n            </div>\n          }\n        </cms-notices-panel>\n\n        <!--\n        The terms, read-only. Six facts rather than 111: the approver is confirming what they already\n        saw in the queue, and the full record is one click away in the header.\n      -->\n        <section class=\"scoular-card cws:p-4 cws:xl:col-start-1\">\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\n            Contract terms\n          </h3>\n\n          <dl class=\"cws:grid cws:grid-cols-1 cws:gap-x-6 cws:gap-y-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Customer</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ customerFor(row) }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</dt>\n              <!-- #1124: \"code, description\", either half alone when only one is known. -->\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ codeAndDescription(row.commodityCode, row.commodity) }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Quantity</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                <!--\n                ⚠ The unit is always rendered beside the number. A grain quantity with no unit is the\n                defect recorded when CTRM was found storing pounds while the API returns bushels.\n              -->\n                @if (row.quantity === null) {\n                  —\n                } @else {\n                  {{ row.quantity | number: '1.0-0' }} {{ row.quantityUom ?? '' }}\n                }\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Price</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ row.price === null ? '—' : (row.price | number: '1.4-4') }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Market zone</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ codeAndDescription(row.marketZone, row.marketZoneDescription) }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Trader</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ row.traderInitials ?? '—' }}\n              </dd>\n            </div>\n          </dl>\n        </section>\n\n        <!--\n        The document. This is the whole lower half of the Portal screen, and it is the thing an\n        approver is actually reading before deciding. From `xl` it is the right-hand column on its own,\n        held in view by `sticky top-4` while the left column scrolls.\n      -->\n        <section\n          class=\"scoular-card cws:p-4 cws:xl:sticky cws:xl:top-4 cws:xl:col-start-2 cws:xl:row-[1/-1] cws:xl:self-start\"\n        >\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\n            Contract document\n          </h3>\n\n          <!-- #1086: the newest draft, requested from CTRM only when none is listed, never while one is pending. -->\n          <cms-approval-draft-document [contractNumber]=\"contractNumber()\" />\n        </section>\n\n        <!--\n          F6.2 — the ECM panel, bound to the approval request under #492 (shape agreed on #469,\n          2026-10-06). E-sign and its recipients come from ECM's routing; the approver never sets\n          e-sign, and the distribution is never sent empty.\n\n          🔴 **At most five recipients, the server's limit (#1172), refused HERE before sending.**\n          Whether they fit is the server's to say: where CTRM takes them joined in one Char(100)\n          field (#1160), it answers 422 approval-recipients-too-long, shown beside the list.\n        -->\n        <section class=\"scoular-card cws:p-4 cws:xl:col-start-1\">\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\n            Send a copy to\n          </h3>\n\n          <!-- The case, always stated, as Contract Portal does (#492). -->\n          <p role=\"status\" class=\"cws:mb-3 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n            {{ ecmCase() }}\n          </p>\n\n          @if (ecmRecipients().length === 0) {\n            <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n              Nobody is on this contract's distribution list yet.\n            </p>\n          } @else {\n            <ul class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-1\">\n              @for (address of ecmRecipients(); track address) {\n                <li\n                  class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:rounded cws:border cws:border-slate-200 cws:px-2 cws:py-1 cws:text-sm cws:text-slate-800 cws:dark:border-slate-700 cws:dark:text-slate-100\"\n                >\n                  <span class=\"truncate\">{{ address }}</span>\n                  @if (ecmEditable()) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary cws:shrink-0 cws:px-2 cws:py-0.5 cws:text-xs\"\n                      (click)=\"removeRecipient(address)\"\n                    >\n                      Remove\n                    </button>\n                  }\n                </li>\n              }\n            </ul>\n          }\n\n          @if (ecmEditable()) {\n            <div class=\"cws:mt-2 cws:flex cws:items-start cws:gap-2\">\n              <label class=\"cws:flex-1\">\n                <span class=\"sr-only\">Recipient email address</span>\n                <input\n                  type=\"email\"\n                  class=\"scoular-form-input\"\n                  placeholder=\"name@example.com\"\n                  [value]=\"recipientDraft()\"\n                  [disabled]=\"ecmRecipients().length >= maxRecipients\"\n                  (input)=\"onRecipientDraft($any($event.target).value)\"\n                  (keydown.enter)=\"$event.preventDefault(); addRecipient()\"\n                />\n              </label>\n              <button\n                type=\"button\"\n                class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\n                [disabled]=\"!canAddRecipient()\"\n                (click)=\"addRecipient()\"\n              >\n                Add\n              </button>\n            </div>\n\n            @if (recipientRefusal(); as refusal) {\n              <!-- The reason at the control, not a greyed button with no explanation. -->\n              <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\n                {{ refusal }}\n              </p>\n            } @else {\n              <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                {{ ecmRecipients().length }} of {{ maxRecipients }} recipients.\n              </p>\n            }\n          }\n\n          <!--\n            #1172: the server's \"recipients too long\" refusal, beside the list it is about. Removing one\n            clears it; nothing was sent, so approving again is safe.\n          -->\n          <div class=\"cws:mt-2\">\n            <cms-status-message [outcome]=\"recipientsFailure()\" (dismissed)=\"recipientsFailure.set(null)\" />\n          </div>\n\n          <div class=\"cws:mt-3 cws:grid cws:gap-3 cws:sm:grid-cols-2\">\n            <label class=\"cws:block\">\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Copies</span>\n              <input\n                type=\"number\"\n                min=\"1\"\n                class=\"scoular-form-input cws:mt-1\"\n                [value]=\"ecmCopies()\"\n                [disabled]=\"!ecmEditable()\"\n                (input)=\"onEcmCopies($any($event.target).value)\"\n              />\n            </label>\n\n            <!--\n              🔴 No e-sign or override checkbox (#492). E-sign is ECM's answer, shown above; an\n              override is a reason only an authorised approver may give, and has no control until\n              CAPFLG3 and the ESOVR list are known.\n            -->\n          </div>\n\n          <div class=\"cws:mt-3\">\n            <label class=\"cws:block\">\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Message</span>\n              <textarea\n                rows=\"3\"\n                class=\"scoular-form-input cws:mt-1\"\n                [value]=\"ecmMessage()\"\n                [disabled]=\"!ecmEditable()\"\n                (input)=\"onEcmMessage($any($event.target).value)\"\n              ></textarea>\n            </label>\n          </div>\n\n          <!--\n            No printer row (#1275, requested by Hope). Portal printing was removed in 2025 and has no\n            replacement, so an approver is not shown a control they cannot use. This reverses #291,\n            which showed it disabled with its reason.\n          -->\n\n        </section>\n\n\n        <!-- The decision. -->\n        <section class=\"scoular-card cws:p-4 cws:xl:col-start-1\">\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">Decision</h3>\n\n          @if (!canApprove()) {\n            <!--\n            The Portal's \"You do NOT have authority to approve this contract\", stated as what the\n            account lacks. ⚠ Worded as OUR authority rather than CTRM's, because CTRM's per-location\n            approval authority is a separate check we cannot read — claiming to speak for it would be\n            a guess about someone else's rules.\n          -->\n            <p role=\"status\" class=\"cws:mb-3 cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n              You do not have authority to approve this contract. Approving needs the\n              <strong>Admin</strong> role on this application.\n            </p>\n          }\n\n          <!-- #803: a decision CTRM recorded, as a success. A simulated one keeps the warning below. -->\n          <div class=\"cws:mb-3\">\n            <cms-status-message [outcome]=\"recorded()\" (dismissed)=\"outcome.set(null)\" />\n          </div>\n\n          @if (outcome(); as result) {\n            @if (result.origin === 'Simulated') {\n            <div class=\"scoular-alert scoular-alert-warning cws:mb-3\" role=\"status\">\n              <div class=\"scoular-alert-title\">{{ result.decision }} — {{ result.origin }}</div>\n              <div class=\"scoular-alert-description\">\n                {{ result.detail }}\n                @if (result.origin === 'Simulated') {\n                  <!--\n                  🔴 The most dangerous outcome this screen can produce is an approval reported as\n                  done that CTRM never heard about. Said in the result itself, not only in a banner\n                  at the top of the page which a user may have scrolled past.\n                -->\n                  <strong>CTRM was not updated.</strong>\n                }\n              </div>\n            </div>\n            }\n          }\n\n          <!--\n            #1148: once decided, the screen stays and offers the next contract in the queue. Never an\n            auto-advance: the approver reads the outcome, then chooses to move on. Named with the\n            number it opens, so it is not mistaken for the header's › beside the crumb.\n          -->\n          @if (nextAfterDecision(); as next) {\n            <div class=\"cws:mb-3\">\n              <button\n                type=\"button\"\n                class=\"scoular-btn scoular-btn-primary\"\n                [attr.aria-label]=\"'Next contract, ' + next.key\"\n                (click)=\"journey.next()\"\n              >\n                Next contract <span aria-hidden=\"true\">&rsaquo;</span>\n              </button>\n            </div>\n          } @else if (backToQueueAfterDecision()) {\n            <!-- #1158: the last contract in the queue was approved, so the way on is the queue itself. -->\n            <div class=\"cws:mb-3\">\n              <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"backToQueue()\">\n                <span aria-hidden=\"true\">&lsaquo;</span> Back to queue\n              </button>\n            </div>\n          }\n\n          <!-- #803: a decision that failed, with the server's reference or why there is none. -->\n          <div class=\"cws:mb-3\">\n            <cms-status-message [outcome]=\"failure()\" (dismissed)=\"failure.set(null)\" />\n          </div>\n\n          <!--\n            #1086: an approve that MAY have gone through. Worded as neither a failure nor a success,\n            because it may be either: the re-read is how the approver finds out. Approve stays held\n            until they acknowledge, which runs that re-read once.\n          -->\n          @if (unconfirmed()) {\n            <div class=\"scoular-alert scoular-alert-warning cws:mb-3\" role=\"status\" data-testid=\"approval-unconfirmed\">\n              <div class=\"scoular-alert-title\">This approval may have gone through</div>\n              <div class=\"scoular-alert-description cws:flex cws:flex-col cws:gap-2\">\n                <p>\n                  CTRM did not confirm the approve of contract {{ contractNumber() }}. It may have reached\n                  CTRM, and the contract may already have been sent to its recipients. Check the contract\n                  again to see its approval status.\n                </p>\n                @if (unconfirmedProblem()?.detail; as detail) {\n                  <p>{{ detail }}</p>\n                }\n                <cms-reference-line [correlationId]=\"unconfirmedProblem()?.reference ?? null\" />\n\n                @if (!acknowledged()) {\n                  <p>\n                    Approving again could send the contract to the same recipients twice, so Approve is\n                    locked until you acknowledge that.\n                  </p>\n                  <div>\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"acknowledgeUnconfirmed()\">\n                      I understand, check the contract again\n                    </button>\n                  </div>\n                } @else if (!rereadSettled()) {\n                  <p>Checking the contract again…</p>\n                } @else if (rereadApproval()?.state === 'complete') {\n                  <p>\n                    Reading the contract back shows it approved, so the earlier approve went through.\n                    Do not approve it again.\n                  </p>\n                } @else {\n                  <p>\n                    Reading the contract back does not show it approved{{\n                      rereadApproval()?.value ? ' (CTRM says “' + rereadApproval()?.value + '”)' : ''\n                    }}. You may approve it again; the approve tells CTRM you accepted that the earlier\n                    one may have gone through.\n                  </p>\n                }\n              </div>\n            </div>\n          }\n\n          @if (rejectOpen()) {\n            <div class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-2\">\n              <label class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" for=\"reject-reason\">\n                Reason for rejection\n              </label>\n              <!--\n              BR-062: the denial email quotes this, so an empty rejection tells the originator\n              nothing. Submit stays disabled until there is a reason.\n            -->\n              <textarea\n                id=\"reject-reason\"\n                rows=\"3\"\n                class=\"scoular-form-input\"\n                [value]=\"rejectReason()\"\n                (input)=\"onRejectReason($any($event.target).value)\"\n              ></textarea>\n\n              <div class=\"cws:flex cws:items-center cws:gap-2\">\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-primary\"\n                  [disabled]=\"rejectReason().trim() === '' || isDeciding()\"\n                  (click)=\"reject()\"\n                >\n                  {{ isDeciding() ? 'Working…' : 'Reject contract' }}\n                </button>\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-secondary\"\n                  (click)=\"cancelReject()\"\n                >\n                  Cancel\n                </button>\n              </div>\n            </div>\n          } @else if (canApprove() && !locked()) {\n            <!--\n              #1158: after a verified approve the decision is gone rather than disabled. The success\n              above says it is approved and to whom it went; a greyed Approve beside it would read as\n              something still to do.\n            -->\n            <!--\n              🔴 The decision controls exist only for an account that may decide (F4.3a).\n\n              The refusal notice above already states why, so rendering a disabled checkbox and\n              two dead buttons underneath it would say the same thing three more times — and a\n              disabled Approve is the control most likely to be read as \"the system is broken\"\n              rather than \"this is not yours to do\".\n            -->\n            <div class=\"cws:flex cws:flex-col cws:gap-3\">\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\n                <!--\n                The Portal's \"Check Box then Click Here to Approve\", kept deliberately: approval has\n                no inverse on this estate, so one stray click must not be enough.\n              -->\n                <input\n                  type=\"checkbox\"\n                  [checked]=\"confirmed()\"\n                  [disabled]=\"!canApprove()\"\n                  (change)=\"onConfirmChange($any($event.target).checked)\"\n                />\n                I have reviewed this contract and approve it\n              </label>\n\n              <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-primary\"\n                  [disabled]=\"!canSubmit()\"\n                  [attr.title]=\"writeRefusal()\"\n                  (click)=\"approve()\"\n                >\n                  {{ isDeciding() ? 'Working…' : 'Approve contract' }}\n                </button>\n\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-secondary\"\n                  [disabled]=\"!canApprove() || isDeciding() || writeRefusal() !== null\"\n                  [attr.title]=\"writeRefusal()\"\n                  (click)=\"openReject()\"\n                >\n                  Reject with notice\n                </button>\n              </div>\n\n              @if (ecmRefusal(); as refusal) {\n                <!-- #492: why Approve is held, said beside it rather than left as a grey button. -->\n                <p role=\"status\" class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n                  {{ refusal }}\n                </p>\n              }\n\n              @if (writeRefusal(); as refusal) {\n                <!-- #411: the decision stays, disabled; this is its reason, said once beside it. -->\n                <p role=\"status\" class=\"cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n                  {{ refusal }}\n                </p>\n              }\n            </div>\n          }\n        </section>\n      </div>\n    }\n  </cms-async-container>\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: ApprovalDraftDocumentComponent,
				selector: "cms-approval-draft-document",
				inputs: ["contractNumber"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ConfirmationProgressComponent,
				selector: "cms-confirmation-progress",
				inputs: ["header"]
			},
			{
				kind: "component",
				type: BreadcrumbComponent,
				selector: "cms-breadcrumb",
				inputs: [
					"crumbs",
					"current",
					"context",
					"queryParams"
				]
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"systemNotices",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: RecordStepperComponent,
				selector: "cms-record-stepper",
				inputs: ["journey"]
			},
			{
				kind: "component",
				type: ReferenceLineComponent,
				selector: "cms-reference-line",
				inputs: ["correlationId", "sent"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "pipe",
				type: DecimalPipe,
				name: "number"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ApprovalDetailPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-approval-detail-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ApprovalDraftDocumentComponent,
				AsyncContainerComponent,
				ConfirmationProgressComponent,
				BreadcrumbComponent,
				DecimalPipe,
				NoticesPanelComponent,
				RecordStepperComponent,
				ReferenceLineComponent,
				RefreshButtonComponent,
				PageHeaderComponent,
				StatusMessageComponent
			],
			template: "<section class=\"cws:flex cws:flex-col cws:gap-4\">\n  <!--\n    The breadcrumb is the only way back, and it goes to the QUEUE rather than to history: this screen\n    is reachable from one place by design, so a generic \"back\" would be less specific than the truth.\n  -->\n  <!--\n    ⚠ **`queryParams` carries the queue's own state back** (JFrisbie, 2026-09-15) — its search, its\n    sort, the page it was on and the row that was opened. Without it the crumb *worked*, which is the\n    failure worth naming: an approver returned to an unfiltered page 1 with their place gone, and\n    nothing looked broken.\n\n    🔑 **Still a real anchor rather than a click handler**, which is what `returnParams` being an\n    object rather than a URL string buys: it keeps its `href`, so middle-click and open-in-new-tab\n    work and Tab reaches it. Escape navigates to the same place from the same computed.\n  -->\n  <!--\n    🔴 The same breadcrumb shape as the record screen, deliberately (JFrisbie, 2026-09-15).\n\n    This was a single `&lsaquo; Approvals` back-link while the record screen carried a full trail, so\n    two screens one click apart disagreed about where the user was. Matching them is the point: an\n    approver moves between these constantly, and a crumb that changes shape mid-journey reads as a\n    different application.\n\n    The first crumb is the screen you came FROM, so it says `Pricing` and returns there when a pricing\n    queue links in with `?from=pricing`, rather than always claiming Approvals.\n  -->\n  <!--\n    ⚠ **The markup moved to `cms-breadcrumb`; nothing about this trail changed.** It was already the\n    ARIA-correct version, and the shared component was extracted from the record screen's identical\n    copy — so this is the same DOM rendered from one definition instead of three.\n  -->\n  <cms-breadcrumb\n    cmsPageHeaderBreadcrumb\n    [crumbs]=\"crumbs()\"\n    [current]=\"contractNumber()\"\n    [context]=\"tradeUnitLabel()\"\n    [queryParams]=\"returnParams()\"\n  />\n\n  <!--\n    🔴 An h2, not the h1 this screen used to open with. The shell owns the page's only h1, so this\n    was the one screen giving the document two top-level headings -- and its section headings were\n    h2s, one level above every other screen's h3s.\n\n    ⚠ The customer name is bound as the description rather than left as its own paragraph, so it\n    truncates and spaces the same way every other screen's does.\n  -->\n  <cms-page-header\n    [title]=\"'Approve contract ' + contractNumber()\"\n    [description]=\"customerName()\"\n  >\n    @if (contract()?.version; as version) {\n      <!-- The record screen's chip: CTRM's version, not a CMS revision, and muted so it cannot be read as part of the key. -->\n      <span\n        cmsPageHeaderTitleSuffix\n        class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\n        title=\"CTRM contract version\"\n      >\n        v{{ version }}\n      </span>\n    }\n    <ng-container cmsPageHeaderActions>\n      <!--\n        ⚠ The SHARED control, not a hand-rolled button (JFrisbie, 2026-09-14). The first version of\n        this screen used a text button reading \"Refresh\" / \"Refreshing…\", which is a second refresh\n        affordance for the app to keep in step with — exactly the drift the component exists to\n        prevent, and it also loses the 36-vs-38px height correction the icon-only form needs.\n      -->\n      <cms-refresh-button\n        label=\"Refresh this contract\"\n        [busy]=\"isRefreshing()\"\n        (refresh)=\"refresh()\"\n      />\n\n      <!--\n        🔴 No Skip (#1148). It returned to the queue, which the crumb and Escape do; the › beside the\n        crumb moves through the queue's filtered order, which is what the Portal's Skip did.\n      -->\n\n      <!--\n        🔴 **`from` and `returnTo` are passed on, and without them the journey breaks one hop later.**\n\n        The record screen picks its breadcrumb from `from` and defaults to the workspace — so this\n        link, bare, sent an approver queue → review → record and then offered them a crumb reading\n        \"Contracts\" that moved them to a different screen entirely. That is the exact failure\n        `record-origin.ts` was written for, reproduced by the one link that had not been given the\n        parameters.\n\n        ⚠ The record's crumb returns to the **queue**, not to this screen — `RecordOrigin` names\n        queues, not intermediate screens. That is the right destination (it is where the journey\n        started and where the state lives) and it is worth knowing rather than discovering.\n      -->\n      <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\n      <a\n        [attr.href]=\"recordHref()\"\n        (click)=\"followRecord($event)\"\n        class=\"scoular-btn scoular-btn-secondary\"\n      >\n        View full record\n      </a>\n      <!-- ‹ Record 3 of 150 ›, last of the record actions on every details screen (JFrisbie, 2026-10-26). -->\n      <cms-record-stepper [journey]=\"journey\" />\n    </ng-container>\n  </cms-page-header>\n\n  <cms-async-container [data]=\"containerState()\" (retry)=\"retry()\">\n    @if (header(); as row) {\n      <!--\n        🔴 **The spacing wrapper, and it is required rather than decorative** (JFrisbie, 2026-09-15,\n        from a screenshot).\n\n        Measured in Edge before it existed: **0px between every block on this screen** — notices\n        panel, terms, document, distribution and decision all touching — against a uniform **16px**\n        on the approvals queue and the contract record. The screen read as one undifferentiated slab.\n\n        🔑 **The cause is that the root's `gap-4` cannot reach these.** It applies between the root's\n        own children — the breadcrumb, the header and `cms-async-container` — and every block here is\n        *inside* that container, which projects `<ng-content />` **bare, with no wrapper and no\n        spacing of its own**. So the gap stopped at the container's edge, which is exactly where it\n        looked like it was working. ⚠ The record screen has carried its own `space-y-4` wrapper for\n        this reason all along; this screen simply never got one.\n\n        ⚠ **`flex flex-col gap-4` rather than the `space-y-4` used elsewhere, deliberately, and they\n        are visually identical at 16px.** `space-y-*` works by putting `margin-block-end` on each\n        child, and **a vertical margin has no effect on an inline box** — which is what silently ate\n        the notices panel's spacing a day earlier and needed `host: { class: 'block' }` to fix. `gap`\n        is a property of the container and applies whatever the children's display is, so a future\n        component dropped in here cannot lose its spacing the same way.\n      -->\n      <!--\n        🔴 **Two columns from `xl`: the contract document on the right, every other block on the left**\n        (JFrisbie, 2026-10-28), so the approver reads the document beside the decision rather than\n        scrolling between them. Below `xl` it is the single column it always was.\n\n        ⚠ **A grid with explicit placement, not two wrapper columns, deliberately.** The DOM order is\n        unchanged, so a narrow screen and the tab order still run terms → document → distribution →\n        decision, and nothing had to be re-ordered with CSS to get there.\n\n        🔑 **`repeat(5,auto) 1fr` is load-bearing: 5 is the number of LEFT blocks.** The document spans\n        every row (`row-[1/-1]`), and when it is taller than the left column the extra height goes to\n        the final `1fr` row; without that row it would be shared out between the left blocks and pull\n        them apart. Adding or removing a left block means changing the 5, and the spec says so.\n\n        The document is `sticky` with `self-start`, so it stays in view while the left column scrolls;\n        a grid item that stretched to its area would have nothing to stick within.\n      -->\n      <div\n        class=\"cws:flex cws:flex-col cws:gap-4 cws:xl:grid cws:xl:grid-cols-2 cws:xl:grid-rows-[repeat(5,auto)_1fr]\"\n      >\n        <!--\n          F6.5 — the approved → customer → broker progression, first on this screen because it is\n          the one where somebody commits. A stage lit here is read as work already done, so the\n          broker caution travels with the component rather than being restated in a template.\n        -->\n        <section\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:xl:col-start-1 cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\n        >\n          <h2 class=\"cws:mb-2 cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n            Confirmation status\n          </h2>\n          <cms-confirmation-progress [header]=\"row\" />\n        </section>\n\n        <!--\n        🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\n        queue this screen is reached from. It was two full-width banners plus one per server warning\n        above the contract terms — on a screen whose entire job is to show six facts and take a\n        decision, the caveats outweighed the content.\n\n        Every notice is still here and still true; what changed is that the screen opens with the\n        contract. ⚠ **The same test the queue applied: is it restated where it bites?** The decision\n        outcome says <strong>CTRM was not updated</strong> in the result itself, so the data-origin\n        caveat is not the only thing carrying that. Collapsing these without that would have been a\n        loss of safety rather than a tidy-up.\n      -->\n        <cms-notices-panel class=\"cws:xl:col-start-1\" [summaries]=\"noticeSummaries()\">\n          <!--\n          #1086: only while the e-sign routing is SIMULATED. Against the live API the routing comes\n          from ECM (GET …/approval/ecm) and the distribution panel states its case, so this caveat\n          would contradict it.\n        -->\n          @if (ecmSimulated()) {\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n              <div class=\"scoular-alert-title\">E-signature routing is simulated</div>\n              <div class=\"scoular-alert-description\">\n                The e-signature answer below is generated locally, not read from the e-signature\n                service. Approving here does not send the contract for signature.\n              </div>\n            </div>\n          }\n\n          @if (isSimulated()) {\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n              <div class=\"scoular-alert-title\">Simulated data</div>\n              <div class=\"scoular-alert-description\">\n                These contract details are generated locally, not read from CTRM.\n              </div>\n            </div>\n          }\n\n          @for (warning of warnings(); track warning) {\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\n            </div>\n          }\n        </cms-notices-panel>\n\n        <!--\n        The terms, read-only. Six facts rather than 111: the approver is confirming what they already\n        saw in the queue, and the full record is one click away in the header.\n      -->\n        <section class=\"scoular-card cws:p-4 cws:xl:col-start-1\">\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\n            Contract terms\n          </h3>\n\n          <dl class=\"cws:grid cws:grid-cols-1 cws:gap-x-6 cws:gap-y-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Customer</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ customerFor(row) }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</dt>\n              <!-- #1124: \"code, description\", either half alone when only one is known. -->\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ codeAndDescription(row.commodityCode, row.commodity) }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Quantity</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                <!--\n                ⚠ The unit is always rendered beside the number. A grain quantity with no unit is the\n                defect recorded when CTRM was found storing pounds while the API returns bushels.\n              -->\n                @if (row.quantity === null) {\n                  —\n                } @else {\n                  {{ row.quantity | number: '1.0-0' }} {{ row.quantityUom ?? '' }}\n                }\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Price</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ row.price === null ? '—' : (row.price | number: '1.4-4') }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Market zone</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ codeAndDescription(row.marketZone, row.marketZoneDescription) }}\n              </dd>\n            </div>\n            <div>\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Trader</dt>\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\n                {{ row.traderInitials ?? '—' }}\n              </dd>\n            </div>\n          </dl>\n        </section>\n\n        <!--\n        The document. This is the whole lower half of the Portal screen, and it is the thing an\n        approver is actually reading before deciding. From `xl` it is the right-hand column on its own,\n        held in view by `sticky top-4` while the left column scrolls.\n      -->\n        <section\n          class=\"scoular-card cws:p-4 cws:xl:sticky cws:xl:top-4 cws:xl:col-start-2 cws:xl:row-[1/-1] cws:xl:self-start\"\n        >\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\n            Contract document\n          </h3>\n\n          <!-- #1086: the newest draft, requested from CTRM only when none is listed, never while one is pending. -->\n          <cms-approval-draft-document [contractNumber]=\"contractNumber()\" />\n        </section>\n\n        <!--\n          F6.2 — the ECM panel, bound to the approval request under #492 (shape agreed on #469,\n          2026-10-06). E-sign and its recipients come from ECM's routing; the approver never sets\n          e-sign, and the distribution is never sent empty.\n\n          🔴 **At most five recipients, the server's limit (#1172), refused HERE before sending.**\n          Whether they fit is the server's to say: where CTRM takes them joined in one Char(100)\n          field (#1160), it answers 422 approval-recipients-too-long, shown beside the list.\n        -->\n        <section class=\"scoular-card cws:p-4 cws:xl:col-start-1\">\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\n            Send a copy to\n          </h3>\n\n          <!-- The case, always stated, as Contract Portal does (#492). -->\n          <p role=\"status\" class=\"cws:mb-3 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n            {{ ecmCase() }}\n          </p>\n\n          @if (ecmRecipients().length === 0) {\n            <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n              Nobody is on this contract's distribution list yet.\n            </p>\n          } @else {\n            <ul class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-1\">\n              @for (address of ecmRecipients(); track address) {\n                <li\n                  class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:rounded cws:border cws:border-slate-200 cws:px-2 cws:py-1 cws:text-sm cws:text-slate-800 cws:dark:border-slate-700 cws:dark:text-slate-100\"\n                >\n                  <span class=\"truncate\">{{ address }}</span>\n                  @if (ecmEditable()) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary cws:shrink-0 cws:px-2 cws:py-0.5 cws:text-xs\"\n                      (click)=\"removeRecipient(address)\"\n                    >\n                      Remove\n                    </button>\n                  }\n                </li>\n              }\n            </ul>\n          }\n\n          @if (ecmEditable()) {\n            <div class=\"cws:mt-2 cws:flex cws:items-start cws:gap-2\">\n              <label class=\"cws:flex-1\">\n                <span class=\"sr-only\">Recipient email address</span>\n                <input\n                  type=\"email\"\n                  class=\"scoular-form-input\"\n                  placeholder=\"name@example.com\"\n                  [value]=\"recipientDraft()\"\n                  [disabled]=\"ecmRecipients().length >= maxRecipients\"\n                  (input)=\"onRecipientDraft($any($event.target).value)\"\n                  (keydown.enter)=\"$event.preventDefault(); addRecipient()\"\n                />\n              </label>\n              <button\n                type=\"button\"\n                class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\n                [disabled]=\"!canAddRecipient()\"\n                (click)=\"addRecipient()\"\n              >\n                Add\n              </button>\n            </div>\n\n            @if (recipientRefusal(); as refusal) {\n              <!-- The reason at the control, not a greyed button with no explanation. -->\n              <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-red-700 cws:dark:text-scoular-yellow\">\n                {{ refusal }}\n              </p>\n            } @else {\n              <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                {{ ecmRecipients().length }} of {{ maxRecipients }} recipients.\n              </p>\n            }\n          }\n\n          <!--\n            #1172: the server's \"recipients too long\" refusal, beside the list it is about. Removing one\n            clears it; nothing was sent, so approving again is safe.\n          -->\n          <div class=\"cws:mt-2\">\n            <cms-status-message [outcome]=\"recipientsFailure()\" (dismissed)=\"recipientsFailure.set(null)\" />\n          </div>\n\n          <div class=\"cws:mt-3 cws:grid cws:gap-3 cws:sm:grid-cols-2\">\n            <label class=\"cws:block\">\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Copies</span>\n              <input\n                type=\"number\"\n                min=\"1\"\n                class=\"scoular-form-input cws:mt-1\"\n                [value]=\"ecmCopies()\"\n                [disabled]=\"!ecmEditable()\"\n                (input)=\"onEcmCopies($any($event.target).value)\"\n              />\n            </label>\n\n            <!--\n              🔴 No e-sign or override checkbox (#492). E-sign is ECM's answer, shown above; an\n              override is a reason only an authorised approver may give, and has no control until\n              CAPFLG3 and the ESOVR list are known.\n            -->\n          </div>\n\n          <div class=\"cws:mt-3\">\n            <label class=\"cws:block\">\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Message</span>\n              <textarea\n                rows=\"3\"\n                class=\"scoular-form-input cws:mt-1\"\n                [value]=\"ecmMessage()\"\n                [disabled]=\"!ecmEditable()\"\n                (input)=\"onEcmMessage($any($event.target).value)\"\n              ></textarea>\n            </label>\n          </div>\n\n          <!--\n            No printer row (#1275, requested by Hope). Portal printing was removed in 2025 and has no\n            replacement, so an approver is not shown a control they cannot use. This reverses #291,\n            which showed it disabled with its reason.\n          -->\n\n        </section>\n\n\n        <!-- The decision. -->\n        <section class=\"scoular-card cws:p-4 cws:xl:col-start-1\">\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">Decision</h3>\n\n          @if (!canApprove()) {\n            <!--\n            The Portal's \"You do NOT have authority to approve this contract\", stated as what the\n            account lacks. ⚠ Worded as OUR authority rather than CTRM's, because CTRM's per-location\n            approval authority is a separate check we cannot read — claiming to speak for it would be\n            a guess about someone else's rules.\n          -->\n            <p role=\"status\" class=\"cws:mb-3 cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n              You do not have authority to approve this contract. Approving needs the\n              <strong>Admin</strong> role on this application.\n            </p>\n          }\n\n          <!-- #803: a decision CTRM recorded, as a success. A simulated one keeps the warning below. -->\n          <div class=\"cws:mb-3\">\n            <cms-status-message [outcome]=\"recorded()\" (dismissed)=\"outcome.set(null)\" />\n          </div>\n\n          @if (outcome(); as result) {\n            @if (result.origin === 'Simulated') {\n            <div class=\"scoular-alert scoular-alert-warning cws:mb-3\" role=\"status\">\n              <div class=\"scoular-alert-title\">{{ result.decision }} — {{ result.origin }}</div>\n              <div class=\"scoular-alert-description\">\n                {{ result.detail }}\n                @if (result.origin === 'Simulated') {\n                  <!--\n                  🔴 The most dangerous outcome this screen can produce is an approval reported as\n                  done that CTRM never heard about. Said in the result itself, not only in a banner\n                  at the top of the page which a user may have scrolled past.\n                -->\n                  <strong>CTRM was not updated.</strong>\n                }\n              </div>\n            </div>\n            }\n          }\n\n          <!--\n            #1148: once decided, the screen stays and offers the next contract in the queue. Never an\n            auto-advance: the approver reads the outcome, then chooses to move on. Named with the\n            number it opens, so it is not mistaken for the header's › beside the crumb.\n          -->\n          @if (nextAfterDecision(); as next) {\n            <div class=\"cws:mb-3\">\n              <button\n                type=\"button\"\n                class=\"scoular-btn scoular-btn-primary\"\n                [attr.aria-label]=\"'Next contract, ' + next.key\"\n                (click)=\"journey.next()\"\n              >\n                Next contract <span aria-hidden=\"true\">&rsaquo;</span>\n              </button>\n            </div>\n          } @else if (backToQueueAfterDecision()) {\n            <!-- #1158: the last contract in the queue was approved, so the way on is the queue itself. -->\n            <div class=\"cws:mb-3\">\n              <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"backToQueue()\">\n                <span aria-hidden=\"true\">&lsaquo;</span> Back to queue\n              </button>\n            </div>\n          }\n\n          <!-- #803: a decision that failed, with the server's reference or why there is none. -->\n          <div class=\"cws:mb-3\">\n            <cms-status-message [outcome]=\"failure()\" (dismissed)=\"failure.set(null)\" />\n          </div>\n\n          <!--\n            #1086: an approve that MAY have gone through. Worded as neither a failure nor a success,\n            because it may be either: the re-read is how the approver finds out. Approve stays held\n            until they acknowledge, which runs that re-read once.\n          -->\n          @if (unconfirmed()) {\n            <div class=\"scoular-alert scoular-alert-warning cws:mb-3\" role=\"status\" data-testid=\"approval-unconfirmed\">\n              <div class=\"scoular-alert-title\">This approval may have gone through</div>\n              <div class=\"scoular-alert-description cws:flex cws:flex-col cws:gap-2\">\n                <p>\n                  CTRM did not confirm the approve of contract {{ contractNumber() }}. It may have reached\n                  CTRM, and the contract may already have been sent to its recipients. Check the contract\n                  again to see its approval status.\n                </p>\n                @if (unconfirmedProblem()?.detail; as detail) {\n                  <p>{{ detail }}</p>\n                }\n                <cms-reference-line [correlationId]=\"unconfirmedProblem()?.reference ?? null\" />\n\n                @if (!acknowledged()) {\n                  <p>\n                    Approving again could send the contract to the same recipients twice, so Approve is\n                    locked until you acknowledge that.\n                  </p>\n                  <div>\n                    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"acknowledgeUnconfirmed()\">\n                      I understand, check the contract again\n                    </button>\n                  </div>\n                } @else if (!rereadSettled()) {\n                  <p>Checking the contract again…</p>\n                } @else if (rereadApproval()?.state === 'complete') {\n                  <p>\n                    Reading the contract back shows it approved, so the earlier approve went through.\n                    Do not approve it again.\n                  </p>\n                } @else {\n                  <p>\n                    Reading the contract back does not show it approved{{\n                      rereadApproval()?.value ? ' (CTRM says “' + rereadApproval()?.value + '”)' : ''\n                    }}. You may approve it again; the approve tells CTRM you accepted that the earlier\n                    one may have gone through.\n                  </p>\n                }\n              </div>\n            </div>\n          }\n\n          @if (rejectOpen()) {\n            <div class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-2\">\n              <label class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" for=\"reject-reason\">\n                Reason for rejection\n              </label>\n              <!--\n              BR-062: the denial email quotes this, so an empty rejection tells the originator\n              nothing. Submit stays disabled until there is a reason.\n            -->\n              <textarea\n                id=\"reject-reason\"\n                rows=\"3\"\n                class=\"scoular-form-input\"\n                [value]=\"rejectReason()\"\n                (input)=\"onRejectReason($any($event.target).value)\"\n              ></textarea>\n\n              <div class=\"cws:flex cws:items-center cws:gap-2\">\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-primary\"\n                  [disabled]=\"rejectReason().trim() === '' || isDeciding()\"\n                  (click)=\"reject()\"\n                >\n                  {{ isDeciding() ? 'Working…' : 'Reject contract' }}\n                </button>\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-secondary\"\n                  (click)=\"cancelReject()\"\n                >\n                  Cancel\n                </button>\n              </div>\n            </div>\n          } @else if (canApprove() && !locked()) {\n            <!--\n              #1158: after a verified approve the decision is gone rather than disabled. The success\n              above says it is approved and to whom it went; a greyed Approve beside it would read as\n              something still to do.\n            -->\n            <!--\n              🔴 The decision controls exist only for an account that may decide (F4.3a).\n\n              The refusal notice above already states why, so rendering a disabled checkbox and\n              two dead buttons underneath it would say the same thing three more times — and a\n              disabled Approve is the control most likely to be read as \"the system is broken\"\n              rather than \"this is not yours to do\".\n            -->\n            <div class=\"cws:flex cws:flex-col cws:gap-3\">\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\n                <!--\n                The Portal's \"Check Box then Click Here to Approve\", kept deliberately: approval has\n                no inverse on this estate, so one stray click must not be enough.\n              -->\n                <input\n                  type=\"checkbox\"\n                  [checked]=\"confirmed()\"\n                  [disabled]=\"!canApprove()\"\n                  (change)=\"onConfirmChange($any($event.target).checked)\"\n                />\n                I have reviewed this contract and approve it\n              </label>\n\n              <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-primary\"\n                  [disabled]=\"!canSubmit()\"\n                  [attr.title]=\"writeRefusal()\"\n                  (click)=\"approve()\"\n                >\n                  {{ isDeciding() ? 'Working…' : 'Approve contract' }}\n                </button>\n\n                <button\n                  type=\"button\"\n                  class=\"scoular-btn scoular-btn-secondary\"\n                  [disabled]=\"!canApprove() || isDeciding() || writeRefusal() !== null\"\n                  [attr.title]=\"writeRefusal()\"\n                  (click)=\"openReject()\"\n                >\n                  Reject with notice\n                </button>\n              </div>\n\n              @if (ecmRefusal(); as refusal) {\n                <!-- #492: why Approve is held, said beside it rather than left as a grey button. -->\n                <p role=\"status\" class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n                  {{ refusal }}\n                </p>\n              }\n\n              @if (writeRefusal(); as refusal) {\n                <!-- #411: the decision stays, disabled; this is its reason, said once beside it. -->\n                <p role=\"status\" class=\"cws:text-sm cws:text-red-700 cws:dark:text-scoular-yellow\">\n                  {{ refusal }}\n                </p>\n              }\n            </div>\n          }\n        </section>\n      </div>\n    }\n  </cms-async-container>\n</section>\n"
		}]
	}],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}],
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	}
});
export { APPROVAL_GRID_COLUMNS, ApprovalDetailPageComponent, ApprovalsPageComponent };

//# sourceMappingURL=cws-features-approvals.mjs.map
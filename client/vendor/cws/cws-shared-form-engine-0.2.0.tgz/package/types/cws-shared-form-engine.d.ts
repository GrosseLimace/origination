import { FormControl, FormGroup, FormRecord, ValidationErrors, ValidatorFn } from "@angular/forms";
import * as i0 from "@angular/core";
import { Signal } from "@angular/core";
/**
 * The control-pattern standard catalog from docs/02a-UX-UI-Specification.md §3.
 *
 * Every one of the ~70 configurable contract components maps to **exactly one** of these
 * patterns, and the pattern is applied identically on every screen ("one pattern per data
 * type" — 02a §1.2). The pattern is carried on the component's catalog row and arrives on
 * the client inside `ResolvedFormConfig`; `<cms-dynamic-field>` switches on it to pick the
 * renderer. Nothing in the form engine may branch on a component *name* to choose a control.
 */
export declare const ControlPattern: {
  /** C1 — searchable code combo. Displays `CODE — Description`; matches code and description together. */
  readonly SearchableCodeCombo: "C1";
  /** C2 — entity typeahead. Async search, min 2 chars, debounced (customer, broker, trader, locations). */
  readonly EntityTypeahead: "C2";
  /** C3 — masked date input + picker. Free-typed `MMDDYYYY` / `MMDDYY` / `MM/DD/YYYY`. */
  readonly MaskedDate: "C3";
  /** C4 — quantity/decimal input. Right-aligned, thousands separators, optional UM suffix. */
  readonly QuantityDecimal: "C4";
  /** C5 — text input with live remaining-character counter. */
  readonly TextWithCounter: "C5";
  /** C6 — auto-growing multiline note with counter. */
  readonly MultilineNote: "C6";
  /** C7 — status badge / confirmation step indicator. */
  readonly StatusBadge: "C7";
  /** C8 — data grid (home, queues, ship periods, price sequences). */
  readonly DataGrid: "C8";
  /** C9 — toggle/flag with an explicit Yes/No label; Space toggles. */
  readonly ToggleFlag: "C9";
  /** C10 — warning-border field. Amber border + tooltip; never blocks save. */
  readonly WarningBorder: "C10";
  /** C11 — inline PDF viewer with a "Generating…" state (BR-093). */
  readonly InlinePdfViewer: "C11";
};
export type ControlPattern = (typeof ControlPattern)[keyof typeof ControlPattern];
/**
 * Catalog names for the components the BR-003…BR-007 rules reference by name.
 *
 * **This is deliberately not the full catalog.** The ~70 components (and the sections they belong
 * to) are *data* — rows in `ContractComponents`, seeded from the Dataverse export and extended by
 * admins without a deployment (BR-001a). The complete section/field inventory is still an open
 * question (docs/06 A16), so enumerating it here would both invent unratified names and defeat the
 * point of a data-driven catalog.
 *
 * What *is* legitimately code is the small set of components a business rule names explicitly:
 * BR-003 blanks and locks the price components, BR-004 computes one of Price/Basis from the
 * others, BR-005 keys market-month requiredness off the matching price, BR-006 enforces
 * all-or-nothing across the four broker fields, and BR-007 defaults the UM fields from the
 * quantity UM. Those rules cannot be expressed without naming their operands.
 *
 * These identifiers must match `ContractComponents.ComponentName` in the seed data. Translating
 * CTRM's own `invalid_params[].name` values onto them is a separate mapping table (docs/03 §2.2,
 * task F2.4) — not this file's job.
 */
export declare const ContractComponent: {
  readonly PriceTypeCode: "PriceTypeCode";
  readonly Price: "Price";
  readonly BasisPrice: "BasisPrice";
  readonly HedgePrice: "HedgePrice";
  readonly GradeAdjustment: "GradeAdjustment";
  readonly FreightAdjustment: "FreightAdjustment";
  readonly BasisMarketMonth: "BasisMarketMonth";
  readonly BasisMarketMonthDescription: "BasisMarketMonthDescription";
  readonly HedgeMarketMonth: "HedgeMarketMonth";
  readonly HedgeMarketMonthDescription: "HedgeMarketMonthDescription";
  readonly BrokerId: "BrokerId";
  readonly BrokerRate: "BrokerRate";
  readonly BrokerContract: "BrokerContract";
  readonly BrokerUnitOfMeasure: "BrokerUnitOfMeasure";
  readonly Quantity: "Quantity";
  readonly QuantityUnitOfMeasure: "QuantityUnitOfMeasure";
  readonly PriceUnitOfMeasure: "PriceUnitOfMeasure";
  readonly GradeAdjustmentUnitOfMeasure: "GradeAdjustmentUnitOfMeasure";
  readonly FreightAdjustmentUnitOfMeasure: "FreightAdjustmentUnitOfMeasure";
};
export type ContractComponent = (typeof ContractComponent)[keyof typeof ContractComponent];
/**
 * Price type codes the rules branch on.
 *
 * Typed as plain strings rather than an exhaustive union: the full set is CTRM reference data
 * (`GET /reference/codes`), so a new code must not require a CMS code change. Only the codes a
 * rule actually names appear here.
 */
export declare const PriceTypeCode: {
  /** Deferred — BR-003 blanks and locks every price component. */
  readonly Deferred: "D";
  /** Variable — treated identically to Deferred by BR-003. */
  readonly Variable: "V";
  /** Unpriced / basis — accrues price sequences after creation; BR-003 locks Hedge only. */
  readonly Unpriced: "U";
  /** Fully priced — the auto-calculation formula includes Hedge (BR-004). */
  readonly Priced: "P";
};
/**
 * Contract prefix type. BR-002 makes the form read-only for an intercompany **purchase**; BR-024
 * evaluates truck logistics only for a **sale** (the `'S'` guard is explicit in CTRM at
 * `conups.sqlrpgle:3274`).
 */
export declare const ContractPrefixType: {
  readonly Sale: "S";
  readonly Purchase: "P";
};
/**
 * The shape the rule engine reads. Not a domain entity — **the contract is not a domain entity**
 * anywhere in this system (ADR-3); CTRM owns it. This is only the current in-flight form value
 * plus the handful of resolved facts the rules need.
 */
/** A scalar control value. The form is dynamic, so values are keyed by catalog component name. */
export type ContractFieldValue = string | number | boolean | null | undefined;
/** One row of the repeating ship-period grid (BR-020…BR-023). */
export interface ShipPeriodRow {
  /** Canonical ISO `yyyy-MM-dd`. Raw user text is kept on the control until it parses (02a C3). */
  readonly beginDate: string | null;
  readonly endDate: string | null;
  readonly quantity: number | null;
  readonly description?: string;
  /** Optional ship-period-type code, prefixed onto the generated description (BR-023). */
  readonly shipPeriodTypeCode?: string;
}
export interface ContractFormValue {
  /** Flat scalar controls, keyed by `ContractComponents.ComponentName`. */
  readonly fields: Readonly<Record<string, ContractFieldValue>>;
  readonly shipPeriods?: readonly ShipPeriodRow[];
}
/**
 * Facts that are *inputs* to the rules but are not form controls.
 *
 * `isIntercompany` is resolved before evaluation rather than computed inside a rule: per BR-002a
 * it is a cached set-membership test over the location-customer set (is this counterparty one of
 * our own locations?), which is an async reference-data lookup. Passing the resolved boolean in
 * keeps every rule a pure synchronous function — and keeps the prefix constants that the
 * 2026-08-14 ruling banned out of CMS entirely.
 */
export interface ContractFacts {
  /** `S` sale / `P` purchase — see `ContractPrefixType`. */
  readonly prefixType: string;
  /** Closed contracts are wholly read-only (BR-002). */
  readonly isClosed: boolean;
  /** Resolved via BR-002a set membership, never a customer-ID prefix test. */
  readonly isIntercompany: boolean;
  /** False when the user lacks CreateUpdate for this contract's trade unit (BR-002). */
  readonly userCanEdit: boolean;
}
/** Reads a field as a trimmed string, treating blank as absent. */
export declare function readString(value: ContractFormValue, componentName: string): string | null;
/** Reads a field as a finite number, treating blank and unparseable input as absent. */
export declare function readNumber(value: ContractFormValue, componentName: string): number | null;
/** True when the field holds no meaningful value. */
export declare function isBlank(value: ContractFormValue, componentName: string): boolean;
/**
 * The already-resolved form configuration served by the BFF at
 * `GET /trade-units/{tu}/form-config` (docs/03 §3.1, §4).
 *
 * Resolution — global mandates ⊕ trade-unit rows ⊕ `0000` fallback — happens **server-side** in
 * `ConfigurationService`. The client never re-resolves; it renders what it is given. Per BR-001a
 * the shape is a *section tree*: sections and fields come from one hierarchical catalog, both
 * ordered and both gated by the same engine, with empty sections pruned before the payload is
 * built.
 */
/** The six per-field behaviour flags of BR-001, plus the section-level subset. */
export interface FieldBehaviour {
  readonly visible: boolean;
  readonly required: boolean;
  readonly readOnly: boolean;
  readonly borderWarning: boolean;
  readonly excludeFromCopy: boolean;
  readonly excludeFromTemplateCopy: boolean;
}
/**
 * Which behaviour flags are locked by a **global mandate** (BR-001: "globally mandated
 * components locking per-location toggles").
 *
 * This matters on the client as well as in admin: per docs/03 §3.1 the effective field state is
 * `mandate ⊕ ruleOverride ⊕ locationConfig`, so a mandated flag must survive a rule that would
 * otherwise change it. Admin renders these rows locked with a lock icon (02a §6.5).
 */
export type MandatedFlags = readonly (keyof FieldBehaviour)[];
/** One allowed dropdown value for a component, from `ValueConfigurations` (BR-001). */
export interface AllowedValue {
  readonly code: string;
  readonly description: string;
}
/**
 * Length and range metadata for a component, sourced from the checked-in `constraints.json`
 * (docs/03 §2.5, ADR-7) and served at `GET /meta/constraints`. The same file drives
 * FluentValidation server-side, so client and server enforce identical limits by construction.
 */
export interface FieldConstraints {
  readonly maxLength?: number;
  readonly minValue?: number;
  readonly maxValue?: number;
  readonly decimalPlaces?: number;
  /** True where the domain permits a negative value (02a C4 only allows them where it does). */
  readonly allowsNegative?: boolean;
}
/** A single configurable field within a section. */
export interface FormFieldConfig {
  /** Catalog identity — `ContractComponents.ComponentName`. Never a display string. */
  readonly componentName: string;
  readonly label: string;
  readonly controlPattern: ControlPattern;
  /** Order within the parent section. Also drives tab order (02a §4.2). */
  readonly order: number;
  readonly behaviour: FieldBehaviour;
  readonly mandatedFlags: MandatedFlags;
  readonly allowedValues?: readonly AllowedValue[];
  readonly constraints?: FieldConstraints;
  /** Tooltip text for a `borderWarning` field, explaining the caution (02a C10). */
  readonly warningText?: string;
}
/**
 * A configurable tab (ADR-17 D7 — tabs are configuration, not a template).
 *
 * This is what retires the legacy app's hard-coded per-location tabs: its BIO tab was an
 * `If(location = 4090)` conditional, and here it is simply a location-dimension configuration row
 * whose `tabs[]` differs.
 */
export interface FormTabConfig {
  readonly id: string;
  readonly label: string;
  readonly order: number;
  readonly visible: boolean;
}
/**
 * A configurable section (Contract Info, Shipping, Remarks, BIO, FOG, Truck Logistics, …).
 *
 * Sections are catalog rows, not code (BR-001a) — which is what retires the legacy hard-coded
 * BIO/FOG tabs. A section carrying no visible fields is pruned server-side.
 */
export interface FormSectionConfig {
  readonly componentName: string;
  readonly label: string;
  /** Which tab this section renders on — matches a {@link FormTabConfig.id}. */
  readonly tab: string;
  readonly order: number;
  readonly visible: boolean;
  readonly mandatedFlags: MandatedFlags;
  readonly fields: readonly FormFieldConfig[];
}
export interface ResolvedFormConfig {
  /** 4-char trade unit this config was resolved for; `*` when resolved without one. */
  readonly tradeUnit: string;
  /** Identifies the winning configuration row and its lineage, for conditional re-fetch. */
  readonly version: string;
  /** The tabs, in display order. Empty means "use the layout's constant" (the fallback path). */
  readonly tabs: readonly FormTabConfig[];
  readonly sections: readonly FormSectionConfig[];
}
/**
 * Where a resolved configuration came from, as the server reports it (implementation brief §6).
 *
 * Rendered as a muted line on the record screen: it is the admin's debugging thread, and the thing
 * that answers "why is this field required here and not there?" without reading the database.
 */
export interface FormConfigProvenance {
  readonly configId: number | null;
  /** 1 (all three dimensions matched) … 8 (global default or synthesized). */
  readonly rank: number;
  readonly matchedDimensions: readonly string[];
  readonly effectiveFrom: string | null;
  readonly version: number | null;
  /** `Database` | `InMemory` | `SynthesizedDefault`. */
  readonly source: string;
}
/** Flattens the section tree to its fields in `(section.order, field.order)` sequence. */
export declare function orderedFields(config: ResolvedFormConfig): readonly FormFieldConfig[];
/** Looks a field up by catalog name across every section. */
export declare function findField(config: ResolvedFormConfig, componentName: string): FormFieldConfig | undefined;
/**
 * What a rule wants done to a field's *value*, as a closed set of intents.
 *
 * This replaces an earlier pair of `blankValue: boolean` + `computedValue?: ContractFieldValue`,
 * which was ambiguous in two ways that only surfaced once something consumed it:
 *
 * 1. `{ blankValue: true, computedValue: 5 }` was representable and its resolution undefined.
 * 2. `computedValue` meant two different things depending on which rule set it — BR-004's
 *    authoritative locked value, and BR-007's merely-suggested default — distinguishable only by
 *    whether `readOnly` happened to come through with it.
 *
 * There was also a truthiness trap: `ContractFieldValue` includes `undefined`, so the optionality
 * marker and a legal value were the same token, and the natural `if (state.computedValue)` silently
 * discarded a computed `0` — a legitimate price.
 *
 * A discriminated union makes all three unrepresentable. `{ kind: 'computed', value: null }` says
 * "authoritative, and the answer is empty" without ambiguity.
 */
export type ValueIntent =
/** No rule spoke. Configuration alone decides; leave the control's value untouched. */
{
  readonly kind: 'none';
} |
/** BR-003 — clear it. A deferred or variable contract carries no prices. */
{
  readonly kind: 'blank';
} |
/** BR-004 — authoritative. Always overwrite, including with `null`. */
{
  readonly kind: 'computed';
  readonly value: ContractFieldValue;
} |
/** BR-007 — a suggestion. Apply only while the control is still empty. */
{
  readonly kind: 'default';
  readonly value: ContractFieldValue;
};
export declare const valueIntentNone: ValueIntent;
export declare const valueIntentBlank: ValueIntent;
export declare const computedValue: (value: ContractFieldValue) => ValueIntent;
export declare const defaultValue: (value: ContractFieldValue) => ValueIntent;
/**
 * What a rule may say about one field. Every property is optional — a rule states only what it
 * changes, and the engine merges the rest from configuration (docs/03 §3.1).
 */
export interface FieldStateOverride {
  readonly componentName: string;
  readonly visible?: boolean;
  readonly required?: boolean;
  readonly readOnly?: boolean;
  readonly borderWarning?: boolean;
  /**
   * What to do with the field's value. The engine reports the intent and never touches a control —
   * applying it is `FormBuilderService`'s job, which is what keeps the rules free of Angular and
   * mirrorable 1:1 by `ContractRulesService` server-side.
   */
  readonly valueIntent?: ValueIntent;
  /** Human-readable formula, surfaced in the tooltip on a calculated field (BR-004, 02a C4). */
  readonly formula?: string;
  /** Which rule produced this override, for debugging and for the admin "why is this locked?" view. */
  readonly source: string;
}
/** A field's state after configuration and rules have been merged. */
export interface EffectiveFieldState extends FieldBehaviour {
  readonly componentName: string;
  /** Never optional — `{ kind: 'none' }` when no rule spoke, so consumers need no null check. */
  readonly valueIntent: ValueIntent;
  readonly formula?: string;
  /** Rule sources that contributed, in application order. Empty when configuration alone applied. */
  readonly appliedRules: readonly string[];
  /**
   * Flags a rule tried to change but could not, because a global mandate locks them (BR-001).
   * Surfaced rather than swallowed so the behaviour is debuggable instead of mysterious.
   */
  readonly suppressedByMandate: readonly (keyof FieldBehaviour)[];
}
/**
 * Per-trade-unit attributes from `LocationAttributes` (docs/03 §5), surfaced to the client
 * because two of them change form behaviour: the auto-calculation mode (BR-004) and whether
 * Pending is a user-visible state (01 §6.1).
 */
/**
 * "Contract Auto Calculation" (BR-004). `Price` computes Price from its components and locks it;
 * `Basis` does the inverse. `None` covers a trade unit with auto-calculation switched off — the
 * legacy attribute is a two-value setting, but a trade unit that has never been configured must
 * not silently inherit either behaviour.
 */
export declare const AutoCalculationMode: {
  readonly None: "None";
  readonly Price: "Price";
  readonly Basis: "Basis";
};
export type AutoCalculationMode = (typeof AutoCalculationMode)[keyof typeof AutoCalculationMode];
export interface TradeUnitAttributes {
  /** 4-char location code; `0000` is the global default. */
  readonly tradeUnit: string;
  /** BR-004 — drives which of Price/Basis is computed and read-only. */
  readonly autoCalculationMode: AutoCalculationMode;
  /**
   * 01 §6.1 — when false the trade unit never sees Pending, and Save behaves as Submit.
   * Also hides the Pending filter on the home grid (02 §2.1).
   */
  readonly pendingContractsEnabled: boolean;
}
/**
 * Everything a rule is allowed to read.
 *
 * docs/03 §3.1 writes the rule signature as `(formValue, tradeUnitAttributes) => FieldStateOverride[]`.
 * This adds a third member, `facts`, for the resolved contract-level booleans BR-002 and BR-006
 * depend on (closed, intercompany, editable). Those are not form controls and BR-002a's
 * intercompany test is an async cached lookup, so resolving them ahead of evaluation is what keeps
 * every rule pure and synchronous. Bundling all three into one context object rather than growing
 * the parameter list keeps the registry signature stable as further facts appear.
 */
export interface ContractRuleContext {
  readonly value: ContractFormValue;
  readonly tradeUnit: TradeUnitAttributes;
  readonly facts: ContractFacts;
}
/**
 * A business rule: a pure function from the current form state to the field states it implies.
 *
 * Rules **must** be free of side effects, Angular, I/O and clocks — they are re-evaluated on every
 * value change via signals, unit-tested in isolation, and mirrored 1:1 server-side by
 * `ContractRulesService` (docs/03 §2.1). The client copy is UX; the server copy is authoritative.
 */
export type ContractRule = (context: ContractRuleContext) => readonly FieldStateOverride[];
/** A rule plus the identity that lands in `FieldStateOverride.source`. */
export interface RegisteredRule {
  /** Business-rule id from docs/01 §7, e.g. `BR-003`. */
  readonly id: string;
  readonly description: string;
  readonly evaluate: ContractRule;
}
/**
 * The contract form-behaviour rules, registered declaratively (docs/03 §3.1).
 *
 * Order is presentation only — later overrides win on a conflicting flag, but the rules are
 * written to be independent (BR-004 guards the `D`/`V` price types itself rather than relying on
 * BR-003 running first), so the set is effectively commutative. Keep it that way: an order-
 * dependent rule set is one where a reordering silently changes behaviour.
 *
 * `ContractRulesService` on the server mirrors this list 1:1 and is the authority — these run in
 * the browser for immediate feedback only (docs/03 §2.1: "never trust the client").
 */
export declare const CONTRACT_RULES: readonly RegisteredRule[];
/**
 * Evaluates the registered rules against a form value and merges the result over configuration.
 *
 * The merge implements `mandate ⊕ ruleOverride ⊕ locationConfig` (docs/03 §3.1):
 *
 * 1. Start from the field's resolved configuration — already `mandates ⊕ trade unit ⊕ 0000` from
 *    the BFF, so this client never re-resolves configuration.
 * 2. Apply each rule's overrides in registration order.
 * 3. **Refuse any override to a flag a global mandate locks** (BR-001). A mandated component's
 *    toggles cannot be overridden by a per-location row, and a rule must not be a back door around
 *    that. Suppressed flags are recorded on the result rather than dropped, so "why didn't my rule
 *    fire?" is answerable.
 *
 * A plain function rather than an `@Injectable` service: it has no dependencies and no state, which
 * keeps it trivially unit-testable and usable from a `computed()` without an injection context.
 */
export declare function evaluateRules(config: ResolvedFormConfig, value: ContractFormValue, tradeUnit: TradeUnitAttributes, facts: ContractFacts, rules?: readonly RegisteredRule[]): ReadonlyMap<string, EffectiveFieldState>;
/**
 * **BR-004 — auto-calculation per trade-unit attribute.**
 *
 * When "Contract Auto Calculation" is `Price`, Price is derived and locked:
 * `Price = Basis + Hedge + GradeAdj + FreightAdj` — dropping Hedge for an unpriced (`U`) contract,
 * whose futures leg is carried by its price sequences rather than the contract header. When the
 * attribute is `Basis`, the identity is inverted and Basis becomes the derived, locked field.
 *
 * The calculated field renders read-only with its formula in a tooltip (02a C4), so a trader can
 * always see why a number is what it is.
 *
 * Skipped entirely for price types `D`/`V`: BR-003 blanks those components, and computing a total
 * from fields that are about to be cleared would fight it. Guarding here rather than relying on
 * rule ordering keeps the two rules independent of registration order.
 */
export declare function autoCalculation(context: ContractRuleContext): readonly FieldStateOverride[];
export declare const autoCalculationRule: RegisteredRule;
/**
 * **BR-006 — broker completeness.**
 *
 * Broker ID, Rate, Contract and UM are all present or all empty. A half-filled broker block is a
 * commission that cannot be settled, so as soon as any one of the four is populated the other
 * three become required.
 *
 * Two exemptions, both from BR-006 as corrected on 2026-08-14:
 *
 * - **Intercompany** — a trade with one of our own locations has no broker to pay. `isIntercompany`
 *   arrives resolved via BR-002a set membership (does this customer ID appear as `LCUST` on any
 *   row of the location master), *not* a customer-ID prefix test. The `XM` heuristic the docs
 *   originally carried was wrong twice over — `XA` and `XL` are intercompany too — and no prefix
 *   is hard-coded anywhere in CMS.
 * - **Closed** — a closed contract is wholly read-only (BR-002); adding requirements to a form
 *   nobody can edit would only produce unfixable validation errors.
 */
export declare function brokerCompleteness(context: ContractRuleContext): readonly FieldStateOverride[];
export declare const brokerCompletenessRule: RegisteredRule;
/**
 * **The market/hedge cascade — #201, implemented from CTRM's own source.**
 *
 * Every rule below is a line in `docs/CTRM-CONTRACT-WRITE-RULES-2026-09-08.md` §1–§2, which was read
 * from `wnr051e.sqlrpgle` and `conups.sqlrpgle`. The citations are per rule rather than per file so a
 * future reader can check one branch without re-deriving the whole cascade.
 *
 * ### 🔴 These are DERIVATIONS, not validations, and that distinction is the whole design
 *
 * The write-rules document is explicit (§2, closing note): *"Do not implement the mirroring rules as
 * client-side validation errors. If our UI refuses what CTRM would happily normalise, we are stricter
 * than the system of record and the user cannot proceed."* So nothing here returns an error. It
 * returns **the values CTRM will store**, so the screen agrees with the system of record before the
 * write rather than after it.
 *
 * That matters more than it sounds, because CTRM's rewrites are silent: a write is accepted, stored
 * **different from what the user typed**, and answers `202` with no message (correction C-4). The user
 * finds out on a printed contract. Showing the derived value is the only point at which the two copies
 * can be reconciled.
 *
 * ### 🔑 The asymmetry, and it is the opposite way round from the wording
 *
 * For the market **code**, CTRM assigns it for you — so the UI need not derive it, only display it.
 * For the market **month**, there is no assignment anywhere and a mismatch is a hard refusal
 * (`wnr051e:5881-5891`). **So the month is the one field the UI must derive, and the code is the one it
 * need not.** F-19 in the write-rules document says exactly this, and reading it the other way round
 * produces a screen that fights CTRM on the code and lets the refusal through on the month.
 *
 * ### ⚠ Framework-free on purpose
 *
 * No Angular, no I/O, no clock — the same contract every rule in this directory keeps, so it can be
 * unit-tested as a table and consumed by **both** pricing surfaces (the contract record screen through
 * the rule engine, and the pricing detail editor directly, which is not rule-engine driven). The two
 * screens name these fields differently, which is why this module uses its own neutral names and lets
 * each caller map: `contract-layout.ts` calls the basis-side month `BasisMarketMonth`, CTRM calls it
 * `price_market_month`, and the pricing editor's draft calls its pair `hedgeMarketCode` /
 * `hedgeMarketMonthCode`.
 *
 * ### ⚠ What this module does NOT do
 *
 * **It does not blank or lock the price fields for `D`/`V`.** `priceTypeStates` (BR-003) already does,
 * has since before #201, and is the rule the server mirrors. {@link MarketCascade.pricesForbidden} is
 * reported here for the benefit of the pricing editor, which has no rule engine — duplicating the
 * blanking would give the record screen two rules writing the same controls.
 */
/** The four CTRM market fields this cascade governs, in its own neutral naming. */
export type MarketCascadeField = 'priceMarketCode' | 'priceMarketMonth' | 'hedgeMarketCode' | 'hedgeMarketMonth';
/**
 * The stored hedge month meaning *"this contract has no futures month"* (`wnr051e:5865-5868`).
 *
 * ⚠ **A real stored value, not a sentinel we invented**, and it is not a month. A UI that treats the
 * hedge month as a pure month list cannot display what CTRM stored — which is why it is named here
 * rather than left as a literal in one branch.
 */
export declare const NO_HEDGE_MONTH = "X";
export interface MarketCascadeInput {
  /** `price_type_code`, as the form currently holds it. */
  readonly priceType: string | null;
  /**
   * The market code the Grain Factors file gives for this location + commodity — i.e. the single row
   * `GET /api/v1/reference/market-codes?location=…&commodityCode=…` returns.
   *
   * 🔴 **Three states, and each takes a different branch**, because CTRM's own overwrite is gated
   * `If FndComm and FndCommFact` (`wnr051e:5157`) — *if the commodity and its Grain Factors row were
   * found*. So "no row" is not the same as "not asked yet", and collapsing them gets the screen wrong
   * in opposite directions.
   *
   * | | meaning | what the cascade does |
   * |---|---|---|
   * | `undefined` | the lookup is in flight | derives (locks) the field, with no value to show yet |
   * | `null` | settled, and there is **no Grain Factors row** | leaves the field to the **user** — CTRM's guard fails, so it will not overwrite |
   * | a code | settled, with a row | derives and fills it |
   *
   * ⚠ The `null` row is the one a two-state model gets wrong: it would lock a control CTRM is about to
   * leave alone, and since there is no value to fill it with the user would face an empty field they
   * cannot type into — the closed-list-of-nothing trap (#219 criterion 7) wearing a different hat.
   */
  readonly grainFactorsMarketCode: string | null | undefined;
  /** `price_market_code` as the form currently holds it. Used only where CTRM does not overwrite it. */
  readonly priceMarketCode: string | null;
  /** `price_market_month` — the basis-side month, and the one field the user genuinely picks. */
  readonly priceMarketMonth: string | null;
  readonly hedgeMarketCode: string | null;
  readonly hedgeMarketMonth: string | null;
}
export interface MarketCascade {
  readonly priceMarketCode: string | null;
  readonly priceMarketMonth: string | null;
  readonly hedgeMarketCode: string | null;
  readonly hedgeMarketMonth: string | null;
  /**
   * The fields CTRM decides rather than the user — render them read-only and filled.
   *
   * ⚠ **Derived is not the same as "has a value".** `hedgeMarketCode` is derived under price type `U`
   * precisely *because* CTRM forces it blank, so a field can be both derived and empty. A UI that
   * treated an empty derived field as "not derived" would offer the user a control CTRM is about to
   * overwrite.
   */
  readonly derived: readonly MarketCascadeField[];
  /**
   * `D`/`V` — CTRM refuses any price at all (`wnr051e:5778-5789`).
   *
   * Reported, not acted on: BR-003 (`priceTypeStates`) owns the blanking and locking on the record
   * screen. The pricing editor has no rule engine and reads this directly.
   */
  readonly pricesForbidden: boolean;
}
/**
 * Runs the cascade in CTRM's own execution order.
 *
 * 🔴 **The order is the program's line order, and it is load-bearing.** `:4947` clears the hedge code
 * for `U` *before* `:5157` derives the market code, and `:5861` clears the hedge month *before*
 * `:5865` can set it to `X` — reordering any pair changes the answer. The branches are therefore
 * written in ascending line number with the citation on each, so the order can be checked against the
 * source rather than reasoned about.
 */
export declare function marketCascade(input: MarketCascadeInput): MarketCascade;
/**
 * **BR-005 — market-month requiredness follows its price.**
 *
 * A Basis or Hedge market month becomes required as soon as its corresponding price is populated:
 * a price against an unstated futures month is not a complete instruction. Conversely, when the
 * selected month's description is "Not Applicable" the field goes read-only — the reference set is
 * telling us this commodity/location combination has no futures month to pick.
 *
 * The read-only case wins over the required case: if there is genuinely no applicable month, the
 * user cannot be asked to choose one. Requiring a field the same rule just locked would produce a
 * form that cannot be saved and cannot be fixed.
 *
 * (The other half of BR-005 — rebuilding the available months when commodity or location changes —
 * is reference-data fetching, not a field-state rule, and belongs to `ReferenceDataStore`.)
 */
export declare function marketMonthRequiredness(context: ContractRuleContext): readonly FieldStateOverride[];
export declare const marketMonthRequirednessRule: RegisteredRule;
/**
 * **BR-003 — price type drives field states.**
 *
 * - `D` (Deferred) / `V` (Variable): Price, Basis, GradeAdj, FreightAdj and Hedge are forced
 *   read-only, not-required, and **blank**. A deferred or variable contract carries no prices, so
 *   leaving a stale value behind would send it to CTRM on the next upsert.
 * - `U` (Unpriced/basis): only Hedge is read-only and not-required. Prices arrive later as price
 *   sequences through the pricing API (01 §6.1), so Hedge is not the contract's to hold — but the
 *   basis fields stay editable.
 *
 * Any other price type leaves these components entirely to configuration.
 */
export declare function priceTypeStates(context: ContractRuleContext): readonly FieldStateOverride[];
export declare const priceTypeStatesRule: RegisteredRule;
/**
 * **BR-007 — unit-of-measure defaulting.**
 *
 * Price, Grade Adj and Broker UMs default to the Quantity UM while blank. In practice a contract
 * priced in one unit and measured in another is the exception, so this removes keystrokes from
 * every entry — which is the whole point for green-screen-speed users (02a §1.1).
 *
 * It is a *default*, not a lock: the rule proposes a value only for a field the user has left
 * empty, and stops proposing the moment they choose something. Nothing here makes the field
 * read-only, so an explicit different UM is always possible.
 *
 * **The Freight Adj UM follows the freight amount, and this rule owns it (#591).** CTRM refuses a
 * freight UM with a zero amount: "Freight-adj UOM is entered, a Freight-adj Amount must be entered"
 * (`wnr051e:5633`), observed on apiuat 2026-10-01. So the UM is defaulted only once an amount is
 * entered, and *cleared* while the amount is blank. A zero amount is blank, because CTRM reads a
 * blank numeric as 0; and a `D`/`V` contract's amount is blank, because BR-003 blanks it in the same
 * pass. This mirrors the server's `UnitOfMeasureDefaultingRule` (#571, #589), and the clear applies
 * whether or not the quantity UM is set, as the server's does.
 */
export declare function unitOfMeasureDefaulting(context: ContractRuleContext): readonly FieldStateOverride[];
export declare const unitOfMeasureDefaultingRule: RegisteredRule;
/**
 * **BR-022 — "Add period" auto-chains consecutive, non-overlapping monthly periods.**
 *
 * The overwhelmingly common shipping pattern is a run of whole months, so adding a period proposes
 * the next one: the month after the last row's end date, spanning that whole month. The user can
 * still edit both dates afterwards — this is a starting point, not a constraint.
 *
 * Returns `null` when the collection is already at CTRM's 12-period cap, so the caller can disable
 * the action rather than silently doing nothing.
 */
export declare function nextShipPeriod(rows: readonly ShipPeriodRow[]): ShipPeriodRow | null;
/**
 * True when any two periods overlap. BR-022 chains *non-overlapping* periods, and overlapping
 * spans are almost always a typo — surfaced as a warning rather than a save block, because CTRM
 * itself permits them and the business has not ruled that they are invalid.
 */
export declare function hasOverlappingPeriods(rows: readonly ShipPeriodRow[]): boolean;
/** `ship_period_description` max length, from the ConDS constraint dictionary (docs/04 §5). */
export declare const MAX_SHIP_PERIOD_DESCRIPTION_LENGTH = 200;
/**
 * **BR-023 — ship-period description generated from the date span.**
 *
 * Three shapes, chosen by what the span actually is:
 *
 * | Span | Description |
 * |---|---|
 * | A whole calendar month | `March 2027` |
 * | Part of one month | `March 1-15, 2027` |
 * | Across months | `March 1 - April 15, 2027` |
 *
 * Optionally prefixed by the ship-period type code, which is how the legacy system distinguished
 * e.g. a delivery period from a shipment period on the printed contract.
 *
 * Returns `null` when there is no begin date to describe. The result is truncated to the CTRM
 * column width — a description that would be silently cut off server-side is worse than one the
 * user can see is short.
 */
export declare function buildShipPeriodDescription(row: ShipPeriodRow): string | null;
/** CTRM's hard cap on the ship-periods collection (docs/04 §8.1; 02 §3.3). */
export declare const MAX_SHIP_PERIODS = 12;
export declare const ShipPeriodIssueCode: {
  readonly QuantityNotPositive: "QuantityNotPositive";
  readonly BeginDateMissing: "BeginDateMissing";
  readonly BeginDateInPast: "BeginDateInPast";
  readonly EndBeforeBegin: "EndBeforeBegin";
  readonly TooManyPeriods: "TooManyPeriods";
};
export type ShipPeriodIssueCode = (typeof ShipPeriodIssueCode)[keyof typeof ShipPeriodIssueCode];
export interface ShipPeriodIssue {
  /** Row index, or `null` for an issue about the collection as a whole. */
  readonly rowIndex: number | null;
  readonly code: ShipPeriodIssueCode;
  readonly message: string;
}
export declare const ReconciliationState: {
  readonly Balanced: "Balanced";
  readonly Under: "Under";
  readonly Over: "Over";
};
export type ReconciliationState = (typeof ReconciliationState)[keyof typeof ReconciliationState];
export interface ShipPeriodReconciliation {
  readonly allocated: number;
  readonly contractQuantity: number;
  /** Positive when quantity remains to allocate, negative when over-allocated. */
  readonly remaining: number;
  readonly state: ReconciliationState;
  /** The pinned summary line from 02a §6.2, e.g. `12,500 of 15,000 allocated — 2,500 remaining`. */
  readonly summary: string;
}
export declare function reconcileShipPeriods(rows: readonly ShipPeriodRow[], contractQuantity: number | null): ShipPeriodReconciliation;
/**
 * **BR-020 — per-row ship-period validation.**
 *
 * Quantity must be positive, a begin date is required, and the end date may not precede it. The
 * "begin date not in the past" check takes `today` as a parameter rather than reading the clock, so
 * the rule stays pure and its tests stay deterministic.
 *
 * Only rows that carry some data are validated for date order — a wholly empty trailing row is the
 * grid's blank new-row affordance, not a user error.
 */
export declare function validateShipPeriods(rows: readonly ShipPeriodRow[], today?: string | null): readonly ShipPeriodIssue[];
/**
 * The CTRM constraint dictionary served by `GET /api/v1/meta/constraints` (ADR-7, docs/03 §2.5).
 *
 * The server serves `constraints.json` verbatim, so this is the same document FluentValidation
 * enforces — that is the whole point of ADR-7, and it is why nothing here re-states a width.
 *
 * **This is version 2 of the document and its shape is not what docs/03 §2.5 describes** (#53). The
 * v1 seed covered ~25 fields with a `maxLength` each; v2 is generated from CTRM's RPG copybooks and
 * carries 142 `base_data` fields plus four write-only envelope parameters, eleven collections and 82
 * collection members, each with a `type` and either a width or a precision/scale pair.
 *
 * **A field absent from this document has no *known* constraint, which is not the same as having
 * none.** The v1 seed proved the more dangerous direction: `advising_bank_description` was missing,
 * so a `*_description` convention answered a confident 30 for a `varchar(32000)` — 1000× too tight,
 * with no null to warn anyone. Absent must therefore mean "attach no validator", never "unlimited"
 * and never "guess from the name".
 */
export interface ConstraintDocument {
  /** Document version. `2` is the generated extract; `1` was the hand-written seed. */
  readonly version: number;
  /** All 142 `base_data` fields plus the four write-only envelope parameters, by CTRM field name. */
  readonly fields: Readonly<Record<string, ConstraintEntry>>;
  /** The eleven collections, by CTRM collection name. */
  readonly collections: Readonly<Record<string, CollectionConstraint>>;
}
/** What a field's value is, which decides which validators can apply at all. */
export type ConstraintType = 'string' | 'number' | 'integer' | 'date' | 'array';
/**
 * Whether CTRM will accept the field back on a write.
 *
 * `readOnly` means `getContract` returns it and `upsertContract` **refuses** it — the seven computed
 * quantities, `version`, `closed_date`, the three confirmation statuses, every `*_description`.
 * Those render disabled and must be stripped from a save payload rather than echoed (E0.6).
 *
 * `writeOnly` is the mirror: accepted by `upsertContract`, never returned by `getContract`, so
 * fetch-then-merge (ADR-4) has to re-supply them on every write. There are four, and they are
 * envelope parameters rather than contract data.
 *
 * Collection *members* carry no `access` — writability is declared once per collection.
 */
export type ConstraintAccess = 'readWrite' | 'readOnly' | 'writeOnly';
/** One field, exactly as the document spells it. */
export interface ConstraintEntry {
  readonly type: ConstraintType;
  readonly access?: ConstraintAccess;
  /** Character width. Present on `string` only. */
  readonly maxLength?: number;
  /** Total digits. Present on `number`, and on `integer` where CTRM declares one. */
  readonly precision?: number;
  /** Decimal places. Present alongside `precision`. */
  readonly scale?: number;
  /**
   * The **read** width, wider than the write width because the value passes through a conversion on
   * the way out of CTRM. Six fields carry these.
   *
   * ⚠ **Never validate against these.** See {@link NumericConstraint} — the catalog does not hand
   * them to a validator, deliberately.
   */
  readonly readPrecision?: number;
  readonly readScale?: number;
  /** e.g. `iso-8601`. Present on `date`. */
  readonly format?: string;
  /** Cap on a nested array's length. Present on `array`. */
  readonly maxItems?: number;
  /** A nested array's own members. Present on `array` — only `sustainability.practices` today. */
  readonly fields?: Readonly<Record<string, ConstraintEntry>>;
}
/** One collection: how many rows it can hold, whether it is writable, and its members. */
export interface CollectionConstraint {
  readonly maxItems: number;
  /** `false` for `sustainability`, which CTRM returns and refuses on write. */
  readonly writable: boolean;
  readonly fields: Readonly<Record<string, ConstraintEntry>>;
}
/**
 * A numeric field's *write* constraint — the only pair it is ever correct to validate against.
 *
 * **The read pair is deliberately not on this type.** Six fields (`quantity`, `price`,
 * `basis_price`, `hedge_price`, `freight_adj`, `broker_rate`) carry both, and the write pair is the
 * one that matches the physical DB2 column — DBU-verified against `GNP007` and `GNP271`. Validating
 * against the read pair would accept values `upsertContract` rejects, and CTRM answers `202` either
 * way, so the loss would be silent.
 *
 * Making the wrong pair *unrepresentable* rather than merely documented is the same reasoning that
 * put `ContractNumber` in the backend's domain: a comment saying "do not use the read pair" is
 * weaker than not handing it over.
 */
export interface NumericConstraint {
  /** Total digits CTRM will store. */
  readonly precision: number;
  /** Decimal places CTRM will store. */
  readonly scale: number;
  /** Digits permitted before the decimal point — `precision - scale`. */
  readonly maxIntegerDigits: number;
  /**
   * True where CTRM returns more precision than it accepts, so re-sending an **unchanged** value
   * writes a different number than was displayed.
   *
   * Not a validation input — a warning for the save path. E0.6's rule is *do not re-send a numeric
   * the user did not change*, and this flags the six fields where breaking it silently loses data.
   */
  readonly roundTripsLossily: boolean;
}
/**
 * Read-only accessor over the CTRM constraint dictionary (#53).
 *
 * **Why a class rather than reaching into the document.** Three of the four ways to get this wrong
 * are lookup mistakes rather than validation mistakes:
 *
 * 1. **Collection members are no longer in the flat `fields` map.** They moved to
 *    `collections.<name>.fields` because the flat map was ambiguous — `note` and `freight_uom`
 *    collided with `base_data` names and `sequence` appears in three different collections. A
 *    `fields['note']` lookup now returns `undefined`, which reads as "unconstrained" if the caller
 *    is careless. {@link collectionField} makes the collection part of the call.
 * 2. **`quality_factor_suffix` and `field_production_codes` never existed in CTRM at all** — they
 *    came from a docs/04 §5 transcription and are gone from v2. Looking them up returns `undefined`
 *    rather than throwing, so a stale reference degrades to no validation, silently.
 * 3. **The read precision pair is wider than the write pair.** {@link numeric} returns only the
 *    write pair, so a caller cannot pick the wrong one.
 *
 * The fourth is attaching `maxLength` to a numeric, which has no `maxLength` at all — see
 * `constraintValidatorsFor`.
 *
 * Absent is always `undefined`, never a default. The catalog does not guess from a field's name.
 */
export declare class ConstraintCatalog {
  private readonly document;
  private constructor();
  /**
   * Wraps a parsed document.
   *
   * Does not validate the document's shape beyond what TypeScript asserts: it is served verbatim
   * from the same file the server validates against, so a mismatch is a deployment problem rather
   * than something to recover from at runtime.
   */
  static from(document: ConstraintDocument): ConstraintCatalog;
  /** Document version. `2` is the generated extract; a `1` here means a stale server. */
  get version(): number;
  /** A `base_data` field or write-only envelope parameter, by CTRM name. */
  field(name: string): ConstraintEntry | undefined;
  /** A collection, by CTRM name — `remarks`, `notes`, `truck_logistics`, `sustainability`, … */
  collection(name: string): CollectionConstraint | undefined;
  /**
   * A member of a collection.
   *
   * Namespaced deliberately: `collectionField('remarks', 'remark_note')` rather than
   * `field('remark_note')`. The flat lookup is what v2 removed.
   */
  collectionField(collection: string, name: string): ConstraintEntry | undefined;
  /**
   * A member of an array nested inside a collection member.
   *
   * Only `sustainability.practices` today, and it is read-only — but the nesting is real and a
   * two-level lookup cannot reach it.
   */
  nestedField(collection: string, arrayField: string, name: string): ConstraintEntry | undefined;
  /**
   * The write-side numeric constraint for an entry, or `undefined` if it is not numeric.
   *
   * This is the only way the catalog surfaces precision, and it never surfaces `readPrecision` /
   * `readScale` — see {@link NumericConstraint} for why that is structural rather than advisory.
   */
  static numeric(entry: ConstraintEntry | undefined): NumericConstraint | undefined;
  /**
   * True where CTRM will accept this field back on a write.
   *
   * `readOnly` fields must be stripped from a save payload rather than echoed — `upsertContract`
   * refuses them, and there are 38 of them (E0.6). Collection members carry no `access` of their
   * own, so use {@link isCollectionWritable} for those.
   *
   * An entry with no `access` is treated as writable: `access` is absent only on collection members,
   * where the collection's own `writable` flag is the authority.
   */
  static isWritable(entry: ConstraintEntry | undefined): boolean;
  /** True where the field is returned by `getContract` — i.e. not one of the four write-only ones. */
  static isReadable(entry: ConstraintEntry | undefined): boolean;
  /** True where CTRM accepts the collection on a write. `sustainability` is the one that does not. */
  isCollectionWritable(collection: string): boolean;
  /**
   * Every `base_data` field name CTRM refuses on a write.
   *
   * The list a save path needs in order to strip rather than echo. Derived rather than hard-coded so
   * it cannot drift from the document.
   */
  readOnlyFieldNames(): readonly string[];
  /**
   * Every field name `upsertContract` accepts but `getContract` never returns.
   *
   * Fetch-then-merge (ADR-4) cannot carry these across a round trip, so a write has to re-supply
   * them from somewhere other than the fetched contract.
   */
  writeOnlyFieldNames(): readonly string[];
}
/**
 * Builds the validators for one CTRM field from its constraint entry (#53).
 *
 * **Branches on `type`, because reading `maxLength` unconditionally attaches nothing to a number.**
 * That is the defect this function exists to prevent: 53 of the document's fields are `number` and
 * **not one of them has a `maxLength`** — every price and every quantity. A factory written against
 * the v1 seed would attach no validator to any of them, throw nothing, log nothing, and let the form
 * accept anything. Same family as Known Issue 18: a green signal that is not one.
 *
 * Requiredness is deliberately absent, as in `staticValidatorsFor`: BR-005 and BR-006 turn it on and
 * off as the user types, so it comes from `EffectiveFieldState` and is reapplied by the reconcile
 * pass. Nothing here changes while the form is open.
 */
export declare function constraintValidatorsFor(entry: ConstraintEntry | undefined): ValidatorFn[];
/**
 * Rejects a number CTRM's column cannot hold, in both directions.
 *
 * `precision` is total digits and `scale` is decimals, so `precision: 11, scale: 5` permits six
 * digits before the point and five after — `999999.99999` fits and `1000000.0` does not, even though
 * the second has fewer significant digits. Checking only decimals would let the second through, which
 * is the mistake a `decimalPlaces`-only validator makes.
 *
 * Counted on the numeric value rather than the typed string, deliberately: `1.500000` against a scale
 * of 5 is not an error, because dropping a trailing zero loses nothing. Only *significant* precision
 * is worth refusing.
 */
export declare function precisionScale(precision: number, scale: number): ValidatorFn;
/** Caps a `FormArray` (or any array-valued control) at the collection's declared row limit. */
export declare function maxItems(max: number): ValidatorFn;
/**
 * Strips the fields CTRM refuses on a write (#53, E0.6).
 *
 * **`upsertContract` refuses read-only fields rather than ignoring them**, and there are 38 of them:
 * all seven computed quantities, `version`, `closed_date`, the three confirmation statuses and every
 * `*_description`. Under fetch-then-merge (ADR-4) the natural implementation echoes back whatever
 * `getContract` returned, which is exactly the payload that gets rejected — so the strip is a
 * requirement of the write path, not a tidiness measure.
 *
 * **Derived from the document, never from a hard-coded list**, so it cannot drift when CTRM's
 * copybooks change and the catalog is regenerated.
 *
 * ⚠ **This is one of two write-side rules and only handles the first.** The other is *do not re-send
 * a numeric the user did not change*: `quantity` reads at up to 5 decimal places and writes at 2, so
 * re-sending an unchanged value writes a different number than was displayed — and CTRM answers
 * `202` either way, so nothing surfaces. That one needs the user's edit history and so cannot be
 * solved by a filter over the final payload. `NumericConstraint.roundTripsLossily` flags the six
 * affected fields; wiring it is the save path's job when it exists.
 */
export declare function writableFields<T extends Record<string, unknown>>(payload: T, catalog: ConstraintCatalog): Partial<T>;
/**
 * Validators derived from a field's *configuration* — the ones that never change while the form is
 * open. Requiredness is deliberately **not** here: BR-005 and BR-006 both turn it on and off as the
 * user types, so it comes from `EffectiveFieldState` and is reapplied by the reconcile pass.
 *
 * ⚠ **`FormFieldConfig.constraints` is NOT `GET /meta/constraints`, and the two must not be
 * conflated.** This reads the per-trade-unit `ResolvedFormConfig` (F2.1, not built — the values in
 * play today are hand-written demo content, Known Issue 30). The CTRM column widths live in the
 * separate constraint dictionary, which is a different shape keyed by CTRM field name, and is
 * consumed through `constraintValidatorsFor` (#53).
 *
 * **What still has to be decided before the two can meet:** `FormFieldConfig.componentName` is a
 * catalog component name and the dictionary is keyed by CTRM field name. Nothing in the repository
 * maps one to the other yet — that mapping is F2.1's, and inventing it here would be guessing at an
 * open question. So this function is deliberately left reading the config's own constraints, and
 * `constraintValidatorsFor` is the one to call once a CTRM field name is in hand.
 *
 * ADR-7's guarantee — that the Angular validators and server-side FluentValidation cannot disagree
 * about a column width — holds only for the dictionary path, not for this one.
 */
export declare function staticValidatorsFor(field: FormFieldConfig): ValidatorFn[];
/**
 * Angular ships no decimal-scale validator. Rejects more precision than the column can hold, rather
 * than letting CTRM silently round it — a price quietly losing its fourth decimal is the kind of
 * difference nobody notices until settlement.
 */
export declare function decimalPlaces(max: number): ValidatorFn;
/**
 * A combo is a closed set: a value outside the trade unit's configured values (BR-001) must not
 * reach CTRM. Pasting an exact-but-unconfigured code is the realistic way this happens.
 */
export declare function allowedValues(codes: readonly string[]): ValidatorFn;
/** One control per configured field, keyed by `ContractComponents.ComponentName`. */
export type ContractFieldControl = FormControl<ContractFieldValue>;
export interface ContractFormGroup extends FormGroup<{
  fields: FormRecord<ContractFieldControl>;
}> {}
/** What a caller gets back from `build`. */
export interface ContractForm {
  readonly group: ContractFormGroup;
  /** Current value, kept in step with the group. */
  readonly value: Signal<ContractFormValue>;
  /** Effective field states after rules, keyed by component name. */
  readonly states: Signal<ReadonlyMap<string, EffectiveFieldState>>;
  fieldState(componentName: string): EffectiveFieldState | undefined;
  control(componentName: string): ContractFieldControl | undefined;
  /**
   * Writes prefilled values — a contract loaded from CTRM, a copied contract, a template — **without
   * presenting them as user input**, and then lets the rules see them (#364).
   *
   * 🔴 **Use this rather than `control(name).setValue(v, { emitEvent: false })`.** Both halves are
   * required and the second one is easy to forget:
   *
   * - the write stays silent, so no `valueChanges` fires: the control stays pristine, `dirtyValues()`
   *   keeps excluding it from a full-replace update, and the draft autosave does not record a record
   *   nobody has touched;
   * - **the value signal is refreshed explicitly**, so `evaluateRules` sees the seeded contract.
   *
   * Skipping the second half is what left BR-003's price blanking and BR-005's requiredness
   * evaluating against an empty form on every loaded record. `reconcile` has always done both for
   * the engine's own silent writes; this is the same pattern for a caller's.
   *
   * Unknown component names are ignored, so a caller may hand over a whole contract payload without
   * first intersecting it with the resolved configuration.
   */
  seed(values: Readonly<Record<string, ContractFieldValue>>): void;
}
/**
 * **F2.2a — builds the contract `FormGroup` from `ResolvedFormConfig` and keeps it in step with the
 * rules** (docs/03 §3.1).
 *
 * Deliberately `@Injectable()` without `providedIn: 'root'`: it is provided on the form component,
 * so each embedded instance gets its own. Two federated Contract Entry components on one host page
 * must not share a FormGroup (03 §3.4.8).
 */
export declare class FormBuilderService {
  private readonly destroyRef;
  private readonly config;
  private readonly tradeUnit;
  private readonly facts;
  private readonly formValue;
  private group;
  private passes;
  /** Requiredness currently applied, so validators are only rebuilt when it actually changes. */
  private readonly appliedRequired;
  private readonly effectiveStates;
  constructor();
  build(config: ResolvedFormConfig, tradeUnit: TradeUnitAttributes, facts: ContractFacts): ContractForm;
  /**
   * The write half of {@link ContractForm.seed}, plus the re-read that makes the rules see it.
   *
   * Mirrors the tail of {@link reconcile} deliberately: silence the writes, then set the value signal
   * once for the whole batch rather than once per control, so 111 seeded fields cost one rule
   * evaluation instead of 111.
   */
  private seed;
  private reconcile;
  /** Returns true when the control's value actually changed. */
  private applyValue;
  private applyRequired;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormBuilderService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Reads the group's value.
 *
 * `getRawValue()`, never `.value` — a FormGroup omits disabled controls from `.value`, so once
 * BR-002 disables a closed contract the rules would evaluate against an empty contract and every
 * one of them would reach the wrong conclusion.
 */
export declare function readFormValue(group: ContractFormGroup): ContractFormValue;
/** A code and the description CTRM has stored beside it, as the contract was last saved. */
export interface SavedCodeDescription {
  readonly code: string;
  readonly description: string;
}
/** Viewing a saved record, or editing one. The create screen has nothing saved, so passes no pairs. */
export type CodeDescriptionMode = 'view' | 'edit';
/**
 * **One combo per code — description pair, showing what the contract actually says** (#595).
 *
 * The six pairs (payment terms, routing, billing instructions, weights and grades to govern, governing
 * trade rule) used to be a code combo plus a free-text description box. CTRM fills the description from
 * the code **only when it is blank** and keeps typed text (`wnr051e:3254-3273`, source read), so the
 * box let a user print anything beside a code. The ruling (GEstevez, 2026-10-01) is no free text where
 * a code exists: the description row is gone and the combo's `code — description` IS the pair.
 *
 * That leaves legacy contracts, whose printed description may be hand-typed. The ruling for them:
 *
 * | mode | what this does |
 * |---|---|
 * | `view` | the combo's one option is the **saved** pair, so the record reads exactly as it was saved |
 * | `edit` | the code table stays the option list, and a field whose saved text differs from its code's is **marked**: an amber border and a hint naming both texts, because the first CWS save replaces what prints |
 *
 * 🔴 **The edit-mode hint is only true once the server normalises.** The description is no longer a
 * form field, so the screen never sends it; the server merges onto CTRM's raw record (ADR-4), and it is
 * the backend's enforcement (#594) that blanks the description so CTRM derives it from the code.
 *
 * ⚠ **Applied as a configuration overlay, never in the combo itself.** The combo renders what it is
 * given and stays a closed list; this only chooses the list (view) or adds a warning (edit). Both
 * leave the control's value alone, so a saved code that is not in the list still shows as-is
 * (`code-combo.component.spec.ts`) and is never written back empty.
 */
export declare function withSavedCodeDescriptions(config: ResolvedFormConfig, saved: ReadonlyMap<string, SavedCodeDescription>, mode: CodeDescriptionMode): ResolvedFormConfig;
/**
 * Turns a control's errors into one line a trader can act on.
 *
 * `error-handling.md` §7 is the standard here: plain language, no error codes, no exception names,
 * and specific about what to do next. "Enter a value" beats "required".
 *
 * Only the first error is shown. A field that is both empty and over-length is empty first, and
 * stacking messages under a control in a dense grid costs more than it explains.
 */
export declare function validationMessageFor(errors: ValidationErrors | null): string | null;
/**
 * **F2.2c — renders one configured field with the control its pattern calls for** (docs/03 §3.1).
 *
 * This is the join between configuration and the UI kit: it takes a `FormFieldConfig`, the
 * `EffectiveFieldState` the rules produced for it, and the `FormControl` holding its value, and
 * switches on `controlPattern` to pick a component from `@cws/shared-ui`.
 *
 * It lives in the form engine rather than the UI kit because the dependency has to run one way —
 * the engine renders *through* the kit (03 §3), so the kit must not know about `FormFieldConfig`.
 * That direction only became available once the shared date parsing moved to `@cws/shared-utils`.
 *
 * **Behaviour comes from `state`, never from `field.behaviour`.** Configuration is the starting
 * point; the rules are the final word, and `EffectiveFieldState` is configuration already merged
 * with them (BR-001). Reading `field.behaviour` here would silently ignore every rule.
 *
 * The control is taken as an input rather than reached for via `formControlName`, so this renders
 * with nothing but `new FormControl(null)` — no ancestor form directive, and no untestable
 * coupling to a parent.
 */
export declare class DynamicFieldComponent {
  readonly field: import("@angular/core").InputSignal<FormFieldConfig>;
  readonly state: import("@angular/core").InputSignal<EffectiveFieldState>;
  readonly control: import("@angular/core").InputSignal<ContractFieldControl>;
  /**
   * Prefixed onto every DOM id. Two instances of the same form on one host page — entirely possible
   * under Module Federation (03 §3.4) — would otherwise emit duplicate ids and break every
   * `<label for>` association on the second one.
   */
  readonly idPrefix: import("@angular/core").InputSignal<string>;
  /**
   * Renders the visible label as screen-reader-only, for a field grouped under one heading.
   *
   * ⚠ Hidden, never removed: dropping the label leaves the control with no accessible name, so a
   * screen reader announces an unlabelled box. Only the sighted heading goes.
   */
  readonly hideLabel: import("@angular/core").InputSignal<boolean>;
  /** Expose the pattern constants to the template. */
  protected readonly patterns: {
    readonly SearchableCodeCombo: "C1";
    readonly EntityTypeahead: "C2";
    readonly MaskedDate: "C3";
    readonly QuantityDecimal: "C4";
    readonly TextWithCounter: "C5";
    readonly MultilineNote: "C6";
    readonly StatusBadge: "C7";
    readonly DataGrid: "C8";
    readonly ToggleFlag: "C9";
    readonly WarningBorder: "C10";
    readonly InlinePdfViewer: "C11";
  };
  protected readonly controlId: import("@angular/core").Signal<string>;
  /**
   * A tick whenever the bound control changes in any way.
   *
   * `control.events` rather than `statusChanges`, because a control becoming *touched* does not
   * emit a status change — and touched is precisely what gates the error message below. Routed
   * through `toObservable(this.control)` so a required input is read lazily (reading it in a field
   * initializer would throw) and so re-binding to a different control re-subscribes.
   */
  private readonly controlEvents;
  /**
   * The message to show, or null. Held back until the control has been touched — shouting "Enter a
   * value" at every empty field the moment a blank form renders is noise, not help.
   */
  protected readonly errorMessage: import("@angular/core").Signal<string | null>;
  protected readonly maxLength: import("@angular/core").Signal<number>;
  protected readonly allowedValues: import("@angular/core").Signal<readonly import("@cws/shared-form-engine").AllowedValue[]>;
  /** True for a pattern that has no renderer yet, so the template can say so out loud. */
  protected readonly unsupported: import("@angular/core").Signal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFieldComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<DynamicFieldComponent, "cms-dynamic-field", never, {
    "field": {
      "alias": "field";
      "required": true;
      "isSignal": true;
    };
    "state": {
      "alias": "state";
      "required": true;
      "isSignal": true;
    };
    "control": {
      "alias": "control";
      "required": true;
      "isSignal": true;
    };
    "idPrefix": {
      "alias": "idPrefix";
      "required": false;
      "isSignal": true;
    };
    "hideLabel": {
      "alias": "hideLabel";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
import { addMonths, compareIsoDates, endOfMonth, fromIsoDate, startOfMonth } from "@cws/shared-utils";
import * as i1 from "@angular/forms";
import { FormControl, FormGroup, FormRecord, ReactiveFormsModule, Validators } from "@angular/forms";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Injectable, computed, effect, inject, input, signal, untracked } from "@angular/core";
import { takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { CodeComboComponent, DateInputComponent, FieldComponent, NoteInputComponent, QuantityInputComponent, TextInputComponent, ToggleComponent } from "@cws/shared-ui";
import { startWith, switchMap } from "rxjs";
const ControlPattern = {
	SearchableCodeCombo: "C1",
	EntityTypeahead: "C2",
	MaskedDate: "C3",
	QuantityDecimal: "C4",
	TextWithCounter: "C5",
	MultilineNote: "C6",
	StatusBadge: "C7",
	DataGrid: "C8",
	ToggleFlag: "C9",
	WarningBorder: "C10",
	InlinePdfViewer: "C11"
};
const ContractComponent = {
	PriceTypeCode: "PriceTypeCode",
	Price: "Price",
	BasisPrice: "BasisPrice",
	HedgePrice: "HedgePrice",
	GradeAdjustment: "GradeAdjustment",
	FreightAdjustment: "FreightAdjustment",
	BasisMarketMonth: "BasisMarketMonth",
	BasisMarketMonthDescription: "BasisMarketMonthDescription",
	HedgeMarketMonth: "HedgeMarketMonth",
	HedgeMarketMonthDescription: "HedgeMarketMonthDescription",
	BrokerId: "BrokerId",
	BrokerRate: "BrokerRate",
	BrokerContract: "BrokerContract",
	BrokerUnitOfMeasure: "BrokerUnitOfMeasure",
	Quantity: "Quantity",
	QuantityUnitOfMeasure: "QuantityUnitOfMeasure",
	PriceUnitOfMeasure: "PriceUnitOfMeasure",
	GradeAdjustmentUnitOfMeasure: "GradeAdjustmentUnitOfMeasure",
	FreightAdjustmentUnitOfMeasure: "FreightAdjustmentUnitOfMeasure"
};
const PriceTypeCode = {
	Deferred: "D",
	Variable: "V",
	Unpriced: "U",
	Priced: "P"
};
const ContractPrefixType = {
	Sale: "S",
	Purchase: "P"
};
function readString(value, componentName) {
	const raw = value.fields[componentName];
	if (raw === null || raw === void 0 || typeof raw === "boolean") return null;
	const text = String(raw).trim();
	return text.length === 0 ? null : text;
}
function readNumber(value, componentName) {
	const raw = value.fields[componentName];
	if (raw === null || raw === void 0 || raw === "" || typeof raw === "boolean") return null;
	const parsed = typeof raw === "number" ? raw : Number(raw);
	return Number.isFinite(parsed) ? parsed : null;
}
function isBlank(value, componentName) {
	return readString(value, componentName) === null;
}
const valueIntentNone = { kind: "none" };
const valueIntentBlank = { kind: "blank" };
const computedValue = (value) => ({
	kind: "computed",
	value
});
const defaultValue = (value) => ({
	kind: "default",
	value
});
function orderedFields(config) {
	return [...config.sections].sort((a, b) => a.order - b.order).flatMap((section) => [...section.fields].sort((a, b) => a.order - b.order));
}
function findField(config, componentName) {
	for (const section of config.sections) {
		const match = section.fields.find((field) => field.componentName === componentName);
		if (match) return match;
	}
}
const AutoCalculationMode = {
	None: "None",
	Price: "Price",
	Basis: "Basis"
};
const RULE_ID$4 = "BR-004";
const PRICE_SCALE = 4;
function round$1(value) {
	return Number(value.toFixed(PRICE_SCALE));
}
function autoCalculation(context) {
	const mode = context.tradeUnit.autoCalculationMode;
	if (mode === AutoCalculationMode.None) return [];
	const priceType = readString(context.value, ContractComponent.PriceTypeCode);
	if (priceType === PriceTypeCode.Deferred || priceType === PriceTypeCode.Variable) return [];
	const includesHedge = priceType !== PriceTypeCode.Unpriced;
	const basis = readNumber(context.value, ContractComponent.BasisPrice);
	const price = readNumber(context.value, ContractComponent.Price);
	const hedge = includesHedge ? readNumber(context.value, ContractComponent.HedgePrice) : null;
	const gradeAdj = readNumber(context.value, ContractComponent.GradeAdjustment);
	const freightAdj = readNumber(context.value, ContractComponent.FreightAdjustment);
	const adjustments = (gradeAdj ?? 0) + (freightAdj ?? 0) + (includesHedge ? hedge ?? 0 : 0);
	if (mode === AutoCalculationMode.Price) {
		const anyOperand = basis !== null || gradeAdj !== null || freightAdj !== null || hedge !== null;
		return [{
			componentName: ContractComponent.Price,
			readOnly: true,
			valueIntent: computedValue(anyOperand ? round$1((basis ?? 0) + adjustments) : null),
			formula: includesHedge ? "Price = Basis + Hedge + Grade Adj + Freight Adj" : "Price = Basis + Grade Adj + Freight Adj",
			source: RULE_ID$4
		}];
	}
	const anyOperand = price !== null || gradeAdj !== null || freightAdj !== null || hedge !== null;
	return [{
		componentName: ContractComponent.BasisPrice,
		readOnly: true,
		valueIntent: computedValue(anyOperand ? round$1((price ?? 0) - adjustments) : null),
		formula: includesHedge ? "Basis = Price − Hedge − Grade Adj − Freight Adj" : "Basis = Price − Grade Adj − Freight Adj",
		source: RULE_ID$4
	}];
}
const autoCalculationRule = {
	id: RULE_ID$4,
	description: "Derives and locks Price or Basis per the trade unit’s auto-calculation mode.",
	evaluate: autoCalculation
};
const RULE_ID$3 = "BR-006";
const BROKER_COMPONENTS = [
	ContractComponent.BrokerId,
	ContractComponent.BrokerRate,
	ContractComponent.BrokerContract,
	ContractComponent.BrokerUnitOfMeasure
];
function brokerCompleteness(context) {
	if (context.facts.isIntercompany || context.facts.isClosed) return [];
	if (!BROKER_COMPONENTS.some((componentName) => !isBlank(context.value, componentName))) return [];
	return BROKER_COMPONENTS.map((componentName) => ({
		componentName,
		required: true,
		source: RULE_ID$3
	}));
}
const brokerCompletenessRule = {
	id: RULE_ID$3,
	description: "Broker ID/Rate/Contract/UM are all-present or all-empty; exempt when intercompany or closed.",
	evaluate: brokerCompleteness
};
const RULE_ID$2 = "BR-005";
const NOT_APPLICABLE = "not applicable";
const PAIRS = [{
	priceComponent: ContractComponent.BasisPrice,
	marketMonthComponent: ContractComponent.BasisMarketMonth,
	marketMonthDescriptionComponent: ContractComponent.BasisMarketMonthDescription
}, {
	priceComponent: ContractComponent.HedgePrice,
	marketMonthComponent: ContractComponent.HedgeMarketMonth,
	marketMonthDescriptionComponent: ContractComponent.HedgeMarketMonthDescription
}];
function marketMonthRequiredness(context) {
	const overrides = [];
	for (const pair of PAIRS) {
		const description = readString(context.value, pair.marketMonthDescriptionComponent);
		if (description !== null && description.toLowerCase() === NOT_APPLICABLE) {
			overrides.push({
				componentName: pair.marketMonthComponent,
				readOnly: true,
				required: false,
				source: RULE_ID$2
			});
			continue;
		}
		if (readNumber(context.value, pair.priceComponent) !== null) overrides.push({
			componentName: pair.marketMonthComponent,
			required: true,
			source: RULE_ID$2
		});
	}
	return overrides;
}
const marketMonthRequirednessRule = {
	id: RULE_ID$2,
	description: "Market month is required once its price is populated, read-only when Not Applicable.",
	evaluate: marketMonthRequiredness
};
const RULE_ID$1 = "BR-003";
const PRICE_COMPONENTS = [
	ContractComponent.Price,
	ContractComponent.BasisPrice,
	ContractComponent.GradeAdjustment,
	ContractComponent.FreightAdjustment,
	ContractComponent.HedgePrice
];
function priceTypeStates(context) {
	const priceType = readString(context.value, ContractComponent.PriceTypeCode);
	if (priceType === PriceTypeCode.Deferred || priceType === PriceTypeCode.Variable) return PRICE_COMPONENTS.map((componentName) => ({
		componentName,
		readOnly: true,
		required: false,
		valueIntent: valueIntentBlank,
		source: RULE_ID$1
	}));
	if (priceType === PriceTypeCode.Unpriced) return [{
		componentName: ContractComponent.HedgePrice,
		readOnly: true,
		required: false,
		source: RULE_ID$1
	}];
	return [];
}
const priceTypeStatesRule = {
	id: RULE_ID$1,
	description: "Price type D/V blanks and locks the price components; U locks Hedge only.",
	evaluate: priceTypeStates
};
const RULE_ID = "BR-007";
const DEFAULTED_UNIT_COMPONENTS = [
	ContractComponent.PriceUnitOfMeasure,
	ContractComponent.GradeAdjustmentUnitOfMeasure,
	ContractComponent.BrokerUnitOfMeasure
];
function unitOfMeasureDefaulting(context) {
	const quantityUnit = readString(context.value, ContractComponent.QuantityUnitOfMeasure);
	const overrides = [];
	if (quantityUnit !== null) {
		for (const componentName of DEFAULTED_UNIT_COMPONENTS) if (isBlank(context.value, componentName)) overrides.push({
			componentName,
			valueIntent: defaultValue(quantityUnit),
			source: RULE_ID
		});
	}
	const freightUnit = ContractComponent.FreightAdjustmentUnitOfMeasure;
	if (freightAmountIsBlank(context.value)) {
		if (!isBlank(context.value, freightUnit)) overrides.push({
			componentName: freightUnit,
			valueIntent: valueIntentBlank,
			source: RULE_ID
		});
	} else if (quantityUnit !== null && isBlank(context.value, freightUnit)) overrides.push({
		componentName: freightUnit,
		valueIntent: defaultValue(quantityUnit),
		source: RULE_ID
	});
	return overrides;
}
function freightAmountIsBlank(value) {
	const priceType = readString(value, ContractComponent.PriceTypeCode);
	if (priceType === PriceTypeCode.Deferred || priceType === PriceTypeCode.Variable) return true;
	const amount = readNumber(value, ContractComponent.FreightAdjustment);
	return amount === null || amount === 0;
}
const unitOfMeasureDefaultingRule = {
	id: RULE_ID,
	description: "Price/GradeAdj/Broker UMs default to the Quantity UM while blank; the FreightAdj UM follows the freight amount.",
	evaluate: unitOfMeasureDefaulting
};
const CONTRACT_RULES = [
	priceTypeStatesRule,
	autoCalculationRule,
	marketMonthRequirednessRule,
	brokerCompletenessRule,
	unitOfMeasureDefaultingRule
];
const OVERRIDABLE_FLAGS = [
	"visible",
	"required",
	"readOnly",
	"borderWarning"
];
function evaluateRules(config, value, tradeUnit, facts, rules = CONTRACT_RULES) {
	const context = {
		value,
		tradeUnit,
		facts
	};
	const overridesByComponent = /* @__PURE__ */ new Map();
	for (const rule of rules) for (const override of rule.evaluate(context)) {
		const existing = overridesByComponent.get(override.componentName);
		if (existing) existing.push(override);
		else overridesByComponent.set(override.componentName, [override]);
	}
	const states = /* @__PURE__ */ new Map();
	for (const section of config.sections) for (const field of section.fields) states.set(field.componentName, mergeField(field, overridesByComponent.get(field.componentName) ?? []));
	return states;
}
function mergeField(field, overrides) {
	const behaviour = { ...field.behaviour };
	const appliedRules = [];
	const suppressedByMandate = [];
	let valueIntent = valueIntentNone;
	let formula;
	for (const override of overrides) {
		let contributed = false;
		for (const flag of OVERRIDABLE_FLAGS) {
			const proposed = override[flag];
			if (proposed === void 0 || proposed === behaviour[flag]) continue;
			if (field.mandatedFlags.includes(flag)) {
				if (!suppressedByMandate.includes(flag)) suppressedByMandate.push(flag);
				continue;
			}
			behaviour[flag] = proposed;
			contributed = true;
		}
		if (override.valueIntent !== void 0 && override.valueIntent.kind !== "none") {
			valueIntent = override.valueIntent;
			contributed = true;
		}
		if (override.formula !== void 0) formula = override.formula;
		if (contributed && !appliedRules.includes(override.source)) appliedRules.push(override.source);
	}
	return {
		componentName: field.componentName,
		...behaviour,
		valueIntent,
		formula,
		appliedRules,
		suppressedByMandate
	};
}
const NO_HEDGE_MONTH = "X";
const PRICED = "P";
const UNPRICED = "U";
const DEFERRED = "D";
const VARIABLE = "V";
const UNHEDGEABLE = "U";
function marketCascade(input) {
	const priceType = normalise(input.priceType);
	const derived = /* @__PURE__ */ new Set();
	let priceMarketCode = normalise(input.priceMarketCode);
	const priceMarketMonth = normalise(input.priceMarketMonth);
	let hedgeMarketCode = normalise(input.hedgeMarketCode);
	let hedgeMarketMonth = normalise(input.hedgeMarketMonth);
	if (priceType === UNPRICED) {
		hedgeMarketCode = null;
		derived.add("hedgeMarketCode");
	}
	const priceTypeDerivesCode = priceType === PRICED || priceType === UNPRICED || priceType === null;
	const grainFactorsHasRow = input.grainFactorsMarketCode !== null;
	if (priceTypeDerivesCode && grainFactorsHasRow) {
		derived.add("priceMarketCode");
		if (input.grainFactorsMarketCode !== void 0) priceMarketCode = normalise(input.grainFactorsMarketCode);
	}
	if (priceType === PRICED && priceMarketCode !== UNHEDGEABLE) {
		hedgeMarketCode = priceMarketCode;
		derived.add("hedgeMarketCode");
	}
	if (hedgeMarketCode === null) {
		hedgeMarketMonth = null;
		derived.add("hedgeMarketMonth");
	}
	if (hedgeMarketCode === UNHEDGEABLE && hedgeMarketMonth === null) {
		hedgeMarketMonth = "X";
		derived.add("hedgeMarketMonth");
	}
	if (priceType === PRICED && priceMarketCode !== UNHEDGEABLE && hedgeMarketCode !== null) {
		hedgeMarketMonth = priceMarketMonth;
		derived.add("hedgeMarketMonth");
	}
	return {
		priceMarketCode,
		priceMarketMonth,
		hedgeMarketCode,
		hedgeMarketMonth,
		derived: [...derived],
		pricesForbidden: priceType === DEFERRED || priceType === VARIABLE
	};
}
function normalise(value) {
	if (value === null || value === void 0) return null;
	const trimmed = value.trim().toUpperCase();
	return trimmed === "" ? null : trimmed;
}
const MAX_SHIP_PERIODS = 12;
const ShipPeriodIssueCode = {
	QuantityNotPositive: "QuantityNotPositive",
	BeginDateMissing: "BeginDateMissing",
	BeginDateInPast: "BeginDateInPast",
	EndBeforeBegin: "EndBeforeBegin",
	TooManyPeriods: "TooManyPeriods"
};
const ReconciliationState = {
	Balanced: "Balanced",
	Under: "Under",
	Over: "Over"
};
const QUANTITY_EPSILON = 1e-6;
function reconcileShipPeriods(rows, contractQuantity) {
	const allocated = rows.reduce((total, row) => total + (row.quantity ?? 0), 0);
	const target = contractQuantity ?? 0;
	const remaining = round(target - allocated);
	const state = Math.abs(remaining) < QUANTITY_EPSILON ? ReconciliationState.Balanced : remaining > 0 ? ReconciliationState.Under : ReconciliationState.Over;
	return {
		allocated: round(allocated),
		contractQuantity: target,
		remaining,
		state,
		summary: buildSummary(round(allocated), target, remaining, state)
	};
}
function buildSummary(allocated, target, remaining, state) {
	const base = `${format(allocated)} of ${format(target)} allocated`;
	if (state === ReconciliationState.Balanced) return `${base} — balanced`;
	if (state === ReconciliationState.Under) return `${base} — ${format(remaining)} remaining`;
	return `${base} — ${format(Math.abs(remaining))} over`;
}
function format(value) {
	return value.toLocaleString("en-US", { maximumFractionDigits: 3 });
}
function round(value) {
	return Number(value.toFixed(6));
}
function validateShipPeriods(rows, today = null) {
	const issues = [];
	if (rows.length > 12) issues.push({
		rowIndex: null,
		code: ShipPeriodIssueCode.TooManyPeriods,
		message: `A contract may have at most 12 ship periods.`
	});
	rows.forEach((row, rowIndex) => {
		if (isEmptyRow(row)) return;
		if (row.quantity === null || row.quantity <= 0) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.QuantityNotPositive,
			message: "Enter a quantity greater than zero."
		});
		if (row.beginDate === null) {
			issues.push({
				rowIndex,
				code: ShipPeriodIssueCode.BeginDateMissing,
				message: "Enter a begin date."
			});
			return;
		}
		if (today !== null && compareIsoDates(row.beginDate, today) < 0) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.BeginDateInPast,
			message: "The begin date cannot be in the past."
		});
		if (row.endDate !== null && compareIsoDates(row.endDate, row.beginDate) < 0) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.EndBeforeBegin,
			message: "The end date cannot be before the begin date."
		});
	});
	return issues;
}
function isEmptyRow(row) {
	return row.beginDate === null && row.endDate === null && (row.quantity === null || row.quantity === 0);
}
function nextShipPeriod(rows) {
	if (rows.length >= 12) return null;
	const anchor = lastAnchorDate(rows);
	if (anchor === null) return {
		beginDate: null,
		endDate: null,
		quantity: null
	};
	const nextMonthDay = addMonths(anchor, 1);
	if (nextMonthDay === null) return {
		beginDate: null,
		endDate: null,
		quantity: null
	};
	const beginDate = startOfMonth(nextMonthDay);
	return {
		beginDate,
		endDate: beginDate === null ? null : endOfMonth(beginDate),
		quantity: null
	};
}
function lastAnchorDate(rows) {
	let latest = null;
	for (const row of rows) {
		const candidate = row.endDate ?? row.beginDate;
		if (candidate !== null && (latest === null || candidate > latest)) latest = candidate;
	}
	return latest;
}
function hasOverlappingPeriods(rows) {
	const spans = rows.filter((row) => row.beginDate !== null).map((row) => ({
		begin: row.beginDate,
		end: row.endDate ?? row.beginDate
	})).sort((a, b) => a.begin < b.begin ? -1 : a.begin > b.begin ? 1 : 0);
	for (let index = 1; index < spans.length; index += 1) {
		const previous = spans[index - 1];
		const current = spans[index];
		if (previous !== void 0 && current !== void 0 && current.begin <= previous.end) return true;
	}
	return false;
}
const MAX_SHIP_PERIOD_DESCRIPTION_LENGTH = 200;
const MONTH_NAMES = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
function monthName(iso) {
	const parsed = fromIsoDate(iso);
	return parsed === null ? null : MONTH_NAMES[parsed.month - 1] ?? null;
}
function isFullMonth(begin, end) {
	return startOfMonth(begin) === begin && endOfMonth(begin) === end;
}
function sameMonth(begin, end) {
	return begin.slice(0, 7) === end.slice(0, 7);
}
function formatDayMonth(iso) {
	const parsed = fromIsoDate(iso);
	const name = monthName(iso);
	return parsed === null || name === null ? null : `${name} ${parsed.day}`;
}
function formatMonthYear(iso) {
	const parsed = fromIsoDate(iso);
	const name = monthName(iso);
	return parsed === null || name === null ? null : `${name} ${parsed.year}`;
}
function buildShipPeriodDescription(row) {
	if (row.beginDate === null) return null;
	const begin = row.beginDate;
	const body = describeSpan(begin, row.endDate ?? row.beginDate);
	if (body === null) return null;
	const prefix = row.shipPeriodTypeCode?.trim();
	const description = prefix ? `${prefix} ${body}` : body;
	return description.length > 200 ? description.slice(0, 200) : description;
}
function describeSpan(begin, end) {
	if (isFullMonth(begin, end)) return formatMonthYear(begin);
	const beginParsed = fromIsoDate(begin);
	const endParsed = fromIsoDate(end);
	if (beginParsed === null || endParsed === null) return null;
	if (sameMonth(begin, end)) {
		const name = monthName(begin);
		if (name === null) return null;
		return beginParsed.day === endParsed.day ? `${name} ${beginParsed.day}, ${beginParsed.year}` : `${name} ${beginParsed.day}-${endParsed.day}, ${beginParsed.year}`;
	}
	const beginText = formatDayMonth(begin);
	const endText = formatDayMonth(end);
	if (beginText === null || endText === null) return null;
	return beginParsed.year === endParsed.year ? `${beginText} - ${endText}, ${endParsed.year}` : `${beginText}, ${beginParsed.year} - ${endText}, ${endParsed.year}`;
}
var ConstraintCatalog = class ConstraintCatalog {
	document;
	constructor(document) {
		this.document = document;
	}
	static from(document) {
		return new ConstraintCatalog(document);
	}
	get version() {
		return this.document.version;
	}
	field(name) {
		return this.document.fields[name];
	}
	collection(name) {
		return this.document.collections[name];
	}
	collectionField(collection, name) {
		return this.document.collections[collection]?.fields[name];
	}
	nestedField(collection, arrayField, name) {
		return this.collectionField(collection, arrayField)?.fields?.[name];
	}
	static numeric(entry) {
		if (entry === void 0 || entry.type !== "number" && entry.type !== "integer") return;
		const { precision, scale } = entry;
		if (precision === void 0) return;
		const resolvedScale = scale ?? 0;
		return {
			precision,
			scale: resolvedScale,
			maxIntegerDigits: precision - resolvedScale,
			roundTripsLossily: entry.readPrecision !== void 0 && entry.readPrecision > precision || entry.readScale !== void 0 && entry.readScale > resolvedScale
		};
	}
	static isWritable(entry) {
		return entry !== void 0 && entry.access !== "readOnly";
	}
	static isReadable(entry) {
		return entry !== void 0 && entry.access !== "writeOnly";
	}
	isCollectionWritable(collection) {
		return this.document.collections[collection]?.writable ?? false;
	}
	readOnlyFieldNames() {
		return Object.entries(this.document.fields).filter(([, entry]) => entry.access === "readOnly").map(([name]) => name);
	}
	writeOnlyFieldNames() {
		return Object.entries(this.document.fields).filter(([, entry]) => entry.access === "writeOnly").map(([name]) => name);
	}
};
function constraintValidatorsFor(entry) {
	if (entry === void 0) return [];
	switch (entry.type) {
		case "string": return entry.maxLength === void 0 ? [] : [Validators.maxLength(entry.maxLength)];
		case "number":
		case "integer": {
			const numeric = ConstraintCatalog.numeric(entry);
			return numeric === void 0 ? [] : [precisionScale(numeric.precision, numeric.scale)];
		}
		case "array": return entry.maxItems === void 0 ? [] : [maxItems(entry.maxItems)];
		case "date": return [];
		default: return [];
	}
}
function precisionScale(precision, scale) {
	const maxIntegerDigits = precision - scale;
	return (control) => {
		const value = control.value;
		if (value === null || value === void 0 || value === "") return null;
		const asNumber = typeof value === "number" ? value : Number(value);
		if (!Number.isFinite(asNumber)) return null;
		const decimals = decimalsOf(asNumber);
		const integerDigits = integerDigitsOf(asNumber);
		if (decimals > scale) return { decimalPlaces: {
			max: scale,
			actual: decimals
		} };
		if (integerDigits > maxIntegerDigits) return { numericPrecision: {
			maxIntegerDigits,
			actualIntegerDigits: integerDigits,
			precision,
			scale
		} };
		return null;
	};
}
function maxItems(max) {
	return (control) => {
		const value = control.value;
		if (!Array.isArray(value)) return null;
		return value.length > max ? { maxItems: {
			max,
			actual: value.length
		} } : null;
	};
}
function decimalsOf(value) {
	if (Number.isInteger(value)) return 0;
	const text = Math.abs(value).toString();
	const [mantissa, exponent] = text.split("e-");
	if (exponent !== void 0) {
		const mantissaDecimals = mantissa?.split(".")[1]?.length ?? 0;
		return Number(exponent) + mantissaDecimals;
	}
	return text.split(".")[1]?.length ?? 0;
}
function integerDigitsOf(value) {
	const whole = Math.trunc(Math.abs(value));
	if (whole === 0) return 0;
	return BigInt(whole.toFixed(0)).toString().length;
}
function writableFields(payload, catalog) {
	const result = {};
	for (const [name, value] of Object.entries(payload)) {
		const entry = catalog.field(name);
		if (entry === void 0 || ConstraintCatalog.isWritable(entry)) result[name] = value;
	}
	return result;
}
function staticValidatorsFor(field) {
	const validators = [];
	const constraints = field.constraints;
	if (constraints?.maxLength !== void 0) validators.push(Validators.maxLength(constraints.maxLength));
	if (constraints?.minValue !== void 0) validators.push(Validators.min(constraints.minValue));
	if (constraints?.maxValue !== void 0) validators.push(Validators.max(constraints.maxValue));
	if (constraints?.allowsNegative === false) validators.push(Validators.min(0));
	if (constraints?.decimalPlaces !== void 0) validators.push(decimalPlaces(constraints.decimalPlaces));
	if (field.allowedValues !== void 0 && field.allowedValues.length > 0) validators.push(allowedValues(field.allowedValues.map((option) => option.code)));
	return validators;
}
function decimalPlaces(max) {
	return (control) => {
		const value = control.value;
		if (value === null || value === void 0 || value === "") return null;
		const asNumber = typeof value === "number" ? value : Number(value);
		if (!Number.isFinite(asNumber)) return null;
		const decimals = countDecimals(asNumber);
		return decimals > max ? { decimalPlaces: {
			max,
			actual: decimals
		} } : null;
	};
}
function countDecimals(value) {
	if (Number.isInteger(value)) return 0;
	const text = Math.abs(value).toString();
	if (text.includes("e-")) {
		const [, exponent] = text.split("e-");
		return Number(exponent ?? 0);
	}
	return text.split(".")[1]?.length ?? 0;
}
function allowedValues(codes) {
	const permitted = new Set(codes);
	return (control) => {
		const value = control.value;
		if (value === null || value === void 0 || value === "") return null;
		return permitted.has(String(value)) ? null : { allowedValues: { value } };
	};
}
const MAX_RECONCILE_PASSES = 8;
var FormBuilderService = class FormBuilderService {
	destroyRef = inject(DestroyRef);
	config = signal(null, ...ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []);
	tradeUnit = signal(null, ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	facts = signal(null, ...ngDevMode ? [{ debugName: "facts" }] : /* istanbul ignore next */ []);
	formValue = signal({ fields: {} }, ...ngDevMode ? [{ debugName: "formValue" }] : /* istanbul ignore next */ []);
	group = null;
	passes = 0;
	appliedRequired = /* @__PURE__ */ new Map();
	effectiveStates = computed(() => {
		const config = this.config();
		const tradeUnit = this.tradeUnit();
		const facts = this.facts();
		if (config === null || tradeUnit === null || facts === null) return /* @__PURE__ */ new Map();
		return evaluateRules(config, this.formValue(), tradeUnit, facts);
	}, ...ngDevMode ? [{ debugName: "effectiveStates" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const states = this.effectiveStates();
			untracked(() => this.reconcile(states));
		});
	}
	build(config, tradeUnit, facts) {
		const fields = new FormRecord({});
		for (const section of [...config.sections].sort((a, b) => a.order - b.order)) for (const field of [...section.fields].sort((a, b) => a.order - b.order)) fields.addControl(field.componentName, new FormControl(null, { validators: staticValidatorsFor(field) }));
		const group = new FormGroup({ fields });
		this.group = group;
		this.config.set(config);
		this.tradeUnit.set(tradeUnit);
		this.facts.set(facts);
		this.formValue.set(readFormValue(group));
		if (facts.isClosed || !facts.userCanEdit) group.disable({ emitEvent: false });
		group.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
			this.passes = 0;
			this.formValue.set(readFormValue(group));
		});
		return {
			group,
			value: this.formValue.asReadonly(),
			states: this.effectiveStates,
			fieldState: (componentName) => this.effectiveStates().get(componentName),
			control: (componentName) => fields.controls[componentName],
			seed: (values) => this.seed(group, fields, values)
		};
	}
	seed(group, fields, values) {
		let wrote = false;
		for (const [componentName, value] of Object.entries(values)) {
			const control = fields.controls[componentName];
			if (control === void 0) continue;
			control.setValue(value, { emitEvent: false });
			wrote = true;
		}
		if (!wrote) return;
		this.passes = 0;
		this.formValue.set(readFormValue(group));
	}
	reconcile(states) {
		const group = this.group;
		if (group === null || states.size === 0) return;
		this.passes += 1;
		if (this.passes > MAX_RECONCILE_PASSES) {
			console.error(`[FormBuilderService] Rule evaluation did not settle after ${MAX_RECONCILE_PASSES} passes — a rule is likely oscillating. Reconciliation stopped to avoid an infinite loop.`);
			return;
		}
		const fields = group.controls.fields;
		let changed = false;
		for (const [componentName, state] of states) {
			const control = fields.controls[componentName];
			if (control === void 0) continue;
			changed = this.applyValue(control, state) || changed;
			this.applyRequired(componentName, control, state);
		}
		if (changed) this.formValue.set(readFormValue(group));
	}
	applyValue(control, state) {
		const intent = state.valueIntent;
		let next;
		switch (intent.kind) {
			case "none": return false;
			case "blank":
				next = null;
				break;
			case "computed":
				next = intent.value;
				break;
			case "default":
				if (!isEmpty(control.value)) return false;
				next = intent.value;
		}
		if (Object.is(control.value, next)) return false;
		control.setValue(next, { emitEvent: false });
		return true;
	}
	applyRequired(componentName, control, state) {
		if (this.appliedRequired.get(componentName) === state.required) return;
		this.appliedRequired.set(componentName, state.required);
		const config = this.config();
		const field = config === null ? void 0 : findFieldConfig(config, componentName);
		if (field === void 0) return;
		const validators = staticValidatorsFor(field);
		if (state.required) validators.push(requiredValidator);
		control.setValidators(validators);
		control.updateValueAndValidity({ emitEvent: false });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FormBuilderService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FormBuilderService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: FormBuilderService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function readFormValue(group) {
	return { fields: group.getRawValue().fields };
}
function isEmpty(value) {
	return value === null || value === void 0 || value === "";
}
function requiredValidator(control) {
	return isEmpty(control.value) ? { required: true } : null;
}
function findFieldConfig(config, componentName) {
	for (const section of config.sections) {
		const match = section.fields.find((field) => field.componentName === componentName);
		if (match) return match;
	}
}
function withSavedCodeDescriptions(config, saved, mode) {
	if (saved.size === 0) return config;
	return {
		...config,
		sections: config.sections.map((section) => ({
			...section,
			fields: section.fields.map((field) => {
				const pair = saved.get(field.componentName);
				if (pair === void 0 || pair.code.trim() === "" || pair.description.trim() === "") return field;
				return mode === "view" ? asSaved(field, pair) : markedIfReplaced(field, pair);
			})
		}))
	};
}
function asSaved(field, pair) {
	return {
		...field,
		controlPattern: ControlPattern.SearchableCodeCombo,
		allowedValues: [{
			code: pair.code.trim(),
			description: pair.description.trim()
		}]
	};
}
function markedIfReplaced(field, pair) {
	const code = pair.code.trim();
	const option = (field.allowedValues ?? []).find((candidate) => candidate.code === code);
	if (option === void 0) return field;
	const savedText = normalised(pair.description);
	if (normalised(option.description).startsWith(savedText)) return field;
	return {
		...field,
		behaviour: {
			...field.behaviour,
			borderWarning: true
		},
		warningText: `Saving replaces the printed description “${pair.description.trim()}” with “${option.description.trim()}”.`
	};
}
function normalised(text) {
	return text.trim().replace(/\s+/g, " ").toUpperCase();
}
function validationMessageFor(errors) {
	if (errors === null) return null;
	const server = errors["server"];
	if (typeof server === "string" && server.trim() !== "") return server;
	if (errors["required"] !== void 0) return "Enter a value.";
	const maxLength = errors["maxlength"];
	if (maxLength?.requiredLength !== void 0) return `Use ${maxLength.requiredLength} characters or fewer.`;
	const decimals = errors["decimalPlaces"];
	if (decimals?.max !== void 0) return decimals.max === 0 ? "Enter a whole number." : `Use no more than ${decimals.max} decimal places.`;
	const min = errors["min"];
	if (min?.min !== void 0) return min.min === 0 ? "Enter a value of zero or more." : `Enter ${min.min} or more.`;
	const max = errors["max"];
	if (max?.max !== void 0) return `Enter ${max.max} or less.`;
	const digits = errors["numericPrecision"];
	if (digits?.maxIntegerDigits !== void 0) return digits.maxIntegerDigits === 0 ? "Enter a value below 1." : `Enter no more than ${digits.maxIntegerDigits} digits before the decimal point.`;
	const items = errors["maxItems"];
	if (items?.max !== void 0) return `Add no more than ${items.max} rows.`;
	if (errors["allowedValues"] !== void 0) return "Choose one of the listed values.";
	return "Check this value.";
}
const UNKNOWN_TEXT_MAX_LENGTH = 255;
var DynamicFieldComponent = class DynamicFieldComponent {
	field = input.required(...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	state = input.required(...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	control = input.required(...ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []);
	idPrefix = input("", ...ngDevMode ? [{ debugName: "idPrefix" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	patterns = ControlPattern;
	controlId = computed(() => `${this.idPrefix()}${this.field().componentName}`, ...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	controlEvents = toSignal(toObservable(this.control).pipe(switchMap((control) => control.events.pipe(startWith(null)))), { initialValue: null });
	errorMessage = computed(() => {
		this.controlEvents();
		const control = this.control();
		if (!control.touched || control.valid) return null;
		return validationMessageFor(control.errors);
	}, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	maxLength = computed(() => this.field().constraints?.maxLength ?? UNKNOWN_TEXT_MAX_LENGTH, ...ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []);
	allowedValues = computed(() => this.field().allowedValues ?? [], ...ngDevMode ? [{ debugName: "allowedValues" }] : /* istanbul ignore next */ []);
	unsupported = computed(() => {
		return ![
			ControlPattern.SearchableCodeCombo,
			ControlPattern.MaskedDate,
			ControlPattern.QuantityDecimal,
			ControlPattern.TextWithCounter,
			ControlPattern.MultilineNote,
			ControlPattern.ToggleFlag
		].includes(this.field().controlPattern);
	}, ...ngDevMode ? [{ debugName: "unsupported" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: DynamicFieldComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: DynamicFieldComponent,
		isStandalone: true,
		selector: "cms-dynamic-field",
		inputs: {
			field: {
				classPropertyName: "field",
				publicName: "field",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			state: {
				classPropertyName: "state",
				publicName: "state",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			control: {
				classPropertyName: "control",
				publicName: "control",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			idPrefix: {
				classPropertyName: "idPrefix",
				publicName: "idPrefix",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<!--\r\n  @if on visibility rather than [hidden] or a CSS class: a hidden-by-CSS field stays in the tab\r\n  sequence, and 02a §4.2 makes tab order an acceptance criterion. The FormControl still exists\r\n  either way, so the value survives a rule turning the field back on.\r\n-->\r\n@if (state().visible) {\r\n  @switch (field().controlPattern) {\r\n    @case (patterns.SearchableCodeCombo) {\r\n      <cms-code-combo\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [options]=\"allowedValues()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MaskedDate) {\r\n      <cms-date-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.QuantityDecimal) {\r\n      <!-- formula comes from the rules (BR-004), so it reads from state, not config. -->\r\n      <cms-quantity-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [decimalPlaces]=\"field().constraints?.decimalPlaces ?? 2\"\r\n        [allowNegative]=\"field().constraints?.allowsNegative ?? false\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [formula]=\"state().formula ?? null\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.TextWithCounter) {\r\n      <cms-text-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MultilineNote) {\r\n      <cms-note-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.ToggleFlag) {\r\n      <cms-toggle\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @default {\r\n      <!--\r\n        A pattern with no renderer yet (C2, C7, C8, C10, C11). Shown, labelled and named rather\r\n        than thrown or skipped: throwing takes down the whole form for one unimplemented field, and\r\n        skipping leaves an invisible control holding unsaveable data. Deliberately NOT falling back\r\n        to a text input — a date rendered as free text looks finished and never gets revisited.\r\n      -->\r\n      <!--\r\n        ⚠ `[labelFor]=\"false\"` because there is no control to point at. The default renders a\r\n        `<label for>`, and a label referencing an element that does not exist is worse than a plain\r\n        heading: it looks like an association and is not one.\r\n      -->\r\n      <cms-field [label]=\"field().label\" [controlId]=\"controlId()\" [labelFor]=\"false\">\r\n        <div\r\n          class=\"cws:rounded-lg cws:border cws:border-dashed cws:border-slate-300 cws:px-4 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:border-slate-600 cws:dark:text-slate-400\"\r\n          role=\"note\"\r\n        >\r\n          Control pattern {{ field().controlPattern }} is not implemented yet.\r\n        </div>\r\n      </cms-field>\r\n    }\r\n  }\r\n}\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: CodeComboComponent,
				selector: "cms-code-combo",
				inputs: [
					"label",
					"controlId",
					"options",
					"required",
					"readOnly",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: DateInputComponent,
				selector: "cms-date-input",
				inputs: [
					"label",
					"controlId",
					"required",
					"readOnly",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: NoteInputComponent,
				selector: "cms-note-input",
				inputs: [
					"label",
					"controlId",
					"maxLength",
					"rows",
					"required",
					"readOnly",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: QuantityInputComponent,
				selector: "cms-quantity-input",
				inputs: [
					"label",
					"controlId",
					"unitOfMeasure",
					"decimalPlaces",
					"allowNegative",
					"required",
					"readOnly",
					"formula",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: TextInputComponent,
				selector: "cms-text-input",
				inputs: [
					"label",
					"hideLabel",
					"controlId",
					"maxLength",
					"required",
					"readOnly",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: ToggleComponent,
				selector: "cms-toggle",
				inputs: [
					"label",
					"controlId",
					"onLabel",
					"offLabel",
					"required",
					"readOnly",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: FieldComponent,
				selector: "cms-field",
				inputs: [
					"label",
					"controlId",
					"required",
					"hideLabel",
					"errorMessage",
					"hint",
					"labelFor"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: DynamicFieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-dynamic-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ReactiveFormsModule,
				CodeComboComponent,
				DateInputComponent,
				NoteInputComponent,
				QuantityInputComponent,
				TextInputComponent,
				ToggleComponent,
				FieldComponent
			],
			template: "<!--\r\n  @if on visibility rather than [hidden] or a CSS class: a hidden-by-CSS field stays in the tab\r\n  sequence, and 02a §4.2 makes tab order an acceptance criterion. The FormControl still exists\r\n  either way, so the value survives a rule turning the field back on.\r\n-->\r\n@if (state().visible) {\r\n  @switch (field().controlPattern) {\r\n    @case (patterns.SearchableCodeCombo) {\r\n      <cms-code-combo\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [options]=\"allowedValues()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MaskedDate) {\r\n      <cms-date-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.QuantityDecimal) {\r\n      <!-- formula comes from the rules (BR-004), so it reads from state, not config. -->\r\n      <cms-quantity-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [decimalPlaces]=\"field().constraints?.decimalPlaces ?? 2\"\r\n        [allowNegative]=\"field().constraints?.allowsNegative ?? false\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [formula]=\"state().formula ?? null\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.TextWithCounter) {\r\n      <cms-text-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MultilineNote) {\r\n      <cms-note-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.ToggleFlag) {\r\n      <cms-toggle\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"field().warningText ?? null\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @default {\r\n      <!--\r\n        A pattern with no renderer yet (C2, C7, C8, C10, C11). Shown, labelled and named rather\r\n        than thrown or skipped: throwing takes down the whole form for one unimplemented field, and\r\n        skipping leaves an invisible control holding unsaveable data. Deliberately NOT falling back\r\n        to a text input — a date rendered as free text looks finished and never gets revisited.\r\n      -->\r\n      <!--\r\n        ⚠ `[labelFor]=\"false\"` because there is no control to point at. The default renders a\r\n        `<label for>`, and a label referencing an element that does not exist is worse than a plain\r\n        heading: it looks like an association and is not one.\r\n      -->\r\n      <cms-field [label]=\"field().label\" [controlId]=\"controlId()\" [labelFor]=\"false\">\r\n        <div\r\n          class=\"cws:rounded-lg cws:border cws:border-dashed cws:border-slate-300 cws:px-4 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:border-slate-600 cws:dark:text-slate-400\"\r\n          role=\"note\"\r\n        >\r\n          Control pattern {{ field().controlPattern }} is not implemented yet.\r\n        </div>\r\n      </cms-field>\r\n    }\r\n  }\r\n}\r\n"
		}]
	}],
	propDecorators: {
		field: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "field",
				required: true
			}]
		}],
		state: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "state",
				required: true
			}]
		}],
		control: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "control",
				required: true
			}]
		}],
		idPrefix: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "idPrefix",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}]
	}
});
export { AutoCalculationMode, CONTRACT_RULES, ConstraintCatalog, ContractComponent, ContractPrefixType, ControlPattern, DynamicFieldComponent, FormBuilderService, MAX_SHIP_PERIODS, MAX_SHIP_PERIOD_DESCRIPTION_LENGTH, NO_HEDGE_MONTH, PriceTypeCode, ReconciliationState, ShipPeriodIssueCode, allowedValues, autoCalculation, autoCalculationRule, brokerCompleteness, brokerCompletenessRule, buildShipPeriodDescription, computedValue, constraintValidatorsFor, decimalPlaces, defaultValue, evaluateRules, findField, hasOverlappingPeriods, isBlank, marketCascade, marketMonthRequiredness, marketMonthRequirednessRule, maxItems, nextShipPeriod, orderedFields, precisionScale, priceTypeStates, priceTypeStatesRule, readFormValue, readNumber, readString, reconcileShipPeriods, staticValidatorsFor, unitOfMeasureDefaulting, unitOfMeasureDefaultingRule, validateShipPeriods, validationMessageFor, valueIntentBlank, valueIntentNone, withSavedCodeDescriptions, writableFields };

//# sourceMappingURL=cws-shared-form-engine.mjs.map
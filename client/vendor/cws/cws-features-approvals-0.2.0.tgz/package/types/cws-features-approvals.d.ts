import { ApprovalActionResult, ApprovalContract, ApprovalEcmRequest, ContractListPage, ContractListQuery, ContractSummary } from "@cws/domain-contracts";
import { AppliedView, BreadcrumbCrumb, FilterGroup, GridColumn, GridRowAction, GridSort, RemoteData } from "@cws/shared-ui";
import * as i0 from "@angular/core";
import { CmsNavigationIntent } from "@cws/core-host-context";
/**
 * **The approval queue's summary metrics** — the workload, before the rows.
 *
 * ### 🔴 Two of the four asked-for metrics have no field behind them, and are DERIVED rather than
 * invented
 *
 * The brief asked for *High Priority Contracts* and *Contracts Expiring Soon*. **`ContractSummary`
 * carries no priority field and CTRM has none** — checked against the model and against
 * `constraints.json`'s field list, not assumed. A card reading "High priority: 0" over a field that
 * does not exist is the failure this repository has hit repeatedly: Known Issue 18, a wrong field
 * name that deserialises to `undefined` and renders as a plausible empty state.
 *
 * So both are replaced by derivations that are **real, stated on the card, and computed from data
 * the queue actually holds**:
 *
 * | Asked for | Built | From |
 * |---|---|---|
 * | High Priority Contracts | **Waiting over 7 days** | `contractDate` |
 * | Contracts Expiring Soon | **Shipping within 14 days** | `shipPeriodBegin` |
 *
 * ⚠ Age is the defensible stand-in for priority *on this screen specifically*: the queue arrives
 * sorted oldest-first because, as the column set already says, on an approval queue the oldest
 * contract is the one at risk. And an unapproved contract whose ship period opens shortly is
 * genuinely urgent — it cannot ship until it is approved.
 *
 * **If a real priority arrives from the business, replace the derivation rather than adding a fifth
 * card** — two competing notions of urgent on one screen is worse than either.
 *
 * ### ⚠ Quantity is NOT summed across units
 *
 * Every row carries its own `quantityUom`. Adding bushels to pounds produces a number that is
 * wrong by a factor of 56 and looks entirely plausible — the same class of error as the 2026-09-02
 * finding that CTRM stores pounds while the API returns bushels. Where the queue is one unit the
 * total is stated with it; where it is mixed the card **refuses to state a total**, because a
 * guessed figure is worse than an absent one.
 */
interface ApprovalMetric {
  /** Card heading. */
  readonly label: string;
  /** The figure, already formatted. `'—'` where no honest figure exists. */
  readonly value: string;
  /**
   * What the figure counts, in a few words.
   *
   * 🔴 **Not decoration on the derived cards.** "Waiting over 7 days" is this screen's definition
   * rather than a CTRM field, and a reader who assumes otherwise would take it to a conversation
   * with the business as though it were one.
   */
  readonly hint: string;
  /** Draws attention. Reserved for the two that mean "act on this", and only when non-zero. */
  readonly urgent?: boolean;
}
/** Contracts older than this many days count as having waited too long. */
declare const WAITING_DAYS = 7;
/** Ship periods opening within this many days count as imminent. */
declare const SHIPPING_DAYS = 14;
/**
 * Builds the four cards from the **matched** queue rather than the visible page.
 *
 * 🔴 **The whole queue, deliberately.** These exist to say how much work there is before the rows
 * are read, and a total that covered only page 1 would understate the workload while looking
 * authoritative — which is the same defect as a grid that sorts one page and presents it as sorted.
 *
 * ⚠ It is still bounded by what CTRM returned: `contract/list` caps its read (CR-4 / #31), so these
 * describe what was read. The queue's own footer carries that caveat and it is not repeated here.
 */
declare function approvalMetrics(rows: readonly ContractSummary[], today: Date): readonly ApprovalMetric[];
export declare class ApprovalsPageComponent {
  private readonly source;
  private readonly tradeUnit;
  /** Opening a review goes through the host (E9 PR 4, F9.10), so it stays inside a host's prefix. */
  private readonly hostContext;
  private readonly route;
  protected readonly columns: readonly import("@cws/shared-ui").GridColumn<ContractSummary>[];
  /**
   * 🔴 **Oldest-first by contract date — the OPPOSITE of the workspace grid's newest-first.**
   *
   * Stated in docs/02 §4.1 and worth a comment because the two grids will otherwise be assumed to
   * share a default. This is a *work* queue: the oldest unapproved contract is the most urgent, and
   * newest-first would bury it on the last page. Getting it backwards would not look like a defect —
   * it would look like a quiet queue.
   */
  /**
   * The state this screen was reached with, from the URL.
   *
   * 🔴 **Read from the URL so the breadcrumb can bring an approver back to where they were.** A row
   * opens the record screen carrying this queue's filters, sort, page and the contract number; the
   * crumb hands them back, this reads them, and the approver lands on the same row of the same page
   * of the same ordering. Held in signals alone — which is what it was — the queue reset to page 1
   * of an unfiltered oldest-first list on every return, and losing your place in a work queue is
   * exactly what makes people stop using it.
   *
   * From the snapshot: it describes the navigation that reached this screen. Subsequent filter and
   * sort changes live in the signals below and are re-packed on the next row activation.
   */
  private readonly initial;
  protected readonly sorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  /** Exposed for the Clear sort button, which hides itself while the sort still matches it. */
  protected readonly defaultSorts: readonly GridSort<string>[];
  /**
   * One free-text term, matched across **every column the grid renders**.
   *
   * 🔴 **This replaced the Trader, Commodity and Customer boxes** (JFrisbie, 2026-09-10). All three
   * are still reachable — they are columns — along with the eleven the boxes could not narrow on.
   *
   * ⚠ **Approver type deliberately stayed a dropdown.** It is a real CTRM request parameter and
   * there is **no approver-type column**, so a row search cannot express it: folding it in would have
   * removed the capability rather than relocating it. That is the trap the status control walked
   * into on the workspace, and it is worth one inconsistency on this bar to avoid it.
   */
  protected readonly searchTerm: import("@angular/core").WritableSignal<string>;
  protected readonly page: import("@angular/core").WritableSignal<number>;
  /** The row to re-focus on return, so the keyboard lands where the user left it. */
  protected readonly focusKey: import("@angular/core").WritableSignal<string | null>;
  /**
   * Bumped by Refresh so the same query genuinely re-issues.
   *
   * ⚠ **Corrected 2026-09-21: this used to say "rather than being served from cache", which read as
   * the SERVER's cache and was not true of it.** Bumping the counter re-issues the *observable* —
   * without it, an identical query emits nothing and the request is never made at all. It said
   * nothing about `CachedContractListReader`, which happily served the same rows for 60 seconds to
   * the re-issued request (#294).
   *
   * 🔴 **It now does both**, and this queue is the screen where it matters most: its entire premise
   * is that somebody else is changing the data while you look at it. See {@link data} for why the
   * bypass is derived from this number moving rather than carried as a flag.
   */
  private readonly attempt;
  protected readonly query: import("@angular/core").Signal<ContractListQuery>;
  private readonly data;
  /**
   * What the async container renders.
   *
   * 🔴 While the precondition is unmet the state is forced to `loaded` with an empty result, so the
   * container shows the empty state rather than a spinner that will never resolve. An indefinite
   * skeleton is how "you must choose something" gets mistaken for a hang -- and the screen issues no
   * request without a scope, so the read never completes to clear it.
   *
   * The workspace has done this since it was built; these screens rendered their own card instead,
   * which is what this replaces.
   */
  protected readonly containerState: import("@angular/core").Signal<RemoteData<ContractListPage>>;
  protected readonly result: import("@angular/core").Signal<ContractListPage | null>;
  /**
   * The queue: everything fetched, narrowed by the search and ordered.
   *
   * The search runs before the sort so the ordering is of the matched set rather than of the page,
   * which is what makes "oldest first" mean the oldest *match*.
   */
  protected readonly queue: import("@angular/core").Signal<ContractSummary[]>;
  /**
   * The workload summary, over the **matched queue** rather than the visible page.
   *
   * ⚠ `new Date()` is read here rather than inside {@link approvalMetrics}, which takes it as an
   * argument — so the derivation is a pure function with deterministic tests, and only this line
   * knows what day it is.
   */
  protected readonly metrics: import("@angular/core").Signal<readonly ApprovalMetric[]>;
  protected readonly pageSize = 50;
  /**
   * What the container says when it has nothing to show.
   *
   * 🔴 Two different absences, and they must not read alike: no trade unit means *nothing was
   * asked for*, while no rows means *the answer was empty*. A single "nothing here" for both tells
   * a user their queue is clear when the screen has not issued a request.
   */
  protected readonly emptyMessage: import("@angular/core").Signal<"Nothing is awaiting approval in this trade unit." | "Choose a trade unit in the top bar to load the approval queue.">;
  /**
   * The page, clamped to what exists.
   *
   * Narrowing the search can leave the requested page past the end of the queue, and an
   * out-of-range page renders an empty grid that reads as "no matches" when the matches are on
   * page 1.
   */
  protected readonly currentPage: import("@angular/core").Signal<number>;
  protected readonly rows: import("@angular/core").Signal<ContractSummary[]>;
  /**
   * True when the server had more unapproved contracts than it sent.
   *
   * The search cannot see past what was fetched, so this is what turns the count below the grid from
   * a claim about the queue into a claim about what was read. It is CTRM's 1,000-row ceiling
   * (CR-4 / #31) becoming visible rather than a new limit.
   */
  protected readonly moreThanOnePage: import("@angular/core").Signal<boolean>;
  protected readonly isRefreshing: import("@angular/core").Signal<boolean>;
  protected readonly isSimulated: import("@angular/core").Signal<boolean>;
  protected readonly warnings: import("@angular/core").Signal<readonly string[]>;
  /**
   * The one-line summary of each standing notice, and — because the panel counts these — the
   * number it reports.
   *
   * 🔴 **This list and the panel's projected content must stay in step.** The count comes from here
   * while the detail is projected markup, so a notice added to the template and not to this list is
   * a notice the header does not count and a collapsed reader never learns about. There is a spec
   * asserting the two agree for exactly that reason.
   *
   * ⚠ Order matches the template, and the conditional entries are conditional in both places: the
   * simulated-data line appears only when the data really is simulated, and the server's own
   * warnings are appended as they arrive.
   */
  protected readonly noticeSummaries: import("@angular/core").Signal<string[]>;
  /**
   * The customer directory is being refused by the field policy (#328, #240).
   *
   * 🔴 **Only `Redacted`.** `Unavailable` is transient and clears itself, `undefined` is an older
   * server saying nothing, and neither is worth a notice — see the workspace's copy of this for the
   * full reasoning, which is the same on both screens.
   *
   * ⚠ **This queue is the one where the gap is most visible**, and that is an argument for the notice
   * rather than against it: `?status=unapproved` is the one status whose CTRM projection carries
   * `customer_name` directly, so these rows normally show a real name from CTRM itself. A user who
   * sees ids here is looking at a column that worked yesterday.
   */
  protected readonly customerNamesRedacted: import("@angular/core").Signal<boolean>;
  /** True once the server echoes a sort chain, retiring the page-local caveat. */
  protected readonly serverSorted: import("@angular/core").Signal<boolean>;
  protected readonly hasTradeUnit: import("@angular/core").Signal<boolean>;
  protected readonly totalPages: import("@angular/core").Signal<number>;
  /**
   * Tracked on the contract NUMBER, not the row object.
   *
   * A refresh returns fresh objects for the same contracts, so identity tracking would tear down and
   * rebuild every row — losing the grid's cell selection and keyboard focus on each poll.
   */
  protected readonly trackByContract: (row: ContractSummary) => string;
  /**
   * The single row action: open the contract for review.
   *
   * 🔴 **Approve and Reject are gone from the grid** (JFrisbie, 2026-09-14), and this is a workflow
   * change rather than a cosmetic one. Deciding from a queue row means deciding from fourteen
   * columns — no terms, no document panel, no distribution list — and an approval has no inverse.
   * The decision now happens on the review screen, which shows what is being approved, keeps the
   * Portal's confirm tick, and states in the result itself that CTRM was not updated.
   *
   * ⚠ **The queue therefore holds no decision state at all any more.** Everything that tracked it —
   * per-contract pending/done/failed, the rejection-reason prompt, the outcome messages, the
   * refusal that stopped a second press — moved with the decision rather than being duplicated
   * beside it. A queue keeping its own copy would disagree with the review screen the first time
   * one of them learned something, which is the second-copy drift ADR-7 exists to prevent.
   *
   * ⚠ A **button**, not a link, because the **grid** stays presentational — these libraries render
   * inside foreign hosts, where the host owns routing. The page asks the host to navigate, through
   * `CMS_HOST_CONTEXT` (E9 PR 4, F9.10), never the root Router.
   *
   * 🔴 **Corrected 2026-09-21: this said `@cws/shared-ui` "deliberately takes no `@angular/router`
   * peer dependency", and that was factually wrong** — the peer has been declared in its
   * `package.json` all along, and `unsaved-changes.guard.ts` imports `CanDeactivateFn` from it. The
   * *reasoning* survives and the call is unchanged; what was wrong was the fact given for it, which
   * would have sent the next person looking for a constraint that does not exist. `cms-breadcrumb`
   * now uses `routerLink` in that library deliberately, because a breadcrumb **is** navigation —
   * which is the distinction this note was reaching for and stated as a blanket ban instead.
   */
  protected readonly rowActions: readonly GridRowAction<ContractSummary>[];
  /**
   * Opens the review screen for a contract.
   *
   * One method behind both the Review button and row activation, so the two cannot drift onto
   * different routes — which is exactly the kind of difference nobody notices until one of them
   * stops working.
   *
   * ✅ **It now carries `returnTo`** (JFrisbie, 2026-09-15), which is the change this method's own
   * remarks were waiting for. They read *"deliberately carries no `returnTo`… passing it here would
   * half-wire something nothing reads"* — true until the review screen's breadcrumb and Escape both
   * learned to unpack it, which they now do. **The two screens had to change together**, and that is
   * why it was left rather than done by halves.
   *
   * ⚠ **Two of this queue's three pieces of state are NOT in `query()`, and packing that alone would
   * silently return the user to the wrong place.** The queue fetches one large page and searches and
   * pages over it in process, so `query().page` is pinned to `1` and `query()` carries no `search`
   * at all — pack it verbatim and every return lands on page 1 with the search cleared, which looks
   * like the feature working until someone is on page 3. The displayed page and the search term come
   * from this screen's own signals instead.
   *
   * 🔑 Same shape, same reasoning and deliberately the same code as the pricing queue's
   * `onRowActivate`, which hit this first. If a third queue needs it, extract it rather than copying
   * it a second time.
   */
  private openReview;
  /**
   * `1–50 of 150`, matching the workspace grid's own footer label exactly.
   *
   * Same arithmetic rather than a shared helper: it is four lines over the page envelope, and the
   * envelope is the shared thing. ⚠ An en dash, not a hyphen — the workspace uses one and two
   * screens disagreeing about the separator reads as one of them being wrong.
   */
  protected readonly rangeLabel: import("@angular/core").Signal<string>;
  protected onSortChange(sorts: readonly GridSort[]): void;
  protected onSearch(term: string): void;
  /**
   * The filter rules, evaluated over every column this grid renders.
   *
   * Client-side, like the search beside it and for the same reason: this screen asks for one large
   * page precisely so a narrowing sees the whole queue rather than the slice it was handed.
   */
  protected readonly filter: import("@angular/core").WritableSignal<FilterGroup>;
  /** Which grid the saved views belong to — see {@link SAVED_FILTER_SCOPES}. */
  protected readonly savedFilterScope: "approvals";
  protected onRulesChange(group: FilterGroup): void;
  /**
   * A saved view: its rules, and its sorting where it has any.
   *
   * 🔴 **EVERY view clears the sort, the baseline included** (JFrisbie, 2026-09-16). `sort` is always
   * a chain and an empty one means "clear it", so what you see after selecting a view is what that
   * view is — it cannot depend on which view preceded it.
   */
  protected onViewChange(view: AppliedView): void;
  /**
   * Set when an export could not complete, so the failure is on screen rather than silent.
   *
   * ⚠ Rendered below the filter chips, **not** in the notices panel: that panel holds standing
   * conditions of the screen, and this is the outcome of something the user just did.
   */
  protected readonly exportError: import("@angular/core").WritableSignal<string | null>;
  /**
   * Names an export file — `approvals-0210-page-1.csv`.
   *
   * ⚠ An arrow property rather than a method, because it is passed to `cms-grid-export` as an input:
   * a plain method would arrive unbound and throw on the first export.
   */
  protected readonly exportFilename: (scope: "page" | "all") => string;
  /**
   * Every row the current search and filter match.
   *
   * ✅ **No request, and that is a property of this screen rather than a shortcut.** The queue
   * deliberately fetches one large page and narrows in the browser (see {@link query}), so the whole
   * matched set is already in memory — where the workspace has to walk the server a page at a time.
   * Same control, same two scopes, different cost, which is exactly why `cms-grid-export` takes a
   * resolver rather than an array.
   */
  protected readonly exportAllRows: () => Promise<readonly ContractSummary[] | null>;
  protected onPageStep(step: -1 | 1): void;
  protected onPage(page: number): void;
  protected refresh(): void;
  protected retry(): void;
  /**
   * One handler for both gestures — the grid emits `rowActivate` for a double-click and for Enter.
   *
   * 🔴 **Goes to the APPROVAL screen, not the record screen** (JFrisbie, 2026-09-14). Activating a
   * row from this queue means "I am deciding on this contract", and the destination is now the
   * screen that lets that happen — the modern replacement for the Contract Portal's `ctrctsapp`.
   *
   * It used to land on `/contracts/{n}` in view mode, which is §4.1's *"approval view of the full
   * contract (read-only)"* — read-only being the problem: the approver could see the contract and
   * then had to go elsewhere to act on it. The full record is still one click away from the new
   * screen for anyone who wants all 111 fields.
   *
   * ✅ **`returnTo` is carried again** (2026-09-15). This note used to record its absence as "a real
   * difference from the old behaviour" whose cost was losing the queue's place on the way back —
   * see {@link openReview}, which now packs it, and the review screen's breadcrumb and Escape, which
   * unpack it.
   */
  /** Double-click or Enter on a row — the same destination the Review button reaches. */
  protected onRowActivate(row: ContractSummary): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ApprovalsPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ApprovalsPageComponent, "cms-approvals-page", never, {}, {}, never, never, true, never>;
}
/** An address the contract would be sent to on approval. */
interface Recipient {
  readonly id: number;
  readonly email: string;
}
/**
 * **Approve a contract — the modern replacement for the Contract Portal's `ctrctsapp` screen.**
 *
 * Reached only from the approvals queue (`/approvals` → `/approvals/{number}`), mirroring
 * `pricing/{number}`. It is deliberately **not** the record screen with a panel bolted on: that
 * component already serves view, edit and create, and the legacy screen this replaces shows no field
 * grid at all — the contract *is* the document, and the approver is confirming terms they have
 * already seen in the queue.
 *
 * A link to the full record is on the page for anyone who needs all 111 fields.
 *
 * ### 🔴 Almost nothing here can reach CTRM yet, and the screen says so rather than implying it can
 *
 * This is a base screen built ahead of its APIs (JFrisbie, 2026-09-14). Each blocker is named where
 * the control is, not collected in a footnote, because a disabled control with no reason is the same
 * dead end as the failure it replaces:
 *
 * | Control | Why it cannot work yet |
 * |---|---|
 * | **Approve / Reject** | `approveContracts` has never succeeded through any transport — the origin `500`s with a Java `OutOfMemoryError` (#108) — and `trader_approval_status` is `readOnly`, so the proven upsert path refuses it too. Runs through {@link APPROVAL_ACTION_SOURCE}, which defaults to **simulated** and stamps every result with its origin. |
 * | **Document preview** | CR-7 (#23) — the Documents API is unpublished, so there is no way to fetch the PDF. The panel renders its unavailable state and names the change request. |
 * | **Email distribution** | `distribution_entry`, `copies` and `email_message` are members of CTRM's approval API (`aprvapih.rpgle`) and no published route exposes them. Rendered read-only. |
 * | **E-Sign status** | CTRM resolves `ECMNONESIGN<env>` per environment out of the `HTP001` DB2 table and calls it itself; we cannot read that table, so the warning is a standing caveat rather than a live status. |
 *
 * ⚠ **The one thing that would make this screen dangerous is reporting an approval that did not
 * happen.** The contract would stay unapproved in CTRM while the person accountable for approving it
 * has been told it is done, and nothing downstream would contradict them. So the origin of every
 * outcome is rendered, and a simulated approval says so in the result itself.
 */
export declare class ApprovalDetailPageComponent {
  private readonly contracts;
  private readonly approvals;
  private readonly permissions;
  /**
   * Every way off this screen — the crumb, Escape, Skip and View full record — goes through the host
   * (E9 PR 4, F9.10): its href and its click. Embedded, a routerLink to `/approvals` or `/contracts`
   * would leave the host's prefix.
   */
  private readonly hostContext;
  private readonly route;
  /**
   * The queue's packed state, from `?returnTo=`, or `null` when this screen was reached directly.
   *
   * Read from the **snapshot**, exactly as the record screen reads its own: it describes the journey
   * that reached this screen, so it cannot change while the screen is open.
   */
  private readonly returnTo;
  /**
   * Where the breadcrumb, Escape and Skip all go back to — the queue, in the state it was left in.
   *
   * 🔴 **One source for all three, which is the point rather than a tidy-up.** The record screen
   * records what happens when a shortcut and the crumb beside it disagree: the crumb returned an
   * approver to their queue while Escape moved them somewhere else, and *nothing looked broken* —
   * the queue was simply gone. Reading one computed is what makes that impossible here.
   *
   * ⚠ **Unpacked into an object rather than kept as a URL string**, so the crumb can stay a real
   * `routerLink` anchor: it keeps its `href`, so middle-click and open-in-new-tab work and a
   * keyboard user reaches it with Tab. A `(click)` handler calling `navigateByUrl` would look
   * identical and be none of those things.
   *
   * ⚠ An absent `returnTo` yields `{}`, which navigates to a bare `/approvals` — the old behaviour,
   * and the right one for a pasted link or a reload, where there is no journey to restore.
   */
  protected readonly returnParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * Query parameters for the "View full record" link, so the record screen's own breadcrumb comes
   * back to the queue rather than to the workspace.
   *
   * ⚠ **`from` is what the record screen reads to label and aim its crumb**, and it defaults to the
   * workspace when absent — so omitting it does not break anything visibly, it just quietly moves an
   * approver to a different screen. `returnTo` is passed straight through so the state survives the
   * extra hop.
   */
  protected readonly recordLinkParams: import("@angular/core").Signal<Record<string, string>>;
  /**
   * The screen this review was opened from, for the breadcrumb — **defaulting to the approvals
   * queue**, not to the workspace.
   *
   * 🔴 The crumb used to be a hard-coded `/approvals` back-link, which is right for the only journey
   * that exists today and wrong the moment a second one does — the exact defect `record-origin.ts`
   * was written for, one screen along. Reading `from` means a queue that links here with
   * `?from=pricing` gets a crumb saying **Pricing** that goes back to Pricing, rather than one that
   * says Approvals and silently moves the user.
   *
   * ⚠ **The fallback is `approvals` rather than the function's own `contracts` default**, because an
   * absent `from` on *this* screen means the approvals queue. Taking the default would send someone
   * who arrived by a pasted link to the workspace.
   */
  protected readonly origin: import("@angular/core").Signal<import("@cws/domain-contracts").RecordOriginDescriptor>;
  /**
   * The same origin by logical name, for the host. Resolved HERE, with this screen's `approvals`
   * fallback: the host's table falls back to the workspace, so passing the raw `from` would send a
   * pasted-link approver to the wrong screen (E9 PR 4).
   */
  private readonly originKey;
  /** Back to where the review was opened from, with its state: the crumb, Escape and Skip. */
  private readonly originIntent;
  /** The full record, telling it this review is behind it. */
  private readonly recordIntent;
  protected readonly recordHref: import("@angular/core").Signal<string>;
  /**
   * A click on one of this screen's links. A plain left click is handed to the host; a modified or
   * middle click is left to the browser, which opens the host's href (the record screen's shape).
   */
  protected follow(event: MouseEvent, intent: CmsNavigationIntent): void;
  protected followRecord(event: MouseEvent): void;
  /**
   * The trail back, as the shared breadcrumb takes it.
   *
   * ⚠ **One crumb, deliberately** — and for the same reason the pricing screen's is one:
   * `recordTrail`'s middle crumb for `approvals` is *this* screen, so calling it here would render a
   * link to the page the user is already on.
   */
  protected readonly crumbs: import("@angular/core").Signal<readonly BreadcrumbCrumb[]>;
  /**
   * The active trade unit, shown above the trail — the context the contract is scoped to.
   *
   * Same line, same placement and same reasoning as the record screen (JFrisbie, 2026-09-15), so the
   * two screens read alike when a user moves between them.
   */
  protected readonly tradeUnitLabel: import("@angular/core").Signal<string | null>;
  /** Bound from the route by `withComponentInputBinding()`. */
  readonly contractNumber: import("@angular/core").InputSignal<string>;
  private readonly attempt;
  private readonly loaded;
  protected readonly containerState: import("@angular/core").Signal<RemoteData<ApprovalContract>>;
  protected readonly contract: import("@angular/core").Signal<ApprovalContract | null>;
  protected readonly header: import("@angular/core").Signal<import("@cws/domain-contracts").ContractSummary | null>;
  /**
   * The customer name for the page header's description line.
   *
   * ⚠ **`null` rather than the id when the name is unusable** — the same call the contract record's
   * field list makes, and for the same reason: this is a *subtitle under a title*, not a Customer
   * column, so an id here would read as the customer's name rather than as an identifier standing in
   * for one. The rows below the header do fall back to the id, because there the label says
   * `Customer` and the neighbouring cells give it context.
   *
   * It also refuses the field policy's `[REDACTED]` literal (#328 criterion 4).
   */
  protected readonly customerName: import("@angular/core").Signal<string | null>;
  /**
   * The customer for a contract row in the terms panel, id-fallback included.
   *
   * @param row The row.
   * @returns What to print.
   */
  protected customerFor(row: {
    customerName: string | null;
    customerId: string | null;
  }): string;
  protected readonly isSimulated: import("@angular/core").Signal<boolean>;
  protected readonly warnings: import("@angular/core").Signal<readonly string[]>;
  /**
   * One line per standing notice, in the order the panel projects them.
   *
   * 🔴 **The order has to match the projected content**, because the collapsed lines are what a
   * reader uses to decide whether expanding is worth it — a summary list that reads in a different
   * order from the detail is a small, permanent puzzle. There is no mechanism enforcing that; it is
   * kept by putting the two next to each other in the template and this list in the same sequence.
   *
   * ⚠ **The e-sign caveat is unconditional and therefore first.** It is the one that does not
   * depend on the environment: it is true on live CTRM too, where "CTRM was not updated" is not.
   */
  protected readonly noticeSummaries: import("@angular/core").Signal<string[]>;
  protected readonly isRefreshing: import("@angular/core").Signal<boolean>;
  /**
   * Whether this caller may approve.
   *
   * ⚠ **Asks the approval capability rather than the write gate.** The two resolve to the same
   * `Admin` test today; asking the right question is what makes F1.3 a change to
   * `shell-permissions.ts` rather than a hunt through the screens.
   *
   * ⚠ Still ours, not CTRM's. CTRM has a per-location approval authority
   * that we cannot read — the legacy screen's *"You do NOT have authority to approve this
   * contract"* comes from `wnr051e`'s own check — so this is our nearest honest equivalent, and the
   * notice says which authority it is talking about rather than implying it is CTRM's.
   */
  protected readonly canApprove: import("@angular/core").Signal<boolean>;
  /**
   * The confirm tick, mirroring the legacy screen's *"Check Box then Click Here to Approve"*.
   *
   * 🔴 Kept rather than modernised away. Approval is irreversible on this estate — there is no
   * un-approve — so a single misplaced click being enough is the wrong default, and the one-gesture
   * version of this control is what the Portal deliberately does not have.
   */
  protected readonly confirmed: import("@angular/core").WritableSignal<boolean>;
  /** The outcome of the last decision, or `null` before one is made. */
  protected readonly outcome: import("@angular/core").WritableSignal<ApprovalActionResult | null>;
  protected readonly failure: import("@angular/core").WritableSignal<string | null>;
  protected readonly isDeciding: import("@angular/core").WritableSignal<boolean>;
  protected readonly rejectOpen: import("@angular/core").WritableSignal<boolean>;
  protected readonly rejectReason: import("@angular/core").WritableSignal<string>;
  /**
   * Who the contract would be emailed to on approval.
   *
   * 🔴 **Empty, and that is the truthful answer rather than a placeholder.** The legacy screen reads
   * this list out of CTRM's own distribution table; nothing we can call exposes it, and
   * `ContractSummary` carries no email address — the fields are `customerId`, `customerName`,
   * `customerContract` and no more.
   *
   * ⚠ The first version of this screen seeded it from `header.customerEmail`, **a field that does
   * not exist**. It would have compiled, deserialised to `undefined` and rendered an empty list —
   * indistinguishable from this, and wrong for a reason nobody could see. That is Known Issue 18
   * exactly: a wrong field name fails silently here.
   *
   * Rendered rather than hidden because the approver needs to know that *nobody* is currently on the
   * list, which is a different statement from the section being absent.
   */
  protected readonly recipients: import("@angular/core").Signal<readonly Recipient[]>;
  /** The addresses the approver typed. Starts from {@link recipients}, which CTRM cannot supply. */
  protected readonly ecmRecipients: import("@angular/core").WritableSignal<readonly string[]>;
  protected readonly ecmCopies: import("@angular/core").WritableSignal<number>;
  protected readonly ecmMessage: import("@angular/core").WritableSignal<string>;
  protected readonly ecmEsign: import("@angular/core").WritableSignal<boolean>;
  protected readonly ecmEsignOverride: import("@angular/core").WritableSignal<boolean>;
  protected readonly maxRecipients = 4;
  /** The recipient being typed, before it joins the list. */
  protected readonly recipientDraft: import("@angular/core").WritableSignal<string>;
  /**
   * Why another recipient cannot be added, or `null`.
   *
   * 🔴 **Four is a structural limit, not a policy.** CTRM's approval API declares
   * `distribution_entry` as four slots, so a fifth has nowhere to go — the screen refuses before
   * sending rather than letting CTRM decide, because an approval is the write with the least
   * tolerance for a silent partial success on this estate.
   */
  protected readonly recipientRefusal: import("@angular/core").Signal<string | null>;
  protected readonly canAddRecipient: import("@angular/core").Signal<boolean>;
  protected onRecipientDraft(value: string): void;
  protected addRecipient(): void;
  protected removeRecipient(address: string): void;
  protected onEcmMessage(value: string): void;
  protected onEcmCopies(value: string): void;
  protected toggleEsign(value: boolean): void;
  protected toggleEsignOverride(value: boolean): void;
  /**
   * Whether the panel is editable.
   *
   * 🔴 **Read-only once e-sign is set** (umbrella issue criterion 5). An e-signed contract's
   * distribution is CTRM's to manage from that point, and editing it here would produce a payload
   * CTRM ignores while the screen showed it as sent.
   */
  protected readonly ecmEditable: import("@angular/core").Signal<boolean>;
  /** The payload the approval carries, or `undefined` when there is nothing to send. */
  protected ecmRequest(): ApprovalEcmRequest | undefined;
  /**
   * Why the printer row is unavailable (#291).
   *
   * ⚠ **Shown and disabled rather than hidden.** The legacy Portal had printer routing on this
   * panel, and an approver who used it needs to know it is gone rather than wonder where it went —
   * an absent control reads as a rendering fault, a disabled one with a reason reads as a decision.
   */
  protected readonly printerUnavailable: string;
  /** CTRM's own default wording, carried across so it does not drift from the Portal's. */
  protected readonly canSubmit: import("@angular/core").Signal<boolean>;
  protected refresh(): void;
  protected retry(): void;
  /**
   * Leaves without deciding — the legacy *Skip*.
   *
   * Returns to the queue rather than advancing to the next contract. Auto-advance is what the green
   * screen does because it has a cursor through a work list; this queue is a grid the user chose a
   * row from, and landing them on a different contract than the one they skipped is how the wrong
   * contract gets approved.
   */
  /**
   * Back to the queue without deciding — and **in the state it was left in**, like the breadcrumb.
   *
   * ⚠ Skip is the one of the three that is not obviously navigation, so it is the one most likely to
   * be left behind on a change like this. Returning an approver to an unfiltered page 1 after they
   * skipped one contract is how a work queue loses someone's place mid-session.
   */
  protected skip(): void;
  /**
   * **Escape goes where the breadcrumb goes.** Same destination, same parameters, one method.
   *
   * ### Why the `defaultPrevented` guard is the whole design
   *
   * This is a *document* listener, so it fires wherever focus is — and this screen can have the
   * shell's identity menu or trade-unit picker open over it, both of which dismiss on Escape via
   * `DropdownDirective`'s own document listener. Without the guard, pressing Escape to close a menu
   * would close it **and** navigate off the contract. The directive marks the event handled when it
   * actually dismissed something, and this stands down when it sees that.
   *
   * ⚠ **It relies on the shell's listeners being registered first**, which holds because the shell
   * renders before the router activates a route into it, and document listeners on the same phase
   * fire in registration order. A future overlay created *after* this component has to mark its own
   * Escape handled — that is the contract, not the ordering.
   *
   * ⚠ **No mode guard here, unlike the record screen's**, and the difference is deliberate: that one
   * is `isView()`-only because Escape in edit mode would discard typed changes without confirmation.
   * This screen has no form to lose — the terms are read-only and the decision needs a ticked
   * confirmation and a button press, neither of which Escape can trigger. 🔴 **If an editable field
   * is ever added here, this needs the same guard.**
   */
  protected onEscape(event: Event): void;
  /**
   * The single navigation behind the breadcrumb's destination, Escape and Skip.
   *
   * The breadcrumb itself is a real anchor rather than a call to this — an anchor is what gives it an
   * `href`, middle-click and Tab — but it carries the same {@link originIntent}, so the three cannot
   * drift onto different destinations. Through the host since E9 PR 4 (F9.10).
   */
  private returnToQueue;
  protected openReject(): void;
  protected cancelReject(): void;
  protected approve(): void;
  protected reject(): void;
  private submit;
  /**
   * Turns a failure into something an approver can act on.
   *
   * 🔴 **A 404 is called out by name, and says where to finish the job.** The live route is not
   * published, so a bare "could not record that decision" reads as a permissions or network problem
   * — sending someone to check access they already hold, rather than telling them the capability is
   * absent and the approval still has to happen on the green screen.
   *
   * ⚠ **Carried over from the queue when the decision moved here** (2026-09-14). The queue used to
   * own this wording; deleting its decision machinery would otherwise have quietly dropped the one
   * message that tells an approver what to do next.
   */
  private describeFailure;
  protected onConfirmChange(checked: boolean): void;
  protected onRejectReason(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<ApprovalDetailPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ApprovalDetailPageComponent, "cms-approval-detail-page", never, {
    "contractNumber": {
      "alias": "contractNumber";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * The approval queue's columns — **the fourteen docs/02 §4.1 names, in its order**.
 *
 * 🔴 **Two of these carry data the home grid structurally cannot show, and that is the reason this
 * is a separate column set rather than a filter over `CONTRACT_GRID_COLUMNS`.**
 * `?status=unapproved` is a *different CTRM procedure* — `getUnapprovedContracts` returning `dsCon`,
 * not `OpenDS` — and it populates **`customer_name`** and **`trader_initials`**, which no other
 * published route does (#47, #107). So Customer reads as a name here and as an id on the workspace,
 * from the same `ContractSummary` type.
 *
 * ⚠ **The inverse is also true and is the trap: this row is NARROWER than the home grid's.** `dsCon`
 * carries no status, market or shipment *status* data, so a column copied across from the workspace
 * would render blank for every row and read as missing data. Everything below was checked against
 * `ContractSummary`'s own remarks about which status populates it — do not add a column here on the
 * strength of it working on the home screen.
 *
 * Formatters are **imported, never re-implemented**: a quantity rendered `1,875,000` on one screen
 * and `1,875,000.00` on another reads as two different numbers.
 *
 * ### ⚠ Every column reads the same weight, deliberately
 *
 * Four of these were briefly emphasised — customer, commodity, quantity, price — on the argument
 * that fourteen equally loud columns give the eye nowhere to start. **Reversed** (JFrisbie,
 * 2026-09-14): a grid that weights some of its own columns is a grid making a judgement on the
 * reader's behalf, and which four matter is not the same for every approver. Uniform is the
 * standard here; the affordances that order attention are sort, filter and column width.
 *
 * Do not reintroduce per-column weight or colour on one screen — it would be the only grid in the
 * application that does it, which is how two grids stop reading as the same tool.
 */
/** `Primary` / `Secondary`, from the queue's own filter rather than the row. */
export type ApproverType = '' | 'Primary' | 'Secondary';
export declare const APPROVAL_GRID_COLUMNS: readonly GridColumn<ContractSummary>[];
/**
 * ⚠ **There is deliberately NO confirmation indicator here, and no approval-status column.**
 *
 * docs/02 §4.4 / BR-065's three-part indicator (Approved → Customer ✓ → Broker ✓) belongs to the
 * *views*, and it **already exists** — `CONFIRMATION_STAGES` in
 * `@cws/features-contract-summary`'s `contract-detail.fields.ts` renders exactly those three stages
 * from exactly those three fields, on the record screen a queue row opens. A second derivation of
 * the same three fields here would be the second-copy drift ADR-7 exists to prevent, and the two
 * would disagree the first time one of them learned something.
 *
 * §4.1's column list also has no approval-status column, and it should not: **every row in this
 * queue is unapproved by definition**, so the column would be one repeated value — the same reason
 * the workspace grid has no trade-unit column and this one does.
 */
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, HostListener, computed, inject, input, signal } from "@angular/core";
import { toObservable, toSignal } from "@angular/core/rxjs-interop";
import { ActivatedRoute } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { APPROVAL_ACTION_SOURCE, APPROVAL_CONTRACT_SOURCE, CONTRACT_LIST_SOURCE, ConfirmationProgressComponent, DEFAULT_PAGE_SIZE, MAX_ECM_RECIPIENTS, MAX_PAGE_SIZE, RECORD_ORIGIN_PARAM, customerDisplayName, formatContractDate, formatPrice, formatQuantity, formatShipPeriod, formatShortDate, fromRouteParams, injectTradeUnitLabel, recordOrigin, recordOriginKey, toRouteParams, toSortParam, wholeDaysBetween } from "@cws/domain-contracts";
import { AsyncContainerComponent, BreadcrumbComponent, ClearSortButtonComponent, DataGridComponent, EMPTY_FILTER, FilterBuilderComponent, FilterSelectComponent, GridExportComponent, GridToolbarComponent, NoticesPanelComponent, PageHeaderComponent, PagerComponent, RefreshButtonComponent, SAVED_FILTER_SCOPES, SearchShortcutDirective, compareBySorts, matchesGroup, matchesSearch, remoteLoading } from "@cws/shared-ui";
import { scan, switchMap } from "rxjs";
import { DecimalPipe } from "@angular/common";
function totalQuantity(rows) {
	const quantified = rows.filter((row) => row.quantity !== null);
	const units = new Set(quantified.map((row) => row.quantityUom ?? "").filter((unit) => unit !== ""));
	if (units.size > 1) return {
		value: "—",
		hint: `Mixed units (${[...units].sort().join(", ")}) — no single total`
	};
	const total = quantified.reduce((sum, row) => sum + (row.quantity ?? 0), 0);
	const unit = [...units][0] ?? "";
	return {
		value: `${formatQuantity(total)}${unit === "" ? "" : ` ${unit}`}`,
		hint: quantified.length === rows.length ? "Across the queue" : "Excludes unquantified contracts"
	};
}
function approvalMetrics(rows, today) {
	const quantity = totalQuantity(rows);
	const waiting = rows.filter((row) => {
		const age = wholeDaysBetween(row.contractDate, today);
		return age !== null && age > 7;
	}).length;
	const shipping = rows.filter((row) => {
		const until = wholeDaysBetween(row.shipPeriodBegin, today);
		return until !== null && until >= -14;
	}).length;
	return [
		{
			label: "Pending approvals",
			value: `${rows.length}`,
			hint: "Awaiting your decision"
		},
		{
			label: "Total quantity",
			value: quantity.value,
			hint: quantity.hint
		},
		{
			label: `Waiting over 7 days`,
			value: `${waiting}`,
			hint: "By contract date — CTRM has no priority field",
			urgent: waiting > 0
		},
		{
			label: `Shipping within 14 days`,
			value: `${shipping}`,
			hint: "Ship period opens soon or has opened",
			urgent: shipping > 0
		}
	];
}
function formatCustomer(row) {
	return customerDisplayName(row.customerName, row.customerId);
}
function formatOriginDestination(row) {
	const origin = row.originName ?? "";
	const destination = row.destinationName ?? "";
	if (origin && destination) return `${origin} → ${destination}`;
	return origin || destination;
}
const APPROVAL_GRID_COLUMNS = [
	{
		key: "tradeUnit",
		header: "Trade Unit",
		sortable: true,
		width: 120,
		format: (row) => row.tradeUnit ?? ""
	},
	{
		key: "contractNumber",
		header: "Contract",
		sortable: true,
		width: 130,
		format: (row) => row.contractNumber
	},
	{
		key: "contractDate",
		header: "Date",
		sortable: true,
		width: 90,
		format: (row) => formatShortDate(row.contractDate),
		sortValue: (row) => row.contractDate ?? "",
		tooltip: (row) => formatContractDate(row.contractDate)
	},
	{
		key: "customerName",
		header: "Customer",
		sortable: true,
		width: 200,
		format: formatCustomer
	},
	{
		key: "commodity",
		header: "Commodity",
		sortable: true,
		width: 150,
		format: (row) => row.commodity ?? ""
	},
	{
		key: "customerContract",
		header: "Customer Contract",
		sortable: true,
		width: 175,
		format: (row) => row.customerContract ?? ""
	},
	{
		key: "shipPeriodBegin",
		header: "Ship Period",
		sortable: true,
		width: 150,
		format: formatShipPeriod,
		sortValue: (row) => row.shipPeriodBegin ?? ""
	},
	{
		key: "originName",
		header: "Origin / Destination",
		sortable: true,
		width: 200,
		format: formatOriginDestination,
		sortValue: (row) => row.originName ?? ""
	},
	{
		key: "quantity",
		header: "Quantity",
		align: "end",
		sortable: true,
		width: 130,
		format: (row) => row.quantity === null ? "" : `${formatQuantity(row.quantity)} ${row.quantityUom ?? ""}`.trim(),
		sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "price",
		header: "Price",
		align: "end",
		sortable: true,
		width: 110,
		format: (row) => formatPrice(row.price),
		sortValue: (row) => row.price ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "basisPrice",
		header: "Basis Price",
		align: "end",
		sortable: true,
		width: 110,
		format: (row) => formatPrice(row.basisPrice),
		sortValue: (row) => row.basisPrice ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "paymentTerms",
		header: "Payment Terms",
		sortable: true,
		width: 150,
		format: (row) => row.paymentTerms ?? ""
	},
	{
		key: "marketZone",
		header: "Market Zone",
		sortable: true,
		width: 110,
		format: (row) => row.marketZone ?? ""
	},
	{
		key: "trader",
		header: "Trader",
		sortable: true,
		width: 140,
		format: (row) => row.trader ?? row.traderInitials ?? ""
	}
];
const DEFAULT_SORTS = [{
	key: "contractDate",
	direction: "asc"
}];
var ApprovalsPageComponent = class ApprovalsPageComponent {
	source = inject(CONTRACT_LIST_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	columns = APPROVAL_GRID_COLUMNS;
	initial = fromRouteParams(this.route.snapshot.queryParamMap);
	sorts = signal(this.route.snapshot.queryParamMap.get("sort") === null ? DEFAULT_SORTS : this.initial.sorts, ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	defaultSorts = DEFAULT_SORTS;
	searchTerm = signal(this.initial.query.search ?? "", ...ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []);
	page = signal(this.initial.query.page, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	focusKey = signal(this.initial.focus, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	query = computed(() => {
		return {
			status: "Unapproved",
			...this.tradeUnit.code() === null ? {} : { tradeUnit: this.tradeUnit.code() },
			sort: toSortParam(this.sorts()),
			page: 1,
			pageSize: MAX_PAGE_SIZE
		};
	}, ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	data = toSignal(toObservable(computed(() => ({
		query: this.query(),
		attempt: this.attempt()
	}))).pipe(scan((previous, next) => ({
		...next,
		refresh: next.attempt !== previous.attempt
	}), {
		query: this.query(),
		attempt: 0,
		refresh: false
	}), switchMap(({ query, refresh }) => this.source.list(query, { refresh }))), { initialValue: remoteLoading() });
	containerState = computed(() => this.hasTradeUnit() ? this.data() : {
		status: "loaded",
		value: emptyPage(this.query())
	}, ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	result = computed(() => {
		const state = this.data();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "result" }] : /* istanbul ignore next */ []);
	queue = computed(() => {
		const term = this.searchTerm();
		const group = this.filter();
		const matched = (this.result()?.rows ?? []).filter((row) => matchesGroup(row, this.columns, group) && matchesSearch(row, this.columns, term));
		const sorts = this.sorts();
		return sorts.length === 0 ? matched : [...matched].sort((left, right) => compareBySorts(this.columns, sorts, left, right));
	}, ...ngDevMode ? [{ debugName: "queue" }] : /* istanbul ignore next */ []);
	metrics = computed(() => approvalMetrics(this.queue(), /* @__PURE__ */ new Date()), ...ngDevMode ? [{ debugName: "metrics" }] : /* istanbul ignore next */ []);
	pageSize = DEFAULT_PAGE_SIZE;
	emptyMessage = computed(() => this.hasTradeUnit() ? "Nothing is awaiting approval in this trade unit." : "Choose a trade unit in the top bar to load the approval queue.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	currentPage = computed(() => Math.min(Math.max(this.page(), 1), this.totalPages()), ...ngDevMode ? [{ debugName: "currentPage" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const start = (this.currentPage() - 1) * this.pageSize;
		return this.queue().slice(start, start + this.pageSize);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	moreThanOnePage = computed(() => (this.result()?.totalPages ?? 1) > 1, ...ngDevMode ? [{ debugName: "moreThanOnePage" }] : /* istanbul ignore next */ []);
	isRefreshing = computed(() => this.data().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => this.result()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.result()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [
		"Scoped to one trade unit",
		"Approvals do not update CTRM",
		...this.isSimulated() ? ["Simulated rows, not read from CTRM"] : [],
		...this.customerNamesRedacted() ? ["Customer names are unavailable"] : [],
		...this.warnings()
	], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	customerNamesRedacted = computed(() => this.result()?.customerNames === "Redacted", ...ngDevMode ? [{ debugName: "customerNamesRedacted" }] : /* istanbul ignore next */ []);
	serverSorted = computed(() => (this.result()?.appliedSort ?? null) !== null, ...ngDevMode ? [{ debugName: "serverSorted" }] : /* istanbul ignore next */ []);
	hasTradeUnit = computed(() => {
		const code = this.tradeUnit.code();
		return code !== null && code !== "";
	}, ...ngDevMode ? [{ debugName: "hasTradeUnit" }] : /* istanbul ignore next */ []);
	totalPages = computed(() => Math.max(1, Math.ceil(this.queue().length / DEFAULT_PAGE_SIZE)), ...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	trackByContract = (row) => row.contractNumber;
	rowActions = [{
		label: "Review",
		tone: "primary",
		run: (row) => this.openReview(row)
	}];
	openReview(row) {
		const params = toRouteParams(this.query(), this.sorts(), row.contractNumber);
		const search = this.searchTerm().trim();
		const returnTo = new URLSearchParams({
			...params,
			...search === "" ? {} : { search },
			...this.currentPage() > 1 ? { page: String(this.currentPage()) } : {}
		}).toString();
		this.hostContext.navigate({
			kind: "review",
			origin: "approvals",
			contractNumber: row.contractNumber,
			params: { returnTo }
		});
	}
	rangeLabel = computed(() => {
		const total = this.queue().length;
		if (total === 0) return "";
		return `${(this.currentPage() - 1) * this.pageSize + 1}–${Math.min(this.currentPage() * this.pageSize, total)} of ${total}`;
	}, ...ngDevMode ? [{ debugName: "rangeLabel" }] : /* istanbul ignore next */ []);
	onSortChange(sorts) {
		this.sorts.set(sorts);
	}
	onSearch(term) {
		this.searchTerm.set(term);
		this.page.set(1);
	}
	filter = signal(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	savedFilterScope = SAVED_FILTER_SCOPES.approvals;
	onRulesChange(group) {
		this.filter.set(group);
		this.page.set(1);
	}
	onViewChange(view) {
		this.filter.set(view.group);
		this.sorts.set(view.sort);
		this.page.set(1);
	}
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportFilename = (scope) => {
		return `approvals-${this.tradeUnit.code() ?? "all"}-${scope === "page" ? `page-${this.currentPage()}` : "all"}`;
	};
	exportAllRows = () => Promise.resolve(this.queue());
	onPageStep(step) {
		this.page.set(Math.min(Math.max(this.currentPage() + step, 1), this.totalPages()));
	}
	onPage(page) {
		this.page.set(page);
	}
	refresh() {
		this.attempt.update((value) => value + 1);
	}
	retry() {
		this.refresh();
	}
	onRowActivate(row) {
		this.openReview(row);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ApprovalsPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ApprovalsPageComponent,
		isStandalone: true,
		selector: "cms-approvals-page",
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    title=\"Approvals\"\r\n    description=\"Contracts awaiting trader approval, oldest first.\"\r\n  />\r\n\r\n  <!--\r\n    🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-14). This was three\r\n    full-width banners plus one per server warning, ahead of the first row of the work queue.\r\n\r\n    Every one of them is still here and still true — the panel states how many there are, summarises\r\n    each in a line, and shows them in full on demand. What changed is that the queue now opens with\r\n    the queue.\r\n\r\n    ⚠ **The CTRM-is-not-updated warning can be de-emphasised HERE only because the decision moved.**\r\n    It was unconditional and loud because Approve and Reject sat in the grid immediately below it,\r\n    and an approval falsely believed to be done is the worst outcome this screen can produce. The\r\n    decision now happens on the review screen, which states the same thing at the point of action\r\n    and in the result itself. Collapsing it here without that move would have been a real loss of\r\n    safety rather than a tidy-up.\r\n  -->\r\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n    <!--\r\n      🔴 The scope statement. BR-060 scopes this queue to the approver's own approval locations plus\r\n      the ones they back up; that needs `traderLocations` and `backupApprovers`, two CTRM reads that\r\n      work and that no endpoint publishes. So what is on screen is ONE trade unit.\r\n\r\n      An approver whose remit spans four locations would otherwise see one location's queue, find it\r\n      short, and reasonably conclude there was nothing to approve. A silently narrow work queue is\r\n      worse than an empty one.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Showing one trade unit, not your full approver remit</div>\r\n      <div class=\"scoular-alert-description\">\r\n        This queue is scoped to the trade unit selected above. Approver-based scoping needs two CTRM\r\n        reads that are not published yet, so <strong>contracts awaiting you in other trade units are\r\n        not listed here</strong> — switch trade unit to see them.\r\n      </div>\r\n    </div>\r\n\r\n    <!--\r\n      The capability warning. Two independent blockers, both checked against the authorities:\r\n\r\n        1. `approveContracts` has never succeeded through any transport — the origin OOMs building\r\n           its output parameters (issue 108) — and the API publishes no approval route.\r\n        2. `trader_approval_status` is `\"access\": \"readOnly\"` in `constraints.json`, so the proven\r\n           contract-upsert path refuses it rather than ignoring it.\r\n\r\n      ⚠ **The description below deliberately names NEITHER blocker.** It used to carry both CTRM\r\n      identifiers in `<code>` and a live link into our issue tracker, which is three things a trader\r\n      can neither act on nor reach — and the link implied a status they could go and check. What a\r\n      trader needs from this box is the consequence and the alternative; the mechanism is above, for\r\n      whoever maintains the screen.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">\r\n        Approvals are recorded in this session only — CTRM is not updated\r\n      </div>\r\n      <div class=\"scoular-alert-description\">\r\n        Decisions taken on the review screen <strong>do not reach CTRM</strong>, which cannot yet\r\n        accept an approval from this application. They are <strong>lost on reload</strong> and must\r\n        still be completed on the green screen. Use this queue to review and decide; record the\r\n        decision in CTRM as you do today.\r\n      </div>\r\n    </div>\r\n\r\n    @if (isSimulated()) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Simulated data</div>\r\n        <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\r\n      </div>\r\n    }\r\n\r\n    @if (customerNamesRedacted()) {\r\n      <!--\r\n        🔴 The customer directory is refusing us (#328). Same notice as the workspace, and it belongs\r\n        here more than there: this is the one status whose CTRM projection carries a customer name\r\n        directly, so ids in this column are a column that worked yesterday.\r\n\r\n        ⚠ Names no internal identifier, per the 2026-09-17 copy guard, and leads with what is still\r\n        reliable — the contracts and the decisions are unaffected, only the label on the counterparty.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\r\n        <div class=\"scoular-alert-description\">\r\n          The customer directory is not answering for this application, so the Customer column falls\r\n          back to account numbers. The contracts awaiting you and their details are unaffected. This\r\n          will not clear by retrying — please report it.\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @for (warning of warnings(); track warning) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n      </div>\r\n    }\r\n  </cms-notices-panel>\r\n\r\n  <!--\r\n    🔴 **The workload, before the rows** (JFrisbie, 2026-09-14). An approver arriving at this screen\r\n    had to read the grid to find out how much was waiting; these answer it in one glance.\r\n\r\n    ⚠ **Two of these are DERIVATIONS, not fields, and the cards say so.** CTRM has no priority field\r\n    and `ContractSummary` carries none — so \"high priority\" is `Waiting over 7 days` from the\r\n    contract date, and \"expiring soon\" is `Shipping within 14 days` from the ship period. The hint\r\n    line under each is what stops the number being taken to the business as though it were a CTRM\r\n    concept. See `approval-metrics.ts`.\r\n\r\n    ⚠ **Rendered only with a trade unit chosen**, because without one the queue has not been asked\r\n    for and four zeroes would read as \"nothing to approve\" rather than \"nothing requested\".\r\n  -->\r\n  @if (hasTradeUnit()) {\r\n    <dl class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:lg:grid-cols-4\">\r\n      @for (metric of metrics(); track metric.label) {\r\n        <!--\r\n          `scoular-card` for the surface, so these match the panels around them rather than\r\n          inventing a second card style.\r\n        -->\r\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\r\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\r\n\r\n          <!--\r\n            ⚠ Colour is never the only carrier — the urgent cards are distinguished by their LABEL\r\n            as much as by the tint, because roughly 1 in 12 men has a colour vision deficiency\r\n            (02a §4). \"Waiting over 7 days\" says what it is with the colour removed.\r\n          -->\r\n          <dd\r\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\r\n            [class]=\"\r\n              metric.urgent\r\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\r\n                : 'cws:text-slate-900 cws:dark:text-white'\r\n            \"\r\n          >\r\n            {{ metric.value }}\r\n          </dd>\r\n\r\n          <p class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</p>\r\n        </div>\r\n      }\r\n    </dl>\r\n  }\r\n\r\n  <!--\r\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto`.\r\n\r\n    🔴 This mirrors the workspace grid's own row exactly (JFrisbie, 2026-09-10) — same order, same\r\n    `ml-auto` split, same components — so the controls do not move as a user goes between the two\r\n    screens. The filters are inline rather than behind a Filters dropdown because there are four of\r\n    them and they fit; the workspace hides its behind a button because it has a search box competing\r\n    for the same row.\r\n  -->\r\n  <!--\r\n    🔴 **The width goes on the LABEL, never on the field** — seventh instance of this repo's\r\n    unlayered-CSS trap.\r\n\r\n    `.scoular-form-input` is `@apply w-full`, and the design system compiles unlayered while Tailwind\r\n    utilities land in `@layer utilities` — so a `w-28` on the input silently loses and the field\r\n    fills its wrapper instead. Measured: every filter here rendered **193px** regardless of the class\r\n    on it, which is what wrapped the refresh/pager block onto a second line.\r\n\r\n    The wrapper carries no design-system class, so a utility on it is uncontested — which is the\r\n    recorded remedy: put the declaration where there is no contest rather than fighting the layer.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <!--\r\n    🔴 **The toolbar is a card now** (JFrisbie, 2026-09-14), which is the only part of the requested\r\n    elevation that was actually missing.\r\n\r\n    ⚠ The other two targets already had it, and adding a shadow to either would have been a no-op\r\n    dressed as a change: `.scoular-card` is `@apply rounded-lg border bg-white shadow-sm`, so the\r\n    summary cards above already carry it, and the grid's own wrapper declares the same three. Worth\r\n    stating because a Tailwind `shadow-sm` layered on top of `.scoular-card` would also LOSE — the\r\n    design system compiles unlayered and utilities land in `@layer utilities` — so it would have\r\n    looked deliberate and done nothing.\r\n\r\n    `p-3` rather than the design system's own `p-6`: this is a control strip, and card padding meant\r\n    for content pushes the search box away from the grid it filters.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <cms-grid-toolbar>\r\n    <!--\r\n      One search box, replacing the Trader, Commodity and Customer boxes (JFrisbie, 2026-09-10).\r\n\r\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so all\r\n      three are still reachable, plus the eleven the boxes could not narrow on.\r\n\r\n      ⚠ **Applied CLIENT-SIDE, which is why this screen now asks for one large page.** A search\r\n      over rows we hold can only see the page it was given, so with a server page of 50 a term\r\n      matching a contract on page 3 would return nothing — and on a work queue “no matches” reads\r\n      as “nothing to approve”. See the query in the component.\r\n\r\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\r\n      move as a user goes between the screens.\r\n    -->\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        autocomplete=\"off\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"searchTerm()\"\r\n        (input)=\"onSearch($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!--\r\n      Saved views and the filter builder, the same pair the workspace carries (JFrisbie, 2026-09-15).\r\n\r\n      ⚠ **Its own scope.** A workspace view has no meaning here — it would carry rules against columns\r\n      this grid does not render and match nothing, which on a work queue reads as \"nothing to\r\n      approve\". `SAVED_FILTER_SCOPES` declares all four keys together and a test asserts they differ.\r\n\r\n      🔴 The width is on this wrapper, not on the control: `.scoular-form-input` is `@apply w-full`\r\n      and the design system compiles unlayered, so a `w-*` on the control itself would lose.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\r\n      (click)=\"builder.beginAdd()\"\r\n    >\r\n      + Add filter\r\n    </button>\r\n\r\n    <!--\r\n      🔴 **The Approver type dropdown that stood here is GONE (JFrisbie, 2026-09-17), and the\r\n      consequence is real rather than cosmetic.** The toolbar is now one standard set of controls on\r\n      every grid — search, view, add filter, clear sort, export, refresh, pager — and nothing else.\r\n\r\n      ⚠ What that costs, stated so nobody re-derives it from an empty space: `approverType` was a\r\n      **CTRM request parameter**, and this grid renders **no approver-type column**, so neither the\r\n      search nor a filter rule can express it. Primary-versus-Secondary narrowing is therefore\r\n      **unreachable from this screen** until a control returns. This is the same trade the status\r\n      dropdown made on the workspace, made deliberately and with the same reasoning on the record.\r\n\r\n      ✅ Nothing about the request plumbing was deleted: `ContractListQuery.approverType` still\r\n      exists and the API still accepts it, so restoring a control is a template change rather than a\r\n      rebuild.\r\n    -->\r\n\r\n    <!--\r\n      Clear sort, and it stays hidden until the queue is sorted some other way.\r\n\r\n      `defaultSorts` is what makes that true and is not decoration: this screen ARRIVES sorted\r\n      oldest-first, which is the queue's own meaning rather than anything the user did -- so a\r\n      button offering to undo it would be there from the moment they arrive, and pressing it would\r\n      discard the answer to \"what should I work on next\" rather than undoing a choice.\r\n    -->\r\n    <cms-clear-sort-button\r\n      [sorts]=\"sorts()\"\r\n      [defaultSorts]=\"defaultSorts\"\r\n      (clear)=\"onSortChange($event)\"\r\n    />\r\n\r\n    <!--\r\n      `ml-auto` puts refresh and the pager hard right, which is where the workspace keeps them. Note\r\n      this is the first element in the row with it, so everything before it stays left-aligned.\r\n    -->\r\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\r\n      <!--\r\n        Export, the same control the workspace carries and the same component — see\r\n        `cms-grid-export` for why this is shared rather than the workspace's markup copied here.\r\n\r\n        ⚠ **Both scopes are cheap on this screen and the choice is still offered.** This queue fetches\r\n        one large page and slices it locally, so \"all pages\" is already in memory — but the question\r\n        it answers is \"what I am looking at\" versus \"everything the filter matched\", and those are\r\n        different files on a paged grid. Hiding the step where it happens to be cheap would make the\r\n        same control mean different things on different screens.\r\n      -->\r\n      <cms-grid-export\r\n        [columns]=\"columns\"\r\n        [pageRows]=\"rows()\"\r\n        [totalCount]=\"queue().length\"\r\n        [allRows]=\"exportAllRows\"\r\n        [filename]=\"exportFilename\"\r\n        [disabled]=\"!hasTradeUnit() || queue().length === 0\"\r\n        (failed)=\"exportError.set($event)\"\r\n      />\r\n\r\n      <cms-refresh-button\r\n        label=\"Refresh the approval queue\"\r\n        [busy]=\"isRefreshing()\"\r\n        [disabled]=\"!hasTradeUnit()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <!--\r\n        The top pager, so advancing a page does not mean scrolling past 50 rows first. Same\r\n        component as the footer's, not a copy.\r\n\r\n        🔴 **`currentPage()`, NEVER `query().page`.** This queue fetches ONE large server page and\r\n        slices it locally, so a search can see the whole matched set rather than one page of it —\r\n        which means `query().page` is pinned to `1` and is not the page the user is on.\r\n\r\n        Bound to `query().page` the pager read \"Page 1 of N\" forever, First and Previous were\r\n        permanently disabled, and Next emitted `1 + 1` — so page 2 was reachable and page 3 was not\r\n        (JFrisbie, 2026-09-14). ⚠ Note a single Next click still worked, which is why the one test\r\n        that existed here never caught it.\r\n\r\n        `currentPage()` is also the CLAMPED page, and the rows are sliced by the same value — so the\r\n        indicator and the grid cannot disagree after a search narrows the queue.\r\n      -->\r\n      <cms-pager\r\n        [page]=\"currentPage()\"\r\n        [totalPages]=\"totalPages()\"\r\n        position=\"top\"\r\n        (goTo)=\"onPage($event)\"\r\n      />\r\n    </div>\r\n  </cms-grid-toolbar>\r\n\r\n  <!--\r\n    The chips and the rule editor. Renders NOTHING when there are no rules and the editor is closed,\r\n    so it leaves no empty band above the queue. Its own \"+ Add filter\" button is suppressed because\r\n    the toolbar carries one — one owner for the editor's open state, as on the workspace.\r\n  -->\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onRulesChange($event)\"\r\n  />\r\n\r\n  <!--\r\n    ⚠ **Deliberately NOT in the notices panel**, which is for standing conditions of the screen. A\r\n    failed export is the outcome of something the user just did, and behind a collapsed panel it is a\r\n    message nobody sees — the same rule the workspace applies to its own export failure.\r\n  -->\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    ⚠ **The rejection-reason prompt and the decision outcomes used to sit here, and both moved with\r\n    the decision** (JFrisbie, 2026-09-14) rather than being kept beside a queue that no longer\r\n    decides anything.\r\n\r\n    BR-062's reason — the body of the denial email — is collected on the review screen, where the\r\n    contract being rejected is on screen while it is typed. A prompt here asked someone to justify\r\n    rejecting a contract they were looking at fourteen columns of.\r\n  -->\r\n\r\n  <!--\r\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\r\n\r\n    This screen used to render a `scoular-card` above the container and hide the container behind\r\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\r\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\r\n    read as a notice about the data rather than as the absence of any.\r\n\r\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\r\n    unit the request is certain to 422, which is why the screen never issues one.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    [empty]=\"!hasTradeUnit() || rows().length === 0\"\r\n    [emptyMessage]=\"emptyMessage()\"\r\n    loadingLabel=\"Loading the approval queue\"\r\n    (retry)=\"retry()\"\r\n  >\r\n      <!--\r\n        ⚠ **`striped` is safe HERE specifically because this queue declares no `rowTone`.** A stripe\r\n        and a semantic tint are both a background on the `<tr>`, and together the tint stops meaning\r\n        anything — a shaded row could be \"rejected\" or just \"even\". The grid enforces the precedence\r\n        rather than trusting this binding, but a future tone on this queue would make the stripe the\r\n        wrong call rather than merely a redundant one.\r\n      -->\r\n      <cms-data-grid\r\n        [rows]=\"rows()\"\r\n        [columns]=\"columns\"\r\n        label=\"Contracts awaiting approval\"\r\n        [striped]=\"true\"\r\n        [sorts]=\"sorts()\"\r\n        [trackBy]=\"trackByContract\"\r\n        [focusKey]=\"focusKey()\"\r\n        [actions]=\"rowActions\"\r\n        actionsHeader=\"Review\"\r\n        [actionsWidth]=\"110\"\r\n        (sortChange)=\"onSortChange($event)\"\r\n        (rowActivate)=\"onRowActivate($event)\"\r\n        (pageStep)=\"onPageStep($event)\"\r\n      />\r\n\r\n      <!--\r\n        The footer, matching the workspace grid: record count left, pager right. Same\r\n        `justify-between` row and the same `1–50 of 150` wording, so the two screens read alike.\r\n      -->\r\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\r\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <p>{{ rangeLabel() }}</p>\r\n\r\n          @if (!serverSorted() && sorts().length > 0 && moreThanOnePage()) {\r\n            <!--\r\n              The sort caveat, and it is NOT the one this screen carried first.\r\n\r\n              It used to read \"Sorted within this page\" and was guarded on the LOCAL page count.\r\n              That stopped being true the moment this queue started fetching one large page and\r\n              paging in process: the sort runs over the whole matched set and the slice happens\r\n              after it, so the ordering already spans every page on screen.\r\n\r\n              What survives is the real limit, and it is the one worth saying: CTRM sent a capped\r\n              set (CR-4 / #31), so \"the oldest contract\" means the oldest of what was READ. On a\r\n              work queue that is exactly the distinction an approver relies on -- which is why the\r\n              guard is now the server's own truncation rather than a local page boundary.\r\n\r\n              Retires itself when the server echoes `appliedSort`.\r\n            -->\r\n            <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n              Sorted across everything read -- CTRM sent more than it returned, so this is not the\r\n              whole queue.\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        <cms-pager\r\n          [page]=\"currentPage()\"\r\n          [totalPages]=\"totalPages()\"\r\n          position=\"bottom\"\r\n          (goTo)=\"onPage($event)\"\r\n        />\r\n      </footer>\r\n  </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep"
				]
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"initiallyExpanded"
				]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ApprovalsPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-approvals-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FilterBuilderComponent,
				FilterSelectComponent,
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				NoticesPanelComponent,
				SearchShortcutDirective,
				GridExportComponent,
				GridToolbarComponent,
				PagerComponent,
				RefreshButtonComponent,
				PageHeaderComponent
			],
			template: "<section class=\"cws:space-y-4\">\r\n  <cms-page-header\r\n    title=\"Approvals\"\r\n    description=\"Contracts awaiting trader approval, oldest first.\"\r\n  />\r\n\r\n  <!--\r\n    🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-14). This was three\r\n    full-width banners plus one per server warning, ahead of the first row of the work queue.\r\n\r\n    Every one of them is still here and still true — the panel states how many there are, summarises\r\n    each in a line, and shows them in full on demand. What changed is that the queue now opens with\r\n    the queue.\r\n\r\n    ⚠ **The CTRM-is-not-updated warning can be de-emphasised HERE only because the decision moved.**\r\n    It was unconditional and loud because Approve and Reject sat in the grid immediately below it,\r\n    and an approval falsely believed to be done is the worst outcome this screen can produce. The\r\n    decision now happens on the review screen, which states the same thing at the point of action\r\n    and in the result itself. Collapsing it here without that move would have been a real loss of\r\n    safety rather than a tidy-up.\r\n  -->\r\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n    <!--\r\n      🔴 The scope statement. BR-060 scopes this queue to the approver's own approval locations plus\r\n      the ones they back up; that needs `traderLocations` and `backupApprovers`, two CTRM reads that\r\n      work and that no endpoint publishes. So what is on screen is ONE trade unit.\r\n\r\n      An approver whose remit spans four locations would otherwise see one location's queue, find it\r\n      short, and reasonably conclude there was nothing to approve. A silently narrow work queue is\r\n      worse than an empty one.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">Showing one trade unit, not your full approver remit</div>\r\n      <div class=\"scoular-alert-description\">\r\n        This queue is scoped to the trade unit selected above. Approver-based scoping needs two CTRM\r\n        reads that are not published yet, so <strong>contracts awaiting you in other trade units are\r\n        not listed here</strong> — switch trade unit to see them.\r\n      </div>\r\n    </div>\r\n\r\n    <!--\r\n      The capability warning. Two independent blockers, both checked against the authorities:\r\n\r\n        1. `approveContracts` has never succeeded through any transport — the origin OOMs building\r\n           its output parameters (issue 108) — and the API publishes no approval route.\r\n        2. `trader_approval_status` is `\"access\": \"readOnly\"` in `constraints.json`, so the proven\r\n           contract-upsert path refuses it rather than ignoring it.\r\n\r\n      ⚠ **The description below deliberately names NEITHER blocker.** It used to carry both CTRM\r\n      identifiers in `<code>` and a live link into our issue tracker, which is three things a trader\r\n      can neither act on nor reach — and the link implied a status they could go and check. What a\r\n      trader needs from this box is the consequence and the alternative; the mechanism is above, for\r\n      whoever maintains the screen.\r\n    -->\r\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n      <div class=\"scoular-alert-title\">\r\n        Approvals are recorded in this session only — CTRM is not updated\r\n      </div>\r\n      <div class=\"scoular-alert-description\">\r\n        Decisions taken on the review screen <strong>do not reach CTRM</strong>, which cannot yet\r\n        accept an approval from this application. They are <strong>lost on reload</strong> and must\r\n        still be completed on the green screen. Use this queue to review and decide; record the\r\n        decision in CTRM as you do today.\r\n      </div>\r\n    </div>\r\n\r\n    @if (isSimulated()) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Simulated data</div>\r\n        <div class=\"scoular-alert-description\">These rows are generated, not read from CTRM.</div>\r\n      </div>\r\n    }\r\n\r\n    @if (customerNamesRedacted()) {\r\n      <!--\r\n        🔴 The customer directory is refusing us (#328). Same notice as the workspace, and it belongs\r\n        here more than there: this is the one status whose CTRM projection carries a customer name\r\n        directly, so ids in this column are a column that worked yesterday.\r\n\r\n        ⚠ Names no internal identifier, per the 2026-09-17 copy guard, and leads with what is still\r\n        reliable — the contracts and the decisions are unaffected, only the label on the counterparty.\r\n      -->\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\r\n        <div class=\"scoular-alert-description\">\r\n          The customer directory is not answering for this application, so the Customer column falls\r\n          back to account numbers. The contracts awaiting you and their details are unaffected. This\r\n          will not clear by retrying — please report it.\r\n        </div>\r\n      </div>\r\n    }\r\n\r\n    @for (warning of warnings(); track warning) {\r\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n        <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n      </div>\r\n    }\r\n  </cms-notices-panel>\r\n\r\n  <!--\r\n    🔴 **The workload, before the rows** (JFrisbie, 2026-09-14). An approver arriving at this screen\r\n    had to read the grid to find out how much was waiting; these answer it in one glance.\r\n\r\n    ⚠ **Two of these are DERIVATIONS, not fields, and the cards say so.** CTRM has no priority field\r\n    and `ContractSummary` carries none — so \"high priority\" is `Waiting over 7 days` from the\r\n    contract date, and \"expiring soon\" is `Shipping within 14 days` from the ship period. The hint\r\n    line under each is what stops the number being taken to the business as though it were a CTRM\r\n    concept. See `approval-metrics.ts`.\r\n\r\n    ⚠ **Rendered only with a trade unit chosen**, because without one the queue has not been asked\r\n    for and four zeroes would read as \"nothing to approve\" rather than \"nothing requested\".\r\n  -->\r\n  @if (hasTradeUnit()) {\r\n    <dl class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:lg:grid-cols-4\">\r\n      @for (metric of metrics(); track metric.label) {\r\n        <!--\r\n          `scoular-card` for the surface, so these match the panels around them rather than\r\n          inventing a second card style.\r\n        -->\r\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\r\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\r\n\r\n          <!--\r\n            ⚠ Colour is never the only carrier — the urgent cards are distinguished by their LABEL\r\n            as much as by the tint, because roughly 1 in 12 men has a colour vision deficiency\r\n            (02a §4). \"Waiting over 7 days\" says what it is with the colour removed.\r\n          -->\r\n          <dd\r\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\r\n            [class]=\"\r\n              metric.urgent\r\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\r\n                : 'cws:text-slate-900 cws:dark:text-white'\r\n            \"\r\n          >\r\n            {{ metric.value }}\r\n          </dd>\r\n\r\n          <p class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</p>\r\n        </div>\r\n      }\r\n    </dl>\r\n  }\r\n\r\n  <!--\r\n    The toolbar: filters left, refresh then the top pager pushed hard right by `ml-auto`.\r\n\r\n    🔴 This mirrors the workspace grid's own row exactly (JFrisbie, 2026-09-10) — same order, same\r\n    `ml-auto` split, same components — so the controls do not move as a user goes between the two\r\n    screens. The filters are inline rather than behind a Filters dropdown because there are four of\r\n    them and they fit; the workspace hides its behind a button because it has a search box competing\r\n    for the same row.\r\n  -->\r\n  <!--\r\n    🔴 **The width goes on the LABEL, never on the field** — seventh instance of this repo's\r\n    unlayered-CSS trap.\r\n\r\n    `.scoular-form-input` is `@apply w-full`, and the design system compiles unlayered while Tailwind\r\n    utilities land in `@layer utilities` — so a `w-28` on the input silently loses and the field\r\n    fills its wrapper instead. Measured: every filter here rendered **193px** regardless of the class\r\n    on it, which is what wrapped the refresh/pager block onto a second line.\r\n\r\n    The wrapper carries no design-system class, so a utility on it is uncontested — which is the\r\n    recorded remedy: put the declaration where there is no contest rather than fighting the layer.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <!--\r\n    🔴 **The toolbar is a card now** (JFrisbie, 2026-09-14), which is the only part of the requested\r\n    elevation that was actually missing.\r\n\r\n    ⚠ The other two targets already had it, and adding a shadow to either would have been a no-op\r\n    dressed as a change: `.scoular-card` is `@apply rounded-lg border bg-white shadow-sm`, so the\r\n    summary cards above already carry it, and the grid's own wrapper declares the same three. Worth\r\n    stating because a Tailwind `shadow-sm` layered on top of `.scoular-card` would also LOSE — the\r\n    design system compiles unlayered and utilities land in `@layer utilities` — so it would have\r\n    looked deliberate and done nothing.\r\n\r\n    `p-3` rather than the design system's own `p-6`: this is a control strip, and card padding meant\r\n    for content pushes the search box away from the grid it filters.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <cms-grid-toolbar>\r\n    <!--\r\n      One search box, replacing the Trader, Commodity and Customer boxes (JFrisbie, 2026-09-10).\r\n\r\n      🔴 **It matches every column the grid renders**, via `matchesSearch` over `columns` — so all\r\n      three are still reachable, plus the eleven the boxes could not narrow on.\r\n\r\n      ⚠ **Applied CLIENT-SIDE, which is why this screen now asks for one large page.** A search\r\n      over rows we hold can only see the page it was given, so with a server page of 50 a term\r\n      matching a contract on page 3 would return nothing — and on a work queue “no matches” reads\r\n      as “nothing to approve”. See the query in the component.\r\n\r\n      `flex-1` with a floor and a ceiling, matching the workspace toolbar so the control does not\r\n      move as a user goes between the screens.\r\n    -->\r\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-xl\">\r\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\r\n      <input\r\n        type=\"search\"\r\n        cmsSearchShortcut\r\n        class=\"scoular-form-input cws:w-full\"\r\n        autocomplete=\"off\"\r\n        placeholder=\"Search every column\"\r\n        [value]=\"searchTerm()\"\r\n        (input)=\"onSearch($any($event.target).value)\"\r\n      />\r\n    </label>\r\n\r\n    <!--\r\n      Saved views and the filter builder, the same pair the workspace carries (JFrisbie, 2026-09-15).\r\n\r\n      ⚠ **Its own scope.** A workspace view has no meaning here — it would carry rules against columns\r\n      this grid does not render and match nothing, which on a work queue reads as \"nothing to\r\n      approve\". `SAVED_FILTER_SCOPES` declares all four keys together and a test asserts they differ.\r\n\r\n      🔴 The width is on this wrapper, not on the control: `.scoular-form-input` is `@apply w-full`\r\n      and the design system compiles unlayered, so a `w-*` on the control itself would lose.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <div class=\"cws:w-56\">\r\n      <cms-filter-select\r\n        [scope]=\"savedFilterScope\"\r\n        [filter]=\"filter()\"\r\n        [sorts]=\"sorts()\"\r\n        (viewChange)=\"onViewChange($event)\"\r\n      />\r\n    </div>\r\n\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline cws:shrink-0\"\r\n      (click)=\"builder.beginAdd()\"\r\n    >\r\n      + Add filter\r\n    </button>\r\n\r\n    <!--\r\n      🔴 **The Approver type dropdown that stood here is GONE (JFrisbie, 2026-09-17), and the\r\n      consequence is real rather than cosmetic.** The toolbar is now one standard set of controls on\r\n      every grid — search, view, add filter, clear sort, export, refresh, pager — and nothing else.\r\n\r\n      ⚠ What that costs, stated so nobody re-derives it from an empty space: `approverType` was a\r\n      **CTRM request parameter**, and this grid renders **no approver-type column**, so neither the\r\n      search nor a filter rule can express it. Primary-versus-Secondary narrowing is therefore\r\n      **unreachable from this screen** until a control returns. This is the same trade the status\r\n      dropdown made on the workspace, made deliberately and with the same reasoning on the record.\r\n\r\n      ✅ Nothing about the request plumbing was deleted: `ContractListQuery.approverType` still\r\n      exists and the API still accepts it, so restoring a control is a template change rather than a\r\n      rebuild.\r\n    -->\r\n\r\n    <!--\r\n      Clear sort, and it stays hidden until the queue is sorted some other way.\r\n\r\n      `defaultSorts` is what makes that true and is not decoration: this screen ARRIVES sorted\r\n      oldest-first, which is the queue's own meaning rather than anything the user did -- so a\r\n      button offering to undo it would be there from the moment they arrive, and pressing it would\r\n      discard the answer to \"what should I work on next\" rather than undoing a choice.\r\n    -->\r\n    <cms-clear-sort-button\r\n      [sorts]=\"sorts()\"\r\n      [defaultSorts]=\"defaultSorts\"\r\n      (clear)=\"onSortChange($event)\"\r\n    />\r\n\r\n    <!--\r\n      `ml-auto` puts refresh and the pager hard right, which is where the workspace keeps them. Note\r\n      this is the first element in the row with it, so everything before it stays left-aligned.\r\n    -->\r\n    <div class=\"cws:ml-auto cws:flex cws:items-end cws:gap-2\">\r\n      <!--\r\n        Export, the same control the workspace carries and the same component — see\r\n        `cms-grid-export` for why this is shared rather than the workspace's markup copied here.\r\n\r\n        ⚠ **Both scopes are cheap on this screen and the choice is still offered.** This queue fetches\r\n        one large page and slices it locally, so \"all pages\" is already in memory — but the question\r\n        it answers is \"what I am looking at\" versus \"everything the filter matched\", and those are\r\n        different files on a paged grid. Hiding the step where it happens to be cheap would make the\r\n        same control mean different things on different screens.\r\n      -->\r\n      <cms-grid-export\r\n        [columns]=\"columns\"\r\n        [pageRows]=\"rows()\"\r\n        [totalCount]=\"queue().length\"\r\n        [allRows]=\"exportAllRows\"\r\n        [filename]=\"exportFilename\"\r\n        [disabled]=\"!hasTradeUnit() || queue().length === 0\"\r\n        (failed)=\"exportError.set($event)\"\r\n      />\r\n\r\n      <cms-refresh-button\r\n        label=\"Refresh the approval queue\"\r\n        [busy]=\"isRefreshing()\"\r\n        [disabled]=\"!hasTradeUnit()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <!--\r\n        The top pager, so advancing a page does not mean scrolling past 50 rows first. Same\r\n        component as the footer's, not a copy.\r\n\r\n        🔴 **`currentPage()`, NEVER `query().page`.** This queue fetches ONE large server page and\r\n        slices it locally, so a search can see the whole matched set rather than one page of it —\r\n        which means `query().page` is pinned to `1` and is not the page the user is on.\r\n\r\n        Bound to `query().page` the pager read \"Page 1 of N\" forever, First and Previous were\r\n        permanently disabled, and Next emitted `1 + 1` — so page 2 was reachable and page 3 was not\r\n        (JFrisbie, 2026-09-14). ⚠ Note a single Next click still worked, which is why the one test\r\n        that existed here never caught it.\r\n\r\n        `currentPage()` is also the CLAMPED page, and the rows are sliced by the same value — so the\r\n        indicator and the grid cannot disagree after a search narrows the queue.\r\n      -->\r\n      <cms-pager\r\n        [page]=\"currentPage()\"\r\n        [totalPages]=\"totalPages()\"\r\n        position=\"top\"\r\n        (goTo)=\"onPage($event)\"\r\n      />\r\n    </div>\r\n  </cms-grid-toolbar>\r\n\r\n  <!--\r\n    The chips and the rule editor. Renders NOTHING when there are no rules and the editor is closed,\r\n    so it leaves no empty band above the queue. Its own \"+ Add filter\" button is suppressed because\r\n    the toolbar carries one — one owner for the editor's open state, as on the workspace.\r\n  -->\r\n  <cms-filter-builder\r\n    #builder\r\n    [columns]=\"columns\"\r\n    [filter]=\"filter()\"\r\n    [showAddButton]=\"false\"\r\n    (filterChange)=\"onRulesChange($event)\"\r\n  />\r\n\r\n  <!--\r\n    ⚠ **Deliberately NOT in the notices panel**, which is for standing conditions of the screen. A\r\n    failed export is the outcome of something the user just did, and behind a collapsed panel it is a\r\n    message nobody sees — the same rule the workspace applies to its own export failure.\r\n  -->\r\n  @if (exportError(); as error) {\r\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\r\n      <div class=\"scoular-alert-description\">{{ error }}</div>\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    ⚠ **The rejection-reason prompt and the decision outcomes used to sit here, and both moved with\r\n    the decision** (JFrisbie, 2026-09-14) rather than being kept beside a queue that no longer\r\n    decides anything.\r\n\r\n    BR-062's reason — the body of the denial email — is collected on the review screen, where the\r\n    contract being rejected is on screen while it is typed. A prompt here asked someone to justify\r\n    rejecting a contract they were looking at fourteen columns of.\r\n  -->\r\n\r\n  <!--\r\n    🔴 ONE presentation of \"choose a trade unit\", through the container, matching the workspace.\r\n\r\n    This screen used to render a `scoular-card` above the container and hide the container behind\r\n    an `@else`; the pricing queue did the same and pricing approvals used a tinted alert with a\r\n    title. Four screens, four ways to say the same precondition -- and the alert in particular\r\n    read as a notice about the data rather than as the absence of any.\r\n\r\n    CTRM refuses an unscoped read, so this is a precondition and not a courtesy: without a trade\r\n    unit the request is certain to 422, which is why the screen never issues one.\r\n  -->\r\n  <cms-async-container\r\n    [data]=\"containerState()\"\r\n    [empty]=\"!hasTradeUnit() || rows().length === 0\"\r\n    [emptyMessage]=\"emptyMessage()\"\r\n    loadingLabel=\"Loading the approval queue\"\r\n    (retry)=\"retry()\"\r\n  >\r\n      <!--\r\n        ⚠ **`striped` is safe HERE specifically because this queue declares no `rowTone`.** A stripe\r\n        and a semantic tint are both a background on the `<tr>`, and together the tint stops meaning\r\n        anything — a shaded row could be \"rejected\" or just \"even\". The grid enforces the precedence\r\n        rather than trusting this binding, but a future tone on this queue would make the stripe the\r\n        wrong call rather than merely a redundant one.\r\n      -->\r\n      <cms-data-grid\r\n        [rows]=\"rows()\"\r\n        [columns]=\"columns\"\r\n        label=\"Contracts awaiting approval\"\r\n        [striped]=\"true\"\r\n        [sorts]=\"sorts()\"\r\n        [trackBy]=\"trackByContract\"\r\n        [focusKey]=\"focusKey()\"\r\n        [actions]=\"rowActions\"\r\n        actionsHeader=\"Review\"\r\n        [actionsWidth]=\"110\"\r\n        (sortChange)=\"onSortChange($event)\"\r\n        (rowActivate)=\"onRowActivate($event)\"\r\n        (pageStep)=\"onPageStep($event)\"\r\n      />\r\n\r\n      <!--\r\n        The footer, matching the workspace grid: record count left, pager right. Same\r\n        `justify-between` row and the same `1–50 of 150` wording, so the two screens read alike.\r\n      -->\r\n      <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\r\n        <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <p>{{ rangeLabel() }}</p>\r\n\r\n          @if (!serverSorted() && sorts().length > 0 && moreThanOnePage()) {\r\n            <!--\r\n              The sort caveat, and it is NOT the one this screen carried first.\r\n\r\n              It used to read \"Sorted within this page\" and was guarded on the LOCAL page count.\r\n              That stopped being true the moment this queue started fetching one large page and\r\n              paging in process: the sort runs over the whole matched set and the slice happens\r\n              after it, so the ordering already spans every page on screen.\r\n\r\n              What survives is the real limit, and it is the one worth saying: CTRM sent a capped\r\n              set (CR-4 / #31), so \"the oldest contract\" means the oldest of what was READ. On a\r\n              work queue that is exactly the distinction an approver relies on -- which is why the\r\n              guard is now the server's own truncation rather than a local page boundary.\r\n\r\n              Retires itself when the server echoes `appliedSort`.\r\n            -->\r\n            <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\r\n              Sorted across everything read -- CTRM sent more than it returned, so this is not the\r\n              whole queue.\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        <cms-pager\r\n          [page]=\"currentPage()\"\r\n          [totalPages]=\"totalPages()\"\r\n          position=\"bottom\"\r\n          (goTo)=\"onPage($event)\"\r\n        />\r\n      </footer>\r\n  </cms-async-container>\r\n</section>\r\n"
		}]
	}]
});
function emptyPage(query) {
	return {
		rows: [],
		totalCount: 0,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: 1,
		dataOrigin: "Simulated",
		filteredInProcess: false,
		warnings: []
	};
}
const DEFAULT_EMAIL_MESSAGE = "Please sign and return the attached contract.";
var ApprovalDetailPageComponent = class ApprovalDetailPageComponent {
	contracts = inject(APPROVAL_CONTRACT_SOURCE);
	approvals = inject(APPROVAL_ACTION_SOURCE);
	permissions = inject(PERMISSION_CONTEXT);
	hostContext = inject(CMS_HOST_CONTEXT);
	route = inject(ActivatedRoute);
	returnTo = this.route.snapshot.queryParamMap.get("returnTo");
	returnParams = computed(() => Object.fromEntries(new URLSearchParams(this.returnTo ?? "")), ...ngDevMode ? [{ debugName: "returnParams" }] : /* istanbul ignore next */ []);
	recordLinkParams = computed(() => ({
		[RECORD_ORIGIN_PARAM]: "approvals",
		...this.returnTo === null ? {} : { returnTo: this.returnTo }
	}), ...ngDevMode ? [{ debugName: "recordLinkParams" }] : /* istanbul ignore next */ []);
	origin = computed(() => recordOrigin(this.originKey(), "approvals"), ...ngDevMode ? [{ debugName: "origin" }] : /* istanbul ignore next */ []);
	originKey = computed(() => recordOriginKey(this.route.snapshot.queryParamMap.get(RECORD_ORIGIN_PARAM), "approvals"), ...ngDevMode ? [{ debugName: "originKey" }] : /* istanbul ignore next */ []);
	originIntent = computed(() => ({
		kind: "origin",
		origin: this.originKey(),
		params: this.returnParams()
	}), ...ngDevMode ? [{ debugName: "originIntent" }] : /* istanbul ignore next */ []);
	recordIntent = computed(() => ({
		kind: "contract",
		contractNumber: this.contractNumber(),
		params: this.recordLinkParams()
	}), ...ngDevMode ? [{ debugName: "recordIntent" }] : /* istanbul ignore next */ []);
	recordHref = computed(() => this.hostContext.hrefFor(this.recordIntent()), ...ngDevMode ? [{ debugName: "recordHref" }] : /* istanbul ignore next */ []);
	follow(event, intent) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(intent);
	}
	followRecord(event) {
		this.follow(event, this.recordIntent());
	}
	crumbs = computed(() => {
		const intent = this.originIntent();
		return [{
			label: this.origin().label,
			path: this.origin().path,
			link: {
				href: this.hostContext.hrefFor(intent),
				follow: (event) => this.follow(event, intent)
			}
		}];
	}, ...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	tradeUnitLabel = injectTradeUnitLabel();
	contractNumber = input.required(...ngDevMode ? [{ debugName: "contractNumber" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	loaded = toSignal(toObservable(computed(() => ({
		number: this.contractNumber(),
		attempt: this.attempt()
	}))).pipe(switchMap(({ number }) => this.contracts.get(number))), { initialValue: remoteLoading() });
	containerState = computed(() => this.loaded(), ...ngDevMode ? [{ debugName: "containerState" }] : /* istanbul ignore next */ []);
	contract = computed(() => {
		const state = this.loaded();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "contract" }] : /* istanbul ignore next */ []);
	header = computed(() => this.contract()?.header ?? null, ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	customerName = computed(() => {
		const name = customerDisplayName(this.header()?.customerName, null);
		return name === "" ? null : name;
	}, ...ngDevMode ? [{ debugName: "customerName" }] : /* istanbul ignore next */ []);
	customerFor(row) {
		return customerDisplayName(row.customerName, row.customerId, "—");
	}
	isSimulated = computed(() => this.contract()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	warnings = computed(() => this.contract()?.warnings ?? [], ...ngDevMode ? [{ debugName: "warnings" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => [
		"Approving here does not send for e-signature",
		...this.isSimulated() ? ["Simulated details, not read from CTRM"] : [],
		...this.warnings()
	], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	isRefreshing = computed(() => this.loaded().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	canApprove = computed(() => this.permissions.canApproveContracts(), ...ngDevMode ? [{ debugName: "canApprove" }] : /* istanbul ignore next */ []);
	confirmed = signal(false, ...ngDevMode ? [{ debugName: "confirmed" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	isDeciding = signal(false, ...ngDevMode ? [{ debugName: "isDeciding" }] : /* istanbul ignore next */ []);
	rejectOpen = signal(false, ...ngDevMode ? [{ debugName: "rejectOpen" }] : /* istanbul ignore next */ []);
	rejectReason = signal("", ...ngDevMode ? [{ debugName: "rejectReason" }] : /* istanbul ignore next */ []);
	recipients = computed(() => [], ...ngDevMode ? [{ debugName: "recipients" }] : /* istanbul ignore next */ []);
	ecmRecipients = signal([], ...ngDevMode ? [{ debugName: "ecmRecipients" }] : /* istanbul ignore next */ []);
	ecmCopies = signal(1, ...ngDevMode ? [{ debugName: "ecmCopies" }] : /* istanbul ignore next */ []);
	ecmMessage = signal(DEFAULT_EMAIL_MESSAGE, ...ngDevMode ? [{ debugName: "ecmMessage" }] : /* istanbul ignore next */ []);
	ecmEsign = signal(false, ...ngDevMode ? [{ debugName: "ecmEsign" }] : /* istanbul ignore next */ []);
	ecmEsignOverride = signal(false, ...ngDevMode ? [{ debugName: "ecmEsignOverride" }] : /* istanbul ignore next */ []);
	maxRecipients = MAX_ECM_RECIPIENTS;
	recipientDraft = signal("", ...ngDevMode ? [{ debugName: "recipientDraft" }] : /* istanbul ignore next */ []);
	recipientRefusal = computed(() => {
		if (this.ecmRecipients().length >= MAX_ECM_RECIPIENTS) return `CTRM carries at most ${MAX_ECM_RECIPIENTS} recipients on an approval, so no more can be added. Remove one first.`;
		const draft = this.recipientDraft().trim();
		if (draft !== "" && this.ecmRecipients().includes(draft)) return "That address is already on the list.";
		return null;
	}, ...ngDevMode ? [{ debugName: "recipientRefusal" }] : /* istanbul ignore next */ []);
	canAddRecipient = computed(() => this.recipientDraft().trim() !== "" && this.recipientRefusal() === null, ...ngDevMode ? [{ debugName: "canAddRecipient" }] : /* istanbul ignore next */ []);
	onRecipientDraft(value) {
		this.recipientDraft.set(value);
	}
	addRecipient() {
		if (!this.canAddRecipient()) return;
		this.ecmRecipients.update((list) => [...list, this.recipientDraft().trim()]);
		this.recipientDraft.set("");
	}
	removeRecipient(address) {
		this.ecmRecipients.update((list) => list.filter((entry) => entry !== address));
	}
	onEcmMessage(value) {
		this.ecmMessage.set(value);
	}
	onEcmCopies(value) {
		const parsed = Number.parseInt(value, 10);
		this.ecmCopies.set(Number.isFinite(parsed) && parsed > 0 ? parsed : 1);
	}
	toggleEsign(value) {
		this.ecmEsign.set(value);
	}
	toggleEsignOverride(value) {
		this.ecmEsignOverride.set(value);
	}
	ecmEditable = computed(() => !this.ecmEsign() && this.canApprove(), ...ngDevMode ? [{ debugName: "ecmEditable" }] : /* istanbul ignore next */ []);
	ecmRequest() {
		if (this.ecmRecipients().length === 0 && this.ecmMessage().trim() === "") return;
		return {
			distribution_entry: this.ecmRecipients(),
			copies: this.ecmCopies(),
			email_message: this.ecmMessage(),
			esign: this.ecmEsign(),
			esign_override: this.ecmEsignOverride()
		};
	}
	printerUnavailable = "Printer routing was removed from the Portal in 2025 and has no replacement here, so an approval cannot be routed to a printer.";
	canSubmit = computed(() => this.canApprove() && this.confirmed() && !this.isDeciding(), ...ngDevMode ? [{ debugName: "canSubmit" }] : /* istanbul ignore next */ []);
	refresh() {
		this.attempt.update((value) => value + 1);
	}
	retry() {
		this.refresh();
	}
	skip() {
		this.returnToQueue();
	}
	onEscape(event) {
		if (event.defaultPrevented) return;
		this.returnToQueue();
	}
	returnToQueue() {
		this.hostContext.navigate(this.originIntent());
	}
	openReject() {
		this.rejectOpen.set(true);
	}
	cancelReject() {
		this.rejectOpen.set(false);
		this.rejectReason.set("");
	}
	approve() {
		if (!this.canSubmit()) return;
		this.submit("Approved");
	}
	reject() {
		if (this.rejectReason().trim() === "" || this.isDeciding()) return;
		this.submit("Rejected", this.rejectReason().trim());
	}
	submit(decision, reason) {
		this.isDeciding.set(true);
		this.outcome.set(null);
		this.failure.set(null);
		(decision === "Approved" ? this.approvals.approve(this.contractNumber(), this.ecmRequest()) : this.approvals.reject(this.contractNumber(), reason ?? "")).subscribe({
			next: (result) => {
				this.isDeciding.set(false);
				this.outcome.set(result);
				this.rejectOpen.set(false);
				this.confirmed.set(false);
			},
			error: (error) => {
				this.isDeciding.set(false);
				this.failure.set(this.describeFailure(error));
			}
		});
	}
	describeFailure(error) {
		const contractNumber = this.contractNumber();
		if (error?.status === 404) return `The approval endpoint is not published by the API yet, so nothing was sent for ${contractNumber}. Complete this approval on the green screen.`;
		return `We could not record that decision on ${contractNumber}. Nothing was changed.`;
	}
	onConfirmChange(checked) {
		this.confirmed.set(checked);
	}
	onRejectReason(value) {
		this.rejectReason.set(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ApprovalDetailPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ApprovalDetailPageComponent,
		isStandalone: true,
		selector: "cms-approval-detail-page",
		inputs: { contractNumber: {
			classPropertyName: "contractNumber",
			publicName: "contractNumber",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: { "document:keydown.escape": "onEscape($event)" } },
		ngImport: i0,
		template: "<section class=\"cws:flex cws:flex-col cws:gap-4\">\r\n  <!--\r\n    The breadcrumb is the only way back, and it goes to the QUEUE rather than to history: this screen\r\n    is reachable from one place by design, so a generic \"back\" would be less specific than the truth.\r\n  -->\r\n  <!--\r\n    ⚠ **`queryParams` carries the queue's own state back** (JFrisbie, 2026-09-15) — its search, its\r\n    sort, the page it was on and the row that was opened. Without it the crumb *worked*, which is the\r\n    failure worth naming: an approver returned to an unfiltered page 1 with their place gone, and\r\n    nothing looked broken.\r\n\r\n    🔑 **Still a real anchor rather than a click handler**, which is what `returnParams` being an\r\n    object rather than a URL string buys: it keeps its `href`, so middle-click and open-in-new-tab\r\n    work and Tab reaches it. Escape and Skip navigate to the same place from the same computed.\r\n  -->\r\n  <!--\r\n    🔴 The same breadcrumb shape as the record screen, deliberately (JFrisbie, 2026-09-15).\r\n\r\n    This was a single `&lsaquo; Approvals` back-link while the record screen carried a full trail, so\r\n    two screens one click apart disagreed about where the user was. Matching them is the point: an\r\n    approver moves between these constantly, and a crumb that changes shape mid-journey reads as a\r\n    different application.\r\n\r\n    The first crumb is the screen you came FROM, so it says `Pricing` and returns there when a pricing\r\n    queue links in with `?from=pricing`, rather than always claiming Approvals.\r\n  -->\r\n  <!--\r\n    ⚠ **The markup moved to `cms-breadcrumb`; nothing about this trail changed.** It was already the\r\n    ARIA-correct version, and the shared component was extracted from the record screen's identical\r\n    copy — so this is the same DOM rendered from one definition instead of three.\r\n  -->\r\n  <cms-breadcrumb\r\n    cmsPageHeaderBreadcrumb\r\n    [crumbs]=\"crumbs()\"\r\n    [current]=\"contractNumber()\"\r\n    [context]=\"tradeUnitLabel()\"\r\n    [queryParams]=\"returnParams()\"\r\n  />\r\n\r\n  <!--\r\n    🔴 An h2, not the h1 this screen used to open with. The shell owns the page's only h1, so this\r\n    was the one screen giving the document two top-level headings -- and its section headings were\r\n    h2s, one level above every other screen's h3s.\r\n\r\n    ⚠ The customer name is bound as the description rather than left as its own paragraph, so it\r\n    truncates and spaces the same way every other screen's does.\r\n  -->\r\n  <cms-page-header\r\n    [title]=\"'Approve contract ' + contractNumber()\"\r\n    [description]=\"customerName()\"\r\n  >\r\n    <ng-container cmsPageHeaderActions>\r\n      <!--\r\n        ⚠ The SHARED control, not a hand-rolled button (JFrisbie, 2026-09-14). The first version of\r\n        this screen used a text button reading \"Refresh\" / \"Refreshing…\", which is a second refresh\r\n        affordance for the app to keep in step with — exactly the drift the component exists to\r\n        prevent, and it also loses the 36-vs-38px height correction the icon-only form needs.\r\n      -->\r\n      <cms-refresh-button\r\n        label=\"Refresh this contract\"\r\n        [busy]=\"isRefreshing()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <!--\r\n        \"Skip\" in the Portal moves to the next contract in a cursor through a work list. Here it\r\n        returns to the queue: this screen was reached by choosing a row, and landing someone on a\r\n        different contract than the one they skipped is how the wrong contract gets approved.\r\n      -->\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"skip()\">Skip</button>\r\n\r\n      <!--\r\n        🔴 **`from` and `returnTo` are passed on, and without them the journey breaks one hop later.**\r\n\r\n        The record screen picks its breadcrumb from `from` and defaults to the workspace — so this\r\n        link, bare, sent an approver queue → review → record and then offered them a crumb reading\r\n        \"Contracts\" that moved them to a different screen entirely. That is the exact failure\r\n        `record-origin.ts` was written for, reproduced by the one link that had not been given the\r\n        parameters.\r\n\r\n        ⚠ The record's crumb returns to the **queue**, not to this screen — `RecordOrigin` names\r\n        queues, not intermediate screens. That is the right destination (it is where the journey\r\n        started and where the state lives) and it is worth knowing rather than discovering.\r\n      -->\r\n      <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\r\n      <a\r\n        [attr.href]=\"recordHref()\"\r\n        (click)=\"followRecord($event)\"\r\n        class=\"scoular-btn scoular-btn-secondary\"\r\n      >\r\n        View full record\r\n      </a>\r\n    </ng-container>\r\n  </cms-page-header>\r\n\r\n  <cms-async-container [data]=\"containerState()\" (retry)=\"retry()\">\r\n    @if (header(); as row) {\r\n      <!--\r\n        🔴 **The spacing wrapper, and it is required rather than decorative** (JFrisbie, 2026-09-15,\r\n        from a screenshot).\r\n\r\n        Measured in Edge before it existed: **0px between every block on this screen** — notices\r\n        panel, terms, document, distribution and decision all touching — against a uniform **16px**\r\n        on the approvals queue and the contract record. The screen read as one undifferentiated slab.\r\n\r\n        🔑 **The cause is that the root's `gap-4` cannot reach these.** It applies between the root's\r\n        own children — the breadcrumb, the header and `cms-async-container` — and every block here is\r\n        *inside* that container, which projects `<ng-content />` **bare, with no wrapper and no\r\n        spacing of its own**. So the gap stopped at the container's edge, which is exactly where it\r\n        looked like it was working. ⚠ The record screen has carried its own `space-y-4` wrapper for\r\n        this reason all along; this screen simply never got one.\r\n\r\n        ⚠ **`flex flex-col gap-4` rather than the `space-y-4` used elsewhere, deliberately, and they\r\n        are visually identical at 16px.** `space-y-*` works by putting `margin-block-end` on each\r\n        child, and **a vertical margin has no effect on an inline box** — which is what silently ate\r\n        the notices panel's spacing a day earlier and needed `host: { class: 'block' }` to fix. `gap`\r\n        is a property of the container and applies whatever the children's display is, so a future\r\n        component dropped in here cannot lose its spacing the same way.\r\n      -->\r\n      <div class=\"cws:flex cws:flex-col cws:gap-4\">\r\n        <!--\r\n          F6.5 — the approved → customer → broker progression, first on this screen because it is\r\n          the one where somebody commits. A stage lit here is read as work already done, so the\r\n          broker caution travels with the component rather than being restated in a template.\r\n        -->\r\n        <section\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <h2 class=\"cws:mb-2 cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n            Confirmation status\r\n          </h2>\r\n          <cms-confirmation-progress [header]=\"row\" />\r\n        </section>\r\n\r\n        <!--\r\n        🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\r\n        queue this screen is reached from. It was two full-width banners plus one per server warning\r\n        above the contract terms — on a screen whose entire job is to show six facts and take a\r\n        decision, the caveats outweighed the content.\r\n\r\n        Every notice is still here and still true; what changed is that the screen opens with the\r\n        contract. ⚠ **The same test the queue applied: is it restated where it bites?** The decision\r\n        outcome says <strong>CTRM was not updated</strong> in the result itself, so the data-origin\r\n        caveat is not the only thing carrying that. Collapsing these without that would have been a\r\n        loss of safety rather than a tidy-up.\r\n      -->\r\n        <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n          <!--\r\n          ⚠ A standing caveat, not a live status. CTRM resolves the e-sign endpoint per environment\r\n          out of the HTP001 DB2 table and calls it itself; nothing we can read exposes whether it is\r\n          configured, so this states the consequence rather than claiming to know the setting.\r\n\r\n          Deliberately first: it is the only one of these that is true on live CTRM as well.\r\n        -->\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">E-Sign status is unknown to this application</div>\r\n            <div class=\"scoular-alert-description\">\r\n              CTRM holds the e-signature configuration per environment and we cannot read it.\r\n              Approving here does not send the contract for signature.\r\n            </div>\r\n          </div>\r\n\r\n          @if (isSimulated()) {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Simulated data</div>\r\n              <div class=\"scoular-alert-description\">\r\n                These contract details are generated locally, not read from CTRM.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @for (warning of warnings(); track warning) {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n            </div>\r\n          }\r\n        </cms-notices-panel>\r\n\r\n        <!--\r\n        The terms, read-only. Six facts rather than 111: the approver is confirming what they already\r\n        saw in the queue, and the full record is one click away in the header.\r\n      -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Contract terms\r\n          </h3>\r\n\r\n          <dl class=\"cws:grid cws:grid-cols-1 cws:gap-x-6 cws:gap-y-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Customer</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ customerFor(row) }}\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">{{ row.commodity ?? '—' }}</dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Quantity</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                <!--\r\n                ⚠ The unit is always rendered beside the number. A grain quantity with no unit is the\r\n                defect recorded when CTRM was found storing pounds while the API returns bushels.\r\n              -->\r\n                @if (row.quantity === null) {\r\n                  —\r\n                } @else {\r\n                  {{ row.quantity | number: '1.0-0' }} {{ row.quantityUom ?? '' }}\r\n                }\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Price</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ row.price === null ? '—' : (row.price | number: '1.4-4') }}\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Market zone</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ row.marketZone ?? '—' }}\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Trader</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ row.traderInitials ?? '—' }}\r\n              </dd>\r\n            </div>\r\n          </dl>\r\n        </section>\r\n\r\n        <!--\r\n        The document. This is the whole lower half of the Portal screen, and it is the thing an\r\n        approver is actually reading before deciding.\r\n      -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Contract document\r\n          </h3>\r\n\r\n          <div\r\n            class=\"cws:flex cws:min-h-48 cws:flex-col cws:items-center cws:justify-center cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-6 cws:text-center cws:dark:border-slate-600\"\r\n            role=\"status\"\r\n          >\r\n            <p class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\r\n              Document preview is not available yet\r\n            </p>\r\n            <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Listing a contract's documents and streaming one back needs CTRM's Documents API,\r\n              which is not published. Until it is, use the Contract Portal to read the contract\r\n              before approving.\r\n            </p>\r\n          </div>\r\n        </section>\r\n\r\n        <!--\r\n          F6.2 — the ECM panel, now bound to the approval request.\r\n\r\n          ⚠ **The brief said these fields were already on the request. They were not** —\r\n          `approve(contractNumber)` took a number and nothing else, and this section rendered\r\n          read-only with an empty recipient list. The five members were added to the seam first.\r\n\r\n          🔴 **At most four recipients, refused HERE rather than by CTRM.** `distribution_entry` is\r\n          four slots, so a fifth has nowhere to go. An approval is the write with the least\r\n          tolerance for a silent partial success on this estate, so the limit is enforced before\r\n          sending.\r\n        -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Send a copy to\r\n          </h3>\r\n\r\n          @if (ecmRecipients().length === 0) {\r\n            <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n              Nobody is on this contract's distribution list yet.\r\n            </p>\r\n          } @else {\r\n            <ul class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-1\">\r\n              @for (address of ecmRecipients(); track address) {\r\n                <li\r\n                  class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:rounded cws:border cws:border-slate-200 cws:px-2 cws:py-1 cws:text-sm cws:text-slate-800 cws:dark:border-slate-700 cws:dark:text-slate-100\"\r\n                >\r\n                  <span class=\"truncate\">{{ address }}</span>\r\n                  @if (ecmEditable()) {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary cws:shrink-0 cws:px-2 cws:py-0.5 cws:text-xs\"\r\n                      (click)=\"removeRecipient(address)\"\r\n                    >\r\n                      Remove\r\n                    </button>\r\n                  }\r\n                </li>\r\n              }\r\n            </ul>\r\n          }\r\n\r\n          @if (ecmEditable()) {\r\n            <div class=\"cws:mt-2 cws:flex cws:items-start cws:gap-2\">\r\n              <label class=\"cws:flex-1\">\r\n                <span class=\"sr-only\">Recipient email address</span>\r\n                <input\r\n                  type=\"email\"\r\n                  class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                  placeholder=\"name@example.com\"\r\n                  [value]=\"recipientDraft()\"\r\n                  [disabled]=\"ecmRecipients().length >= maxRecipients\"\r\n                  (input)=\"onRecipientDraft($any($event.target).value)\"\r\n                />\r\n              </label>\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\r\n                [disabled]=\"!canAddRecipient()\"\r\n                (click)=\"addRecipient()\"\r\n              >\r\n                Add\r\n              </button>\r\n            </div>\r\n\r\n            @if (recipientRefusal(); as refusal) {\r\n              <!-- The reason at the control, not a greyed button with no explanation. -->\r\n              <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n                {{ refusal }}\r\n              </p>\r\n            } @else {\r\n              <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                {{ ecmRecipients().length }} of {{ maxRecipients }} recipients.\r\n              </p>\r\n            }\r\n          }\r\n\r\n          <div class=\"cws:mt-3 cws:grid cws:gap-3 cws:sm:grid-cols-2\">\r\n            <label class=\"cws:block\">\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Copies</span>\r\n              <input\r\n                type=\"number\"\r\n                min=\"1\"\r\n                class=\"cws:mt-1 cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                [value]=\"ecmCopies()\"\r\n                [disabled]=\"!ecmEditable()\"\r\n                (input)=\"onEcmCopies($any($event.target).value)\"\r\n              />\r\n            </label>\r\n\r\n            <div class=\"cws:flex cws:flex-col cws:justify-end cws:gap-1\">\r\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"ecmEsign()\"\r\n                  [disabled]=\"!canApprove()\"\r\n                  (change)=\"toggleEsign($any($event.target).checked)\"\r\n                />\r\n                <span>Send for e-signature</span>\r\n              </label>\r\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"ecmEsignOverride()\"\r\n                  [disabled]=\"!canApprove()\"\r\n                  (change)=\"toggleEsignOverride($any($event.target).checked)\"\r\n                />\r\n                <span>Override CTRM's e-sign decision</span>\r\n              </label>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"cws:mt-3\">\r\n            <label class=\"cws:block\">\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Message</span>\r\n              <textarea\r\n                rows=\"3\"\r\n                class=\"cws:mt-1 cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                [value]=\"ecmMessage()\"\r\n                [disabled]=\"!ecmEditable()\"\r\n                (input)=\"onEcmMessage($any($event.target).value)\"\r\n              ></textarea>\r\n            </label>\r\n          </div>\r\n\r\n          <!--\r\n            🔴 The printer row: SHOWN and disabled, with its reason (#291).\r\n\r\n            Portal printing was removed in 2025 and has no replacement here. An approver who used it\r\n            needs to know it is gone rather than wonder where it went — an absent control reads as a\r\n            rendering fault, a disabled one with a reason reads as a decision.\r\n          -->\r\n          <div class=\"cws:mt-3 cws:flex cws:items-center cws:gap-2 cws:opacity-60\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n              <input type=\"checkbox\" disabled [title]=\"printerUnavailable\" />\r\n              <span>Send to a printer</span>\r\n            </label>\r\n          </div>\r\n          <p class=\"cws:mt-1 cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n            {{ printerUnavailable }}\r\n          </p>\r\n\r\n          @if (ecmEsign()) {\r\n            <p role=\"status\" class=\"cws:mt-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              This contract is going for e-signature, so CTRM manages its distribution from here on\r\n              and these fields are read-only.\r\n            </p>\r\n          }\r\n        </section>\r\n\r\n\r\n        <!-- The decision. -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">Decision</h3>\r\n\r\n          @if (!canApprove()) {\r\n            <!--\r\n            The Portal's \"You do NOT have authority to approve this contract\", stated as what the\r\n            account lacks. ⚠ Worded as OUR authority rather than CTRM's, because CTRM's per-location\r\n            approval authority is a separate check we cannot read — claiming to speak for it would be\r\n            a guess about someone else's rules.\r\n          -->\r\n            <p role=\"status\" class=\"cws:mb-3 cws:text-sm cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n              You do not have authority to approve this contract. Approving needs the\r\n              <strong>Admin</strong> role on this application.\r\n            </p>\r\n          }\r\n\r\n          @if (outcome(); as result) {\r\n            <div class=\"scoular-alert scoular-alert-warning cws:mb-3\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">{{ result.decision }} — {{ result.origin }}</div>\r\n              <div class=\"scoular-alert-description\">\r\n                {{ result.detail }}\r\n                @if (result.origin === 'Simulated') {\r\n                  <!--\r\n                  🔴 The most dangerous outcome this screen can produce is an approval reported as\r\n                  done that CTRM never heard about. Said in the result itself, not only in a banner\r\n                  at the top of the page which a user may have scrolled past.\r\n                -->\r\n                  <strong>CTRM was not updated.</strong>\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (failure(); as message) {\r\n            <div class=\"scoular-alert scoular-alert-error cws:mb-3\" role=\"alert\">\r\n              <div class=\"scoular-alert-description\">{{ message }}</div>\r\n            </div>\r\n          }\r\n\r\n          @if (rejectOpen()) {\r\n            <div class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-2\">\r\n              <label class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" for=\"reject-reason\">\r\n                Reason for rejection\r\n              </label>\r\n              <!--\r\n              BR-062: the denial email quotes this, so an empty rejection tells the originator\r\n              nothing. Submit stays disabled until there is a reason.\r\n            -->\r\n              <textarea\r\n                id=\"reject-reason\"\r\n                rows=\"3\"\r\n                class=\"scoular-form-input\"\r\n                [value]=\"rejectReason()\"\r\n                (input)=\"onRejectReason($any($event.target).value)\"\r\n              ></textarea>\r\n\r\n              <div class=\"cws:flex cws:items-center cws:gap-2\">\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-primary\"\r\n                  [disabled]=\"rejectReason().trim() === '' || isDeciding()\"\r\n                  (click)=\"reject()\"\r\n                >\r\n                  {{ isDeciding() ? 'Working…' : 'Reject contract' }}\r\n                </button>\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                  (click)=\"cancelReject()\"\r\n                >\r\n                  Cancel\r\n                </button>\r\n              </div>\r\n            </div>\r\n          } @else if (canApprove()) {\r\n            <!--\r\n              🔴 The decision controls exist only for an account that may decide (F4.3a).\r\n\r\n              The refusal notice above already states why, so rendering a disabled checkbox and\r\n              two dead buttons underneath it would say the same thing three more times — and a\r\n              disabled Approve is the control most likely to be read as \"the system is broken\"\r\n              rather than \"this is not yours to do\".\r\n            -->\r\n            <div class=\"cws:flex cws:flex-col cws:gap-3\">\r\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                <!--\r\n                The Portal's \"Check Box then Click Here to Approve\", kept deliberately: approval has\r\n                no inverse on this estate, so one stray click must not be enough.\r\n              -->\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"confirmed()\"\r\n                  [disabled]=\"!canApprove()\"\r\n                  (change)=\"onConfirmChange($any($event.target).checked)\"\r\n                />\r\n                I have reviewed this contract and approve it\r\n              </label>\r\n\r\n              <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-primary\"\r\n                  [disabled]=\"!canSubmit()\"\r\n                  (click)=\"approve()\"\r\n                >\r\n                  {{ isDeciding() ? 'Working…' : 'Approve contract' }}\r\n                </button>\r\n\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                  [disabled]=\"!canApprove() || isDeciding()\"\r\n                  (click)=\"openReject()\"\r\n                >\r\n                  Reject with notice\r\n                </button>\r\n              </div>\r\n            </div>\r\n          }\r\n        </section>\r\n      </div>\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ConfirmationProgressComponent,
				selector: "cms-confirmation-progress",
				inputs: ["header"]
			},
			{
				kind: "component",
				type: BreadcrumbComponent,
				selector: "cms-breadcrumb",
				inputs: [
					"crumbs",
					"current",
					"context",
					"queryParams"
				]
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "pipe",
				type: DecimalPipe,
				name: "number"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ApprovalDetailPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-approval-detail-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				ConfirmationProgressComponent,
				BreadcrumbComponent,
				DecimalPipe,
				NoticesPanelComponent,
				RefreshButtonComponent,
				PageHeaderComponent
			],
			template: "<section class=\"cws:flex cws:flex-col cws:gap-4\">\r\n  <!--\r\n    The breadcrumb is the only way back, and it goes to the QUEUE rather than to history: this screen\r\n    is reachable from one place by design, so a generic \"back\" would be less specific than the truth.\r\n  -->\r\n  <!--\r\n    ⚠ **`queryParams` carries the queue's own state back** (JFrisbie, 2026-09-15) — its search, its\r\n    sort, the page it was on and the row that was opened. Without it the crumb *worked*, which is the\r\n    failure worth naming: an approver returned to an unfiltered page 1 with their place gone, and\r\n    nothing looked broken.\r\n\r\n    🔑 **Still a real anchor rather than a click handler**, which is what `returnParams` being an\r\n    object rather than a URL string buys: it keeps its `href`, so middle-click and open-in-new-tab\r\n    work and Tab reaches it. Escape and Skip navigate to the same place from the same computed.\r\n  -->\r\n  <!--\r\n    🔴 The same breadcrumb shape as the record screen, deliberately (JFrisbie, 2026-09-15).\r\n\r\n    This was a single `&lsaquo; Approvals` back-link while the record screen carried a full trail, so\r\n    two screens one click apart disagreed about where the user was. Matching them is the point: an\r\n    approver moves between these constantly, and a crumb that changes shape mid-journey reads as a\r\n    different application.\r\n\r\n    The first crumb is the screen you came FROM, so it says `Pricing` and returns there when a pricing\r\n    queue links in with `?from=pricing`, rather than always claiming Approvals.\r\n  -->\r\n  <!--\r\n    ⚠ **The markup moved to `cms-breadcrumb`; nothing about this trail changed.** It was already the\r\n    ARIA-correct version, and the shared component was extracted from the record screen's identical\r\n    copy — so this is the same DOM rendered from one definition instead of three.\r\n  -->\r\n  <cms-breadcrumb\r\n    cmsPageHeaderBreadcrumb\r\n    [crumbs]=\"crumbs()\"\r\n    [current]=\"contractNumber()\"\r\n    [context]=\"tradeUnitLabel()\"\r\n    [queryParams]=\"returnParams()\"\r\n  />\r\n\r\n  <!--\r\n    🔴 An h2, not the h1 this screen used to open with. The shell owns the page's only h1, so this\r\n    was the one screen giving the document two top-level headings -- and its section headings were\r\n    h2s, one level above every other screen's h3s.\r\n\r\n    ⚠ The customer name is bound as the description rather than left as its own paragraph, so it\r\n    truncates and spaces the same way every other screen's does.\r\n  -->\r\n  <cms-page-header\r\n    [title]=\"'Approve contract ' + contractNumber()\"\r\n    [description]=\"customerName()\"\r\n  >\r\n    <ng-container cmsPageHeaderActions>\r\n      <!--\r\n        ⚠ The SHARED control, not a hand-rolled button (JFrisbie, 2026-09-14). The first version of\r\n        this screen used a text button reading \"Refresh\" / \"Refreshing…\", which is a second refresh\r\n        affordance for the app to keep in step with — exactly the drift the component exists to\r\n        prevent, and it also loses the 36-vs-38px height correction the icon-only form needs.\r\n      -->\r\n      <cms-refresh-button\r\n        label=\"Refresh this contract\"\r\n        [busy]=\"isRefreshing()\"\r\n        (refresh)=\"refresh()\"\r\n      />\r\n\r\n      <!--\r\n        \"Skip\" in the Portal moves to the next contract in a cursor through a work list. Here it\r\n        returns to the queue: this screen was reached by choosing a row, and landing someone on a\r\n        different contract than the one they skipped is how the wrong contract gets approved.\r\n      -->\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"skip()\">Skip</button>\r\n\r\n      <!--\r\n        🔴 **`from` and `returnTo` are passed on, and without them the journey breaks one hop later.**\r\n\r\n        The record screen picks its breadcrumb from `from` and defaults to the workspace — so this\r\n        link, bare, sent an approver queue → review → record and then offered them a crumb reading\r\n        \"Contracts\" that moved them to a different screen entirely. That is the exact failure\r\n        `record-origin.ts` was written for, reproduced by the one link that had not been given the\r\n        parameters.\r\n\r\n        ⚠ The record's crumb returns to the **queue**, not to this screen — `RecordOrigin` names\r\n        queues, not intermediate screens. That is the right destination (it is where the journey\r\n        started and where the state lives) and it is worth knowing rather than discovering.\r\n      -->\r\n      <!-- The host's href and a click handed to the host (E9 PR 4); embedded, /contracts would escape. -->\r\n      <a\r\n        [attr.href]=\"recordHref()\"\r\n        (click)=\"followRecord($event)\"\r\n        class=\"scoular-btn scoular-btn-secondary\"\r\n      >\r\n        View full record\r\n      </a>\r\n    </ng-container>\r\n  </cms-page-header>\r\n\r\n  <cms-async-container [data]=\"containerState()\" (retry)=\"retry()\">\r\n    @if (header(); as row) {\r\n      <!--\r\n        🔴 **The spacing wrapper, and it is required rather than decorative** (JFrisbie, 2026-09-15,\r\n        from a screenshot).\r\n\r\n        Measured in Edge before it existed: **0px between every block on this screen** — notices\r\n        panel, terms, document, distribution and decision all touching — against a uniform **16px**\r\n        on the approvals queue and the contract record. The screen read as one undifferentiated slab.\r\n\r\n        🔑 **The cause is that the root's `gap-4` cannot reach these.** It applies between the root's\r\n        own children — the breadcrumb, the header and `cms-async-container` — and every block here is\r\n        *inside* that container, which projects `<ng-content />` **bare, with no wrapper and no\r\n        spacing of its own**. So the gap stopped at the container's edge, which is exactly where it\r\n        looked like it was working. ⚠ The record screen has carried its own `space-y-4` wrapper for\r\n        this reason all along; this screen simply never got one.\r\n\r\n        ⚠ **`flex flex-col gap-4` rather than the `space-y-4` used elsewhere, deliberately, and they\r\n        are visually identical at 16px.** `space-y-*` works by putting `margin-block-end` on each\r\n        child, and **a vertical margin has no effect on an inline box** — which is what silently ate\r\n        the notices panel's spacing a day earlier and needed `host: { class: 'block' }` to fix. `gap`\r\n        is a property of the container and applies whatever the children's display is, so a future\r\n        component dropped in here cannot lose its spacing the same way.\r\n      -->\r\n      <div class=\"cws:flex cws:flex-col cws:gap-4\">\r\n        <!--\r\n          F6.5 — the approved → customer → broker progression, first on this screen because it is\r\n          the one where somebody commits. A stage lit here is read as work already done, so the\r\n          broker caution travels with the component rather than being restated in a template.\r\n        -->\r\n        <section\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <h2 class=\"cws:mb-2 cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n            Confirmation status\r\n          </h2>\r\n          <cms-confirmation-progress [header]=\"row\" />\r\n        </section>\r\n\r\n        <!--\r\n        🔴 **The standing notices, collapsed into one panel** (JFrisbie, 2026-09-15), matching the\r\n        queue this screen is reached from. It was two full-width banners plus one per server warning\r\n        above the contract terms — on a screen whose entire job is to show six facts and take a\r\n        decision, the caveats outweighed the content.\r\n\r\n        Every notice is still here and still true; what changed is that the screen opens with the\r\n        contract. ⚠ **The same test the queue applied: is it restated where it bites?** The decision\r\n        outcome says <strong>CTRM was not updated</strong> in the result itself, so the data-origin\r\n        caveat is not the only thing carrying that. Collapsing these without that would have been a\r\n        loss of safety rather than a tidy-up.\r\n      -->\r\n        <cms-notices-panel [summaries]=\"noticeSummaries()\">\r\n          <!--\r\n          ⚠ A standing caveat, not a live status. CTRM resolves the e-sign endpoint per environment\r\n          out of the HTP001 DB2 table and calls it itself; nothing we can read exposes whether it is\r\n          configured, so this states the consequence rather than claiming to know the setting.\r\n\r\n          Deliberately first: it is the only one of these that is true on live CTRM as well.\r\n        -->\r\n          <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n            <div class=\"scoular-alert-title\">E-Sign status is unknown to this application</div>\r\n            <div class=\"scoular-alert-description\">\r\n              CTRM holds the e-signature configuration per environment and we cannot read it.\r\n              Approving here does not send the contract for signature.\r\n            </div>\r\n          </div>\r\n\r\n          @if (isSimulated()) {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">Simulated data</div>\r\n              <div class=\"scoular-alert-description\">\r\n                These contract details are generated locally, not read from CTRM.\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @for (warning of warnings(); track warning) {\r\n            <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\r\n              <div class=\"scoular-alert-description\">{{ warning }}</div>\r\n            </div>\r\n          }\r\n        </cms-notices-panel>\r\n\r\n        <!--\r\n        The terms, read-only. Six facts rather than 111: the approver is confirming what they already\r\n        saw in the queue, and the full record is one click away in the header.\r\n      -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Contract terms\r\n          </h3>\r\n\r\n          <dl class=\"cws:grid cws:grid-cols-1 cws:gap-x-6 cws:gap-y-3 cws:sm:grid-cols-2 cws:lg:grid-cols-3\">\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Customer</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ customerFor(row) }}\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Commodity</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">{{ row.commodity ?? '—' }}</dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Quantity</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                <!--\r\n                ⚠ The unit is always rendered beside the number. A grain quantity with no unit is the\r\n                defect recorded when CTRM was found storing pounds while the API returns bushels.\r\n              -->\r\n                @if (row.quantity === null) {\r\n                  —\r\n                } @else {\r\n                  {{ row.quantity | number: '1.0-0' }} {{ row.quantityUom ?? '' }}\r\n                }\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Price</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ row.price === null ? '—' : (row.price | number: '1.4-4') }}\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Market zone</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ row.marketZone ?? '—' }}\r\n              </dd>\r\n            </div>\r\n            <div>\r\n              <dt class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Trader</dt>\r\n              <dd class=\"cws:text-sm cws:text-slate-900 cws:dark:text-slate-100\">\r\n                {{ row.traderInitials ?? '—' }}\r\n              </dd>\r\n            </div>\r\n          </dl>\r\n        </section>\r\n\r\n        <!--\r\n        The document. This is the whole lower half of the Portal screen, and it is the thing an\r\n        approver is actually reading before deciding.\r\n      -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Contract document\r\n          </h3>\r\n\r\n          <div\r\n            class=\"cws:flex cws:min-h-48 cws:flex-col cws:items-center cws:justify-center cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-6 cws:text-center cws:dark:border-slate-600\"\r\n            role=\"status\"\r\n          >\r\n            <p class=\"cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\r\n              Document preview is not available yet\r\n            </p>\r\n            <p class=\"cws:max-w-md cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              Listing a contract's documents and streaming one back needs CTRM's Documents API,\r\n              which is not published. Until it is, use the Contract Portal to read the contract\r\n              before approving.\r\n            </p>\r\n          </div>\r\n        </section>\r\n\r\n        <!--\r\n          F6.2 — the ECM panel, now bound to the approval request.\r\n\r\n          ⚠ **The brief said these fields were already on the request. They were not** —\r\n          `approve(contractNumber)` took a number and nothing else, and this section rendered\r\n          read-only with an empty recipient list. The five members were added to the seam first.\r\n\r\n          🔴 **At most four recipients, refused HERE rather than by CTRM.** `distribution_entry` is\r\n          four slots, so a fifth has nowhere to go. An approval is the write with the least\r\n          tolerance for a silent partial success on this estate, so the limit is enforced before\r\n          sending.\r\n        -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Send a copy to\r\n          </h3>\r\n\r\n          @if (ecmRecipients().length === 0) {\r\n            <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\r\n              Nobody is on this contract's distribution list yet.\r\n            </p>\r\n          } @else {\r\n            <ul class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-1\">\r\n              @for (address of ecmRecipients(); track address) {\r\n                <li\r\n                  class=\"cws:flex cws:items-center cws:justify-between cws:gap-2 cws:rounded cws:border cws:border-slate-200 cws:px-2 cws:py-1 cws:text-sm cws:text-slate-800 cws:dark:border-slate-700 cws:dark:text-slate-100\"\r\n                >\r\n                  <span class=\"truncate\">{{ address }}</span>\r\n                  @if (ecmEditable()) {\r\n                    <button\r\n                      type=\"button\"\r\n                      class=\"scoular-btn scoular-btn-secondary cws:shrink-0 cws:px-2 cws:py-0.5 cws:text-xs\"\r\n                      (click)=\"removeRecipient(address)\"\r\n                    >\r\n                      Remove\r\n                    </button>\r\n                  }\r\n                </li>\r\n              }\r\n            </ul>\r\n          }\r\n\r\n          @if (ecmEditable()) {\r\n            <div class=\"cws:mt-2 cws:flex cws:items-start cws:gap-2\">\r\n              <label class=\"cws:flex-1\">\r\n                <span class=\"sr-only\">Recipient email address</span>\r\n                <input\r\n                  type=\"email\"\r\n                  class=\"cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                  placeholder=\"name@example.com\"\r\n                  [value]=\"recipientDraft()\"\r\n                  [disabled]=\"ecmRecipients().length >= maxRecipients\"\r\n                  (input)=\"onRecipientDraft($any($event.target).value)\"\r\n                />\r\n              </label>\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\r\n                [disabled]=\"!canAddRecipient()\"\r\n                (click)=\"addRecipient()\"\r\n              >\r\n                Add\r\n              </button>\r\n            </div>\r\n\r\n            @if (recipientRefusal(); as refusal) {\r\n              <!-- The reason at the control, not a greyed button with no explanation. -->\r\n              <p role=\"status\" class=\"cws:mt-1 cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n                {{ refusal }}\r\n              </p>\r\n            } @else {\r\n              <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                {{ ecmRecipients().length }} of {{ maxRecipients }} recipients.\r\n              </p>\r\n            }\r\n          }\r\n\r\n          <div class=\"cws:mt-3 cws:grid cws:gap-3 cws:sm:grid-cols-2\">\r\n            <label class=\"cws:block\">\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Copies</span>\r\n              <input\r\n                type=\"number\"\r\n                min=\"1\"\r\n                class=\"cws:mt-1 cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-1 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                [value]=\"ecmCopies()\"\r\n                [disabled]=\"!ecmEditable()\"\r\n                (input)=\"onEcmCopies($any($event.target).value)\"\r\n              />\r\n            </label>\r\n\r\n            <div class=\"cws:flex cws:flex-col cws:justify-end cws:gap-1\">\r\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"ecmEsign()\"\r\n                  [disabled]=\"!canApprove()\"\r\n                  (change)=\"toggleEsign($any($event.target).checked)\"\r\n                />\r\n                <span>Send for e-signature</span>\r\n              </label>\r\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"ecmEsignOverride()\"\r\n                  [disabled]=\"!canApprove()\"\r\n                  (change)=\"toggleEsignOverride($any($event.target).checked)\"\r\n                />\r\n                <span>Override CTRM's e-sign decision</span>\r\n              </label>\r\n            </div>\r\n          </div>\r\n\r\n          <div class=\"cws:mt-3\">\r\n            <label class=\"cws:block\">\r\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Message</span>\r\n              <textarea\r\n                rows=\"3\"\r\n                class=\"cws:mt-1 cws:w-full cws:rounded cws:border cws:border-slate-300 cws:px-2 cws:py-2 cws:text-sm cws:dark:border-slate-600 cws:dark:bg-slate-900 cws:dark:text-white\"\r\n                [value]=\"ecmMessage()\"\r\n                [disabled]=\"!ecmEditable()\"\r\n                (input)=\"onEcmMessage($any($event.target).value)\"\r\n              ></textarea>\r\n            </label>\r\n          </div>\r\n\r\n          <!--\r\n            🔴 The printer row: SHOWN and disabled, with its reason (#291).\r\n\r\n            Portal printing was removed in 2025 and has no replacement here. An approver who used it\r\n            needs to know it is gone rather than wonder where it went — an absent control reads as a\r\n            rendering fault, a disabled one with a reason reads as a decision.\r\n          -->\r\n          <div class=\"cws:mt-3 cws:flex cws:items-center cws:gap-2 cws:opacity-60\">\r\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n              <input type=\"checkbox\" disabled [title]=\"printerUnavailable\" />\r\n              <span>Send to a printer</span>\r\n            </label>\r\n          </div>\r\n          <p class=\"cws:mt-1 cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n            {{ printerUnavailable }}\r\n          </p>\r\n\r\n          @if (ecmEsign()) {\r\n            <p role=\"status\" class=\"cws:mt-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              This contract is going for e-signature, so CTRM manages its distribution from here on\r\n              and these fields are read-only.\r\n            </p>\r\n          }\r\n        </section>\r\n\r\n\r\n        <!-- The decision. -->\r\n        <section class=\"scoular-card cws:p-4\">\r\n          <h3 class=\"cws:mb-3 cws:text-sm cws:font-semibold cws:text-slate-700 cws:dark:text-slate-200\">Decision</h3>\r\n\r\n          @if (!canApprove()) {\r\n            <!--\r\n            The Portal's \"You do NOT have authority to approve this contract\", stated as what the\r\n            account lacks. ⚠ Worded as OUR authority rather than CTRM's, because CTRM's per-location\r\n            approval authority is a separate check we cannot read — claiming to speak for it would be\r\n            a guess about someone else's rules.\r\n          -->\r\n            <p role=\"status\" class=\"cws:mb-3 cws:text-sm cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n              You do not have authority to approve this contract. Approving needs the\r\n              <strong>Admin</strong> role on this application.\r\n            </p>\r\n          }\r\n\r\n          @if (outcome(); as result) {\r\n            <div class=\"scoular-alert scoular-alert-warning cws:mb-3\" role=\"status\">\r\n              <div class=\"scoular-alert-title\">{{ result.decision }} — {{ result.origin }}</div>\r\n              <div class=\"scoular-alert-description\">\r\n                {{ result.detail }}\r\n                @if (result.origin === 'Simulated') {\r\n                  <!--\r\n                  🔴 The most dangerous outcome this screen can produce is an approval reported as\r\n                  done that CTRM never heard about. Said in the result itself, not only in a banner\r\n                  at the top of the page which a user may have scrolled past.\r\n                -->\r\n                  <strong>CTRM was not updated.</strong>\r\n                }\r\n              </div>\r\n            </div>\r\n          }\r\n\r\n          @if (failure(); as message) {\r\n            <div class=\"scoular-alert scoular-alert-error cws:mb-3\" role=\"alert\">\r\n              <div class=\"scoular-alert-description\">{{ message }}</div>\r\n            </div>\r\n          }\r\n\r\n          @if (rejectOpen()) {\r\n            <div class=\"cws:mb-3 cws:flex cws:flex-col cws:gap-2\">\r\n              <label class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" for=\"reject-reason\">\r\n                Reason for rejection\r\n              </label>\r\n              <!--\r\n              BR-062: the denial email quotes this, so an empty rejection tells the originator\r\n              nothing. Submit stays disabled until there is a reason.\r\n            -->\r\n              <textarea\r\n                id=\"reject-reason\"\r\n                rows=\"3\"\r\n                class=\"scoular-form-input\"\r\n                [value]=\"rejectReason()\"\r\n                (input)=\"onRejectReason($any($event.target).value)\"\r\n              ></textarea>\r\n\r\n              <div class=\"cws:flex cws:items-center cws:gap-2\">\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-primary\"\r\n                  [disabled]=\"rejectReason().trim() === '' || isDeciding()\"\r\n                  (click)=\"reject()\"\r\n                >\r\n                  {{ isDeciding() ? 'Working…' : 'Reject contract' }}\r\n                </button>\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                  (click)=\"cancelReject()\"\r\n                >\r\n                  Cancel\r\n                </button>\r\n              </div>\r\n            </div>\r\n          } @else if (canApprove()) {\r\n            <!--\r\n              🔴 The decision controls exist only for an account that may decide (F4.3a).\r\n\r\n              The refusal notice above already states why, so rendering a disabled checkbox and\r\n              two dead buttons underneath it would say the same thing three more times — and a\r\n              disabled Approve is the control most likely to be read as \"the system is broken\"\r\n              rather than \"this is not yours to do\".\r\n            -->\r\n            <div class=\"cws:flex cws:flex-col cws:gap-3\">\r\n              <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                <!--\r\n                The Portal's \"Check Box then Click Here to Approve\", kept deliberately: approval has\r\n                no inverse on this estate, so one stray click must not be enough.\r\n              -->\r\n                <input\r\n                  type=\"checkbox\"\r\n                  [checked]=\"confirmed()\"\r\n                  [disabled]=\"!canApprove()\"\r\n                  (change)=\"onConfirmChange($any($event.target).checked)\"\r\n                />\r\n                I have reviewed this contract and approve it\r\n              </label>\r\n\r\n              <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2\">\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-primary\"\r\n                  [disabled]=\"!canSubmit()\"\r\n                  (click)=\"approve()\"\r\n                >\r\n                  {{ isDeciding() ? 'Working…' : 'Approve contract' }}\r\n                </button>\r\n\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-btn scoular-btn-secondary\"\r\n                  [disabled]=\"!canApprove() || isDeciding()\"\r\n                  (click)=\"openReject()\"\r\n                >\r\n                  Reject with notice\r\n                </button>\r\n              </div>\r\n            </div>\r\n          }\r\n        </section>\r\n      </div>\r\n    }\r\n  </cms-async-container>\r\n</section>\r\n"
		}]
	}],
	propDecorators: {
		contractNumber: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "contractNumber",
				required: true
			}]
		}],
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	}
});
export { APPROVAL_GRID_COLUMNS, ApprovalDetailPageComponent, ApprovalsPageComponent };

//# sourceMappingURL=cws-features-approvals.mjs.map
import { addMonths, compareIsoDates, endOfMonth, fromIsoDate, startOfMonth } from "@cws/shared-utils";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, Injectable, InjectionToken, computed, effect, inject, input, linkedSignal, output, signal, untracked } from "@angular/core";
import * as i1 from "@angular/forms";
import { FormControl, FormGroup, FormRecord, ReactiveFormsModule, Validators } from "@angular/forms";
import { takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { CodeComboComponent, DateInputComponent, FieldComponent, NoteInputComponent, QuantityInputComponent, TextInputComponent, ToggleComponent, remoteError } from "@cws/shared-ui";
import { of, startWith, switchMap } from "rxjs";
const ControlPattern = {
	SearchableCodeCombo: "C1",
	EntityTypeahead: "C2",
	MaskedDate: "C3",
	QuantityDecimal: "C4",
	TextWithCounter: "C5",
	MultilineNote: "C6",
	StatusBadge: "C7",
	DataGrid: "C8",
	ToggleFlag: "C9",
	WarningBorder: "C10",
	InlinePdfViewer: "C11"
};
const ContractComponent = {
	PriceTypeCode: "PriceTypeCode",
	Price: "Price",
	BasisPrice: "BasisPrice",
	HedgePrice: "HedgePrice",
	GradeAdjustment: "GradeAdjustment",
	FreightAdjustment: "FreightAdjustment",
	BasisMarketMonth: "BasisMarketMonth",
	BasisMarketMonthDescription: "BasisMarketMonthDescription",
	HedgeMarketMonth: "HedgeMarketMonth",
	HedgeMarketMonthDescription: "HedgeMarketMonthDescription",
	BrokerId: "BrokerId",
	BrokerRate: "BrokerRate",
	BrokerContract: "BrokerContract",
	BrokerUnitOfMeasure: "BrokerUnitOfMeasure",
	Quantity: "Quantity",
	QuantityUnitOfMeasure: "QuantityUnitOfMeasure",
	PriceUnitOfMeasure: "PriceUnitOfMeasure",
	GradeAdjustmentUnitOfMeasure: "GradeAdjustmentUnitOfMeasure",
	FreightAdjustmentUnitOfMeasure: "FreightAdjustmentUnitOfMeasure"
};
const PriceTypeCode = {
	Deferred: "D",
	Variable: "V",
	Unpriced: "U",
	Priced: "P"
};
const ContractPrefixType = {
	Sale: "S",
	Purchase: "P"
};
function readString(value, componentName) {
	const raw = value.fields[componentName];
	if (raw === null || raw === void 0 || typeof raw === "boolean") return null;
	const text = String(raw).trim();
	return text.length === 0 ? null : text;
}
function readNumber(value, componentName) {
	const raw = value.fields[componentName];
	if (raw === null || raw === void 0 || raw === "" || typeof raw === "boolean") return null;
	const parsed = typeof raw === "number" ? raw : Number(raw);
	return Number.isFinite(parsed) ? parsed : null;
}
function isBlank(value, componentName) {
	return readString(value, componentName) === null;
}
function isZeroOrBlank(value, componentName) {
	const parsed = readNumber(value, componentName);
	return parsed === null || parsed === 0;
}
const valueIntentNone = { kind: "none" };
const valueIntentBlank = { kind: "blank" };
const computedValue = (value) => ({
	kind: "computed",
	value
});
const defaultValue = (value) => ({
	kind: "default",
	value
});
function orderedFields(config) {
	return [...config.sections].sort((a, b) => a.order - b.order).flatMap((section) => [...section.fields].sort((a, b) => a.order - b.order));
}
function findField(config, componentName) {
	for (const section of config.sections) {
		const match = section.fields.find((field) => field.componentName === componentName);
		if (match) return match;
	}
}
const AutoCalculationMode = {
	None: "None",
	Price: "Price",
	Basis: "Basis"
};
function presentationFrom(raw) {
	if (typeof raw !== "object" || raw === null) return;
	const source = raw;
	const flag = (key) => typeof source[key] === "boolean" ? { [key]: source[key] } : {};
	const text = (key) => {
		const value = source[key];
		return typeof value === "string" && value.trim() !== "" ? { [key]: value.trim() } : {};
	};
	const presentation = {
		...flag("halfWidth"),
		...flag("labelHidden"),
		...text("label"),
		...flag("tooltipEnabled"),
		...text("tooltipDescription")
	};
	return Object.keys(presentation).length === 0 ? void 0 : presentation;
}
function presentationMaps(config, layout) {
	const halfFields = { ...layout.halfFields };
	const hiddenLabelFields = { ...layout.hiddenLabelFields };
	const fieldNotes = { ...layout.fieldNotes };
	for (const field of orderedFields(config)) {
		const presentation = field.presentation;
		if (presentation === void 0) continue;
		const name = field.componentName;
		if (presentation.halfWidth !== void 0) halfFields[name] = presentation.halfWidth;
		if (presentation.labelHidden !== void 0) hiddenLabelFields[name] = presentation.labelHidden;
		if (presentation.tooltipEnabled === false) delete fieldNotes[name];
		else if (presentation.tooltipDescription !== void 0) fieldNotes[name] = presentation.tooltipDescription;
	}
	return {
		halfFields,
		hiddenLabelFields,
		fieldNotes
	};
}
function labelFor(field) {
	return field.presentation?.label ?? field.label;
}
const SMALL_TEXT_MAX_LENGTH = 3;
const LARGE_TEXT_MIN_LENGTH = 100;
function fieldWidthFor(field, hints = {}) {
	if (field.controlPattern === ControlPattern.MultilineNote) return "full";
	if (hints.half === true) return "small";
	if (hints.wide === true) return "large";
	if (field.controlPattern === ControlPattern.ToggleFlag) return "small";
	const maxLength = field.constraints?.maxLength ?? null;
	if (field.controlPattern === ControlPattern.TextWithCounter && maxLength !== null) {
		if (maxLength <= SMALL_TEXT_MAX_LENGTH) return "small";
		if (maxLength >= LARGE_TEXT_MIN_LENGTH) return "large";
	}
	return "medium";
}
function readPriceType(value) {
	return readString(value, ContractComponent.PriceTypeCode)?.toUpperCase() ?? null;
}
const RULE_ID$4 = "BR-004";
const NOISE_SCALE = 10;
function roundToScale(value, scale) {
	const clean = Number(value.toFixed(NOISE_SCALE));
	if (scale === void 0 || scale >= NOISE_SCALE) return clean;
	const magnitude = Math.round(Number(`${Math.abs(clean).toFixed(NOISE_SCALE)}e${scale}`));
	return magnitude === 0 ? 0 : Math.sign(clean) * Number(`${magnitude}e-${scale}`);
}
function autoCalculation(context) {
	const mode = context.tradeUnit.autoCalculationMode;
	if (mode === AutoCalculationMode.None) return [];
	const priceType = readPriceType(context.value);
	if (priceType === PriceTypeCode.Deferred || priceType === PriceTypeCode.Variable) return [];
	const includesHedge = priceType !== PriceTypeCode.Unpriced;
	const basis = readNumber(context.value, ContractComponent.BasisPrice);
	const price = readNumber(context.value, ContractComponent.Price);
	const hedge = includesHedge ? readNumber(context.value, ContractComponent.HedgePrice) : null;
	const gradeAdj = readNumber(context.value, ContractComponent.GradeAdjustment);
	const freightAdj = readNumber(context.value, ContractComponent.FreightAdjustment);
	const adjustments = (gradeAdj ?? 0) + (freightAdj ?? 0) + (includesHedge ? hedge ?? 0 : 0);
	if (mode === AutoCalculationMode.Price) {
		const anyOperand = basis !== null || gradeAdj !== null || freightAdj !== null || hedge !== null;
		return [{
			componentName: ContractComponent.Price,
			readOnly: true,
			valueIntent: computedValue(anyOperand ? roundToScale((basis ?? 0) + adjustments, context.decimalPlaces?.get(ContractComponent.Price)) : null),
			formula: includesHedge ? "Price = Basis + Hedge + Grade Adj + Freight Adj" : "Price = Basis + Grade Adj + Freight Adj",
			source: RULE_ID$4
		}];
	}
	const anyOperand = price !== null || gradeAdj !== null || freightAdj !== null || hedge !== null;
	return [{
		componentName: ContractComponent.BasisPrice,
		readOnly: true,
		valueIntent: computedValue(anyOperand ? roundToScale((price ?? 0) - adjustments, context.decimalPlaces?.get(ContractComponent.BasisPrice)) : null),
		formula: includesHedge ? "Basis = Price − Hedge − Grade Adj − Freight Adj" : "Basis = Price − Grade Adj − Freight Adj",
		source: RULE_ID$4
	}];
}
const autoCalculationRule = {
	id: RULE_ID$4,
	description: "Derives and locks Price or Basis per the trade unit’s auto-calculation mode.",
	evaluate: autoCalculation
};
const RULE_ID$3 = "BR-006";
const BROKER_COMPONENTS = [
	ContractComponent.BrokerId,
	ContractComponent.BrokerRate,
	ContractComponent.BrokerContract,
	ContractComponent.BrokerUnitOfMeasure
];
function brokerCompleteness(context) {
	if (!BROKER_COMPONENTS.some((componentName) => componentName === ContractComponent.BrokerRate ? !isZeroOrBlank(context.value, componentName) : !isBlank(context.value, componentName))) return [];
	return BROKER_COMPONENTS.map((componentName) => ({
		componentName,
		required: true,
		...componentName === ContractComponent.BrokerRate ? { zeroIsBlank: true } : {},
		source: RULE_ID$3
	}));
}
const brokerCompletenessRule = {
	id: RULE_ID$3,
	description: "Broker ID/Rate/Contract/UM are all-present or all-empty, with no exemptions.",
	evaluate: brokerCompleteness
};
const RULE_ID$2 = "BR-005";
const NOT_APPLICABLE = "not applicable";
const PAIRS = [{
	priceComponent: ContractComponent.BasisPrice,
	marketMonthComponent: ContractComponent.BasisMarketMonth,
	marketMonthDescriptionComponent: ContractComponent.BasisMarketMonthDescription
}, {
	priceComponent: ContractComponent.HedgePrice,
	marketMonthComponent: ContractComponent.HedgeMarketMonth,
	marketMonthDescriptionComponent: ContractComponent.HedgeMarketMonthDescription
}];
function marketMonthRequiredness(context) {
	const overrides = [];
	for (const pair of PAIRS) {
		const description = readString(context.value, pair.marketMonthDescriptionComponent);
		if (description !== null && description.toLowerCase() === NOT_APPLICABLE) {
			overrides.push({
				componentName: pair.marketMonthComponent,
				readOnly: true,
				required: false,
				source: RULE_ID$2
			});
			continue;
		}
		if (!isZeroOrBlank(context.value, pair.priceComponent)) overrides.push({
			componentName: pair.marketMonthComponent,
			required: true,
			source: RULE_ID$2
		});
	}
	return overrides;
}
const marketMonthRequirednessRule = {
	id: RULE_ID$2,
	description: "Market month is required once its price is populated, read-only when Not Applicable.",
	evaluate: marketMonthRequiredness
};
const RULE_ID$1 = "BR-003";
const PRICE_COMPONENTS = [
	ContractComponent.Price,
	ContractComponent.BasisPrice,
	ContractComponent.GradeAdjustment,
	ContractComponent.FreightAdjustment,
	ContractComponent.HedgePrice
];
function priceTypeStates(context) {
	const priceType = readPriceType(context.value);
	if (priceType === PriceTypeCode.Deferred || priceType === PriceTypeCode.Variable) return PRICE_COMPONENTS.map((componentName) => ({
		componentName,
		readOnly: true,
		required: false,
		valueIntent: valueIntentBlank,
		source: RULE_ID$1
	}));
	if (priceType === PriceTypeCode.Unpriced) return [{
		componentName: ContractComponent.HedgePrice,
		readOnly: true,
		required: false,
		valueIntent: valueIntentBlank,
		source: RULE_ID$1
	}];
	return [];
}
const priceTypeStatesRule = {
	id: RULE_ID$1,
	description: "Price type D/V blanks and locks the price components; U blanks and locks Hedge only.",
	evaluate: priceTypeStates
};
const RULE_ID = "BR-007";
const DEFAULTED_UNIT_COMPONENTS = [ContractComponent.PriceUnitOfMeasure, ContractComponent.GradeAdjustmentUnitOfMeasure];
function unitOfMeasureDefaulting(context) {
	const quantityUnit = readString(context.value, ContractComponent.QuantityUnitOfMeasure);
	const overrides = [];
	if (quantityUnit !== null) {
		for (const componentName of DEFAULTED_UNIT_COMPONENTS) if (isBlank(context.value, componentName)) overrides.push({
			componentName,
			valueIntent: defaultValue(quantityUnit),
			source: RULE_ID
		});
	}
	const brokerUnit = ContractComponent.BrokerUnitOfMeasure;
	if (quantityUnit !== null && brokerBeingEntered(context.value) && isBlank(context.value, brokerUnit)) overrides.push({
		componentName: brokerUnit,
		valueIntent: defaultValue(quantityUnit),
		source: RULE_ID
	});
	const freightUnit = ContractComponent.FreightAdjustmentUnitOfMeasure;
	if (freightAmountIsBlank(context.value)) {
		if (!isBlank(context.value, freightUnit)) overrides.push({
			componentName: freightUnit,
			valueIntent: valueIntentBlank,
			source: RULE_ID
		});
	} else if (quantityUnit !== null && isBlank(context.value, freightUnit)) overrides.push({
		componentName: freightUnit,
		valueIntent: defaultValue(quantityUnit),
		source: RULE_ID
	});
	return overrides;
}
function brokerBeingEntered(value) {
	return !isBlank(value, ContractComponent.BrokerId) || !isZeroOrBlank(value, ContractComponent.BrokerRate) || !isBlank(value, ContractComponent.BrokerContract);
}
function freightAmountIsBlank(value) {
	const priceType = readPriceType(value);
	if (priceType === PriceTypeCode.Deferred || priceType === PriceTypeCode.Variable) return true;
	const amount = readNumber(value, ContractComponent.FreightAdjustment);
	return amount === null || amount === 0;
}
const unitOfMeasureDefaultingRule = {
	id: RULE_ID,
	description: "Price/GradeAdj UMs default to the Quantity UM while blank; the Broker UM follows the broker and the FreightAdj UM the freight amount.",
	evaluate: unitOfMeasureDefaulting
};
const CONTRACT_RULES = [
	priceTypeStatesRule,
	autoCalculationRule,
	marketMonthRequirednessRule,
	brokerCompletenessRule,
	unitOfMeasureDefaultingRule
];
const OVERRIDABLE_FLAGS = [
	"visible",
	"required",
	"readOnly",
	"borderWarning"
];
function evaluateRules(config, value, tradeUnit, facts, rules = CONTRACT_RULES) {
	const context = {
		value,
		tradeUnit,
		facts,
		decimalPlaces: decimalPlacesOf(config)
	};
	const overridesByComponent = /* @__PURE__ */ new Map();
	for (const rule of rules) for (const override of rule.evaluate(context)) {
		const existing = overridesByComponent.get(override.componentName);
		if (existing) existing.push(override);
		else overridesByComponent.set(override.componentName, [override]);
	}
	const states = /* @__PURE__ */ new Map();
	for (const section of config.sections) for (const field of section.fields) states.set(field.componentName, mergeField(field, overridesByComponent.get(field.componentName) ?? []));
	return states;
}
function decimalPlacesOf(config) {
	const scales = /* @__PURE__ */ new Map();
	for (const section of config.sections) for (const field of section.fields) {
		const scale = field.constraints?.decimalPlaces;
		if (scale !== void 0) scales.set(field.componentName, scale);
	}
	return scales;
}
function mergeField(field, overrides) {
	const behaviour = { ...field.behaviour };
	const appliedRules = [];
	const suppressedByMandate = [];
	let valueIntent = valueIntentNone;
	let formula;
	let zeroIsBlank = false;
	for (const override of overrides) {
		let contributed = false;
		if (override.zeroIsBlank === true) zeroIsBlank = true;
		for (const flag of OVERRIDABLE_FLAGS) {
			const proposed = override[flag];
			if (proposed === void 0 || proposed === behaviour[flag]) continue;
			if (field.mandatedFlags.includes(flag)) {
				if (!suppressedByMandate.includes(flag)) suppressedByMandate.push(flag);
				continue;
			}
			behaviour[flag] = proposed;
			contributed = true;
		}
		if (override.valueIntent !== void 0 && override.valueIntent.kind !== "none") {
			valueIntent = override.valueIntent;
			contributed = true;
		}
		if (override.formula !== void 0) formula = override.formula;
		if (contributed && !appliedRules.includes(override.source)) appliedRules.push(override.source);
	}
	return {
		componentName: field.componentName,
		...behaviour,
		valueIntent,
		formula,
		...zeroIsBlank ? { zeroIsBlank } : {},
		appliedRules,
		suppressedByMandate
	};
}
const NO_HEDGE_MONTH = "X";
const PRICED = "P";
const UNPRICED = "U";
const DEFERRED = "D";
const VARIABLE = "V";
const UNHEDGEABLE = "U";
function marketCascade(input) {
	const priceType = normalise(input.priceType);
	const derived = /* @__PURE__ */ new Set();
	let priceMarketCode = normalise(input.priceMarketCode);
	const priceMarketMonth = normalise(input.priceMarketMonth);
	let hedgeMarketCode = normalise(input.hedgeMarketCode);
	let hedgeMarketMonth = normalise(input.hedgeMarketMonth);
	if (priceType === UNPRICED) {
		hedgeMarketCode = null;
		derived.add("hedgeMarketCode");
	}
	const priceTypeDerivesCode = priceType === PRICED || priceType === UNPRICED || priceType === null;
	const grainFactorsHasRow = input.grainFactorsMarketCode !== null;
	if (priceTypeDerivesCode && grainFactorsHasRow) {
		derived.add("priceMarketCode");
		if (input.grainFactorsMarketCode !== void 0) priceMarketCode = normalise(input.grainFactorsMarketCode);
	}
	if (priceType === PRICED && priceMarketCode !== UNHEDGEABLE) {
		hedgeMarketCode = priceMarketCode;
		derived.add("hedgeMarketCode");
	}
	if (hedgeMarketCode === null) {
		hedgeMarketMonth = null;
		derived.add("hedgeMarketMonth");
	}
	if (hedgeMarketCode === UNHEDGEABLE && hedgeMarketMonth === null) {
		hedgeMarketMonth = "X";
		derived.add("hedgeMarketMonth");
	}
	if (priceType === PRICED && priceMarketCode !== UNHEDGEABLE && hedgeMarketCode !== null) {
		hedgeMarketMonth = priceMarketMonth;
		derived.add("hedgeMarketMonth");
	}
	const hedgeMonthLockedBlank = priceType === PRICED && !isZeroOrBlankPrice(input.hedgePrice) && hedgeMarketMonth === null && derived.has("hedgeMarketMonth");
	const redirectRequirement = hedgeMonthLockedBlank && priceMarketCode === null && !derived.has("priceMarketCode");
	const redirectToMonth = hedgeMonthLockedBlank && priceMarketCode !== null && priceMarketCode !== UNHEDGEABLE;
	return {
		priceMarketCode,
		priceMarketMonth,
		hedgeMarketCode,
		hedgeMarketMonth,
		derived: [...derived],
		pricesForbidden: priceType === DEFERRED || priceType === VARIABLE,
		requirementRedirect: redirectRequirement ? {
			require: "priceMarketCode",
			relieve: "hedgeMarketMonth"
		} : redirectToMonth ? {
			require: "priceMarketMonth",
			relieve: "hedgeMarketMonth"
		} : null
	};
}
function isZeroOrBlankPrice(value) {
	return isZeroOrBlank({ fields: { hedgePrice: value ?? null } }, "hedgePrice");
}
function normalise(value) {
	if (value === null || value === void 0) return null;
	const trimmed = value.trim().toUpperCase();
	return trimmed === "" ? null : trimmed;
}
const MAX_SHIP_PERIODS = 12;
const ShipPeriodIssueCode = {
	QuantityNotPositive: "QuantityNotPositive",
	BeginDateMissing: "BeginDateMissing",
	BeginDateInPast: "BeginDateInPast",
	EndDateMissing: "EndDateMissing",
	EndBeforeBegin: "EndBeforeBegin",
	TooManyPeriods: "TooManyPeriods"
};
const ReconciliationState = {
	Balanced: "Balanced",
	Under: "Under",
	Over: "Over"
};
const QUANTITY_EPSILON = 1e-6;
function reconcileShipPeriods(rows, contractQuantity) {
	const allocated = rows.reduce((total, row) => total + (row.quantity ?? 0), 0);
	const target = contractQuantity ?? 0;
	const remaining = round(target - allocated);
	const state = Math.abs(remaining) < QUANTITY_EPSILON ? ReconciliationState.Balanced : remaining > 0 ? ReconciliationState.Under : ReconciliationState.Over;
	return {
		allocated: round(allocated),
		contractQuantity: target,
		remaining,
		state,
		summary: buildSummary(round(allocated), target, remaining, state)
	};
}
function buildSummary(allocated, target, remaining, state) {
	const base = `${format(allocated)} of ${format(target)} allocated`;
	if (state === ReconciliationState.Balanced) return `${base} — balanced`;
	if (state === ReconciliationState.Under) return `${base} — ${format(remaining)} remaining`;
	return `${base} — ${format(Math.abs(remaining))} over`;
}
function format(value) {
	return value.toLocaleString("en-US", { maximumFractionDigits: 3 });
}
function round(value) {
	return Number(value.toFixed(6));
}
function validateShipPeriods(rows, today = null) {
	const issues = [];
	if (rows.length > 12) issues.push({
		rowIndex: null,
		code: ShipPeriodIssueCode.TooManyPeriods,
		message: `A contract may have at most 12 ship periods.`
	});
	rows.forEach((row, rowIndex) => {
		if (isEmptyRow(row)) return;
		if (row.quantity === null || row.quantity <= 0) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.QuantityNotPositive,
			message: "Enter a quantity greater than zero."
		});
		if (row.beginDate === null) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.BeginDateMissing,
			message: "Enter a begin date."
		});
		if (row.endDate === null) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.EndDateMissing,
			message: "Enter an end date."
		});
		if (row.beginDate === null) return;
		if (today !== null && compareIsoDates(row.beginDate, today) < 0) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.BeginDateInPast,
			message: "The begin date cannot be in the past."
		});
		if (row.endDate !== null && compareIsoDates(row.endDate, row.beginDate) < 0) issues.push({
			rowIndex,
			code: ShipPeriodIssueCode.EndBeforeBegin,
			message: "The end date cannot be before the begin date."
		});
	});
	return issues;
}
function isEmptyRow(row) {
	return row.beginDate === null && row.endDate === null && (row.quantity === null || row.quantity === 0);
}
function nextShipPeriod(rows) {
	if (rows.length >= 12) return null;
	const anchor = lastAnchorDate(rows);
	if (anchor === null) return {
		beginDate: null,
		endDate: null,
		quantity: null
	};
	const nextMonthDay = addMonths(anchor, 1);
	if (nextMonthDay === null) return {
		beginDate: null,
		endDate: null,
		quantity: null
	};
	const beginDate = startOfMonth(nextMonthDay);
	return {
		beginDate,
		endDate: beginDate === null ? null : endOfMonth(beginDate),
		quantity: null
	};
}
function lastAnchorDate(rows) {
	let latest = null;
	for (const row of rows) {
		const candidate = row.endDate ?? row.beginDate;
		if (candidate !== null && (latest === null || candidate > latest)) latest = candidate;
	}
	return latest;
}
function hasOverlappingPeriods(rows) {
	const spans = rows.filter((row) => row.beginDate !== null).map((row) => ({
		begin: row.beginDate,
		end: row.endDate ?? row.beginDate
	})).sort((a, b) => a.begin < b.begin ? -1 : a.begin > b.begin ? 1 : 0);
	for (let index = 1; index < spans.length; index += 1) {
		const previous = spans[index - 1];
		const current = spans[index];
		if (previous !== void 0 && current !== void 0 && current.begin <= previous.end) return true;
	}
	return false;
}
const MAX_SHIP_PERIOD_DESCRIPTION_LENGTH = 200;
const MONTH_NAMES = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
function monthName(iso) {
	const parsed = fromIsoDate(iso);
	return parsed === null ? null : MONTH_NAMES[parsed.month - 1] ?? null;
}
function isFullMonth(begin, end) {
	return startOfMonth(begin) === begin && endOfMonth(begin) === end;
}
function sameMonth(begin, end) {
	return begin.slice(0, 7) === end.slice(0, 7);
}
function formatDayMonth(iso) {
	const parsed = fromIsoDate(iso);
	const name = monthName(iso);
	return parsed === null || name === null ? null : `${name} ${parsed.day}`;
}
function formatMonthYear(iso) {
	const parsed = fromIsoDate(iso);
	const name = monthName(iso);
	return parsed === null || name === null ? null : `${name} ${parsed.year}`;
}
function buildShipPeriodDescription(row) {
	if (row.beginDate === null) return null;
	const begin = row.beginDate;
	const body = describeSpan(begin, row.endDate ?? row.beginDate);
	if (body === null) return null;
	const prefix = row.shipPeriodTypeCode?.trim();
	const description = prefix ? `${prefix} ${body}` : body;
	return description.length > 200 ? description.slice(0, 200) : description;
}
function describeSpan(begin, end) {
	if (isFullMonth(begin, end)) return formatMonthYear(begin);
	const beginParsed = fromIsoDate(begin);
	const endParsed = fromIsoDate(end);
	if (beginParsed === null || endParsed === null) return null;
	if (sameMonth(begin, end)) {
		const name = monthName(begin);
		if (name === null) return null;
		return beginParsed.day === endParsed.day ? `${name} ${beginParsed.day}, ${beginParsed.year}` : `${name} ${beginParsed.day}-${endParsed.day}, ${beginParsed.year}`;
	}
	const beginText = formatDayMonth(begin);
	const endText = formatDayMonth(end);
	if (beginText === null || endText === null) return null;
	return beginParsed.year === endParsed.year ? `${beginText} - ${endText}, ${endParsed.year}` : `${beginText}, ${beginParsed.year} - ${endText}, ${endParsed.year}`;
}
var ConstraintCatalog = class ConstraintCatalog {
	document;
	constructor(document) {
		this.document = document;
	}
	static from(document) {
		return new ConstraintCatalog(document);
	}
	get version() {
		return this.document.version;
	}
	field(name) {
		return this.document.fields[name];
	}
	collection(name) {
		return this.document.collections[name];
	}
	collectionField(collection, name) {
		return this.document.collections[collection]?.fields[name];
	}
	nestedField(collection, arrayField, name) {
		return this.collectionField(collection, arrayField)?.fields?.[name];
	}
	static numeric(entry) {
		if (entry === void 0 || entry.type !== "number" && entry.type !== "integer") return;
		const { precision, scale } = entry;
		if (precision === void 0) return;
		const resolvedScale = scale ?? 0;
		return {
			precision,
			scale: resolvedScale,
			maxIntegerDigits: precision - resolvedScale,
			roundTripsLossily: entry.readPrecision !== void 0 && entry.readPrecision > precision || entry.readScale !== void 0 && entry.readScale > resolvedScale
		};
	}
	static allowedValues(entry) {
		const values = entry?.allowedValues?.values;
		return values === void 0 || values.length === 0 ? void 0 : values;
	}
	static isWritable(entry) {
		return entry !== void 0 && entry.access !== "readOnly";
	}
	static isReadable(entry) {
		return entry !== void 0 && entry.access !== "writeOnly";
	}
	isCollectionWritable(collection) {
		return this.document.collections[collection]?.writable ?? false;
	}
	readOnlyFieldNames() {
		return Object.entries(this.document.fields).filter(([, entry]) => entry.access === "readOnly").map(([name]) => name);
	}
	writeOnlyFieldNames() {
		return Object.entries(this.document.fields).filter(([, entry]) => entry.access === "writeOnly").map(([name]) => name);
	}
};
const CONSTRAINT_SOURCE = new InjectionToken("CONSTRAINT_SOURCE");
const BUNDLED_CONSTRAINT_DOCUMENT = new InjectionToken("BUNDLED_CONSTRAINT_DOCUMENT");
function constraintValidatorsFor(entry) {
	if (entry === void 0) return [];
	switch (entry.type) {
		case "string": return entry.maxLength === void 0 ? [] : [Validators.maxLength(entry.maxLength)];
		case "number":
		case "integer": {
			const numeric = ConstraintCatalog.numeric(entry);
			return numeric === void 0 ? [] : [precisionScale(numeric.precision, numeric.scale)];
		}
		case "array": return entry.maxItems === void 0 ? [] : [maxItems(entry.maxItems)];
		case "date": return [];
		default: return [];
	}
}
function precisionScale(precision, scale) {
	const maxIntegerDigits = precision - scale;
	return (control) => {
		const value = control.value;
		if (value === null || value === void 0 || value === "") return null;
		const asNumber = typeof value === "number" ? value : Number(value);
		if (!Number.isFinite(asNumber)) return null;
		const decimals = decimalsOf(asNumber);
		const integerDigits = integerDigitsOf(asNumber);
		if (decimals > scale) return { decimalPlaces: {
			max: scale,
			actual: decimals
		} };
		if (integerDigits > maxIntegerDigits) return { numericPrecision: {
			maxIntegerDigits,
			actualIntegerDigits: integerDigits,
			precision,
			scale
		} };
		return null;
	};
}
function maxItems(max) {
	return (control) => {
		const value = control.value;
		if (!Array.isArray(value)) return null;
		return value.length > max ? { maxItems: {
			max,
			actual: value.length
		} } : null;
	};
}
function decimalsOf(value) {
	if (Number.isInteger(value)) return 0;
	const text = Math.abs(value).toString();
	const [mantissa, exponent] = text.split("e-");
	if (exponent !== void 0) {
		const mantissaDecimals = mantissa?.split(".")[1]?.length ?? 0;
		return Number(exponent) + mantissaDecimals;
	}
	return text.split(".")[1]?.length ?? 0;
}
function integerDigitsOf(value) {
	const whole = Math.trunc(Math.abs(value));
	if (whole === 0) return 0;
	return BigInt(whole.toFixed(0)).toString().length;
}
function writableFields(payload, catalog) {
	const result = {};
	for (const [name, value] of Object.entries(payload)) {
		const entry = catalog.field(name);
		if (entry === void 0 || ConstraintCatalog.isWritable(entry)) result[name] = value;
	}
	return result;
}
function staticValidatorsFor(field) {
	return configValidators(field, true);
}
const warnedUnknown = /* @__PURE__ */ new Set();
function fieldValidatorsFor(field, catalog) {
	const ctrmField = field.ctrmField;
	const entry = catalog === null || ctrmField === void 0 ? void 0 : catalog.field(ctrmField);
	if (entry === void 0) {
		if (catalog !== null && ctrmField !== void 0 && !warnedUnknown.has(ctrmField)) {
			warnedUnknown.add(ctrmField);
			console.warn(`[constraints] "${ctrmField}" is not in the constraint document, so ${field.componentName} gets no width validator from it. Unknown is not unconstrained: check the layout row.`);
		}
		return configValidators(field, true);
	}
	return [...constraintValidatorsFor(entry), ...configValidators(field, false)];
}
function configValidators(field, includeWidths) {
	const validators = [];
	const constraints = field.constraints;
	if (includeWidths && constraints?.maxLength !== void 0) validators.push(Validators.maxLength(constraints.maxLength));
	if (constraints?.minValue !== void 0) validators.push(Validators.min(constraints.minValue));
	if (constraints?.maxValue !== void 0) validators.push(Validators.max(constraints.maxValue));
	if (constraints?.allowsNegative === false) validators.push(Validators.min(0));
	if (includeWidths && constraints?.decimalPlaces !== void 0) validators.push(decimalPlaces(constraints.decimalPlaces));
	if (field.allowedValues !== void 0 && field.allowedValues.length > 0) validators.push(allowedValues(field.allowedValues.map((option) => option.code)));
	return validators;
}
function decimalPlaces(max) {
	return (control) => {
		const value = control.value;
		if (value === null || value === void 0 || value === "") return null;
		const asNumber = typeof value === "number" ? value : Number(value);
		if (!Number.isFinite(asNumber)) return null;
		const decimals = countDecimals(asNumber);
		return decimals > max ? { decimalPlaces: {
			max,
			actual: decimals
		} } : null;
	};
}
function countDecimals(value) {
	if (Number.isInteger(value)) return 0;
	const text = Math.abs(value).toString();
	if (text.includes("e-")) {
		const [, exponent] = text.split("e-");
		return Number(exponent ?? 0);
	}
	return text.split(".")[1]?.length ?? 0;
}
function allowedValues(codes) {
	const permitted = new Set(codes);
	return (control) => {
		const value = control.value;
		if (value === null || value === void 0 || value === "") return null;
		return permitted.has(String(value)) ? null : { allowedValues: { value } };
	};
}
const MAX_RECONCILE_PASSES = 8;
var FormBuilderService = class FormBuilderService {
	destroyRef = inject(DestroyRef);
	config = signal(null, ...ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []);
	tradeUnit = signal(null, ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	facts = signal(null, ...ngDevMode ? [{ debugName: "facts" }] : /* istanbul ignore next */ []);
	formValue = signal({ fields: {} }, ...ngDevMode ? [{ debugName: "formValue" }] : /* istanbul ignore next */ []);
	requirements = signal([], ...ngDevMode ? [{ debugName: "requirements" }] : /* istanbul ignore next */ []);
	validityRevision = signal(0, ...ngDevMode ? [{ debugName: "validityRevision" }] : /* istanbul ignore next */ []);
	group = null;
	catalog = null;
	passes = 0;
	appliedRequired = /* @__PURE__ */ new Map();
	effectiveStates = computed(() => {
		const config = this.config();
		const tradeUnit = this.tradeUnit();
		const facts = this.facts();
		if (config === null || tradeUnit === null || facts === null) return /* @__PURE__ */ new Map();
		const requirements = this.requirements();
		const rules = requirements.length === 0 ? CONTRACT_RULES : [...CONTRACT_RULES, screenRequirementsRule(requirements)];
		return evaluateRules(config, this.formValue(), tradeUnit, facts, rules);
	}, ...ngDevMode ? [{ debugName: "effectiveStates" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const states = this.effectiveStates();
			untracked(() => this.reconcile(states));
		});
	}
	build(config, tradeUnit, facts, catalog = null) {
		this.catalog = catalog;
		const fields = new FormRecord({});
		for (const section of [...config.sections].sort((a, b) => a.order - b.order)) for (const field of [...section.fields].sort((a, b) => a.order - b.order)) fields.addControl(field.componentName, new FormControl(null, { validators: fieldValidatorsFor(field, catalog) }));
		const group = new FormGroup({ fields });
		this.group = group;
		this.config.set(config);
		this.tradeUnit.set(tradeUnit);
		this.facts.set(facts);
		this.formValue.set(readFormValue(group));
		if (facts.isClosed || !facts.userCanEdit) group.disable({ emitEvent: false });
		group.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
			this.passes = 0;
			this.formValue.set(readFormValue(group));
		});
		return {
			group,
			value: this.formValue.asReadonly(),
			states: this.effectiveStates,
			validity: this.validityRevision.asReadonly(),
			fieldState: (componentName) => this.effectiveStates().get(componentName),
			control: (componentName) => fields.controls[componentName],
			seed: (values) => this.seed(group, fields, values),
			setRequirements: (requirements) => {
				this.passes = 0;
				this.requirements.set(requirements);
			}
		};
	}
	seed(group, fields, values) {
		let wrote = false;
		for (const [componentName, value] of Object.entries(values)) {
			const control = fields.controls[componentName];
			if (control === void 0) continue;
			control.setValue(value, { emitEvent: false });
			wrote = true;
		}
		if (!wrote) return;
		this.passes = 0;
		this.formValue.set(readFormValue(group));
	}
	reconcile(states) {
		const group = this.group;
		if (group === null || states.size === 0) return;
		this.passes += 1;
		if (this.passes > MAX_RECONCILE_PASSES) {
			console.error(`[FormBuilderService] Rule evaluation did not settle after ${MAX_RECONCILE_PASSES} passes — a rule is likely oscillating. Reconciliation stopped to avoid an infinite loop.`);
			return;
		}
		const fields = group.controls.fields;
		let changed = false;
		let revalidated = false;
		for (const [componentName, state] of states) {
			const control = fields.controls[componentName];
			if (control === void 0) continue;
			changed = this.applyValue(control, state) || changed;
			revalidated = this.applyRequired(componentName, control, state) || revalidated;
		}
		if (revalidated) this.validityRevision.update((revision) => revision + 1);
		if (changed) this.formValue.set(readFormValue(group));
	}
	applyValue(control, state) {
		const intent = state.valueIntent;
		let next;
		switch (intent.kind) {
			case "none": return false;
			case "blank":
				next = null;
				break;
			case "computed":
				next = intent.value;
				break;
			case "default":
				if (!isEmpty(control.value)) return false;
				next = intent.value;
		}
		if (Object.is(control.value, next)) return false;
		control.setValue(next, { emitEvent: false });
		return true;
	}
	applyRequired(componentName, control, state) {
		const message = state.required ? this.requiredMessageFor(componentName) : void 0;
		const applied = `${state.required}:${state.zeroIsBlank === true}:${message ?? ""}`;
		if (this.appliedRequired.get(componentName) === applied) return false;
		this.appliedRequired.set(componentName, applied);
		const config = this.config();
		const field = config === null ? void 0 : findFieldConfig(config, componentName);
		if (field === void 0) return false;
		const validators = fieldValidatorsFor(field, this.catalog);
		if (state.required) validators.push(requiredValidatorFor(state, message));
		control.setValidators(validators);
		control.updateValueAndValidity({ emitEvent: false });
		return true;
	}
	requiredMessageFor(componentName) {
		return this.requirements().find((requirement) => requirement.componentName === componentName && requirement.required)?.message;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: FormBuilderService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: FormBuilderService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: FormBuilderService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function screenRequirementsRule(requirements) {
	return {
		id: "screen",
		description: "Requirement overrides a screen supplies from facts only it knows (#1063).",
		evaluate: () => requirements.map(({ componentName, required, source }) => ({
			componentName,
			required,
			source
		}))
	};
}
function readFormValue(group) {
	return { fields: group.getRawValue().fields };
}
function isEmpty(value) {
	return value === null || value === void 0 || value === "";
}
function isRequiredValueMissing(value, state) {
	if (value === null || value === void 0 || value === "") return true;
	if (state?.zeroIsBlank !== true || typeof value === "boolean") return false;
	return (typeof value === "number" ? value : Number(String(value).trim())) === 0;
}
function requiredValidatorFor(state, message) {
	const error = message === void 0 ? { required: true } : {
		required: true,
		requiredMessage: message
	};
	return (control) => isRequiredValueMissing(control.value, state) ? error : null;
}
function findFieldConfig(config, componentName) {
	for (const section of config.sections) {
		const match = section.fields.find((field) => field.componentName === componentName);
		if (match) return match;
	}
}
function withSavedCodeDescriptions(config, saved, mode, currentCodes = /* @__PURE__ */ new Map()) {
	if (saved.size === 0) return config;
	return {
		...config,
		sections: config.sections.map((section) => ({
			...section,
			fields: section.fields.map((field) => {
				const pair = saved.get(field.componentName);
				if (pair === void 0 || pair.code.trim() === "" || pair.description.trim() === "") return field;
				return mode === "view" ? asSaved(field, pair) : markedIfReplaced(field, pair, currentCodes.get(field.componentName));
			})
		}))
	};
}
function asSaved(field, pair) {
	return {
		...field,
		controlPattern: ControlPattern.SearchableCodeCombo,
		allowedValues: [{
			code: pair.code.trim(),
			description: pair.description.trim()
		}]
	};
}
function markedIfReplaced(field, pair, current) {
	if (current === void 0) return field;
	const code = (current ?? "").trim();
	if (code === pair.code.trim()) return field;
	if (code === "") return {
		...field,
		behaviour: {
			...field.behaviour,
			borderWarning: true
		},
		warningText: `Saving clears the printed description “${pair.description.trim()}”.`
	};
	const option = (field.allowedValues ?? []).find((candidate) => candidate.code === code);
	if (option === void 0) return field;
	const savedText = normalised(pair.description);
	if (normalised(option.description).startsWith(savedText)) return field;
	return {
		...field,
		behaviour: {
			...field.behaviour,
			borderWarning: true
		},
		warningText: `Saving replaces the printed description “${pair.description.trim()}” with “${option.description.trim()}”.`
	};
}
function normalised(text) {
	return text.trim().replace(/\s+/g, " ").toUpperCase();
}
function validationMessageFor(errors) {
	if (errors === null) return null;
	const server = errors["server"];
	if (typeof server === "string" && server.trim() !== "") return server;
	if (errors["required"] !== void 0) {
		const message = errors["requiredMessage"];
		return typeof message === "string" && message.trim() !== "" ? message : "Enter a value.";
	}
	const maxLength = errors["maxlength"];
	if (maxLength?.requiredLength !== void 0) return `Use ${maxLength.requiredLength} characters or fewer.`;
	const decimals = errors["decimalPlaces"];
	if (decimals?.max !== void 0) return decimals.max === 0 ? "Enter a whole number." : `Use no more than ${decimals.max} decimal places.`;
	const min = errors["min"];
	if (min?.min !== void 0) return min.min === 0 ? "Enter a value of zero or more." : `Enter ${min.min} or more.`;
	const max = errors["max"];
	if (max?.max !== void 0) return `Enter ${max.max} or less.`;
	const digits = errors["numericPrecision"];
	if (digits?.maxIntegerDigits !== void 0) return digits.maxIntegerDigits === 0 ? "Enter a value below 1." : `Enter no more than ${digits.maxIntegerDigits} digits before the decimal point.`;
	const items = errors["maxItems"];
	if (items?.max !== void 0) return `Add no more than ${items.max} rows.`;
	if (errors["allowedValues"] !== void 0) return "Choose one of the listed values.";
	return "Check this value.";
}
const CODE_SEARCH_SOURCES = new InjectionToken("CODE_SEARCH_SOURCES");
const UNAVAILABLE_SEARCH = () => of(remoteError({ message: "No search is provided for this field." }));
var DynamicFieldComponent = class DynamicFieldComponent {
	field = input.required(...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	state = input.required(...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	control = input.required(...ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []);
	idPrefix = input("", ...ngDevMode ? [{ debugName: "idPrefix" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	skipTab = input(false, ...ngDevMode ? [{ debugName: "skipTab" }] : /* istanbul ignore next */ []);
	help = input(null, ...ngDevMode ? [{ debugName: "help" }] : /* istanbul ignore next */ []);
	marker = input(null, ...ngDevMode ? [{ debugName: "marker" }] : /* istanbul ignore next */ []);
	display = input(false, ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	compact = input(false, ...ngDevMode ? [{ debugName: "compact" }] : /* istanbul ignore next */ []);
	verdict = input(null, ...ngDevMode ? [{ debugName: "verdict" }] : /* istanbul ignore next */ []);
	verdictTone = computed(() => {
		const tone = this.verdict()?.tone;
		return tone === "valid" || tone === "invalid" ? tone : null;
	}, ...ngDevMode ? [{ debugName: "verdictTone" }] : /* istanbul ignore next */ []);
	verdictId = computed(() => this.verdict() === null ? null : `${this.controlId()}-verdict`, ...ngDevMode ? [{ debugName: "verdictId" }] : /* istanbul ignore next */ []);
	warningText = computed(() => this.display() && !this.state().borderWarning ? null : this.field().warningText ?? null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	plain = computed(() => this.state().readOnly && !this.state().borderWarning && this.errorMessage() === null, ...ngDevMode ? [{ debugName: "plain" }] : /* istanbul ignore next */ []);
	patterns = ControlPattern;
	controlId = computed(() => `${this.idPrefix()}${this.field().componentName}`, ...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	controlEvents = toSignal(toObservable(this.control).pipe(switchMap((control) => control.events.pipe(startWith(null)))), { initialValue: null });
	errorMessage = computed(() => {
		this.controlEvents();
		const control = this.control();
		if (!control.touched || control.valid) return null;
		return validationMessageFor(control.errors);
	}, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	maxLength = computed(() => this.field().constraints?.maxLength ?? null, ...ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []);
	allowedValues = computed(() => this.field().allowedValues ?? [], ...ngDevMode ? [{ debugName: "allowedValues" }] : /* istanbul ignore next */ []);
	searchSources = inject(CODE_SEARCH_SOURCES, { optional: true });
	codeSearch = computed(() => {
		const key = this.field().searchSet;
		const source = key === void 0 ? void 0 : this.searchSources?.[key];
		return source === void 0 ? UNAVAILABLE_SEARCH : (text) => source.search(text);
	}, ...ngDevMode ? [{ debugName: "codeSearch" }] : /* istanbul ignore next */ []);
	unsupported = computed(() => {
		return ![
			ControlPattern.SearchableCodeCombo,
			ControlPattern.EntityTypeahead,
			ControlPattern.MaskedDate,
			ControlPattern.QuantityDecimal,
			ControlPattern.TextWithCounter,
			ControlPattern.MultilineNote,
			ControlPattern.ToggleFlag
		].includes(this.field().controlPattern);
	}, ...ngDevMode ? [{ debugName: "unsupported" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: DynamicFieldComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: DynamicFieldComponent,
		isStandalone: true,
		selector: "cms-dynamic-field",
		inputs: {
			field: {
				classPropertyName: "field",
				publicName: "field",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			state: {
				classPropertyName: "state",
				publicName: "state",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			control: {
				classPropertyName: "control",
				publicName: "control",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			idPrefix: {
				classPropertyName: "idPrefix",
				publicName: "idPrefix",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			skipTab: {
				classPropertyName: "skipTab",
				publicName: "skipTab",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			help: {
				classPropertyName: "help",
				publicName: "help",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			marker: {
				classPropertyName: "marker",
				publicName: "marker",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			display: {
				classPropertyName: "display",
				publicName: "display",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			compact: {
				classPropertyName: "compact",
				publicName: "compact",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			verdict: {
				classPropertyName: "verdict",
				publicName: "verdict",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<!--\r\n  @if on visibility rather than [hidden] or a CSS class: a hidden-by-CSS field stays in the tab\r\n  sequence, and 02a §4.2 makes tab order an acceptance criterion. The FormControl still exists\r\n  either way, so the value survives a rule turning the field back on.\r\n-->\r\n@if (state().visible) {\r\n  @switch (field().controlPattern) {\r\n    @case (patterns.SearchableCodeCombo) {\r\n      <cms-code-combo\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [options]=\"allowedValues()\"\r\n        [compact]=\"compact()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.EntityTypeahead) {\r\n      <!--\r\n        C2 (#1064): the code combo in search mode. The list is a server search for what was typed,\r\n        and a typed code still commits, because CTRM checks it on save. No options: the search is\r\n        the list.\r\n      -->\r\n      <cms-code-combo\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [options]=\"allowedValues()\"\r\n        [search]=\"codeSearch()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MaskedDate) {\r\n      <cms-date-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.QuantityDecimal) {\r\n      <!-- formula comes from the rules (BR-004), so it reads from state, not config. -->\r\n      <cms-quantity-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [decimalPlaces]=\"field().constraints?.decimalPlaces ?? 2\"\r\n        [allowNegative]=\"field().constraints?.allowsNegative ?? false\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [formula]=\"state().formula ?? null\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.TextWithCounter) {\r\n      <cms-text-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MultilineNote) {\r\n      <cms-note-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.ToggleFlag) {\r\n      <cms-toggle\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @default {\r\n      <!--\r\n        A pattern the form engine does not render, by ruling (F2.2b, #737, 2026-10-08). No layout\r\n        row carries one, and `control-pattern-renderer.spec.ts` in `@cws/domain-contracts` keeps it\r\n        that way. Where each renders instead:\r\n          C7  status badge     — `cms-status-badge` in the grid, the chrome and the user menu; the\r\n                                 record's confirmation ribbon draws its own step chip\r\n          C8  data grid        — `cms-data-grid` on home, approvals, pricing and the record page\r\n          C10 warning border   — every case above binds `[borderWarning]` and `[warningText]`; it\r\n                                 is a property of each control, not a pattern a row can be\r\n          C11 inline PDF       — the record's Documents tab (`contract-documents-tab.component.ts`)\r\n        C2 left this list with #1064: it is rendered above, as the code combo in search mode.\r\n        Shown, labelled and named rather than thrown or skipped: throwing takes down the whole form\r\n        for one field, and skipping leaves an invisible control holding unsaveable data. Deliberately\r\n        NOT falling back to a text input — a date rendered as free text looks finished and never\r\n        gets revisited.\r\n      -->\r\n      <!--\r\n        ⚠ `[labelFor]=\"false\"` because there is no control to point at. The default renders a\r\n        `<label for>`, and a label referencing an element that does not exist is worse than a plain\r\n        heading: it looks like an association and is not one.\r\n      -->\r\n      <cms-field [label]=\"field().label\" [controlId]=\"controlId()\" [labelFor]=\"false\">\r\n        <div\r\n          class=\"cws:rounded-lg cws:border cws:border-dashed cws:border-slate-300 cws:px-4 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:border-slate-600 cws:dark:text-slate-400\"\r\n          role=\"note\"\r\n        >\r\n          Control pattern {{ field().controlPattern }} is not rendered by the form engine.\r\n        </div>\r\n      </cms-field>\r\n    }\r\n  }\r\n}\r\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: CodeComboComponent,
				selector: "cms-code-combo",
				inputs: [
					"label",
					"controlId",
					"options",
					"required",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"compact",
					"search",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage",
					"tone",
					"describedByExtra"
				]
			},
			{
				kind: "component",
				type: DateInputComponent,
				selector: "cms-date-input",
				inputs: [
					"label",
					"controlId",
					"required",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: NoteInputComponent,
				selector: "cms-note-input",
				inputs: [
					"label",
					"controlId",
					"maxLength",
					"rows",
					"required",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: QuantityInputComponent,
				selector: "cms-quantity-input",
				inputs: [
					"label",
					"controlId",
					"unitOfMeasure",
					"decimalPlaces",
					"allowNegative",
					"required",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"formula",
					"borderWarning",
					"warningText",
					"errorMessage",
					"tone",
					"describedByExtra"
				]
			},
			{
				kind: "component",
				type: TextInputComponent,
				selector: "cms-text-input",
				inputs: [
					"label",
					"hideLabel",
					"controlId",
					"maxLength",
					"required",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage",
					"tone",
					"describedByExtra"
				]
			},
			{
				kind: "component",
				type: ToggleComponent,
				selector: "cms-toggle",
				inputs: [
					"label",
					"controlId",
					"onLabel",
					"offLabel",
					"required",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: FieldComponent,
				selector: "cms-field",
				inputs: [
					"label",
					"controlId",
					"required",
					"hideLabel",
					"errorMessage",
					"hint",
					"labelFor",
					"help",
					"marker",
					"display"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: DynamicFieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-dynamic-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ReactiveFormsModule,
				CodeComboComponent,
				DateInputComponent,
				NoteInputComponent,
				QuantityInputComponent,
				TextInputComponent,
				ToggleComponent,
				FieldComponent
			],
			template: "<!--\r\n  @if on visibility rather than [hidden] or a CSS class: a hidden-by-CSS field stays in the tab\r\n  sequence, and 02a §4.2 makes tab order an acceptance criterion. The FormControl still exists\r\n  either way, so the value survives a rule turning the field back on.\r\n-->\r\n@if (state().visible) {\r\n  @switch (field().controlPattern) {\r\n    @case (patterns.SearchableCodeCombo) {\r\n      <cms-code-combo\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [options]=\"allowedValues()\"\r\n        [compact]=\"compact()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.EntityTypeahead) {\r\n      <!--\r\n        C2 (#1064): the code combo in search mode. The list is a server search for what was typed,\r\n        and a typed code still commits, because CTRM checks it on save. No options: the search is\r\n        the list.\r\n      -->\r\n      <cms-code-combo\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [options]=\"allowedValues()\"\r\n        [search]=\"codeSearch()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MaskedDate) {\r\n      <cms-date-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.QuantityDecimal) {\r\n      <!-- formula comes from the rules (BR-004), so it reads from state, not config. -->\r\n      <cms-quantity-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [decimalPlaces]=\"field().constraints?.decimalPlaces ?? 2\"\r\n        [allowNegative]=\"field().constraints?.allowsNegative ?? false\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [formula]=\"state().formula ?? null\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.TextWithCounter) {\r\n      <cms-text-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n        [tone]=\"verdictTone()\"\r\n        [describedByExtra]=\"verdictId()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.MultilineNote) {\r\n      <cms-note-input\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [maxLength]=\"maxLength()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @case (patterns.ToggleFlag) {\r\n      <cms-toggle\r\n        [formControl]=\"control()\"\r\n        [label]=\"field().label\"\r\n        [hideLabel]=\"hideLabel()\"\r\n        [controlId]=\"controlId()\"\r\n        [required]=\"state().required\"\r\n        [readOnly]=\"state().readOnly\"\r\n        [plain]=\"plain()\"\r\n        [display]=\"display()\"\r\n        [help]=\"help()\"\r\n        [marker]=\"marker()\"\r\n        [skipTab]=\"skipTab()\"\r\n        [borderWarning]=\"state().borderWarning\"\r\n        [warningText]=\"warningText()\"\r\n        [errorMessage]=\"errorMessage()\"\r\n      />\r\n    }\r\n\r\n    @default {\r\n      <!--\r\n        A pattern the form engine does not render, by ruling (F2.2b, #737, 2026-10-08). No layout\r\n        row carries one, and `control-pattern-renderer.spec.ts` in `@cws/domain-contracts` keeps it\r\n        that way. Where each renders instead:\r\n          C7  status badge     — `cms-status-badge` in the grid, the chrome and the user menu; the\r\n                                 record's confirmation ribbon draws its own step chip\r\n          C8  data grid        — `cms-data-grid` on home, approvals, pricing and the record page\r\n          C10 warning border   — every case above binds `[borderWarning]` and `[warningText]`; it\r\n                                 is a property of each control, not a pattern a row can be\r\n          C11 inline PDF       — the record's Documents tab (`contract-documents-tab.component.ts`)\r\n        C2 left this list with #1064: it is rendered above, as the code combo in search mode.\r\n        Shown, labelled and named rather than thrown or skipped: throwing takes down the whole form\r\n        for one field, and skipping leaves an invisible control holding unsaveable data. Deliberately\r\n        NOT falling back to a text input — a date rendered as free text looks finished and never\r\n        gets revisited.\r\n      -->\r\n      <!--\r\n        ⚠ `[labelFor]=\"false\"` because there is no control to point at. The default renders a\r\n        `<label for>`, and a label referencing an element that does not exist is worse than a plain\r\n        heading: it looks like an association and is not one.\r\n      -->\r\n      <cms-field [label]=\"field().label\" [controlId]=\"controlId()\" [labelFor]=\"false\">\r\n        <div\r\n          class=\"cws:rounded-lg cws:border cws:border-dashed cws:border-slate-300 cws:px-4 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:border-slate-600 cws:dark:text-slate-400\"\r\n          role=\"note\"\r\n        >\r\n          Control pattern {{ field().controlPattern }} is not rendered by the form engine.\r\n        </div>\r\n      </cms-field>\r\n    }\r\n  }\r\n}\r\n"
		}]
	}],
	propDecorators: {
		field: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "field",
				required: true
			}]
		}],
		state: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "state",
				required: true
			}]
		}],
		control: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "control",
				required: true
			}]
		}],
		idPrefix: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "idPrefix",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		skipTab: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "skipTab",
				required: false
			}]
		}],
		help: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "help",
				required: false
			}]
		}],
		marker: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "marker",
				required: false
			}]
		}],
		display: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "display",
				required: false
			}]
		}],
		compact: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "compact",
				required: false
			}]
		}],
		verdict: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "verdict",
				required: false
			}]
		}]
	}
});
function validationSummary(form, config) {
	const states = form.states();
	const items = [];
	for (const section of [...config.sections].sort((a, b) => a.order - b.order)) for (const field of [...section.fields].sort((a, b) => a.order - b.order)) {
		const control = form.control(field.componentName);
		const errors = control?.errors ?? null;
		const message = validationMessageFor(errors);
		if (control === void 0 || errors === null || message === null) continue;
		const source = "server" in errors ? "server" : "client";
		const hidden = !section.visible || !(states.get(field.componentName)?.visible ?? field.behaviour.visible);
		items.push({
			componentName: field.componentName,
			label: field.label,
			sectionId: section.componentName,
			message,
			source,
			hidden,
			blocking: source === "client" && !hidden && (control.dirty || "required" in errors),
			noticed: source === "server" || control.touched || control.dirty,
			required: source === "client" && "required" in errors
		});
	}
	return items;
}
var ValidationSummaryComponent = class ValidationSummaryComponent {
	entries = input.required(...ngDevMode ? [{ debugName: "entries" }] : /* istanbul ignore next */ []);
	expanded = input(true, ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	expandedChange = output();
	open = linkedSignal(() => this.expanded(), ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	chosen = output();
	host = inject(ElementRef);
	blockingCount = computed(() => this.entries().filter((entry) => entry.blocking).length, ...ngDevMode ? [{ debugName: "blockingCount" }] : /* istanbul ignore next */ []);
	heading = computed(() => {
		const count = this.entries().length;
		return count === 1 ? "1 field needs attention" : `${count} fields need attention`;
	}, ...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	announcement = computed(() => {
		const blocking = this.blockingCount();
		return blocking === 0 ? this.heading() : `${this.heading()}. ${blocking} must be fixed before saving.`;
	}, ...ngDevMode ? [{ debugName: "announcement" }] : /* istanbul ignore next */ []);
	toggle() {
		this.setOpen(!this.open());
	}
	setOpen(open) {
		this.open.set(open);
		this.expandedChange.emit(open);
	}
	focusNext() {
		if (!this.open()) this.setOpen(true);
		queueMicrotask(() => {
			const root = this.host.nativeElement;
			const toggle = root.querySelector("[data-summary-toggle]");
			const items = [...root.querySelectorAll("[data-summary-item]")];
			const active = document.activeElement;
			if (active === null || !root.contains(active) || items.length === 0) {
				toggle?.focus();
				return;
			}
			items[(items.indexOf(active) + 1) % items.length].focus();
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.1",
		ngImport: i0,
		type: ValidationSummaryComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.1",
		type: ValidationSummaryComponent,
		isStandalone: true,
		selector: "cms-validation-summary",
		inputs: {
			entries: {
				classPropertyName: "entries",
				publicName: "entries",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			expanded: {
				classPropertyName: "expanded",
				publicName: "expanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			expandedChange: "expandedChange",
			chosen: "chosen"
		},
		host: { classAttribute: "cws:block cws:w-full" },
		ngImport: i0,
		template: "<section class=\"scoular-alert scoular-alert-warning\" aria-label=\"Validation summary\">\r\n  <div class=\"scoular-alert-content cws:w-full\">\r\n    <!--\r\n      The heading is the toggle, so the count is what a collapsed panel shows. F8 lands here first.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-alert-title cws:flex cws:w-full cws:items-center cws:justify-between cws:text-left\"\r\n      data-summary-toggle\r\n      aria-controls=\"validation-summary-list\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      (click)=\"toggle()\"\r\n    >\r\n      <span>{{ heading() }}</span>\r\n      <span aria-hidden=\"true\">{{ open() ? '▴' : '▾' }}</span>\r\n    </button>\r\n\r\n    <!-- Polite: a count changing as the user types must not interrupt them. -->\r\n    <p class=\"cws:sr-only\" aria-live=\"polite\">{{ announcement() }}</p>\r\n\r\n    @if (open()) {\r\n      @if (blockingCount() > 0) {\r\n        <p class=\"scoular-alert-description cws:mt-1\">\r\n          Save is held until the fields marked \"must fix\" are corrected.\r\n        </p>\r\n      }\r\n      <ul id=\"validation-summary-list\" class=\"cws:mt-1 cws:space-y-0.5\">\r\n        @for (entry of entries(); track entry.key) {\r\n          <li>\r\n            <button\r\n              type=\"button\"\r\n              class=\"cws:text-left cws:underline cws:decoration-dotted cws:underline-offset-2 cws:hover:decoration-solid cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue\"\r\n              data-summary-item\r\n              (click)=\"chosen.emit(entry)\"\r\n            >\r\n              <span class=\"cws:font-semibold\">{{ entry.label }}</span>\r\n              @if (entry.where) {\r\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\"> ({{ entry.where }})</span>\r\n              }\r\n              <span>: {{ entry.message }}</span>\r\n              @if (entry.blocking) {\r\n                <span class=\"cws:font-semibold\"> Must fix.</span>\r\n              }\r\n              @if (entry.hidden) {\r\n                <span> Hidden by configuration, so it cannot be edited here.</span>\r\n              }\r\n            </button>\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n</section>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.1",
	ngImport: i0,
	type: ValidationSummaryComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-validation-summary",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block cws:w-full" },
			template: "<section class=\"scoular-alert scoular-alert-warning\" aria-label=\"Validation summary\">\r\n  <div class=\"scoular-alert-content cws:w-full\">\r\n    <!--\r\n      The heading is the toggle, so the count is what a collapsed panel shows. F8 lands here first.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-alert-title cws:flex cws:w-full cws:items-center cws:justify-between cws:text-left\"\r\n      data-summary-toggle\r\n      aria-controls=\"validation-summary-list\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      (click)=\"toggle()\"\r\n    >\r\n      <span>{{ heading() }}</span>\r\n      <span aria-hidden=\"true\">{{ open() ? '▴' : '▾' }}</span>\r\n    </button>\r\n\r\n    <!-- Polite: a count changing as the user types must not interrupt them. -->\r\n    <p class=\"cws:sr-only\" aria-live=\"polite\">{{ announcement() }}</p>\r\n\r\n    @if (open()) {\r\n      @if (blockingCount() > 0) {\r\n        <p class=\"scoular-alert-description cws:mt-1\">\r\n          Save is held until the fields marked \"must fix\" are corrected.\r\n        </p>\r\n      }\r\n      <ul id=\"validation-summary-list\" class=\"cws:mt-1 cws:space-y-0.5\">\r\n        @for (entry of entries(); track entry.key) {\r\n          <li>\r\n            <button\r\n              type=\"button\"\r\n              class=\"cws:text-left cws:underline cws:decoration-dotted cws:underline-offset-2 cws:hover:decoration-solid cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue\"\r\n              data-summary-item\r\n              (click)=\"chosen.emit(entry)\"\r\n            >\r\n              <span class=\"cws:font-semibold\">{{ entry.label }}</span>\r\n              @if (entry.where) {\r\n                <span class=\"cws:text-slate-600 cws:dark:text-slate-300\"> ({{ entry.where }})</span>\r\n              }\r\n              <span>: {{ entry.message }}</span>\r\n              @if (entry.blocking) {\r\n                <span class=\"cws:font-semibold\"> Must fix.</span>\r\n              }\r\n              @if (entry.hidden) {\r\n                <span> Hidden by configuration, so it cannot be edited here.</span>\r\n              }\r\n            </button>\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n</section>\r\n"
		}]
	}],
	propDecorators: {
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: true
			}]
		}],
		expanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "expanded",
				required: false
			}]
		}],
		expandedChange: [{
			type: i0.Output,
			args: ["expandedChange"]
		}],
		chosen: [{
			type: i0.Output,
			args: ["chosen"]
		}]
	}
});
export { AutoCalculationMode, BUNDLED_CONSTRAINT_DOCUMENT, CODE_SEARCH_SOURCES, CONSTRAINT_SOURCE, CONTRACT_RULES, ConstraintCatalog, ContractComponent, ContractPrefixType, ControlPattern, DynamicFieldComponent, FormBuilderService, MAX_SHIP_PERIODS, MAX_SHIP_PERIOD_DESCRIPTION_LENGTH, NO_HEDGE_MONTH, PriceTypeCode, ReconciliationState, ShipPeriodIssueCode, ValidationSummaryComponent, allowedValues, autoCalculation, autoCalculationRule, brokerCompleteness, brokerCompletenessRule, buildShipPeriodDescription, computedValue, constraintValidatorsFor, decimalPlaces, defaultValue, evaluateRules, fieldValidatorsFor, fieldWidthFor, findField, hasOverlappingPeriods, isBlank, isRequiredValueMissing, isZeroOrBlank, labelFor, marketCascade, marketMonthRequiredness, marketMonthRequirednessRule, maxItems, nextShipPeriod, orderedFields, precisionScale, presentationFrom, presentationMaps, priceTypeStates, priceTypeStatesRule, readFormValue, readNumber, readString, reconcileShipPeriods, staticValidatorsFor, unitOfMeasureDefaulting, unitOfMeasureDefaultingRule, validateShipPeriods, validationMessageFor, validationSummary, valueIntentBlank, valueIntentNone, withSavedCodeDescriptions, writableFields };

//# sourceMappingURL=cws-shared-form-engine.mjs.map
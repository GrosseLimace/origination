import { InjectionToken } from "@angular/core";
const CMS_HOST_CONTEXT = new InjectionToken("CMS_HOST_CONTEXT");
const testHostContext = (overrides = {}) => ({
	tradeUnit: () => "2087",
	user: () => testHostUser(),
	theme: () => "light",
	baseHref: () => "/",
	auth: testHostAuth(),
	navigate: () => void 0,
	hrefFor: (intent) => intent.kind === "module" ? `/${intent.module}` : `#cws-intent:${intent.kind}`,
	...overrides
});
const testHostUser = (overrides = {}) => ({
	id: "00000000-0000-0000-0000-000000000000",
	username: "jfrisbie@scoular.com",
	displayName: "Jacob Frisbie",
	...overrides
});
const testHostAuth = (overrides = {}) => ({
	isSignedIn: () => true,
	accessToken: () => Promise.resolve("test-access-token"),
	...overrides
});
const recordingHostContext = (overrides = {}) => {
	const intents = [];
	return {
		intents,
		context: testHostContext({
			navigate: (intent) => {
				intents.push(intent);
			},
			...overrides
		})
	};
};
function routerHostContext(router, parts) {
	return {
		tradeUnit: parts.tradeUnit,
		user: parts.user,
		theme: parts.theme,
		baseHref: parts.baseHref,
		auth: parts.auth,
		navigate: (intent) => {
			const destination = destinationFor(router, parts.routes, intent);
			if ("tree" in destination) router.navigateByUrl(destination.tree);
			else if (destination.extras === void 0) router.navigate([...destination.commands]);
			else router.navigate([...destination.commands], destination.extras);
		},
		hrefFor: (intent) => {
			const destination = destinationFor(router, parts.routes, intent);
			return router.serializeUrl("tree" in destination ? destination.tree : router.createUrlTree([...destination.commands], destination.extras));
		}
	};
}
function destinationFor(router, routes, intent) {
	switch (intent.kind) {
		case "contract": {
			const commands = intent.mode === "edit" ? routes.editContract(intent.contractNumber) : routes.contract(intent.contractNumber);
			return intent.params === void 0 ? { commands } : {
				commands,
				extras: { queryParams: { ...intent.params } }
			};
		}
		case "new-contract": return {
			commands: routes.newContract(),
			extras: { queryParams: { ...intent.params } }
		};
		case "review": return {
			commands: routes.review(intent.origin, intent.contractNumber),
			extras: { queryParams: { ...intent.params } }
		};
		case "origin": return {
			commands: routes.origin(intent.origin),
			extras: { queryParams: { ...intent.params } }
		};
		case "module": return {
			commands: routes.module(intent.module),
			extras: intent.params ? { queryParams: { ...intent.params } } : void 0
		};
		case "view-state": return { tree: viewStateTree(router, intent.params) };
	}
}
function viewStateTree(router, params) {
	const tree = router.parseUrl(router.url);
	tree.queryParams = { ...params };
	return tree;
}
export { CMS_HOST_CONTEXT, recordingHostContext, routerHostContext, testHostAuth, testHostContext, testHostUser };

//# sourceMappingURL=cws-core-host-context.mjs.map
import { InjectionToken } from "@angular/core";
import { Router } from "@angular/router";
/**
 * Which theme the host is currently showing.
 *
 * The **resolved** value, never the preference: `ThemeStore` in the shell distinguishes `light`,
 * `dark` and `system`, and `system` is not a thing a component can render against. A library asking
 * this question is asking "which of my two icon variants do I draw", and that has exactly two
 * answers.
 */
export type CmsHostTheme = 'light' | 'dark';
/**
 * Who the host says is signed in.
 *
 * ### 🔴 There are deliberately NO roles here, and that absence is load-bearing
 *
 * `PermissionContext` already answers "what may this caller do", and it answers it **by intent** —
 * `canEditPricing()`, not `roles.includes('Admin')`. Its own docstring states the one rule for
 * consumers: *read a function off this context, never inspect roles.* Putting a role list on the
 * host context would create a second, untyped way to ask the same question, and the second one is
 * the one that breaks when F1.3's per-trade-unit matrix (#138) makes the four capabilities stop
 * agreeing with each other.
 *
 * So this carries **identity**, and `PERMISSION_CONTEXT` carries **authority**. A host supplies both;
 * they are not the same seam and must not be collapsed.
 *
 * ### Why three fields rather than one
 *
 * Correction **C-13** keys on the token's immutable `oid` and carries the UPN denormalised for
 * display and audit, because a changed UPN silently orphans every row keyed on it. The same split
 * applies here: {@link id} is what a host should key anything on, {@link username} is what an audit
 * row records, and {@link displayName} is the only one meant to be read by a person.
 */
export interface CmsHostUser {
  /**
   * The immutable directory object id (`oid`), or `null` when the host will not say.
   *
   * ⚠ **Never key on {@link username} instead.** It is neither immutable nor guaranteed unique, which
   * is the whole reason C-13 exists.
   */
  readonly id: string | null;
  /** The sign-in name, normally the work email. What an audit row records (C-13). */
  readonly username: string | null;
  /** A human-readable name for display only. May collide between two people; never key on it. */
  readonly displayName: string | null;
}
/**
 * How a feature library obtains an access token, without knowing how the host signs anyone in.
 *
 * ### Why this exists at all
 *
 * `@cws/core-auth` owns MSAL, and its public API already records the constraint: *no feature library
 * may depend on MSAL directly — a host application under Module Federation supplies the token
 * instead, and a feature that imported MSAL could not be embedded.* This interface is the shape of
 * "supplies the token instead".
 *
 * The shell implements it over `CmsAuthService`. Originations implements it over whatever it already
 * has. Neither implementation appears in a feature library.
 */
export interface CmsHostAuth {
  /**
   * Whether the host currently has a signed-in principal.
   *
   * ⚠ **`false` is ambiguous by design**, exactly as `CmsAuthService.roles` is: not signed in, no
   * role assigned, and a token that could not be acquired all read the same. Treat it as "a call
   * will not carry credentials" and let the API's own 401/403 say which.
   */
  readonly isSignedIn: () => boolean;
  /**
   * An access token for the given scopes, or `null` when one cannot be had **silently**.
   *
   * ### 🔴 Silent acquisition only — an implementation must never redirect from here
   *
   * A feature library calls this during rendering. An implementation that escalated to an
   * interactive redirect would bounce the user to the identity provider from inside a component,
   * losing unsaved form state on a screen with 104 editable fields. The shell's `CmsAuthService`
   * already takes this position twice, in `readRoles` and `loadPhoto`, and for the same reason.
   *
   * `null` therefore means "ask the host to sign in", not "this failed".
   */
  readonly accessToken: (scopes?: readonly string[]) => Promise<string | null>;
}
/**
 * The workspace's modules, by logical name, for the `module` intent (2026-09-30, F9.10).
 *
 * `pricing-approvals` is a module of its own because Pricing links to it as a sibling screen, not as
 * a review of one contract.
 */
export type CwsModule = 'home' | 'approvals' | 'pricing' | 'pricing-approvals' | 'admin';
/**
 * Where a screen wants to go. **The host decides what that means.**
 *
 * ### 🔴 Why an intent rather than a URL
 *
 * The record screen used to call `router.navigate(['/contracts', destination])` — an **absolute**
 * path at the application root. Embedded, that escapes the host's outlet entirely and lands the user
 * somewhere the host never routed. The 2026-09-18 host-workspace spike found it (#335 finding 3) and
 * `public-api.ts` claimed the opposite was already true.
 *
 * A URL is the shell's answer to a question the screen should not be asking. The screen knows it
 * wants *this contract*; only the host knows what that is called in its own routing table.
 *
 * ### The three kinds, and why `view-state` is one of them
 *
 * The first two leave the screen. The third does not — it is the screen recording its own position
 * so a refresh or a shared link reproduces it.
 *
 * 🔴 **`view-state` is not optional for a host to honour.** `activeTab` is a `computed` reading the
 * query parameter map and nothing else, so a host that swallows a `view-state` intent produces a
 * screen whose tabs do not switch — the click registers, the signal never changes, and nothing
 * anywhere reports it. That is asserted in the embedded harness (F9.3) rather than left to be
 * discovered.
 */
export type CmsNavigationIntent =
/**
 * Open a contract record.
 *
 * `mode` defaults to `view`. `params` is view state to open it with (the tab), already flattened.
 * Both are optional additions (2026-09-28): an intent without them means exactly what it always did.
 */
{
  readonly kind: 'contract';
  readonly contractNumber: string;
  readonly mode?: 'view' | 'edit';
  readonly params?: Readonly<Record<string, string>>;
} |
/**
 * Start a new contract. `params` carries `copyFrom` when it is a copy of an existing one.
 * Added 2026-09-28 for the New and Copy anchors, which used to carry the shell's `/contracts/new`.
 */
{
  readonly kind: 'new-contract';
  readonly params: Readonly<Record<string, string>>;
} |
/**
 * Go to the origin's own review of this contract, the breadcrumb's middle crumb: the approval
 * detail when the record was opened from Approvals, or the price sequences from Pricing. A host
 * with no such screen may resolve it to the origin itself. Added 2026-09-28.
 */
{
  readonly kind: 'review';
  readonly origin: string;
  readonly contractNumber: string;
  readonly params: Readonly<Record<string, string>>;
} |
/**
 * Leave the record for the screen the journey started on.
 *
 * `origin` is a logical name (`workspace`, `approvals`, `pricing`), not a path — that is the whole
 * point. `params` is the state to restore there, already flattened to strings.
 */
{
  readonly kind: 'origin';
  readonly origin: string;
  readonly params: Readonly<Record<string, string>>;
} |
/**
 * Go to one of the workspace's modules (2026-09-30, F9.10).
 *
 * The chrome's module nav and a queue's link to a sibling module (Pricing → Pricing approvals)
 * used to carry the shell's absolute paths, which escape a host's prefix. Like `origin`, the module
 * is a logical name; the host's route table says what it is called. `params` is a query string to
 * open it with.
 */
{
  readonly kind: 'module';
  readonly module: CwsModule;
  readonly params?: Readonly<Record<string, string>>;
} |
/**
 * Stay here; record this view state.
 *
 * `params` is the **complete** intended parameter set, not a patch — the shell's implementation
 * replaces rather than merges, matching what `paramsForTab` has always produced.
 */
{
  readonly kind: 'view-state';
  readonly params: Readonly<Record<string, string>>;
};
/**
 * Everything a CWS feature needs from the application hosting it (ADR-13).
 *
 * ### The seam, and why it is shaped like the two that already exist
 *
 * `TRADE_UNIT_CONTEXT` and `PERMISSION_CONTEXT` are already provided by the shell and consumed by
 * features through a token, precisely so that a Module Federation host can supply its own
 * (docs/02 §1a, 03 §3.4). This is the same arrangement for the things those two do not cover:
 * identity, theme, the base href, and — the one that was actually broken — navigation.
 *
 * ⚠ **{@link tradeUnit} duplicates `TRADE_UNIT_CONTEXT` on purpose, and does not replace it.** A
 * host supplying this context should supply both from one source; the older token stays because five
 * screens read it and re-pointing them is not F9.1's scope. If they are ever wired to disagree, the
 * host has a bug — the harness asserts they agree.
 *
 * ### What is deliberately NOT here
 *
 * **Roles** — see {@link CmsHostUser}. **HTTP** — the host's interceptors apply and
 * `problemDetailsInterceptor` is installed at the shell for exactly that reason. **Anything that
 * writes to `document`** — the shell's `ThemeStore` already records why a library must never reach
 * up and toggle a class on the host's `<html>`.
 */
export interface CmsHostContext {
  /** The active trade unit, or `null` when the host has not chosen one. */
  readonly tradeUnit: () => string | null;
  /** The signed-in principal, or `null`. Identity only — authority lives on `PERMISSION_CONTEXT`. */
  readonly user: () => CmsHostUser | null;
  /** Which theme is being shown right now, resolved. */
  readonly theme: () => CmsHostTheme;
  /**
   * The host's base href, with a trailing slash.
   *
   * For building an absolute link a user can copy — "copy link to this contract" — not for routing,
   * which goes through {@link navigate}. Embedded, this is the host's base and not ours.
   */
  readonly baseHref: () => string;
  /** How the host signs people in and hands out tokens. */
  readonly auth: CmsHostAuth;
  /** Where the screen wants to go. See {@link CmsNavigationIntent}. */
  readonly navigate: (intent: CmsNavigationIntent) => void;
  /**
   * The `href` an anchor for this intent should carry, in the HOST's URL space.
   *
   * 🔴 **Why it exists** (F9.1 criterion 1, found by the embedding host on 2026-09-28). The screen's
   * anchors are real links, so middle-click, open-in-new-tab and copy-link work, and a real link needs
   * an `href`. They used to take it from the shell's absolute paths (`/contracts/...`), so embedded,
   * Edit pointed at a route the host did not have and a click dropped the user on the host's own
   * dashboard. The host is the only party that knows its URLs.
   *
   * A plain click on such an anchor still goes through {@link navigate}; the `href` serves the
   * browser's own gestures. It must therefore describe the same destination {@link navigate} would.
   */
  readonly hrefFor: (intent: CmsNavigationIntent) => string;
}
/**
 * The host context.
 *
 * 🔴 **Required, with no default factory, deliberately.** A defaulted token would let a host mount a
 * screen having wired nothing and get silent no-op navigation — a screen where Save-and-close does
 * nothing at all, with no error. `NG0201` naming this token is a far better failure, and it is the
 * one the embedded harness plants on purpose (F9.3).
 */
export declare const CMS_HOST_CONTEXT: InjectionToken<CmsHostContext>;
/**
 * A {@link CmsHostContext} for specs, with everything supplied and nothing real.
 *
 * ### One factory rather than a stub per spec
 *
 * Twelve specs render the contract record screen. Written inline, adding a member to the context
 * would break all twelve separately and be patched twelve times — and the twelfth person to patch
 * one would reach for `as unknown as CmsHostContext` and quietly opt that screen out of the type.
 * Same reasoning as `allPermissions`, which this deliberately mirrors.
 *
 * ### ⚠ This proves nothing about navigation actually happening
 *
 * {@link recordingHostContext} collects intents; this one discards them. Either way, a spec asserting
 * through this factory is making a claim about **what the screen asked for**, never about where a
 * user ends up — that is `routerHostContext`'s job and it is exercised through a real `Router` in the
 * record screen's routing spec. Same caution `allPermissions` carries, for the same reason.
 */
export declare const testHostContext: (overrides?: Partial<CmsHostContext>) => CmsHostContext;
/** A signed-in principal. Identity only — authority is `allPermissions`, a different seam. */
export declare const testHostUser: (overrides?: Partial<CmsHostUser>) => CmsHostUser;
/**
 * A host that is signed in and hands out a fixed token.
 *
 * ⚠ The token is a placeholder string and **not a JWT**. Nothing in a feature library parses it —
 * `rolesFromAccessToken` lives in `@cws/core-auth` and is the shell's business — so a spec that
 * needs a decodable token is testing the wrong layer.
 */
export declare const testHostAuth: (overrides?: Partial<CmsHostAuth>) => CmsHostAuth;
/** A host context that remembers what it was asked to do. */
export interface RecordingHostContext {
  readonly context: CmsHostContext;
  /** Every intent, in order. */
  readonly intents: readonly CmsNavigationIntent[];
}
/**
 * A {@link CmsHostContext} that records navigation intents instead of performing them.
 *
 * This is what makes "the screen never touches the root Router" assertable: the intent is the
 * screen's entire outward navigation contract, so a spec can state exactly what leaving the record
 * should ask for, without standing up a router.
 */
export declare const recordingHostContext: (overrides?: Partial<CmsHostContext>) => RecordingHostContext;
/**
 * How a host turns a {@link CmsNavigationIntent} into its own router commands.
 *
 * 🔴 **This is the whole reason the intent is not a URL.** The screen knows it wants *this contract*;
 * only the host knows what that is called in its routing table. Standalone, `/contracts/{n}`.
 * Embedded under Originations, something else entirely — and the screen must not have to know which.
 */
export interface CmsHostRoutes {
  /** Router commands for a contract record. */
  readonly contract: (contractNumber: string) => readonly unknown[];
  /**
   * Router commands for a logical origin screen.
   *
   * `origin` arrives as the raw value the URL carried (`approvals`, `pricing`, or anything at all —
   * a hand-edited URL is a real input). An implementation is expected to normalise it and fall back
   * rather than throw; the shell's does so through `recordOrigin`, which already has that behaviour
   * and a documented reason for it.
   */
  readonly origin: (origin: string) => readonly unknown[];
  /** Router commands for a contract record's edit form. Added 2026-09-28 with `hrefFor`. */
  readonly editContract: (contractNumber: string) => readonly unknown[];
  /** Router commands for a new contract. Added 2026-09-28. */
  readonly newContract: () => readonly unknown[];
  /**
   * Router commands for an origin's own review of one contract (the breadcrumb's middle crumb).
   * Added 2026-09-28. An origin with no review screen should answer its own commands.
   */
  readonly review: (origin: string, contractNumber: string) => readonly unknown[];
  /** Router commands for one of the workspace's modules. Added 2026-09-30 (F9.10). */
  readonly module: (module: CwsModule) => readonly unknown[];
}
/** The parts of a host context an Angular `Router` cannot supply by itself. */
export interface RouterHostContextParts {
  readonly tradeUnit: () => string | null;
  readonly user: () => CmsHostUser | null;
  readonly theme: () => CmsHostTheme;
  readonly baseHref: () => string;
  readonly auth: CmsHostAuth;
  readonly routes: CmsHostRoutes;
}
/**
 * A {@link CmsHostContext} whose navigation is performed by the Angular `Router`.
 *
 * ### Why this lives in the library rather than in the shell
 *
 * It is used in two places — the shell provides it, and the record screen's twelve specs need a
 * context that really moves the URL, because several of them assert on `router.url` and one asserts
 * that the tab survives a refresh. Written once in the shell it would have to be written **again**
 * as test scaffolding, and the two copies would be free to disagree: the #135 two-engines trap,
 * which `shell-permissions.ts` exists to prevent and which a spec of its own once walked into.
 *
 * So there is one implementation, it is the one that ships, and the specs exercise it.
 *
 * ### ⚠ It takes a peer dependency on `@angular/router`, and that does not make the seam Angular-only
 *
 * {@link CmsHostContext} itself imports nothing but `InjectionToken`. This function is the
 * **reference implementation for an Angular host** and a non-Angular host simply never imports it —
 * the library is `sideEffects: false`, so it is dropped entirely by tree-shaking. The alternative,
 * a second package for one function, buys nothing and costs a build target.
 */
export declare function routerHostContext(router: Router, parts: RouterHostContextParts): CmsHostContext;
# `@cws/core-host-context` — the seam between a feature and its host

**In the build as of 2026-09-24 (F9.1, #416).** Registered in `angular.json`, `build:libs` and the
`tsconfig.json` path mappings.

> This README previously said the opposite — *"reserved for E9, deliberately not in the build"* —
> which was correct from 2026-09-16 until F9.1 landed. Kept as a note rather than deleted, because a
> file that quietly changes its mind is how this repository ends up with instructions nobody
> re-pointed.

## What it is

`CmsHostContext` (ADR-13) is everything a CWS feature needs from the application hosting it:

| Member | Why a feature cannot just work it out |
|---|---|
| `tradeUnit()` | The host chooses it. Standalone that is the shell's picker; embedded it is the host's own state |
| `user()` | Identity only — `id` (the immutable `oid`, per C-13), `username`, `displayName` |
| `theme()` | The **resolved** `light`/`dark`, so a component can pick an icon without reading `document` |
| `baseHref()` | For building a copyable absolute link, never for routing |
| `auth` | `CmsHostAuth` — silent token acquisition. No feature library may import MSAL |
| `navigate(intent)` | The host decides what "open this contract" means in **its** routing table |

## The defect it exists to fix

`ContractRecordPageComponent` injected the root `Router` and navigated to **absolute** paths —
`/contracts/{n}`, `/`, `/approvals` — while `@cws/features-contract-summary`'s own `public-api.ts`
claimed it *"never reaches for the root router"*. The 2026-09-18 host-workspace spike found it
(#335 finding 3). Embedded, that navigation escapes the host's outlet and lands the user somewhere
the host never routed.

`CmsNavigationIntent` replaces the URL with a statement of intent:

```ts
hostContext.navigate({ kind: 'contract', contractNumber: 'SC1240000' });
hostContext.navigate({ kind: 'origin', origin: 'approvals', params: { ... } });
hostContext.navigate({ kind: 'view-state', params: { tab: 'shipping' } });
```

## 🔴 `view-state` is not optional for a host to honour

`activeTab` is a `computed` reading the query parameter map and nothing else. A host that swallows a
`view-state` intent produces a screen whose **tabs do not switch** — the click registers, the signal
never changes, and nothing anywhere reports it. The embedded harness asserts it (F9.3, #419).

## What is deliberately absent

- **Roles.** `PermissionContext` already answers "what may this caller do", by intent-name rather
  than by role, and its own docstring forbids consumers inspecting roles. A role list here would be
  a second way to ask one question — and the one that breaks when #138 makes the four capabilities
  stop agreeing.
- **HTTP.** The host's interceptors apply. `problemDetailsInterceptor` is installed at the shell.
- **Anything that writes to `document`.** The shell's `ThemeStore` records why a library must never
  reach up and toggle a class on the host's `<html>`.

## Implementing it

`routerHostContext(router, parts)` is the reference implementation for an **Angular** host and is
what the shell provides. It lives here rather than in the shell because the record screen's twelve
specs need a context that really moves the URL — written in the shell it would have to be written
again as test scaffolding, and two copies are free to disagree (#135's two-engines trap).

A non-Angular host never imports it; the library is `sideEffects: false`, so it is tree-shaken away.

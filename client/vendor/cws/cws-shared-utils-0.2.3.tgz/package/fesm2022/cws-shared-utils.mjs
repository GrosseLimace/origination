const PIVOT_YEAR_MAX_2000S = 29;
const DIGITS_8 = /^(\d{2})(\d{2})(\d{4})$/;
const DIGITS_6 = /^(\d{2})(\d{2})(\d{2})$/;
const SEPARATED = /^(\d{1,2})[/.](\d{1,2})(?:[/.](\d{2}|\d{4}))?$/;
const ISO_TYPED = /^(\d{4})-(\d{2})-(\d{2})$/;
function expandTwoDigitYear(twoDigitYear) {
	return twoDigitYear <= PIVOT_YEAR_MAX_2000S ? 2e3 + twoDigitYear : 1900 + twoDigitYear;
}
function isRealDate({ year, month, day }) {
	if (month < 1 || month > 12 || day < 1) return false;
	return day <= new Date(Date.UTC(year, month, 0)).getUTCDate();
}
function toIsoDate({ year, month, day }) {
	const pad = (n) => String(n).padStart(2, "0");
	return `${String(year).padStart(4, "0")}-${pad(month)}-${pad(day)}`;
}
function fromIsoDate(iso) {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!match) return null;
	const parsed = {
		year: Number(match[1]),
		month: Number(match[2]),
		day: Number(match[3])
	};
	return isRealDate(parsed) ? parsed : null;
}
function formatDisplayDate(iso) {
	if (iso === null) return "";
	const parsed = fromIsoDate(iso);
	if (parsed === null) return iso;
	const pad = (n) => String(n).padStart(2, "0");
	return `${pad(parsed.month)}/${pad(parsed.day)}/${parsed.year}`;
}
function parseShipPeriodDate(input, defaultYear) {
	const text = input.trim();
	if (text.length === 0) return null;
	const parsed = parseDigits(text) ?? parseSeparated(text, defaultYear) ?? parseIso(text);
	if (parsed === null || !isRealDate(parsed)) return null;
	return toIsoDate(parsed);
}
function parseDigits(text) {
	const eight = DIGITS_8.exec(text);
	if (eight) return {
		month: Number(eight[1]),
		day: Number(eight[2]),
		year: Number(eight[3])
	};
	const six = DIGITS_6.exec(text);
	if (six) return {
		month: Number(six[1]),
		day: Number(six[2]),
		year: expandTwoDigitYear(Number(six[3]))
	};
	return null;
}
function parseIso(text) {
	const match = ISO_TYPED.exec(text);
	return match ? {
		year: Number(match[1]),
		month: Number(match[2]),
		day: Number(match[3])
	} : null;
}
function parseSeparated(text, defaultYear) {
	const match = SEPARATED.exec(text);
	if (!match) return null;
	const rawYear = match[3];
	if (rawYear === void 0) return defaultYear === void 0 ? null : {
		month: Number(match[1]),
		day: Number(match[2]),
		year: defaultYear
	};
	return {
		month: Number(match[1]),
		day: Number(match[2]),
		year: rawYear.length === 2 ? expandTwoDigitYear(Number(rawYear)) : Number(rawYear)
	};
}
function endOfMonth(iso) {
	const parsed = fromIsoDate(iso);
	if (parsed === null) return null;
	const lastDay = new Date(Date.UTC(parsed.year, parsed.month, 0)).getUTCDate();
	return toIsoDate({
		year: parsed.year,
		month: parsed.month,
		day: lastDay
	});
}
function startOfMonth(iso) {
	const parsed = fromIsoDate(iso);
	return parsed === null ? null : toIsoDate({
		year: parsed.year,
		month: parsed.month,
		day: 1
	});
}
function addMonths(iso, count) {
	const parsed = fromIsoDate(iso);
	if (parsed === null) return null;
	const zeroBased = parsed.month - 1 + count;
	const year = parsed.year + Math.floor(zeroBased / 12);
	const month = (zeroBased % 12 + 12) % 12 + 1;
	const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
	return toIsoDate({
		year,
		month,
		day: Math.min(parsed.day, lastDay)
	});
}
function compareIsoDates(left, right) {
	return left < right ? -1 : left > right ? 1 : 0;
}
function addDays(iso, count) {
	const parsed = fromIsoDate(iso);
	if (parsed === null) return null;
	const shifted = new Date(Date.UTC(parsed.year, parsed.month - 1, parsed.day + count));
	return toIsoDate({
		year: shifted.getUTCFullYear(),
		month: shifted.getUTCMonth() + 1,
		day: shifted.getUTCDate()
	});
}
function dayOfWeek(iso) {
	const parsed = fromIsoDate(iso);
	if (parsed === null) return null;
	return new Date(Date.UTC(parsed.year, parsed.month - 1, parsed.day)).getUTCDay();
}
export { addDays, addMonths, compareIsoDates, dayOfWeek, endOfMonth, expandTwoDigitYear, formatDisplayDate, fromIsoDate, isRealDate, parseShipPeriodDate, startOfMonth, toIsoDate };

//# sourceMappingURL=cws-shared-utils.mjs.map
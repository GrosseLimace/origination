import * as i0 from "@angular/core";
import { EnvironmentProviders, InjectionToken, Signal } from "@angular/core";
import { AccountInfo, IPublicClientApplication, SilentRequest, SsoSilentRequest } from "@azure/msal-browser";
import { CanActivateFn } from "@angular/router";
import { HttpInterceptorFn } from "@angular/common/http";
/**
 * Reads the `roles` claim out of an access token.
 *
 * **Why this exists at all, and why it is not the id token.** App roles are defined on the *API*
 * app registration, so Entra emits them in the access token issued for that API's scope. The SPA's
 * own registration defines **zero** app roles (verified 2026-08-25: `appRoles: []` on both
 * `a1b87993-…` dev and `f9b64275-…` QA), and an id token is issued for the SPA — so `roles` can
 * never appear in `idTokenClaims`, for any user, in any environment. Reading it there returned an
 * empty array unconditionally and rendered "No role" for a fully entitled user (#65, Known Issue 36).
 *
 * **This is for display only, and must never be an authorization decision.** Nothing here validates
 * the signature, the issuer, the audience or the lifetime — a caller who trusted it would be
 * trusting a string held in browser storage. The API is the authority: it validates the token and
 * enforces the `CmsUser` policy (#36), and it will refuse a request whatever this function returned.
 * What this buys is the *diagnosis* — turning "the application is broken" into "your account has no
 * role", which is a much shorter conversation.
 *
 * Decoding a token we are not the audience of is deliberate and safe: we are the party that
 * requested it, it is already in our own storage, and we only ever read one claim out of it.
 */
export declare function rolesFromAccessToken(token: string | null | undefined): readonly string[];
/** The signed-in principal as the chrome needs it. `oid` is the key (C-13); `username` is display and audit only. */
export interface CwsAccount {
  readonly oid: string;
  readonly username: string;
  readonly name: string | null;
}
/**
 * The seam under `cwsTokenInterceptor` and `cwsAuthGuard` (D-14). `CmsAuthService` implements it over MSAL;
 * a host may supply its own through `CwsWorkspaceConfig.auth.tokenProvider`.
 */
export interface CwsTokenProvider {
  /** Memoised; resolves once the provider can answer. Safe to call from a guard or interceptor on a lazy route. */
  ready(): Promise<void>;
  /** May interact, by the implementation's own policy. Call it ONLY from a navigation (the guard) or a user gesture — never from a request (D-15). */
  ensureSignedIn(): Promise<boolean>;
  /** Silent only. `null` = no token without interaction; an implementation sets `signInBlocked` when that happens with a principal present. */
  accessToken(scopes?: readonly string[]): Promise<string | null>;
  readonly account: Signal<CwsAccount | null>;
  /** Sign-in needs an interaction that was not performed here (lock held by another client, popup blocked or cancelled, silent failure). The chrome shows its Sign in button on it. */
  readonly signInBlocked: Signal<boolean>;
  /** From a user gesture. */
  signIn(): void;
  signOut(): void;
}
export declare const CWS_TOKEN_PROVIDER: InjectionToken<CwsTokenProvider>;
/** What the interceptor needs that is common to both modes. */
export interface CwsTokenTarget {
  readonly apiUrl: string;
  readonly apiScopes: readonly string[];
  readonly onSilentFailure: 'redirect' | 'fail';
}
export declare const CWS_TOKEN_TARGET: InjectionToken<CwsTokenTarget>;
/** What the shell has to supply. Every value is a public identifier, never a secret. */
export interface CmsAuthConfig {
  /** The SPA's own app registration. */
  readonly clientId: string;
  /** `https://login.microsoftonline.com/{tenantId}`. */
  readonly authority: string;
  /** Must exactly match a **SPA**-platform redirect URI on the app registration. */
  readonly redirectUri: string;
  readonly postLogoutRedirectUri: string;
  /**
   * The API scopes to request, e.g.
   * `api://5050fd5c-…/ContractManagementSystem.Application.Dev`.
   */
  readonly apiScopes: readonly string[];
  /**
   * The API base the token is attached to. Requests whose URL is this or starts with `${this}/` get a bearer; nothing else does.
   *
   * So this must be the API's own origin and path, not a wildcard: a too-broad entry would send our
   * access token to third-party hosts, and under a host that means the host's own APIs.
   */
  readonly apiUrl: string;
  /** Standalone: 'redirect' (docs/02 §1.2). Under a host: 'popup', because a redirect leaves the host's page. */
  readonly interaction: 'redirect' | 'popup';
  /** Try `ssoSilent` before any interaction. Standalone false (today's behaviour); under a host true. */
  readonly silentSignIn: boolean;
  /** A username for `ssoSilent`'s `loginHint`, e.g. from the host's own session. Read only when `silentSignIn` is true. */
  readonly loginHint?: () => string | null;
  /** D-19 (T0): a blank page on the host's origin for the hidden iframe `ssoSilent` and iframe-based `acquireTokenSilent` navigate to, so the host application does not bootstrap inside it. Unset standalone. */
  readonly silentRedirectUri?: string;
}
export declare const CMS_AUTH_CONFIG: InjectionToken<CmsAuthConfig>;
/**
 * CWS's own `PublicClientApplication`.
 *
 * A token of ours rather than msal-angular's `MSAL_INSTANCE` so that a host running its own
 * msal-angular cannot collide with it: two libraries resolving one global token would hand one of
 * them the other's client ID.
 */
export declare const CWS_MSAL_INSTANCE: InjectionToken<IPublicClientApplication>;
/**
 * Entra ID sign-in for the shell — the client half of the authorization fix (#36).
 *
 * Every CTRM-backed route requires `Admin` or `User` in the `roles` claim, so without a token the
 * application has no read path at all: `GET /api/v1/contracts` answers 401. Sign-in is therefore a
 * precondition for the home grid rather than a feature beside it.
 *
 * Standalone signs in by redirect, per docs/02 §1.2 ("Entra ID sign-in (MSAL redirect)"); under a
 * host `interaction: 'popup'`, because a redirect leaves the host's page. Popups are blocked by
 * default in some managed browser configurations, which is why a popup is only ever opened from a
 * navigation or a user gesture (D-15).
 *
 * **Load-bearing and easy to get wrong:**
 *
 * 1. **`initialize()` must complete before any other MSAL call.** msal-browser v5 throws
 *    `BrowserAuthError: uninitialized_public_client_application` otherwise, and because the throw
 *    happens inside an interceptor it surfaces as a failed HTTP request rather than as an auth error.
 *    `CmsAuthService.ready()` owns that, memoised, so the initializer, the guard and the interceptor
 *    can all await it: `provideAppInitializer` never runs for providers on a lazy route, which is
 *    where a host mounts CWS (D-4).
 * 2. **Under `interaction: 'redirect'` a redirect response must be consumed on every page load**, not
 *    just after sign-in; skip it and the user lands back on the app still signed out. Under
 *    `'popup'` it is never consumed at all, so CWS cannot touch a hash addressed to a host's client
 *    (D-5).
 * 3. **`cwsTokenInterceptor` is a functional interceptor (`HttpInterceptorFn`), not a class**, so it
 *    cannot register itself the way `HTTP_INTERCEPTORS` multi-providers used to — Angular only finds
 *    a functional interceptor if it is named in the `withInterceptors([...])` array passed to the
 *    `provideHttpClient` call that creates the `HttpClient` it should run on. `provideCmsAuth` binds
 *    the token seam (`CWS_TOKEN_PROVIDER`) but does **not** call `provideHttpClient` itself — the
 *    composing app (the shell's `app.config.ts`, or `provideCwsWorkspace`) must include
 *    `provideHttpClient(withInterceptors([cwsTokenInterceptor, …]))` alongside this function, or the
 *    interceptor is simply never invoked and every API request leaves with no bearer.
 */
export declare function provideCmsAuth(config: CmsAuthConfig): EnvironmentProviders;
/**
 * Host-token mode (D-14): the HOST supplies the Contracts API token through its own
 * {@link CwsTokenProvider}, and CWS runs no MSAL instance at all.
 *
 * Provides the interceptor's target, binds `CWS_TOKEN_PROVIDER` to the host's provider, and provides
 * `HostTokenAuthService` **as** `CmsAuthService` so the chrome's identity reads keep working. No MSAL
 * instance, no auth config, no initializer: the host owns sign-in.
 *
 * ⚠ `onSilentFailure` is always `'fail'`: under a host a redirect would leave the host's page, so a
 * request with no token fails with a 401 rather than navigating (D-15).
 */
export declare function provideCwsHostTokenAuth(options: {
  readonly apiUrl: string;
  readonly apiScopes: readonly string[];
  readonly tokenProvider: CwsTokenProvider;
}): EnvironmentProviders;
/**
 * The signed-in identity, as signals.
 *
 * Thin on purpose — MSAL already owns the session. What this adds is the **`roles` claim**, exposed
 * because its absence is the single most confusing failure in this application: a user can sign in
 * perfectly and still have every API call answered 403, because authorization needs `Admin` or
 * `User` in `roles` (#36) and that comes from an app-role assignment in Entra, not from signing in.
 *
 * Surfacing it turns "the app is broken" into "your account has no role", which is a different
 * conversation and a much shorter one.
 *
 * It is also CWS's default {@link CwsTokenProvider} (D-14), over CWS's own MSAL instance.
 *
 * **Not `providedIn: 'root'`.** `provideCmsAuth` provides it, so under a host it lives in the
 * injector of the route CWS is mounted on and a host's own root can never resolve one by accident —
 * nor can a host's `CmsAuthService`, if it had one, be handed to CWS.
 */
export declare class CmsAuthService implements CwsTokenProvider {
  private readonly msal;
  private readonly config;
  /** Named for MSAL's type; the public {@link account} is the provider-shaped view of it. */
  private readonly msalAccount;
  /** {@link ready}'s memo. */
  private started;
  /** The sign-in attempt in flight, shared by concurrent callers; see {@link ensureSignedIn}. */
  private signingIn;
  private readonly blocked;
  /**
   * True when sign-in needs an interaction that was not performed here: the lock is held by another
   * client on the origin, the popup was blocked or closed, or a silent token failed with a principal
   * present. The chrome shows its Sign in button on it, which is a gesture and so may interact.
   */
  readonly signInBlocked: import("@angular/core").Signal<boolean>;
  /**
   * Roles from the access token, populated by {@link refresh}.
   *
   * Held rather than computed because reading them is asynchronous — the token has to be acquired
   * from MSAL — and a signal that triggered a token acquisition on read would fire once per template
   * binding.
   */
  private readonly accessRoles;
  /** The Graph photo as a `data:` URL. See {@link loadPhoto} for why not an object URL. */
  private readonly photo;
  readonly isSignedIn: import("@angular/core").Signal<boolean>;
  /** The principal as {@link CwsTokenProvider} exposes it; `oid` is `localAccountId` (see {@link userId}). */
  readonly account: import("@angular/core").Signal<CwsAccount | null>;
  /**
   * The sign-in name, normally the work email.
   *
   * Distinct from {@link displayName}: two people can share a display name, and when someone is
   * looking at an identity menu to work out *which* account they are signed in as, the name is
   * exactly the thing that failed to answer that.
   */
  readonly username: import("@angular/core").Signal<string | null>;
  /**
   * The immutable directory object id (`oid`) of the signed-in account, or `null`.
   *
   * **`localAccountId`, not `homeAccountId`.** For an Entra account MSAL sets `localAccountId` to the
   * `oid` claim; `homeAccountId` is `{oid}.{tid}` and would silently carry the tenant into anything
   * keyed on it.
   *
   * Exposed for correction **C-13**: rows key on `oid` and carry the UPN denormalised for display and
   * audit, because {@link username} is neither immutable nor guaranteed unique — a changed UPN
   * orphans every row keyed on it, with nothing reporting the orphan.
   */
  readonly userId: import("@angular/core").Signal<string | null>;
  /** Display name, falling back to the username — a guest account may have no name. */
  readonly displayName: import("@angular/core").Signal<string | null>;
  /**
   * The signed-in user's Outlook profile photo as an object URL, or `null`.
   *
   * `null` is an ordinary outcome, not a failure: **`/me/photo/$value` answers 404 for any account
   * that has never set a photo**, which is a large share of accounts. {@link initials} is the
   * fallback and always renders, so the avatar works for everybody and looks better for some — the
   * arrangement the `initials` docstring below has described since it was written.
   */
  readonly photoUrl: import("@angular/core").Signal<string | null>;
  /**
   * Initials for the avatar, e.g. "John Smith" → "JS".
   *
   * Derived rather than fetched, and still the fallback now that {@link photoUrl} exists — Entra
   * does not put a photo in the token, and Graph answers 404 for an account that has not set one.
   * Building initials first means the avatar works for everybody before it works prettily for some.
   *
   * Takes the first and last word so a middle name does not produce three letters, and falls back
   * to the first character of the username when there is no display name at all.
   */
  readonly initials: import("@angular/core").Signal<string>;
  /**
   * The app roles on the current **access** token — the ones the API will actually enforce.
   *
   * **This used to read `idTokenClaims.roles`, and that could never work.** App roles are defined on
   * the *API* app registration, so they are emitted in the access token issued for the API's scope.
   * Both SPA registrations define zero app roles, and the id token is issued for the SPA — so
   * `idTokenClaims.roles` was `undefined` for every user in every environment, and the shell showed
   * "No role" to fully entitled accounts (#65, Known Issue 36). The old comment reasoned that the two
   * tokens "match for a single-tenant app with app roles assigned to the user"; they do not, and no
   * amount of Entra assignment would have made them.
   *
   * Empty is therefore ambiguous by design — not signed in, no role assigned, or the token could not
   * be acquired all read the same here. Treat it as "the API will refuse this user", which is the one
   * conclusion that holds in all three cases, and let the API's own 401/403 say which.
   */
  readonly roles: import("@angular/core").Signal<readonly string[]>;
  /** True when the token carries a role the API will accept. */
  readonly canReadContracts: import("@angular/core").Signal<boolean>;
  /**
   * Initialise; under 'redirect' consume a redirect response; adopt a cached account; read roles.
   *
   * Memoised because three callers await it (D-4): the app initializer standalone, and the guard and
   * the interceptor under a host, where `provideAppInitializer` on a lazy route never runs.
   */
  ready(): Promise<void>;
  private start;
  /**
   * Consumes the authorization code Entra appended to the URL; skip it and the user lands back on
   * the app still signed out, which reads as "sign-in did not work".
   *
   * A failure is logged rather than rethrown: `ready()` is memoised and awaited by the guard and the
   * interceptor, so one rejected redirect would otherwise poison every later navigation and request
   * until a reload. The user is left signed out, which the guard then handles like any other.
   */
  private consumeRedirect;
  /**
   * Signed in, or the attempt to be: an active account resolves true at once; otherwise `ssoSilent`
   * when `silentSignIn`, then the configured interaction. A redirect resolves false because the page
   * is leaving; a popup resolves true once it lands.
   *
   * Interactive, so call it only from a navigation or a gesture (D-15). The three blocked codes
   * resolve false with `signInBlocked` set; any other failure is a fault and is rethrown.
   *
   * 🔴 **Concurrent callers share ONE attempt** (#615). A route's `canActivate` guards run together,
   * and `/admin` has two that sign in (`cwsAuthGuard`, and the admin guard, which must not read roles
   * before there are any). Two attempts would be two `ssoSilent` calls through MSAL's origin-wide
   * interaction lock (spike M2), and the second fails `interaction_in_progress`. The memo is cleared
   * once the attempt settles, so a later navigation, after a sign-out or a blocked attempt, tries
   * again rather than replaying a stale answer.
   */
  ensureSignedIn(): Promise<boolean>;
  private attemptSignIn;
  /**
   * `ssoSilent` against the session Entra already holds, e.g. the host's.
   *
   * A cached account is passed when there is one (spike M3 measured that a host's account IS
   * visible to this instance), and `loginHint` only when there is not: an account names exactly one
   * session, where a username leaves Entra to choose. A silent failure is not an error — it is the
   * signal to interact — so it resolves false.
   */
  private trySilentSignIn;
  /**
   * The Sign in button. A user gesture, so a popup opened here has the activation a guard's or an
   * interceptor's would lack.
   *
   * Void, so nothing may escape it: a failure is routed through the same three codes as
   * {@link ensureSignedIn} (→ `signInBlocked`) and anything else is logged, never left as an
   * unhandled rejection.
   */
  signIn(): void;
  /**
   * Adds `silentRedirectUri` as `redirectUri` when configured (D-19), and nothing when not.
   *
   * `ssoSilent` and an iframe-based `acquireTokenSilent` navigate a hidden iframe to `redirectUri`.
   * Left at the host's root, the whole host application would bootstrap inside that iframe on every
   * silent call. Omitted entirely rather than set `undefined`, so standalone sends what it always did.
   */
  private silentRequest;
  /**
   * Carries the active account when there is one, so a step-up (the Sign in button after a silent
   * failure) goes to that account the way msal-angular's `MsalInterceptor` redirect did, rather than
   * showing an account chooser. No `account` key at all when nobody is signed in.
   */
  private interactiveRequest;
  /** Cleared before the refresh, so a token that still cannot be had afterwards re-blocks. */
  private adopt;
  /** Per `interaction`, for the same reason as sign-in: a redirect would leave a host's page. */
  signOut(): void;
  /**
   * Re-reads the active account and the roles on its access token.
   *
   * Called from {@link ready} once MSAL has initialised and any redirect response has been
   * consumed, so standalone knows the roles before the first render rather than appearing
   * a frame later — a role badge that flickers from "No role" to "Admin" is worse than either, since
   * "No role" is a warning.
   *
   * **It was previously never called at all.** The account signal was seeded once at construction
   * and happened to be correct, because the initializer sets the active account before anything
   * injects this service. That was luck rather than design: any consumer injected earlier would have
   * read `null` and rendered a signed-out shell to a signed-in user.
   */
  refresh(): Promise<void>;
  /**
   * An access token for the given scopes, or `null` when one cannot be had **silently**.
   *
   * This is the shell's half of `CmsHostAuth` (F9.1, ADR-13): a feature library embedded under a
   * foreign host asks its host for a token and never learns that MSAL exists here.
   *
   * ### 🔴 Silent only, and `null` is an ordinary outcome
   *
   * On a first visit this runs before the user has signed in at all, so `acquireTokenSilent` is
   * *expected* to throw `InteractionRequiredAuthError` — and it must never be escalated to an
   * interactive redirect. From an app initializer that fires before routing has decided whether the
   * route needs a token; from a component it would discard unsaved work on a screen with 104
   * editable fields. `cwsAuthGuard` (via {@link ensureSignedIn}) and `cwsTokenInterceptor` own that
   * decision. A failure with an account present sets {@link signInBlocked}.
   *
   * Defaults to the configured API scopes, which is what every in-app caller wants; `loadPhoto`
   * passes Graph's scope explicitly because it is a different resource.
   */
  accessToken(scopes?: readonly string[]): Promise<string | null>;
  /**
   * {@link accessToken} without awaiting {@link ready}, for {@link refresh}: `ready()` awaits
   * `refresh()`, so a refresh that awaited `ready()` would wait on itself forever.
   */
  private silentToken;
  /**
   * Acquires the API access token and reads its roles.
   *
   * Delegates to `silentToken` (the body of {@link accessToken}) rather than calling `acquireTokenSilent` a second time — two
   * copies of the silent-only rule would be free to disagree, and the one that drifted would
   * re-arm the interactive-redirect hazard that copy documents.
   */
  private readRoles;
  /**
   * Fetches the Outlook profile photo from Microsoft Graph, falling back to initials on anything.
   *
   * ### Why this needs no new permission and prompts nobody
   *
   * `User.Read` is **already declared on all three SPA registrations and admin-consented for all
   * principals** (`consentType: AllPrincipals`) — it is the default delegated permission every Entra
   * app registration ships with. Verified against dev `a1b87993` and QA `f9b64275` before this was
   * written, rather than assumed. So the token below is one the user already has rights to.
   *
   * ### Three deliberate choices, each avoiding a way this could go wrong
   *
   * 1. **Silent only, exactly like {@link readRoles}.** A failure returns no photo and never
   *    escalates to an interactive redirect. Bouncing a user to Entra to re-consent so an avatar can
   *    be prettier would be an appalling trade, and from an app initializer it would fire before
   *    routing has decided whether the route needs a token at all.
   * 2. **`fetch`, not `HttpClient`.** This request must not pass through a token interceptor, which
   *    on a silent failure may start a redirect for the same reason as (1). Using `fetch` states that
   *    intent instead of relying on Graph's URL not matching `apiUrl`, and keeps this service free of
   *    an `HttpClient` dependency. For the same reason a failure here never sets `signInBlocked`.
   * 3. **A non-OK response is not logged as an error.** 404 means "this account has no photo", which
   *    is the single most common outcome and entirely normal.
   *
   * ### 🔴 Why a `data:` URL and not `URL.createObjectURL`
   *
   * **The Content-Security-Policy would have blocked the object URL, and only in deployed
   * environments.** `SecurityHeadersMiddleware` sends `img-src 'self' data:` — no `blob:` — so a
   * `blob:` avatar is refused by the browser with a console message and nothing else: no failed
   * request, no exception, no App Insights entry. Under `ng serve` that middleware is not in the
   * path at all, so it would have looked perfect locally and shown a broken avatar on dev, QA and
   * prod. That is the works-locally/breaks-deployed shape this repository keeps being bitten by
   * (Known Issues 9, 27, 28).
   *
   * A `data:` URL is already permitted by the existing policy, so this needs **no security-header
   * change** — which also keeps the fix inside this lane, since that middleware is backend-owned.
   * The costs are a base64 encode and roughly 33% more memory for one small image, both trivially
   * acceptable next to relaxing a CSP. It removes the object-URL lifetime problem outright: there is
   * nothing to revoke.
   *
   * ⚠ `connect-src` **already lists `https://graph.microsoft.com`**, so the fetch itself was allowed
   * before this change — worth knowing, because a Graph call failing on CSP would look identical to
   * a token problem.
   *
   * ⚠ `/me/photo/$value` returns the **full-size** image — up to 648×648 — for an avatar rendered at
   * 28 CSS pixels. One request per sign-in, so this is accepted rather than optimised; the sized
   * form (`/me/photos/64x64/$value`) 404s when that rendition does not exist, which would turn one
   * reliable request into two unreliable ones.
   */
  private loadPhoto;
  static ɵfac: i0.ɵɵFactoryDeclaration<CmsAuthService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Every public member the chrome, the host context and `MePermissionContext` read.
 *
 * `HostTokenAuthService` implements it, so a substitute provided as `CmsAuthService` in host-token
 * mode (D-14) cannot miss one: the compiler refuses it rather than a screen throwing at runtime.
 */
export type CwsAuthSurface = Pick<CmsAuthService, 'isSignedIn' | 'username' | 'userId' | 'displayName' | 'photoUrl' | 'initials' | 'roles' | 'canReadContracts' | 'account' | 'signInBlocked' | 'signIn' | 'signOut' | 'refresh' | 'ready' | 'ensureSignedIn' | 'accessToken'>;
/**
 * The chrome's identity when a HOST supplies the token (D-14, host-token mode).
 *
 * `provideCwsHostTokenAuth` provides this **as** `CmsAuthService`, the pattern every test bed
 * already uses with a stub, so the user menu, the host context and `MePermissionContext` keep reading
 * the members they always read. It implements {@link CwsAuthSurface}, so the compiler refuses a
 * missing member. Without it a host-token mount would `NG0201` on the user menu's first
 * `inject(CmsAuthService)`.
 *
 * ⚠ **No Graph photo in this mode.** A host provider is asked only for the Contracts API scope, so
 * `photoUrl` is always `null` and the avatar renders initials, which the chrome already handles.
 *
 * ⚠ **`roles` come from whatever token the host hands over.** That authorizes identically only if
 * Entra stamps the CWS API registration's app roles on a token the HOST's registration acquired for
 * the CWS scope. That is platform knowledge, not yet observed here: the probe in the plan's §9
 * item 11 settles it, and until it runs this mode is available rather than recommended.
 */
export declare class HostTokenAuthService implements CwsAuthSurface, CwsTokenProvider {
  private readonly provider;
  private readonly target;
  private readonly accessRoles;
  readonly account: import("@angular/core").Signal<import("@cws/core-auth").CwsAccount | null>;
  readonly signInBlocked: import("@angular/core").Signal<boolean>;
  readonly isSignedIn: import("@angular/core").Signal<boolean>;
  readonly username: import("@angular/core").Signal<string | null>;
  /** The Entra object id: the key (C-13). */
  readonly userId: import("@angular/core").Signal<string | null>;
  /** Display name, falling back to the username — a guest account may have no name. */
  readonly displayName: import("@angular/core").Signal<string | null>;
  readonly initials: import("@angular/core").Signal<string>;
  readonly photoUrl: import("@angular/core").Signal<string | null>;
  readonly roles: import("@angular/core").Signal<readonly string[]>;
  /** True when the token carries a role the API will accept; the same rule as `CmsAuthService`. */
  readonly canReadContracts: import("@angular/core").Signal<boolean>;
  ready(): Promise<void>;
  /**
   * Signed in **with the roles read**, the same promise `CmsAuthService.ensureSignedIn()` makes in
   * Mode A (#615).
   *
   * The `account` effect below also decodes the roles, but an effect cannot be awaited: on a cold
   * deep link the admin guard asked for `Admin` while that read was still in flight, and refused an
   * administrator. So a successful sign-in reads the token itself before it resolves. A `false` is
   * passed straight through; there is no token to read.
   */
  ensureSignedIn(): Promise<boolean>;
  accessToken(scopes?: readonly string[]): Promise<string | null>;
  signIn(): void;
  signOut(): void;
  /**
   * 🔴 #601: roles are re-read whenever the host's account changes, including the first read.
   *
   * Nothing else calls {@link refresh} in Mode B: `cwsAuthGuard` and `cwsTokenInterceptor` talk to
   * the host's `CWS_TOKEN_PROVIDER` directly, never to this class, and a route-level initializer is
   * inert under a host. So before this, `roles()` stayed `[]` for the life of the page and Admin
   * could only come from `/me`. The account signal is the one thing that changes when the host's
   * session does, so it is what drives the read.
   */
  constructor();
  /** Bumped per read, so a slow earlier read cannot overwrite a later one. */
  private reads;
  /** The newest read, which a superseded one waits for (see {@link refresh}). */
  private latest;
  /**
   * Re-reads the roles from a token the host supplies for the Contracts API scopes.
   *
   * ⚠ **Resolves once the roles are SET, even when a newer read supersedes this one** (#615). Signing
   * in changes `account`, so the effect above starts its own read straight after `ensureSignedIn()`
   * starts one. Only the newest may write; before this, the older one resolved having written
   * nothing, so a caller awaiting it saw no roles yet. A superseded read now waits for the newer one.
   */
  refresh(): Promise<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<HostTokenAuthService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Initials for the avatar, e.g. "John Smith" → "JS".
 *
 * Takes the first and last word so a middle name does not produce three letters, and falls back to
 * the first character of `fallback` (the username) when there is no display name at all.
 *
 * Shared by `CmsAuthService` and `HostTokenAuthService` (E9 PR 3), so the two identities a chrome can
 * show cannot initial the same person differently. Moved out of `CmsAuthService.initials` unchanged.
 */
export declare function initialsOf(name: string | null | undefined, fallback?: string | null): string;
/**
 * Replaces `MsalGuard` on every CWS route, standalone and under a host (D-3): one code path with a
 * config switch, rather than one guard standalone and another embedded.
 *
 * A navigation is one of the two places allowed to interact (D-15), so this is where
 * `ensureSignedIn()` is called; what it does — redirect, popup, `ssoSilent` first — is the
 * provider's policy, not the guard's. It reads `CWS_TOKEN_PROVIDER` only (D-14), so a
 * host-supplied provider decides for itself and no MSAL need be present.
 *
 * It also covers `ready()` under a host: `provideAppInitializer` never runs on a lazy route, and
 * `ensureSignedIn()` awaits `ready()` first (D-4).
 */
export declare const cwsAuthGuard: CanActivateFn;
/**
 * Whether `url` is under `apiUrl`: the base itself, a path below it, or the base with a query.
 *
 * A prefix match on a segment boundary, never a bare `startsWith`: `/api/v1` must not match
 * `/api/v10` or `/api/v1-legacy`, which under a host could be somebody else's API.
 */
export declare function isApiRequest(url: string, apiUrl: string): boolean;
export declare const cwsTokenInterceptor: HttpInterceptorFn;
export interface FakeMsalOptions {
  /**
   * An account already in the cache, as after a reload. Returned by `getAllAccounts`; not active until adopted.
   * Omit `idTokenClaims` to model a host's account seen through the shared cache (spike M3), which is not adopted.
   */
  readonly account?: AccountInfo | null;
  /** What `acquireTokenSilent` answers. Defaults to an opaque string. */
  readonly accessToken?: string;
  /** Whether `ssoSilent` finds a session. Defaults to `'fails'`, the state of a first visit. */
  readonly ssoSilent?: 'succeeds' | 'fails';
  /** When set, `loginPopup` rejects with this `errorCode`. */
  readonly loginPopupError?: string;
  /** When set, `acquireTokenSilent` rejects with this `errorCode`. */
  readonly acquireTokenSilentError?: string;
}
/** Call counts per method, for asserting what did and did not happen. */
export interface FakeMsalCalls {
  initialize: number;
  handleRedirectPromise: number;
  setActiveAccount: number;
  acquireTokenSilent: number;
  ssoSilent: number;
  loginRedirect: number;
  loginPopup: number;
  logoutRedirect: number;
  logoutPopup: number;
}
export type FakeMsal = IPublicClientApplication & {
  readonly calls: FakeMsalCalls;
  /** The request the most recent `ssoSilent` received, or `null` before any. */
  readonly lastSsoSilent: SsoSilentRequest | null;
  /** The request the most recent `acquireTokenSilent` received, or `null` before any. */
  readonly lastAcquireTokenSilent: SilentRequest | null;
  /** Puts an account in the cache, as a sign-in elsewhere on the origin would. Does not make it active. */
  addAccount(account: AccountInfo): void;
};
/** The account a successful `ssoSilent` or `loginPopup` produces when the options named none. */
export declare const FAKE_ACCOUNT: AccountInfo;
export declare function fakePublicClientApplication(options?: FakeMsalOptions): FakeMsal;
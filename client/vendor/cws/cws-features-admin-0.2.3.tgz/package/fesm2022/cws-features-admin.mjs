import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Injectable, InjectionToken, computed, effect, inject, input, linkedSignal, output, signal, untracked, viewChild } from "@angular/core";
import { ActivatedRoute, Router, RouterLink, RouterLinkActive, RouterOutlet } from "@angular/router";
import { takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { ADDENDUM_CONTENT_FORMATS, ADDENDUM_DATE_ANCHOR, ADDENDUM_INITIALS_ANCHOR, ADDENDUM_MARKUP_CONTENT_FORMAT, ADDENDUM_SIGNATURE_ANCHOR, ADDENDUM_TEMPLATE_SOURCE, ADDENDUM_TYPE_SOURCE, ALL_TRADE_UNITS, BASIS_LOCATION_ADMIN_SOURCE, BASIS_PLACE_RULES, COLLECTION_BLOCKS, CONTRACT_GRID_COLUMNS, CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT, CONTRACT_LAYOUT_FIELD_NOTES, CONTRACT_LAYOUT_FIXED_WIDTH_FIELDS, CONTRACT_LAYOUT_GROUP_HEADINGS, CONTRACT_LAYOUT_HALF_FIELDS, CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS, CONTRACT_LAYOUT_WIDE_FIELDS, CONTRACT_READ_ONLY_FIELDS, CONTRACT_TEMPLATE_SOURCE, CONTRACT_WRITABLE_FIELDS, CWS_EXTERNAL_LINKS, ContractFormComponent, DEFAULT_ADDENDUM_LANGUAGE, DIRECTORY_NOT_OFFERED, DIRECTORY_UNAVAILABLE, FAMILY_B_ADDENDUM_FIELD_SETS, FORM_CONFIG_ADMIN_SOURCE, FORM_CONFIG_SOURCE, LOCATION_SOURCE, ME_SOURCE, NO_USER_FOUND, PERMISSION_CATALOG_SOURCE, PERSON_REFUSAL, PINNED_GRID_COLUMN, ROLE_ADMIN_SOURCE, SIMULATED_PERMISSION_CATALOG, SamplePermissionCatalogSource, TRADE_UNIT_VALUES_ADMIN_SOURCE, UNKNOWN_SETTINGS_SCOPE, USER_DIRECTORY_SOURCE, addendumAnchorProblems, adminRefusalOf, collectionBlockTab, diffConfigDocuments, emptiedTabs, gridColumnChoices, holdsPermission, isAllTradeUnits, isEntraObjectId, legacyEditsAllowed, looksLikeUpn, settingsScopeOf, tabsAfterCascade, templatePromptFieldsOf, templateSeedFor, templateValuesFromForm, templateValuesOf, typeDraftOf, userGridColumnKeys } from "@cws/domain-contracts";
import { BehaviorSubject, Subject, catchError, concat, debounceTime, defer, filter, firstValueFrom, map, of, switchMap, take, timer } from "rxjs";
import * as i1 from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { CONSTRAINT_SOURCE, CTRM_REQUIRED_REASON, ctrmRequiredFields, presentationMaps, validationSummary } from "@cws/shared-form-engine";
import { AsyncContainerComponent, CodeComboComponent, DateInputComponent, DropdownCaretComponent, ExportFieldsComponent, FormRowComponent, FormRowFieldComponent, PageHeaderComponent, PointerDragGesture, RowMenuComponent, StatusMessageComponent, elementUnder, injectConfirm, mutationFailed, mutationRefused, mutationSucceeded, remoteLoaded, remoteLoading } from "@cws/shared-ui";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { CdkMenu, CdkMenuGroup, CdkMenuItem, CdkMenuTrigger } from "@angular/cdk/menu";
import { DOCUMENT } from "@angular/common";
import { DIALOG_DATA, Dialog, DialogRef } from "@angular/cdk/dialog";
const ADMIN_AREAS = [
	{
		path: "form-configuration",
		title: "Form configuration",
		summary: "Which fields the contract record shows and requires, and which tabs it has, per contract type, trade unit and commodity.",
		adminOnly: false,
		views: [
			{
				path: "",
				label: "Form builder"
			},
			{
				path: "rows",
				label: "Configuration rows"
			},
			{
				path: "preview",
				label: "Preview a resolution"
			}
		]
	},
	{
		path: "trade-unit-values",
		title: "Trade unit values",
		summary: "Narrow the code-list values and market months a trade unit offers on its contracts.",
		adminOnly: false,
		views: []
	},
	{
		path: "contract-templates",
		title: "Contract templates",
		summary: "Starting points for a new contract: the values a template sets and the fields it asks the trader to complete, per trade unit.",
		adminOnly: false,
		views: []
	},
	{
		path: "addendums",
		title: "Addendums",
		summary: "The in-house addendum templates, and the addendum types a contract can carry.",
		adminOnly: false,
		views: [{
			path: "",
			label: "Templates"
		}, {
			path: "types",
			label: "Types"
		}]
	},
	{
		path: "basis-locations",
		title: "Basis locations",
		summary: "The price terms, places and regions a basis location is chosen from, and each trade unit's rule.",
		adminOnly: false,
		views: [
			{
				path: "",
				label: "Price terms"
			},
			{
				path: "places",
				label: "Places"
			},
			{
				path: "regions",
				label: "Regions"
			},
			{
				path: "trade-units",
				label: "Trade units"
			},
			{
				path: "hta",
				label: "HTA special types"
			}
		]
	},
	{
		path: "roles",
		title: "Roles and permissions",
		summary: "Roles, who holds them in which trade unit, and the provisional permission set they are built from.",
		adminOnly: true,
		views: [
			{
				path: "",
				label: "Roles"
			},
			{
				path: "assignments",
				label: "Assignments"
			},
			{
				path: "permissions",
				label: "Permissions"
			}
		]
	}
];
function adminArea(path) {
	const area = ADMIN_AREAS.find((each) => each.path === path);
	if (area === void 0) throw new Error(`No admin area "${path}".`);
	return area;
}
var AdminLayout = class AdminLayout {
	wide = signal(false, ...ngDevMode ? [{ debugName: "wide" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminLayout,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminLayout
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AdminLayout,
	decorators: [{ type: Injectable }]
});
var AdminScope = class AdminScope {
	me = inject(ME_SOURCE, { optional: true });
	locationSource = inject(LOCATION_SOURCE, { optional: true });
	scope = toSignal(this.me === null ? of(UNKNOWN_SETTINGS_SCOPE) : this.me.get().pipe(map((state) => settingsScopeOf(state.status === "loaded" ? state.value : null))), { initialValue: UNKNOWN_SETTINGS_SCOPE });
	locationList = toSignal(this.locationSource === null ? of(null) : this.locationSource.list().pipe(map((state) => state.status === "loaded" ? state.value : null)), { initialValue: null });
	locations = computed(() => this.locationList()?.locations ?? null, ...ngDevMode ? [{ debugName: "locations" }] : /* istanbul ignore next */ []);
	locationOrigin = computed(() => this.locationList()?.dataOrigin ?? null, ...ngDevMode ? [{ debugName: "locationOrigin" }] : /* istanbul ignore next */ []);
	knownNotAdmin = computed(() => this.scope().known && !this.scope().isAdmin, ...ngDevMode ? [{ debugName: "knownNotAdmin" }] : /* istanbul ignore next */ []);
	nameOf(code) {
		return this.locations()?.find((location) => location.code === code)?.name ?? null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminScope,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminScope
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AdminScope,
	decorators: [{ type: Injectable }]
});
var AdminPageComponent = class AdminPageComponent {
	access = inject(AdminScope);
	layout = inject(AdminLayout);
	gridClass = computed(() => this.layout.wide() ? "cws:grid cws:gap-6" : "cws:grid cws:gap-6 cws:lg:grid-cols-[13rem_minmax(0,1fr)]", ...ngDevMode ? [{ debugName: "gridClass" }] : /* istanbul ignore next */ []);
	areas = computed(() => ADMIN_AREAS.filter((area) => !area.adminOnly || !this.access.knownNotAdmin()), ...ngDevMode ? [{ debugName: "areas" }] : /* istanbul ignore next */ []);
	linkClass = "cws:block cws:whitespace-nowrap cws:rounded cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60 cws:aria-[current=page]:bg-slate-100 cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:bg-slate-700 cws:dark:aria-[current=page]:text-sky-300";
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AdminPageComponent,
		isStandalone: true,
		selector: "cms-admin-page",
		host: { classAttribute: "cws:block" },
		providers: [AdminScope, AdminLayout],
		ngImport: i0,
		template: `
    <!--
      The form builder with a form open asks for the section's whole width (AdminLayout): the navigation steps
      aside, and the grid drops its side column so the page is not left in the 13rem one. Discard brings it back.
    -->
    <div [class]="gridClass()">
      @if (!layout.wide()) {
      <nav aria-label="Admin" class="cws:min-w-0">
        <ul class="cws:flex cws:gap-1 cws:overflow-x-auto cws:border-b cws:border-slate-200 cws:pb-2 cws:lg:flex-col cws:lg:border-b-0 cws:lg:border-r cws:lg:pb-0 cws:lg:pr-3 cws:dark:border-slate-700">
          <li>
            <a
              [class]="linkClass"
              routerLink="."
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >Overview</a
            >
          </li>
          @for (area of areas(); track area.path) {
            <li>
              <!-- Not exact: an area stays marked on each of its tabs. -->
              <a
                [class]="linkClass"
                [routerLink]="area.path"
                routerLinkActive=""
                ariaCurrentWhenActive="page"
                >{{ area.title }}</a
              >
            </li>
          }
        </ul>
      </nav>
      }

      <div class="cws:min-w-0">
        <router-outlet />
      </div>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			},
			{
				kind: "directive",
				type: RouterOutlet,
				selector: "router-outlet",
				inputs: ["name", "routerOutletData"],
				outputs: [
					"activate",
					"deactivate",
					"attach",
					"detach"
				],
				exportAs: ["outlet"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AdminPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-admin-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				RouterLink,
				RouterLinkActive,
				RouterOutlet
			],
			providers: [AdminScope, AdminLayout],
			host: { class: "cws:block" },
			template: `
    <!--
      The form builder with a form open asks for the section's whole width (AdminLayout): the navigation steps
      aside, and the grid drops its side column so the page is not left in the 13rem one. Discard brings it back.
    -->
    <div [class]="gridClass()">
      @if (!layout.wide()) {
      <nav aria-label="Admin" class="cws:min-w-0">
        <ul class="cws:flex cws:gap-1 cws:overflow-x-auto cws:border-b cws:border-slate-200 cws:pb-2 cws:lg:flex-col cws:lg:border-b-0 cws:lg:border-r cws:lg:pb-0 cws:lg:pr-3 cws:dark:border-slate-700">
          <li>
            <a
              [class]="linkClass"
              routerLink="."
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >Overview</a
            >
          </li>
          @for (area of areas(); track area.path) {
            <li>
              <!-- Not exact: an area stays marked on each of its tabs. -->
              <a
                [class]="linkClass"
                [routerLink]="area.path"
                routerLinkActive=""
                ariaCurrentWhenActive="page"
                >{{ area.title }}</a
              >
            </li>
          }
        </ul>
      </nav>
      }

      <div class="cws:min-w-0">
        <router-outlet />
      </div>
    </div>
  `
		}]
	}]
});
let nextId$2 = 0;
var AddendumPlaceholderFieldsComponent = class AddendumPlaceholderFieldsComponent {
	rows = input.required(...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	groups = input.required(...ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []);
	ctrmListed = input(true, ...ngDevMode ? [{ debugName: "ctrmListed" }] : /* istanbul ignore next */ []);
	describedBy = input(null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	invalid = input(false, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	fieldChange = output();
	removed = output();
	listId = `cws-addendum-fields-${nextId$2++}`;
	example = "{{contract_number}}";
	offered = computed(() => new Set(this.groups().flatMap((group) => group.options.map((option) => option.value))), ...ngDevMode ? [{ debugName: "offered" }] : /* istanbul ignore next */ []);
	braces(placeholder) {
		return `{{${placeholder}}}`;
	}
	pick(placeholder, field) {
		this.fieldChange.emit({
			placeholder,
			field: field.trim()
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AddendumPlaceholderFieldsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AddendumPlaceholderFieldsComponent,
		isStandalone: true,
		selector: "cws-addendum-placeholder-fields",
		inputs: {
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			groups: {
				classPropertyName: "groups",
				publicName: "groups",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			ctrmListed: {
				classPropertyName: "ctrmListed",
				publicName: "ctrmListed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedBy: {
				classPropertyName: "describedBy",
				publicName: "describedBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			fieldChange: "fieldChange",
			removed: "removed"
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <fieldset class="cws:space-y-2" [attr.aria-describedby]="describedBy()" [attr.aria-invalid]="invalid()" data-testid="placeholder-fields">
      <legend class="cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400">Fields</legend>
      <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
        Read from the template content: write a placeholder as {{ example }} where a value goes, then pick the
        field it prints. A CTRM field prints the contract's value; an addendum field prints what the trader enters;
        a customer-master or generated field is filled in by the server when the addendum is made.
      </p>

      @if (rows().length === 0) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-empty">
          No placeholders in the template content yet.
        </p>
      } @else {
        <table class="cws:w-full cws:text-left cws:text-xs">
          <thead class="cws:text-slate-500 cws:dark:text-slate-400">
            <tr>
              <th class="cws:py-1">Placeholder</th>
              <th class="cws:py-1">Field</th>
              <th class="cws:py-1" aria-label="Status"></th>
            </tr>
          </thead>
          <tbody>
            @for (row of rows(); track row.placeholder) {
              <tr class="cws:border-t cws:border-slate-100 cws:dark:border-slate-800" [attr.data-placeholder]="row.placeholder">
                <td class="cws:py-1 cws:pr-2 cws:font-mono">{{ braces(row.placeholder) }}</td>
                <td class="cws:py-1 cws:pr-2">
                  @if (ctrmListed()) {
                    <select
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [disabled]="disabled()"
                      (change)="pick(row.placeholder, $any($event.target).value)"
                    >
                      <option value="" [selected]="row.field === ''">Pick a field</option>
                      @if (row.field !== '' && !offered().has(row.field)) {
                        <option [value]="row.field" selected>{{ row.field }} · not in the list</option>
                      }
                      @for (group of groups(); track group.label) {
                        <optgroup [label]="group.label">
                          @for (option of group.options; track option.value) {
                            <option [value]="option.value" [selected]="option.value === row.field">{{ option.label }}</option>
                          }
                        </optgroup>
                      }
                    </select>
                  } @else {
                    <input
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [attr.list]="listId"
                      placeholder="contract_number, or addendum_call_strike"
                      [value]="row.field"
                      [disabled]="disabled()"
                      (input)="pick(row.placeholder, $any($event.target).value)"
                    />
                  }
                </td>
                <td class="cws:py-1">
                  @if (!row.inText) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400">Not in the text any more; kept until removed.</span>
                    <button
                      type="button"
                      class="scoular-btn scoular-btn-secondary cws:ml-2"
                      [attr.aria-label]="'Remove ' + row.placeholder"
                      [disabled]="disabled()"
                      (click)="removed.emit(row.placeholder)"
                    >
                      Remove
                    </button>
                  } @else if (row.field === '') {
                    <span class="cws:text-rose-700 cws:dark:text-rose-300" data-testid="placeholder-unmapped">No field: would print blank</span>
                  } @else if (row.suggested) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-suggested">Matched by name</span>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      }

      @if (!ctrmListed()) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-no-ctrm-list">
          CTRM's field list could not be read here, so type the field name. The server checks it on Save.
        </p>
        <datalist [id]="listId">
          @for (group of groups(); track group.label) {
            @for (option of group.options; track option.value) {
              <option [value]="option.value">{{ option.label }}</option>
            }
          }
        </datalist>
      }
    </fieldset>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AddendumPlaceholderFieldsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-addendum-placeholder-fields",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: `
    <fieldset class="cws:space-y-2" [attr.aria-describedby]="describedBy()" [attr.aria-invalid]="invalid()" data-testid="placeholder-fields">
      <legend class="cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400">Fields</legend>
      <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
        Read from the template content: write a placeholder as {{ example }} where a value goes, then pick the
        field it prints. A CTRM field prints the contract's value; an addendum field prints what the trader enters;
        a customer-master or generated field is filled in by the server when the addendum is made.
      </p>

      @if (rows().length === 0) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-empty">
          No placeholders in the template content yet.
        </p>
      } @else {
        <table class="cws:w-full cws:text-left cws:text-xs">
          <thead class="cws:text-slate-500 cws:dark:text-slate-400">
            <tr>
              <th class="cws:py-1">Placeholder</th>
              <th class="cws:py-1">Field</th>
              <th class="cws:py-1" aria-label="Status"></th>
            </tr>
          </thead>
          <tbody>
            @for (row of rows(); track row.placeholder) {
              <tr class="cws:border-t cws:border-slate-100 cws:dark:border-slate-800" [attr.data-placeholder]="row.placeholder">
                <td class="cws:py-1 cws:pr-2 cws:font-mono">{{ braces(row.placeholder) }}</td>
                <td class="cws:py-1 cws:pr-2">
                  @if (ctrmListed()) {
                    <select
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [disabled]="disabled()"
                      (change)="pick(row.placeholder, $any($event.target).value)"
                    >
                      <option value="" [selected]="row.field === ''">Pick a field</option>
                      @if (row.field !== '' && !offered().has(row.field)) {
                        <option [value]="row.field" selected>{{ row.field }} · not in the list</option>
                      }
                      @for (group of groups(); track group.label) {
                        <optgroup [label]="group.label">
                          @for (option of group.options; track option.value) {
                            <option [value]="option.value" [selected]="option.value === row.field">{{ option.label }}</option>
                          }
                        </optgroup>
                      }
                    </select>
                  } @else {
                    <input
                      class="scoular-form-input cws:w-72 cws:font-mono"
                      [attr.aria-label]="'Field for ' + row.placeholder"
                      [attr.aria-invalid]="row.inText && row.field === ''"
                      [attr.list]="listId"
                      placeholder="contract_number, or addendum_call_strike"
                      [value]="row.field"
                      [disabled]="disabled()"
                      (input)="pick(row.placeholder, $any($event.target).value)"
                    />
                  }
                </td>
                <td class="cws:py-1">
                  @if (!row.inText) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400">Not in the text any more; kept until removed.</span>
                    <button
                      type="button"
                      class="scoular-btn scoular-btn-secondary cws:ml-2"
                      [attr.aria-label]="'Remove ' + row.placeholder"
                      [disabled]="disabled()"
                      (click)="removed.emit(row.placeholder)"
                    >
                      Remove
                    </button>
                  } @else if (row.field === '') {
                    <span class="cws:text-rose-700 cws:dark:text-rose-300" data-testid="placeholder-unmapped">No field: would print blank</span>
                  } @else if (row.suggested) {
                    <span class="cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-suggested">Matched by name</span>
                  }
                </td>
              </tr>
            }
          </tbody>
        </table>
      }

      @if (!ctrmListed()) {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="placeholder-fields-no-ctrm-list">
          CTRM's field list could not be read here, so type the field name. The server checks it on Save.
        </p>
        <datalist [id]="listId">
          @for (group of groups(); track group.label) {
            @for (option of group.options; track option.value) {
              <option [value]="option.value">{{ option.label }}</option>
            }
          }
        </datalist>
      }
    </fieldset>
  `
		}]
	}],
	propDecorators: {
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: true
			}]
		}],
		groups: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groups",
				required: true
			}]
		}],
		ctrmListed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ctrmListed",
				required: false
			}]
		}],
		describedBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedBy",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		fieldChange: [{
			type: i0.Output,
			args: ["fieldChange"]
		}],
		removed: [{
			type: i0.Output,
			args: ["removed"]
		}]
	}
});
const PLACEHOLDER_PATTERN = /\{\{\s*([A-Za-z0-9_]+)\s*(?:\|\s*(?<print>[a-z]+)\s*)?\}\}/g;
function templatePlaceholders(content) {
	const names = [];
	for (const match of (content ?? "").matchAll(PLACEHOLDER_PATTERN)) if (!names.includes(match[1])) names.push(match[1]);
	return names;
}
function mappingsOf(fields) {
	return Object.fromEntries(fields.map((entry) => [entry.placeholder, entry.field]));
}
function placeholderRows(content, mappings, suggest = () => null) {
	const inText = templatePlaceholders(content);
	const rows = inText.map((placeholder) => {
		if (Object.hasOwn(mappings, placeholder)) return {
			placeholder,
			field: mappings[placeholder],
			inText: true,
			suggested: false
		};
		const suggestion = suggest(placeholder);
		return {
			placeholder,
			field: suggestion ?? "",
			inText: true,
			suggested: suggestion !== null
		};
	});
	for (const [placeholder, field] of Object.entries(mappings)) if (!inText.includes(placeholder) && field !== "") rows.push({
		placeholder,
		field,
		inText: false,
		suggested: false
	});
	return rows;
}
function unmappedPlaceholders(rows) {
	return rows.filter((row) => row.inText && row.field.trim() === "").map((row) => row.placeholder);
}
function unmappedPlaceholdersMessage(placeholders) {
	return `These placeholders are in the template but not mapped to a field, so they would print blank: ${[...placeholders].sort(ordinal).join(", ")}.`;
}
function fieldsOf$1(rows) {
	return rows.filter((row) => row.field.trim() !== "").map((row) => ({
		placeholder: row.placeholder,
		field: row.field.trim()
	}));
}
function addendumFieldGroups(specialTypes) {
	const codes = specialTypes.map((code) => code.trim());
	const matched = FAMILY_B_ADDENDUM_FIELD_SETS.filter((set) => set.specialTypes.some((code) => codes.includes(code)));
	return (matched.length > 0 ? matched : FAMILY_B_ADDENDUM_FIELD_SETS).map((set) => ({
		label: `${set.title} fields (${set.specialTypes.join(", ")})`,
		options: set.fields.map((field) => ({
			value: field.cwsField,
			label: `${field.cwsField} · ${field.label}`
		}))
	}));
}
const SERVER_SUPPLIED_FIELD_GROUPS = [{
	label: "Customer master (filled in by the server)",
	fields: [
		{
			field: "customer.merchandisingName",
			label: "Seller name",
			optional: false,
			sample: "[Seller name]"
		},
		{
			field: "customer.merchandisingAddressLine1",
			label: "Address line 1",
			optional: false,
			sample: "[Address line 1]"
		},
		{
			field: "customer.merchandisingAddressLine2",
			label: "Address line 2",
			optional: true,
			sample: "[Address line 2]"
		},
		{
			field: "customer.merchandisingCity",
			label: "City",
			optional: false,
			sample: "[City]"
		},
		{
			field: "customer.merchandisingStateProvince",
			label: "State or province",
			optional: false,
			sample: "[ST]"
		},
		{
			field: "customer.merchandisingPostalCode",
			label: "Postal code",
			optional: false,
			sample: "[Postal code]"
		},
		{
			field: "customer.merchandisingCountry",
			label: "Country",
			optional: false,
			sample: "[Country]"
		},
		{
			field: "customer.merchandisingPhone",
			label: "Phone",
			optional: true,
			sample: "[Phone]"
		},
		{
			field: "customer.merchandisingCityStatePostal",
			label: "City, state and postal code, on one line",
			optional: false,
			sample: "[City], [ST] [Postal code]"
		}
	]
}, {
	label: "Generated (filled in by the server)",
	fields: [{
		field: "generated.addendumDate",
		label: "Addendum date, the day it is generated (Central time)",
		optional: false,
		sample: "12/15/2026"
	}]
}];
function serverSuppliedFieldOf(field) {
	return SERVER_SUPPLIED_FIELD_GROUPS.flatMap((group) => group.fields).find((candidate) => candidate.field === field) ?? null;
}
function serverFieldGroups() {
	return SERVER_SUPPLIED_FIELD_GROUPS.map((group) => ({
		label: group.label,
		options: group.fields.map((field) => ({
			value: field.field,
			label: `${field.field} · ${field.label}${field.optional ? " (optional: a blank drops its line)" : ""}`
		}))
	}));
}
function rewritten(document, field) {
	const entry = document.fields[field];
	return entry?.rewrittenOnWrite !== void 0 && entry.rewrittenOnWrite !== null;
}
function refusedOnTemplate(document, field) {
	if (rewritten(document, field)) return true;
	if (!field.endsWith("_description")) return false;
	const base = field.slice(0, -12);
	return rewritten(document, base) || rewritten(document, `${base}_code`);
}
function ctrmFieldGroup(document) {
	return {
		label: "CTRM fields",
		options: Object.keys(document.fields).filter((field) => !refusedOnTemplate(document, field)).sort(ordinal).map((field) => ({
			value: field,
			label: field
		}))
	};
}
function suggestedField(placeholder, groups) {
	const offered = new Set(groups.flatMap((group) => group.options.map((option) => option.value)));
	for (const candidate of [placeholder, `addendum_${placeholder}`]) if (offered.has(candidate)) return candidate;
	return null;
}
const SAMPLE_DATE = "2026-12-15";
function cwsFieldOf(field) {
	return FAMILY_B_ADDENDUM_FIELD_SETS.flatMap((set) => set.fields).find((candidate) => candidate.cwsField === field) ?? null;
}
function sampleValueFor(field, document) {
	const supplied = serverSuppliedFieldOf(field);
	if (supplied !== null) return supplied.sample;
	const cws = cwsFieldOf(field);
	if (cws !== null) return cws.kind === "date" ? SAMPLE_DATE : cws.kind === "price" ? "1.2500" : `[${cws.label}]`;
	const entry = document?.fields[field];
	switch (entry?.type) {
		case "date": return SAMPLE_DATE;
		case "number":
		case "integer": return (entry.scale ?? 0) > 0 ? `100.${"0".repeat(entry.scale)}` : "100";
		default: return `[${field}]`;
	}
}
function previewSegments(content, rows, document) {
	const fieldOf = new Map(rows.map((row) => [row.placeholder, row.field.trim()]));
	const segments = [];
	let last = 0;
	for (const match of content.matchAll(PLACEHOLDER_PATTERN)) {
		const index = match.index ?? 0;
		if (index > last) segments.push({
			kind: "text",
			text: content.slice(last, index)
		});
		const field = fieldOf.get(match[1]) ?? "";
		segments.push(field === "" ? {
			kind: "missing",
			text: `[${match[1]}: no field]`
		} : {
			kind: "value",
			text: sampleValueFor(field, document)
		});
		last = index + match[0].length;
	}
	if (last < content.length) segments.push({
		kind: "text",
		text: content.slice(last)
	});
	return segments;
}
function ordinal(left, right) {
	return left < right ? -1 : left > right ? 1 : 0;
}
const MAX_MATCHES = 8;
let nextId$1 = 0;
var AdminCodePickerComponent = class AdminCodePickerComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	name = input(null, ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	codes = input([], ...ngDevMode ? [{ debugName: "codes" }] : /* istanbul ignore next */ []);
	options = input(null, ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	unknownMessage = input.required(...ngDevMode ? [{ debugName: "unknownMessage" }] : /* istanbul ignore next */ []);
	emptyMeaning = input(null, ...ngDevMode ? [{ debugName: "emptyMeaning" }] : /* istanbul ignore next */ []);
	note = input(null, ...ngDevMode ? [{ debugName: "note" }] : /* istanbul ignore next */ []);
	searchPlaceholder = input("Type a code or name", ...ngDevMode ? [{ debugName: "searchPlaceholder" }] : /* istanbul ignore next */ []);
	freePlaceholder = input(null, ...ngDevMode ? [{ debugName: "freePlaceholder" }] : /* istanbul ignore next */ []);
	describedBy = input(null, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	invalid = input(false, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	codesChange = output();
	labelId = `cws-code-picker-${nextId$1}-label`;
	listId = `cws-code-picker-${nextId$1++}-list`;
	term = signal("", ...ngDevMode ? [{ debugName: "term" }] : /* istanbul ignore next */ []);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	active = signal(0, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	refusal = signal(null, ...ngDevMode ? [{ debugName: "refusal" }] : /* istanbul ignore next */ []);
	matches = computed(() => {
		const term = this.term().trim().toLowerCase();
		const picked = new Set(this.codes());
		return (this.options() ?? []).filter((option) => !picked.has(option.code)).filter((option) => term === "" || option.code.toLowerCase().includes(term) || option.label.toLowerCase().includes(term)).slice(0, MAX_MATCHES);
	}, ...ngDevMode ? [{ debugName: "matches" }] : /* istanbul ignore next */ []);
	activeId = computed(() => this.open() && this.matches().length > 0 ? this.optionId(this.active()) : null, ...ngDevMode ? [{ debugName: "activeId" }] : /* istanbul ignore next */ []);
	optionId(index) {
		return `${this.listId}-${index}`;
	}
	known(code) {
		return this.options()?.some((option) => option.code === code) ?? true;
	}
	chipLabel(code) {
		const option = this.options()?.find((candidate) => candidate.code === code);
		return option === void 0 ? `${code} · not in the list` : option.label;
	}
	onInput(value) {
		this.term.set(value);
		this.open.set(true);
		this.active.set(0);
		this.refusal.set(null);
	}
	onKeydown(event) {
		const count = this.matches().length;
		switch (event.key) {
			case "ArrowDown":
				event.preventDefault();
				this.open.set(true);
				this.active.set(count === 0 ? 0 : (this.active() + 1) % count);
				break;
			case "ArrowUp":
				event.preventDefault();
				this.open.set(true);
				this.active.set(count === 0 ? 0 : (this.active() - 1 + count) % count);
				break;
			case "Home":
				if (this.open()) {
					event.preventDefault();
					this.active.set(0);
				}
				break;
			case "End":
				if (this.open()) {
					event.preventDefault();
					this.active.set(Math.max(0, count - 1));
				}
				break;
			case "Escape":
				this.open.set(false);
				break;
			case "Enter":
				event.preventDefault();
				this.commit();
				break;
			case "Backspace": if (this.term() === "" && this.codes().length > 0) this.remove(this.codes()[this.codes().length - 1]);
		}
	}
	commit() {
		const typed = this.term().trim();
		const exact = (this.options() ?? []).find((option) => option.code.toLowerCase() === typed.toLowerCase());
		if (exact !== void 0) {
			this.add(exact.code);
			return;
		}
		const highlighted = this.open() ? this.matches()[this.active()] : void 0;
		if (highlighted !== void 0) {
			this.add(highlighted.code);
			return;
		}
		if (typed !== "") this.refusal.set(this.unknownMessage()([typed]));
	}
	add(code) {
		if (!this.codes().includes(code)) this.codesChange.emit([...this.codes(), code]);
		this.term.set("");
		this.active.set(0);
		this.refusal.set(null);
	}
	remove(code) {
		this.codesChange.emit(this.codes().filter((candidate) => candidate !== code));
	}
	freeText = linkedSignal({
		...ngDevMode ? { debugName: "freeText" } : /* istanbul ignore next */ {},
		source: () => this.codes(),
		computation: (codes, previous) => previous !== void 0 && sameCodes(listOf$1(previous.value), codes) ? previous.value : codes.join(", ")
	});
	onFreeInput(value) {
		this.freeText.set(value);
		this.codesChange.emit(listOf$1(value));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminCodePickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AdminCodePickerComponent,
		isStandalone: true,
		selector: "cws-admin-code-picker",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			codes: {
				classPropertyName: "codes",
				publicName: "codes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			unknownMessage: {
				classPropertyName: "unknownMessage",
				publicName: "unknownMessage",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			emptyMeaning: {
				classPropertyName: "emptyMeaning",
				publicName: "emptyMeaning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			note: {
				classPropertyName: "note",
				publicName: "note",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			searchPlaceholder: {
				classPropertyName: "searchPlaceholder",
				publicName: "searchPlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			freePlaceholder: {
				classPropertyName: "freePlaceholder",
				publicName: "freePlaceholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			describedBy: {
				classPropertyName: "describedBy",
				publicName: "describedBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { codesChange: "codesChange" },
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <span class="cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400" [id]="labelId">
      {{ label() }}
    </span>

    @if (options() === null) {
      <input
        class="scoular-form-input cws:mt-1 cws:w-full cws:font-mono"
        [attr.name]="name()"
        [attr.aria-labelledby]="labelId"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid()"
        [attr.placeholder]="freePlaceholder()"
        [value]="freeText()"
        [disabled]="disabled()"
        (input)="onFreeInput($any($event.target).value)"
      />
    } @else {
      <!--
        The caret (2026-10-28): this box opens a list, so it says so as a select does. A click on the
        box (or the caret, which passes the click through) opens the list.
      -->
      <div class="cws:relative cws:mt-1">
        <input
          class="scoular-form-input cws:w-full cws:pr-7"
          type="search"
          role="combobox"
          aria-autocomplete="list"
          [attr.name]="name()"
          [attr.aria-labelledby]="labelId"
          [attr.aria-describedby]="describedBy()"
          [attr.aria-invalid]="invalid() || refusal() !== null"
          [attr.aria-expanded]="open()"
          [attr.aria-controls]="listId"
          [attr.aria-activedescendant]="activeId()"
          [attr.placeholder]="searchPlaceholder()"
          [value]="term()"
          [disabled]="disabled()"
          (input)="onInput($any($event.target).value)"
          (keydown)="onKeydown($event)"
          (click)="open.set(true)"
          (blur)="open.set(false)"
        />
        <cms-dropdown-caret
          class="cws:absolute cws:top-1/2 cws:right-0.5 cws:-translate-y-1/2 cws:text-slate-900 cws:dark:text-white"
          [open]="open() && matches().length > 0"
          [disabled]="disabled()"
        />
      </div>

      @if (open() && matches().length > 0) {
        <ul
          class="cws:mt-1 cws:max-h-60 cws:overflow-auto cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:text-xs cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800"
          role="listbox"
          [id]="listId"
          [attr.aria-label]="label() + ' matches'"
        >
          @for (option of matches(); track option.code; let index = $index) {
            <li
              role="option"
              class="cws:cursor-pointer cws:px-2 cws:py-1"
              [id]="optionId(index)"
              [attr.aria-selected]="index === active()"
              [class.cws:bg-slate-100]="index === active()"
              [class.cws:dark:bg-slate-700]="index === active()"
              (mousedown)="$event.preventDefault()"
              (click)="add(option.code)"
            >
              {{ option.label }}
            </li>
          }
        </ul>
      }

      <!-- 2026-10-29: picked codes and the empty hint sit UNDER the box, so every picker's box starts level
        with the inputs beside it, whatever is picked. -->
      @if (codes().length > 0) {
        <ul class="cws:mt-1 cws:flex cws:flex-wrap cws:gap-1" [attr.aria-label]="label() + ' picked'" data-testid="code-picker-chips">
          @for (code of codes(); track code) {
            <li
              class="cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:px-2 cws:py-0.5 cws:text-xs"
              [class.cws:border-slate-300]="known(code)"
              [class.cws:border-rose-400]="!known(code)"
            >
              <span>{{ chipLabel(code) }}</span>
              <button
                type="button"
                class="cws:text-slate-500 cws:hover:text-slate-900 cws:dark:hover:text-white"
                [attr.aria-label]="'Remove ' + code"
                [disabled]="disabled()"
                (click)="remove(code)"
              >
                ×
              </button>
            </li>
          }
        </ul>
      } @else if (emptyMeaning()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ emptyMeaning() }}</p>
      }

      @if (refusal(); as reason) {
        <p class="cws:mt-1 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300" role="alert" data-testid="code-picker-refusal">
          {{ reason }}
        </p>
      }

      @if (note()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="code-picker-note">{{ note() }}</p>
      }
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: DropdownCaretComponent,
			selector: "cms-dropdown-caret",
			inputs: ["open", "disabled"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AdminCodePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-code-picker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			imports: [DropdownCaretComponent],
			template: `
    <span class="cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400" [id]="labelId">
      {{ label() }}
    </span>

    @if (options() === null) {
      <input
        class="scoular-form-input cws:mt-1 cws:w-full cws:font-mono"
        [attr.name]="name()"
        [attr.aria-labelledby]="labelId"
        [attr.aria-describedby]="describedBy()"
        [attr.aria-invalid]="invalid()"
        [attr.placeholder]="freePlaceholder()"
        [value]="freeText()"
        [disabled]="disabled()"
        (input)="onFreeInput($any($event.target).value)"
      />
    } @else {
      <!--
        The caret (2026-10-28): this box opens a list, so it says so as a select does. A click on the
        box (or the caret, which passes the click through) opens the list.
      -->
      <div class="cws:relative cws:mt-1">
        <input
          class="scoular-form-input cws:w-full cws:pr-7"
          type="search"
          role="combobox"
          aria-autocomplete="list"
          [attr.name]="name()"
          [attr.aria-labelledby]="labelId"
          [attr.aria-describedby]="describedBy()"
          [attr.aria-invalid]="invalid() || refusal() !== null"
          [attr.aria-expanded]="open()"
          [attr.aria-controls]="listId"
          [attr.aria-activedescendant]="activeId()"
          [attr.placeholder]="searchPlaceholder()"
          [value]="term()"
          [disabled]="disabled()"
          (input)="onInput($any($event.target).value)"
          (keydown)="onKeydown($event)"
          (click)="open.set(true)"
          (blur)="open.set(false)"
        />
        <cms-dropdown-caret
          class="cws:absolute cws:top-1/2 cws:right-0.5 cws:-translate-y-1/2 cws:text-slate-900 cws:dark:text-white"
          [open]="open() && matches().length > 0"
          [disabled]="disabled()"
        />
      </div>

      @if (open() && matches().length > 0) {
        <ul
          class="cws:mt-1 cws:max-h-60 cws:overflow-auto cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:text-xs cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800"
          role="listbox"
          [id]="listId"
          [attr.aria-label]="label() + ' matches'"
        >
          @for (option of matches(); track option.code; let index = $index) {
            <li
              role="option"
              class="cws:cursor-pointer cws:px-2 cws:py-1"
              [id]="optionId(index)"
              [attr.aria-selected]="index === active()"
              [class.cws:bg-slate-100]="index === active()"
              [class.cws:dark:bg-slate-700]="index === active()"
              (mousedown)="$event.preventDefault()"
              (click)="add(option.code)"
            >
              {{ option.label }}
            </li>
          }
        </ul>
      }

      <!-- 2026-10-29: picked codes and the empty hint sit UNDER the box, so every picker's box starts level
        with the inputs beside it, whatever is picked. -->
      @if (codes().length > 0) {
        <ul class="cws:mt-1 cws:flex cws:flex-wrap cws:gap-1" [attr.aria-label]="label() + ' picked'" data-testid="code-picker-chips">
          @for (code of codes(); track code) {
            <li
              class="cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:px-2 cws:py-0.5 cws:text-xs"
              [class.cws:border-slate-300]="known(code)"
              [class.cws:border-rose-400]="!known(code)"
            >
              <span>{{ chipLabel(code) }}</span>
              <button
                type="button"
                class="cws:text-slate-500 cws:hover:text-slate-900 cws:dark:hover:text-white"
                [attr.aria-label]="'Remove ' + code"
                [disabled]="disabled()"
                (click)="remove(code)"
              >
                ×
              </button>
            </li>
          }
        </ul>
      } @else if (emptyMeaning()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ emptyMeaning() }}</p>
      }

      @if (refusal(); as reason) {
        <p class="cws:mt-1 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300" role="alert" data-testid="code-picker-refusal">
          {{ reason }}
        </p>
      }

      @if (note()) {
        <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="code-picker-note">{{ note() }}</p>
      }
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		codes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "codes",
				required: false
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: false
			}]
		}],
		unknownMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unknownMessage",
				required: true
			}]
		}],
		emptyMeaning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyMeaning",
				required: false
			}]
		}],
		note: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "note",
				required: false
			}]
		}],
		searchPlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "searchPlaceholder",
				required: false
			}]
		}],
		freePlaceholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "freePlaceholder",
				required: false
			}]
		}],
		describedBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "describedBy",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		codesChange: [{
			type: i0.Output,
			args: ["codesChange"]
		}]
	}
});
function listOf$1(text) {
	return text.split(",").map((item) => item.trim()).filter((item) => item !== "");
}
function sameCodes(left, right) {
	return left.length === right.length && left.every((code, index) => code === right[index]);
}
var AdminTabsComponent = class AdminTabsComponent {
	views = input.required(...ngDevMode ? [{ debugName: "views" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	area = inject(ActivatedRoute).parent;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminTabsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AdminTabsComponent,
		isStandalone: true,
		selector: "cws-admin-tabs",
		inputs: {
			views: {
				classPropertyName: "views",
				publicName: "views",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <nav [attr.aria-label]="label()" class="cws:border-b cws:border-slate-200 cws:dark:border-slate-700">
      <ul class="cws:-mb-px cws:flex cws:gap-1 cws:overflow-x-auto">
        @for (view of views(); track view.path) {
          <li>
            <a
              class="cws:block cws:whitespace-nowrap cws:border-b-2 cws:border-transparent cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white cws:aria-[current=page]:border-scoular-blue cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:border-sky-400 cws:dark:aria-[current=page]:text-sky-400"
              [routerLink]="view.path === '' ? ['.'] : [view.path]"
              [relativeTo]="area"
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >{{ view.label }}</a
            >
          </li>
        }
      </ul>
    </nav>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}, {
			kind: "directive",
			type: RouterLinkActive,
			selector: "[routerLinkActive]",
			inputs: [
				"routerLinkActiveOptions",
				"ariaCurrentWhenActive",
				"routerLinkActive"
			],
			outputs: ["isActiveChange"],
			exportAs: ["routerLinkActive"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AdminTabsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-tabs",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [RouterLink, RouterLinkActive],
			host: { class: "cws:block" },
			template: `
    <nav [attr.aria-label]="label()" class="cws:border-b cws:border-slate-200 cws:dark:border-slate-700">
      <ul class="cws:-mb-px cws:flex cws:gap-1 cws:overflow-x-auto">
        @for (view of views(); track view.path) {
          <li>
            <a
              class="cws:block cws:whitespace-nowrap cws:border-b-2 cws:border-transparent cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white cws:aria-[current=page]:border-scoular-blue cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:border-sky-400 cws:dark:aria-[current=page]:text-sky-400"
              [routerLink]="view.path === '' ? ['.'] : [view.path]"
              [relativeTo]="area"
              routerLinkActive=""
              [routerLinkActiveOptions]="{ exact: true }"
              ariaCurrentWhenActive="page"
              >{{ view.label }}</a
            >
          </li>
        }
      </ul>
    </nav>
  `
		}]
	}],
	propDecorators: {
		views: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "views",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}]
	}
});
const TYPE_FIELDS = [
	"specialType",
	"displayName",
	"family"
];
const FAMILIES = ["A", "B"];
var AddendumTypesSectionComponent = class AddendumTypesSectionComponent {
	source = inject(ADDENDUM_TYPE_SOURCE, { optional: true });
	access = inject(AdminScope);
	destroyRef = inject(DestroyRef);
	families = FAMILIES;
	offered = this.source !== null;
	state = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	types = signal([], ...ngDevMode ? [{ debugName: "types" }] : /* istanbul ignore next */ []);
	editor = signal(null, ...ngDevMode ? [{ debugName: "editor" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	typeActions = computed(() => {
		const refusal = () => this.writesRefused() ?? (this.busy() ? "A type change is in progress" : false);
		return new Map(this.types().map((type) => {
			const actions = [{
				label: "Edit",
				run: (row) => this.startEdit(row),
				disabled: refusal
			}];
			if (type.available) actions.push({
				label: "Deactivate",
				run: (row) => this.deactivate(row),
				disabled: refusal
			});
			return [type.specialType, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "typeActions" }] : /* istanbul ignore next */ []);
	writesRefused = computed(() => this.access.knownNotAdmin() ? "Needs the Admin role" : null, ...ngDevMode ? [{ debugName: "writesRefused" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const state = this.state();
		return state.status === "failed" ? state : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	fieldErrors = signal({}, ...ngDevMode ? [{ debugName: "fieldErrors" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	reloadOffered = signal(false, ...ngDevMode ? [{ debugName: "reloadOffered" }] : /* istanbul ignore next */ []);
	constructor() {
		this.load();
	}
	load() {
		const source = this.source;
		if (source === null) return;
		this.state.set({ status: "loading" });
		source.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") this.types.set(answer.value);
			this.state.set(listStateOf$1(answer));
		});
	}
	reload() {
		this.clearOutcome();
		this.cancelEdit();
		this.load();
	}
	familyLabel(family) {
		return family === "A" ? "A (StoneX)" : "B (in-house)";
	}
	errorsFor(field) {
		return this.fieldErrors()[field] ?? [];
	}
	startCreate() {
		this.open({
			original: null,
			specialType: "",
			displayName: "",
			family: "B",
			available: true
		});
	}
	startEdit(type) {
		this.open({
			original: type,
			...typeDraftOf(type)
		});
	}
	cancelEdit() {
		this.editor.set(null);
		this.fieldErrors.set({});
	}
	clearOutcome() {
		this.outcome.set(null);
		this.reloadOffered.set(false);
	}
	save() {
		const editor = this.editor();
		const source = this.source;
		if (editor === null || source === null) return;
		const draft = {
			specialType: editor.original?.specialType ?? editor.specialType.trim(),
			displayName: editor.displayName.trim(),
			family: editor.family,
			available: editor.available
		};
		const local = {
			...draft.specialType === "" ? { specialType: ["A type needs its CTRM special type code."] } : {},
			...draft.displayName === "" ? { displayName: ["A type needs a display name."] } : {}
		};
		this.fieldErrors.set(local);
		this.clearOutcome();
		if (Object.keys(local).length > 0) {
			this.outcome.set(mutationRefused(`Type not saved. ${Object.values(local).flat().join(" ")}`));
			return;
		}
		this.run(editor.original === null ? source.create(draft) : source.update(editor.original, draft), `Type ${draft.specialType} ${editor.original === null ? "created" : "saved"}.`, () => this.editor.set(null));
	}
	deactivate(type) {
		const source = this.source;
		if (source !== null) this.run(source.update(type, {
			...typeDraftOf(type),
			available: false
		}), `Type ${type.specialType} deactivated.`);
	}
	open(editor) {
		this.editor.set(editor);
		this.fieldErrors.set({});
		this.clearOutcome();
	}
	run(request, success, onDone) {
		this.busy.set(true);
		this.clearOutcome();
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.busy.set(false);
			switch (answer.kind) {
				case "done":
					onDone?.();
					this.outcome.set(mutationSucceeded(success));
					this.load();
					break;
				case "unavailable":
					this.outcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "conflict":
					this.outcome.set(mutationFailed(answer));
					this.reloadOffered.set(true);
					break;
				case "failed": {
					const placed = {};
					const unplaced = [];
					for (const [key, reasons] of Object.entries(answer.fieldErrors ?? {})) if (TYPE_FIELDS.includes(key)) placed[key] = reasons;
					else unplaced.push(...reasons);
					this.fieldErrors.set(placed);
					this.outcome.set(mutationFailed({
						message: Object.keys(placed).length === 0 || unplaced.length === 0 ? answer.message : unplaced.join(" "),
						correlationId: answer.correlationId
					}));
					break;
				}
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AddendumTypesSectionComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AddendumTypesSectionComponent,
		isStandalone: true,
		selector: "cws-addendum-types-section",
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<!--\n  #676, #798: the addendum types. A template is offered on a record only for a type that is\n  available, so this is where an administrator sees why a picker is empty, and fixes it.\n-->\n@if (offered) {\n  <section class=\"cws:space-y-2\" aria-labelledby=\"addendum-types-heading\">\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\n      <h3 id=\"addendum-types-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n        Addendum types\n      </h3>\n      @if (state().status === 'loaded' && editor() === null) {\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          [disabled]=\"busy() || writesRefused() !== null\"\n          [attr.title]=\"writesRefused()\"\n          (click)=\"startCreate()\"\n        >\n          New type\n        </button>\n      }\n    </div>\n\n    @if (writesRefused(); as reason) {\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-testid=\"types-admin-only\">\n        {{ reason }}. You can view addendum types; changing them is for an administrator.\n      </p>\n    }\n\n    <!--\n      #803: the last write's outcome, with the server's reference on a failure. A 409 is in the\n      server's words, offers Reload, and is never retried.\n    -->\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\n      @if (reloadOffered()) {\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\n      }\n    </cms-status-message>\n\n    @switch (state().status) {\n      @case ('loading') {\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading types…</p>\n      }\n      @case ('unavailable') {\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"types-unavailable\">\n          Addendum types are not available yet.\n        </p>\n      }\n      @case ('failed') {\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"types-failed\">\n          The addendum types could not be read.\n          @if (failure()?.correlationId; as id) {\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\n          }\n        </p>\n      }\n      @case ('loaded') {\n        <table class=\"cws:w-full cws:text-left cws:text-xs\" aria-label=\"Addendum types\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Code</th>\n              <th class=\"cws:py-1\">Display name</th>\n              <th class=\"cws:py-1\">Family</th>\n              <th class=\"cws:py-1\">Available</th>\n              <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"types-rows\">\n            @for (type of types(); track type.specialType) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ type.specialType }}</td>\n                <td class=\"cws:py-1\">{{ type.displayName }}</td>\n                <td class=\"cws:py-1\">{{ familyLabel(type.family) }}</td>\n                <td class=\"cws:py-1\">{{ type.available ? 'Yes' : 'No' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <!-- #825: Edit and Deactivate behind the row's menu. No Delete, by ruling (2026-10-12). -->\n                  <cms-row-menu\n                    [row]=\"type\"\n                    [actions]=\"typeActions().get(type.specialType) ?? []\"\n                    [label]=\"'Actions for type ' + type.specialType\"\n                  />\n                </td>\n              </tr>\n            } @empty {\n              <tr>\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\" colspan=\"5\" data-testid=\"types-empty\">\n                  No addendum types yet. No template can be offered on a contract until its special type is\n                  added here and marked available.\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n    }\n\n    @if (editor(); as draft) {\n      <form\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\n        aria-label=\"Addendum type\"\n        (ngSubmit)=\"save()\"\n      >\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n          @if (draft.original === null) { New type } @else { Edit type {{ draft.original.specialType }} }\n        </h4>\n\n        <div class=\"cws:flex cws:flex-wrap cws:items-start cws:gap-3\">\n          <!-- Reasons sit outside each label and are tied to it by aria-describedby, as on the template form. -->\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block cws:space-y-1\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Code</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-28 cws:font-mono\"\n                name=\"specialType\"\n                placeholder=\"MNC\"\n                [(ngModel)]=\"draft.specialType\"\n                [readonly]=\"draft.original !== null\"\n                [attr.aria-invalid]=\"errorsFor('specialType').length > 0\"\n                aria-describedby=\"addendum-type-specialType-hint addendum-type-specialType-errors\"\n              />\n            </label>\n            <span id=\"addendum-type-specialType-hint\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              @if (draft.original === null) {\n                CTRM's special type code, not its description.\n              } @else {\n                The code cannot change once a type exists.\n              }\n            </span>\n            <span id=\"addendum-type-specialType-errors\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('specialType'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block cws:space-y-1\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Display name</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-56\"\n                name=\"displayName\"\n                [(ngModel)]=\"draft.displayName\"\n                [attr.aria-invalid]=\"errorsFor('displayName').length > 0\"\n                aria-describedby=\"addendum-type-displayName-errors\"\n              />\n            </label>\n            <span id=\"addendum-type-displayName-errors\" class=\"cws:block cws:max-w-56 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('displayName'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block cws:space-y-1\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Family</span>\n              <select\n                class=\"scoular-form-input cws:mt-1 cws:w-36\"\n                name=\"family\"\n                [(ngModel)]=\"draft.family\"\n                [attr.aria-invalid]=\"errorsFor('family').length > 0\"\n                aria-describedby=\"addendum-type-family-errors\"\n              >\n                @for (family of families; track family) {\n                  <option [value]=\"family\">{{ familyLabel(family) }}</option>\n                }\n              </select>\n            </label>\n            <span id=\"addendum-type-family-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('family'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-6 cws:text-xs\">\n            <input type=\"checkbox\" name=\"available\" [(ngModel)]=\"draft.available\" />\n            Available (approved by Legal)\n          </label>\n        </div>\n\n        <div class=\"cws:flex cws:gap-2\">\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\n            {{ busy() ? 'Saving…' : 'Save type' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\n        </div>\n      </form>\n    }\n  </section>\n}\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AddendumTypesSectionComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-addendum-types-section",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				RowMenuComponent,
				StatusMessageComponent
			],
			host: { class: "cws:block" },
			template: "<!--\n  #676, #798: the addendum types. A template is offered on a record only for a type that is\n  available, so this is where an administrator sees why a picker is empty, and fixes it.\n-->\n@if (offered) {\n  <section class=\"cws:space-y-2\" aria-labelledby=\"addendum-types-heading\">\n    <div class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\n      <h3 id=\"addendum-types-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n        Addendum types\n      </h3>\n      @if (state().status === 'loaded' && editor() === null) {\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          [disabled]=\"busy() || writesRefused() !== null\"\n          [attr.title]=\"writesRefused()\"\n          (click)=\"startCreate()\"\n        >\n          New type\n        </button>\n      }\n    </div>\n\n    @if (writesRefused(); as reason) {\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-testid=\"types-admin-only\">\n        {{ reason }}. You can view addendum types; changing them is for an administrator.\n      </p>\n    }\n\n    <!--\n      #803: the last write's outcome, with the server's reference on a failure. A 409 is in the\n      server's words, offers Reload, and is never retried.\n    -->\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\n      @if (reloadOffered()) {\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\n      }\n    </cms-status-message>\n\n    @switch (state().status) {\n      @case ('loading') {\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading types…</p>\n      }\n      @case ('unavailable') {\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"types-unavailable\">\n          Addendum types are not available yet.\n        </p>\n      }\n      @case ('failed') {\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\" data-testid=\"types-failed\">\n          The addendum types could not be read.\n          @if (failure()?.correlationId; as id) {\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\n          }\n        </p>\n      }\n      @case ('loaded') {\n        <table class=\"cws:w-full cws:text-left cws:text-xs\" aria-label=\"Addendum types\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Code</th>\n              <th class=\"cws:py-1\">Display name</th>\n              <th class=\"cws:py-1\">Family</th>\n              <th class=\"cws:py-1\">Available</th>\n              <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"types-rows\">\n            @for (type of types(); track type.specialType) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ type.specialType }}</td>\n                <td class=\"cws:py-1\">{{ type.displayName }}</td>\n                <td class=\"cws:py-1\">{{ familyLabel(type.family) }}</td>\n                <td class=\"cws:py-1\">{{ type.available ? 'Yes' : 'No' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <!-- #825: Edit and Deactivate behind the row's menu. No Delete, by ruling (2026-10-12). -->\n                  <cms-row-menu\n                    [row]=\"type\"\n                    [actions]=\"typeActions().get(type.specialType) ?? []\"\n                    [label]=\"'Actions for type ' + type.specialType\"\n                  />\n                </td>\n              </tr>\n            } @empty {\n              <tr>\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\" colspan=\"5\" data-testid=\"types-empty\">\n                  No addendum types yet. No template can be offered on a contract until its special type is\n                  added here and marked available.\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n    }\n\n    @if (editor(); as draft) {\n      <form\n        class=\"cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\n        aria-label=\"Addendum type\"\n        (ngSubmit)=\"save()\"\n      >\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n          @if (draft.original === null) { New type } @else { Edit type {{ draft.original.specialType }} }\n        </h4>\n\n        <div class=\"cws:flex cws:flex-wrap cws:items-start cws:gap-3\">\n          <!-- Reasons sit outside each label and are tied to it by aria-describedby, as on the template form. -->\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block cws:space-y-1\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Code</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-28 cws:font-mono\"\n                name=\"specialType\"\n                placeholder=\"MNC\"\n                [(ngModel)]=\"draft.specialType\"\n                [readonly]=\"draft.original !== null\"\n                [attr.aria-invalid]=\"errorsFor('specialType').length > 0\"\n                aria-describedby=\"addendum-type-specialType-hint addendum-type-specialType-errors\"\n              />\n            </label>\n            <span id=\"addendum-type-specialType-hint\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              @if (draft.original === null) {\n                CTRM's special type code, not its description.\n              } @else {\n                The code cannot change once a type exists.\n              }\n            </span>\n            <span id=\"addendum-type-specialType-errors\" class=\"cws:block cws:max-w-48 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('specialType'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block cws:space-y-1\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Display name</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-56\"\n                name=\"displayName\"\n                [(ngModel)]=\"draft.displayName\"\n                [attr.aria-invalid]=\"errorsFor('displayName').length > 0\"\n                aria-describedby=\"addendum-type-displayName-errors\"\n              />\n            </label>\n            <span id=\"addendum-type-displayName-errors\" class=\"cws:block cws:max-w-56 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('displayName'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block cws:space-y-1\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Family</span>\n              <select\n                class=\"scoular-form-input cws:mt-1 cws:w-36\"\n                name=\"family\"\n                [(ngModel)]=\"draft.family\"\n                [attr.aria-invalid]=\"errorsFor('family').length > 0\"\n                aria-describedby=\"addendum-type-family-errors\"\n              >\n                @for (family of families; track family) {\n                  <option [value]=\"family\">{{ familyLabel(family) }}</option>\n                }\n              </select>\n            </label>\n            <span id=\"addendum-type-family-errors\" class=\"cws:block cws:max-w-40 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('family'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-6 cws:text-xs\">\n            <input type=\"checkbox\" name=\"available\" [(ngModel)]=\"draft.available\" />\n            Available (approved by Legal)\n          </label>\n        </div>\n\n        <div class=\"cws:flex cws:gap-2\">\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\n            {{ busy() ? 'Saving…' : 'Save type' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\n        </div>\n      </form>\n    }\n  </section>\n}\n"
		}]
	}],
	ctorParameters: () => []
});
function listStateOf$1(answer) {
	switch (answer.kind) {
		case "done": return { status: "loaded" };
		case "unavailable": return { status: "unavailable" };
		default: return {
			status: "failed",
			message: answer.message,
			...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
		};
	}
}
const EDITOR_FIELDS = [
	"name",
	"specialTypes",
	"language",
	"tradeUnits",
	"contentFormat",
	"templateContent",
	"fields"
];
const CONTENT_FORMATS = ADDENDUM_CONTENT_FORMATS;
function unknownCodes(codes, options) {
	if (options === null) return [];
	const known = new Set(options.map((option) => option.code));
	return codes.filter((code) => !known.has(code));
}
function unknownTypesMessage(codes) {
	return `Not addendum types: ${codes.join(", ")}. Create the type first.`;
}
function unknownTradeUnitsMessage(codes) {
	return `Not CTRM locations, so the template would never be offered there: ${codes.join(", ")}.`;
}
const NOT_ONBOARDED_EXPLANATION = "Not onboarded: the trade unit has no form configuration in CWS yet. Contract saves there are refused, and an addendum is generated by a save, so this template is not used there until the trade unit is onboarded under Form configuration.";
function typeNotAvailableMessage(code) {
	return `${code} is not available, so no addendum is generated for it and this template is not offered for it.`;
}
var AddendumTemplatesPageComponent = class AddendumTemplatesPageComponent {
	view = input("all", {
		...ngDevMode ? { debugName: "view" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "all"
	});
	showTemplates = computed(() => this.view() !== "types", ...ngDevMode ? [{ debugName: "showTemplates" }] : /* istanbul ignore next */ []);
	showTypes = computed(() => this.view() !== "templates", ...ngDevMode ? [{ debugName: "showTypes" }] : /* istanbul ignore next */ []);
	routed = computed(() => this.view() !== "all", ...ngDevMode ? [{ debugName: "routed" }] : /* istanbul ignore next */ []);
	area = adminArea("addendums");
	source = inject(ADDENDUM_TEMPLATE_SOURCE, { optional: true });
	typeSource = inject(ADDENDUM_TYPE_SOURCE, { optional: true });
	constraintSource = inject(CONSTRAINT_SOURCE, { optional: true });
	access = inject(AdminScope);
	types = signal(null, ...ngDevMode ? [{ debugName: "types" }] : /* istanbul ignore next */ []);
	typeOptions = computed(() => this.types()?.map((type) => ({
		code: type.specialType,
		label: `${type.specialType} · ${type.displayName}` + (type.available ? " · approved by Legal" : " · not yet approved by Legal, so no addendum is generated for it")
	})) ?? null, ...ngDevMode ? [{ debugName: "typeOptions" }] : /* istanbul ignore next */ []);
	tradeUnitOptions = computed(() => {
		const locations = this.access.locations();
		if (locations === null) return null;
		const scope = this.access.scope();
		const onboarded = new Set(scope.onboarded);
		return [...locations].sort((left, right) => left.code.localeCompare(right.code)).map((location) => ({
			code: location.code,
			label: `${location.code}${location.name === null ? "" : ` · ${location.name}`}` + (scope.known ? onboarded.has(location.code) ? " · onboarded" : " · not onboarded" : "")
		}));
	}, ...ngDevMode ? [{ debugName: "tradeUnitOptions" }] : /* istanbul ignore next */ []);
	tradeUnitNote = computed(() => {
		const locations = this.access.locations();
		const notes = [this.access.locationOrigin() === "Simulated" && locations !== null ? `This environment reads CTRM's simulator, so only its ${locations.length} locations can be picked: ${locations.map((location) => location.code).sort().join(", ")}.` : null, locations !== null && this.access.scope().known ? NOT_ONBOARDED_EXPLANATION : null].filter((note) => note !== null);
		return notes.length === 0 ? null : notes.join(" ");
	}, ...ngDevMode ? [{ debugName: "tradeUnitNote" }] : /* istanbul ignore next */ []);
	unknownTypesMessage = unknownTypesMessage;
	unknownTradeUnitsMessage = unknownTradeUnitsMessage;
	typeNotAvailableMessage = typeNotAvailableMessage;
	writesRefused = computed(() => this.access.knownNotAdmin() ? "Needs the Admin role" : null, ...ngDevMode ? [{ debugName: "writesRefused" }] : /* istanbul ignore next */ []);
	confirm = injectConfirm();
	destroyRef = inject(DestroyRef);
	anchors = [
		ADDENDUM_SIGNATURE_ANCHOR,
		ADDENDUM_DATE_ANCHOR,
		ADDENDUM_INITIALS_ANCHOR
	];
	contentFormats = CONTENT_FORMATS;
	markupReferenceUrl = inject(CWS_EXTERNAL_LINKS).addendumMarkupReference ?? null;
	offered = this.source !== null;
	state = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	unavailableReason = computed(() => {
		const state = this.state();
		return state.status === "unavailable" ? state.reason : null;
	}, ...ngDevMode ? [{ debugName: "unavailableReason" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const state = this.state();
		return state.status === "failed" ? state : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	templates = signal([], ...ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []);
	editor = signal(null, ...ngDevMode ? [{ debugName: "editor" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	content = signal("", ...ngDevMode ? [{ debugName: "content" }] : /* istanbul ignore next */ []);
	mappings = signal({}, ...ngDevMode ? [{ debugName: "mappings" }] : /* istanbul ignore next */ []);
	constraints = signal(null, ...ngDevMode ? [{ debugName: "constraints" }] : /* istanbul ignore next */ []);
	constraintsRequested = false;
	ctrmListed = computed(() => this.constraints() !== null, ...ngDevMode ? [{ debugName: "ctrmListed" }] : /* istanbul ignore next */ []);
	fieldGroups = computed(() => {
		const document = this.constraints();
		return [
			...addendumFieldGroups(this.editor()?.specialTypes ?? []),
			...serverFieldGroups(),
			...document === null ? [] : [ctrmFieldGroup(document)]
		];
	}, ...ngDevMode ? [{ debugName: "fieldGroups" }] : /* istanbul ignore next */ []);
	placeholderRows = computed(() => placeholderRows(this.content(), this.mappings(), (name) => suggestedField(name, this.fieldGroups())), ...ngDevMode ? [{ debugName: "placeholderRows" }] : /* istanbul ignore next */ []);
	unmapped = computed(() => unmappedPlaceholders(this.placeholderRows()), ...ngDevMode ? [{ debugName: "unmapped" }] : /* istanbul ignore next */ []);
	previewOpen = signal(false, ...ngDevMode ? [{ debugName: "previewOpen" }] : /* istanbul ignore next */ []);
	preview = computed(() => this.previewOpen() ? previewSegments(this.content(), this.placeholderRows(), this.constraints()) : [], ...ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []);
	initialsOptional = signal(false, ...ngDevMode ? [{ debugName: "initialsOptional" }] : /* istanbul ignore next */ []);
	anchorChecks = computed(() => this.anchors.map((anchor) => ({
		anchor,
		present: this.content().includes(anchor),
		required: !(this.initialsOptional() && anchor === ADDENDUM_INITIALS_ANCHOR)
	})), ...ngDevMode ? [{ debugName: "anchorChecks" }] : /* istanbul ignore next */ []);
	unavailableTypes = computed(() => {
		const picked = this.editor()?.specialTypes ?? [];
		return (this.types() ?? []).filter((type) => !type.available && picked.includes(type.specialType));
	}, ...ngDevMode ? [{ debugName: "unavailableTypes" }] : /* istanbul ignore next */ []);
	typeWritesOffered = this.typeSource !== null;
	templateActions = computed(() => {
		const refusal = () => this.writesRefused() ?? (this.busy() ? "A template change is in progress" : false);
		return new Map(this.templates().map((template) => {
			const actions = [{
				label: "Edit",
				run: (row) => this.startEdit(row),
				disabled: refusal
			}];
			if (template.active) actions.push({
				label: "Deactivate",
				run: (row) => this.deactivate(row),
				disabled: refusal
			});
			actions.push({
				label: "Delete",
				run: (row) => this.remove(row),
				disabled: refusal
			});
			return [template.id, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "templateActions" }] : /* istanbul ignore next */ []);
	anchorProblems = signal([], ...ngDevMode ? [{ debugName: "anchorProblems" }] : /* istanbul ignore next */ []);
	fieldErrors = signal({}, ...ngDevMode ? [{ debugName: "fieldErrors" }] : /* istanbul ignore next */ []);
	contentProblems = computed(() => [...this.anchorProblems(), ...this.fieldErrors().templateContent ?? []], ...ngDevMode ? [{ debugName: "contentProblems" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	reloadOffered = signal(false, ...ngDevMode ? [{ debugName: "reloadOffered" }] : /* istanbul ignore next */ []);
	constructor() {
		this.load();
	}
	loadTypes() {
		this.typeSource?.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => this.types.set(answer.kind === "done" ? answer.value : null));
	}
	loadConstraints() {
		const source = this.constraintSource;
		if (source === null || this.constraintsRequested) return;
		this.constraintsRequested = true;
		source.document().pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (snapshot) => this.constraints.set(snapshot.document),
			error: () => {
				this.constraintsRequested = false;
				this.constraints.set(null);
			}
		});
	}
	load() {
		const source = this.source;
		if (source === null) return;
		this.state.set({ status: "loading" });
		source.list().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (answer.kind === "done") this.templates.set(answer.value);
			this.state.set(listStateOf(answer));
		});
	}
	reload() {
		this.clearOutcome();
		this.cancelEdit();
		this.load();
	}
	errorsFor(field) {
		return this.fieldErrors()[field] ?? [];
	}
	startCreate() {
		this.open({
			id: null,
			version: null,
			rowVersion: null,
			name: "",
			specialTypes: [],
			language: DEFAULT_ADDENDUM_LANGUAGE,
			contentFormat: ADDENDUM_MARKUP_CONTENT_FORMAT,
			tradeUnits: [],
			active: true
		}, "", {}, false);
	}
	startEdit(template) {
		this.open({
			id: template.id,
			version: template.version,
			rowVersion: template.rowVersion,
			name: template.name,
			specialTypes: [...template.specialTypes],
			language: template.language,
			contentFormat: template.contentFormat,
			tradeUnits: [...template.tradeUnits],
			active: template.active
		}, template.templateContent, mappingsOf(template.fields), template.initialsAnchorOptional === true);
	}
	cancelEdit() {
		this.editor.set(null);
		this.previewOpen.set(false);
		this.anchorProblems.set([]);
		this.fieldErrors.set({});
	}
	setField(change) {
		this.mappings.update((mappings) => ({
			...mappings,
			[change.placeholder]: change.field
		}));
	}
	removeMapping(placeholder) {
		this.mappings.update((mappings) => Object.fromEntries(Object.entries(mappings).filter(([key]) => key !== placeholder)));
	}
	togglePreview() {
		this.previewOpen.update((open) => !open);
	}
	makeAvailable(type) {
		const source = this.typeSource;
		if (source === null) return;
		this.confirm({
			title: `Make ${type.specialType} available?`,
			message: `Only when Legal has approved ${type.displayName}. Once it is available, its active templates are offered on contracts of that special type, and saving such a contract generates an addendum.`,
			confirmLabel: "Make available",
			cancelLabel: "Not yet"
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (!confirmed) return;
			this.busy.set(true);
			this.clearOutcome();
			source.update(type, {
				...typeDraftOf(type),
				available: true
			}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
				this.busy.set(false);
				this.loadTypes();
				if (answer.kind === "done") this.outcome.set(mutationSucceeded(`Type ${type.specialType} is now available.`));
				else this.outcome.set(mutationFailed(answer.kind === "unavailable" ? { message: answer.reason } : answer));
			});
		});
	}
	clearOutcome() {
		this.outcome.set(null);
		this.reloadOffered.set(false);
	}
	save() {
		const editor = this.editor();
		const source = this.source;
		if (editor === null || source === null) return;
		const templateContent = this.content();
		const initialsAnchorOptional = this.initialsOptional();
		const problems = addendumAnchorProblems(templateContent, initialsAnchorOptional);
		const specialTypes = editor.specialTypes;
		const rows = this.placeholderRows();
		const unmapped = unmappedPlaceholders(rows);
		const unknownTypes = unknownCodes(specialTypes, this.typeOptions());
		const unknownUnits = unknownCodes(editor.tradeUnits, this.tradeUnitOptions());
		const local = {
			...editor.name.trim() === "" ? { name: ["A template needs a name."] } : {},
			...specialTypes.length === 0 ? { specialTypes: ["A template serves at least one special type."] } : unknownTypes.length > 0 ? { specialTypes: [unknownTypesMessage(unknownTypes)] } : {},
			...unknownUnits.length > 0 ? { tradeUnits: [unknownTradeUnitsMessage(unknownUnits)] } : {},
			...unmapped.length > 0 ? { fields: [unmappedPlaceholdersMessage(unmapped)] } : {}
		};
		this.anchorProblems.set(problems);
		this.fieldErrors.set(local);
		this.clearOutcome();
		if (problems.length > 0 || Object.keys(local).length > 0) {
			this.outcome.set(mutationRefused("Template not saved. The reasons are beside the fields."));
			return;
		}
		const draft = {
			name: editor.name.trim(),
			specialTypes,
			language: editor.language.trim() === "" ? DEFAULT_ADDENDUM_LANGUAGE : editor.language.trim(),
			tradeUnits: editor.tradeUnits,
			templateContent,
			contentFormat: editor.contentFormat,
			fields: fieldsOf$1(rows),
			active: editor.active,
			initialsAnchorOptional
		};
		this.run(editor.id === null || editor.rowVersion === null ? source.create(draft) : source.update(editor.id, editor.rowVersion, draft), `Template "${draft.name}" ${editor.id === null ? "created" : "saved"}.`, () => this.cancelEdit());
	}
	deactivate(template) {
		const source = this.source;
		if (source !== null) this.run(source.deactivate(template), `Template "${template.name}" deactivated.`);
	}
	remove(template) {
		const source = this.source;
		if (source === null) return;
		this.confirm({
			title: "Delete this addendum template?",
			message: `"${template.name}" will be deleted and can no longer be used to generate an addendum. Deactivate it instead to keep it and its history.`,
			confirmLabel: "Delete template",
			cancelLabel: "Keep template",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) this.run(source.remove(template), `Template "${template.name}" deleted.`);
		});
	}
	tradeUnitsLabel(template) {
		return template.tradeUnits.length === 0 ? "All" : template.tradeUnits.join(", ");
	}
	setCodes(field, codes) {
		const editor = this.editor();
		if (editor !== null) this.editor.set({
			...editor,
			[field]: [...codes]
		});
	}
	open(editor, content, mappings, initialsAnchorOptional) {
		this.loadTypes();
		this.loadConstraints();
		this.editor.set(editor);
		this.content.set(content);
		this.mappings.set(mappings);
		this.initialsOptional.set(initialsAnchorOptional);
		this.previewOpen.set(false);
		this.anchorProblems.set([]);
		this.fieldErrors.set({});
		this.clearOutcome();
	}
	run(request, success, onDone) {
		this.busy.set(true);
		this.clearOutcome();
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.busy.set(false);
			switch (answer.kind) {
				case "done":
					onDone?.();
					this.outcome.set(mutationSucceeded(success));
					this.load();
					break;
				case "unavailable":
					this.outcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "conflict":
					this.outcome.set(mutationFailed(answer));
					this.reloadOffered.set(true);
					break;
				case "failed": {
					const placed = {};
					const unplaced = [];
					for (const [key, reasons] of Object.entries(answer.fieldErrors ?? {})) if (EDITOR_FIELDS.includes(key)) placed[key] = reasons;
					else unplaced.push(...reasons);
					this.fieldErrors.set(placed);
					this.outcome.set(mutationFailed({
						message: Object.keys(placed).length === 0 || unplaced.length === 0 ? answer.message : unplaced.join(" "),
						correlationId: answer.correlationId
					}));
					break;
				}
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AddendumTemplatesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AddendumTemplatesPageComponent,
		isStandalone: true,
		selector: "cws-addendum-templates-page",
		inputs: { view: {
			classPropertyName: "view",
			publicName: "view",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <!--\n    #825: the Addendums page of the Admin section, with Templates and Types as its tabs. Mounted on its\n    own (view \"all\") it shows both, types first, as the old single page did.\n  -->\n  <cms-page-header\n    title=\"Addendums\"\n    description=\"The documents generated for the in-house addendums (minimum price with a call, min/max and premium advance), and the addendum types a contract can carry.\"\n  >\n    @if (showTemplates() && offered && state().status === 'loaded' && editor() === null) {\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\" (click)=\"startCreate()\">\n        New template\n      </button>\n    }\n  </cms-page-header>\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Addendum views\" />\n  }\n\n  @if (writesRefused(); as reason) {\n    <!-- #696: the template writes are Admin-only on the server, so a settings holder reads them here. -->\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-templates-admin-only>\n      {{ reason }}. You can view templates; changing them is for an administrator.\n    </p>\n  }\n\n  @if (showTypes()) {\n    <!-- #676, #798: the addendum types, above the templates that serve them. Absent without a type source. -->\n    <cws-addendum-types-section />\n  }\n\n  @if (showTemplates()) {\n  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Templates</h3>\n\n  <!-- Kept visible: a template that breaks it is refused on save. -->\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n    Used exactly as Legal approved them. Every template must carry the signature, date and initials\n    anchors the signing service looks for; the initials anchor only when the text has an initials line.\n  </p>\n\n  <!--\n    #803: the last template write's outcome, with the server's reference on a failure. A 409 is the\n    row changed since it was read: in the server's words, with Reload, and never retried.\n  -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\n    @if (reloadOffered()) {\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\n    }\n  </cms-status-message>\n\n  @if (!offered) {\n    <!-- A host that embeds the admin screen without the template seam. Said, not left blank. -->\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-not-offered\">\n      Addendum templates are not offered here.\n    </p>\n  } @else {\n    @switch (state().status) {\n      @case ('loading') {\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading templates…</p>\n      }\n      @case ('unavailable') {\n        <!--\n          🔴 The routes are wired before the backend publishes them. A 404 lands here and says so; an\n          empty table would read as \"no templates exist\", which a missing route cannot claim.\n        -->\n        <div class=\"scoular-alert scoular-alert-info\" data-testid=\"templates-unavailable\">\n          <div class=\"scoular-alert-title\">Not available yet</div>\n          <div class=\"scoular-alert-description\">{{ unavailableReason() }}</div>\n        </div>\n      }\n      @case ('failed') {\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\n          {{ failure()?.message }}\n          @if (failure()?.correlationId; as id) {\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\n          }\n        </p>\n      }\n      @case ('loaded') {\n        @if (templates().length === 0) {\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-empty\">\n            No addendum templates yet.\n          </p>\n        } @else {\n          <table class=\"cws:w-full cws:text-left cws:text-xs\">\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n              <tr>\n                <th class=\"cws:py-1\">Name</th>\n                <th class=\"cws:py-1\">Special types</th>\n                <th class=\"cws:py-1\">Language</th>\n                <th class=\"cws:py-1\">Trade units</th>\n                <th class=\"cws:py-1\">Version</th>\n                <th class=\"cws:py-1\">Active</th>\n                <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\n              </tr>\n            </thead>\n            <tbody data-testid=\"templates-rows\">\n              @for (template of templates(); track template.id) {\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                  <td class=\"cws:py-1\">{{ template.name }}</td>\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.specialTypes.join(', ') }}</td>\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.language }}</td>\n                  <td class=\"cws:py-1\">{{ tradeUnitsLabel(template) }}</td>\n                  <td class=\"cws:py-1 cws:tabular-nums\">{{ template.version }}</td>\n                  <td class=\"cws:py-1\">{{ template.active ? 'Yes' : 'No' }}</td>\n                  <td class=\"cws:py-1 cws:text-right\">\n                    <!-- #825: Edit, Deactivate and Delete behind the row's menu. Delete still asks first. -->\n                    <cms-row-menu\n                      [row]=\"template\"\n                      [actions]=\"templateActions().get(template.id) ?? []\"\n                      [label]=\"'Actions for ' + template.name\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        }\n      }\n    }\n\n    @if (editor(); as draft) {\n      <form\n        class=\"cws:space-y-4 cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\"\n        aria-label=\"Addendum template\"\n        (ngSubmit)=\"save()\"\n      >\n        <h4 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n          @if (draft.id === null) { New template } @else { Edit template, version {{ draft.version }} }\n        </h4>\n\n        <!--\n          2026-10-29: one grid of equal fields, captions above their boxes, in place of a wrapping row of\n          hand-picked widths that put some captions beside their boxes and some above.\n        -->\n        <div class=\"cws:grid cws:grid-cols-1 cws:items-start cws:gap-x-4 cws:gap-y-3 cws:md:grid-cols-2 cws:xl:grid-cols-3\">\n          <!--\n            Each field's reasons sit OUTSIDE its label and are tied to it by aria-describedby: inside\n            the label they would become part of the field's accessible name.\n          -->\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Name</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"name\"\n                [(ngModel)]=\"draft.name\"\n                [attr.aria-invalid]=\"errorsFor('name').length > 0\"\n                aria-describedby=\"addendum-template-name-errors\"\n              />\n            </label>\n            <span id=\"addendum-template-name-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('name'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <!--\n            #814: picked from the addendum types, never typed. An unapproved type is still pickable, and\n            says so, because a template may be written before Legal approves the type.\n          -->\n          <div class=\"cws:space-y-1\">\n            <cws-admin-code-picker\n              label=\"Special types\"\n              name=\"specialTypes\"\n              [codes]=\"draft.specialTypes\"\n              [options]=\"typeOptions()\"\n              [unknownMessage]=\"unknownTypesMessage\"\n              searchPlaceholder=\"Type a special type\"\n              freePlaceholder=\"MNC, MNP\"\n              describedBy=\"addendum-template-specialTypes-errors\"\n              [invalid]=\"errorsFor('specialTypes').length > 0\"\n              (codesChange)=\"setCodes('specialTypes', $event)\"\n            />\n            <span id=\"addendum-template-specialTypes-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('specialTypes'); track reason) { {{ reason }} }\n            </span>\n            <!--\n              #924: a picked type that is not available, said here with its fix, so the template can be\n              made usable without visiting the Types tab. Make available asks first: it is Legal's approval.\n            -->\n            @if (unavailableTypes().length > 0) {\n              <ul class=\"cws:space-y-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" data-testid=\"types-not-available\">\n                @for (type of unavailableTypes(); track type.specialType) {\n                  <li>\n                    {{ typeNotAvailableMessage(type.specialType) }}\n                    @if (typeWritesOffered) {\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn scoular-btn-secondary cws:mt-1\"\n                        [disabled]=\"busy() || writesRefused() !== null\"\n                        [attr.title]=\"writesRefused()\"\n                        (click)=\"makeAvailable(type)\"\n                      >\n                        Make {{ type.specialType }} available\n                      </button>\n                    }\n                  </li>\n                }\n              </ul>\n            }\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Language</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"language\"\n                [(ngModel)]=\"draft.language\"\n                [attr.aria-invalid]=\"errorsFor('language').length > 0\"\n                aria-describedby=\"addendum-template-language-errors\"\n              />\n            </label>\n            <span id=\"addendum-template-language-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('language'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Content format</span>\n              <!-- #1115: full width, so `text/x-cws-addendum` shows whole. -->\n              <select\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"contentFormat\"\n                [(ngModel)]=\"draft.contentFormat\"\n                [attr.aria-invalid]=\"errorsFor('contentFormat').length > 0\"\n                aria-describedby=\"addendum-template-contentFormat-errors\"\n              >\n                @for (format of contentFormats; track format) {\n                  <option [value]=\"format\">{{ format }}</option>\n                }\n              </select>\n            </label>\n            <span id=\"addendum-template-contentFormat-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('contentFormat'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <!-- #814: picked from CTRM's locations, with typeahead: live CTRM has over a thousand. -->\n          <div class=\"cws:space-y-1\">\n            <cws-admin-code-picker\n              label=\"Trade units\"\n              name=\"tradeUnits\"\n              [codes]=\"draft.tradeUnits\"\n              [options]=\"tradeUnitOptions()\"\n              [unknownMessage]=\"unknownTradeUnitsMessage\"\n              emptyMeaning=\"None picked: the template serves every trade unit.\"\n              [note]=\"tradeUnitNote()\"\n              searchPlaceholder=\"Type a location code or name\"\n              freePlaceholder=\"Blank for all, or 0210, 2087\"\n              describedBy=\"addendum-template-tradeUnits-errors\"\n              [invalid]=\"errorsFor('tradeUnits').length > 0\"\n              (codesChange)=\"setCodes('tradeUnits', $event)\"\n            />\n            <span id=\"addendum-template-tradeUnits-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('tradeUnits'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <!-- A caption like its neighbours', and the box at input height, so it lines up with them. -->\n          <div>\n            <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\" aria-hidden=\"true\">Status</span>\n            <label class=\"cws:mt-1 cws:flex cws:min-h-10 cws:items-center cws:gap-2 cws:text-sm\">\n              <input type=\"checkbox\" name=\"active\" [(ngModel)]=\"draft.active\" />\n              Active\n            </label>\n          </div>\n        </div>\n\n        <label class=\"cws:block\">\n          <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template content</span>\n          <textarea\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\n            rows=\"12\"\n            name=\"templateContent\"\n            [ngModel]=\"content()\"\n            (ngModelChange)=\"content.set($event)\"\n            [attr.aria-invalid]=\"contentProblems().length > 0\"\n            aria-describedby=\"addendum-template-anchors\"\n          ></textarea>\n        </label>\n\n        <!--\n          #1115: the markup's grammar, beside the box it is typed in. A literal tab is kept as typed or\n          pasted (label and value pairs are tab-separated) and the box is monospace, so `@table`,\n          `@row` and `@cell` line up. Tab itself still moves focus, so a keyboard user is never trapped.\n          The URL is the host's (`CwsExternalLinks.addendumMarkupReference`); none configured, no link.\n        -->\n        @if (markupReferenceUrl; as markupUrl) {\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            <a\n              class=\"cws:rounded cws:text-scoular-blue cws:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\n              [href]=\"markupUrl\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >Markup authoring reference<span class=\"sr-only\"> (opens in a new tab)</span></a>\n            for <code class=\"cws:font-mono\">text/x-cws-addendum</code>: the <code class=\"cws:font-mono\">{{ '@cws 1' }}</code>\n            first line, the directives, and the <code class=\"cws:font-mono\">|date</code> and\n            <code class=\"cws:font-mono\">|number</code> print types.\n          </p>\n        }\n\n        <!--\n          🔴 Beside the content field, because that is where the fix goes. Each reason names the\n          anchor to add, so an administrator pasting in Legal's text knows what is missing rather than\n          being told only that something is. A server refusal of the content lands here too.\n        -->\n        <div id=\"addendum-template-anchors\" class=\"cws:space-y-1 cws:text-xs\">\n          @if (contentProblems().length > 0) {\n            <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"anchor-problems\">\n              @for (problem of contentProblems(); track problem) {\n                <li>{{ problem }}</li>\n              }\n            </ul>\n          }\n          <!--\n            #924: each required anchor, ticked off as it is typed, so a missing one is seen while pasting\n            Legal's text rather than on Save. Save still refuses a missing one (above).\n          -->\n          <ul class=\"cws:flex cws:flex-wrap cws:gap-x-4 cws:gap-y-1\" aria-label=\"Required anchors\" data-testid=\"anchor-checklist\">\n            @for (check of anchorChecks(); track check.anchor) {\n              <li\n                [class.cws:text-emerald-700]=\"check.present\"\n                [class.cws:dark:text-emerald-300]=\"check.present\"\n                [class.cws:text-slate-500]=\"!check.present\"\n                [class.cws:dark:text-slate-400]=\"!check.present\"\n                [attr.data-present]=\"check.present\"\n                [attr.data-required]=\"check.required\"\n              >\n                <span aria-hidden=\"true\">{{ check.present ? '✓' : check.required ? '○' : '–' }}</span>\n                <code class=\"cws:font-mono\">{{ check.anchor }}</code>\n                @if (check.required) {\n                  <span class=\"cws:sr-only\">{{ check.present ? 'present' : 'missing' }}</span>\n                } @else {\n                  <span class=\"cws:ml-1\" data-testid=\"anchor-not-required\">(not required: this text has no initials line)</span>\n                }\n              </li>\n            }\n          </ul>\n          <!--\n            #1038: the template's initialsAnchorOptional. Only the initials anchor is waived, as on the\n            server; the signature and date anchors stay required.\n          -->\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-1\">\n            <input\n              type=\"checkbox\"\n              name=\"initialsAnchorOptional\"\n              [ngModel]=\"initialsOptional()\"\n              (ngModelChange)=\"initialsOptional.set($event)\"\n            />\n            This text has no initials line\n          </label>\n        </div>\n\n        <!-- #924: the placeholders, read from the content, each with a field picker. Replaces the free-text box. -->\n        <cws-addendum-placeholder-fields\n          [rows]=\"placeholderRows()\"\n          [groups]=\"fieldGroups()\"\n          [ctrmListed]=\"ctrmListed()\"\n          [invalid]=\"errorsFor('fields').length > 0 || unmapped().length > 0\"\n          describedBy=\"addendum-template-fields-errors\"\n          (fieldChange)=\"setField($event)\"\n          (removed)=\"removeMapping($event)\"\n        />\n        <ul id=\"addendum-template-fields-errors\" class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n          @for (reason of errorsFor('fields'); track reason) {\n            <li>{{ reason }}</li>\n          }\n        </ul>\n\n        @if (previewOpen()) {\n          <!--\n            #924: the draft's text with sample values, before anything is saved. The server previews a\n            SAVED template only, from a contract, as the PDF; this is the text that PDF would carry.\n          -->\n          <section class=\"cws:space-y-1\" aria-label=\"Template preview\" data-testid=\"template-preview\">\n            <h5 class=\"cws:text-xs cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview, with sample values</h5>\n            <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              Sample values only: a text field shows its own name in brackets. The document is the PDF the\n              server lays out from this text; to see it, save the template and preview from a contract.\n            </p>\n            <pre class=\"cws:max-h-96 cws:overflow-auto cws:whitespace-pre-wrap cws:rounded cws:border cws:border-slate-200 cws:bg-slate-50 cws:p-3 cws:font-mono cws:text-xs cws:dark:border-slate-700 cws:dark:bg-slate-900\">@for (segment of preview(); track $index) {@switch (segment.kind) {@case ('value') {<mark class=\"cws:bg-sky-100 cws:dark:bg-sky-900\" data-testid=\"preview-value\">{{ segment.text }}</mark>}@case ('missing') {<mark class=\"cws:bg-rose-100 cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" data-testid=\"preview-missing\">{{ segment.text }}</mark>}@default {<span>{{ segment.text }}</span>}}}</pre>\n          </section>\n        }\n\n        <div class=\"cws:flex cws:gap-2\">\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\n            {{ busy() ? 'Saving…' : 'Save template' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [attr.aria-pressed]=\"previewOpen()\" (click)=\"togglePreview()\">\n            {{ previewOpen() ? 'Hide preview' : 'Preview' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\n        </div>\n      </form>\n    }\n  }\n  }\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: AddendumPlaceholderFieldsComponent,
				selector: "cws-addendum-placeholder-fields",
				inputs: [
					"rows",
					"groups",
					"ctrmListed",
					"describedBy",
					"invalid",
					"disabled"
				],
				outputs: ["fieldChange", "removed"]
			},
			{
				kind: "component",
				type: AddendumTypesSectionComponent,
				selector: "cws-addendum-types-section"
			},
			{
				kind: "component",
				type: AdminCodePickerComponent,
				selector: "cws-admin-code-picker",
				inputs: [
					"label",
					"name",
					"codes",
					"options",
					"unknownMessage",
					"emptyMeaning",
					"note",
					"searchPlaceholder",
					"freePlaceholder",
					"describedBy",
					"invalid",
					"disabled"
				],
				outputs: ["codesChange"]
			},
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AddendumTemplatesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-addendum-templates-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AddendumPlaceholderFieldsComponent,
				AddendumTypesSectionComponent,
				AdminCodePickerComponent,
				AdminTabsComponent,
				FormsModule,
				PageHeaderComponent,
				RowMenuComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-4\">\n  <!--\n    #825: the Addendums page of the Admin section, with Templates and Types as its tabs. Mounted on its\n    own (view \"all\") it shows both, types first, as the old single page did.\n  -->\n  <cms-page-header\n    title=\"Addendums\"\n    description=\"The documents generated for the in-house addendums (minimum price with a call, min/max and premium advance), and the addendum types a contract can carry.\"\n  >\n    @if (showTemplates() && offered && state().status === 'loaded' && editor() === null) {\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\" (click)=\"startCreate()\">\n        New template\n      </button>\n    }\n  </cms-page-header>\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Addendum views\" />\n  }\n\n  @if (writesRefused(); as reason) {\n    <!-- #696: the template writes are Admin-only on the server, so a settings holder reads them here. -->\n    <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"note\" data-templates-admin-only>\n      {{ reason }}. You can view templates; changing them is for an administrator.\n    </p>\n  }\n\n  @if (showTypes()) {\n    <!-- #676, #798: the addendum types, above the templates that serve them. Absent without a type source. -->\n    <cws-addendum-types-section />\n  }\n\n  @if (showTemplates()) {\n  <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Templates</h3>\n\n  <!-- Kept visible: a template that breaks it is refused on save. -->\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n    Used exactly as Legal approved them. Every template must carry the signature, date and initials\n    anchors the signing service looks for; the initials anchor only when the text has an initials line.\n  </p>\n\n  <!--\n    #803: the last template write's outcome, with the server's reference on a failure. A 409 is the\n    row changed since it was read: in the server's words, with Reload, and never retried.\n  -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"clearOutcome()\">\n    @if (reloadOffered()) {\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\n    }\n  </cms-status-message>\n\n  @if (!offered) {\n    <!-- A host that embeds the admin screen without the template seam. Said, not left blank. -->\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-not-offered\">\n      Addendum templates are not offered here.\n    </p>\n  } @else {\n    @switch (state().status) {\n      @case ('loading') {\n        <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading templates…</p>\n      }\n      @case ('unavailable') {\n        <!--\n          🔴 The routes are wired before the backend publishes them. A 404 lands here and says so; an\n          empty table would read as \"no templates exist\", which a missing route cannot claim.\n        -->\n        <div class=\"scoular-alert scoular-alert-info\" data-testid=\"templates-unavailable\">\n          <div class=\"scoular-alert-title\">Not available yet</div>\n          <div class=\"scoular-alert-description\">{{ unavailableReason() }}</div>\n        </div>\n      }\n      @case ('failed') {\n        <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\n          {{ failure()?.message }}\n          @if (failure()?.correlationId; as id) {\n            <span class=\"cws:block cws:font-mono\">Reference: {{ id }}</span>\n          }\n        </p>\n      }\n      @case ('loaded') {\n        @if (templates().length === 0) {\n          <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"templates-empty\">\n            No addendum templates yet.\n          </p>\n        } @else {\n          <table class=\"cws:w-full cws:text-left cws:text-xs\">\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n              <tr>\n                <th class=\"cws:py-1\">Name</th>\n                <th class=\"cws:py-1\">Special types</th>\n                <th class=\"cws:py-1\">Language</th>\n                <th class=\"cws:py-1\">Trade units</th>\n                <th class=\"cws:py-1\">Version</th>\n                <th class=\"cws:py-1\">Active</th>\n                <th class=\"cws:py-1\" aria-label=\"Actions\"></th>\n              </tr>\n            </thead>\n            <tbody data-testid=\"templates-rows\">\n              @for (template of templates(); track template.id) {\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                  <td class=\"cws:py-1\">{{ template.name }}</td>\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.specialTypes.join(', ') }}</td>\n                  <td class=\"cws:py-1 cws:font-mono\">{{ template.language }}</td>\n                  <td class=\"cws:py-1\">{{ tradeUnitsLabel(template) }}</td>\n                  <td class=\"cws:py-1 cws:tabular-nums\">{{ template.version }}</td>\n                  <td class=\"cws:py-1\">{{ template.active ? 'Yes' : 'No' }}</td>\n                  <td class=\"cws:py-1 cws:text-right\">\n                    <!-- #825: Edit, Deactivate and Delete behind the row's menu. Delete still asks first. -->\n                    <cms-row-menu\n                      [row]=\"template\"\n                      [actions]=\"templateActions().get(template.id) ?? []\"\n                      [label]=\"'Actions for ' + template.name\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        }\n      }\n    }\n\n    @if (editor(); as draft) {\n      <form\n        class=\"cws:space-y-4 cws:rounded cws:border cws:border-slate-200 cws:p-4 cws:dark:border-slate-700\"\n        aria-label=\"Addendum template\"\n        (ngSubmit)=\"save()\"\n      >\n        <h4 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n          @if (draft.id === null) { New template } @else { Edit template, version {{ draft.version }} }\n        </h4>\n\n        <!--\n          2026-10-29: one grid of equal fields, captions above their boxes, in place of a wrapping row of\n          hand-picked widths that put some captions beside their boxes and some above.\n        -->\n        <div class=\"cws:grid cws:grid-cols-1 cws:items-start cws:gap-x-4 cws:gap-y-3 cws:md:grid-cols-2 cws:xl:grid-cols-3\">\n          <!--\n            Each field's reasons sit OUTSIDE its label and are tied to it by aria-describedby: inside\n            the label they would become part of the field's accessible name.\n          -->\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Name</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"name\"\n                [(ngModel)]=\"draft.name\"\n                [attr.aria-invalid]=\"errorsFor('name').length > 0\"\n                aria-describedby=\"addendum-template-name-errors\"\n              />\n            </label>\n            <span id=\"addendum-template-name-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('name'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <!--\n            #814: picked from the addendum types, never typed. An unapproved type is still pickable, and\n            says so, because a template may be written before Legal approves the type.\n          -->\n          <div class=\"cws:space-y-1\">\n            <cws-admin-code-picker\n              label=\"Special types\"\n              name=\"specialTypes\"\n              [codes]=\"draft.specialTypes\"\n              [options]=\"typeOptions()\"\n              [unknownMessage]=\"unknownTypesMessage\"\n              searchPlaceholder=\"Type a special type\"\n              freePlaceholder=\"MNC, MNP\"\n              describedBy=\"addendum-template-specialTypes-errors\"\n              [invalid]=\"errorsFor('specialTypes').length > 0\"\n              (codesChange)=\"setCodes('specialTypes', $event)\"\n            />\n            <span id=\"addendum-template-specialTypes-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('specialTypes'); track reason) { {{ reason }} }\n            </span>\n            <!--\n              #924: a picked type that is not available, said here with its fix, so the template can be\n              made usable without visiting the Types tab. Make available asks first: it is Legal's approval.\n            -->\n            @if (unavailableTypes().length > 0) {\n              <ul class=\"cws:space-y-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" data-testid=\"types-not-available\">\n                @for (type of unavailableTypes(); track type.specialType) {\n                  <li>\n                    {{ typeNotAvailableMessage(type.specialType) }}\n                    @if (typeWritesOffered) {\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn scoular-btn-secondary cws:mt-1\"\n                        [disabled]=\"busy() || writesRefused() !== null\"\n                        [attr.title]=\"writesRefused()\"\n                        (click)=\"makeAvailable(type)\"\n                      >\n                        Make {{ type.specialType }} available\n                      </button>\n                    }\n                  </li>\n                }\n              </ul>\n            }\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Language</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"language\"\n                [(ngModel)]=\"draft.language\"\n                [attr.aria-invalid]=\"errorsFor('language').length > 0\"\n                aria-describedby=\"addendum-template-language-errors\"\n              />\n            </label>\n            <span id=\"addendum-template-language-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('language'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <div class=\"cws:space-y-1\">\n            <label class=\"cws:block\">\n              <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Content format</span>\n              <!-- #1115: full width, so `text/x-cws-addendum` shows whole. -->\n              <select\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"contentFormat\"\n                [(ngModel)]=\"draft.contentFormat\"\n                [attr.aria-invalid]=\"errorsFor('contentFormat').length > 0\"\n                aria-describedby=\"addendum-template-contentFormat-errors\"\n              >\n                @for (format of contentFormats; track format) {\n                  <option [value]=\"format\">{{ format }}</option>\n                }\n              </select>\n            </label>\n            <span id=\"addendum-template-contentFormat-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('contentFormat'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <!-- #814: picked from CTRM's locations, with typeahead: live CTRM has over a thousand. -->\n          <div class=\"cws:space-y-1\">\n            <cws-admin-code-picker\n              label=\"Trade units\"\n              name=\"tradeUnits\"\n              [codes]=\"draft.tradeUnits\"\n              [options]=\"tradeUnitOptions()\"\n              [unknownMessage]=\"unknownTradeUnitsMessage\"\n              emptyMeaning=\"None picked: the template serves every trade unit.\"\n              [note]=\"tradeUnitNote()\"\n              searchPlaceholder=\"Type a location code or name\"\n              freePlaceholder=\"Blank for all, or 0210, 2087\"\n              describedBy=\"addendum-template-tradeUnits-errors\"\n              [invalid]=\"errorsFor('tradeUnits').length > 0\"\n              (codesChange)=\"setCodes('tradeUnits', $event)\"\n            />\n            <span id=\"addendum-template-tradeUnits-errors\" class=\"cws:block cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              @for (reason of errorsFor('tradeUnits'); track reason) { {{ reason }} }\n            </span>\n          </div>\n          <!-- A caption like its neighbours', and the box at input height, so it lines up with them. -->\n          <div>\n            <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\" aria-hidden=\"true\">Status</span>\n            <label class=\"cws:mt-1 cws:flex cws:min-h-10 cws:items-center cws:gap-2 cws:text-sm\">\n              <input type=\"checkbox\" name=\"active\" [(ngModel)]=\"draft.active\" />\n              Active\n            </label>\n          </div>\n        </div>\n\n        <label class=\"cws:block\">\n          <span class=\"cws:block cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Template content</span>\n          <textarea\n            class=\"scoular-form-input cws:mt-1 cws:w-full cws:font-mono cws:text-xs\"\n            rows=\"12\"\n            name=\"templateContent\"\n            [ngModel]=\"content()\"\n            (ngModelChange)=\"content.set($event)\"\n            [attr.aria-invalid]=\"contentProblems().length > 0\"\n            aria-describedby=\"addendum-template-anchors\"\n          ></textarea>\n        </label>\n\n        <!--\n          #1115: the markup's grammar, beside the box it is typed in. A literal tab is kept as typed or\n          pasted (label and value pairs are tab-separated) and the box is monospace, so `@table`,\n          `@row` and `@cell` line up. Tab itself still moves focus, so a keyboard user is never trapped.\n          The URL is the host's (`CwsExternalLinks.addendumMarkupReference`); none configured, no link.\n        -->\n        @if (markupReferenceUrl; as markupUrl) {\n          <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            <a\n              class=\"cws:rounded cws:text-scoular-blue cws:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\n              [href]=\"markupUrl\"\n              target=\"_blank\"\n              rel=\"noopener noreferrer\"\n            >Markup authoring reference<span class=\"sr-only\"> (opens in a new tab)</span></a>\n            for <code class=\"cws:font-mono\">text/x-cws-addendum</code>: the <code class=\"cws:font-mono\">{{ '@cws 1' }}</code>\n            first line, the directives, and the <code class=\"cws:font-mono\">|date</code> and\n            <code class=\"cws:font-mono\">|number</code> print types.\n          </p>\n        }\n\n        <!--\n          🔴 Beside the content field, because that is where the fix goes. Each reason names the\n          anchor to add, so an administrator pasting in Legal's text knows what is missing rather than\n          being told only that something is. A server refusal of the content lands here too.\n        -->\n        <div id=\"addendum-template-anchors\" class=\"cws:space-y-1 cws:text-xs\">\n          @if (contentProblems().length > 0) {\n            <ul class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"anchor-problems\">\n              @for (problem of contentProblems(); track problem) {\n                <li>{{ problem }}</li>\n              }\n            </ul>\n          }\n          <!--\n            #924: each required anchor, ticked off as it is typed, so a missing one is seen while pasting\n            Legal's text rather than on Save. Save still refuses a missing one (above).\n          -->\n          <ul class=\"cws:flex cws:flex-wrap cws:gap-x-4 cws:gap-y-1\" aria-label=\"Required anchors\" data-testid=\"anchor-checklist\">\n            @for (check of anchorChecks(); track check.anchor) {\n              <li\n                [class.cws:text-emerald-700]=\"check.present\"\n                [class.cws:dark:text-emerald-300]=\"check.present\"\n                [class.cws:text-slate-500]=\"!check.present\"\n                [class.cws:dark:text-slate-400]=\"!check.present\"\n                [attr.data-present]=\"check.present\"\n                [attr.data-required]=\"check.required\"\n              >\n                <span aria-hidden=\"true\">{{ check.present ? '✓' : check.required ? '○' : '–' }}</span>\n                <code class=\"cws:font-mono\">{{ check.anchor }}</code>\n                @if (check.required) {\n                  <span class=\"cws:sr-only\">{{ check.present ? 'present' : 'missing' }}</span>\n                } @else {\n                  <span class=\"cws:ml-1\" data-testid=\"anchor-not-required\">(not required: this text has no initials line)</span>\n                }\n              </li>\n            }\n          </ul>\n          <!--\n            #1038: the template's initialsAnchorOptional. Only the initials anchor is waived, as on the\n            server; the signature and date anchors stay required.\n          -->\n          <label class=\"cws:flex cws:items-center cws:gap-2 cws:pt-1\">\n            <input\n              type=\"checkbox\"\n              name=\"initialsAnchorOptional\"\n              [ngModel]=\"initialsOptional()\"\n              (ngModelChange)=\"initialsOptional.set($event)\"\n            />\n            This text has no initials line\n          </label>\n        </div>\n\n        <!-- #924: the placeholders, read from the content, each with a field picker. Replaces the free-text box. -->\n        <cws-addendum-placeholder-fields\n          [rows]=\"placeholderRows()\"\n          [groups]=\"fieldGroups()\"\n          [ctrmListed]=\"ctrmListed()\"\n          [invalid]=\"errorsFor('fields').length > 0 || unmapped().length > 0\"\n          describedBy=\"addendum-template-fields-errors\"\n          (fieldChange)=\"setField($event)\"\n          (removed)=\"removeMapping($event)\"\n        />\n        <ul id=\"addendum-template-fields-errors\" class=\"cws:list-disc cws:space-y-1 cws:pl-5 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n          @for (reason of errorsFor('fields'); track reason) {\n            <li>{{ reason }}</li>\n          }\n        </ul>\n\n        @if (previewOpen()) {\n          <!--\n            #924: the draft's text with sample values, before anything is saved. The server previews a\n            SAVED template only, from a contract, as the PDF; this is the text that PDF would carry.\n          -->\n          <section class=\"cws:space-y-1\" aria-label=\"Template preview\" data-testid=\"template-preview\">\n            <h5 class=\"cws:text-xs cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview, with sample values</h5>\n            <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n              Sample values only: a text field shows its own name in brackets. The document is the PDF the\n              server lays out from this text; to see it, save the template and preview from a contract.\n            </p>\n            <pre class=\"cws:max-h-96 cws:overflow-auto cws:whitespace-pre-wrap cws:rounded cws:border cws:border-slate-200 cws:bg-slate-50 cws:p-3 cws:font-mono cws:text-xs cws:dark:border-slate-700 cws:dark:bg-slate-900\">@for (segment of preview(); track $index) {@switch (segment.kind) {@case ('value') {<mark class=\"cws:bg-sky-100 cws:dark:bg-sky-900\" data-testid=\"preview-value\">{{ segment.text }}</mark>}@case ('missing') {<mark class=\"cws:bg-rose-100 cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" data-testid=\"preview-missing\">{{ segment.text }}</mark>}@default {<span>{{ segment.text }}</span>}}}</pre>\n          </section>\n        }\n\n        <div class=\"cws:flex cws:gap-2\">\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy() || writesRefused() !== null\" [attr.title]=\"writesRefused()\">\n            {{ busy() ? 'Saving…' : 'Save template' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [attr.aria-pressed]=\"previewOpen()\" (click)=\"togglePreview()\">\n            {{ previewOpen() ? 'Hide preview' : 'Preview' }}\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelEdit()\">Cancel</button>\n        </div>\n      </form>\n    }\n  }\n  }\n</section>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { view: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "view",
			required: false
		}]
	}] }
});
function listStateOf(answer) {
	switch (answer.kind) {
		case "done": return { status: "loaded" };
		case "unavailable": return {
			status: "unavailable",
			reason: answer.reason
		};
		default: return {
			status: "failed",
			message: answer.message,
			...answer.correlationId === void 0 ? {} : { correlationId: answer.correlationId }
		};
	}
}
var AdminOverviewComponent = class AdminOverviewComponent {
	access = inject(AdminScope);
	areas = computed(() => ADMIN_AREAS.filter((area) => !area.adminOnly || !this.access.knownNotAdmin()), ...ngDevMode ? [{ debugName: "areas" }] : /* istanbul ignore next */ []);
	viewList(views) {
		return views.map((view) => view.label).join(" · ");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminOverviewComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AdminOverviewComponent,
		isStandalone: true,
		selector: "cws-admin-overview",
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <section class="cws:space-y-6">
      <cms-page-header
        title="Admin"
        description="Configuration for Contract Workspace: how contracts are entered, what each trade unit offers, addendums, and who may do what."
      />

      <ul class="cws:grid cws:gap-4 cws:md:grid-cols-2" aria-label="Admin areas">
        @for (area of areas(); track area.path) {
          <li class="scoular-card cws:flex cws:flex-col cws:gap-2 cws:p-4">
            <h3 class="cws:text-base cws:font-semibold">
              <a
                class="cws:text-scoular-blue cws:hover:underline cws:dark:text-sky-400"
                [routerLink]="[area.path]"
                >{{ area.title }}</a
              >
            </h3>
            <p class="cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">{{ area.summary }}</p>
            @if (area.views.length > 0) {
              <p class="cws:mt-auto cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                {{ viewList(area.views) }}
              </p>
            }
          </li>
        }
      </ul>

      <p class="cws:text-sm cws:text-slate-500 cws:dark:text-slate-400">
        Still to come: contract templates, and the agreed permission set that roles are built from.
      </p>
    </section>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: PageHeaderComponent,
			selector: "cms-page-header",
			inputs: ["title", "description"]
		}, {
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AdminOverviewComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-overview",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [PageHeaderComponent, RouterLink],
			host: { class: "cws:block" },
			template: `
    <section class="cws:space-y-6">
      <cms-page-header
        title="Admin"
        description="Configuration for Contract Workspace: how contracts are entered, what each trade unit offers, addendums, and who may do what."
      />

      <ul class="cws:grid cws:gap-4 cws:md:grid-cols-2" aria-label="Admin areas">
        @for (area of areas(); track area.path) {
          <li class="scoular-card cws:flex cws:flex-col cws:gap-2 cws:p-4">
            <h3 class="cws:text-base cws:font-semibold">
              <a
                class="cws:text-scoular-blue cws:hover:underline cws:dark:text-sky-400"
                [routerLink]="[area.path]"
                >{{ area.title }}</a
              >
            </h3>
            <p class="cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">{{ area.summary }}</p>
            @if (area.views.length > 0) {
              <p class="cws:mt-auto cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                {{ viewList(area.views) }}
              </p>
            }
          </li>
        }
      </ul>

      <p class="cws:text-sm cws:text-slate-500 cws:dark:text-slate-400">
        Still to come: contract templates, and the agreed permission set that roles are built from.
      </p>
    </section>
  `
		}]
	}]
});
const ANY_CODE = "*";
let nextId = 0;
var AdminTradeUnitSelectComponent = class AdminTradeUnitSelectComponent {
	access = inject(AdminScope);
	id = `cws-admin-tu-${nextId++}`;
	label = input("Trade unit", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	value = input("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	allowAny = input(false, ...ngDevMode ? [{ debugName: "allowAny" }] : /* istanbul ignore next */ []);
	everyLocation = input(false, ...ngDevMode ? [{ debugName: "everyLocation" }] : /* istanbul ignore next */ []);
	valueChange = output();
	mode = computed(() => {
		if (this.everyLocation()) return this.access.locations() === null ? "free" : "all";
		if (this.access.knownNotAdmin() && !this.access.scope().everyTradeUnit) return "held";
		return this.access.locations() === null ? "free" : "all";
	}, ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	offerAny = computed(() => this.allowAny() && this.mode() === "all", ...ngDevMode ? [{ debugName: "offerAny" }] : /* istanbul ignore next */ []);
	anyLabel = computed(() => this.access.scope().everyTradeUnit ? "Any trade unit (every trade unit)" : "Any trade unit (Admin only)", ...ngDevMode ? [{ debugName: "anyLabel" }] : /* istanbul ignore next */ []);
	options = computed(() => {
		const scope = this.access.scope();
		if (this.mode() === "held") return scope.tradeUnits.map((code) => {
			const name = this.access.nameOf(code);
			return {
				code,
				label: name === null ? code : `${code} · ${name}`,
				description: name ?? code
			};
		});
		const onboarded = new Set(scope.onboarded);
		return [...this.access.locations() ?? []].sort((left, right) => left.code.localeCompare(right.code)).map((location) => {
			const marker = scope.known ? onboarded.has(location.code) ? " · onboarded" : " · not onboarded" : "";
			return {
				code: location.code,
				label: `${location.code}${location.name === null ? "" : ` · ${location.name}`}${marker}`,
				description: `${location.name ?? location.code}${marker}`
			};
		});
	}, ...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	comboOptions = computed(() => [...this.offerAny() ? [{
		code: ANY_CODE,
		description: this.anyLabel()
	}] : [], ...this.options().map((option) => ({
		code: option.code,
		description: option.description
	}))], ...ngDevMode ? [{ debugName: "comboOptions" }] : /* istanbul ignore next */ []);
	comboValue = computed(() => this.value() === "" && this.offerAny() ? ANY_CODE : this.value(), ...ngDevMode ? [{ debugName: "comboValue" }] : /* istanbul ignore next */ []);
	pick(code) {
		this.valueChange.emit(code === null || code === ANY_CODE ? "" : code);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AdminTradeUnitSelectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AdminTradeUnitSelectComponent,
		isStandalone: true,
		selector: "cws-admin-trade-unit-select",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowAny: {
				classPropertyName: "allowAny",
				publicName: "allowAny",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			everyLocation: {
				classPropertyName: "everyLocation",
				publicName: "everyLocation",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { valueChange: "valueChange" },
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: `
    <!--
      2026-10-30: the caption is the visible one; in list mode the combo carries the accessible name
      (hideLabel), so it is said once. In free mode the caption labels the text box as before.
    -->
    <label class="cws:block cws:space-y-1" [attr.for]="mode() === 'free' ? id : null">
      <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">{{ label() }}</span>
    </label>

    @switch (mode()) {
      @case ('free') {
        <input
          [id]="id"
          class="scoular-form-input cws:mt-1 cws:w-full"
          [attr.placeholder]="allowAny() ? 'Any' : 'e.g. 2087'"
          [value]="value()"
          (input)="valueChange.emit($any($event.target).value)"
        />
      }
      @default {
        <!--
          🔴 2026-10-30: ONE searchable box. The list modes were a "Filter by code or name" box above a
          select once there were more than 12 locations, so on live CTRM (a thousand-plus) the row stood
          taller than its neighbours, and nowhere else showed it (the simulator has 6). The combo filters
          by code and name as you type, and a closed set: half-typed text is discarded on leaving, so a
          typo cannot become the value.
        -->
        <cms-code-combo
          class="cws:mt-1 cws:block"
          [label]="label()"
          [controlId]="id"
          [hideLabel]="true"
          [options]="comboOptions()"
          [ngModel]="comboValue()"
          (ngModelChange)="pick($event)"
        />
        @if (mode() === 'held') {
          <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-held-note>
            The trade units where you manage settings.
          </p>
        }
      }
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: CodeComboComponent,
				selector: "cms-code-combo",
				inputs: [
					"label",
					"controlId",
					"options",
					"required",
					"requiredMarker",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"compact",
					"search",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage",
					"tone",
					"describedByExtra"
				]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AdminTradeUnitSelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-admin-trade-unit-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			imports: [CodeComboComponent, FormsModule],
			template: `
    <!--
      2026-10-30: the caption is the visible one; in list mode the combo carries the accessible name
      (hideLabel), so it is said once. In free mode the caption labels the text box as before.
    -->
    <label class="cws:block cws:space-y-1" [attr.for]="mode() === 'free' ? id : null">
      <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">{{ label() }}</span>
    </label>

    @switch (mode()) {
      @case ('free') {
        <input
          [id]="id"
          class="scoular-form-input cws:mt-1 cws:w-full"
          [attr.placeholder]="allowAny() ? 'Any' : 'e.g. 2087'"
          [value]="value()"
          (input)="valueChange.emit($any($event.target).value)"
        />
      }
      @default {
        <!--
          🔴 2026-10-30: ONE searchable box. The list modes were a "Filter by code or name" box above a
          select once there were more than 12 locations, so on live CTRM (a thousand-plus) the row stood
          taller than its neighbours, and nowhere else showed it (the simulator has 6). The combo filters
          by code and name as you type, and a closed set: half-typed text is discarded on leaving, so a
          typo cannot become the value.
        -->
        <cms-code-combo
          class="cws:mt-1 cws:block"
          [label]="label()"
          [controlId]="id"
          [hideLabel]="true"
          [options]="comboOptions()"
          [ngModel]="comboValue()"
          (ngModelChange)="pick($event)"
        />
        @if (mode() === 'held') {
          <p class="cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-held-note>
            The trade units where you manage settings.
          </p>
        }
      }
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		allowAny: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowAny",
				required: false
			}]
		}],
		everyLocation: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "everyLocation",
				required: false
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
var BasisLocationsPageComponent = class BasisLocationsPageComponent {
	source = inject(BASIS_LOCATION_ADMIN_SOURCE, { optional: true });
	view = input("all", {
		...ngDevMode ? { debugName: "view" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "all"
	});
	routed = computed(() => this.view() !== "all", ...ngDevMode ? [{ debugName: "routed" }] : /* istanbul ignore next */ []);
	area = adminArea("basis-locations");
	offered = this.source !== null;
	shows(view) {
		const current = this.view();
		return current === "all" || current === view;
	}
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	fieldErrors = signal({}, ...ngDevMode ? [{ debugName: "fieldErrors" }] : /* istanbul ignore next */ []);
	includeRetired = signal(false, ...ngDevMode ? [{ debugName: "includeRetired" }] : /* istanbul ignore next */ []);
	terms = signal(null, ...ngDevMode ? [{ debugName: "terms" }] : /* istanbul ignore next */ []);
	places = signal(null, ...ngDevMode ? [{ debugName: "places" }] : /* istanbul ignore next */ []);
	regions = signal(null, ...ngDevMode ? [{ debugName: "regions" }] : /* istanbul ignore next */ []);
	listError = signal(null, ...ngDevMode ? [{ debugName: "listError" }] : /* istanbul ignore next */ []);
	termCode = "";
	termPrintToken = "";
	termIncoTerms = "";
	placeCity = "";
	placeState = "";
	regionCode = "";
	regionPrintToken = "";
	regionStates = "";
	tradeUnit = signal("", ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	setting = signal(null, ...ngDevMode ? [{ debugName: "setting" }] : /* istanbul ignore next */ []);
	settingWarnings = signal([], ...ngDevMode ? [{ debugName: "settingWarnings" }] : /* istanbul ignore next */ []);
	placeRule = signal("CityStateOrRegion", ...ngDevMode ? [{ debugName: "placeRule" }] : /* istanbul ignore next */ []);
	legacyEdits = signal("Allow", ...ngDevMode ? [{ debugName: "legacyEdits" }] : /* istanbul ignore next */ []);
	rules = BASIS_PLACE_RULES;
	legacyChoices = computed(() => legacyEditsAllowed(this.placeRule()), ...ngDevMode ? [{ debugName: "legacyChoices" }] : /* istanbul ignore next */ []);
	htaCodes = signal(null, ...ngDevMode ? [{ debugName: "htaCodes" }] : /* istanbul ignore next */ []);
	htaText = "";
	constructor() {
		this.loadLists();
		this.loadHta();
	}
	errorFor(member) {
		return this.fieldErrors()[member]?.join(" ") ?? null;
	}
	setIncludeRetired(value) {
		this.includeRetired.set(value);
		this.loadLists();
	}
	loadLists() {
		if (this.source === null) return;
		const retired = this.includeRetired();
		this.listError.set(null);
		this.read(this.source.terms(retired), (rows) => this.terms.set(rows));
		this.read(this.source.places(retired), (rows) => this.places.set(rows));
		this.read(this.source.regions(retired), (rows) => this.regions.set(rows));
	}
	addTerm() {
		if (this.termCode.trim() === "" || this.termPrintToken.trim() === "") {
			this.outcome.set(mutationRefused("A price term needs a code and a print token."));
			return;
		}
		const incoTermsCode = this.termIncoTerms.trim() === "" ? null : this.termIncoTerms.trim();
		this.write(this.source.addTerm({
			code: this.termCode.trim(),
			printToken: this.termPrintToken.trim(),
			incoTermsCode
		}), (written) => {
			this.termCode = "";
			this.termPrintToken = "";
			this.termIncoTerms = "";
			return {
				message: `Price term ${written.value.code} added.`,
				warnings: written.warnings,
				reload: "lists"
			};
		});
	}
	addPlace() {
		if (this.placeCity.trim() === "" || this.placeState.trim() === "") {
			this.outcome.set(mutationRefused("A place needs a city and a state."));
			return;
		}
		this.write(this.source.addPlace({
			city: this.placeCity.trim(),
			state: this.placeState.trim()
		}), (written) => {
			this.placeCity = "";
			this.placeState = "";
			return {
				message: `Place ${written.value.text} added.`,
				warnings: written.warnings,
				reload: "lists"
			};
		});
	}
	addRegion() {
		if (this.regionCode.trim() === "" || this.regionPrintToken.trim() === "") {
			this.outcome.set(mutationRefused("A region needs a code and a print token."));
			return;
		}
		const states = this.regionStates.split(/[\s,]+/).map((state) => state.trim()).filter((state) => state !== "");
		this.write(this.source.addRegion({
			code: this.regionCode.trim(),
			printToken: this.regionPrintToken.trim(),
			states
		}), (written) => {
			this.regionCode = "";
			this.regionPrintToken = "";
			this.regionStates = "";
			return {
				message: `Region ${written.value.code} added.`,
				warnings: written.warnings,
				reload: "lists"
			};
		});
	}
	retireTerm(row) {
		this.write(this.source.retireTerm(row), () => ({
			message: `Price term ${row.code} retired.`,
			reload: "lists"
		}));
	}
	retirePlace(row) {
		this.write(this.source.retirePlace(row), () => ({
			message: `Place ${row.text} retired.`,
			reload: "lists"
		}));
	}
	retireRegion(row) {
		this.write(this.source.retireRegion(row), () => ({
			message: `Region ${row.code} retired.`,
			reload: "lists"
		}));
	}
	loadSetting() {
		const unit = this.tradeUnit().trim();
		if (this.source === null || unit === "") return;
		this.settingWarnings.set([]);
		this.read(this.source.setting(unit), (setting) => this.showSetting(setting));
	}
	choosePlaceRule(value) {
		const rule = value;
		this.placeRule.set(rule);
		if (!legacyEditsAllowed(rule).includes(this.legacyEdits())) this.legacyEdits.set("Allow");
	}
	chooseLegacyEdits(value) {
		this.legacyEdits.set(value);
	}
	saveSetting() {
		const current = this.setting();
		if (current === null) return;
		this.write(this.source.putSetting(current.tradeUnit, {
			placeRule: this.placeRule(),
			legacyEdits: this.legacyEdits()
		}, current.configured ? current.rowVersion : null), (written) => {
			this.showSetting(written.value);
			this.settingWarnings.set(written.warnings);
			return {
				message: `Trade unit ${written.value.tradeUnit} now enforces its basis location.`,
				warnings: []
			};
		});
	}
	loadHta() {
		if (this.source === null) return;
		this.read(this.source.htaSpecialTypes(), (codes) => {
			this.htaCodes.set(codes);
			this.htaText = codes.join(", ");
		});
	}
	saveHta() {
		const codes = this.htaText.split(/[\s,]+/).map((code) => code.trim()).filter((code) => code !== "");
		this.write(this.source.putHtaSpecialTypes(codes), (saved) => {
			this.htaCodes.set(saved);
			this.htaText = saved.join(", ");
			return { message: saved.length === 0 ? "No special type allows a term alone now." : `Saved: ${saved.join(", ")}.` };
		});
	}
	showSetting(setting) {
		this.setting.set(setting);
		this.placeRule.set(setting.placeRule);
		this.legacyEdits.set(setting.legacyEdits);
	}
	read(call, apply) {
		call.subscribe((answer) => {
			if (answer.kind === "done") apply(answer.value);
			else this.listError.set(answer.message);
		});
	}
	write(call, after) {
		this.busy.set(true);
		this.outcome.set(null);
		this.fieldErrors.set({});
		call.subscribe((answer) => {
			this.busy.set(false);
			if (answer.kind === "done") {
				const said = after(answer.value);
				const warnings = said.warnings ?? [];
				this.outcome.set(mutationSucceeded(warnings.length === 0 ? said.message : `${said.message} ${warnings.join(" ")}`, { stays: warnings.length > 0 }));
				if (said.reload === "lists") this.loadLists();
				return;
			}
			if (answer.kind === "failed") this.fieldErrors.set(answer.fieldErrors ?? {});
			else this.loadLists();
			this.outcome.set(mutationFailed({
				message: answer.message,
				correlationId: answer.correlationId ?? null
			}));
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BasisLocationsPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: BasisLocationsPageComponent,
		isStandalone: true,
		selector: "cws-basis-locations-page",
		inputs: { view: {
			classPropertyName: "view",
			publicName: "view",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Basis locations\"\n    description=\"The price terms, places and regions a contract's basis location is chosen from, each trade unit's rule, and the special types that may leave out the place.\"\n  />\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Basis location views\" />\n  }\n\n  @if (!offered) {\n    <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"basis-admin-unoffered\">\n      Basis-location administration is not offered here.\n    </p>\n  } @else {\n    <!-- #803: the last write's outcome. A 409's words are the server's, verbatim: they name the row in the way. -->\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\n\n    @if (listError(); as message) {\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\n        {{ message }}\n      </p>\n    }\n\n    @if (shows('terms') || shows('places') || shows('regions')) {\n      <!--\n        Kept visible: it is what an administrator needs before retiring anything. A retired row stays\n        on every contract that carries its text, which then asks for a re-pick on its next edit.\n      -->\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-4 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n        <p>Rows are retired, never edited: retire one and add its replacement.</p>\n        <label class=\"cws:inline-flex cws:cursor-pointer cws:items-center cws:gap-2 cws:text-xs\">\n          <input\n            type=\"checkbox\"\n            class=\"cws:size-4 cws:accent-scoular-blue\"\n            [checked]=\"includeRetired()\"\n            (change)=\"setIncludeRetired($any($event.target).checked)\"\n            data-testid=\"basis-admin-include-retired\"\n          />\n          Show retired rows\n        </label>\n      </div>\n    }\n\n    @if (shows('terms')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-terms\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Price terms</h3>\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Code</th>\n              <th class=\"cws:py-1\">Print token</th>\n              <th class=\"cws:py-1\">Incoterm</th>\n              <th class=\"cws:py-1\">Status</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            @for (row of terms() ?? []; track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.code }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.printToken }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.incoTermsCode ?? '(none)' }}</td>\n                <td class=\"cws:py-1\">{{ row.retired ? 'Retired' : 'Live' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  @if (!row.retired) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Retire price term ' + row.code\"\n                      [disabled]=\"busy()\"\n                      (click)=\"retireTerm(row)\"\n                    >\n                      Retire\n                    </button>\n                  }\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n\n        <cms-form-row class=\"cws:mt-3\">\n          <label cmsFormRowField=\"Code\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"termCode\" name=\"termCode\" placeholder=\"e.g. FOB\"\n                   [attr.aria-invalid]=\"errorFor('code') !== null ? 'true' : null\" />\n            @if (errorFor('code'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <label cmsFormRowField=\"Print token\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"termPrintToken\" name=\"termPrintToken\" placeholder=\"e.g. FOB\"\n                   [attr.aria-invalid]=\"errorFor('printToken') !== null ? 'true' : null\" />\n            @if (errorFor('printToken'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <label cmsFormRowField=\"Incoterm (optional)\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"termIncoTerms\" name=\"termIncoTerms\" placeholder=\"e.g. FOB\"\n                   [attr.aria-invalid]=\"errorFor('incoTermsCode') !== null ? 'true' : null\" />\n            @if (errorFor('incoTermsCode'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addTerm()\">Add price term</button>\n        </cms-form-row>\n      </div>\n    }\n\n    @if (shows('places')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-places\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Places (city and state)</h3>\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Text</th>\n              <th class=\"cws:py-1\">Status</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            @for (row of places() ?? []; track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.text }}</td>\n                <td class=\"cws:py-1\">{{ row.retired ? 'Retired' : 'Live' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  @if (!row.retired) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Retire place ' + row.text\"\n                      [disabled]=\"busy()\"\n                      (click)=\"retirePlace(row)\"\n                    >\n                      Retire\n                    </button>\n                  }\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n\n        <cms-form-row class=\"cws:mt-3\">\n          <label cmsFormRowField=\"City\">\n            <input class=\"scoular-form-input cws:w-48\" [(ngModel)]=\"placeCity\" name=\"placeCity\" placeholder=\"e.g. Exampleton\"\n                   [attr.aria-invalid]=\"errorFor('city') !== null ? 'true' : null\" />\n            @if (errorFor('city'); as reason) {\n              <!-- The width is the server's: it names the composed text and its length (11 characters while BASIS is live). -->\n              <span class=\"cws:block cws:max-w-sm cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"basis-admin-city-error\">{{ reason }}</span>\n            }\n          </label>\n          <label cmsFormRowField=\"State\">\n            <input class=\"scoular-form-input cws:w-20\" [(ngModel)]=\"placeState\" name=\"placeState\" placeholder=\"e.g. NE\"\n                   [attr.aria-invalid]=\"errorFor('state') !== null ? 'true' : null\" />\n            @if (errorFor('state'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addPlace()\">Add place</button>\n        </cms-form-row>\n      </div>\n    }\n\n    @if (shows('regions')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-regions\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Regions</h3>\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Code</th>\n              <th class=\"cws:py-1\">Print token</th>\n              <th class=\"cws:py-1\">States</th>\n              <th class=\"cws:py-1\">Status</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            @for (row of regions() ?? []; track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.code }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.printToken }}</td>\n                <td class=\"cws:py-1\">{{ row.states.join(', ') }}</td>\n                <td class=\"cws:py-1\">{{ row.retired ? 'Retired' : 'Live' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  @if (!row.retired) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Retire region ' + row.code\"\n                      [disabled]=\"busy()\"\n                      (click)=\"retireRegion(row)\"\n                    >\n                      Retire\n                    </button>\n                  }\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n\n        <cms-form-row class=\"cws:mt-3\">\n          <label cmsFormRowField=\"Code\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"regionCode\" name=\"regionCode\" placeholder=\"e.g. GULF\"\n                   [attr.aria-invalid]=\"errorFor('code') !== null ? 'true' : null\" />\n          </label>\n          <label cmsFormRowField=\"Print token\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"regionPrintToken\" name=\"regionPrintToken\" placeholder=\"e.g. GULF\"\n                   [attr.aria-invalid]=\"errorFor('printToken') !== null ? 'true' : null\" />\n          </label>\n          <label cmsFormRowField=\"States (optional)\">\n            <input class=\"scoular-form-input cws:w-40\" [(ngModel)]=\"regionStates\" name=\"regionStates\" placeholder=\"e.g. LA, TX\"\n                   [attr.aria-invalid]=\"errorFor('states') !== null ? 'true' : null\" />\n            @if (errorFor('states'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addRegion()\">Add region</button>\n        </cms-form-row>\n      </div>\n    }\n\n    @if (shows('trade-units')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-setting\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">A trade unit's rule</h3>\n        <!-- Said before the save, because the save is what switches the unit on. -->\n        <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n          Saving a rule makes this trade unit require a basis location from the lists. Until then it is optional\n          there. Built by CTRM is for a BCO trade unit, where CTRM sets it from the incoterm and named place.\n        </p>\n\n        <div class=\"cws:mt-2 cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\n          <cws-admin-trade-unit-select class=\"cws:w-72\" label=\"Trade unit\" [value]=\"tradeUnit()\" (valueChange)=\"tradeUnit.set($event)\" />\n          <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"tradeUnit().trim() === '' || busy()\" (click)=\"loadSetting()\">\n            Load\n          </button>\n        </div>\n\n        @if (setting(); as current) {\n          <p class=\"cws:mt-3 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"basis-admin-setting-state\">\n            {{ current.configured ? 'Enforced: a basis location from the lists is required.' : 'Not configured: optional for now.' }}\n          </p>\n          <cms-form-row class=\"cws:mt-2\">\n            <label cmsFormRowField=\"Place rule\">\n              <select class=\"scoular-form-select cws:w-64\" (change)=\"choosePlaceRule($any($event.target).value)\"\n                      [attr.aria-invalid]=\"errorFor('placeRule') !== null ? 'true' : null\">\n                @for (rule of rules; track rule.value) {\n                  <option [value]=\"rule.value\" [selected]=\"placeRule() === rule.value\">{{ rule.label }}</option>\n                }\n              </select>\n            </label>\n            <label cmsFormRowField=\"On an edit with no selection\">\n              <select class=\"scoular-form-select cws:w-64\" (change)=\"chooseLegacyEdits($any($event.target).value)\"\n                      [attr.aria-invalid]=\"errorFor('legacyEdits') !== null ? 'true' : null\" data-testid=\"basis-admin-legacy-edits\">\n                @for (choice of legacyChoices(); track choice) {\n                  <option [value]=\"choice\" [selected]=\"legacyEdits() === choice\">\n                    {{ choice === 'Allow' ? 'Allow the save, keeping the text' : 'Require a selection' }}\n                  </option>\n                }\n              </select>\n              @if (errorFor('legacyEdits'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n            </label>\n            <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy()\" (click)=\"saveSetting()\">Save rule</button>\n          </cms-form-row>\n          @if (errorFor('ifMatch'); as reason) {\n            <p class=\"cws:mt-2 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</p>\n          }\n          @for (warning of settingWarnings(); track warning) {\n            <!-- The server's C3 warning: the rule is saved, and no live value satisfies it. -->\n            <p class=\"scoular-alert scoular-alert-warning cws:mt-2 cws:text-xs\" role=\"status\" data-testid=\"basis-admin-setting-warning\">{{ warning }}</p>\n          }\n        }\n      </div>\n    }\n\n    @if (shows('hta')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-hta\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Hedge-to-arrive special types</h3>\n        <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n          On these special types a price term alone, with no place, is allowed. Saving replaces the whole set.\n        </p>\n        <cms-form-row class=\"cws:mt-2\">\n          <label cmsFormRowField=\"Special types\">\n            <input class=\"scoular-form-input cws:w-64\" [(ngModel)]=\"htaText\" name=\"htaText\" placeholder=\"e.g. HTA\"\n                   [attr.aria-invalid]=\"errorFor('codes') !== null ? 'true' : null\" />\n            @if (errorFor('codes'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy() || htaCodes() === null\" (click)=\"saveHta()\">\n            Save special types\n          </button>\n        </cms-form-row>\n      </div>\n    }\n  }\n</section>\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "component",
				type: AdminTradeUnitSelectComponent,
				selector: "cws-admin-trade-unit-select",
				inputs: [
					"label",
					"value",
					"allowAny",
					"everyLocation"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: FormRowComponent,
				selector: "cms-form-row"
			},
			{
				kind: "component",
				type: FormRowFieldComponent,
				selector: "label[cmsFormRowField]",
				inputs: ["cmsFormRowField"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BasisLocationsPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-basis-locations-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				AdminTabsComponent,
				AdminTradeUnitSelectComponent,
				FormRowComponent,
				FormRowFieldComponent,
				PageHeaderComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-4\">\n  <cms-page-header\n    title=\"Basis locations\"\n    description=\"The price terms, places and regions a contract's basis location is chosen from, each trade unit's rule, and the special types that may leave out the place.\"\n  />\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Basis location views\" />\n  }\n\n  @if (!offered) {\n    <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" role=\"status\" data-testid=\"basis-admin-unoffered\">\n      Basis-location administration is not offered here.\n    </p>\n  } @else {\n    <!-- #803: the last write's outcome. A 409's words are the server's, verbatim: they name the row in the way. -->\n    <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\n\n    @if (listError(); as message) {\n      <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\n        {{ message }}\n      </p>\n    }\n\n    @if (shows('terms') || shows('places') || shows('regions')) {\n      <!--\n        Kept visible: it is what an administrator needs before retiring anything. A retired row stays\n        on every contract that carries its text, which then asks for a re-pick on its next edit.\n      -->\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-4 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n        <p>Rows are retired, never edited: retire one and add its replacement.</p>\n        <label class=\"cws:inline-flex cws:cursor-pointer cws:items-center cws:gap-2 cws:text-xs\">\n          <input\n            type=\"checkbox\"\n            class=\"cws:size-4 cws:accent-scoular-blue\"\n            [checked]=\"includeRetired()\"\n            (change)=\"setIncludeRetired($any($event.target).checked)\"\n            data-testid=\"basis-admin-include-retired\"\n          />\n          Show retired rows\n        </label>\n      </div>\n    }\n\n    @if (shows('terms')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-terms\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Price terms</h3>\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Code</th>\n              <th class=\"cws:py-1\">Print token</th>\n              <th class=\"cws:py-1\">Incoterm</th>\n              <th class=\"cws:py-1\">Status</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            @for (row of terms() ?? []; track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.code }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.printToken }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.incoTermsCode ?? '(none)' }}</td>\n                <td class=\"cws:py-1\">{{ row.retired ? 'Retired' : 'Live' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  @if (!row.retired) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Retire price term ' + row.code\"\n                      [disabled]=\"busy()\"\n                      (click)=\"retireTerm(row)\"\n                    >\n                      Retire\n                    </button>\n                  }\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n\n        <cms-form-row class=\"cws:mt-3\">\n          <label cmsFormRowField=\"Code\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"termCode\" name=\"termCode\" placeholder=\"e.g. FOB\"\n                   [attr.aria-invalid]=\"errorFor('code') !== null ? 'true' : null\" />\n            @if (errorFor('code'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <label cmsFormRowField=\"Print token\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"termPrintToken\" name=\"termPrintToken\" placeholder=\"e.g. FOB\"\n                   [attr.aria-invalid]=\"errorFor('printToken') !== null ? 'true' : null\" />\n            @if (errorFor('printToken'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <label cmsFormRowField=\"Incoterm (optional)\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"termIncoTerms\" name=\"termIncoTerms\" placeholder=\"e.g. FOB\"\n                   [attr.aria-invalid]=\"errorFor('incoTermsCode') !== null ? 'true' : null\" />\n            @if (errorFor('incoTermsCode'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addTerm()\">Add price term</button>\n        </cms-form-row>\n      </div>\n    }\n\n    @if (shows('places')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-places\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Places (city and state)</h3>\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Text</th>\n              <th class=\"cws:py-1\">Status</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            @for (row of places() ?? []; track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.text }}</td>\n                <td class=\"cws:py-1\">{{ row.retired ? 'Retired' : 'Live' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  @if (!row.retired) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Retire place ' + row.text\"\n                      [disabled]=\"busy()\"\n                      (click)=\"retirePlace(row)\"\n                    >\n                      Retire\n                    </button>\n                  }\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n\n        <cms-form-row class=\"cws:mt-3\">\n          <label cmsFormRowField=\"City\">\n            <input class=\"scoular-form-input cws:w-48\" [(ngModel)]=\"placeCity\" name=\"placeCity\" placeholder=\"e.g. Exampleton\"\n                   [attr.aria-invalid]=\"errorFor('city') !== null ? 'true' : null\" />\n            @if (errorFor('city'); as reason) {\n              <!-- The width is the server's: it names the composed text and its length (11 characters while BASIS is live). -->\n              <span class=\"cws:block cws:max-w-sm cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\" data-testid=\"basis-admin-city-error\">{{ reason }}</span>\n            }\n          </label>\n          <label cmsFormRowField=\"State\">\n            <input class=\"scoular-form-input cws:w-20\" [(ngModel)]=\"placeState\" name=\"placeState\" placeholder=\"e.g. NE\"\n                   [attr.aria-invalid]=\"errorFor('state') !== null ? 'true' : null\" />\n            @if (errorFor('state'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addPlace()\">Add place</button>\n        </cms-form-row>\n      </div>\n    }\n\n    @if (shows('regions')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-regions\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Regions</h3>\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Code</th>\n              <th class=\"cws:py-1\">Print token</th>\n              <th class=\"cws:py-1\">States</th>\n              <th class=\"cws:py-1\">Status</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody>\n            @for (row of regions() ?? []; track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.code }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.printToken }}</td>\n                <td class=\"cws:py-1\">{{ row.states.join(', ') }}</td>\n                <td class=\"cws:py-1\">{{ row.retired ? 'Retired' : 'Live' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  @if (!row.retired) {\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Retire region ' + row.code\"\n                      [disabled]=\"busy()\"\n                      (click)=\"retireRegion(row)\"\n                    >\n                      Retire\n                    </button>\n                  }\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n\n        <cms-form-row class=\"cws:mt-3\">\n          <label cmsFormRowField=\"Code\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"regionCode\" name=\"regionCode\" placeholder=\"e.g. GULF\"\n                   [attr.aria-invalid]=\"errorFor('code') !== null ? 'true' : null\" />\n          </label>\n          <label cmsFormRowField=\"Print token\">\n            <input class=\"scoular-form-input cws:w-28\" [(ngModel)]=\"regionPrintToken\" name=\"regionPrintToken\" placeholder=\"e.g. GULF\"\n                   [attr.aria-invalid]=\"errorFor('printToken') !== null ? 'true' : null\" />\n          </label>\n          <label cmsFormRowField=\"States (optional)\">\n            <input class=\"scoular-form-input cws:w-40\" [(ngModel)]=\"regionStates\" name=\"regionStates\" placeholder=\"e.g. LA, TX\"\n                   [attr.aria-invalid]=\"errorFor('states') !== null ? 'true' : null\" />\n            @if (errorFor('states'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addRegion()\">Add region</button>\n        </cms-form-row>\n      </div>\n    }\n\n    @if (shows('trade-units')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-setting\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">A trade unit's rule</h3>\n        <!-- Said before the save, because the save is what switches the unit on. -->\n        <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n          Saving a rule makes this trade unit require a basis location from the lists. Until then it is optional\n          there. Built by CTRM is for a BCO trade unit, where CTRM sets it from the incoterm and named place.\n        </p>\n\n        <div class=\"cws:mt-2 cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\n          <cws-admin-trade-unit-select class=\"cws:w-72\" label=\"Trade unit\" [value]=\"tradeUnit()\" (valueChange)=\"tradeUnit.set($event)\" />\n          <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"tradeUnit().trim() === '' || busy()\" (click)=\"loadSetting()\">\n            Load\n          </button>\n        </div>\n\n        @if (setting(); as current) {\n          <p class=\"cws:mt-3 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"basis-admin-setting-state\">\n            {{ current.configured ? 'Enforced: a basis location from the lists is required.' : 'Not configured: optional for now.' }}\n          </p>\n          <cms-form-row class=\"cws:mt-2\">\n            <label cmsFormRowField=\"Place rule\">\n              <select class=\"scoular-form-select cws:w-64\" (change)=\"choosePlaceRule($any($event.target).value)\"\n                      [attr.aria-invalid]=\"errorFor('placeRule') !== null ? 'true' : null\">\n                @for (rule of rules; track rule.value) {\n                  <option [value]=\"rule.value\" [selected]=\"placeRule() === rule.value\">{{ rule.label }}</option>\n                }\n              </select>\n            </label>\n            <label cmsFormRowField=\"On an edit with no selection\">\n              <select class=\"scoular-form-select cws:w-64\" (change)=\"chooseLegacyEdits($any($event.target).value)\"\n                      [attr.aria-invalid]=\"errorFor('legacyEdits') !== null ? 'true' : null\" data-testid=\"basis-admin-legacy-edits\">\n                @for (choice of legacyChoices(); track choice) {\n                  <option [value]=\"choice\" [selected]=\"legacyEdits() === choice\">\n                    {{ choice === 'Allow' ? 'Allow the save, keeping the text' : 'Require a selection' }}\n                  </option>\n                }\n              </select>\n              @if (errorFor('legacyEdits'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n            </label>\n            <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"busy()\" (click)=\"saveSetting()\">Save rule</button>\n          </cms-form-row>\n          @if (errorFor('ifMatch'); as reason) {\n            <p class=\"cws:mt-2 cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</p>\n          }\n          @for (warning of settingWarnings(); track warning) {\n            <!-- The server's C3 warning: the rule is saved, and no live value satisfies it. -->\n            <p class=\"scoular-alert scoular-alert-warning cws:mt-2 cws:text-xs\" role=\"status\" data-testid=\"basis-admin-setting-warning\">{{ warning }}</p>\n          }\n        }\n      </div>\n    }\n\n    @if (shows('hta')) {\n      <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\" data-testid=\"basis-admin-hta\">\n        <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Hedge-to-arrive special types</h3>\n        <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n          On these special types a price term alone, with no place, is allowed. Saving replaces the whole set.\n        </p>\n        <cms-form-row class=\"cws:mt-2\">\n          <label cmsFormRowField=\"Special types\">\n            <input class=\"scoular-form-input cws:w-64\" [(ngModel)]=\"htaText\" name=\"htaText\" placeholder=\"e.g. HTA\"\n                   [attr.aria-invalid]=\"errorFor('codes') !== null ? 'true' : null\" />\n            @if (errorFor('codes'); as reason) { <span class=\"cws:block cws:max-w-xs cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">{{ reason }}</span> }\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy() || htaCodes() === null\" (click)=\"saveHta()\">\n            Save special types\n          </button>\n        </cms-form-row>\n      </div>\n    }\n  }\n</section>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { view: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "view",
			required: false
		}]
	}] }
});
const TEMPLATES_MANAGE = "templates:manage";
var ContractTemplatesAccess = class ContractTemplatesAccess {
	source = inject(ME_SOURCE, { optional: true });
	me = toSignal(this.source === null ? of(void 0) : this.source.get().pipe(map((state) => state.status === "loaded" ? state.value : state.status === "error" ? void 0 : null)), { initialValue: void 0 });
	known = computed(() => this.me() !== void 0 && this.me() !== null, ...ngDevMode ? [{ debugName: "known" }] : /* istanbul ignore next */ []);
	canManage(tradeUnit) {
		const me = this.me();
		return me === void 0 || me === null ? true : holdsPermission(me, tradeUnit, TEMPLATES_MANAGE);
	}
	defaultTradeUnit = computed(() => {
		const me = this.me();
		if (me === void 0 || me === null) return "";
		return me.defaultTradeUnit ?? me.tradeUnits.find((unit) => unit.isDefault)?.code ?? "";
	}, ...ngDevMode ? [{ debugName: "defaultTradeUnit" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ContractTemplatesAccess,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ContractTemplatesAccess
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ContractTemplatesAccess,
	decorators: [{ type: Injectable }]
});
function fieldsSetOf(template) {
	return Object.keys(templateValuesOf(template)).length;
}
function fieldsToCompleteOf(template) {
	return templatePromptFieldsOf(template).length;
}
const DRIVERS = [["TextCode", "contractTypeClass"], ["CommodityCode", "commodityCode"]];
const CTRM_FIELD_BY_COMPONENT = new Map(CONTRACT_WRITABLE_FIELDS.map((field) => [field.componentName, field.ctrmField]));
var ContractTemplateEditorComponent = class ContractTemplateEditorComponent {
	templates = inject(CONTRACT_TEMPLATE_SOURCE, { optional: true });
	configs = inject(FORM_CONFIG_SOURCE, { optional: true });
	host = inject(CMS_HOST_CONTEXT, { optional: true });
	access = inject(ContractTemplatesAccess);
	destroyRef = inject(DestroyRef);
	id = input(void 0, ...ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []);
	tradeUnitParam = input(void 0, {
		...ngDevMode ? { debugName: "tradeUnitParam" } : /* istanbul ignore next */ {},
		alias: "tradeUnit"
	});
	tradeUnit = signal("", ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	name = signal("", ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	current = signal(null, ...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	loadState = signal("new", ...ngDevMode ? [{ debugName: "loadState" }] : /* istanbul ignore next */ []);
	startingValues = signal({}, ...ngDevMode ? [{ debugName: "startingValues" }] : /* istanbul ignore next */ []);
	drivers = signal({}, ...ngDevMode ? [{ debugName: "drivers" }] : /* istanbul ignore next */ []);
	checked = signal(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	search = signal("", ...ngDevMode ? [{ debugName: "search" }] : /* istanbul ignore next */ []);
	saving = signal(false, ...ngDevMode ? [{ debugName: "saving" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	outcomeFailed = signal(false, ...ngDevMode ? [{ debugName: "outcomeFailed" }] : /* istanbul ignore next */ []);
	isNew = computed(() => this.id() === void 0 || this.id() === "new", ...ngDevMode ? [{ debugName: "isNew" }] : /* istanbul ignore next */ []);
	canManage = computed(() => this.tradeUnit() !== "" && this.access.canManage(this.tradeUnit()), ...ngDevMode ? [{ debugName: "canManage" }] : /* istanbul ignore next */ []);
	resolutionKey = computed(() => {
		const unit = this.tradeUnit().trim();
		const drivers = this.drivers();
		return unit === "" || this.loadState() === "loading" ? null : {
			locationCode: unit,
			...drivers.contractTypeClass === void 0 ? {} : { contractTypeClass: drivers.contractTypeClass },
			...drivers.commodityCode === void 0 ? {} : { commodityCode: drivers.commodityCode }
		};
	}, ...ngDevMode ? [{ debugName: "resolutionKey" }] : /* istanbul ignore next */ []);
	configState = toSignal(toObservable(this.resolutionKey).pipe(switchMap((key) => key === null || this.configs === null ? of(null) : this.configs.load(key))), { initialValue: null });
	bundle = signal(null, ...ngDevMode ? [{ debugName: "bundle" }] : /* istanbul ignore next */ []);
	formKey = computed(() => this.bundle()?.config.version ?? "none", ...ngDevMode ? [{ debugName: "formKey" }] : /* istanbul ignore next */ []);
	form = signal(null, ...ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []);
	presentation = computed(() => {
		const layout = {
			halfFields: CONTRACT_LAYOUT_HALF_FIELDS,
			hiddenLabelFields: CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS,
			fieldNotes: CONTRACT_LAYOUT_FIELD_NOTES
		};
		const config = this.bundle()?.config;
		return config === void 0 ? layout : presentationMaps(config, layout, CONTRACT_LAYOUT_FIXED_WIDTH_FIELDS);
	}, ...ngDevMode ? [{ debugName: "presentation" }] : /* istanbul ignore next */ []);
	readOnlyFields = CONTRACT_READ_ONLY_FIELDS;
	wideFields = CONTRACT_LAYOUT_WIDE_FIELDS;
	groupHeadings = CONTRACT_LAYOUT_GROUP_HEADINGS;
	fieldCtrmNames = CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT;
	initialValues = computed(() => templateSeedFor(this.startingValues()), ...ngDevMode ? [{ debugName: "initialValues" }] : /* istanbul ignore next */ []);
	checklistAll = computed(() => {
		const config = this.bundle()?.config;
		const form = this.form();
		if (config === void 0) return [];
		const states = form?.states() ?? /* @__PURE__ */ new Map();
		return [...config.sections].filter((section) => section.visible).sort((a, b) => a.order - b.order).map((section) => ({
			id: section.componentName,
			label: section.label,
			fields: [...section.fields].sort((a, b) => a.order - b.order).filter((field) => states.get(field.componentName)?.visible ?? field.behaviour.visible).flatMap((field) => {
				const ctrmField = CTRM_FIELD_BY_COMPONENT.get(field.componentName);
				return ctrmField === void 0 || IDENTITY_FIELDS.has(ctrmField) ? [] : [{
					componentName: field.componentName,
					ctrmField,
					label: field.label
				}];
			})
		})).filter((section) => section.fields.length > 0);
	}, ...ngDevMode ? [{ debugName: "checklistAll" }] : /* istanbul ignore next */ []);
	checklist = computed(() => {
		const term = this.search().trim().toLowerCase();
		return term === "" ? this.checklistAll() : this.checklistAll().map((section) => ({
			...section,
			fields: section.fields.filter((field) => field.label.toLowerCase().includes(term) || field.ctrmField.includes(term))
		})).filter((section) => section.fields.length > 0);
	}, ...ngDevMode ? [{ debugName: "checklist" }] : /* istanbul ignore next */ []);
	locked = computed(() => {
		const form = this.form();
		const config = this.bundle()?.config;
		if (form === null || config === void 0) return /* @__PURE__ */ new Set();
		form.value();
		form.validity();
		return new Set(validationSummary(form, config).filter((item) => item.required === true && !item.hidden).map((item) => item.componentName));
	}, ...ngDevMode ? [{ debugName: "locked" }] : /* istanbul ignore next */ []);
	carriedPrompts = computed(() => {
		const shown = new Set(this.checklistAll().flatMap((section) => section.fields).map((field) => field.componentName));
		return [...this.checked()].filter((componentName) => !shown.has(componentName)).flatMap((componentName) => {
			const ctrmField = CTRM_FIELD_BY_COMPONENT.get(componentName);
			return ctrmField === void 0 ? [] : [ctrmField];
		});
	}, ...ngDevMode ? [{ debugName: "carriedPrompts" }] : /* istanbul ignore next */ []);
	promptFields = computed(() => {
		const checked = this.checked();
		const locked = this.locked();
		return [...this.checklistAll().flatMap((section) => section.fields).filter((field) => checked.has(field.componentName) || locked.has(field.componentName)).map((field) => field.ctrmField), ...this.carriedPrompts()];
	}, ...ngDevMode ? [{ debugName: "promptFields" }] : /* istanbul ignore next */ []);
	previewHref = computed(() => {
		const saved = this.current();
		if (saved === null) return null;
		const intent = {
			kind: "new-contract",
			params: {
				tradeUnit: saved.tradeUnit,
				template: String(saved.id)
			}
		};
		return this.host?.hrefFor(intent) ?? `/contracts/new?tradeUnit=${encodeURIComponent(saved.tradeUnit)}&template=${saved.id}`;
	}, ...ngDevMode ? [{ debugName: "previewHref" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const state = this.configState();
			if (state !== null && state.status === "loaded") untracked(() => this.bundle.set(state.value));
		});
		effect(() => {
			const id = this.id();
			const unit = this.tradeUnitParam()?.trim() ?? "";
			untracked(() => this.open(id, unit));
		});
	}
	onTradeUnit(unit) {
		if (this.isNew() && this.current() === null) this.tradeUnit.set(unit);
	}
	onFormReady(form) {
		this.form.set(form);
		for (const [componentName, dimension] of DRIVERS) form.control(componentName)?.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((value) => {
			const next = typeof value === "string" && value.trim() !== "" ? value.trim() : typeof value === "number" ? String(value) : void 0;
			if (next === this.drivers()[dimension]) return;
			this.startingValues.set(templateValuesFromForm(form));
			this.drivers.update((drivers) => ({
				...drivers,
				[dimension]: next
			}));
		});
	}
	isChecked(field) {
		return this.checked().has(field.componentName) || this.locked().has(field.componentName);
	}
	toggle(field, on) {
		this.checked.update((checked) => {
			const next = new Set(checked);
			if (on) next.add(field.componentName);
			else next.delete(field.componentName);
			return next;
		});
	}
	save() {
		const templates = this.templates;
		const form = this.form();
		const name = this.name().trim();
		const unit = this.tradeUnit().trim();
		if (templates === null || form === null || name === "" || unit === "" || !this.canManage()) return;
		const values = templateValuesFromForm(form);
		const prompts = this.promptFields();
		const current = this.current();
		this.saving.set(true);
		this.outcome.set(null);
		(current === null ? templates.save(unit, name, values, prompts) : templates.rename(current, unit, name, values, prompts)).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (saved) => {
				this.saving.set(false);
				this.current.set(saved);
				this.say(this.savedMessage(name, saved, prompts), false);
			},
			error: (error) => {
				this.saving.set(false);
				this.say(this.refusal(error, name), true);
			}
		});
	}
	savedMessage(name, saved, prompts) {
		return `Template "${name}" saved.${saved.removed.length === 0 ? "" : ` It does not carry ${saved.removed.map((field) => this.labelOf(field)).join(", ")} for this trade unit.`}${saved.promptFields === void 0 && prompts.length > 0 ? " This server does not keep the fields to complete yet, so a create from it shows the full form until it does." : ""}`;
	}
	refusal(error, name) {
		const problem = error ?? null;
		if (problem?.status === 409) return `"${name}" was changed by someone else since it was opened, so nothing was saved. Open it again from the list.`;
		if (problem?.status === 400 && (problem.error?.type ?? "").endsWith("template-prompt-fields-invalid")) return `The fields to complete were refused: ${problem.error?.detail ?? "the server named no field."}`;
		return `"${name}" could not be saved. Try again.`;
	}
	labelOf(ctrmField) {
		return this.checklistAll().flatMap((section) => section.fields).find((field) => field.ctrmField === ctrmField)?.label ?? ctrmField;
	}
	say(message, failed) {
		this.outcome.set(message);
		this.outcomeFailed.set(failed);
	}
	open(id, unit) {
		if (id === void 0 || id === "new") {
			this.loadState.set("new");
			this.tradeUnit.set(unit);
			return;
		}
		if (this.templates === null || unit === "") {
			this.loadState.set("missing");
			return;
		}
		this.loadState.set("loading");
		this.templates.list(unit).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => {
			if (state.status === "error") {
				this.loadState.set("error");
				return;
			}
			if (state.status !== "loaded") return;
			const template = state.value.find((each) => String(each.id) === id);
			if (template === void 0) {
				this.loadState.set("missing");
				return;
			}
			const values = templateValuesOf(template);
			const prompts = new Set(templatePromptFieldsOf(template));
			this.current.set(template);
			this.name.set(template.name);
			this.tradeUnit.set(template.tradeUnit);
			this.startingValues.set(values);
			this.drivers.set({
				...scalar(values["text_code"]) === void 0 ? {} : { contractTypeClass: scalar(values["text_code"]) },
				...scalar(values["commodity_code"]) === void 0 ? {} : { commodityCode: scalar(values["commodity_code"]) }
			});
			this.checked.set(new Set(CONTRACT_WRITABLE_FIELDS.filter((field) => prompts.has(field.ctrmField)).map((field) => field.componentName)));
			this.loadState.set("loaded");
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ContractTemplateEditorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ContractTemplateEditorComponent,
		isStandalone: true,
		selector: "cws-contract-template-editor",
		inputs: {
			id: {
				classPropertyName: "id",
				publicName: "id",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			tradeUnitParam: {
				classPropertyName: "tradeUnitParam",
				publicName: "tradeUnit",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block cws:space-y-4" },
		providers: [AdminScope, ContractTemplatesAccess],
		ngImport: i0,
		template: "<section class=\"scoular-card cws:p-4\" aria-labelledby=\"template-editor-heading\">\n  <div class=\"cws:flex cws:flex-wrap cws:items-start cws:justify-between cws:gap-3\">\n    <div>\n      <a class=\"cws:text-xs cws:text-scoular-blue cws:underline cws:dark:text-sky-400\" routerLink=\"..\" [queryParams]=\"{ tradeUnit: tradeUnit() }\">\n        Contract templates\n      </a>\n      <h2 id=\"template-editor-heading\" class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n        {{ isNew() && current() === null ? 'New contract template' : name() || 'Contract template' }}\n      </h2>\n      <p class=\"cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n        The form a trader starts from. Nothing here reserves a contract number or writes to CTRM.\n      </p>\n    </div>\n\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\n      @if (previewHref(); as href) {\n        <!-- T12: the existing deep link, in a new tab. -->\n        <a class=\"scoular-btn scoular-btn-secondary\" [attr.href]=\"href\" target=\"_blank\" rel=\"noopener\" data-testid=\"template-preview\">\n          Preview as a trader\n        </a>\n      }\n      @if (canManage()) {\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-primary\"\n          [disabled]=\"saving() || name().trim() === '' || form() === null\"\n          (click)=\"save()\"\n          data-testid=\"template-save\"\n        >\n          @if (saving()) { Saving… } @else { Save template }\n        </button>\n      }\n    </div>\n  </div>\n\n  @if (outcome(); as message) {\n    <p role=\"status\" class=\"cws:mt-3 cws:text-sm\" [class.cws:text-red-700]=\"outcomeFailed()\" data-testid=\"template-outcome\">\n      {{ message }}\n    </p>\n  }\n\n  @if (tradeUnit() !== '' && !canManage()) {\n    <p role=\"status\" class=\"cws:mt-3 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n      You can read this template. Changing it needs the templates permission in this trade unit.\n    </p>\n  }\n\n  <div class=\"cws:mt-3 cws:grid cws:gap-3 cws:md:grid-cols-2\">\n    @if (isNew() && current() === null) {\n      <cws-admin-trade-unit-select label=\"Trade unit\" [everyLocation]=\"true\" [value]=\"tradeUnit()\" (valueChange)=\"onTradeUnit($event)\" />\n    } @else {\n      <p class=\"cws:text-sm\"><span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Trade unit</span><br />{{ tradeUnit() }}</p>\n    }\n    <label class=\"cws:block\">\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Name</span>\n      <input class=\"scoular-form-input cws:mt-1 cws:w-full\" [value]=\"name()\" (input)=\"name.set($any($event.target).value)\" [readOnly]=\"!canManage()\" />\n    </label>\n  </div>\n</section>\n\n@switch (loadState()) {\n  @case ('loading') {\n    <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">Loading the template…</p>\n  }\n  @case ('missing') {\n    <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">This template was not found. Open it from the list of its trade unit's templates.</p>\n  }\n  @case ('error') {\n    <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">The template could not be loaded.</p>\n  }\n  @default {\n    @if (tradeUnit() === '') {\n      <p class=\"scoular-card cws:p-4 cws:text-sm\">Choose a trade unit to build the template on its form.</p>\n    } @else if (bundle(); as loaded) {\n      <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-[minmax(0,1fr)_20rem]\">\n        <div class=\"cws:min-w-0\">\n          <!-- Rebuilt only when the configuration changes; the values ride across in startingValues. -->\n          @for (key of [formKey()]; track key) {\n            <cms-contract-form\n              [config]=\"loaded.config\"\n              [tradeUnit]=\"loaded.tradeUnit\"\n              [readOnly]=\"!canManage()\"\n              [constraints]=\"loaded.constraints ?? null\"\n              [fieldNotes]=\"presentation().fieldNotes\"\n              [halfFields]=\"presentation().halfFields\"\n              [hiddenLabelFields]=\"presentation().hiddenLabelFields\"\n              [wideFields]=\"wideFields\"\n              [groupHeadings]=\"groupHeadings\"\n              [fieldCtrmNames]=\"fieldCtrmNames\"\n              [readOnlyFields]=\"readOnlyFields\"\n              [initialValues]=\"initialValues()\"\n              instanceId=\"template\"\n              (ready)=\"onFormReady($event)\"\n            />\n          }\n        </div>\n\n        <!-- T11: the fields a trader is asked to complete, beside the form. -->\n        <aside class=\"scoular-card cws:self-start cws:p-4\" aria-labelledby=\"template-checklist-heading\" data-testid=\"template-checklist\">\n          <h3 id=\"template-checklist-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields to complete</h3>\n          <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n            A trader creating from this template sees only these, and anything still required.\n            {{ promptFields().length }} chosen.\n          </p>\n          @if (carriedPrompts().length > 0) {\n            <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"template-carried-prompts\">\n              {{ carriedPrompts().length }} more {{ carriedPrompts().length === 1 ? 'is' : 'are' }} asked for but not on this form\n              now ({{ carriedPrompts().join(', ') }}). Saving keeps {{ carriedPrompts().length === 1 ? 'it' : 'them' }}.\n            </p>\n          }\n          <label class=\"cws:mt-2 cws:block\">\n            <span class=\"cws:sr-only\">Search the fields</span>\n            <input class=\"scoular-form-input cws:w-full cws:text-xs\" type=\"search\" placeholder=\"Search the fields\" [value]=\"search()\" (input)=\"search.set($any($event.target).value)\" />\n          </label>\n\n          <div class=\"cws:mt-2 cws:max-h-[60vh] cws:space-y-3 cws:overflow-y-auto\">\n            @for (section of checklist(); track section.id) {\n              <fieldset>\n                <legend class=\"cws:text-xs cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:dark:text-slate-400\">{{ section.label }}</legend>\n                @for (field of section.fields; track field.componentName) {\n                  <label class=\"cws:flex cws:items-start cws:gap-2 cws:py-0.5 cws:text-sm\">\n                    <input\n                      type=\"checkbox\"\n                      class=\"cws:mt-1 cws:size-4 cws:accent-scoular-blue\"\n                      [checked]=\"isChecked(field)\"\n                      [disabled]=\"locked().has(field.componentName) || !canManage()\"\n                      (change)=\"toggle(field, $any($event.target).checked)\"\n                      [attr.data-prompt-field]=\"field.ctrmField\"\n                    />\n                    <span>\n                      {{ field.label }}\n                      @if (locked().has(field.componentName)) {\n                        <span class=\"cws:block cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">required and blank, so it will be asked for</span>\n                      }\n                    </span>\n                  </label>\n                }\n              </fieldset>\n            } @empty {\n              <p class=\"cws:text-xs\">No field matches.</p>\n            }\n          </div>\n        </aside>\n      </div>\n    } @else {\n      <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">Loading this trade unit's form…</p>\n    }\n  }\n}\n",
		dependencies: [
			{
				kind: "component",
				type: AdminTradeUnitSelectComponent,
				selector: "cws-admin-trade-unit-select",
				inputs: [
					"label",
					"value",
					"allowAny",
					"everyLocation"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: ContractFormComponent,
				selector: "cms-contract-form",
				inputs: [
					"config",
					"tradeUnit",
					"facts",
					"readOnly",
					"instanceId",
					"visibleSections",
					"visibleFields",
					"hideEmptyFields",
					"fieldNotes",
					"pinnedNotes",
					"emptyNotes",
					"sectionNotes",
					"wideFields",
					"halfFields",
					"fieldCtrmNames",
					"constraints",
					"hiddenLabelFields",
					"groupHeadings",
					"readOnlyFields",
					"lockedFields",
					"fieldVerdicts",
					"fieldAddons",
					"initialValues",
					"defaultValues"
				],
				outputs: ["ready", "fieldBlur"]
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ContractTemplateEditorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-template-editor",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AdminTradeUnitSelectComponent,
				ContractFormComponent,
				RouterLink
			],
			providers: [AdminScope, ContractTemplatesAccess],
			host: { class: "cws:block cws:space-y-4" },
			template: "<section class=\"scoular-card cws:p-4\" aria-labelledby=\"template-editor-heading\">\n  <div class=\"cws:flex cws:flex-wrap cws:items-start cws:justify-between cws:gap-3\">\n    <div>\n      <a class=\"cws:text-xs cws:text-scoular-blue cws:underline cws:dark:text-sky-400\" routerLink=\"..\" [queryParams]=\"{ tradeUnit: tradeUnit() }\">\n        Contract templates\n      </a>\n      <h2 id=\"template-editor-heading\" class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n        {{ isNew() && current() === null ? 'New contract template' : name() || 'Contract template' }}\n      </h2>\n      <p class=\"cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n        The form a trader starts from. Nothing here reserves a contract number or writes to CTRM.\n      </p>\n    </div>\n\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\n      @if (previewHref(); as href) {\n        <!-- T12: the existing deep link, in a new tab. -->\n        <a class=\"scoular-btn scoular-btn-secondary\" [attr.href]=\"href\" target=\"_blank\" rel=\"noopener\" data-testid=\"template-preview\">\n          Preview as a trader\n        </a>\n      }\n      @if (canManage()) {\n        <button\n          type=\"button\"\n          class=\"scoular-btn scoular-btn-primary\"\n          [disabled]=\"saving() || name().trim() === '' || form() === null\"\n          (click)=\"save()\"\n          data-testid=\"template-save\"\n        >\n          @if (saving()) { Saving… } @else { Save template }\n        </button>\n      }\n    </div>\n  </div>\n\n  @if (outcome(); as message) {\n    <p role=\"status\" class=\"cws:mt-3 cws:text-sm\" [class.cws:text-red-700]=\"outcomeFailed()\" data-testid=\"template-outcome\">\n      {{ message }}\n    </p>\n  }\n\n  @if (tradeUnit() !== '' && !canManage()) {\n    <p role=\"status\" class=\"cws:mt-3 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n      You can read this template. Changing it needs the templates permission in this trade unit.\n    </p>\n  }\n\n  <div class=\"cws:mt-3 cws:grid cws:gap-3 cws:md:grid-cols-2\">\n    @if (isNew() && current() === null) {\n      <cws-admin-trade-unit-select label=\"Trade unit\" [everyLocation]=\"true\" [value]=\"tradeUnit()\" (valueChange)=\"onTradeUnit($event)\" />\n    } @else {\n      <p class=\"cws:text-sm\"><span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Trade unit</span><br />{{ tradeUnit() }}</p>\n    }\n    <label class=\"cws:block\">\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Name</span>\n      <input class=\"scoular-form-input cws:mt-1 cws:w-full\" [value]=\"name()\" (input)=\"name.set($any($event.target).value)\" [readOnly]=\"!canManage()\" />\n    </label>\n  </div>\n</section>\n\n@switch (loadState()) {\n  @case ('loading') {\n    <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">Loading the template…</p>\n  }\n  @case ('missing') {\n    <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">This template was not found. Open it from the list of its trade unit's templates.</p>\n  }\n  @case ('error') {\n    <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">The template could not be loaded.</p>\n  }\n  @default {\n    @if (tradeUnit() === '') {\n      <p class=\"scoular-card cws:p-4 cws:text-sm\">Choose a trade unit to build the template on its form.</p>\n    } @else if (bundle(); as loaded) {\n      <div class=\"cws:grid cws:gap-4 cws:lg:grid-cols-[minmax(0,1fr)_20rem]\">\n        <div class=\"cws:min-w-0\">\n          <!-- Rebuilt only when the configuration changes; the values ride across in startingValues. -->\n          @for (key of [formKey()]; track key) {\n            <cms-contract-form\n              [config]=\"loaded.config\"\n              [tradeUnit]=\"loaded.tradeUnit\"\n              [readOnly]=\"!canManage()\"\n              [constraints]=\"loaded.constraints ?? null\"\n              [fieldNotes]=\"presentation().fieldNotes\"\n              [halfFields]=\"presentation().halfFields\"\n              [hiddenLabelFields]=\"presentation().hiddenLabelFields\"\n              [wideFields]=\"wideFields\"\n              [groupHeadings]=\"groupHeadings\"\n              [fieldCtrmNames]=\"fieldCtrmNames\"\n              [readOnlyFields]=\"readOnlyFields\"\n              [initialValues]=\"initialValues()\"\n              instanceId=\"template\"\n              (ready)=\"onFormReady($event)\"\n            />\n          }\n        </div>\n\n        <!-- T11: the fields a trader is asked to complete, beside the form. -->\n        <aside class=\"scoular-card cws:self-start cws:p-4\" aria-labelledby=\"template-checklist-heading\" data-testid=\"template-checklist\">\n          <h3 id=\"template-checklist-heading\" class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields to complete</h3>\n          <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\n            A trader creating from this template sees only these, and anything still required.\n            {{ promptFields().length }} chosen.\n          </p>\n          @if (carriedPrompts().length > 0) {\n            <p class=\"cws:mt-1 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"template-carried-prompts\">\n              {{ carriedPrompts().length }} more {{ carriedPrompts().length === 1 ? 'is' : 'are' }} asked for but not on this form\n              now ({{ carriedPrompts().join(', ') }}). Saving keeps {{ carriedPrompts().length === 1 ? 'it' : 'them' }}.\n            </p>\n          }\n          <label class=\"cws:mt-2 cws:block\">\n            <span class=\"cws:sr-only\">Search the fields</span>\n            <input class=\"scoular-form-input cws:w-full cws:text-xs\" type=\"search\" placeholder=\"Search the fields\" [value]=\"search()\" (input)=\"search.set($any($event.target).value)\" />\n          </label>\n\n          <div class=\"cws:mt-2 cws:max-h-[60vh] cws:space-y-3 cws:overflow-y-auto\">\n            @for (section of checklist(); track section.id) {\n              <fieldset>\n                <legend class=\"cws:text-xs cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:dark:text-slate-400\">{{ section.label }}</legend>\n                @for (field of section.fields; track field.componentName) {\n                  <label class=\"cws:flex cws:items-start cws:gap-2 cws:py-0.5 cws:text-sm\">\n                    <input\n                      type=\"checkbox\"\n                      class=\"cws:mt-1 cws:size-4 cws:accent-scoular-blue\"\n                      [checked]=\"isChecked(field)\"\n                      [disabled]=\"locked().has(field.componentName) || !canManage()\"\n                      (change)=\"toggle(field, $any($event.target).checked)\"\n                      [attr.data-prompt-field]=\"field.ctrmField\"\n                    />\n                    <span>\n                      {{ field.label }}\n                      @if (locked().has(field.componentName)) {\n                        <span class=\"cws:block cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">required and blank, so it will be asked for</span>\n                      }\n                    </span>\n                  </label>\n                }\n              </fieldset>\n            } @empty {\n              <p class=\"cws:text-xs\">No field matches.</p>\n            }\n          </div>\n        </aside>\n      </div>\n    } @else {\n      <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">Loading this trade unit's form…</p>\n    }\n  }\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		id: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "id",
				required: false
			}]
		}],
		tradeUnitParam: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tradeUnit",
				required: false
			}]
		}]
	}
});
const IDENTITY_FIELDS = /* @__PURE__ */ new Set([
	"contract_number",
	"contract_suffix",
	"location"
]);
function scalar(value) {
	return typeof value === "string" && value.trim() !== "" ? value.trim() : typeof value === "number" ? String(value) : void 0;
}
var ContractTemplatesPageComponent = class ContractTemplatesPageComponent {
	source = inject(CONTRACT_TEMPLATE_SOURCE, { optional: true });
	access = inject(ContractTemplatesAccess);
	confirm = injectConfirm();
	destroyRef = inject(DestroyRef);
	tradeUnit = signal("", ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	list = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "list" }] : /* istanbul ignore next */ []);
	renaming = signal(null, ...ngDevMode ? [{ debugName: "renaming" }] : /* istanbul ignore next */ []);
	renameText = signal("", ...ngDevMode ? [{ debugName: "renameText" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	outcomeFailed = signal(false, ...ngDevMode ? [{ debugName: "outcomeFailed" }] : /* istanbul ignore next */ []);
	templates = computed(() => {
		const state = this.list();
		return state.status === "loaded" ? state.templates : [];
	}, ...ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []);
	canManage = computed(() => this.tradeUnit() !== "" && this.access.canManage(this.tradeUnit()), ...ngDevMode ? [{ debugName: "canManage" }] : /* istanbul ignore next */ []);
	fieldsSet = fieldsSetOf;
	fieldsToComplete = fieldsToCompleteOf;
	constructor() {
		effect(() => {
			const fallback = this.access.defaultTradeUnit();
			untracked(() => {
				if (this.tradeUnit() === "" && fallback !== "") this.tradeUnit.set(fallback);
			});
		});
		effect(() => {
			const unit = this.tradeUnit();
			untracked(() => this.load(unit));
		});
	}
	dated(value) {
		if (value === null || value === void 0 || !/^\d{4}-\d{2}-\d{2}/.test(value)) return null;
		return `${value.slice(5, 7)}/${value.slice(8, 10)}/${value.slice(0, 4)}`;
	}
	startRename(template) {
		this.renaming.set(template.id);
		this.renameText.set(template.name);
		this.outcome.set(null);
	}
	saveRename(template) {
		const source = this.source;
		const name = this.renameText().trim();
		if (source === null || name === "") return;
		this.busy.set(true);
		source.rename(template, this.tradeUnit(), name, templateValuesOf(template), templatePromptFieldsOf(template)).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: () => {
				this.busy.set(false);
				this.renaming.set(null);
				this.say(`Renamed to "${name}".`, false);
				this.load(this.tradeUnit());
			},
			error: (error) => {
				this.busy.set(false);
				this.renaming.set(null);
				this.refused(error, `"${template.name}" could not be renamed, so it keeps its name. Try again.`, template);
			}
		});
	}
	retire(template) {
		const source = this.source;
		if (source === null) return;
		this.outcome.set(null);
		this.confirm({
			title: "Retire this template?",
			message: `"${template.name}" will no longer be offered to anyone in this trade unit.`,
			confirmLabel: "Retire template",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (!confirmed) return;
			this.busy.set(true);
			source.remove(template).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
				next: () => {
					this.busy.set(false);
					this.say(`"${template.name}" retired.`, false);
					this.load(this.tradeUnit());
				},
				error: (error) => {
					this.busy.set(false);
					this.refused(error, `"${template.name}" could not be retired, so it is still offered. Try again.`, template);
				}
			});
		});
	}
	refused(error, otherwise, template) {
		if (error?.status === 409) {
			this.say(`"${template.name}" was changed by someone else since this list was read, so nothing was changed. The list is up to date now.`, true);
			this.load(this.tradeUnit());
			return;
		}
		this.say(otherwise, true);
	}
	say(message, failed) {
		this.outcome.set(message);
		this.outcomeFailed.set(failed);
	}
	load(unit) {
		const source = this.source;
		if (source === null || unit.trim() === "") {
			this.list.set({ status: "idle" });
			return;
		}
		source.list(unit.trim()).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => {
			if (state.status === "loaded") this.list.set({
				status: "loaded",
				templates: state.value
			});
			else if (state.status === "error") this.list.set({ status: "error" });
			else this.list.set({ status: "loading" });
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ContractTemplatesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ContractTemplatesPageComponent,
		isStandalone: true,
		selector: "cws-contract-templates-page",
		host: { classAttribute: "cws:block cws:space-y-4" },
		providers: [AdminScope, ContractTemplatesAccess],
		ngImport: i0,
		template: `
    <section class="scoular-card cws:p-4" aria-labelledby="contract-templates-heading">
      <h2 id="contract-templates-heading" class="cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white">
        Contract templates
      </h2>
      <p class="cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
        Starting points for a new contract: the values a template sets and the fields it asks the trader to complete.
      </p>

      @if (source === null) {
        <p role="status" class="cws:mt-3 cws:text-sm">Templates are not available here.</p>
      } @else {
        <div class="cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-3">
          <cws-admin-trade-unit-select
            class="cws:w-72"
            label="Trade unit"
            [everyLocation]="true"
            [value]="tradeUnit()"
            (valueChange)="tradeUnit.set($event)"
          />
          @if (canManage()) {
            <a
              class="scoular-btn scoular-btn-primary"
              routerLink="new"
              [queryParams]="{ tradeUnit: tradeUnit() }"
              [class.cws:pointer-events-none]="tradeUnit() === ''"
              [attr.aria-disabled]="tradeUnit() === '' ? 'true' : null"
              data-testid="contract-templates-new"
            >
              New template
            </a>
          }
        </div>

        @if (tradeUnit() !== '' && !canManage()) {
          <p role="status" class="cws:mt-3 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300" data-testid="contract-templates-read-only">
            You can read this trade unit's templates. Changing them needs the templates permission in this trade unit.
          </p>
        }

        @if (outcome(); as message) {
          <p role="status" class="cws:mt-3 cws:text-sm" [class.cws:text-red-700]="outcomeFailed()" data-testid="contract-templates-outcome">
            {{ message }}
          </p>
        }

        @switch (list().status) {
          @case ('idle') {
            <p class="cws:mt-3 cws:text-sm cws:text-slate-500">Choose a trade unit to see its templates.</p>
          }
          @case ('loading') {
            <p role="status" class="cws:mt-3 cws:text-sm">Loading templates…</p>
          }
          @case ('error') {
            <p role="status" class="cws:mt-3 cws:text-sm">The templates for this trade unit could not be loaded.</p>
          }
          @case ('loaded') {
            @if (templates().length === 0) {
              <p class="cws:mt-3 cws:text-sm">This trade unit has no templates yet.</p>
            } @else {
              <table class="cws:mt-3 cws:w-full cws:text-left cws:text-sm" data-testid="contract-templates-list">
                <thead class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  <tr>
                    <th scope="col" class="cws:py-2">Name</th>
                    <th scope="col" class="cws:py-2">Fields set</th>
                    <th scope="col" class="cws:py-2">Fields to complete</th>
                    <th scope="col" class="cws:py-2">Last used</th>
                    <th scope="col" class="cws:py-2">Updated</th>
                    <th scope="col" class="cws:py-2"><span class="cws:sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody>
                  @for (template of templates(); track template.id) {
                    <tr class="cws:border-t cws:border-slate-200 cws:dark:border-slate-700">
                      <td class="cws:py-2">
                        @if (renaming() === template.id) {
                          <label>
                            <span class="cws:sr-only">New name for {{ template.name }}</span>
                            <input
                              class="scoular-form-input"
                              [value]="renameText()"
                              (input)="renameText.set($any($event.target).value)"
                            />
                          </label>
                        } @else {
                          {{ template.name }}
                        }
                      </td>
                      <td class="cws:py-2">{{ fieldsSet(template) }}</td>
                      <td class="cws:py-2">{{ fieldsToComplete(template) }}</td>
                      <td class="cws:py-2">{{ dated(template.lastUsedUtc) ?? 'Never' }}</td>
                      <td class="cws:py-2">{{ template.updatedBy ?? template.createdBy }}, {{ dated(template.updatedUtc ?? template.createdUtc) }}</td>
                      <td class="cws:py-2 cws:text-right cws:whitespace-nowrap">
                        <a
                          class="scoular-btn scoular-btn-secondary scoular-btn-sm"
                          [routerLink]="[template.id]"
                          [queryParams]="{ tradeUnit: tradeUnit() }"
                          [attr.aria-label]="(canManage() ? 'Edit ' : 'Open ') + template.name"
                        >
                          {{ canManage() ? 'Edit' : 'Open' }}
                        </a>
                        @if (canManage()) {
                          @if (renaming() === template.id) {
                            <button type="button" class="scoular-btn scoular-btn-primary scoular-btn-sm cws:ml-1" [disabled]="renameText().trim() === '' || busy()" (click)="saveRename(template)">
                              Save name
                            </button>
                            <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1" (click)="renaming.set(null)">Cancel</button>
                          } @else {
                            <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1" [attr.aria-label]="'Rename ' + template.name" (click)="startRename(template)">
                              Rename
                            </button>
                            <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1" [attr.aria-label]="'Retire ' + template.name" [disabled]="busy()" (click)="retire(template)">
                              Retire
                            </button>
                          }
                        }
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
        }
      }
    </section>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: AdminTradeUnitSelectComponent,
			selector: "cws-admin-trade-unit-select",
			inputs: [
				"label",
				"value",
				"allowAny",
				"everyLocation"
			],
			outputs: ["valueChange"]
		}, {
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ContractTemplatesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-contract-templates-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [AdminTradeUnitSelectComponent, RouterLink],
			providers: [AdminScope, ContractTemplatesAccess],
			host: { class: "cws:block cws:space-y-4" },
			template: `
    <section class="scoular-card cws:p-4" aria-labelledby="contract-templates-heading">
      <h2 id="contract-templates-heading" class="cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white">
        Contract templates
      </h2>
      <p class="cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
        Starting points for a new contract: the values a template sets and the fields it asks the trader to complete.
      </p>

      @if (source === null) {
        <p role="status" class="cws:mt-3 cws:text-sm">Templates are not available here.</p>
      } @else {
        <div class="cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-3">
          <cws-admin-trade-unit-select
            class="cws:w-72"
            label="Trade unit"
            [everyLocation]="true"
            [value]="tradeUnit()"
            (valueChange)="tradeUnit.set($event)"
          />
          @if (canManage()) {
            <a
              class="scoular-btn scoular-btn-primary"
              routerLink="new"
              [queryParams]="{ tradeUnit: tradeUnit() }"
              [class.cws:pointer-events-none]="tradeUnit() === ''"
              [attr.aria-disabled]="tradeUnit() === '' ? 'true' : null"
              data-testid="contract-templates-new"
            >
              New template
            </a>
          }
        </div>

        @if (tradeUnit() !== '' && !canManage()) {
          <p role="status" class="cws:mt-3 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300" data-testid="contract-templates-read-only">
            You can read this trade unit's templates. Changing them needs the templates permission in this trade unit.
          </p>
        }

        @if (outcome(); as message) {
          <p role="status" class="cws:mt-3 cws:text-sm" [class.cws:text-red-700]="outcomeFailed()" data-testid="contract-templates-outcome">
            {{ message }}
          </p>
        }

        @switch (list().status) {
          @case ('idle') {
            <p class="cws:mt-3 cws:text-sm cws:text-slate-500">Choose a trade unit to see its templates.</p>
          }
          @case ('loading') {
            <p role="status" class="cws:mt-3 cws:text-sm">Loading templates…</p>
          }
          @case ('error') {
            <p role="status" class="cws:mt-3 cws:text-sm">The templates for this trade unit could not be loaded.</p>
          }
          @case ('loaded') {
            @if (templates().length === 0) {
              <p class="cws:mt-3 cws:text-sm">This trade unit has no templates yet.</p>
            } @else {
              <table class="cws:mt-3 cws:w-full cws:text-left cws:text-sm" data-testid="contract-templates-list">
                <thead class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                  <tr>
                    <th scope="col" class="cws:py-2">Name</th>
                    <th scope="col" class="cws:py-2">Fields set</th>
                    <th scope="col" class="cws:py-2">Fields to complete</th>
                    <th scope="col" class="cws:py-2">Last used</th>
                    <th scope="col" class="cws:py-2">Updated</th>
                    <th scope="col" class="cws:py-2"><span class="cws:sr-only">Actions</span></th>
                  </tr>
                </thead>
                <tbody>
                  @for (template of templates(); track template.id) {
                    <tr class="cws:border-t cws:border-slate-200 cws:dark:border-slate-700">
                      <td class="cws:py-2">
                        @if (renaming() === template.id) {
                          <label>
                            <span class="cws:sr-only">New name for {{ template.name }}</span>
                            <input
                              class="scoular-form-input"
                              [value]="renameText()"
                              (input)="renameText.set($any($event.target).value)"
                            />
                          </label>
                        } @else {
                          {{ template.name }}
                        }
                      </td>
                      <td class="cws:py-2">{{ fieldsSet(template) }}</td>
                      <td class="cws:py-2">{{ fieldsToComplete(template) }}</td>
                      <td class="cws:py-2">{{ dated(template.lastUsedUtc) ?? 'Never' }}</td>
                      <td class="cws:py-2">{{ template.updatedBy ?? template.createdBy }}, {{ dated(template.updatedUtc ?? template.createdUtc) }}</td>
                      <td class="cws:py-2 cws:text-right cws:whitespace-nowrap">
                        <a
                          class="scoular-btn scoular-btn-secondary scoular-btn-sm"
                          [routerLink]="[template.id]"
                          [queryParams]="{ tradeUnit: tradeUnit() }"
                          [attr.aria-label]="(canManage() ? 'Edit ' : 'Open ') + template.name"
                        >
                          {{ canManage() ? 'Edit' : 'Open' }}
                        </a>
                        @if (canManage()) {
                          @if (renaming() === template.id) {
                            <button type="button" class="scoular-btn scoular-btn-primary scoular-btn-sm cws:ml-1" [disabled]="renameText().trim() === '' || busy()" (click)="saveRename(template)">
                              Save name
                            </button>
                            <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1" (click)="renaming.set(null)">Cancel</button>
                          } @else {
                            <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1" [attr.aria-label]="'Rename ' + template.name" (click)="startRename(template)">
                              Rename
                            </button>
                            <button type="button" class="scoular-btn scoular-btn-secondary scoular-btn-sm cws:ml-1" [attr.aria-label]="'Retire ' + template.name" [disabled]="busy()" (click)="retire(template)">
                              Retire
                            </button>
                          }
                        }
                      </td>
                    </tr>
                  }
                </tbody>
              </table>
            }
          }
        }
      }
    </section>
  `
		}]
	}],
	ctorParameters: () => []
});
var FormConfigAdminPageComponent = class FormConfigAdminPageComponent {
	source = inject(FORM_CONFIG_ADMIN_SOURCE);
	view = input("all", {
		...ngDevMode ? { debugName: "view" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "all"
	});
	showRows = computed(() => this.view() !== "preview", ...ngDevMode ? [{ debugName: "showRows" }] : /* istanbul ignore next */ []);
	showPreview = computed(() => this.view() !== "rows", ...ngDevMode ? [{ debugName: "showPreview" }] : /* istanbul ignore next */ []);
	routed = computed(() => this.view() !== "all", ...ngDevMode ? [{ debugName: "routed" }] : /* istanbul ignore next */ []);
	area = adminArea("form-configuration");
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	listState = signal(remoteLoading(), ...ngDevMode ? [{ debugName: "listState" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.value.rows : [];
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	storeOrigin = computed(() => {
		const state = this.listState();
		return state.status === "loaded" ? state.value.storeOrigin : null;
	}, ...ngDevMode ? [{ debugName: "storeOrigin" }] : /* istanbul ignore next */ []);
	notDurable = computed(() => this.storeOrigin() === "InMemory", ...ngDevMode ? [{ debugName: "notDurable" }] : /* istanbul ignore next */ []);
	previewType = "";
	previewLocation = "";
	previewCommodity = "";
	previewContract = "";
	previewState = signal(null, ...ngDevMode ? [{ debugName: "previewState" }] : /* istanbul ignore next */ []);
	preview = computed(() => {
		const state = this.previewState();
		return state !== null && state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "preview" }] : /* istanbul ignore next */ []);
	previewProvenance = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return null;
		const { provenance } = resolved;
		if (provenance.configId === null) return "No configuration row matched. The form falls back to the built-in defaults generated from the field layout — correct and safe, but nothing an administrator has configured applies.";
		const matched = provenance.matchedDimensions.length === 0 ? "the global default row (no dimensions pinned)" : `matched on ${provenance.matchedDimensions.map(dimensionLabel).join(" and ")}`;
		return `Configuration #${provenance.configId}, version ${provenance.version}, ${matched}. Effective from ${provenance.effectiveFrom}, served from ${provenance.source}.`;
	}, ...ngDevMode ? [{ debugName: "previewProvenance" }] : /* istanbul ignore next */ []);
	previewRequired = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return [];
		return resolved.config.sections.flatMap((section) => section.fields.filter((field) => field.behaviour.required).map((field) => field.label));
	}, ...ngDevMode ? [{ debugName: "previewRequired" }] : /* istanbul ignore next */ []);
	previewHidden = computed(() => {
		const resolved = this.preview();
		if (resolved === null) return [];
		return resolved.config.sections.flatMap((section) => section.fields.filter((field) => !field.behaviour.visible).map((field) => field.label));
	}, ...ngDevMode ? [{ debugName: "previewHidden" }] : /* istanbul ignore next */ []);
	previewTabs = computed(() => {
		const resolved = this.preview()?.config;
		return tabsAfterCascade(resolved?.tabs ?? [], resolved?.sections ?? []).map((tab) => tab.label);
	}, ...ngDevMode ? [{ debugName: "previewTabs" }] : /* istanbul ignore next */ []);
	auditRowId = signal(null, ...ngDevMode ? [{ debugName: "auditRowId" }] : /* istanbul ignore next */ []);
	auditState = signal(remoteLoading(), ...ngDevMode ? [{ debugName: "auditState" }] : /* istanbul ignore next */ []);
	auditError = computed(() => {
		const state = this.auditState();
		return state.status === "error" ? state.error.message : "";
	}, ...ngDevMode ? [{ debugName: "auditError" }] : /* istanbul ignore next */ []);
	auditPartial = computed(() => {
		const state = this.auditState();
		return state.status === "loaded" && state.value.partial === true;
	}, ...ngDevMode ? [{ debugName: "auditPartial" }] : /* istanbul ignore next */ []);
	auditEntries = computed(() => {
		const state = this.auditState();
		if (state.status !== "loaded") return [];
		const entries = state.value.entries;
		return entries.map((entry, index) => ({
			entry,
			isOldest: index === 0,
			changes: diffConfigDocuments(index === 0 ? null : parseSnapshot(entries[index - 1].configJsonSnapshot), parseSnapshot(entry.configJsonSnapshot) ?? EMPTY_DOCUMENT)
		})).reverse();
	}, ...ngDevMode ? [{ debugName: "auditEntries" }] : /* istanbul ignore next */ []);
	toggleAudit(row) {
		if (this.auditRowId() === row.id) {
			this.auditRowId.set(null);
			return;
		}
		this.auditRowId.set(row.id);
		this.auditState.set(remoteLoading());
		this.source.auditTrail(row.id).subscribe((state) => this.auditState.set(state));
	}
	router = inject(Router, { optional: true });
	route = inject(ActivatedRoute, { optional: true });
	rowActions = computed(() => {
		const open = this.auditRowId();
		return new Map(this.rows().map((row) => {
			const actions = [];
			if (row.isActive) actions.push({
				label: "Edit",
				run: (target) => this.edit(target)
			}, {
				label: "Deactivate",
				run: (target) => this.deactivate(target)
			});
			actions.push({
				label: open === row.id ? "Hide history" : "History",
				run: (target) => this.toggleAudit(target)
			});
			return [row.id, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "rowActions" }] : /* istanbul ignore next */ []);
	startNew() {
		this.router?.navigate([".."], { relativeTo: this.route ?? void 0 });
	}
	edit(row) {
		this.router?.navigate([".."], {
			relativeTo: this.route ?? void 0,
			queryParams: {
				...row.contractTypeClass === null ? {} : { type: row.contractTypeClass },
				...row.locationCode === null ? {} : { tradeUnit: row.locationCode },
				...row.commodityCode === null ? {} : { commodity: row.commodityCode }
			}
		});
	}
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	constructor() {
		this.reload();
	}
	reload() {
		this.attempt.update((attempt) => attempt + 1);
		this.source.list().subscribe((state) => this.listState.set(state));
	}
	runPreview() {
		this.previewState.set(remoteLoading());
		this.source.preview({
			...this.previewContract !== "" ? { contractNumber: this.previewContract } : {},
			...this.previewContract === "" ? {
				...this.previewType !== "" ? { contractTypeClass: this.previewType } : {},
				...this.previewLocation !== "" ? { locationCode: this.previewLocation } : {},
				...this.previewCommodity !== "" ? { commodityCode: this.previewCommodity } : {}
			} : {}
		}).subscribe((state) => this.previewState.set(state));
	}
	deactivate(row) {
		this.outcome.set(null);
		this.source.deactivate(row.id, row.rowVersion).subscribe((state) => {
			if (state.status === "loaded") {
				this.outcome.set(mutationSucceeded(`Configuration ${row.id} deactivated.`));
				this.reload();
				return;
			}
			if (state.status === "error") this.outcome.set(mutationFailed(state.error));
		});
	}
	dimension(value) {
		return value === null || value === "" ? "Any" : value;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormConfigAdminPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormConfigAdminPageComponent,
		isStandalone: true,
		selector: "cms-form-config-admin-page",
		inputs: { view: {
			classPropertyName: "view",
			publicName: "view",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		ngImport: i0,
		template: "<section class=\"cws:space-y-6\">\n  <!--\n    #825: the title, one sentence, and the page's primary action. The rules that used to follow in the\n    description, and the soft-delete note under the table, are behind \"How configuration resolves\":\n    they explain the page rather than change a decision on it.\n  -->\n  <cms-page-header\n    title=\"Form configuration\"\n    description=\"Which fields the contract record shows and requires, and which tabs it has, per contract type, trade unit and commodity.\"\n  >\n    @if (showRows()) {\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"startNew()\">\n        New configuration\n      </button>\n    }\n  </cms-page-header>\n\n  <details class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n    <summary class=\"cws:cursor-pointer cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\n      How configuration resolves\n    </summary>\n    <div class=\"cws:mt-2 cws:space-y-2\">\n      <p>\n        The most specific match wins, and the whole configuration applies, with no merging between rows.\n        A blank dimension means <em>any</em>.\n      </p>\n      <p>\n        Deactivating is a soft delete: the row stops resolving and frees its dimensions for a replacement,\n        and every change is kept in the configuration audit trail with who made it.\n      </p>\n    </div>\n  </details>\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Form configuration views\" />\n  }\n\n  @if (notDurable()) {\n    <!--\n      Said out loud rather than assumed. No deployed environment has a configuration database\n      connection string yet, so the honest answer is usually \"in memory\" — and an admin whose saved\n      configuration vanishes on the next restart, without having been told, is owed an explanation\n      nobody can give them afterwards.\n    -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n      <div class=\"scoular-alert-title\">Configuration is not being stored durably</div>\n      <div class=\"scoular-alert-description\">\n        This environment has no configuration database configured, so rows are held in memory and are\n        lost when the application restarts. Resolution, validation and the audit trail all behave\n        exactly as they will against a database — only the persistence is missing.\n      </div>\n    </div>\n  }\n\n  <!--\n    The form builder (2026-10-28, F14) retired the checkbox editor from this screen: New configuration and a row's\n    Edit open the builder at the row's dimensions. The list, the resolution tool and the audit trail stay here.\n  -->\n\n  <!--\n    🔑 THE PREVIEW TOOL — first on the page, ahead of the list, on purpose.\n\n    The question an admin actually arrives with is \"given a contract like THIS, what will the form\n    do?\", and the ranking rules are hard to hold in your head once a dozen rows exist. The list\n    answers \"what rows are there\"; this answers the question.\n\n    It calls the same `resolve` endpoint the record screen calls, so it cannot disagree with\n    production — a preview with its own copy of the ranking rules would be a second answer to\n    \"which configuration wins\".\n  -->\n  @if (showPreview()) {\n  <div class=\"scoular-card cws:space-y-4 cws:p-4\">\n    <div class=\"cws:space-y-1\">\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview a resolution</h3>\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n        Which configuration a contract like this gets. Leave a box empty to mean <em>any</em>.\n      </p>\n      <details class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        <summary class=\"cws:cursor-pointer\">Why give a contract number?</summary>\n        <p class=\"cws:mt-1\">\n          The server derives all three dimensions from the contract itself, which is the only way to get\n          the contract type right: CTRM derives it and does not accept it on a write.\n        </p>\n      </details>\n    </div>\n\n    <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type class</span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewType\"\n          placeholder=\"e.g. BCO - English\"\n          [(ngModel)]=\"previewType\"\n        />\n      </label>\n\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Trade unit</span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewLocation\"\n          placeholder=\"e.g. 0210\"\n          [(ngModel)]=\"previewLocation\"\n        />\n      </label>\n\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewCommodity\"\n          placeholder=\"e.g. YC\"\n          [(ngModel)]=\"previewCommodity\"\n        />\n      </label>\n\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n          Or a contract number\n        </span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewContract\"\n          placeholder=\"e.g. SC1240000\"\n          [(ngModel)]=\"previewContract\"\n        />\n      </label>\n    </div>\n\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"runPreview()\">\n      Resolve\n    </button>\n\n    @if (previewProvenance() !== null) {\n      <div class=\"cws:space-y-3 cws:border-t cws:border-slate-200 cws:pt-4 cws:dark:border-slate-700\">\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\" data-testid=\"preview-provenance\">\n          {{ previewProvenance() }}\n        </p>\n\n        <dl class=\"cws:grid cws:gap-3 cws:text-sm cws:sm:grid-cols-3\">\n          <div>\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Tabs</dt>\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-tabs\">\n              {{ previewTabs().length > 0 ? previewTabs().join(', ') : '—' }}\n            </dd>\n          </div>\n\n          <div>\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\n              Required fields ({{ previewRequired().length }})\n            </dt>\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-required\">\n              {{ previewRequired().length > 0 ? previewRequired().join(', ') : 'None' }}\n            </dd>\n          </div>\n\n          <div>\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\n              Hidden fields ({{ previewHidden().length }})\n            </dt>\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-hidden\">\n              {{ previewHidden().length > 0 ? previewHidden().join(', ') : 'None' }}\n            </dd>\n          </div>\n        </dl>\n\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Auto-calculation: {{ preview()?.tradeUnitAttributes.autoCalculationMode }} · Pending\n          contracts:\n          {{ preview()?.tradeUnitAttributes.pendingContractsEnabled ? 'enabled' : 'disabled' }}\n        </p>\n      </div>\n    }\n  </div>\n  }\n\n  @if (showRows()) {\n  <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Configuration rows</h3>\n\n  <!-- #803: the last save or deactivate, with the server's reference on a failure. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\n    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\n  </cms-status-message>\n\n  <cms-async-container\n    [data]=\"listState()\"\n    [empty]=\"rows().length === 0\"\n    emptyMessage=\"No configuration rows exist yet, so every contract resolves to the built-in defaults generated from the field layout.\"\n    loadingLabel=\"Loading form configuration\"\n    (retry)=\"reload()\"\n  >\n    <div class=\"scoular-card cws:overflow-x-auto\">\n      <table class=\"cws:w-full cws:text-sm\">\n        <caption class=\"sr-only\">Form configuration rows</caption>\n        <thead class=\"cws:border-b cws:border-slate-200 cws:text-left cws:dark:border-slate-700\">\n          <tr>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Contract type</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Trade unit</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Commodity</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Effective from</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Version</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Status</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Last changed</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">\n              <span class=\"sr-only\">Actions</span>\n            </th>\n          </tr>\n        </thead>\n        <tbody>\n          @for (row of rows(); track row.id) {\n            <tr class=\"cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\">\n              <!--\n                `Any` rather than a blank cell. A null dimension means \"this row applies to every\n                contract type\", and an empty cell reads as missing data — the opposite of what it says.\n              -->\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.contractTypeClass) }}</td>\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.locationCode) }}</td>\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.commodityCode) }}</td>\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.effectiveFrom }}</td>\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.version }}</td>\n              <td class=\"cws:px-3 cws:py-2\">\n                @if (row.isActive) {\n                  <span class=\"cws:text-emerald-700 cws:dark:text-emerald-400\">Active</span>\n                } @else {\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Deactivated</span>\n                }\n              </td>\n              <td class=\"cws:px-3 cws:py-2\">\n                {{ row.modifiedByUpn }}\n              </td>\n              <td class=\"cws:px-3 cws:py-2 cws:text-right\">\n                <!--\n                  #825: Edit, Deactivate and History behind the row's menu (they were three inline\n                  buttons). History is on deactivated rows too (F8.6): the audit outlives its subject.\n                -->\n                <cms-row-menu\n                  [row]=\"row\"\n                  [actions]=\"rowActions().get(row.id) ?? []\"\n                  [label]=\"'Actions for configuration ' + row.id\"\n                />\n              </td>\n            </tr>\n\n            @if (auditRowId() === row.id) {\n              <tr>\n                <!-- All eight columns. It said 7, leaving the actions column of the row beside it. -->\n                <td colspan=\"8\" class=\"cws:bg-slate-50 cws:px-3 cws:py-3 cws:dark:bg-slate-900/40\">\n                  @switch (auditState().status) {\n                    @case ('loading') {\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading history…</p>\n                    }\n                    @case ('error') {\n                      <p class=\"cws:text-xs cws:text-rose-700 cws:dark:text-rose-400\" role=\"alert\">\n                        {{ auditError() }}\n                      </p>\n                    }\n                    @default {\n                      <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                        Newest first. Each entry lists what changed against the entry before it —\n                        the stored snapshots are full documents, so this is derived, not a second\n                        record.\n                      </p>\n\n                      @if (auditPartial()) {\n                        <!-- #700: entries from trade units this account does not manage are left out, so the\n                             oldest entry shown changed something the screen does not show. -->\n                        <p class=\"cws:mb-2 cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-900 cws:dark:bg-amber-950 cws:dark:text-amber-200\" role=\"note\" data-audit-partial>\n                          Scoped to your trade units: some earlier history is not shown, because it was made while\n                          this row belonged to a trade unit you do not manage.\n                        </p>\n                      }\n\n                      @for (item of auditEntries(); track item.entry.auditId) {\n                        <details class=\"cws:mb-1 cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\n                          <summary\n                            class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-xs\"\n                            [attr.data-testid]=\"'audit-summary-' + item.entry.auditId\"\n                          >\n                            <span class=\"cws:font-medium\">{{ item.entry.changeType }}</span>\n                            · v{{ item.entry.version }}\n                            · {{ item.entry.timestampUtc }}\n                            · {{ item.entry.actorUpn }}\n                            <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n                              @if (item.isOldest) {\n                                — the oldest entry held; nothing before it to compare\n                              } @else if (item.changes.length === 0) {\n                                — no field changed\n                              } @else {\n                                — {{ item.changes.length }}\n                                {{ item.changes.length === 1 ? 'change' : 'changes' }}\n                              }\n                            </span>\n                          </summary>\n\n                          @if (item.changes.length > 0) {\n                            <ul\n                              class=\"cws:space-y-1 cws:px-4 cws:pb-3 cws:pt-1 cws:text-xs\"\n                              [attr.data-testid]=\"'audit-changes-' + item.entry.auditId\"\n                            >\n                              @for (change of item.changes; track change.scope + change.subject + change.property) {\n                                <li>\n                                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">{{ change.scope }}</span>\n                                  <span class=\"cws:font-medium\">{{ change.subject }}</span>\n                                  @if (change.property !== '') {\n                                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">·{{ change.property }}</span>\n                                  }\n                                  @if (change.before !== '' && change.after !== '') {\n                                    : {{ change.before }} → {{ change.after }}\n                                  }\n                                </li>\n                              }\n                            </ul>\n                          }\n                        </details>\n                      } @empty {\n                        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                          No history recorded for this row.\n                        </p>\n                      }\n                    }\n                  }\n                </td>\n              </tr>\n            }\n          }\n        </tbody>\n      </table>\n    </div>\n  </cms-async-container>\n  }\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormConfigAdminPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-config-admin-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AdminTabsComponent,
				AsyncContainerComponent,
				FormsModule,
				PageHeaderComponent,
				RowMenuComponent,
				StatusMessageComponent
			],
			template: "<section class=\"cws:space-y-6\">\n  <!--\n    #825: the title, one sentence, and the page's primary action. The rules that used to follow in the\n    description, and the soft-delete note under the table, are behind \"How configuration resolves\":\n    they explain the page rather than change a decision on it.\n  -->\n  <cms-page-header\n    title=\"Form configuration\"\n    description=\"Which fields the contract record shows and requires, and which tabs it has, per contract type, trade unit and commodity.\"\n  >\n    @if (showRows()) {\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"startNew()\">\n        New configuration\n      </button>\n    }\n  </cms-page-header>\n\n  <details class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n    <summary class=\"cws:cursor-pointer cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\n      How configuration resolves\n    </summary>\n    <div class=\"cws:mt-2 cws:space-y-2\">\n      <p>\n        The most specific match wins, and the whole configuration applies, with no merging between rows.\n        A blank dimension means <em>any</em>.\n      </p>\n      <p>\n        Deactivating is a soft delete: the row stops resolving and frees its dimensions for a replacement,\n        and every change is kept in the configuration audit trail with who made it.\n      </p>\n    </div>\n  </details>\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Form configuration views\" />\n  }\n\n  @if (notDurable()) {\n    <!--\n      Said out loud rather than assumed. No deployed environment has a configuration database\n      connection string yet, so the honest answer is usually \"in memory\" — and an admin whose saved\n      configuration vanishes on the next restart, without having been told, is owed an explanation\n      nobody can give them afterwards.\n    -->\n    <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n      <div class=\"scoular-alert-title\">Configuration is not being stored durably</div>\n      <div class=\"scoular-alert-description\">\n        This environment has no configuration database configured, so rows are held in memory and are\n        lost when the application restarts. Resolution, validation and the audit trail all behave\n        exactly as they will against a database — only the persistence is missing.\n      </div>\n    </div>\n  }\n\n  <!--\n    The form builder (2026-10-28, F14) retired the checkbox editor from this screen: New configuration and a row's\n    Edit open the builder at the row's dimensions. The list, the resolution tool and the audit trail stay here.\n  -->\n\n  <!--\n    🔑 THE PREVIEW TOOL — first on the page, ahead of the list, on purpose.\n\n    The question an admin actually arrives with is \"given a contract like THIS, what will the form\n    do?\", and the ranking rules are hard to hold in your head once a dozen rows exist. The list\n    answers \"what rows are there\"; this answers the question.\n\n    It calls the same `resolve` endpoint the record screen calls, so it cannot disagree with\n    production — a preview with its own copy of the ranking rules would be a second answer to\n    \"which configuration wins\".\n  -->\n  @if (showPreview()) {\n  <div class=\"scoular-card cws:space-y-4 cws:p-4\">\n    <div class=\"cws:space-y-1\">\n      <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Preview a resolution</h3>\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n        Which configuration a contract like this gets. Leave a box empty to mean <em>any</em>.\n      </p>\n      <details class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        <summary class=\"cws:cursor-pointer\">Why give a contract number?</summary>\n        <p class=\"cws:mt-1\">\n          The server derives all three dimensions from the contract itself, which is the only way to get\n          the contract type right: CTRM derives it and does not accept it on a write.\n        </p>\n      </details>\n    </div>\n\n    <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type class</span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewType\"\n          placeholder=\"e.g. BCO - English\"\n          [(ngModel)]=\"previewType\"\n        />\n      </label>\n\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Trade unit</span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewLocation\"\n          placeholder=\"e.g. 0210\"\n          [(ngModel)]=\"previewLocation\"\n        />\n      </label>\n\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewCommodity\"\n          placeholder=\"e.g. YC\"\n          [(ngModel)]=\"previewCommodity\"\n        />\n      </label>\n\n      <label class=\"cws:space-y-1\">\n        <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n          Or a contract number\n        </span>\n        <input\n          class=\"scoular-form-input cws:w-full\"\n          name=\"previewContract\"\n          placeholder=\"e.g. SC1240000\"\n          [(ngModel)]=\"previewContract\"\n        />\n      </label>\n    </div>\n\n    <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"runPreview()\">\n      Resolve\n    </button>\n\n    @if (previewProvenance() !== null) {\n      <div class=\"cws:space-y-3 cws:border-t cws:border-slate-200 cws:pt-4 cws:dark:border-slate-700\">\n        <p class=\"cws:text-sm cws:font-medium cws:text-slate-900 cws:dark:text-white\" data-testid=\"preview-provenance\">\n          {{ previewProvenance() }}\n        </p>\n\n        <dl class=\"cws:grid cws:gap-3 cws:text-sm cws:sm:grid-cols-3\">\n          <div>\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">Tabs</dt>\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-tabs\">\n              {{ previewTabs().length > 0 ? previewTabs().join(', ') : '—' }}\n            </dd>\n          </div>\n\n          <div>\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\n              Required fields ({{ previewRequired().length }})\n            </dt>\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-required\">\n              {{ previewRequired().length > 0 ? previewRequired().join(', ') : 'None' }}\n            </dd>\n          </div>\n\n          <div>\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\n              Hidden fields ({{ previewHidden().length }})\n            </dt>\n            <dd class=\"cws:text-slate-900 cws:dark:text-slate-100\" data-testid=\"preview-hidden\">\n              {{ previewHidden().length > 0 ? previewHidden().join(', ') : 'None' }}\n            </dd>\n          </div>\n        </dl>\n\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Auto-calculation: {{ preview()?.tradeUnitAttributes.autoCalculationMode }} · Pending\n          contracts:\n          {{ preview()?.tradeUnitAttributes.pendingContractsEnabled ? 'enabled' : 'disabled' }}\n        </p>\n      </div>\n    }\n  </div>\n  }\n\n  @if (showRows()) {\n  <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Configuration rows</h3>\n\n  <!-- #803: the last save or deactivate, with the server's reference on a failure. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\">\n    <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"reload()\">Reload</button>\n  </cms-status-message>\n\n  <cms-async-container\n    [data]=\"listState()\"\n    [empty]=\"rows().length === 0\"\n    emptyMessage=\"No configuration rows exist yet, so every contract resolves to the built-in defaults generated from the field layout.\"\n    loadingLabel=\"Loading form configuration\"\n    (retry)=\"reload()\"\n  >\n    <div class=\"scoular-card cws:overflow-x-auto\">\n      <table class=\"cws:w-full cws:text-sm\">\n        <caption class=\"sr-only\">Form configuration rows</caption>\n        <thead class=\"cws:border-b cws:border-slate-200 cws:text-left cws:dark:border-slate-700\">\n          <tr>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Contract type</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Trade unit</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Commodity</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Effective from</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Version</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Status</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Last changed</th>\n            <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">\n              <span class=\"sr-only\">Actions</span>\n            </th>\n          </tr>\n        </thead>\n        <tbody>\n          @for (row of rows(); track row.id) {\n            <tr class=\"cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\">\n              <!--\n                `Any` rather than a blank cell. A null dimension means \"this row applies to every\n                contract type\", and an empty cell reads as missing data — the opposite of what it says.\n              -->\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.contractTypeClass) }}</td>\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.locationCode) }}</td>\n              <td class=\"cws:px-3 cws:py-2\">{{ dimension(row.commodityCode) }}</td>\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.effectiveFrom }}</td>\n              <td class=\"cws:px-3 cws:py-2 cws:tabular-nums\">{{ row.version }}</td>\n              <td class=\"cws:px-3 cws:py-2\">\n                @if (row.isActive) {\n                  <span class=\"cws:text-emerald-700 cws:dark:text-emerald-400\">Active</span>\n                } @else {\n                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Deactivated</span>\n                }\n              </td>\n              <td class=\"cws:px-3 cws:py-2\">\n                {{ row.modifiedByUpn }}\n              </td>\n              <td class=\"cws:px-3 cws:py-2 cws:text-right\">\n                <!--\n                  #825: Edit, Deactivate and History behind the row's menu (they were three inline\n                  buttons). History is on deactivated rows too (F8.6): the audit outlives its subject.\n                -->\n                <cms-row-menu\n                  [row]=\"row\"\n                  [actions]=\"rowActions().get(row.id) ?? []\"\n                  [label]=\"'Actions for configuration ' + row.id\"\n                />\n              </td>\n            </tr>\n\n            @if (auditRowId() === row.id) {\n              <tr>\n                <!-- All eight columns. It said 7, leaving the actions column of the row beside it. -->\n                <td colspan=\"8\" class=\"cws:bg-slate-50 cws:px-3 cws:py-3 cws:dark:bg-slate-900/40\">\n                  @switch (auditState().status) {\n                    @case ('loading') {\n                      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Loading history…</p>\n                    }\n                    @case ('error') {\n                      <p class=\"cws:text-xs cws:text-rose-700 cws:dark:text-rose-400\" role=\"alert\">\n                        {{ auditError() }}\n                      </p>\n                    }\n                    @default {\n                      <p class=\"cws:mb-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                        Newest first. Each entry lists what changed against the entry before it —\n                        the stored snapshots are full documents, so this is derived, not a second\n                        record.\n                      </p>\n\n                      @if (auditPartial()) {\n                        <!-- #700: entries from trade units this account does not manage are left out, so the\n                             oldest entry shown changed something the screen does not show. -->\n                        <p class=\"cws:mb-2 cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-900 cws:dark:bg-amber-950 cws:dark:text-amber-200\" role=\"note\" data-audit-partial>\n                          Scoped to your trade units: some earlier history is not shown, because it was made while\n                          this row belonged to a trade unit you do not manage.\n                        </p>\n                      }\n\n                      @for (item of auditEntries(); track item.entry.auditId) {\n                        <details class=\"cws:mb-1 cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\">\n                          <summary\n                            class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-xs\"\n                            [attr.data-testid]=\"'audit-summary-' + item.entry.auditId\"\n                          >\n                            <span class=\"cws:font-medium\">{{ item.entry.changeType }}</span>\n                            · v{{ item.entry.version }}\n                            · {{ item.entry.timestampUtc }}\n                            · {{ item.entry.actorUpn }}\n                            <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n                              @if (item.isOldest) {\n                                — the oldest entry held; nothing before it to compare\n                              } @else if (item.changes.length === 0) {\n                                — no field changed\n                              } @else {\n                                — {{ item.changes.length }}\n                                {{ item.changes.length === 1 ? 'change' : 'changes' }}\n                              }\n                            </span>\n                          </summary>\n\n                          @if (item.changes.length > 0) {\n                            <ul\n                              class=\"cws:space-y-1 cws:px-4 cws:pb-3 cws:pt-1 cws:text-xs\"\n                              [attr.data-testid]=\"'audit-changes-' + item.entry.auditId\"\n                            >\n                              @for (change of item.changes; track change.scope + change.subject + change.property) {\n                                <li>\n                                  <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">{{ change.scope }}</span>\n                                  <span class=\"cws:font-medium\">{{ change.subject }}</span>\n                                  @if (change.property !== '') {\n                                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">·{{ change.property }}</span>\n                                  }\n                                  @if (change.before !== '' && change.after !== '') {\n                                    : {{ change.before }} → {{ change.after }}\n                                  }\n                                </li>\n                              }\n                            </ul>\n                          }\n                        </details>\n                      } @empty {\n                        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                          No history recorded for this row.\n                        </p>\n                      }\n                    }\n                  }\n                </td>\n              </tr>\n            }\n          }\n        </tbody>\n      </table>\n    </div>\n  </cms-async-container>\n  }\n</section>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { view: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "view",
			required: false
		}]
	}] }
});
function dimensionLabel(dimension) {
	switch (dimension) {
		case "contractTypeClass": return "contract type";
		case "locationCode": return "location";
		case "commodityCode": return "commodity";
		default: return dimension;
	}
}
const EMPTY_DOCUMENT = {
	schemaVersion: 0,
	tabs: [],
	sections: [],
	fields: {},
	attributes: {
		autoCalculationMode: "",
		pendingContractsEnabled: false
	}
};
function parseSnapshot(json) {
	try {
		return JSON.parse(json);
	} catch {
		return null;
	}
}
const LOCKED_FIELD_GROUPS = (() => {
	const groups = [];
	for (const name of Object.keys(CONTRACT_LAYOUT_FIXED_WIDTH_FIELDS)) {
		const heading = CONTRACT_LAYOUT_GROUP_HEADINGS[name];
		if (heading !== void 0) groups.push({
			heading,
			members: [name]
		});
		else groups.at(-1)?.members.push(name);
	}
	return groups;
})();
const LOCKED_GROUP_MEMBERS = new Set(LOCKED_FIELD_GROUPS.flatMap((group) => group.members));
function groupOf(field) {
	return LOCKED_FIELD_GROUPS.find((group) => group.members.includes(field));
}
function groupLockReason(group) {
	return `The ${group.heading.toLowerCase()} is on every contract form`;
}
const SYSTEM_TAB_IDS = /* @__PURE__ */ new Set([
	"log",
	"documents",
	"addendum"
]);
const MAX_ID_LENGTH = 40;
function apply(document, op, rules) {
	switch (op.kind) {
		case "placeField": return placeField(setFlags(document, op.field, { visible: true }, rules), op.field, op.section, op.index);
		case "moveField": return placeField(document, op.field, op.section, op.index);
		case "addTab": return addTab(document, op.label);
		case "renameTab": return renameTab(document, op.tab, op.label);
		case "moveTab": return moveTab(document, op.tab, op.index);
		case "deleteTab": return deleteTab(document, op.tab, rules);
		case "addSection": return addSection(document, op.tab, op.label);
		case "renameSection": return renameSection(document, op.section, op.label);
		case "moveSection": return moveSection(document, op.section, op.tab, op.index);
		case "deleteSection": return deleteSection(document, op.section, rules);
		case "setFieldFlags": return setFlags(document, op.field, op.flags, rules);
		case "setPresentation": return setPresentation(document, op.field, op.presentation);
		case "moveCollection": return moveCollection(document, op.collection, op.tab);
		case "setCollectionFlags": return setCollectionFlags(document, op.collection, op.flags);
		case "setRemarkType": return withRemarkType(document, op.code, op.behaviour);
		case "setHomeGridColumns": return setHomeGridColumns(document, op.columns);
		case "setTabVisible": return setTabVisible(document, op.tab, op.visible);
		case "setSectionVisible": return document.sections.some((section) => section.id === op.section) ? {
			...document,
			sections: document.sections.map((section) => section.id === op.section ? {
				...section,
				visible: op.visible
			} : section)
		} : document;
		case "setAttributes": return {
			...document,
			attributes: {
				...document.attributes,
				...op.attributes
			}
		};
		case "replace": return op.document;
	}
}
function orderedTabs(document) {
	return [...document.tabs].sort((left, right) => left.order - right.order);
}
function sectionsOf(document, tab) {
	return document.sections.filter((section) => section.tab === tab).sort((left, right) => left.order - right.order);
}
function fieldsOf(document, section) {
	return Object.entries(document.fields).filter(([, behaviour]) => behaviour.section === section).sort(([leftName, left], [rightName, right]) => left.order - right.order || leftName.localeCompare(rightName)).map(([name]) => name);
}
function placedFieldsOf(document, section) {
	return fieldsOf(document, section).filter((name) => document.fields[name].visible);
}
function emptyItems(document) {
	const blockTabs = new Set(COLLECTION_BLOCKS.map((block) => collectionBlockTab(block, document.collections)));
	return {
		tabs: new Set(document.tabs.filter((tab) => !document.sections.some((section) => section.tab === tab.id) && !blockTabs.has(tab.id)).map((tab) => tab.id)),
		sections: new Set(document.sections.filter((section) => placedFieldsOf(document, section.id).length === 0).map((section) => section.id))
	};
}
function blockTab(document, block) {
	return collectionBlockTab(block, document.collections);
}
function idFromLabel(label, taken, fallback) {
	const base = label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_ID_LENGTH).replace(/-+$/g, "") || fallback;
	for (let attempt = 1;; attempt++) {
		const suffix = attempt === 1 ? "" : `-${attempt}`;
		const candidate = `${base.slice(0, MAX_ID_LENGTH - suffix.length).replace(/-+$/g, "")}${suffix}`;
		if (!taken.has(candidate) && !SYSTEM_TAB_IDS.has(candidate)) return candidate;
	}
}
function placeField(document, field, section, index) {
	const behaviour = document.fields[field];
	if (behaviour === void 0 || !document.sections.some((candidate) => candidate.id === section)) return document;
	const placed = placedFieldsOf(document, section).filter((name) => name !== field);
	const unplaced = fieldsOf(document, section).filter((name) => name !== field && !document.fields[name].visible);
	const clamped = Math.max(0, Math.min(index, placed.length));
	const order = [
		...placed.slice(0, clamped),
		field,
		...placed.slice(clamped),
		...unplaced
	];
	const fields = { ...document.fields };
	if (behaviour.section !== section) fieldsOf(document, behaviour.section).filter((name) => name !== field).forEach((name, position) => fields[name] = {
		...fields[name],
		order: position + 1
	});
	order.forEach((name, position) => fields[name] = {
		...fields[name],
		section,
		order: position + 1
	});
	return {
		...document,
		fields
	};
}
function setFlags(document, field, requested, rules) {
	const behaviour = document.fields[field];
	const registry = rules.fields[field];
	if (behaviour === void 0) return document;
	const flags = LOCKED_GROUP_MEMBERS.has(field) ? {
		...requested,
		visible: true
	} : requested;
	let next = {
		...behaviour,
		...flags
	};
	if (flags.required === true) next = {
		...next,
		visible: true
	};
	if (flags.visible === false) next = {
		...next,
		required: false
	};
	if (registry?.readOnly === true) next = {
		...next,
		required: false
	};
	if (registry !== void 0 && !registry.configurable) next = {
		...next,
		visible: true,
		...registry.systemRequired ? { required: true } : {}
	};
	if (rules.ctrmRequired?.has(field) === true && registry?.readOnly !== true) next = {
		...next,
		visible: true,
		required: true
	};
	return sameFlags(behaviour, next) ? document : {
		...document,
		fields: {
			...document.fields,
			[field]: next
		}
	};
}
function setPresentation(document, field, presentation) {
	const behaviour = document.fields[field];
	if (behaviour === void 0) return document;
	const cleaned = Object.fromEntries(Object.entries({
		...behaviour.presentation,
		...presentation
	}).filter(([, value]) => value !== void 0 && value !== null && value !== ""));
	const { presentation: _dropped, ...rest } = behaviour;
	return {
		...document,
		fields: {
			...document.fields,
			[field]: Object.keys(cleaned).length === 0 ? rest : {
				...rest,
				presentation: cleaned
			}
		}
	};
}
function sameFlags(left, right) {
	return left.visible === right.visible && left.required === right.required && left.readOnly === right.readOnly && left.borderWarning === right.borderWarning && left.excludeFromCopy === right.excludeFromCopy && left.excludeFromTemplateCopy === right.excludeFromTemplateCopy;
}
function addTab(document, label) {
	const text = label.trim();
	if (text === "") return document;
	const id = idFromLabel(text, new Set(document.tabs.map((tab) => tab.id)), "tab");
	return renumberTabs({
		...document,
		tabs: [...orderedTabs(document), {
			id,
			label: text,
			order: Number.MAX_SAFE_INTEGER,
			visible: true
		}]
	});
}
function renameTab(document, tab, label) {
	const text = label.trim();
	if (text === "" || !document.tabs.some((candidate) => candidate.id === tab)) return document;
	return {
		...document,
		tabs: document.tabs.map((candidate) => candidate.id === tab ? {
			...candidate,
			label: text
		} : candidate)
	};
}
function moveTab(document, tab, index) {
	const ordered = orderedTabs(document);
	const moving = ordered.find((candidate) => candidate.id === tab);
	if (moving === void 0) return document;
	const rest = ordered.filter((candidate) => candidate.id !== tab);
	const clamped = Math.max(0, Math.min(index, rest.length));
	const tabs = [
		...rest.slice(0, clamped),
		moving,
		...rest.slice(clamped)
	].map((candidate, position) => ({
		...candidate,
		order: position + 1
	}));
	return tabs.every((candidate, position) => candidate.id === ordered[position].id) ? document : {
		...document,
		tabs
	};
}
function deleteTab(document, tab, rules) {
	const remaining = orderedTabs(document).filter((candidate) => candidate.id !== tab);
	if (remaining.length === document.tabs.length || !remaining.some((candidate) => candidate.visible)) return document;
	let next = {
		...document,
		tabs: remaining
	};
	for (const section of sectionsOf(document, tab)) next = deleteSection(next, section.id, rules, true);
	const collections = { ...next.collections ?? {} };
	for (const block of COLLECTION_BLOCKS) if (collectionBlockTab(block, next.collections) === tab) for (const name of [block.collection, ...block.alsoMoves]) collections[name] = {
		...defaultCollection(next, name),
		tab: remaining[0].id
	};
	return renumberTabs({
		...next,
		collections,
		sections: next.sections
	});
}
function setTabVisible(document, tab, visible) {
	const tabs = document.tabs.map((candidate) => candidate.id === tab ? {
		...candidate,
		visible
	} : candidate);
	return !tabs.some((candidate) => candidate.visible) || !document.tabs.some((candidate) => candidate.id === tab) ? document : {
		...document,
		tabs
	};
}
function renumberTabs(document) {
	return {
		...document,
		tabs: orderedTabs(document).map((tab, position) => ({
			...tab,
			order: position + 1
		}))
	};
}
function addSection(document, tab, label) {
	const text = label.trim();
	if (text === "" || !document.tabs.some((candidate) => candidate.id === tab)) return document;
	const id = idFromLabel(text, new Set(document.sections.map((section) => section.id)), "section");
	return renumberSections({
		...document,
		sections: [...document.sections, {
			id,
			label: text,
			tab,
			order: Number.MAX_SAFE_INTEGER,
			visible: true
		}]
	});
}
function renameSection(document, section, label) {
	const text = label.trim();
	if (text === "" || !document.sections.some((candidate) => candidate.id === section)) return document;
	return {
		...document,
		sections: document.sections.map((candidate) => candidate.id === section ? {
			...candidate,
			label: text
		} : candidate)
	};
}
function moveSection(document, section, tab, index) {
	const moving = document.sections.find((candidate) => candidate.id === section);
	if (moving === void 0 || !document.tabs.some((candidate) => candidate.id === tab)) return document;
	const target = sectionsOf(document, tab).filter((candidate) => candidate.id !== section);
	const clamped = Math.max(0, Math.min(index, target.length));
	const reordered = [
		...target.slice(0, clamped),
		{
			...moving,
			tab
		},
		...target.slice(clamped)
	];
	const byId = new Map(reordered.map((candidate, position) => [candidate.id, {
		...candidate,
		order: position + 1
	}]));
	return renumberSections({
		...document,
		sections: document.sections.map((candidate) => byId.get(candidate.id) ?? candidate)
	});
}
function deleteSection(document, section, rules, force = false) {
	const remaining = document.sections.filter((candidate) => candidate.id !== section);
	if (remaining.length === document.sections.length || remaining.length === 0 && !force) return document;
	const home = orderedTabs(document).flatMap((tab) => sectionsOf({
		...document,
		sections: remaining
	}, tab.id)).find(() => true);
	if (home === void 0) return document;
	let next = {
		...document,
		sections: remaining
	};
	for (const field of fieldsOf(document, section)) {
		next = placeField(next, field, home.id, Number.MAX_SAFE_INTEGER);
		next = setFlags(next, field, { visible: false }, rules);
	}
	return renumberSections(next);
}
function renumberSections(document) {
	const ordered = orderedTabs(document).flatMap((tab) => sectionsOf(document, tab.id));
	const orphans = document.sections.filter((section) => !ordered.includes(section));
	const order = new Map([...ordered, ...orphans].map((section, position) => [section.id, position + 1]));
	return {
		...document,
		sections: document.sections.map((section) => ({
			...section,
			order: order.get(section.id)
		}))
	};
}
function moveCollection(document, collection, tab) {
	const block = COLLECTION_BLOCKS.find((candidate) => candidate.collection === collection);
	if (block === void 0 || !document.tabs.some((candidate) => candidate.id === tab) || collectionBlockTab(block, document.collections) === tab) return document;
	const collections = { ...document.collections ?? {} };
	for (const name of [block.collection, ...block.alsoMoves]) {
		const { tab: _previous, ...flags } = defaultCollection(document, name);
		collections[name] = tab === block.layoutTab ? flags : {
			...flags,
			tab
		};
	}
	return {
		...document,
		collections
	};
}
function setCollectionFlags(document, collection, flags) {
	return {
		...document,
		collections: {
			...document.collections ?? {},
			[collection]: {
				...defaultCollection(document, collection),
				...flags
			}
		}
	};
}
function withRemarkType(document, code, behaviour) {
	const next = {
		visible: behaviour.visible,
		required: behaviour.visible && behaviour.required
	};
	return {
		...document,
		remarkTypes: {
			...document.remarkTypes ?? {},
			[code]: next
		}
	};
}
function setHomeGridColumns(document, columns) {
	const { homeGridColumns: _previous, ...attributes } = document.attributes;
	return {
		...document,
		attributes: columns === void 0 ? attributes : {
			...attributes,
			homeGridColumns: columns
		}
	};
}
function defaultCollection(document, name) {
	return document.collections?.[name] ?? {
		excludeFromCopy: false,
		excludeFromTemplateCopy: false
	};
}
const UNDO_LIMIT = 100;
var BuilderHistory = class BuilderHistory {
	present;
	past;
	future;
	constructor(present, past, future) {
		this.present = present;
		this.past = past;
		this.future = future;
	}
	static start(document) {
		return new BuilderHistory(document, [], []);
	}
	get canUndo() {
		return this.past.length > 0;
	}
	get canRedo() {
		return this.future.length > 0;
	}
	get depth() {
		return this.past.length;
	}
	apply(op, rules) {
		const next = apply(this.present, op, rules);
		if (next === this.present) return this;
		return new BuilderHistory(next, [...this.past, this.present].slice(-100), []);
	}
	undo() {
		if (!this.canUndo) return this;
		return new BuilderHistory(this.past[this.past.length - 1], this.past.slice(0, -1), [this.present, ...this.future]);
	}
	redo() {
		if (!this.canRedo) return this;
		return new BuilderHistory(this.future[0], [...this.past, this.present], this.future.slice(1));
	}
};
var BuilderJsonDialogComponent = class BuilderJsonDialogComponent {
	data = inject(DIALOG_DATA);
	ref = inject(DialogRef);
	text = signal("", ...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	problems = signal([], ...ngDevMode ? [{ debugName: "problems" }] : /* istanbul ignore next */ []);
	empty = computed(() => this.text().trim() === "", ...ngDevMode ? [{ debugName: "empty" }] : /* istanbul ignore next */ []);
	edit(text) {
		this.text.set(text);
		this.problems.set([]);
	}
	readFile(event) {
		(event.target.files?.[0])?.text().then((text) => this.edit(text));
	}
	import() {
		if (this.empty()) return;
		const result = this.data.check(this.text());
		if (result.ok) this.ref.close({
			document: result.document,
			ignored: result.ignored,
			added: result.added
		});
		else this.problems.set(result.problems);
	}
	cancel() {
		this.ref.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderJsonDialogComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: BuilderJsonDialogComponent,
		isStandalone: true,
		selector: "cws-builder-json-dialog",
		host: {
			attributes: {
				"role": "dialog",
				"aria-modal": "true"
			},
			listeners: { "keydown.escape": "cancel()" },
			properties: { "attr.aria-labelledby": "\"builder-json-title\"" },
			classAttribute: "cws:block cws:w-[48rem] cws:max-w-full cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800"
		},
		ngImport: i0,
		template: `
    <form (submit)="$event.preventDefault(); import()">
      <h2 id="builder-json-title" class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100">Import JSON</h2>
      <p class="cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
        Paste a form configuration, as Export gives it. It replaces the draft, and Undo brings the draft back. Nothing is saved until Save.
      </p>

      <label for="builder-json-text" class="cws:mt-4 cws:block cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-300">
        Form configuration JSON
      </label>
      <textarea
        #area
        id="builder-json-text"
        rows="16"
        spellcheck="false"
        autocomplete="off"
        class="scoular-form-input cws:mt-1 cws:block cws:w-full cws:font-mono cws:text-xs"
        [value]="text()"
        (input)="edit(area.value)"
        data-testid="builder-json-text"
      ></textarea>

      <label class="cws:mt-2 cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300">
        Or choose a file
        <input type="file" accept="application/json,.json" class="cws:text-sm" (change)="readFile($event)" data-testid="builder-json-file" />
      </label>

      @if (problems().length > 0) {
        <div role="alert" class="cws:mt-4 cws:text-sm cws:text-red-700 cws:dark:text-red-300" data-testid="builder-json-problems">
          <p class="cws:font-semibold">Nothing was imported:</p>
          <ul class="cws:mt-1 cws:list-disc cws:pl-5">
            @for (problem of problems(); track $index) {
              <li>{{ problem }}</li>
            }
          </ul>
        </div>
      }

      <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
        <button type="button" class="scoular-btn scoular-btn-secondary" (click)="cancel()">Cancel</button>
        <button type="submit" class="scoular-btn scoular-btn-primary" [disabled]="empty()">Import</button>
      </div>
    </form>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderJsonDialogComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-builder-json-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "cws:block cws:w-[48rem] cws:max-w-full cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800",
				role: "dialog",
				"aria-modal": "true",
				"[attr.aria-labelledby]": "\"builder-json-title\"",
				"(keydown.escape)": "cancel()"
			},
			template: `
    <form (submit)="$event.preventDefault(); import()">
      <h2 id="builder-json-title" class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100">Import JSON</h2>
      <p class="cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
        Paste a form configuration, as Export gives it. It replaces the draft, and Undo brings the draft back. Nothing is saved until Save.
      </p>

      <label for="builder-json-text" class="cws:mt-4 cws:block cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-300">
        Form configuration JSON
      </label>
      <textarea
        #area
        id="builder-json-text"
        rows="16"
        spellcheck="false"
        autocomplete="off"
        class="scoular-form-input cws:mt-1 cws:block cws:w-full cws:font-mono cws:text-xs"
        [value]="text()"
        (input)="edit(area.value)"
        data-testid="builder-json-text"
      ></textarea>

      <label class="cws:mt-2 cws:flex cws:items-center cws:gap-2 cws:text-sm cws:text-slate-700 cws:dark:text-slate-300">
        Or choose a file
        <input type="file" accept="application/json,.json" class="cws:text-sm" (change)="readFile($event)" data-testid="builder-json-file" />
      </label>

      @if (problems().length > 0) {
        <div role="alert" class="cws:mt-4 cws:text-sm cws:text-red-700 cws:dark:text-red-300" data-testid="builder-json-problems">
          <p class="cws:font-semibold">Nothing was imported:</p>
          <ul class="cws:mt-1 cws:list-disc cws:pl-5">
            @for (problem of problems(); track $index) {
              <li>{{ problem }}</li>
            }
          </ul>
        </div>
      }

      <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
        <button type="button" class="scoular-btn scoular-btn-secondary" (click)="cancel()">Cancel</button>
        <button type="submit" class="scoular-btn scoular-btn-primary" [disabled]="empty()">Import</button>
      </div>
    </form>
  `
		}]
	}]
});
function injectBuilderJsonImport() {
	const dialog = inject(Dialog);
	return (request) => dialog.open(BuilderJsonDialogComponent, {
		data: request,
		disableClose: true,
		autoFocus: "#builder-json-text"
	}).closed.pipe(map((result) => result ?? null));
}
var BuilderItemMenuComponent = class BuilderItemMenuComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	moveLabel = input("Move to", ...ngDevMode ? [{ debugName: "moveLabel" }] : /* istanbul ignore next */ []);
	targets = input([], ...ngDevMode ? [{ debugName: "targets" }] : /* istanbul ignore next */ []);
	actions = input([], ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
	moveTo = output();
	leading = computed(() => this.actions().filter((action) => !action.destructive), ...ngDevMode ? [{ debugName: "leading" }] : /* istanbul ignore next */ []);
	trailing = computed(() => this.actions().filter((action) => action.destructive), ...ngDevMode ? [{ debugName: "trailing" }] : /* istanbul ignore next */ []);
	runAction(action) {
		if (!action.refusal) action.run();
	}
	choose(target) {
		if (!target.current) this.moveTo.emit(target.id);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderItemMenuComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: BuilderItemMenuComponent,
		isStandalone: true,
		selector: "cms-builder-item-menu",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			moveLabel: {
				classPropertyName: "moveLabel",
				publicName: "moveLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			targets: {
				classPropertyName: "targets",
				publicName: "targets",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { moveTo: "moveTo" },
		ngImport: i0,
		template: `
    <button
      type="button"
      class="cws:flex cws:size-6 cws:items-center cws:justify-center cws:rounded cws:text-slate-400 cws:hover:bg-slate-200 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-500 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-200"
      aria-haspopup="menu"
      [attr.aria-label]="label()"
      [title]="label()"
      [cdkMenuTriggerFor]="menu"
      (click)="$event.stopPropagation()"
    >
      <svg aria-hidden="true" viewBox="0 0 16 16" class="cws:size-4" fill="currentColor">
        <circle cx="3" cy="8" r="1.4" />
        <circle cx="8" cy="8" r="1.4" />
        <circle cx="13" cy="8" r="1.4" />
      </svg>
    </button>

    <ng-template #menu>
      <div cdkMenu class="scoular-dropdown cws:static cws:mt-1 cws:min-w-48" [attr.aria-label]="label()">
        <!-- Inline in both loops, not a shared template: the menu finds its items where they are declared. -->
        @for (action of leading(); track action.label) {
          <button
            type="button"
            cdkMenuItem
            class="scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0"
            [class.cws:cursor-not-allowed]="!!action.refusal"
            [class.cws:opacity-60]="!!action.refusal"
            [cdkMenuItemDisabled]="!!action.refusal"
            (cdkMenuItemTriggered)="runAction(action)"
          >
            <span>{{ action.label }}</span>
            @if (action.refusal; as reason) {
              <span class="cws:max-w-64 cws:text-xs cws:whitespace-normal cws:text-slate-500 cws:dark:text-slate-400">{{ reason }}</span>
            }
          </button>
        }
        @if (targets().length > 0) {
          <div
            class="cws:border-t cws:border-slate-100 cws:px-3 cws:pt-2 cws:pb-1 cws:text-[11px] cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:first:border-t-0 cws:dark:border-slate-700 cws:dark:text-slate-400"
            aria-hidden="true"
          >
            {{ moveLabel() }}
          </div>
          <div cdkMenuGroup role="group" [attr.aria-label]="moveLabel()" class="cws:max-h-56 cws:overflow-y-auto">
            @for (target of targets(); track target.id) {
              <button
                type="button"
                cdkMenuItem
                class="scoular-dropdown-item cws:flex cws:items-center cws:gap-2"
                [class.cws:font-semibold]="target.current"
                [cdkMenuItemDisabled]="!!target.current"
                (cdkMenuItemTriggered)="choose(target)"
              >
                {{ target.label }}
                @if (target.current) {
                  <span class="cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400">(here)</span>
                }
              </button>
            }
          </div>
        }
        @if (trailing().length > 0) {
          <div class="cws:border-t cws:border-slate-100 cws:dark:border-slate-700" role="separator"></div>
          @for (action of trailing(); track action.label) {
            <button
              type="button"
              cdkMenuItem
              class="scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0"
              [class.cws:text-red-700]="!action.refusal"
              [class.cws:dark:text-red-300]="!action.refusal"
              [class.cws:cursor-not-allowed]="!!action.refusal"
              [class.cws:opacity-60]="!!action.refusal"
              [cdkMenuItemDisabled]="!!action.refusal"
              (cdkMenuItemTriggered)="runAction(action)"
            >
              <span>{{ action.label }}</span>
              @if (action.refusal; as reason) {
                <span class="cws:max-w-64 cws:text-xs cws:whitespace-normal cws:text-slate-500 cws:dark:text-slate-400">{{ reason }}</span>
              }
            </button>
          }
        }
      </div>
    </ng-template>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: CdkMenu,
				selector: "[cdkMenu]",
				outputs: ["closed"],
				exportAs: ["cdkMenu"]
			},
			{
				kind: "directive",
				type: CdkMenuGroup,
				selector: "[cdkMenuGroup]",
				exportAs: ["cdkMenuGroup"]
			},
			{
				kind: "directive",
				type: CdkMenuItem,
				selector: "[cdkMenuItem]",
				inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"],
				outputs: ["cdkMenuItemTriggered"],
				exportAs: ["cdkMenuItem"]
			},
			{
				kind: "directive",
				type: CdkMenuTrigger,
				selector: "[cdkMenuTriggerFor]",
				inputs: [
					"cdkMenuTriggerFor",
					"cdkMenuPosition",
					"cdkMenuTriggerData",
					"cdkMenuTriggerTransformOriginOn"
				],
				outputs: ["cdkMenuOpened", "cdkMenuClosed"],
				exportAs: ["cdkMenuTriggerFor"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderItemMenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-builder-item-menu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				CdkMenu,
				CdkMenuGroup,
				CdkMenuItem,
				CdkMenuTrigger
			],
			template: `
    <button
      type="button"
      class="cws:flex cws:size-6 cws:items-center cws:justify-center cws:rounded cws:text-slate-400 cws:hover:bg-slate-200 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-500 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-200"
      aria-haspopup="menu"
      [attr.aria-label]="label()"
      [title]="label()"
      [cdkMenuTriggerFor]="menu"
      (click)="$event.stopPropagation()"
    >
      <svg aria-hidden="true" viewBox="0 0 16 16" class="cws:size-4" fill="currentColor">
        <circle cx="3" cy="8" r="1.4" />
        <circle cx="8" cy="8" r="1.4" />
        <circle cx="13" cy="8" r="1.4" />
      </svg>
    </button>

    <ng-template #menu>
      <div cdkMenu class="scoular-dropdown cws:static cws:mt-1 cws:min-w-48" [attr.aria-label]="label()">
        <!-- Inline in both loops, not a shared template: the menu finds its items where they are declared. -->
        @for (action of leading(); track action.label) {
          <button
            type="button"
            cdkMenuItem
            class="scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0"
            [class.cws:cursor-not-allowed]="!!action.refusal"
            [class.cws:opacity-60]="!!action.refusal"
            [cdkMenuItemDisabled]="!!action.refusal"
            (cdkMenuItemTriggered)="runAction(action)"
          >
            <span>{{ action.label }}</span>
            @if (action.refusal; as reason) {
              <span class="cws:max-w-64 cws:text-xs cws:whitespace-normal cws:text-slate-500 cws:dark:text-slate-400">{{ reason }}</span>
            }
          </button>
        }
        @if (targets().length > 0) {
          <div
            class="cws:border-t cws:border-slate-100 cws:px-3 cws:pt-2 cws:pb-1 cws:text-[11px] cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:first:border-t-0 cws:dark:border-slate-700 cws:dark:text-slate-400"
            aria-hidden="true"
          >
            {{ moveLabel() }}
          </div>
          <div cdkMenuGroup role="group" [attr.aria-label]="moveLabel()" class="cws:max-h-56 cws:overflow-y-auto">
            @for (target of targets(); track target.id) {
              <button
                type="button"
                cdkMenuItem
                class="scoular-dropdown-item cws:flex cws:items-center cws:gap-2"
                [class.cws:font-semibold]="target.current"
                [cdkMenuItemDisabled]="!!target.current"
                (cdkMenuItemTriggered)="choose(target)"
              >
                {{ target.label }}
                @if (target.current) {
                  <span class="cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400">(here)</span>
                }
              </button>
            }
          </div>
        }
        @if (trailing().length > 0) {
          <div class="cws:border-t cws:border-slate-100 cws:dark:border-slate-700" role="separator"></div>
          @for (action of trailing(); track action.label) {
            <button
              type="button"
              cdkMenuItem
              class="scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0"
              [class.cws:text-red-700]="!action.refusal"
              [class.cws:dark:text-red-300]="!action.refusal"
              [class.cws:cursor-not-allowed]="!!action.refusal"
              [class.cws:opacity-60]="!!action.refusal"
              [cdkMenuItemDisabled]="!!action.refusal"
              (cdkMenuItemTriggered)="runAction(action)"
            >
              <span>{{ action.label }}</span>
              @if (action.refusal; as reason) {
                <span class="cws:max-w-64 cws:text-xs cws:whitespace-normal cws:text-slate-500 cws:dark:text-slate-400">{{ reason }}</span>
              }
            </button>
          }
        }
      </div>
    </ng-template>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		moveLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "moveLabel",
				required: false
			}]
		}],
		targets: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "targets",
				required: false
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: false
			}]
		}],
		moveTo: [{
			type: i0.Output,
			args: ["moveTo"]
		}]
	}
});
const FORM_BUILDER_SAMPLE_VALUES = new InjectionToken("FORM_BUILDER_SAMPLE_VALUES");
const BUILT_IN_SAMPLE_VALUES = {
	ContractPrefixType: "P",
	ContractPrefixCommodity: "C",
	ContractNumber: "999999",
	CustomerId: "AAA999999",
	CustomerContract: "AAA999999",
	ContractDate: "2026-10-28",
	Quantity: 5e3,
	Price: 4.25,
	BasisPrice: .15,
	HedgePrice: 4.1,
	NamedPlace: "Example Terminal",
	ShipPeriodDescription: "Nov 2026 through Dec 2026"
};
const NOT_BUILT_MESSAGE = "The live preview is not built on this server. Showing the last saved form for these dimensions instead.";
var BuilderPreviewComponent = class BuilderPreviewComponent {
	source = inject(FORM_CONFIG_SOURCE, { optional: true });
	document = input.required(...ngDevMode ? [{ debugName: "document" }] : /* istanbul ignore next */ []);
	resolutionKey = input.required(...ngDevMode ? [{ debugName: "resolutionKey" }] : /* istanbul ignore next */ []);
	problemsChange = output();
	notBuiltMessage = NOT_BUILT_MESSAGE;
	modes = [{
		id: "create",
		label: "Create"
	}, {
		id: "details",
		label: "Details"
	}];
	widths = [{
		id: "desktop",
		label: "Desktop"
	}, {
		id: "narrow",
		label: "Narrow"
	}];
	mode = signal("create", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	width = signal("desktop", ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	fullScreen = signal(false, ...ngDevMode ? [{ debugName: "fullScreen" }] : /* istanbul ignore next */ []);
	previewTab = signal(null, ...ngDevMode ? [{ debugName: "previewTab" }] : /* istanbul ignore next */ []);
	sampleValues = inject(FORM_BUILDER_SAMPLE_VALUES, { optional: true }) ?? BUILT_IN_SAMPLE_VALUES;
	wideFields = CONTRACT_LAYOUT_WIDE_FIELDS;
	groupHeadings = CONTRACT_LAYOUT_GROUP_HEADINGS;
	fieldCtrmNames = CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT;
	readOnlyFields = CONTRACT_READ_ONLY_FIELDS;
	request = computed(() => ({
		document: this.document(),
		key: this.resolutionKey()
	}), ...ngDevMode ? [{ debugName: "request" }] : /* istanbul ignore next */ []);
	result = toSignal(toObservable(this.request).pipe(debounceTime(300), switchMap(({ document, key }) => this.previewOf(key, document))), { initialValue: null });
	bundle = signal(null, ...ngDevMode ? [{ debugName: "bundle" }] : /* istanbul ignore next */ []);
	notBuilt = signal(false, ...ngDevMode ? [{ debugName: "notBuilt" }] : /* istanbul ignore next */ []);
	problems = signal(null, ...ngDevMode ? [{ debugName: "problems" }] : /* istanbul ignore next */ []);
	failure = signal(null, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	generation = signal(0, ...ngDevMode ? [{ debugName: "generation" }] : /* istanbul ignore next */ []);
	formKey = computed(() => `preview-${this.generation()}`, ...ngDevMode ? [{ debugName: "formKey" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const state = this.result();
			if (state === null || state.status !== "loaded" && state.status !== "error") return;
			if (state.status === "error") {
				this.failure.set(state.error.message);
				return;
			}
			this.failure.set(null);
			const value = state.value;
			switch (value.kind) {
				case "loaded":
				case "fallback":
					this.bundle.set(value.bundle);
					this.generation.update((count) => count + 1);
					this.notBuilt.set(value.kind === "fallback");
					this.problems.set(null);
					this.problemsChange.emit(null);
					break;
				case "invalid":
					this.problems.set(Object.values(value.problems).flatMap((messages) => messages));
					this.problemsChange.emit(value.problems);
			}
		});
	}
	previewTabs = computed(() => {
		const config = this.bundle()?.config;
		return config === void 0 ? [] : [...tabsAfterCascade(config.tabs, config.sections)].sort((a, b) => a.order - b.order);
	}, ...ngDevMode ? [{ debugName: "previewTabs" }] : /* istanbul ignore next */ []);
	shownTab = computed(() => {
		const tabs = this.previewTabs();
		return tabs.find((tab) => tab.id === this.previewTab())?.id ?? tabs[0]?.id ?? null;
	}, ...ngDevMode ? [{ debugName: "shownTab" }] : /* istanbul ignore next */ []);
	sectionsOnTab = computed(() => (this.bundle()?.config.sections ?? []).filter((section) => section.tab === this.shownTab()).map((section) => section.componentName), ...ngDevMode ? [{ debugName: "sectionsOnTab" }] : /* istanbul ignore next */ []);
	blocksOnTab = computed(() => COLLECTION_BLOCKS.filter((block) => collectionBlockTab(block, this.bundle()?.config.collections) === this.shownTab()), ...ngDevMode ? [{ debugName: "blocksOnTab" }] : /* istanbul ignore next */ []);
	presentation = computed(() => {
		const layout = {
			halfFields: CONTRACT_LAYOUT_HALF_FIELDS,
			hiddenLabelFields: CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS,
			fieldNotes: CONTRACT_LAYOUT_FIELD_NOTES
		};
		const config = this.bundle()?.config;
		return config === void 0 ? layout : presentationMaps(config, layout, CONTRACT_LAYOUT_FIXED_WIDTH_FIELDS);
	}, ...ngDevMode ? [{ debugName: "presentation" }] : /* istanbul ignore next */ []);
	previewOf(key, document) {
		if (this.source === null) return of(remoteLoaded({ kind: "not-built" }));
		const fallback = () => this.source.load(key).pipe(map((state) => state.status === "loaded" ? remoteLoaded({
			kind: "fallback",
			bundle: state.value
		}) : state));
		if (this.source.preview === void 0) return fallback();
		return this.source.preview(key, document).pipe(switchMap((state) => state.status === "loaded" && state.value.kind === "not-built" ? fallback() : of(state)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderPreviewComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: BuilderPreviewComponent,
		isStandalone: true,
		selector: "cms-builder-preview",
		inputs: {
			document: {
				classPropertyName: "document",
				publicName: "document",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			resolutionKey: {
				classPropertyName: "resolutionKey",
				publicName: "resolutionKey",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { problemsChange: "problemsChange" },
		ngImport: i0,
		template: `
    <section
      class="scoular-card cws:flex cws:flex-col cws:gap-2 cws:p-3 cws:xl:h-full"
      [class.cws:fixed]="fullScreen()"
      [class.cws:inset-0]="fullScreen()"
      [class.cws:z-50]="fullScreen()"
      [class.cws:overflow-y-auto]="fullScreen()"
      aria-labelledby="builder-preview-heading"
      data-testid="builder-preview"
    >
      <div class="cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-2">
        <h3 id="builder-preview-heading" class="cws:mr-auto cws:flex cws:items-center cws:gap-2 cws:text-sm cws:font-semibold cws:text-slate-800 cws:dark:text-slate-100">
          <span class="cws:size-2 cws:rounded-full cws:bg-emerald-500" aria-hidden="true"></span>
          Live preview
        </h3>
        <!-- Segmented controls rather than buttons: they choose how the result is shown, they do not act. -->
        <div role="group" aria-label="Preview mode" class="cws:inline-flex cws:rounded-md cws:bg-slate-100 cws:p-0.5 cws:dark:bg-slate-900">
          @for (option of modes; track option.id) {
            <button
              type="button"
              class="cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white"
              [class.cws:bg-white]="mode() === option.id"
              [class.cws:shadow-sm]="mode() === option.id"
              [class.cws:text-slate-900]="mode() === option.id"
              [class.cws:dark:bg-slate-700]="mode() === option.id"
              [class.cws:dark:text-white]="mode() === option.id"
              [attr.aria-pressed]="mode() === option.id"
              (click)="mode.set(option.id)"
            >
              {{ option.label }}
            </button>
          }
        </div>
        <div role="group" aria-label="Preview width" class="cws:inline-flex cws:rounded-md cws:bg-slate-100 cws:p-0.5 cws:dark:bg-slate-900">
          @for (option of widths; track option.id) {
            <button
              type="button"
              class="cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white"
              [class.cws:bg-white]="width() === option.id"
              [class.cws:shadow-sm]="width() === option.id"
              [class.cws:text-slate-900]="width() === option.id"
              [class.cws:dark:bg-slate-700]="width() === option.id"
              [class.cws:dark:text-white]="width() === option.id"
              [attr.aria-pressed]="width() === option.id"
              (click)="width.set(option.id)"
              [attr.data-testid]="'builder-preview-' + option.id"
            >
              {{ option.label }}
            </button>
          }
        </div>
        <button
          type="button"
          class="cws:rounded-md cws:px-2 cws:py-1 cws:text-xs cws:font-medium cws:text-slate-600 cws:ring-1 cws:ring-slate-200 cws:hover:bg-slate-50 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:ring-slate-600 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white"
          [attr.aria-pressed]="fullScreen()"
          (click)="fullScreen.set(!fullScreen())"
          data-testid="builder-preview-full"
        >
          {{ fullScreen() ? 'Close full screen' : 'Full screen' }}
        </button>
      </div>

      @if (notBuilt()) {
        <p role="status" class="cws:text-xs cws:text-amber-800 cws:dark:text-amber-200" data-testid="builder-preview-not-built">{{ notBuiltMessage }}</p>
      }
      @if (problems(); as list) {
        <div role="alert" class="cws:text-xs cws:text-red-700 cws:dark:text-red-300" data-testid="builder-preview-problems">
          <p class="cws:font-medium">The server would refuse this draft:</p>
          <ul class="cws:list-disc cws:pl-4">
            @for (problem of list; track $index) {
              <li>{{ problem }}</li>
            }
          </ul>
        </div>
      }
      @if (failure(); as message) {
        <p role="status" class="cws:text-xs cws:text-red-700 cws:dark:text-red-300">{{ message }}</p>
      }

      <!--
        The canvas: a tinted surface under the form's own card, so it reads as the rendered result rather than one
        more configuration panel. Narrow keeps its phone-sized width, centred on the surface.
      -->
      <div class="cws:min-h-0 cws:flex-1 cws:overflow-y-auto cws:rounded-md cws:bg-slate-100 cws:p-3 cws:dark:bg-slate-900" data-testid="builder-preview-canvas">
      @if (bundle(); as loaded) {
        <div
          [class.cws:max-w-sm]="width() === 'narrow'"
          [class.cws:mx-auto]="width() === 'narrow'"
          data-testid="builder-preview-frame"
        >
          <!--
            The record screen's segmented tabs, class for class (contract-record-page.component.html), so
            the preview reads as the form it previews. Buttons rather than its links: these switch the
            preview, not the route.
          -->
          <div
            role="tablist"
            aria-label="Previewed tabs"
            class="cws:mb-3 cws:inline-flex cws:max-w-full cws:gap-0.5 cws:overflow-x-auto cws:rounded-xl cws:border cws:border-slate-200 cws:bg-slate-100 cws:p-1 cws:[scrollbar-width:thin] cws:dark:border-slate-700 cws:dark:bg-slate-800/70"
          >
            @for (tab of previewTabs(); track tab.id) {
              <button
                type="button"
                role="tab"
                class="cws:flex cws:items-center cws:gap-1.5 cws:rounded-lg cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:whitespace-nowrap cws:transition-colors cws:focus-visible:outline-2 cws:focus-visible:-outline-offset-2 cws:focus-visible:outline-scoular-blue"
                [class.cws:bg-white]="tab.id === shownTab()"
                [class.cws:text-scoular-blue]="tab.id === shownTab()"
                [class.cws:shadow-xs]="tab.id === shownTab()"
                [class.cws:ring-1]="tab.id === shownTab()"
                [class.cws:ring-slate-200]="tab.id === shownTab()"
                [class.cws:dark:bg-slate-700]="tab.id === shownTab()"
                [class.cws:dark:text-sky-300]="tab.id === shownTab()"
                [class.cws:dark:ring-slate-600]="tab.id === shownTab()"
                [class.cws:text-slate-600]="tab.id !== shownTab()"
                [class.cws:hover:bg-slate-200/70]="tab.id !== shownTab()"
                [class.cws:hover:text-slate-900]="tab.id !== shownTab()"
                [class.cws:dark:text-slate-400]="tab.id !== shownTab()"
                [class.cws:dark:hover:bg-slate-700/30]="tab.id !== shownTab()"
                [class.cws:dark:hover:text-slate-100]="tab.id !== shownTab()"
                [attr.aria-selected]="tab.id === shownTab()"
                (click)="previewTab.set(tab.id)"
                data-testid="builder-preview-tab"
              >
                {{ tab.label }}
              </button>
            }
          </div>
          @for (key of [formKey()]; track key) {
            <cms-contract-form
              [config]="loaded.config"
              [tradeUnit]="loaded.tradeUnit"
              [readOnly]="mode() === 'details'"
              [visibleSections]="sectionsOnTab()"
              [constraints]="loaded.constraints ?? null"
              [fieldNotes]="presentation().fieldNotes"
              [halfFields]="presentation().halfFields"
              [hiddenLabelFields]="presentation().hiddenLabelFields"
              [wideFields]="wideFields"
              [groupHeadings]="groupHeadings"
              [fieldCtrmNames]="fieldCtrmNames"
              [readOnlyFields]="readOnlyFields"
              [initialValues]="sampleValues"
              instanceId="builder-preview"
            />
          }
          @for (block of blocksOnTab(); track block.collection) {
            <p class="cws:mt-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="builder-preview-grid">
              {{ block.label }} grid
            </p>
          }
        </div>
      } @else {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">Composing the preview…</p>
      }
      </div>
    </section>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: ContractFormComponent,
			selector: "cms-contract-form",
			inputs: [
				"config",
				"tradeUnit",
				"facts",
				"readOnly",
				"instanceId",
				"visibleSections",
				"visibleFields",
				"hideEmptyFields",
				"fieldNotes",
				"pinnedNotes",
				"emptyNotes",
				"sectionNotes",
				"wideFields",
				"halfFields",
				"fieldCtrmNames",
				"constraints",
				"hiddenLabelFields",
				"groupHeadings",
				"readOnlyFields",
				"lockedFields",
				"fieldVerdicts",
				"fieldAddons",
				"initialValues",
				"defaultValues"
			],
			outputs: ["ready", "fieldBlur"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderPreviewComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-builder-preview",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ContractFormComponent],
			template: `
    <section
      class="scoular-card cws:flex cws:flex-col cws:gap-2 cws:p-3 cws:xl:h-full"
      [class.cws:fixed]="fullScreen()"
      [class.cws:inset-0]="fullScreen()"
      [class.cws:z-50]="fullScreen()"
      [class.cws:overflow-y-auto]="fullScreen()"
      aria-labelledby="builder-preview-heading"
      data-testid="builder-preview"
    >
      <div class="cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-2">
        <h3 id="builder-preview-heading" class="cws:mr-auto cws:flex cws:items-center cws:gap-2 cws:text-sm cws:font-semibold cws:text-slate-800 cws:dark:text-slate-100">
          <span class="cws:size-2 cws:rounded-full cws:bg-emerald-500" aria-hidden="true"></span>
          Live preview
        </h3>
        <!-- Segmented controls rather than buttons: they choose how the result is shown, they do not act. -->
        <div role="group" aria-label="Preview mode" class="cws:inline-flex cws:rounded-md cws:bg-slate-100 cws:p-0.5 cws:dark:bg-slate-900">
          @for (option of modes; track option.id) {
            <button
              type="button"
              class="cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white"
              [class.cws:bg-white]="mode() === option.id"
              [class.cws:shadow-sm]="mode() === option.id"
              [class.cws:text-slate-900]="mode() === option.id"
              [class.cws:dark:bg-slate-700]="mode() === option.id"
              [class.cws:dark:text-white]="mode() === option.id"
              [attr.aria-pressed]="mode() === option.id"
              (click)="mode.set(option.id)"
            >
              {{ option.label }}
            </button>
          }
        </div>
        <div role="group" aria-label="Preview width" class="cws:inline-flex cws:rounded-md cws:bg-slate-100 cws:p-0.5 cws:dark:bg-slate-900">
          @for (option of widths; track option.id) {
            <button
              type="button"
              class="cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white"
              [class.cws:bg-white]="width() === option.id"
              [class.cws:shadow-sm]="width() === option.id"
              [class.cws:text-slate-900]="width() === option.id"
              [class.cws:dark:bg-slate-700]="width() === option.id"
              [class.cws:dark:text-white]="width() === option.id"
              [attr.aria-pressed]="width() === option.id"
              (click)="width.set(option.id)"
              [attr.data-testid]="'builder-preview-' + option.id"
            >
              {{ option.label }}
            </button>
          }
        </div>
        <button
          type="button"
          class="cws:rounded-md cws:px-2 cws:py-1 cws:text-xs cws:font-medium cws:text-slate-600 cws:ring-1 cws:ring-slate-200 cws:hover:bg-slate-50 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:ring-slate-600 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white"
          [attr.aria-pressed]="fullScreen()"
          (click)="fullScreen.set(!fullScreen())"
          data-testid="builder-preview-full"
        >
          {{ fullScreen() ? 'Close full screen' : 'Full screen' }}
        </button>
      </div>

      @if (notBuilt()) {
        <p role="status" class="cws:text-xs cws:text-amber-800 cws:dark:text-amber-200" data-testid="builder-preview-not-built">{{ notBuiltMessage }}</p>
      }
      @if (problems(); as list) {
        <div role="alert" class="cws:text-xs cws:text-red-700 cws:dark:text-red-300" data-testid="builder-preview-problems">
          <p class="cws:font-medium">The server would refuse this draft:</p>
          <ul class="cws:list-disc cws:pl-4">
            @for (problem of list; track $index) {
              <li>{{ problem }}</li>
            }
          </ul>
        </div>
      }
      @if (failure(); as message) {
        <p role="status" class="cws:text-xs cws:text-red-700 cws:dark:text-red-300">{{ message }}</p>
      }

      <!--
        The canvas: a tinted surface under the form's own card, so it reads as the rendered result rather than one
        more configuration panel. Narrow keeps its phone-sized width, centred on the surface.
      -->
      <div class="cws:min-h-0 cws:flex-1 cws:overflow-y-auto cws:rounded-md cws:bg-slate-100 cws:p-3 cws:dark:bg-slate-900" data-testid="builder-preview-canvas">
      @if (bundle(); as loaded) {
        <div
          [class.cws:max-w-sm]="width() === 'narrow'"
          [class.cws:mx-auto]="width() === 'narrow'"
          data-testid="builder-preview-frame"
        >
          <!--
            The record screen's segmented tabs, class for class (contract-record-page.component.html), so
            the preview reads as the form it previews. Buttons rather than its links: these switch the
            preview, not the route.
          -->
          <div
            role="tablist"
            aria-label="Previewed tabs"
            class="cws:mb-3 cws:inline-flex cws:max-w-full cws:gap-0.5 cws:overflow-x-auto cws:rounded-xl cws:border cws:border-slate-200 cws:bg-slate-100 cws:p-1 cws:[scrollbar-width:thin] cws:dark:border-slate-700 cws:dark:bg-slate-800/70"
          >
            @for (tab of previewTabs(); track tab.id) {
              <button
                type="button"
                role="tab"
                class="cws:flex cws:items-center cws:gap-1.5 cws:rounded-lg cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:whitespace-nowrap cws:transition-colors cws:focus-visible:outline-2 cws:focus-visible:-outline-offset-2 cws:focus-visible:outline-scoular-blue"
                [class.cws:bg-white]="tab.id === shownTab()"
                [class.cws:text-scoular-blue]="tab.id === shownTab()"
                [class.cws:shadow-xs]="tab.id === shownTab()"
                [class.cws:ring-1]="tab.id === shownTab()"
                [class.cws:ring-slate-200]="tab.id === shownTab()"
                [class.cws:dark:bg-slate-700]="tab.id === shownTab()"
                [class.cws:dark:text-sky-300]="tab.id === shownTab()"
                [class.cws:dark:ring-slate-600]="tab.id === shownTab()"
                [class.cws:text-slate-600]="tab.id !== shownTab()"
                [class.cws:hover:bg-slate-200/70]="tab.id !== shownTab()"
                [class.cws:hover:text-slate-900]="tab.id !== shownTab()"
                [class.cws:dark:text-slate-400]="tab.id !== shownTab()"
                [class.cws:dark:hover:bg-slate-700/30]="tab.id !== shownTab()"
                [class.cws:dark:hover:text-slate-100]="tab.id !== shownTab()"
                [attr.aria-selected]="tab.id === shownTab()"
                (click)="previewTab.set(tab.id)"
                data-testid="builder-preview-tab"
              >
                {{ tab.label }}
              </button>
            }
          </div>
          @for (key of [formKey()]; track key) {
            <cms-contract-form
              [config]="loaded.config"
              [tradeUnit]="loaded.tradeUnit"
              [readOnly]="mode() === 'details'"
              [visibleSections]="sectionsOnTab()"
              [constraints]="loaded.constraints ?? null"
              [fieldNotes]="presentation().fieldNotes"
              [halfFields]="presentation().halfFields"
              [hiddenLabelFields]="presentation().hiddenLabelFields"
              [wideFields]="wideFields"
              [groupHeadings]="groupHeadings"
              [fieldCtrmNames]="fieldCtrmNames"
              [readOnlyFields]="readOnlyFields"
              [initialValues]="sampleValues"
              instanceId="builder-preview"
            />
          }
          @for (block of blocksOnTab(); track block.collection) {
            <p class="cws:mt-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400" data-testid="builder-preview-grid">
              {{ block.label }} grid
            </p>
          }
        </div>
      } @else {
        <p class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">Composing the preview…</p>
      }
      </div>
    </section>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		document: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "document",
				required: true
			}]
		}],
		resolutionKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resolutionKey",
				required: true
			}]
		}],
		problemsChange: [{
			type: i0.Output,
			args: ["problemsChange"]
		}]
	}
});
var BuilderPromptDialogComponent = class BuilderPromptDialogComponent {
	data = inject(DIALOG_DATA);
	ref = inject(DialogRef);
	value = signal(this.data.value ?? "", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	empty = computed(() => this.value().trim() === "", ...ngDevMode ? [{ debugName: "empty" }] : /* istanbul ignore next */ []);
	confirm() {
		if (!this.empty()) this.ref.close(this.value());
	}
	cancel() {
		this.ref.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderPromptDialogComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: BuilderPromptDialogComponent,
		isStandalone: true,
		selector: "cws-builder-prompt-dialog",
		host: {
			attributes: {
				"role": "dialog",
				"aria-modal": "true"
			},
			listeners: { "keydown.escape": "cancel()" },
			properties: { "attr.aria-labelledby": "\"builder-prompt-title\"" },
			classAttribute: "cws:block cws:w-[28rem] cws:max-w-full cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800"
		},
		ngImport: i0,
		template: `
    <form (submit)="$event.preventDefault(); confirm()">
      <h2 id="builder-prompt-title" class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100">
        {{ data.title }}
      </h2>

      <label for="builder-prompt-input" class="cws:mt-4 cws:block cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-300">
        {{ data.label }}
      </label>
      <input
        #input
        id="builder-prompt-input"
        type="text"
        autocomplete="off"
        class="scoular-form-input cws:mt-1 cws:block cws:w-full"
        [value]="value()"
        (input)="value.set(input.value)"
        (focus)="input.select()"
        data-testid="builder-prompt-input"
      />

      <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
        <button type="button" class="scoular-btn scoular-btn-secondary" (click)="cancel()">Cancel</button>
        <button type="submit" class="scoular-btn scoular-btn-primary" [disabled]="empty()">Confirm</button>
      </div>
    </form>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderPromptDialogComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-builder-prompt-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "cws:block cws:w-[28rem] cws:max-w-full cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800",
				role: "dialog",
				"aria-modal": "true",
				"[attr.aria-labelledby]": "\"builder-prompt-title\"",
				"(keydown.escape)": "cancel()"
			},
			template: `
    <form (submit)="$event.preventDefault(); confirm()">
      <h2 id="builder-prompt-title" class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100">
        {{ data.title }}
      </h2>

      <label for="builder-prompt-input" class="cws:mt-4 cws:block cws:text-sm cws:font-medium cws:text-slate-700 cws:dark:text-slate-300">
        {{ data.label }}
      </label>
      <input
        #input
        id="builder-prompt-input"
        type="text"
        autocomplete="off"
        class="scoular-form-input cws:mt-1 cws:block cws:w-full"
        [value]="value()"
        (input)="value.set(input.value)"
        (focus)="input.select()"
        data-testid="builder-prompt-input"
      />

      <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
        <button type="button" class="scoular-btn scoular-btn-secondary" (click)="cancel()">Cancel</button>
        <button type="submit" class="scoular-btn scoular-btn-primary" [disabled]="empty()">Confirm</button>
      </div>
    </form>
  `
		}]
	}]
});
function injectBuilderPrompt() {
	const dialog = inject(Dialog);
	return (request) => dialog.open(BuilderPromptDialogComponent, {
		data: request,
		disableClose: true,
		autoFocus: "#builder-prompt-input"
	}).closed.pipe(map((result) => typeof result === "string" ? result : null));
}
function ctrmRequiredComponents(registry, document) {
	const columns = ctrmRequiredFields(document);
	if (registry === null || columns.size === 0) return /* @__PURE__ */ new Set();
	return new Set(Object.entries(registry.fields).filter(([, field]) => columns.has(field.ctrmField) && !field.readOnly).map(([name]) => name));
}
function flagLock(field, key, rules) {
	const registry = rules.fields[field];
	if (registry === void 0) return null;
	if (key === "required" && registry.readOnly) return "CTRM sets this field";
	if (rules.ctrmRequired?.has(field) === true) return CTRM_REQUIRED_REASON;
	if (!registry.configurable) return key === "visible" ? "a driver is always shown" : registry.systemRequired ? "a driver is always required" : null;
	const group = groupOf(field);
	return key === "visible" && group !== void 0 ? groupLockReason(group) : null;
}
function withLocks(document, rules) {
	let next = document;
	for (const field of [...rules.ctrmRequired ?? [], ...LOCKED_GROUP_MEMBERS]) next = apply(next, {
		kind: "setFieldFlags",
		field,
		flags: {}
	}, rules);
	return withGroupsTogether(next, rules);
}
function groupsIn(document) {
	return LOCKED_FIELD_GROUPS.map((group) => ({
		...group,
		members: group.members.filter((name) => name in document.fields)
	})).filter((group) => group.members.length > 0).map((group) => ({
		...group,
		lead: group.members[0]
	}));
}
function groupLedBy(document, row) {
	return groupsIn(document).find((group) => group.lead === row);
}
function rowMembers(document, row) {
	return groupLedBy(document, row)?.members ?? [row];
}
function canvasRows(document, section) {
	const placed = placedFieldsOf(document, section);
	const folded = new Set(groupsIn(document).filter((group) => placed.includes(group.lead)).flatMap((group) => group.members.slice(1)));
	return placed.filter((name) => !folded.has(name));
}
function rowMoveOp(document, row, section, before, rules, kind = "moveField") {
	const members = rowMembers(document, row);
	if (members.length === 1) return {
		kind,
		field: row,
		section,
		index: indexBefore(document, row, section, before)
	};
	const moved = moveTogether(document, members, section, before, rules);
	return moved === document ? null : {
		kind: "replace",
		document: moved
	};
}
function indexBefore(document, field, section, before) {
	const index = before === null ? -1 : placedFieldsOf(document, section).filter((name) => name !== field).indexOf(before);
	return index < 0 ? Number.MAX_SAFE_INTEGER : index;
}
function moveTogether(document, members, section, before, rules) {
	let next = document;
	let anchor = before;
	for (const member of [...members].reverse()) {
		next = apply(next, {
			kind: "moveField",
			field: member,
			section,
			index: indexBefore(next, member, section, anchor)
		}, rules);
		anchor = member;
	}
	return Object.entries(document.fields).every(([name, behaviour]) => next.fields[name].section === behaviour.section && next.fields[name].order === behaviour.order) ? document : next;
}
function withGroupsTogether(document, rules) {
	let next = document;
	for (const group of groupsIn(document)) {
		if (group.members.length < 2 || together(next, group.members)) continue;
		const first = firstOnForm(next, group.members);
		if (first === void 0) continue;
		const section = next.fields[first].section;
		const placed = placedFieldsOf(next, section);
		const before = placed.slice(placed.indexOf(first)).find((name) => !group.members.includes(name)) ?? null;
		next = moveTogether(next, group.members, section, before, rules);
	}
	return next;
}
function together(document, members) {
	const section = document.fields[members[0]].section;
	const placed = placedFieldsOf(document, section);
	const start = placed.indexOf(members[0]);
	return start >= 0 && members.every((name, offset) => placed[start + offset] === name);
}
function firstOnForm(document, members) {
	return orderedTabs(document).flatMap((tab) => sectionsOf(document, tab.id).flatMap((section) => fieldsOf(document, section.id))).find((name) => members.includes(name) && document.fields[name].visible);
}
var BuilderPropertiesComponent = class BuilderPropertiesComponent {
	document = input.required(...ngDevMode ? [{ debugName: "document" }] : /* istanbul ignore next */ []);
	registry = input.required(...ngDevMode ? [{ debugName: "registry" }] : /* istanbul ignore next */ []);
	selection = input(null, ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	ctrmRequired = input(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "ctrmRequired" }] : /* istanbul ignore next */ []);
	op = output();
	field = computed(() => {
		const selected = this.selection();
		if (selected?.kind !== "field") return null;
		const behaviour = this.document().fields[selected.id];
		const registry = this.registry().fields[selected.id];
		return behaviour === void 0 || registry === void 0 ? null : {
			id: selected.id,
			label: registry.label,
			behaviour,
			registry,
			presentation: behaviour.presentation,
			layoutHalf: CONTRACT_LAYOUT_HALF_FIELDS[selected.id] === true,
			fixedWidth: CONTRACT_LAYOUT_FIXED_WIDTH_FIELDS[selected.id] === true
		};
	}, ...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	flags = computed(() => {
		const current = this.field();
		if (current === null) return [];
		const rules = {
			fields: this.registry().fields,
			ctrmRequired: this.ctrmRequired()
		};
		const row = (key, label, locked = null) => ({
			key,
			label,
			checked: current.behaviour[key],
			locked
		});
		return [
			row("visible", "Visible", flagLock(current.id, "visible", rules)),
			row("required", "Required", flagLock(current.id, "required", rules)),
			row("readOnly", "Read-only"),
			row("borderWarning", "Border warning"),
			row("excludeFromCopy", "Leave out of a copy"),
			row("excludeFromTemplateCopy", "Leave out of a template")
		];
	}, ...ngDevMode ? [{ debugName: "flags" }] : /* istanbul ignore next */ []);
	section = computed(() => {
		const selected = this.selection();
		return selected?.kind === "section" ? this.document().sections.find((section) => section.id === selected.id) ?? null : null;
	}, ...ngDevMode ? [{ debugName: "section" }] : /* istanbul ignore next */ []);
	tab = computed(() => {
		const selected = this.selection();
		return selected?.kind === "tab" ? this.document().tabs.find((tab) => tab.id === selected.id) ?? null : null;
	}, ...ngDevMode ? [{ debugName: "tab" }] : /* istanbul ignore next */ []);
	block = computed(() => {
		const selected = this.selection();
		const block = selected?.kind === "block" ? COLLECTION_BLOCKS.find((candidate) => candidate.collection === selected.id) : void 0;
		return block === void 0 ? null : {
			...block,
			excludeFromCopy: this.document().collections?.[block.collection]?.excludeFromCopy ?? false,
			copyable: this.registry().collections?.[block.collection]?.copyable ?? true
		};
	}, ...ngDevMode ? [{ debugName: "block" }] : /* istanbul ignore next */ []);
	setFlag(key, value) {
		const current = this.field();
		if (current !== null) this.op.emit({
			kind: "setFieldFlags",
			field: current.id,
			flags: { [key]: value }
		});
	}
	setPresentation(presentation) {
		const current = this.field();
		if (current !== null) this.op.emit({
			kind: "setPresentation",
			field: current.id,
			presentation
		});
	}
	choice(value) {
		return value === void 0 ? "" : String(value);
	}
	setChoice(key, value) {
		this.setPresentation({ [key]: value === "" ? void 0 : value === "true" });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderPropertiesComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: BuilderPropertiesComponent,
		isStandalone: true,
		selector: "cms-builder-properties",
		inputs: {
			document: {
				classPropertyName: "document",
				publicName: "document",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			registry: {
				classPropertyName: "registry",
				publicName: "registry",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selection: {
				classPropertyName: "selection",
				publicName: "selection",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ctrmRequired: {
				classPropertyName: "ctrmRequired",
				publicName: "ctrmRequired",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { op: "op" },
		ngImport: i0,
		template: `
    <!-- Inside the builder's editing panel, which names it on its toggle: no card of its own, and the heading is for a screen reader. -->
    <section class="cws:space-y-3 cws:p-3" aria-labelledby="builder-properties-heading" data-testid="builder-properties">
      <h3 id="builder-properties-heading" class="cws:sr-only">
        Properties
      </h3>

      @switch (selection()?.kind) {
        @case ('field') {
          @if (field(); as current) {
            <p class="cws:text-sm cws:font-medium" data-testid="builder-properties-name">{{ current.label }}</p>
            <fieldset class="cws:space-y-1">
              <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Behaviour</legend>
              @for (flag of flags(); track flag.key) {
                <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
                  <input
                    type="checkbox"
                    [checked]="flag.checked"
                    [disabled]="readOnly() || flag.locked !== null"
                    (change)="setFlag(flag.key, $any($event.target).checked)"
                    [attr.data-flag]="flag.key"
                  />
                  {{ flag.label }}
                  @if (flag.locked; as reason) {
                    <span class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">({{ reason }})</span>
                  }
                </label>
              }
            </fieldset>

            <fieldset class="cws:space-y-2">
              <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Presentation</legend>
              <!--
                Three standard widths (2026-10-29), stored in the one flag configuration has today:
                unset is Automatic, halfWidth true is Compact, false is Normal. A compound group's
                members (the contract number) are fixed: the form draws the group as one normal field.
              -->
              @if (current.fixedWidth) {
                <p class="cws:text-sm" data-testid="builder-width-fixed">
                  Width
                  <span class="cws:mt-1 cws:block cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                    Fixed: the contract number always takes one normal field.
                  </span>
                </p>
              } @else {
                <label class="cws:block cws:text-sm">
                  Width
                  <select
                    class="scoular-form-input cws:mt-1 cws:w-full"
                    [value]="choice(current.presentation?.halfWidth)"
                    [disabled]="readOnly()"
                    (change)="setChoice('halfWidth', $any($event.target).value)"
                    data-testid="builder-width"
                  >
                    <option value="">Automatic ({{ current.layoutHalf ? 'compact' : 'from the field' }})</option>
                    <option value="true">Compact: a short box, for a code or flag</option>
                    <option value="false">Normal: one column</option>
                  </select>
                  <span class="cws:mt-1 cws:block cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                    Automatic sizes a field from what it holds: compact for a short code, two columns for a
                    long description.
                  </span>
                </label>
              }
              <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
                <input
                  type="checkbox"
                  [checked]="current.presentation?.labelHidden !== true"
                  [disabled]="readOnly()"
                  (change)="setPresentation({ labelHidden: $any($event.target).checked ? undefined : true })"
                  data-testid="builder-heading-visible"
                />
                Show the heading
              </label>
              <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
                <input
                  type="checkbox"
                  [checked]="current.presentation?.tooltipEnabled !== false"
                  [disabled]="readOnly()"
                  (change)="setPresentation({ tooltipEnabled: $any($event.target).checked ? undefined : false })"
                  data-testid="builder-tooltip-on"
                />
                Show a description behind the "i"
              </label>
              <label class="cws:block cws:text-sm">
                Description text
                <textarea
                  rows="3"
                  class="scoular-form-input cws:mt-1 cws:w-full"
                  maxlength="500"
                  [value]="current.presentation?.tooltipDescription ?? ''"
                  [disabled]="readOnly() || current.presentation?.tooltipEnabled === false"
                  (change)="setPresentation({ tooltipDescription: $any($event.target).value.trim() || undefined })"
                  placeholder="The layout's description"
                  data-testid="builder-tooltip-text"
                ></textarea>
              </label>
            </fieldset>
          }
        }
        @case ('section') {
          @if (section(); as current) {
            <p class="cws:text-sm cws:font-medium">Section: {{ current.label }}</p>
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="current.visible"
                [disabled]="readOnly()"
                (change)="op.emit({ kind: 'setSectionVisible', section: current.id, visible: $any($event.target).checked })"
                data-testid="builder-section-visible"
              />
              Visible
            </label>
          }
        }
        @case ('tab') {
          @if (tab(); as current) {
            <p class="cws:text-sm cws:font-medium">Tab: {{ current.label }}</p>
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="current.visible"
                [disabled]="readOnly()"
                (change)="op.emit({ kind: 'setTabVisible', tab: current.id, visible: $any($event.target).checked })"
                data-testid="builder-tab-visible"
              />
              Visible
            </label>
          }
        }
        @case ('block') {
          @if (block(); as current) {
            <p class="cws:text-sm cws:font-medium">{{ current.label }}</p>
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="current.excludeFromCopy"
                [disabled]="readOnly() || !current.copyable"
                (change)="op.emit({ kind: 'setCollectionFlags', collection: current.collection, flags: { excludeFromCopy: $any($event.target).checked } })"
                data-testid="builder-block-exclude"
              />
              Leave out of a copy
            </label>
          }
        }
        @default {
          <p class="cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">Select a field, section, tab or grid on the canvas to set its properties.</p>
        }
      }
    </section>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderPropertiesComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-builder-properties",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <!-- Inside the builder's editing panel, which names it on its toggle: no card of its own, and the heading is for a screen reader. -->
    <section class="cws:space-y-3 cws:p-3" aria-labelledby="builder-properties-heading" data-testid="builder-properties">
      <h3 id="builder-properties-heading" class="cws:sr-only">
        Properties
      </h3>

      @switch (selection()?.kind) {
        @case ('field') {
          @if (field(); as current) {
            <p class="cws:text-sm cws:font-medium" data-testid="builder-properties-name">{{ current.label }}</p>
            <fieldset class="cws:space-y-1">
              <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Behaviour</legend>
              @for (flag of flags(); track flag.key) {
                <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
                  <input
                    type="checkbox"
                    [checked]="flag.checked"
                    [disabled]="readOnly() || flag.locked !== null"
                    (change)="setFlag(flag.key, $any($event.target).checked)"
                    [attr.data-flag]="flag.key"
                  />
                  {{ flag.label }}
                  @if (flag.locked; as reason) {
                    <span class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">({{ reason }})</span>
                  }
                </label>
              }
            </fieldset>

            <fieldset class="cws:space-y-2">
              <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Presentation</legend>
              <!--
                Three standard widths (2026-10-29), stored in the one flag configuration has today:
                unset is Automatic, halfWidth true is Compact, false is Normal. A compound group's
                members (the contract number) are fixed: the form draws the group as one normal field.
              -->
              @if (current.fixedWidth) {
                <p class="cws:text-sm" data-testid="builder-width-fixed">
                  Width
                  <span class="cws:mt-1 cws:block cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                    Fixed: the contract number always takes one normal field.
                  </span>
                </p>
              } @else {
                <label class="cws:block cws:text-sm">
                  Width
                  <select
                    class="scoular-form-input cws:mt-1 cws:w-full"
                    [value]="choice(current.presentation?.halfWidth)"
                    [disabled]="readOnly()"
                    (change)="setChoice('halfWidth', $any($event.target).value)"
                    data-testid="builder-width"
                  >
                    <option value="">Automatic ({{ current.layoutHalf ? 'compact' : 'from the field' }})</option>
                    <option value="true">Compact: a short box, for a code or flag</option>
                    <option value="false">Normal: one column</option>
                  </select>
                  <span class="cws:mt-1 cws:block cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">
                    Automatic sizes a field from what it holds: compact for a short code, two columns for a
                    long description.
                  </span>
                </label>
              }
              <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
                <input
                  type="checkbox"
                  [checked]="current.presentation?.labelHidden !== true"
                  [disabled]="readOnly()"
                  (change)="setPresentation({ labelHidden: $any($event.target).checked ? undefined : true })"
                  data-testid="builder-heading-visible"
                />
                Show the heading
              </label>
              <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
                <input
                  type="checkbox"
                  [checked]="current.presentation?.tooltipEnabled !== false"
                  [disabled]="readOnly()"
                  (change)="setPresentation({ tooltipEnabled: $any($event.target).checked ? undefined : false })"
                  data-testid="builder-tooltip-on"
                />
                Show a description behind the "i"
              </label>
              <label class="cws:block cws:text-sm">
                Description text
                <textarea
                  rows="3"
                  class="scoular-form-input cws:mt-1 cws:w-full"
                  maxlength="500"
                  [value]="current.presentation?.tooltipDescription ?? ''"
                  [disabled]="readOnly() || current.presentation?.tooltipEnabled === false"
                  (change)="setPresentation({ tooltipDescription: $any($event.target).value.trim() || undefined })"
                  placeholder="The layout's description"
                  data-testid="builder-tooltip-text"
                ></textarea>
              </label>
            </fieldset>
          }
        }
        @case ('section') {
          @if (section(); as current) {
            <p class="cws:text-sm cws:font-medium">Section: {{ current.label }}</p>
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="current.visible"
                [disabled]="readOnly()"
                (change)="op.emit({ kind: 'setSectionVisible', section: current.id, visible: $any($event.target).checked })"
                data-testid="builder-section-visible"
              />
              Visible
            </label>
          }
        }
        @case ('tab') {
          @if (tab(); as current) {
            <p class="cws:text-sm cws:font-medium">Tab: {{ current.label }}</p>
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="current.visible"
                [disabled]="readOnly()"
                (change)="op.emit({ kind: 'setTabVisible', tab: current.id, visible: $any($event.target).checked })"
                data-testid="builder-tab-visible"
              />
              Visible
            </label>
          }
        }
        @case ('block') {
          @if (block(); as current) {
            <p class="cws:text-sm cws:font-medium">{{ current.label }}</p>
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="current.excludeFromCopy"
                [disabled]="readOnly() || !current.copyable"
                (change)="op.emit({ kind: 'setCollectionFlags', collection: current.collection, flags: { excludeFromCopy: $any($event.target).checked } })"
                data-testid="builder-block-exclude"
              />
              Leave out of a copy
            </label>
          }
        }
        @default {
          <p class="cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">Select a field, section, tab or grid on the canvas to set its properties.</p>
        }
      }
    </section>
  `
		}]
	}],
	propDecorators: {
		document: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "document",
				required: true
			}]
		}],
		registry: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "registry",
				required: true
			}]
		}],
		selection: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selection",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		ctrmRequired: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ctrmRequired",
				required: false
			}]
		}],
		op: [{
			type: i0.Output,
			args: ["op"]
		}]
	}
});
var BuilderSettingsComponent = class BuilderSettingsComponent {
	document = input.required(...ngDevMode ? [{ debugName: "document" }] : /* istanbul ignore next */ []);
	registry = input.required(...ngDevMode ? [{ debugName: "registry" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	op = output();
	lockedColumns = [PINNED_GRID_COLUMN];
	allColumns = CONTRACT_GRID_COLUMNS.map((column) => column.key);
	columnFields = computed(() => {
		const headers = new Map(CONTRACT_GRID_COLUMNS.map((column) => [column.key, column.header]));
		return gridColumnChoices(this.allColumns, null, this.document().attributes.homeGridColumns ?? null).map((choice) => ({
			key: choice.key,
			header: headers.get(choice.key) ?? choice.key,
			included: choice.shown
		}));
	}, ...ngDevMode ? [{ debugName: "columnFields" }] : /* istanbul ignore next */ []);
	onColumns(fields) {
		this.op.emit({
			kind: "setHomeGridColumns",
			columns: userGridColumnKeys(fields.map((field) => ({
				key: field.key,
				shown: field.included
			}))) ?? void 0
		});
	}
	collections = computed(() => {
		const offered = this.registry().collections;
		if (offered === void 0) return null;
		return Object.entries(offered).map(([name, collection]) => ({
			name,
			label: name.replace(/_/g, " "),
			copyable: collection.copyable,
			excluded: this.document().collections?.[name]?.excludeFromCopy ?? false
		}));
	}, ...ngDevMode ? [{ debugName: "collections" }] : /* istanbul ignore next */ []);
	remarks = computed(() => {
		const offered = this.registry().remarkTypes;
		if (offered === void 0) return null;
		return offered.map((type) => {
			const behaviour = this.document().remarkTypes?.[type.code];
			return {
				code: type.code,
				label: type.label,
				visible: behaviour?.visible ?? true,
				required: behaviour?.required ?? false
			};
		});
	}, ...ngDevMode ? [{ debugName: "remarks" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderSettingsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: BuilderSettingsComponent,
		isStandalone: true,
		selector: "cms-builder-settings",
		inputs: {
			document: {
				classPropertyName: "document",
				publicName: "document",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			registry: {
				classPropertyName: "registry",
				publicName: "registry",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { op: "op" },
		ngImport: i0,
		template: `
    <!-- Inside the builder's editing panel, which names it on its toggle: no card of its own, and the heading is for a screen reader. -->
    <section class="cws:space-y-4 cws:p-3" aria-labelledby="builder-settings-heading" data-testid="builder-settings">
      <h3 id="builder-settings-heading" class="cws:sr-only">
        Trade unit settings
      </h3>

      <fieldset class="cws:space-y-2">
        <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Trade unit behaviour</legend>
        <label class="cws:block cws:text-sm">
          Contract auto-calculation
          <select
            class="scoular-form-input cws:mt-1 cws:w-full"
            [value]="document().attributes.autoCalculationMode"
            [disabled]="readOnly()"
            (change)="op.emit({ kind: 'setAttributes', attributes: { autoCalculationMode: $any($event.target).value } })"
            data-testid="builder-auto-calc"
          >
            <option value="None">None: Price and Basis stay editable</option>
            <option value="Price">Price: computed from its components and locked</option>
            <option value="Basis">Basis: computed from its components and locked</option>
          </select>
        </label>
        <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
          <input
            type="checkbox"
            [checked]="document().attributes.pendingContractsEnabled"
            [disabled]="readOnly()"
            (change)="op.emit({ kind: 'setAttributes', attributes: { pendingContractsEnabled: $any($event.target).checked } })"
            data-testid="builder-pending"
          />
          Pending contracts enabled
        </label>
      </fieldset>

      <div class="cws:space-y-2" data-testid="builder-grid-columns">
        <div class="cws:flex cws:items-center cws:justify-between cws:gap-2">
          <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">
            Home grid columns
            <span class="cws:font-normal cws:text-slate-500 cws:dark:text-slate-400">
              ({{ document().attributes.homeGridColumns === undefined ? 'every column' : 'this list, in this order' }})
            </span>
          </span>
          <button
            type="button"
            class="scoular-btn scoular-btn-secondary cws:text-xs"
            [disabled]="readOnly() || document().attributes.homeGridColumns === undefined"
            (click)="op.emit({ kind: 'setHomeGridColumns', columns: undefined })"
          >
            Reset to all
          </button>
        </div>
        @if (!readOnly()) {
          <cms-export-fields
            [fields]="columnFields()"
            [lockedKeys]="lockedColumns"
            noun="columns"
            listLabel="Home grid columns, in order"
            emptyMessage="Select at least one column."
            (fieldsChange)="onColumns($event)"
          />
        }
      </div>

      @if (collections(); as rows) {
        <fieldset class="cws:space-y-1" data-testid="builder-collections">
          <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Collections on copy</legend>
          @for (row of rows; track row.name) {
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="row.excluded"
                [disabled]="readOnly() || !row.copyable"
                (change)="op.emit({ kind: 'setCollectionFlags', collection: row.name, flags: { excludeFromCopy: $any($event.target).checked } })"
                [attr.data-collection]="row.name"
              />
              Leave {{ row.label }} out of a copy
              @if (!row.copyable) {
                <span class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">(a copy never carries it)</span>
              }
            </label>
          }
        </fieldset>
      }

      @if (remarks(); as rows) {
        <fieldset class="cws:space-y-1" data-testid="builder-remarks">
          <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Remarks</legend>
          @for (row of rows; track row.code) {
            <div class="cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:text-sm">
              <span class="cws:min-w-0 cws:flex-1">{{ row.label }}</span>
              <label class="cws:flex cws:items-center cws:gap-1 cws:text-xs">
                <input
                  type="checkbox"
                  [checked]="row.visible"
                  [disabled]="readOnly()"
                  (change)="op.emit({ kind: 'setRemarkType', code: row.code, behaviour: { visible: $any($event.target).checked, required: row.required } })"
                  [attr.data-remark-visible]="row.code"
                />
                Visible
              </label>
              <label class="cws:flex cws:items-center cws:gap-1 cws:text-xs">
                <input
                  type="checkbox"
                  [checked]="row.required"
                  [disabled]="readOnly() || !row.visible"
                  (change)="op.emit({ kind: 'setRemarkType', code: row.code, behaviour: { visible: row.visible, required: $any($event.target).checked } })"
                  [attr.data-remark-required]="row.code"
                />
                Required
              </label>
            </div>
          }
        </fieldset>
      }
    </section>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: ExportFieldsComponent,
			selector: "cms-export-fields",
			inputs: [
				"fields",
				"lockedKeys",
				"noun",
				"listLabel",
				"emptyMessage"
			],
			outputs: ["fieldsChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderSettingsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-builder-settings",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [ExportFieldsComponent],
			template: `
    <!-- Inside the builder's editing panel, which names it on its toggle: no card of its own, and the heading is for a screen reader. -->
    <section class="cws:space-y-4 cws:p-3" aria-labelledby="builder-settings-heading" data-testid="builder-settings">
      <h3 id="builder-settings-heading" class="cws:sr-only">
        Trade unit settings
      </h3>

      <fieldset class="cws:space-y-2">
        <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Trade unit behaviour</legend>
        <label class="cws:block cws:text-sm">
          Contract auto-calculation
          <select
            class="scoular-form-input cws:mt-1 cws:w-full"
            [value]="document().attributes.autoCalculationMode"
            [disabled]="readOnly()"
            (change)="op.emit({ kind: 'setAttributes', attributes: { autoCalculationMode: $any($event.target).value } })"
            data-testid="builder-auto-calc"
          >
            <option value="None">None: Price and Basis stay editable</option>
            <option value="Price">Price: computed from its components and locked</option>
            <option value="Basis">Basis: computed from its components and locked</option>
          </select>
        </label>
        <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
          <input
            type="checkbox"
            [checked]="document().attributes.pendingContractsEnabled"
            [disabled]="readOnly()"
            (change)="op.emit({ kind: 'setAttributes', attributes: { pendingContractsEnabled: $any($event.target).checked } })"
            data-testid="builder-pending"
          />
          Pending contracts enabled
        </label>
      </fieldset>

      <div class="cws:space-y-2" data-testid="builder-grid-columns">
        <div class="cws:flex cws:items-center cws:justify-between cws:gap-2">
          <span class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">
            Home grid columns
            <span class="cws:font-normal cws:text-slate-500 cws:dark:text-slate-400">
              ({{ document().attributes.homeGridColumns === undefined ? 'every column' : 'this list, in this order' }})
            </span>
          </span>
          <button
            type="button"
            class="scoular-btn scoular-btn-secondary cws:text-xs"
            [disabled]="readOnly() || document().attributes.homeGridColumns === undefined"
            (click)="op.emit({ kind: 'setHomeGridColumns', columns: undefined })"
          >
            Reset to all
          </button>
        </div>
        @if (!readOnly()) {
          <cms-export-fields
            [fields]="columnFields()"
            [lockedKeys]="lockedColumns"
            noun="columns"
            listLabel="Home grid columns, in order"
            emptyMessage="Select at least one column."
            (fieldsChange)="onColumns($event)"
          />
        }
      </div>

      @if (collections(); as rows) {
        <fieldset class="cws:space-y-1" data-testid="builder-collections">
          <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Collections on copy</legend>
          @for (row of rows; track row.name) {
            <label class="cws:flex cws:items-center cws:gap-2 cws:text-sm">
              <input
                type="checkbox"
                [checked]="row.excluded"
                [disabled]="readOnly() || !row.copyable"
                (change)="op.emit({ kind: 'setCollectionFlags', collection: row.name, flags: { excludeFromCopy: $any($event.target).checked } })"
                [attr.data-collection]="row.name"
              />
              Leave {{ row.label }} out of a copy
              @if (!row.copyable) {
                <span class="cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">(a copy never carries it)</span>
              }
            </label>
          }
        </fieldset>
      }

      @if (remarks(); as rows) {
        <fieldset class="cws:space-y-1" data-testid="builder-remarks">
          <legend class="cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300">Remarks</legend>
          @for (row of rows; track row.code) {
            <div class="cws:flex cws:flex-wrap cws:items-center cws:gap-3 cws:text-sm">
              <span class="cws:min-w-0 cws:flex-1">{{ row.label }}</span>
              <label class="cws:flex cws:items-center cws:gap-1 cws:text-xs">
                <input
                  type="checkbox"
                  [checked]="row.visible"
                  [disabled]="readOnly()"
                  (change)="op.emit({ kind: 'setRemarkType', code: row.code, behaviour: { visible: $any($event.target).checked, required: row.required } })"
                  [attr.data-remark-visible]="row.code"
                />
                Visible
              </label>
              <label class="cws:flex cws:items-center cws:gap-1 cws:text-xs">
                <input
                  type="checkbox"
                  [checked]="row.required"
                  [disabled]="readOnly() || !row.visible"
                  (change)="op.emit({ kind: 'setRemarkType', code: row.code, behaviour: { visible: row.visible, required: $any($event.target).checked } })"
                  [attr.data-remark-required]="row.code"
                />
                Required
              </label>
            </div>
          }
        </fieldset>
      }
    </section>
  `
		}]
	}],
	propDecorators: {
		document: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "document",
				required: true
			}]
		}],
		registry: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "registry",
				required: true
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		op: [{
			type: i0.Output,
			args: ["op"]
		}]
	}
});
function configJson(document) {
	return JSON.stringify(document, null, 2);
}
const MAX_PROBLEMS = 10;
function readConfigJson(text, fields, current) {
	let parsed;
	try {
		parsed = JSON.parse(text);
	} catch (error) {
		return refuse([`This is not valid JSON: ${error instanceof Error ? error.message : String(error)}.`]);
	}
	if (!isObject(parsed)) return refuse(["The JSON must be one form configuration: an object with tabs, sections and fields."]);
	const problems = [];
	if (parsed["schemaVersion"] !== void 0 && parsed["schemaVersion"] !== current.schemaVersion) problems.push(`schemaVersion is ${JSON.stringify(parsed["schemaVersion"])}, and this builder edits version ${current.schemaVersion}.`);
	const tabs = readList(parsed["tabs"], "tabs", problems, readTab);
	const sections = readList(parsed["sections"], "sections", problems, readSection);
	const entries = readFields(parsed["fields"], problems);
	if (tabs !== null && tabs.length === 0) problems.push("tabs is empty. A form needs at least one tab.");
	if (tabs !== null && sections !== null) {
		const tabIds = new Set(tabs.map((tab) => tab.id));
		for (const section of sections.filter((candidate) => !tabIds.has(candidate.tab))) problems.push(`Section "${section.id}" is on tab "${section.tab}", which is not one of the tabs.`);
	}
	if (sections !== null && entries !== null) {
		const sectionIds = new Set(sections.map((section) => section.id));
		for (const [name, behaviour] of Object.entries(entries)) if (name in fields && !sectionIds.has(behaviour.section)) problems.push(`Field "${name}" is in section "${behaviour.section}", which is not one of the sections.`);
	}
	const attributes = readAttributes(parsed["attributes"], current, problems);
	for (const member of ["collections", "remarkTypes"]) if (parsed[member] !== void 0 && !isObject(parsed[member])) problems.push(`${member} must be an object keyed by name.`);
	if (problems.length > 0 || tabs === null || sections === null || entries === null) return refuse(problems);
	const ignored = Object.keys(entries).filter((name) => !(name in fields));
	const kept = Object.fromEntries(Object.entries(entries).filter(([name]) => name in fields));
	const shell = {
		schemaVersion: current.schemaVersion,
		tabs,
		sections,
		fields: kept,
		attributes
	};
	const firstSection = orderedTabs(shell).flatMap((tab) => sectionsOf(shell, tab.id))[0]?.id ?? sections[0]?.id;
	const sectionIds = new Set(sections.map((section) => section.id));
	const added = [];
	for (const [name, registry] of Object.entries(fields).sort(([, a], [, b]) => a.order - b.order)) {
		if (name in kept || firstSection === void 0) continue;
		const section = sectionIds.has(registry.section) ? registry.section : firstSection;
		const last = Math.max(0, ...Object.values(kept).filter((entry) => entry.section === section).map((entry) => entry.order));
		const fixed = !registry.configurable;
		kept[name] = {
			visible: fixed,
			required: fixed && registry.systemRequired,
			readOnly: registry.readOnly,
			borderWarning: false,
			excludeFromCopy: false,
			excludeFromTemplateCopy: false,
			section,
			order: last + 1
		};
		added.push(name);
	}
	const collections = parsed["collections"] ?? current.collections;
	const remarkTypes = parsed["remarkTypes"] ?? current.remarkTypes;
	return {
		ok: true,
		document: {
			...shell,
			fields: kept,
			...collections === void 0 ? {} : { collections },
			...remarkTypes === void 0 ? {} : { remarkTypes }
		},
		ignored,
		added
	};
}
function refuse(problems) {
	return {
		ok: false,
		problems: problems.length > MAX_PROBLEMS ? [...problems.slice(0, MAX_PROBLEMS), `And ${problems.length - MAX_PROBLEMS} more.`] : problems
	};
}
function isObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function readList(value, member, problems, read) {
	if (!Array.isArray(value)) {
		problems.push(`${member} must be a list.`);
		return null;
	}
	const items = [];
	let valid = true;
	value.forEach((item, index) => {
		const at = `${member} item ${index + 1}`;
		if (!isObject(item)) {
			problems.push(`${at} must be an object.`);
			valid = false;
			return;
		}
		const result = read(item, at, problems);
		if (result === null) valid = false;
		else items.push(result);
	});
	return valid ? items : null;
}
function typed(item, at, problems, types) {
	let valid = true;
	for (const [member, type] of Object.entries(types)) {
		const value = item[member];
		if (!(type === "string" ? typeof value === "string" && value.trim() !== "" : typeof value === type)) {
			problems.push(`${at}: ${member} must be ${type === "string" ? "text" : type === "number" ? "a number" : "true or false"}.`);
			valid = false;
		}
	}
	return valid;
}
function readTab(item, at, problems) {
	return typed(item, at, problems, {
		id: "string",
		label: "string",
		order: "number",
		visible: "boolean"
	}) ? {
		id: item["id"],
		label: item["label"],
		order: item["order"],
		visible: item["visible"]
	} : null;
}
function readSection(item, at, problems) {
	return typed(item, at, problems, {
		id: "string",
		label: "string",
		tab: "string",
		order: "number",
		visible: "boolean"
	}) ? {
		id: item["id"],
		label: item["label"],
		tab: item["tab"],
		order: item["order"],
		visible: item["visible"]
	} : null;
}
const OPTIONAL_FLAGS = [
	"readOnly",
	"borderWarning",
	"excludeFromCopy",
	"excludeFromTemplateCopy"
];
function readFields(value, problems) {
	if (!isObject(value)) {
		problems.push("fields must be an object keyed by field name.");
		return null;
	}
	const fields = {};
	let valid = true;
	for (const [name, entry] of Object.entries(value)) {
		const at = `Field "${name}"`;
		if (!isObject(entry)) {
			problems.push(`${at} must be an object.`);
			valid = false;
			continue;
		}
		let ok = typed(entry, at, problems, {
			visible: "boolean",
			required: "boolean",
			section: "string",
			order: "number"
		});
		for (const flag of OPTIONAL_FLAGS.filter((candidate) => entry[candidate] !== void 0 && typeof entry[candidate] !== "boolean")) {
			problems.push(`${at}: ${flag} must be true or false.`);
			ok = false;
		}
		if (entry["presentation"] !== void 0 && !isObject(entry["presentation"])) {
			problems.push(`${at}: presentation must be an object.`);
			ok = false;
		}
		if (!ok) {
			valid = false;
			continue;
		}
		fields[name] = {
			visible: entry["visible"],
			required: entry["required"],
			readOnly: entry["readOnly"] === true,
			borderWarning: entry["borderWarning"] === true,
			excludeFromCopy: entry["excludeFromCopy"] === true,
			excludeFromTemplateCopy: entry["excludeFromTemplateCopy"] === true,
			section: entry["section"],
			order: entry["order"],
			...entry["presentation"] === void 0 ? {} : { presentation: entry["presentation"] }
		};
	}
	return valid ? fields : null;
}
function readAttributes(value, current, problems) {
	if (value === void 0) return current.attributes;
	if (!isObject(value)) {
		problems.push("attributes must be an object.");
		return current.attributes;
	}
	if (!typed(value, "attributes", problems, {
		autoCalculationMode: "string",
		pendingContractsEnabled: "boolean"
	})) return current.attributes;
	if (value["homeGridColumns"] !== void 0 && !(Array.isArray(value["homeGridColumns"]) && value["homeGridColumns"].every((column) => typeof column === "string"))) {
		problems.push("attributes: homeGridColumns must be a list of column names.");
		return current.attributes;
	}
	return value;
}
function documentFromResolution(resolved) {
	const fields = {};
	for (const section of resolved.config.sections) section.fields.forEach((field, position) => {
		fields[field.componentName] = {
			visible: field.behaviour.visible,
			required: field.behaviour.required,
			readOnly: field.behaviour.readOnly,
			borderWarning: field.behaviour.borderWarning === true,
			excludeFromCopy: field.behaviour.excludeFromCopy === true,
			excludeFromTemplateCopy: field.behaviour.excludeFromTemplateCopy === true,
			section: section.componentName,
			order: field.order ?? position + 1,
			...field.presentation === void 0 || field.presentation === null ? {} : { presentation: field.presentation }
		};
	});
	const attributes = resolved.tradeUnitAttributes;
	return {
		schemaVersion: 1,
		tabs: resolved.config.tabs.map((tab) => ({
			id: tab.id,
			label: tab.label,
			order: tab.order,
			visible: tab.visible
		})),
		sections: resolved.config.sections.map((section, position) => ({
			id: section.componentName,
			label: section.label,
			tab: section.tab,
			order: section.order ?? position + 1,
			visible: section.visible
		})),
		fields,
		attributes: {
			autoCalculationMode: attributes.autoCalculationMode,
			pendingContractsEnabled: attributes.pendingContractsEnabled,
			...attributes.homeGridColumns === void 0 || attributes.homeGridColumns === null ? {} : { homeGridColumns: attributes.homeGridColumns }
		},
		...resolved.config.collections === void 0 ? {} : { collections: { ...resolved.config.collections } },
		...resolved.config.remarkTypes === void 0 ? {} : { remarkTypes: { ...resolved.config.remarkTypes } }
	};
}
function changedItems(base, present) {
	const same = (left, right) => JSON.stringify(left) === JSON.stringify(right);
	const baseSections = new Map(base.sections.map((section) => [section.id, section]));
	const baseTabs = new Map(base.tabs.map((tab) => [tab.id, tab]));
	return {
		fields: new Set(Object.keys(present.fields).filter((name) => !same(base.fields[name], present.fields[name]))),
		sections: new Set(present.sections.filter((section) => !same(baseSections.get(section.id), section)).map((section) => section.id)),
		tabs: new Set(present.tabs.filter((tab) => !same(baseTabs.get(tab.id), tab)).map((tab) => tab.id))
	};
}
const SCRATCH_TAB_ID = "new-tab";
const SCRATCH_SECTION_ID = "new-section";
function scratchDocument(document, rules) {
	const tabOrder = new Map(document.tabs.map((tab) => [tab.id, tab.order]));
	const sectionAt = new Map(document.sections.map((section) => [section.id, section]));
	const position = (name) => {
		const behaviour = document.fields[name];
		const section = sectionAt.get(behaviour.section);
		const last = Number.MAX_SAFE_INTEGER;
		return [
			tabOrder.get(section?.tab ?? "") ?? last,
			section?.order ?? last,
			behaviour.order
		];
	};
	const names = Object.keys(document.fields).sort((left, right) => {
		const [a, b] = [position(left), position(right)];
		return a[0] - b[0] || a[1] - b[1] || a[2] - b[2] || left.localeCompare(right);
	});
	let unplaced = document;
	for (const name of names) unplaced = apply(unplaced, {
		kind: "setFieldFlags",
		field: name,
		flags: { visible: false }
	}, rules);
	const ordered = [...names.filter((name) => unplaced.fields[name].visible), ...names.filter((name) => !unplaced.fields[name].visible)];
	const fields = {};
	ordered.forEach((name, position) => {
		fields[name] = {
			...unplaced.fields[name],
			section: SCRATCH_SECTION_ID,
			order: position + 1
		};
	});
	const collections = {};
	for (const [name, behaviour] of Object.entries(document.collections ?? {})) collections[name] = behaviour.tab === void 0 ? behaviour : {
		...behaviour,
		tab: SCRATCH_TAB_ID
	};
	for (const block of COLLECTION_BLOCKS) for (const name of [block.collection, ...block.alsoMoves]) collections[name] = {
		...collections[name] ?? {
			excludeFromCopy: false,
			excludeFromTemplateCopy: false
		},
		tab: SCRATCH_TAB_ID
	};
	return {
		...document,
		tabs: [{
			id: SCRATCH_TAB_ID,
			label: "New tab",
			order: 1,
			visible: true
		}],
		sections: [{
			id: SCRATCH_SECTION_ID,
			label: "New section",
			tab: SCRATCH_TAB_ID,
			order: 1,
			visible: true
		}],
		fields,
		collections
	};
}
const SETTINGS_MANAGE = "settings:manage";
const TAB_HOVER_MS = 600;
const GRIDS_GROUP = "grids";
const GRID_REMOVE_REFUSAL = "A grid cannot be removed: the form configuration can move it to another tab but cannot hide it";
var FormBuilderPageComponent = class FormBuilderPageComponent {
	source = inject(FORM_CONFIG_ADMIN_SOURCE);
	meSource = inject(ME_SOURCE, { optional: true });
	constraintSource = inject(CONSTRAINT_SOURCE, { optional: true });
	route = inject(ActivatedRoute, { optional: true });
	router = inject(Router, { optional: true });
	destroyRef = inject(DestroyRef);
	confirm = injectConfirm();
	prompt = injectBuilderPrompt();
	importDialog = injectBuilderJsonImport();
	dom = inject(DOCUMENT);
	area = adminArea("form-configuration");
	blocks = COLLECTION_BLOCKS;
	typeInput = signal("", ...ngDevMode ? [{ debugName: "typeInput" }] : /* istanbul ignore next */ []);
	locationInput = signal("", ...ngDevMode ? [{ debugName: "locationInput" }] : /* istanbul ignore next */ []);
	commodityInput = signal("", ...ngDevMode ? [{ debugName: "commodityInput" }] : /* istanbul ignore next */ []);
	dimensions = signal(null, ...ngDevMode ? [{ debugName: "dimensions" }] : /* istanbul ignore next */ []);
	editing = computed(() => {
		const state = this.loadState();
		return this.dimensions() !== null && (state === "loading" || state === "loaded");
	}, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	openedOn = computed(() => {
		const dimensions = this.dimensions();
		const any = (value) => value === "" ? "Any" : value;
		return dimensions === null ? "" : `Contract type ${any(dimensions.contractTypeClass)} · Trade unit ${any(dimensions.locationCode)} · Commodity ${any(dimensions.commodityCode)}`;
	}, ...ngDevMode ? [{ debugName: "openedOn" }] : /* istanbul ignore next */ []);
	registry = signal(null, ...ngDevMode ? [{ debugName: "registry" }] : /* istanbul ignore next */ []);
	rows = signal([], ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	loadState = signal("idle", ...ngDevMode ? [{ debugName: "loadState" }] : /* istanbul ignore next */ []);
	loadError = signal(null, ...ngDevMode ? [{ debugName: "loadError" }] : /* istanbul ignore next */ []);
	ownRow = signal(null, ...ngDevMode ? [{ debugName: "ownRow" }] : /* istanbul ignore next */ []);
	inheritedFrom = signal(null, ...ngDevMode ? [{ debugName: "inheritedFrom" }] : /* istanbul ignore next */ []);
	baseline = signal(null, ...ngDevMode ? [{ debugName: "baseline" }] : /* istanbul ignore next */ []);
	history = signal(null, ...ngDevMode ? [{ debugName: "history" }] : /* istanbul ignore next */ []);
	document = computed(() => {
		const present = this.history()?.present ?? null;
		return present === null ? null : withLocks(withRegistryFieldsOnly(present, this.registry()), this.rules());
	}, ...ngDevMode ? [{ debugName: "document" }] : /* istanbul ignore next */ []);
	dirty = computed(() => {
		const history = this.history();
		const baseline = this.baseline();
		return history !== null && baseline !== null && history.present !== baseline;
	}, ...ngDevMode ? [{ debugName: "dirty" }] : /* istanbul ignore next */ []);
	constraintDocument = toSignal(this.constraintSource === null ? of(null) : this.constraintSource.document().pipe(map((snapshot) => snapshot.document), catchError(() => of(null))), { initialValue: null });
	ctrmRequired = computed(() => ctrmRequiredComponents(this.registry(), this.constraintDocument()), ...ngDevMode ? [{ debugName: "ctrmRequired" }] : /* istanbul ignore next */ []);
	ctrmRequiredReason = CTRM_REQUIRED_REASON;
	rules = computed(() => ({
		fields: this.registry()?.fields ?? {},
		ctrmRequired: this.ctrmRequired()
	}), ...ngDevMode ? [{ debugName: "rules" }] : /* istanbul ignore next */ []);
	activeTab = signal(null, ...ngDevMode ? [{ debugName: "activeTab" }] : /* istanbul ignore next */ []);
	selection = signal(null, ...ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []);
	inspector = signal(null, ...ngDevMode ? [{ debugName: "inspector" }] : /* istanbul ignore next */ []);
	inspectorViews = [{
		id: "properties",
		label: "Properties"
	}, {
		id: "settings",
		label: "Trade unit settings"
	}];
	toggleInspector(view) {
		this.inspector.update((open) => open === view ? null : view);
	}
	resolutionKey = computed(() => {
		const dimensions = this.dimensions();
		return dimensions === null ? {} : previewDimensionsOf(dimensions);
	}, ...ngDevMode ? [{ debugName: "resolutionKey" }] : /* istanbul ignore next */ []);
	problems = signal(null, ...ngDevMode ? [{ debugName: "problems" }] : /* istanbul ignore next */ []);
	invalid = computed(() => {
		const keys = Object.keys(this.problems() ?? {});
		const named = (prefix) => new Set(keys.filter((key) => key.startsWith(prefix)).map((key) => key.slice(prefix.length).split(".")[0]));
		return {
			fields: named("config.fields."),
			sections: named("config.sections."),
			collections: named("config.collections."),
			tabs: keys.includes("config.tabs")
		};
	}, ...ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []);
	tabs = computed(() => {
		const document = this.document();
		return document === null ? [] : orderedTabs(document);
	}, ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	shownTab = computed(() => {
		const tabs = this.tabs();
		const active = this.activeTab();
		return tabs.find((tab) => tab.id === active)?.id ?? tabs[0]?.id ?? null;
	}, ...ngDevMode ? [{ debugName: "shownTab" }] : /* istanbul ignore next */ []);
	shownSections = computed(() => {
		const document = this.document();
		const tab = this.shownTab();
		return document === null || tab === null ? [] : sectionsOf(document, tab).map((section) => ({
			...section,
			fields: canvasRows(document, section.id)
		}));
	}, ...ngDevMode ? [{ debugName: "shownSections" }] : /* istanbul ignore next */ []);
	shownBlocks = computed(() => {
		const document = this.document();
		const tab = this.shownTab();
		return document === null ? [] : this.blocks.filter((block) => blockTab(document, block) === tab);
	}, ...ngDevMode ? [{ debugName: "shownBlocks" }] : /* istanbul ignore next */ []);
	empty = computed(() => {
		const document = this.document();
		return document === null ? {
			tabs: /* @__PURE__ */ new Set(),
			sections: /* @__PURE__ */ new Set()
		} : emptyItems(document);
	}, ...ngDevMode ? [{ debugName: "empty" }] : /* istanbul ignore next */ []);
	changed = computed(() => {
		const document = this.document();
		const baseline = this.baseline();
		return document === null || baseline === null ? {
			fields: /* @__PURE__ */ new Set(),
			sections: /* @__PURE__ */ new Set(),
			tabs: /* @__PURE__ */ new Set()
		} : changedItems(withLocks(baseline, this.rules()), document);
	}, ...ngDevMode ? [{ debugName: "changed" }] : /* istanbul ignore next */ []);
	inheritedBadge = computed(() => {
		if (this.ownRow() !== null) return null;
		const from = this.inheritedFrom();
		return from === null ? "From the default" : `From row ${from}`;
	}, ...ngDevMode ? [{ debugName: "inheritedBadge" }] : /* istanbul ignore next */ []);
	paletteSearch = signal("", ...ngDevMode ? [{ debugName: "paletteSearch" }] : /* istanbul ignore next */ []);
	paletteFilter = signal("all", ...ngDevMode ? [{ debugName: "paletteFilter" }] : /* istanbul ignore next */ []);
	paletteFilters = [
		{
			id: "all",
			label: "All"
		},
		{
			id: "unplaced",
			label: "Unplaced"
		},
		{
			id: "placed",
			label: "Placed"
		}
	];
	collapsedGroups = signal(/* @__PURE__ */ new Set(), ...ngDevMode ? [{ debugName: "collapsedGroups" }] : /* istanbul ignore next */ []);
	searching = computed(() => this.paletteSearch().trim() !== "", ...ngDevMode ? [{ debugName: "searching" }] : /* istanbul ignore next */ []);
	toggleGroup(group) {
		this.collapsedGroups.update((collapsed) => {
			const next = new Set(collapsed);
			if (!next.delete(group)) next.add(group);
			return next;
		});
	}
	palette = computed(() => {
		const registry = this.registry();
		const document = this.document();
		if (registry === null || document === null) return [];
		const term = this.paletteSearch().trim().toLowerCase();
		const filter = this.paletteFilter();
		const collapsed = this.collapsedGroups();
		const sectionLabels = new Map(registry.sections.map((section) => [section.id, section.label]));
		const placedSection = new Map(document.sections.map((section) => [section.id, section]));
		const tabLabels = new Map(document.tabs.map((tab) => [tab.id, tab.label]));
		const groups = /* @__PURE__ */ new Map();
		const folded = this.foldedMembers();
		for (const [name, field] of Object.entries(registry.fields).sort(([, a], [, b]) => a.order - b.order)) {
			const label = groupLedBy(document, name)?.heading ?? field.label;
			const names = [label, ...rowMembers(document, name).flatMap((member) => [member, registry.fields[member]?.label ?? ""])];
			if (folded.has(name) || term !== "" && !names.some((text) => text.toLowerCase().includes(term))) continue;
			const behaviour = document.fields[name];
			const section = behaviour === void 0 ? void 0 : placedSection.get(behaviour.section);
			const place = behaviour?.visible === true && section !== void 0 ? `${tabLabels.get(section.tab) ?? section.tab} › ${section.label}` : null;
			if (filter === "placed" && place === null || filter === "unplaced" && place !== null) continue;
			const group = groups.get(field.section) ?? {
				id: field.section,
				label: sectionLabels.get(field.section) ?? field.section,
				expanded: term !== "" || !collapsed.has(field.section),
				fields: []
			};
			group.fields.push({
				id: name,
				label,
				place
			});
			groups.set(field.section, group);
		}
		return [...groups.values()];
	}, ...ngDevMode ? [{ debugName: "palette" }] : /* istanbul ignore next */ []);
	foldedMembers = computed(() => {
		const document = this.document();
		return new Set(document === null ? [] : groupsIn(document).flatMap((group) => group.members.slice(1)));
	}, ...ngDevMode ? [{ debugName: "foldedMembers" }] : /* istanbul ignore next */ []);
	fieldCount = computed(() => {
		const folded = this.foldedMembers();
		return Object.keys(this.registry()?.fields ?? {}).filter((name) => !folded.has(name)).length;
	}, ...ngDevMode ? [{ debugName: "fieldCount" }] : /* istanbul ignore next */ []);
	placedCount = computed(() => {
		const document = this.document();
		const folded = this.foldedMembers();
		return document === null ? 0 : Object.entries(document.fields).filter(([name, behaviour]) => behaviour.visible && !folded.has(name)).length;
	}, ...ngDevMode ? [{ debugName: "placedCount" }] : /* istanbul ignore next */ []);
	paletteGrids = computed(() => {
		const document = this.document();
		if (document === null) return null;
		const term = this.paletteSearch().trim().toLowerCase();
		const filter = this.paletteFilter();
		const tabLabels = new Map(document.tabs.map((tab) => [tab.id, tab.label]));
		const grids = this.blocks.filter((block) => term === "" || block.label.toLowerCase().includes(term) || block.collection.includes(term)).map((block) => ({
			id: block.collection,
			label: block.label,
			place: tabLabels.get(blockTab(document, block)) ?? null
		})).filter((entry) => !(filter === "placed" && entry.place === null || filter === "unplaced" && entry.place !== null));
		return grids.length === 0 ? null : {
			id: GRIDS_GROUP,
			label: "Grids",
			expanded: term !== "" || !this.collapsedGroups().has(GRIDS_GROUP),
			grids
		};
	}, ...ngDevMode ? [{ debugName: "paletteGrids" }] : /* istanbul ignore next */ []);
	placeGrid(collection) {
		const tab = this.shownTab();
		if (tab !== null) {
			this.run({
				kind: "moveCollection",
				collection,
				tab
			});
			this.selection.set({
				kind: "block",
				id: collection
			});
		}
	}
	me = toSignal(this.meSource === null ? of(void 0) : this.meSource.get().pipe(map((state) => state.status === "loaded" ? state.value : state.status === "error" ? void 0 : null)), { initialValue: null });
	canWrite = computed(() => {
		const me = this.me();
		const dimensions = this.dimensions();
		if (me === void 0) return true;
		return dimensions !== null && holdsPermission(me, dimensions.locationCode, "settings:manage");
	}, ...ngDevMode ? [{ debugName: "canWrite" }] : /* istanbul ignore next */ []);
	saving = signal(false, ...ngDevMode ? [{ debugName: "saving" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	overKey = signal(null, ...ngDevMode ? [{ debugName: "overKey" }] : /* istanbul ignore next */ []);
	dragging = signal(null, ...ngDevMode ? [{ debugName: "dragging" }] : /* istanbul ignore next */ []);
	gesture = new PointerDragGesture({
		handleSelector: "[data-drag]",
		ignoreSelector: "button:not([data-drag-grip]), input, select, textarea",
		source: (handle) => {
			const kind = handle.getAttribute("data-drag");
			const id = handle.getAttribute("data-id");
			return this.readOnly() || kind === null || id === null ? null : {
				kind,
				id
			};
		},
		target: (x, y) => {
			const element = elementUnder(x, y, "[data-drop]");
			if (element === null) return null;
			const kind = element.getAttribute("data-drop");
			const key = element.getAttribute("data-key") ?? "";
			const index = Number(element.getAttribute("data-index") ?? Number.MAX_SAFE_INTEGER);
			const shown = this.shownTab();
			if (this.dragging()?.kind === "block" && kind !== "tab" && kind !== "tab-end" && shown !== null) return {
				kind: "tab-end",
				key: `tab-end:${shown}`,
				tab: shown,
				index: Number.MAX_SAFE_INTEGER
			};
			const box = kind === "field" ? element.getBoundingClientRect() : null;
			const after = box !== null && box.height > 0 && y > box.top + box.height / 2;
			return {
				kind,
				key: after ? key.replace(/^field:/, "after:") : key,
				section: element.getAttribute("data-section") ?? void 0,
				tab: element.getAttribute("data-tab") ?? void 0,
				index: after ? index + 1 : index
			};
		},
		started: (source) => this.dragging.set(source),
		over: (target) => {
			this.overKey.set(target === null ? null : target.key);
			this.hoverTab(target);
		},
		ended: () => {
			this.dragging.set(null);
			this.overKey.set(null);
			this.clearTabHover();
		},
		dropped: (source, target) => {
			const op = this.dropOp(source, target);
			if (op !== null) this.run(op);
		}
	});
	readOnly = computed(() => !this.canWrite(), ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	layout = inject(AdminLayout, { optional: true });
	constructor() {
		inject(DestroyRef).onDestroy(() => {
			this.gesture.cancel();
			this.layout?.wide.set(false);
		});
		effect(() => {
			const editing = this.editing();
			untracked(() => this.layout?.wide.set(editing));
		});
		this.source.registry().subscribe((state) => {
			if (state.status === "loaded") this.registry.set(state.value);
		});
		this.reloadRows();
		const params = this.route?.snapshot.queryParamMap;
		if (params !== void 0 && (params.has("tradeUnit") || params.has("type") || params.has("commodity"))) {
			this.typeInput.set(params.get("type") ?? "");
			this.locationInput.set(params.get("tradeUnit") ?? "");
			this.commodityInput.set(params.get("commodity") ?? "");
			this.open();
		}
	}
	open() {
		if (this.dirty() && !this.confirmDiscard()) return;
		const dimensions = {
			contractTypeClass: this.typeInput().trim(),
			locationCode: this.locationInput().trim(),
			commodityCode: this.commodityInput().trim().toUpperCase()
		};
		this.dimensions.set(dimensions);
		this.load(dimensions);
	}
	load(dimensions) {
		this.loadState.set("loading");
		this.loadError.set(null);
		this.outcome.set(null);
		this.selection.set(null);
		const own = this.rows().find((row) => row.isActive && sameDimensions(row, dimensions));
		if (own !== void 0) {
			this.source.get(own.id).subscribe((state) => {
				if (state.status === "loaded") {
					this.ownRow.set(state.value);
					this.inheritedFrom.set(null);
					this.start(state.value.config);
				} else if (state.status === "error") this.fail(state.error.message);
			});
			return;
		}
		this.source.preview(previewDimensionsOf(dimensions)).subscribe((state) => {
			if (state.status === "loaded") {
				this.ownRow.set(null);
				this.inheritedFrom.set(state.value.provenance.configId);
				this.start(documentFromResolution(state.value));
			} else if (state.status === "error") this.fail(state.error.message);
		});
	}
	start(document) {
		this.baseline.set(document);
		this.history.set(BuilderHistory.start(document));
		this.loadState.set("loaded");
		if (!document.tabs.some((tab) => tab.id === this.activeTab())) this.activeTab.set(orderedTabs(document)[0]?.id ?? null);
	}
	fail(message) {
		this.loadState.set("error");
		this.loadError.set(message);
	}
	reloadRows() {
		this.source.list().subscribe((state) => {
			if (state.status === "loaded") this.rows.set(state.value.rows);
		});
	}
	run(op) {
		const history = this.history();
		if (history === null || this.readOnly()) return;
		this.history.set(history.apply(op, this.rules()));
		this.outcome.set(null);
		const document = this.document();
		if (document !== null && !document.tabs.some((tab) => tab.id === this.activeTab())) this.activeTab.set(orderedTabs(document)[0]?.id ?? null);
	}
	undo() {
		this.history.update((history) => history?.undo() ?? null);
	}
	redo() {
		this.history.update((history) => history?.redo() ?? null);
	}
	discard() {
		this.gesture.cancel();
		this.dimensions.set(null);
		this.history.set(null);
		this.baseline.set(null);
		this.ownRow.set(null);
		this.inheritedFrom.set(null);
		this.selection.set(null);
		this.problems.set(null);
		this.outcome.set(null);
		this.inspector.set(null);
		this.loadState.set("idle");
	}
	addTab() {
		this.ask({
			title: "Add a tab",
			label: "Name the new tab"
		}, (label) => {
			this.run({
				kind: "addTab",
				label
			});
			const document = this.document();
			const added = document === null ? void 0 : orderedTabs(document).at(-1);
			if (added !== void 0 && added.label === label.trim()) this.activeTab.set(added.id);
		});
	}
	renameTab(tab, current) {
		this.ask({
			title: `Rename the ${current} tab`,
			label: "Rename the tab",
			value: current
		}, (label) => {
			this.run({
				kind: "renameTab",
				tab,
				label
			});
		});
	}
	deleteTab(tab, label) {
		this.confirmDelete(`Delete the ${label} tab?`, "Its sections go too, and their fields return to the palette. Undo brings them back.", () => this.run({
			kind: "deleteTab",
			tab
		}));
	}
	addSection(tab) {
		this.ask({
			title: "Add a section",
			label: "Name the new section"
		}, (label) => {
			this.run({
				kind: "addSection",
				tab,
				label
			});
		});
	}
	renameSection(section, current) {
		this.ask({
			title: `Rename the ${current} section`,
			label: "Rename the section heading",
			value: current
		}, (label) => {
			this.run({
				kind: "renameSection",
				section,
				label
			});
		});
	}
	deleteSection(section, label) {
		this.confirmDelete(`Delete the ${label} section?`, "Its fields return to the palette. Undo brings them back.", () => this.run({
			kind: "deleteSection",
			section
		}));
	}
	ask(request, then) {
		this.prompt(request).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((label) => {
			if (label !== null) then(label);
		});
	}
	confirmDelete(title, message, then) {
		this.confirm({
			title,
			message,
			confirmLabel: "Confirm",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) then();
		});
	}
	placeTarget = computed(() => {
		const document = this.document();
		const selected = this.selection();
		const id = selected?.kind === "section" ? selected.id : selected?.kind === "field" ? document?.fields[selected.id]?.section : this.shownSections()[0]?.id;
		const section = document?.sections.find((candidate) => candidate.id === id);
		return section === void 0 ? null : {
			id: section.id,
			label: section.label
		};
	}, ...ngDevMode ? [{ debugName: "placeTarget" }] : /* istanbul ignore next */ []);
	placeFromPalette(field) {
		const section = this.placeTarget()?.id;
		if (section !== void 0) {
			this.run({
				kind: "placeField",
				field,
				section,
				index: Number.MAX_SAFE_INTEGER
			});
			this.selection.set({
				kind: "field",
				id: field
			});
		}
	}
	toggleVisible(field) {
		const behaviour = this.document()?.fields[field];
		if (behaviour !== void 0) this.run({
			kind: "setFieldFlags",
			field,
			flags: { visible: !behaviour.visible }
		});
	}
	removeField(field) {
		if (this.removeBlocked(field) === null) this.run({
			kind: "setFieldFlags",
			field,
			flags: { visible: false }
		});
	}
	removeBlocked(field) {
		const lock = this.groupLock(field);
		if (lock !== null) return `${lock}.`;
		if (this.registry()?.fields[field]?.configurable === false) return `${this.fieldLabel(field)} cannot be removed: every contract form shows it.`;
		return this.ctrmRequired().has(field) ? `${this.fieldLabel(field)} cannot be removed. ${CTRM_REQUIRED_REASON}.` : null;
	}
	groupLock(row) {
		const document = this.document();
		const group = document === null ? void 0 : groupLedBy(document, row);
		return group === void 0 ? null : groupLockReason(group);
	}
	rowLabel(row) {
		const document = this.document();
		return (document === null ? void 0 : groupLedBy(document, row)?.heading) ?? this.fieldLabel(row);
	}
	membersOf(row) {
		const document = this.document();
		return document === null ? [row] : rowMembers(document, row);
	}
	rowChanged(row) {
		const changed = this.changed().fields;
		return this.membersOf(row).some((name) => changed.has(name));
	}
	rowInvalid(row) {
		const invalid = this.invalid().fields;
		return this.membersOf(row).some((name) => invalid.has(name));
	}
	propertiesSelection = computed(() => {
		const selected = this.selection();
		return selected?.kind === "field" && this.groupLock(selected.id) !== null ? null : selected;
	}, ...ngDevMode ? [{ debugName: "propertiesSelection" }] : /* istanbul ignore next */ []);
	toggleRequired(field) {
		const behaviour = this.document()?.fields[field];
		if (behaviour !== void 0) this.run({
			kind: "setFieldFlags",
			field,
			flags: { required: !behaviour.required }
		});
	}
	dropOp(source, target) {
		const document = this.document();
		if (document === null) return null;
		switch (source.kind) {
			case "field":
			case "palette": {
				const kind = source.kind === "palette" ? "placeField" : "moveField";
				const section = target.section ?? (target.tab === void 0 ? void 0 : sectionsOf(document, target.tab)[0]?.id);
				if (section === void 0) return null;
				let index = target.kind === "field" ? target.index : target.kind === "section" ? 0 : Number.MAX_SAFE_INTEGER;
				const behaviour = document.fields[source.id];
				const rows = canvasRows(document, section);
				if (target.kind === "field" && behaviour?.visible === true && behaviour.section === section) {
					const from = rows.indexOf(source.id);
					if (from >= 0 && from < index) index -= 1;
					if (from === index) return null;
				}
				const others = rows.filter((name) => name !== source.id);
				return rowMoveOp(document, source.id, section, others[index] ?? null, this.rules(), kind);
			}
			case "section": {
				const tab = target.tab;
				return tab === void 0 || target.kind === "field" || target.kind === "section-end" ? null : {
					kind: "moveSection",
					section: source.id,
					tab,
					index: target.kind === "section" ? target.index : Number.MAX_SAFE_INTEGER
				};
			}
			case "tab": return target.kind === "tab" ? {
				kind: "moveTab",
				tab: source.id,
				index: target.index
			} : null;
			case "block": {
				const block = this.blocks.find((candidate) => candidate.collection === source.id);
				return block === void 0 || target.tab === void 0 || target.kind !== "tab" && target.kind !== "tab-end" || blockTab(document, block) === target.tab ? null : {
					kind: "moveCollection",
					collection: source.id,
					tab: target.tab
				};
			}
		}
	}
	onPointerDown(event) {
		this.gesture.press(event);
	}
	tabHover = null;
	hoverTab(target) {
		const tab = target?.kind === "tab" && this.dragging()?.kind !== "tab" ? target.tab : void 0;
		if (tab !== void 0 && tab === this.tabHover?.tab) return;
		this.clearTabHover();
		if (tab !== void 0 && tab !== this.shownTab()) this.tabHover = {
			tab,
			timer: setTimeout(() => {
				this.tabHover = null;
				this.activeTab.set(tab);
			}, 600)
		};
	}
	clearTabHover() {
		if (this.tabHover !== null) {
			clearTimeout(this.tabHover.timer);
			this.tabHover = null;
		}
	}
	fieldDrag = computed(() => {
		const kind = this.dragging()?.kind;
		return kind === "field" || kind === "palette";
	}, ...ngDevMode ? [{ debugName: "fieldDrag" }] : /* istanbul ignore next */ []);
	onKeydown(event) {
		const target = event.target;
		const typing = target !== null && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName);
		if ((event.ctrlKey || event.metaKey) && !typing) {
			if (event.key.toLowerCase() === "z" && !event.shiftKey) {
				event.preventDefault();
				this.undo();
			} else if (event.key.toLowerCase() === "y" || event.key.toLowerCase() === "z" && event.shiftKey) {
				event.preventDefault();
				this.redo();
			}
			return;
		}
		if (event.key === "Escape") {
			this.gesture.cancel();
			this.selection.set(null);
			return;
		}
		if (!event.altKey || typing) return;
		const op = this.keyboardOp(event.key);
		if (op !== null) {
			event.preventDefault();
			this.run(op);
			if (op.kind === "moveCollection") this.activeTab.set(op.tab);
		}
	}
	keyboardOp(key) {
		const document = this.document();
		const selected = this.selection();
		if (document === null || selected === null) return null;
		if (selected.kind === "field") {
			const behaviour = document.fields[selected.id];
			if (behaviour === void 0) return null;
			const rows = canvasRows(document, behaviour.section);
			const index = rows.indexOf(selected.id);
			const order = orderedTabs(document).flatMap((tab) => sectionsOf(document, tab.id).map((section) => section.id));
			const at = order.indexOf(behaviour.section);
			const move = (section, before) => rowMoveOp(document, selected.id, section, before, this.rules());
			switch (key) {
				case "ArrowUp": return index > 0 ? move(behaviour.section, rows[index - 1]) : null;
				case "ArrowDown": return index >= 0 && index < rows.length - 1 ? move(behaviour.section, rows[index + 2] ?? null) : null;
				case "ArrowLeft": return at > 0 ? move(order[at - 1], null) : null;
				case "ArrowRight": return at >= 0 && at < order.length - 1 ? move(order[at + 1], canvasRows(document, order[at + 1])[0] ?? null) : null;
			}
		}
		if (selected.kind === "section") {
			const section = document.sections.find((candidate) => candidate.id === selected.id);
			if (section === void 0) return null;
			const siblings = sectionsOf(document, section.tab);
			const index = siblings.findIndex((candidate) => candidate.id === section.id);
			const tabs = orderedTabs(document).map((tab) => tab.id);
			const at = tabs.indexOf(section.tab);
			switch (key) {
				case "ArrowUp": return index > 0 ? {
					kind: "moveSection",
					section: section.id,
					tab: section.tab,
					index: index - 1
				} : null;
				case "ArrowDown": return index < siblings.length - 1 ? {
					kind: "moveSection",
					section: section.id,
					tab: section.tab,
					index: index + 1
				} : null;
				case "ArrowLeft": return at > 0 ? {
					kind: "moveSection",
					section: section.id,
					tab: tabs[at - 1],
					index: Number.MAX_SAFE_INTEGER
				} : null;
				case "ArrowRight": return at < tabs.length - 1 ? {
					kind: "moveSection",
					section: section.id,
					tab: tabs[at + 1],
					index: Number.MAX_SAFE_INTEGER
				} : null;
			}
		}
		if (selected.kind === "tab") {
			const tabs = orderedTabs(document).map((tab) => tab.id);
			const at = tabs.indexOf(selected.id);
			switch (key) {
				case "ArrowLeft": return at > 0 ? {
					kind: "moveTab",
					tab: selected.id,
					index: at - 1
				} : null;
				case "ArrowRight": return at < tabs.length - 1 ? {
					kind: "moveTab",
					tab: selected.id,
					index: at + 1
				} : null;
			}
		}
		if (selected.kind === "block") {
			const block = this.blocks.find((candidate) => candidate.collection === selected.id);
			const tabs = orderedTabs(document).map((tab) => tab.id);
			const at = block === void 0 ? -1 : tabs.indexOf(blockTab(document, block));
			switch (key) {
				case "ArrowLeft": return at > 0 ? {
					kind: "moveCollection",
					collection: selected.id,
					tab: tabs[at - 1]
				} : null;
				case "ArrowRight": return at >= 0 && at < tabs.length - 1 ? {
					kind: "moveCollection",
					collection: selected.id,
					tab: tabs[at + 1]
				} : null;
			}
		}
		return null;
	}
	moveTargets = computed(() => {
		const document = this.document();
		return document === null ? [] : orderedTabs(document).flatMap((tab) => sectionsOf(document, tab.id).map((section) => ({
			id: section.id,
			label: `${tab.label} › ${section.label}`
		})));
	}, ...ngDevMode ? [{ debugName: "moveTargets" }] : /* istanbul ignore next */ []);
	shownTabInfo = computed(() => this.tabs().find((tab) => tab.id === this.shownTab()) ?? null, ...ngDevMode ? [{ debugName: "shownTabInfo" }] : /* istanbul ignore next */ []);
	sectionTargets = computed(() => {
		const targets = this.moveTargets();
		return new Map(targets.map((own) => [own.id, targets.map((target) => ({
			...target,
			current: target.id === own.id
		}))]));
	}, ...ngDevMode ? [{ debugName: "sectionTargets" }] : /* istanbul ignore next */ []);
	tabTargets = computed(() => {
		const tabs = this.tabs();
		return new Map(tabs.map((own) => [own.id, tabs.map((tab) => ({
			id: tab.id,
			label: tab.label,
			current: tab.id === own.id
		}))]));
	}, ...ngDevMode ? [{ debugName: "tabTargets" }] : /* istanbul ignore next */ []);
	fieldActions = computed(() => {
		const document = this.document();
		const actions = /* @__PURE__ */ new Map();
		if (document === null) return actions;
		for (const section of document.sections) {
			const rows = canvasRows(document, section.id);
			const move = (name, before) => () => this.runOp(rowMoveOp(document, name, section.id, before, this.rules()));
			rows.forEach((name, index) => {
				actions.set(name, [
					...this.groupLock(name) === null ? [{
						label: "Properties",
						run: () => this.select({
							kind: "field",
							id: name
						})
					}] : [],
					...index > 0 ? [{
						label: "Move up",
						run: move(name, rows[index - 1])
					}] : [],
					...index < rows.length - 1 ? [{
						label: "Move down",
						run: move(name, rows[index + 2] ?? null)
					}] : [],
					{
						label: "Remove from form",
						run: () => this.removeField(name),
						refusal: this.removeBlocked(name),
						destructive: true
					}
				]);
			});
		}
		return actions;
	}, ...ngDevMode ? [{ debugName: "fieldActions" }] : /* istanbul ignore next */ []);
	sectionActions = computed(() => {
		const document = this.document();
		return new Map((document?.sections ?? []).map((section) => [section.id, [{
			label: "Delete section",
			run: () => this.deleteSection(section.id, section.label),
			destructive: true
		}]]));
	}, ...ngDevMode ? [{ debugName: "sectionActions" }] : /* istanbul ignore next */ []);
	gridActions = [{
		label: "Remove from form",
		run: () => void 0,
		refusal: GRID_REMOVE_REFUSAL,
		destructive: true
	}];
	paletteSearchInput = viewChild("paletteSearchInput", ...ngDevMode ? [{ debugName: "paletteSearchInput" }] : /* istanbul ignore next */ []);
	addFieldTo(section) {
		this.selection.set({
			kind: "section",
			id: section
		});
		this.paletteFilter.set("unplaced");
		this.paletteSearchInput()?.nativeElement.focus();
	}
	moveFieldTo(field, section) {
		const document = this.document();
		if (section !== "" && document !== null) this.runOp(rowMoveOp(document, field, section, null, this.rules()));
	}
	runOp(op) {
		if (op !== null) this.run(op);
	}
	moveSectionTo(section, tab) {
		if (tab !== "") this.run({
			kind: "moveSection",
			section,
			tab,
			index: Number.MAX_SAFE_INTEGER
		});
	}
	moveBlockTo(block, tab) {
		if (tab !== "") this.run({
			kind: "moveCollection",
			collection: block.collection,
			tab
		});
	}
	select(selection, event) {
		event?.stopPropagation();
		this.selection.set(selection);
		if (selection.kind !== "field" || this.groupLock(selection.id) === null) this.inspector.set("properties");
	}
	isSelected(kind, id) {
		const selected = this.selection();
		return selected?.kind === kind && selected.id === id;
	}
	fieldLabel(field) {
		return this.registry()?.fields[field]?.label ?? field;
	}
	fieldBehaviour(field) {
		return this.document()?.fields[field];
	}
	allFieldsOf(section) {
		const document = this.document();
		return document === null ? [] : fieldsOf(document, section);
	}
	seedRows = computed(() => {
		const own = this.ownRow()?.id;
		return this.rows().filter((row) => row.isActive && row.id !== own);
	}, ...ngDevMode ? [{ debugName: "seedRows" }] : /* istanbul ignore next */ []);
	scratchDescription = "One new tab and section with only the fields every contract form shows. Every other field is Unplaced in the field list, ready to drag in.";
	seedFrom(rowId) {
		if (rowId === "" || this.readOnly()) return;
		if (rowId === "scratch") {
			const document = this.document();
			if (document !== null) {
				this.selection.set(null);
				this.run({
					kind: "replace",
					document: scratchDocument(document, this.rules())
				});
				this.outcome.set({
					text: `Started from scratch. ${this.scratchDescription}`,
					failed: false,
					conflict: false
				});
			}
			return;
		}
		if (rowId === "default") {
			this.source.preview({}).subscribe((state) => {
				if (state.status === "loaded") this.run({
					kind: "replace",
					document: documentFromResolution(state.value)
				});
			});
			return;
		}
		this.source.get(Number(rowId)).subscribe((state) => {
			if (state.status === "loaded") this.run({
				kind: "replace",
				document: state.value.config
			});
		});
	}
	jsonFileName() {
		const dimensions = this.dimensions();
		const part = (value) => value === void 0 || value === "" ? "any" : value.replace(/[^A-Za-z0-9-]/g, "-");
		return `form-config-${part(dimensions?.contractTypeClass)}-${part(dimensions?.locationCode)}-${part(dimensions?.commodityCode)}.json`;
	}
	async copyJson() {
		const document = this.document();
		if (document === null) return;
		try {
			await this.dom.defaultView.navigator.clipboard.writeText(configJson(document));
			this.outcome.set({
				text: "Copied the form configuration JSON to the clipboard.",
				failed: false,
				conflict: false
			});
		} catch {
			this.downloadJson();
			this.outcome.set({
				text: `The clipboard was refused, so the JSON was downloaded as ${this.jsonFileName()} instead.`,
				failed: false,
				conflict: false
			});
		}
	}
	downloadJson() {
		const document = this.document();
		const view = this.dom.defaultView;
		if (document === null || view === null) return;
		const url = view.URL.createObjectURL(new Blob([configJson(document)], { type: "application/json" }));
		const link = this.dom.createElement("a");
		link.href = url;
		link.download = this.jsonFileName();
		link.click();
		view.URL.revokeObjectURL(url);
		this.outcome.set({
			text: `Downloaded ${this.jsonFileName()}.`,
			failed: false,
			conflict: false
		});
	}
	importJson() {
		const current = this.document();
		if (current === null || this.readOnly()) return;
		this.importDialog({ check: (text) => readConfigJson(text, this.rules().fields, current) }).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((result) => {
			if (result === null) return;
			this.selection.set(null);
			this.run({
				kind: "replace",
				document: result.document
			});
			const notes = [result.ignored.length === 0 ? "" : ` ${countOf(result.ignored.length, "field")} the registry does not know ${result.ignored.length === 1 ? "was" : "were"} ignored.`, result.added.length === 0 ? "" : ` ${countOf(result.added.length, "field")} it did not carry ${result.added.length === 1 ? "was" : "were"} added unplaced.`].join("");
			this.outcome.set({
				text: `Imported the JSON. Not saved until Save.${notes}`,
				failed: false,
				conflict: false
			});
		});
	}
	save() {
		const document = this.document();
		const dimensions = this.dimensions();
		if (document === null || dimensions === null || this.readOnly()) return;
		const own = this.ownRow();
		const submission = {
			...dimensions.contractTypeClass === "" ? {} : { contractTypeClass: dimensions.contractTypeClass },
			...dimensions.locationCode === "" ? {} : { locationCode: dimensions.locationCode },
			...dimensions.commodityCode === "" ? {} : { commodityCode: dimensions.commodityCode },
			effectiveFrom: own?.effectiveFrom ?? todayIso(),
			config: document
		};
		this.saving.set(true);
		this.outcome.set(null);
		(own === null ? this.source.create(submission) : this.source.update(own.id, own.rowVersion, submission)).subscribe((state) => {
			if (state.status === "loaded") {
				this.saving.set(false);
				this.ownRow.set(state.value);
				this.inheritedFrom.set(null);
				this.baseline.set(state.value.config);
				this.history.set(BuilderHistory.start(state.value.config));
				this.outcome.set({
					text: "Saved. A create for these dimensions now uses this form.",
					failed: false,
					conflict: false
				});
				this.reloadRows();
			} else if (state.status === "error") {
				this.saving.set(false);
				this.outcome.set({
					text: state.error.message,
					failed: true,
					conflict: state.error.status === 409 || /changed since/i.test(state.error.message)
				});
			}
		});
	}
	reloadAfterConflict() {
		const dimensions = this.dimensions();
		if (dimensions !== null) this.source.list().subscribe((state) => {
			if (state.status === "loaded") {
				this.rows.set(state.value.rows);
				this.load(dimensions);
			}
		});
	}
	canLeave() {
		return !this.dirty() || this.confirmDiscard();
	}
	onBeforeUnload(event) {
		if (this.dirty()) event.preventDefault();
	}
	confirmDiscard() {
		return this.confirm({
			title: "Leave without saving?",
			message: "You have unsaved changes to this form. Leave without saving them?",
			confirmLabel: "Discard changes",
			cancelLabel: "Keep editing",
			destructive: true
		});
	}
	openRows() {
		this.router?.navigate(["rows"], { relativeTo: this.route ?? void 0 });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormBuilderPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormBuilderPageComponent,
		isStandalone: true,
		selector: "cms-form-builder-page",
		host: { listeners: {
			"window:beforeunload": "onBeforeUnload($event)",
			"keydown": "onKeydown($event)"
		} },
		providers: [AdminScope],
		viewQueries: [{
			propertyName: "paletteSearchInput",
			first: true,
			predicate: ["paletteSearchInput"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\" aria-labelledby=\"form-builder-heading\">\n  <!--\n    With a form open the builder takes the whole width: the heading stays for a screen reader (the page keeps its\n    one h2), and the area's tabs and the pickers step aside until Discard. The toolbar names what is open.\n  -->\n  <div [class.cws:sr-only]=\"editing()\">\n    <!-- The Admin section's one h2 per page is the area's title (#825); the view is the h3. -->\n    <h2 id=\"form-builder-heading\" class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Form configuration</h2>\n    <h3 class=\"cws:mt-1 cws:text-sm cws:font-semibold cws:text-slate-800 cws:dark:text-slate-100\">Form builder</h3>\n    <p class=\"cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n      Build the contract form for a contract type, trade unit and commodity. Drag fields from the palette, arrange\n      tabs and sections, then save. A blank dimension means <em>any</em>.\n    </p>\n  </div>\n\n  @if (area && !editing()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Form configuration views\" />\n  }\n\n  <!-- F1: the dimensions, applied with Open. -->\n  @if (!editing()) {\n  <form class=\"scoular-card cws:grid cws:gap-3 cws:p-4 cws:md:grid-cols-4 cws:md:items-end\" (submit)=\"$event.preventDefault(); open()\">\n    <label class=\"cws:block\">\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type</span>\n      <input\n        class=\"scoular-form-input cws:mt-1 cws:w-full\"\n        [value]=\"typeInput()\"\n        (input)=\"typeInput.set($any($event.target).value)\"\n        placeholder=\"Any\"\n        data-testid=\"builder-type\"\n      />\n    </label>\n    <cws-admin-trade-unit-select\n      label=\"Trade unit\"\n      [allowAny]=\"true\"\n      [everyLocation]=\"true\"\n      [value]=\"locationInput()\"\n      (valueChange)=\"locationInput.set($event)\"\n    />\n    <label class=\"cws:block\">\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\n      <input\n        class=\"scoular-form-input cws:mt-1 cws:w-full\"\n        [value]=\"commodityInput()\"\n        (input)=\"commodityInput.set($any($event.target).value)\"\n        placeholder=\"Any\"\n        data-testid=\"builder-commodity\"\n      />\n    </label>\n    <div>\n      <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" data-testid=\"builder-open\">Open</button>\n    </div>\n  </form>\n  }\n\n  @switch (loadState()) {\n    @case ('idle') {\n      <p class=\"scoular-card cws:p-4 cws:text-sm\">Choose the dimensions and Open to build their form.</p>\n    }\n    @case ('loading') {\n      <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">Loading the form…</p>\n    }\n    @case ('error') {\n      <p role=\"alert\" class=\"scoular-card cws:p-4 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\n        The form could not be loaded. {{ loadError() }}\n      </p>\n    }\n    @default {\n      @if (document(); as doc) {\n        <!-- The toolbar: what is open, the row, undo, redo, discard, save (F9, F13). -->\n        <div class=\"scoular-card cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:p-3\" data-testid=\"builder-toolbar\">\n          <p class=\"cws:mr-auto cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" data-testid=\"builder-row\">\n            <span class=\"cws:block cws:font-semibold cws:text-slate-900 cws:dark:text-white\" data-testid=\"builder-dimensions\">{{ openedOn() }}</span>\n            @if (ownRow(); as row) {\n              Editing configuration row {{ row.id }}, version {{ row.version }}.\n            } @else {\n              No row at these dimensions yet: the form below is inherited ({{ inheritedBadge() }}). Saving creates the row.\n            }\n            {{ placedCount() }} fields placed.\n          </p>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"!history()?.canUndo || readOnly()\" (click)=\"undo()\" data-testid=\"builder-undo\">\n            Undo\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"!history()?.canRedo || readOnly()\" (click)=\"redo()\" data-testid=\"builder-redo\">\n            Redo\n          </button>\n          <label class=\"cws:flex cws:items-center cws:gap-1 cws:text-sm\">\n            <span class=\"cws:sr-only\">Start from</span>\n            <select\n              class=\"scoular-form-input cws:text-sm\"\n              [disabled]=\"readOnly()\"\n              (change)=\"seedFrom($any($event.target).value); $any($event.target).value = ''\"\n              data-testid=\"builder-seed\"\n            >\n              <option value=\"\">Start from…</option>\n              <option value=\"default\">The default</option>\n              <option value=\"scratch\" [title]=\"scratchDescription\">Scratch (empty form)</option>\n              @for (row of seedRows(); track row.id) {\n                <option [value]=\"row.id\">Row {{ row.id }}: {{ row.dimensionKey }}</option>\n              }\n            </select>\n          </label>\n          <!-- The draft as JSON (2026-10-30): one menu, so the toolbar keeps its width. Import is refused read-only. -->\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-secondary\"\n            aria-haspopup=\"menu\"\n            [cdkMenuTriggerFor]=\"jsonMenu\"\n            data-testid=\"builder-json\"\n          >\n            JSON\n          </button>\n          <ng-template #jsonMenu>\n            <div cdkMenu class=\"scoular-dropdown cws:static cws:mt-1 cws:min-w-48\" aria-label=\"JSON\">\n              <button type=\"button\" cdkMenuItem class=\"scoular-dropdown-item\" (cdkMenuItemTriggered)=\"copyJson()\" data-testid=\"builder-json-copy\">\n                Copy JSON\n              </button>\n              <button type=\"button\" cdkMenuItem class=\"scoular-dropdown-item\" (cdkMenuItemTriggered)=\"downloadJson()\" data-testid=\"builder-json-download\">\n                Download JSON\n              </button>\n              <button\n                type=\"button\"\n                cdkMenuItem\n                class=\"scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0\"\n                [class.cws:cursor-not-allowed]=\"readOnly()\"\n                [class.cws:opacity-60]=\"readOnly()\"\n                [cdkMenuItemDisabled]=\"readOnly()\"\n                (cdkMenuItemTriggered)=\"importJson()\"\n                data-testid=\"builder-json-import\"\n              >\n                <span>Import JSON…</span>\n                @if (readOnly()) {\n                  <span class=\"cws:max-w-64 cws:text-xs cws:whitespace-normal cws:text-slate-500 cws:dark:text-slate-400\">Importing needs the settings permission in this trade unit.</span>\n                }\n              </button>\n            </div>\n          </ng-template>\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-secondary\"\n            [disabled]=\"saving()\"\n            title=\"Close the builder without saving, back to the dimensions\"\n            (click)=\"discard()\"\n            data-testid=\"builder-discard\"\n          >\n            Discard\n          </button>\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-primary\"\n            [disabled]=\"readOnly() || saving() || (!dirty() && ownRow() !== null)\"\n            (click)=\"save()\"\n            data-testid=\"builder-save\"\n          >\n            @if (saving()) { Saving… } @else { Save }\n          </button>\n        </div>\n\n        @if (readOnly()) {\n          <!-- F16 -->\n          <p role=\"status\" class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"builder-read-only\">\n            You can look at this form. Changing it needs the settings permission in this trade unit.\n          </p>\n        }\n\n        @if (outcome(); as result) {\n          <div\n            role=\"status\"\n            class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:text-sm\"\n            [class.cws:text-red-700]=\"result.failed\"\n            data-testid=\"builder-outcome\"\n          >\n            <span class=\"cws:whitespace-pre-line\">{{ result.text }}</span>\n            @if (result.conflict) {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"reloadAfterConflict()\" data-testid=\"builder-reload\">\n                Reload\n              </button>\n            }\n          </div>\n        }\n\n        <!--\n          🔴 select-none on the whole builder (Known Issue 44): a press inside a leftover text selection is a\n          SELECTION drag, which the browser announces with pointercancel, so without it the gesture works once and\n          then stops. The shared helper cannot apply this class itself.\n\n          Three columns from xl: the fields, the form's layout, and the live preview. The two outer columns are\n          sticky with their own scroll, so the preview stays in view however long the layout grows. From lg the\n          fields and the layout share the row and the preview sits under them; below lg each is full width, the\n          layout first after a short field list.\n        -->\n        <div\n          class=\"cws:grid cws:select-none cws:gap-4 cws:lg:grid-cols-[14rem_minmax(0,1fr)] cws:xl:grid-cols-[15rem_minmax(0,1fr)_minmax(0,1fr)] cws:2xl:grid-cols-[16rem_minmax(0,1fr)_minmax(0,1.15fr)]\"\n          (pointerdown)=\"onPointerDown($event)\"\n          data-testid=\"builder\"\n        >\n          <!--\n            F5: the palette, the field library. Search, a filter by whether a field is on the form, and the\n            registry's groups, each foldable; a search shows its matches in every group, folded or not. Every entry\n            is a drag source onto the layout, and an unplaced one has Place as its keyboard path.\n          -->\n          <aside\n            class=\"scoular-card cws:flex cws:max-h-80 cws:min-w-0 cws:flex-col cws:overflow-hidden cws:lg:sticky cws:lg:top-4 cws:lg:max-h-[calc(100vh-2rem)] cws:lg:self-start\"\n            aria-label=\"Field palette\"\n            data-testid=\"builder-palette\"\n          >\n            <div class=\"cws:shrink-0 cws:space-y-2 cws:border-b cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n              <div class=\"cws:flex cws:items-baseline cws:justify-between cws:gap-2\">\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-800 cws:dark:text-slate-100\">Fields</h3>\n                <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"builder-palette-count\">{{ placedCount() }} of {{ fieldCount() }} placed</span>\n              </div>\n              <label class=\"cws:block\">\n                <span class=\"cws:sr-only\">Search fields</span>\n                <input\n                  #paletteSearchInput\n                  class=\"scoular-form-input cws:w-full cws:text-sm\"\n                  placeholder=\"Search fields\"\n                  [value]=\"paletteSearch()\"\n                  (input)=\"paletteSearch.set($any($event.target).value)\"\n                  data-testid=\"builder-palette-search\"\n                />\n              </label>\n              <div role=\"group\" aria-label=\"Show fields\" class=\"cws:flex cws:rounded-md cws:bg-slate-100 cws:p-0.5 cws:dark:bg-slate-900\">\n                @for (option of paletteFilters; track option.id) {\n                  <button\n                    type=\"button\"\n                    class=\"cws:flex-1 cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white\"\n                    [class.cws:bg-white]=\"paletteFilter() === option.id\"\n                    [class.cws:shadow-sm]=\"paletteFilter() === option.id\"\n                    [class.cws:text-slate-900]=\"paletteFilter() === option.id\"\n                    [class.cws:dark:bg-slate-700]=\"paletteFilter() === option.id\"\n                    [class.cws:dark:text-white]=\"paletteFilter() === option.id\"\n                    [attr.aria-pressed]=\"paletteFilter() === option.id\"\n                    (click)=\"paletteFilter.set(option.id)\"\n                    [attr.data-testid]=\"'builder-palette-filter-' + option.id\"\n                  >\n                    {{ option.label }}\n                  </button>\n                }\n              </div>\n              @if (!readOnly() && placeTarget(); as target) {\n                <p class=\"cws:truncate cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"builder-place-target\">\n                  Place adds to <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">{{ target.label }}</span>\n                </p>\n              }\n            </div>\n\n            <div class=\"cws:min-h-0 cws:flex-1 cws:overflow-y-auto cws:px-2 cws:pt-1 cws:pb-2\">\n              @for (group of palette(); track group.id) {\n                <div class=\"cws:mt-1\" [attr.data-group]=\"group.id\" data-testid=\"builder-palette-group\">\n                  <h4>\n                    <button\n                      type=\"button\"\n                      class=\"cws:flex cws:w-full cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:py-1 cws:text-left cws:text-[11px] cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:hover:bg-slate-100 cws:hover:text-slate-800 cws:disabled:cursor-default cws:disabled:hover:bg-transparent cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-100\"\n                      [attr.aria-label]=\"group.label + ' fields'\"\n                      [attr.aria-expanded]=\"group.expanded\"\n                      [attr.aria-controls]=\"'builder-palette-group-' + group.id\"\n                      [disabled]=\"searching()\"\n                      [title]=\"searching() ? 'A search shows every match; clear it to fold the group' : ''\"\n                      (click)=\"toggleGroup(group.id)\"\n                    >\n                      <svg\n                        aria-hidden=\"true\"\n                        viewBox=\"0 0 16 16\"\n                        class=\"cws:size-3 cws:shrink-0 cws:transition-transform\"\n                        [class.cws:-rotate-90]=\"!group.expanded\"\n                        fill=\"none\"\n                        stroke=\"currentColor\"\n                        stroke-width=\"2\"\n                        stroke-linecap=\"round\"\n                        stroke-linejoin=\"round\"\n                      >\n                        <path d=\"M4 6l4 4 4-4\" />\n                      </svg>\n                      <span class=\"cws:min-w-0 cws:flex-1 cws:truncate\">{{ group.label }}</span>\n                      <span class=\"cws:font-normal cws:tracking-normal cws:normal-case\">{{ group.fields.length }}</span>\n                    </button>\n                  </h4>\n                  @if (group.expanded) {\n                    <ul [id]=\"'builder-palette-group-' + group.id\">\n                      @for (entry of group.fields; track entry.id) {\n                        @let placed = entry.place !== null;\n                        <li\n                          class=\"cws:group cws:flex cws:items-center cws:gap-1.5 cws:rounded-md cws:py-1 cws:pr-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700/60\"\n                          [class.cws:cursor-grab]=\"!readOnly()\"\n                          [class.cws:opacity-40]=\"dragging()?.kind === 'palette' && dragging()?.id === entry.id\"\n                          data-drag=\"palette\"\n                          [attr.data-id]=\"entry.id\"\n                          [attr.data-placed]=\"placed\"\n                          data-testid=\"builder-palette-entry\"\n                        >\n                          @if (!readOnly()) {\n                            <span\n                              aria-hidden=\"true\"\n                              class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                            >⠿</span>\n                          }\n                          <span class=\"cws:min-w-0 cws:flex-1\">\n                            <span\n                              class=\"cws:block cws:truncate\"\n                              [class.cws:text-slate-900]=\"!placed\"\n                              [class.cws:dark:text-slate-100]=\"!placed\"\n                              [class.cws:text-slate-500]=\"placed\"\n                              [class.cws:dark:text-slate-400]=\"placed\"\n                            >\n                              {{ entry.label }}\n                            </span>\n                            <span class=\"cws:flex cws:items-center cws:gap-1 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n                              <span\n                                aria-hidden=\"true\"\n                                class=\"cws:size-1.5 cws:shrink-0 cws:rounded-full\"\n                                [class.cws:bg-emerald-500]=\"placed\"\n                                [class.cws:ring-1]=\"!placed\"\n                                [class.cws:ring-slate-400]=\"!placed\"\n                              ></span>\n                              <span class=\"cws:truncate\">{{ entry.place ?? 'Unplaced' }}</span>\n                            </span>\n                          </span>\n                          @if (!placed && !readOnly()) {\n                            <!-- The keyboard path for a palette drag: place it where \"Place adds to\" says. -->\n                            <button\n                              type=\"button\"\n                              class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-scoular-blue cws:hover:bg-white cws:dark:text-sky-400 cws:dark:hover:bg-slate-800\"\n                              [attr.aria-label]=\"'Place ' + entry.label\"\n                              (click)=\"placeFromPalette(entry.id)\"\n                            >\n                              Place\n                            </button>\n                          }\n                        </li>\n                      }\n                    </ul>\n                  }\n                </div>\n              } @empty {\n                <p class=\"cws:px-1 cws:py-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"builder-palette-none\">\n                  No fields match{{ searching() ? ' the search' : '' }}{{ paletteFilter() === 'all' ? '' : ' among the ' + (paletteFilter() === 'placed' ? 'placed' : 'unplaced') + ' fields' }}.\n                </p>\n              }\n\n              <!--\n                The grids (2026-10-29): each collection block, placed when it sits on one of the form's tabs. Dragged\n                onto a tab, or onto anywhere in the shown tab's layout, it moves to that tab; an unplaced one has Place,\n                which puts it on the shown tab. Never removed: the configuration cannot hide a grid.\n              -->\n              @if (paletteGrids(); as group) {\n                <div class=\"cws:mt-1\" [attr.data-group]=\"group.id\" data-testid=\"builder-palette-group\">\n                  <h4>\n                    <button\n                      type=\"button\"\n                      class=\"cws:flex cws:w-full cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:py-1 cws:text-left cws:text-[11px] cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:hover:bg-slate-100 cws:hover:text-slate-800 cws:disabled:cursor-default cws:disabled:hover:bg-transparent cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-100\"\n                      aria-label=\"Grids\"\n                      [attr.aria-expanded]=\"group.expanded\"\n                      aria-controls=\"builder-palette-group-grids\"\n                      [disabled]=\"searching()\"\n                      [title]=\"searching() ? 'A search shows every match; clear it to fold the group' : ''\"\n                      (click)=\"toggleGroup(group.id)\"\n                    >\n                      <svg\n                        aria-hidden=\"true\"\n                        viewBox=\"0 0 16 16\"\n                        class=\"cws:size-3 cws:shrink-0 cws:transition-transform\"\n                        [class.cws:-rotate-90]=\"!group.expanded\"\n                        fill=\"none\"\n                        stroke=\"currentColor\"\n                        stroke-width=\"2\"\n                        stroke-linecap=\"round\"\n                        stroke-linejoin=\"round\"\n                      >\n                        <path d=\"M4 6l4 4 4-4\" />\n                      </svg>\n                      <span class=\"cws:min-w-0 cws:flex-1 cws:truncate\">{{ group.label }}</span>\n                      <span class=\"cws:font-normal cws:tracking-normal cws:normal-case\">{{ group.grids.length }}</span>\n                    </button>\n                  </h4>\n                  @if (group.expanded) {\n                    <ul id=\"builder-palette-group-grids\">\n                      @for (entry of group.grids; track entry.id) {\n                        @let placed = entry.place !== null;\n                        <li\n                          class=\"cws:group cws:flex cws:items-center cws:gap-1.5 cws:rounded-md cws:py-1 cws:pr-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700/60\"\n                          [class.cws:cursor-grab]=\"!readOnly()\"\n                          [class.cws:opacity-40]=\"dragging()?.kind === 'block' && dragging()?.id === entry.id\"\n                          data-drag=\"block\"\n                          [attr.data-id]=\"entry.id\"\n                          [attr.data-placed]=\"placed\"\n                          data-testid=\"builder-palette-grid\"\n                        >\n                          @if (!readOnly()) {\n                            <span\n                              aria-hidden=\"true\"\n                              class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                            >⠿</span>\n                          }\n                          <span class=\"cws:min-w-0 cws:flex-1\">\n                            <span\n                              class=\"cws:block cws:truncate\"\n                              [class.cws:text-slate-900]=\"!placed\"\n                              [class.cws:dark:text-slate-100]=\"!placed\"\n                              [class.cws:text-slate-500]=\"placed\"\n                              [class.cws:dark:text-slate-400]=\"placed\"\n                            >\n                              {{ entry.label }}\n                            </span>\n                            <span class=\"cws:flex cws:items-center cws:gap-1 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n                              <span\n                                aria-hidden=\"true\"\n                                class=\"cws:size-1.5 cws:shrink-0 cws:rounded-full\"\n                                [class.cws:bg-emerald-500]=\"placed\"\n                                [class.cws:ring-1]=\"!placed\"\n                                [class.cws:ring-slate-400]=\"!placed\"\n                              ></span>\n                              <span class=\"cws:truncate\">{{ entry.place ?? 'Unplaced' }}</span>\n                            </span>\n                          </span>\n                          @if (!placed && !readOnly() && shownTabInfo(); as tab) {\n                            <button\n                              type=\"button\"\n                              class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-scoular-blue cws:hover:bg-white cws:dark:text-sky-400 cws:dark:hover:bg-slate-800\"\n                              [attr.aria-label]=\"'Place the ' + entry.label + ' grid on ' + tab.label\"\n                              (click)=\"placeGrid(entry.id)\"\n                            >\n                              Place\n                            </button>\n                          }\n                        </li>\n                      }\n                    </ul>\n                  }\n                </div>\n              }\n            </div>\n          </aside>\n\n          <!--\n            The form layout: the tab strip, then the shown tab's sections as headed lists of compact rows, then its\n            grids. One surface with separators between rows, rather than a card per section and a box per field.\n            Dragging is the main way to arrange it; every drag also has a keyboard path (Alt and an arrow) and a\n            \"Move to\" in the item's ⋯ menu.\n          -->\n          <div class=\"scoular-card cws:min-w-0 cws:self-start cws:overflow-hidden\" data-testid=\"builder-canvas\">\n            <div\n              role=\"toolbar\"\n              aria-label=\"Tabs\"\n              class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-x-0.5 cws:border-b cws:border-slate-200 cws:bg-slate-50 cws:px-2 cws:pt-1.5 cws:dark:border-slate-700 cws:dark:bg-slate-900/40\"\n              [class.cws:ring-2]=\"invalid().tabs\"\n              [class.cws:ring-inset]=\"invalid().tabs\"\n              [class.cws:ring-red-600]=\"invalid().tabs\"\n              [attr.data-invalid]=\"invalid().tabs ? 'true' : null\"\n              data-testid=\"builder-tab-strip\"\n            >\n              @for (tab of tabs(); track tab.id; let index = $index) {\n                @let shown = tab.id === shownTab();\n                @let over = overKey() === 'tab:' + tab.id;\n                <span\n                  class=\"cws:-mb-px cws:inline-flex cws:items-center cws:gap-1 cws:rounded-t-md cws:border-b-2 cws:px-2.5 cws:py-1.5 cws:text-sm cws:ring-scoular-blue\"\n                  [class.cws:border-scoular-blue]=\"shown\"\n                  [class.cws:bg-white]=\"shown && !over\"\n                  [class.cws:dark:bg-slate-800]=\"shown && !over\"\n                  [class.cws:font-semibold]=\"shown\"\n                  [class.cws:text-slate-900]=\"shown\"\n                  [class.cws:dark:text-white]=\"shown\"\n                  [class.cws:border-transparent]=\"!shown\"\n                  [class.cws:text-slate-600]=\"!shown\"\n                  [class.cws:dark:text-slate-300]=\"!shown\"\n                  [class.cws:hover:text-slate-900]=\"!shown\"\n                  [class.cws:dark:hover:text-white]=\"!shown\"\n                  [class.cws:bg-sky-100]=\"over\"\n                  [class.cws:dark:bg-sky-900]=\"over\"\n                  [class.cws:ring-2]=\"isSelected('tab', tab.id)\"\n                  [class.cws:ring-inset]=\"isSelected('tab', tab.id)\"\n                  [class.cws:cursor-grab]=\"!readOnly()\"\n                  [class.cws:opacity-50]=\"dragging()?.kind === 'tab' && dragging()?.id === tab.id\"\n                  data-drag=\"tab\"\n                  [attr.data-id]=\"tab.id\"\n                  data-drop=\"tab\"\n                  [attr.data-key]=\"'tab:' + tab.id\"\n                  [attr.data-tab]=\"tab.id\"\n                  [attr.data-index]=\"index\"\n                  data-testid=\"builder-tab\"\n                >\n                  <!--\n                    data-drag-grip: a press on the label may become a tab drag; a plain click still shows the tab. A\n                    field or a section dragged onto a tab lands at the end of its first section, and one that rests\n                    on it for a moment shows the tab, so it can be dropped in a section there.\n                  -->\n                  <button\n                    type=\"button\"\n                    data-drag-grip\n                    [class.cws:cursor-grab]=\"!readOnly()\"\n                    (click)=\"activeTab.set(tab.id); select({ kind: 'tab', id: tab.id }, $event)\"\n                    [attr.aria-pressed]=\"shown\"\n                  >\n                    {{ tab.label }}\n                  </button>\n                  @if (empty().tabs.has(tab.id)) {\n                    <span class=\"cws:text-xs cws:font-normal cws:text-amber-700 cws:dark:text-amber-300\" data-testid=\"builder-empty-tab\">(empty)</span>\n                  }\n                  @if (changed().tabs.has(tab.id)) {\n                    <span class=\"cws:size-1.5 cws:rounded-full cws:bg-scoular-blue cws:dark:bg-sky-400\" title=\"Edited\"></span>\n                    <span class=\"cws:sr-only\">edited</span>\n                  }\n                </span>\n              }\n              @if (!readOnly()) {\n                <button\n                  type=\"button\"\n                  class=\"cws:mb-1 cws:ml-1 cws:rounded cws:px-2 cws:py-1 cws:text-sm cws:text-scoular-blue cws:hover:bg-slate-200/60 cws:dark:text-sky-400 cws:dark:hover:bg-slate-700\"\n                  (click)=\"addTab()\"\n                  data-testid=\"builder-add-tab\"\n                >\n                  <span aria-hidden=\"true\">+</span> Add tab\n                </button>\n              }\n            </div>\n\n            @if (shownTabInfo(); as tab) {\n              @if (!readOnly()) {\n                <div class=\"cws:flex cws:justify-end cws:gap-3 cws:px-3 cws:pt-2 cws:text-xs\">\n                  <button type=\"button\" class=\"cws:text-slate-600 cws:hover:text-scoular-blue cws:hover:underline cws:dark:text-slate-300 cws:dark:hover:text-sky-400\" (click)=\"renameTab(tab.id, tab.label)\">\n                    Rename tab\n                  </button>\n                  <button type=\"button\" class=\"cws:text-red-700 cws:hover:underline cws:dark:text-red-300\" (click)=\"deleteTab(tab.id, tab.label)\">Delete tab</button>\n                </div>\n              }\n\n              @for (section of shownSections(); track section.id; let sectionIndex = $index) {\n                @let sectionSelected = isSelected('section', section.id);\n                <section\n                  class=\"cws:relative cws:px-3 cws:pt-2.5 cws:pb-1\"\n                  [class.cws:bg-sky-50]=\"sectionSelected\"\n                  [class.cws:dark:bg-sky-950]=\"sectionSelected\"\n                  [class.cws:ring-2]=\"invalid().sections.has(section.id)\"\n                  [class.cws:ring-inset]=\"invalid().sections.has(section.id)\"\n                  [class.cws:ring-red-600]=\"invalid().sections.has(section.id)\"\n                  [class.cws:opacity-50]=\"dragging()?.kind === 'section' && dragging()?.id === section.id\"\n                  [attr.data-invalid]=\"invalid().sections.has(section.id) ? 'true' : null\"\n                  [attr.aria-label]=\"'Section ' + section.label\"\n                  data-testid=\"builder-section\"\n                >\n                  @if (overKey() === 'section:' + section.id) {\n                    <span\n                      class=\"cws:pointer-events-none cws:absolute cws:inset-x-2 cws:top-0 cws:z-10 cws:h-0.5 cws:rounded cws:bg-scoular-blue\"\n                      data-testid=\"builder-drop-line\"\n                      data-edge=\"before\"\n                    ></span>\n                  }\n                  <!-- The heading is a drag handle for the section, and a drop target: a field dropped on it goes first in the section. -->\n                  <header\n                    class=\"cws:group cws:flex cws:items-center cws:gap-1.5 cws:pb-1\"\n                    [class.cws:cursor-grab]=\"!readOnly()\"\n                    data-drag=\"section\"\n                    [attr.data-id]=\"section.id\"\n                    data-drop=\"section\"\n                    [attr.data-key]=\"'section:' + section.id\"\n                    [attr.data-tab]=\"tab.id\"\n                    [attr.data-section]=\"section.id\"\n                    [attr.data-index]=\"sectionIndex\"\n                    data-testid=\"builder-section-header\"\n                  >\n                    @if (!readOnly()) {\n                      <span\n                        aria-hidden=\"true\"\n                        class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                      >⠿</span>\n                    }\n                    <button\n                      type=\"button\"\n                      data-drag-grip\n                      class=\"cws:text-xs cws:font-semibold cws:tracking-wider cws:text-slate-600 cws:uppercase cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white\"\n                      [class.cws:cursor-grab]=\"!readOnly()\"\n                      (click)=\"select({ kind: 'section', id: section.id }, $event)\"\n                    >\n                      {{ section.label }}\n                    </button>\n                    @if (empty().sections.has(section.id)) {\n                      <span class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-300\" data-testid=\"builder-empty-section\">(no fields)</span>\n                    }\n                    @if (changed().sections.has(section.id)) {\n                      <span class=\"cws:text-xs cws:text-scoular-blue cws:dark:text-sky-400\">edited</span>\n                    } @else if (inheritedBadge(); as badge) {\n                      <span class=\"cws:rounded cws:bg-slate-100 cws:px-1 cws:text-[11px] cws:text-slate-500 cws:dark:bg-slate-700 cws:dark:text-slate-300\" data-testid=\"builder-inherited\">\n                        {{ badge }}\n                      </span>\n                    }\n                    @if (!readOnly()) {\n                      <span class=\"cws:ml-auto cws:flex cws:items-center cws:gap-1\">\n                        <button\n                          type=\"button\"\n                          class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-900 cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white\"\n                          (click)=\"renameSection(section.id, section.label)\"\n                        >\n                          Rename\n                        </button>\n                        <cms-builder-item-menu\n                          [label]=\"'Actions for section ' + section.label\"\n                          moveLabel=\"Move to tab\"\n                          [targets]=\"tabTargets().get(tab.id) ?? []\"\n                          [actions]=\"sectionActions().get(section.id) ?? []\"\n                          (moveTo)=\"moveSectionTo(section.id, $event)\"\n                        />\n                      </span>\n                    }\n                  </header>\n\n                  <ul class=\"cws:divide-y cws:divide-slate-100 cws:border-t cws:border-slate-100 cws:dark:divide-slate-700/70 cws:dark:border-slate-700/70\">\n                    @for (name of section.fields; track name; let fieldIndex = $index) {\n                      @if (fieldBehaviour(name); as behaviour) {\n                        @let fieldSelected = isSelected('field', name);\n                        @let lifted = (dragging()?.kind === 'field' || dragging()?.kind === 'palette') && dragging()?.id === name;\n                        <!-- A compound group (the contract number) is one row: always shown and required, its ticks locked. -->\n                        @let groupLocked = groupLock(name);\n                        @let flagLocked = groupLocked ?? (ctrmRequired().has(name) ? ctrmRequiredReason : null);\n                        @let rowInvalidNow = rowInvalid(name);\n                        <li\n                          class=\"cws:group cws:relative cws:flex cws:items-center cws:gap-1.5 cws:py-1 cws:pr-0.5 cws:text-sm\"\n                          [class.cws:cursor-grab]=\"!readOnly()\"\n                          [class.cws:hover:bg-slate-50]=\"!fieldSelected\"\n                          [class.cws:dark:hover:bg-slate-700/40]=\"!fieldSelected\"\n                          [class.cws:bg-sky-100]=\"fieldSelected\"\n                          [class.cws:dark:bg-sky-950]=\"fieldSelected\"\n                          [class.cws:bg-red-50]=\"rowInvalidNow\"\n                          [class.cws:dark:bg-red-950]=\"rowInvalidNow\"\n                          [class.cws:opacity-40]=\"lifted\"\n                          [attr.data-dragging]=\"lifted ? 'true' : null\"\n                          [attr.data-invalid]=\"rowInvalidNow ? 'true' : null\"\n                          [attr.data-group]=\"groupLocked === null ? null : 'true'\"\n                          data-drag=\"field\"\n                          [attr.data-id]=\"name\"\n                          data-drop=\"field\"\n                          [attr.data-key]=\"'field:' + name\"\n                          [attr.data-section]=\"section.id\"\n                          [attr.data-index]=\"fieldIndex\"\n                          data-testid=\"builder-field\"\n                        >\n                          @if (overKey() === 'field:' + name || overKey() === 'after:' + name) {\n                            <!-- The insertion line: above the row on its upper half, below it on its lower half. -->\n                            <span\n                              class=\"cws:pointer-events-none cws:absolute cws:inset-x-0 cws:z-10 cws:h-0.5 cws:rounded cws:bg-scoular-blue\"\n                              [class.cws:-top-px]=\"overKey() === 'field:' + name\"\n                              [class.cws:-bottom-px]=\"overKey() === 'after:' + name\"\n                              [attr.data-edge]=\"overKey() === 'after:' + name ? 'after' : 'before'\"\n                              data-testid=\"builder-drop-line\"\n                            ></span>\n                          }\n                          @if (!readOnly()) {\n                            <span\n                              aria-hidden=\"true\"\n                              class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                              data-testid=\"builder-grip\"\n                            >⠿</span>\n                          }\n                          <!-- data-drag-grip: a press on the name may become a drag; a plain click selects the field. -->\n                          <button\n                            type=\"button\"\n                            data-drag-grip\n                            class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-left cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\"\n                            [class.cws:cursor-grab]=\"!readOnly()\"\n                            (click)=\"select({ kind: 'field', id: name }, $event)\"\n                          >\n                            {{ rowLabel(name) }}\n                            @if (groupLocked !== null || behaviour.required) {\n                              <span class=\"cws:text-red-700 cws:dark:text-red-300\" aria-label=\"required\">*</span>\n                            }\n                          </button>\n                          @if (rowChanged(name)) {\n                            <span class=\"cws:text-[11px] cws:text-scoular-blue cws:dark:text-sky-400\">edited</span>\n                          }\n                          <!-- F7's quick toggles, kept on the row but quieter than the name. -->\n                          <span class=\"cws:flex cws:shrink-0 cws:items-center cws:gap-2.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                            <label class=\"cws:flex cws:items-center cws:gap-1\">\n                              <input\n                                type=\"checkbox\"\n                                class=\"cws:size-3.5\"\n                                [checked]=\"behaviour.visible\"\n                                [disabled]=\"readOnly() || flagLocked !== null\"\n                                [attr.title]=\"flagLocked\"\n                                (change)=\"toggleVisible(name)\"\n                              />\n                              Visible\n                            </label>\n                            <label class=\"cws:flex cws:items-center cws:gap-1\">\n                              <input\n                                type=\"checkbox\"\n                                class=\"cws:size-3.5\"\n                                [checked]=\"groupLocked !== null || behaviour.required\"\n                                [disabled]=\"readOnly() || flagLocked !== null\"\n                                [attr.title]=\"flagLocked\"\n                                (change)=\"toggleRequired(name)\"\n                              />\n                              Required\n                            </label>\n                          </span>\n                          @if (!readOnly()) {\n                            <!-- Move to, Move up and down, Properties and Remove: the row's secondary actions (2026-10-29). -->\n                            <cms-builder-item-menu\n                              [label]=\"'Actions for ' + rowLabel(name)\"\n                              [targets]=\"sectionTargets().get(section.id) ?? []\"\n                              [actions]=\"fieldActions().get(name) ?? []\"\n                              (moveTo)=\"moveFieldTo(name, $event)\"\n                            />\n                          }\n                        </li>\n                      }\n                    }\n                    <!-- The end of the section: a drop zone while a field is dragged, and otherwise the way to add one. -->\n                    @if (fieldDrag()) {\n                      <li class=\"cws:py-0.5\" data-drop=\"section-end\" [attr.data-key]=\"'end:' + section.id\" [attr.data-section]=\"section.id\">\n                        <span\n                          class=\"cws:block cws:rounded cws:border cws:border-dashed cws:px-2 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\n                          [class.cws:border-scoular-blue]=\"overKey() === 'end:' + section.id\"\n                          [class.cws:bg-sky-50]=\"overKey() === 'end:' + section.id\"\n                          [class.cws:dark:bg-sky-950]=\"overKey() === 'end:' + section.id\"\n                          [class.cws:border-slate-300]=\"overKey() !== 'end:' + section.id\"\n                          [class.cws:dark:border-slate-600]=\"overKey() !== 'end:' + section.id\"\n                        >\n                          Drop at the end of {{ section.label }}\n                        </span>\n                      </li>\n                    } @else if (!readOnly()) {\n                      <li data-drop=\"section-end\" [attr.data-key]=\"'end:' + section.id\" [attr.data-section]=\"section.id\">\n                        <button\n                          type=\"button\"\n                          class=\"cws:my-0.5 cws:rounded cws:px-1 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-sky-400\"\n                          [attr.aria-label]=\"'Add a field to ' + section.label\"\n                          (click)=\"addFieldTo(section.id)\"\n                          data-testid=\"builder-add-field\"\n                        >\n                          <span aria-hidden=\"true\">+</span> Add field\n                        </button>\n                      </li>\n                    }\n                  </ul>\n                </section>\n              }\n\n              <!-- F8: collection blocks, moved between tabs as whole blocks. -->\n              @for (block of shownBlocks(); track block.collection) {\n                <div\n                  class=\"cws:group cws:mx-3 cws:mt-2 cws:flex cws:items-center cws:gap-1.5 cws:rounded-md cws:bg-slate-50 cws:py-1.5 cws:pr-1 cws:text-sm cws:dark:bg-slate-900/40\"\n                  [class.cws:cursor-grab]=\"!readOnly()\"\n                  [class.cws:ring-2]=\"isSelected('block', block.collection) || invalid().collections.has(block.collection)\"\n                  [class.cws:ring-scoular-blue]=\"!invalid().collections.has(block.collection)\"\n                  [class.cws:ring-red-600]=\"invalid().collections.has(block.collection)\"\n                  [class.cws:opacity-50]=\"dragging()?.kind === 'block' && dragging()?.id === block.collection\"\n                  data-drag=\"block\"\n                  [attr.data-id]=\"block.collection\"\n                  data-testid=\"builder-block\"\n                >\n                  @if (!readOnly()) {\n                    <span\n                      aria-hidden=\"true\"\n                      class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                    >⠿</span>\n                  }\n                  <button\n                    type=\"button\"\n                    data-drag-grip\n                    class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\"\n                    [class.cws:cursor-grab]=\"!readOnly()\"\n                    (click)=\"select({ kind: 'block', id: block.collection }, $event)\"\n                  >\n                    {{ block.label }}\n                  </button>\n                  <span class=\"cws:mr-auto cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">A grid of its own</span>\n                  @if (!readOnly()) {\n                    <cms-builder-item-menu\n                      [label]=\"'Actions for the ' + block.label + ' grid'\"\n                      moveLabel=\"Move to tab\"\n                      [targets]=\"tabTargets().get(tab.id) ?? []\"\n                      [actions]=\"gridActions\"\n                      (moveTo)=\"moveBlockTo(block, $event)\"\n                    />\n                  }\n                </div>\n              }\n\n              <!--\n                The end of the tab, while a section or a grid is dragged, so it can be dropped after the last section. A\n                grid dragged anywhere on the tab lands here, because a grid shows after its tab's sections (2026-10-29).\n              -->\n              @if (dragging()?.kind === 'section' || dragging()?.kind === 'block') {\n                <div\n                  class=\"cws:mx-3 cws:mt-2 cws:rounded cws:border cws:border-dashed cws:p-2 cws:text-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\n                  [class.cws:border-scoular-blue]=\"overKey() === 'tab-end:' + tab.id\"\n                  [class.cws:bg-sky-50]=\"overKey() === 'tab-end:' + tab.id\"\n                  [class.cws:dark:bg-sky-950]=\"overKey() === 'tab-end:' + tab.id\"\n                  [class.cws:border-slate-300]=\"overKey() !== 'tab-end:' + tab.id\"\n                  [class.cws:dark:border-slate-600]=\"overKey() !== 'tab-end:' + tab.id\"\n                  data-drop=\"tab-end\"\n                  [attr.data-key]=\"'tab-end:' + tab.id\"\n                  [attr.data-tab]=\"tab.id\"\n                  data-testid=\"builder-tab-end\"\n                >\n                  @if (dragging()?.kind === 'block') {\n                    The grid goes here: a grid shows after its tab's sections\n                  } @else {\n                    Drop a section here\n                  }\n                </div>\n              }\n\n              @if (!readOnly()) {\n                <div class=\"cws:px-3 cws:pt-1 cws:pb-3\">\n                  <button\n                    type=\"button\"\n                    class=\"cws:rounded cws:px-1 cws:py-0.5 cws:text-sm cws:font-medium cws:text-scoular-blue cws:hover:bg-slate-100 cws:dark:text-sky-400 cws:dark:hover:bg-slate-700\"\n                    (click)=\"addSection(tab.id)\"\n                    data-testid=\"builder-add-section\"\n                  >\n                    <span aria-hidden=\"true\">+</span> Add section\n                  </button>\n                </div>\n              } @else {\n                <div class=\"cws:pb-2\"></div>\n              }\n            }\n          </div>\n\n          <!--\n            The right column: an editing panel (the selected item's properties, F7, or the trade unit's settings,\n            F15) over the live preview (F10). The preview is always mounted, so it stays on screen while a property\n            changes; the panel takes at most half the column's height on a wide screen and scrolls inside it.\n          -->\n          <div\n            class=\"cws:flex cws:min-w-0 cws:flex-col cws:gap-3 cws:lg:col-span-2 cws:xl:sticky cws:xl:top-4 cws:xl:col-span-1 cws:xl:max-h-[calc(100vh-2rem)] cws:xl:self-start\"\n            data-testid=\"builder-side\"\n          >\n            <div class=\"scoular-card cws:flex cws:shrink-0 cws:flex-col cws:overflow-hidden cws:xl:max-h-[45vh]\">\n              <div class=\"cws:flex cws:items-center cws:gap-1 cws:px-2 cws:py-1.5\">\n                <div role=\"group\" aria-label=\"Editing panel\" class=\"cws:flex cws:gap-1\">\n                  @for (view of inspectorViews; track view.id) {\n                    <button\n                      type=\"button\"\n                      class=\"cws:rounded-md cws:px-2.5 cws:py-1 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:bg-slate-100 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white\"\n                      [class.cws:bg-slate-100]=\"inspector() === view.id\"\n                      [class.cws:text-slate-900]=\"inspector() === view.id\"\n                      [class.cws:dark:bg-slate-700]=\"inspector() === view.id\"\n                      [class.cws:dark:text-white]=\"inspector() === view.id\"\n                      [attr.aria-pressed]=\"inspector() === view.id\"\n                      (click)=\"toggleInspector(view.id)\"\n                      [attr.data-testid]=\"'builder-side-' + view.id\"\n                    >\n                      {{ view.label }}\n                    </button>\n                  }\n                </div>\n                @if (inspector() !== null) {\n                  <button\n                    type=\"button\"\n                    class=\"cws:ml-auto cws:rounded cws:p-1 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-800 cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white\"\n                    aria-label=\"Close the panel\"\n                    title=\"Close the panel\"\n                    (click)=\"inspector.set(null)\"\n                    data-testid=\"builder-side-close\"\n                  >\n                    <svg aria-hidden=\"true\" viewBox=\"0 0 16 16\" class=\"cws:size-4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\">\n                      <path d=\"M4 4l8 8M12 4l-8 8\" />\n                    </svg>\n                  </button>\n                } @else {\n                  <span class=\"cws:ml-auto cws:truncate cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Select a field to edit it</span>\n                }\n              </div>\n              @if (inspector() !== null) {\n                <div class=\"cws:min-h-0 cws:overflow-y-auto cws:border-t cws:border-slate-200 cws:dark:border-slate-700\">\n                  @if (registry(); as reg) {\n                    @if (inspector() === 'properties') {\n                      <cms-builder-properties\n                        [document]=\"doc\"\n                        [registry]=\"reg\"\n                        [selection]=\"propertiesSelection()\"\n                        [readOnly]=\"readOnly()\"\n                        [ctrmRequired]=\"ctrmRequired()\"\n                        (op)=\"run($event)\"\n                      />\n                    } @else {\n                      <cms-builder-settings [document]=\"doc\" [registry]=\"reg\" [readOnly]=\"readOnly()\" (op)=\"run($event)\" />\n                    }\n                  }\n                </div>\n              }\n            </div>\n            <cms-builder-preview\n              class=\"cws:block cws:min-h-0 cws:xl:flex-1\"\n              [document]=\"doc\"\n              [resolutionKey]=\"resolutionKey()\"\n              (problemsChange)=\"problems.set($event)\"\n            />\n          </div>\n        </div>\n\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Keyboard: select a card or section, then Alt and an arrow key moves it; Ctrl+Z undoes and Ctrl+Y redoes.\n          <a class=\"cws:text-scoular-blue cws:underline cws:dark:text-sky-400\" routerLink=\"rows\">Every configuration row</a>\n        </p>\n      }\n    }\n  }\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "component",
				type: AdminTradeUnitSelectComponent,
				selector: "cws-admin-trade-unit-select",
				inputs: [
					"label",
					"value",
					"allowAny",
					"everyLocation"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: BuilderItemMenuComponent,
				selector: "cms-builder-item-menu",
				inputs: [
					"label",
					"moveLabel",
					"targets",
					"actions"
				],
				outputs: ["moveTo"]
			},
			{
				kind: "component",
				type: BuilderPreviewComponent,
				selector: "cms-builder-preview",
				inputs: ["document", "resolutionKey"],
				outputs: ["problemsChange"]
			},
			{
				kind: "component",
				type: BuilderPropertiesComponent,
				selector: "cms-builder-properties",
				inputs: [
					"document",
					"registry",
					"selection",
					"readOnly",
					"ctrmRequired"
				],
				outputs: ["op"]
			},
			{
				kind: "component",
				type: BuilderSettingsComponent,
				selector: "cms-builder-settings",
				inputs: [
					"document",
					"registry",
					"readOnly"
				],
				outputs: ["op"]
			},
			{
				kind: "directive",
				type: CdkMenu,
				selector: "[cdkMenu]",
				outputs: ["closed"],
				exportAs: ["cdkMenu"]
			},
			{
				kind: "directive",
				type: CdkMenuItem,
				selector: "[cdkMenuItem]",
				inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"],
				outputs: ["cdkMenuItemTriggered"],
				exportAs: ["cdkMenuItem"]
			},
			{
				kind: "directive",
				type: CdkMenuTrigger,
				selector: "[cdkMenuTriggerFor]",
				inputs: [
					"cdkMenuTriggerFor",
					"cdkMenuPosition",
					"cdkMenuTriggerData",
					"cdkMenuTriggerTransformOriginOn"
				],
				outputs: ["cdkMenuOpened", "cdkMenuClosed"],
				exportAs: ["cdkMenuTriggerFor"]
			},
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormBuilderPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-builder-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AdminTabsComponent,
				AdminTradeUnitSelectComponent,
				BuilderItemMenuComponent,
				BuilderPreviewComponent,
				BuilderPropertiesComponent,
				BuilderSettingsComponent,
				CdkMenu,
				CdkMenuItem,
				CdkMenuTrigger,
				RouterLink
			],
			providers: [AdminScope],
			host: {
				"(window:beforeunload)": "onBeforeUnload($event)",
				"(keydown)": "onKeydown($event)"
			},
			template: "<section class=\"cws:space-y-4\" aria-labelledby=\"form-builder-heading\">\n  <!--\n    With a form open the builder takes the whole width: the heading stays for a screen reader (the page keeps its\n    one h2), and the area's tabs and the pickers step aside until Discard. The toolbar names what is open.\n  -->\n  <div [class.cws:sr-only]=\"editing()\">\n    <!-- The Admin section's one h2 per page is the area's title (#825); the view is the h3. -->\n    <h2 id=\"form-builder-heading\" class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Form configuration</h2>\n    <h3 class=\"cws:mt-1 cws:text-sm cws:font-semibold cws:text-slate-800 cws:dark:text-slate-100\">Form builder</h3>\n    <p class=\"cws:mt-1 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n      Build the contract form for a contract type, trade unit and commodity. Drag fields from the palette, arrange\n      tabs and sections, then save. A blank dimension means <em>any</em>.\n    </p>\n  </div>\n\n  @if (area && !editing()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Form configuration views\" />\n  }\n\n  <!-- F1: the dimensions, applied with Open. -->\n  @if (!editing()) {\n  <form class=\"scoular-card cws:grid cws:gap-3 cws:p-4 cws:md:grid-cols-4 cws:md:items-end\" (submit)=\"$event.preventDefault(); open()\">\n    <label class=\"cws:block\">\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Contract type</span>\n      <input\n        class=\"scoular-form-input cws:mt-1 cws:w-full\"\n        [value]=\"typeInput()\"\n        (input)=\"typeInput.set($any($event.target).value)\"\n        placeholder=\"Any\"\n        data-testid=\"builder-type\"\n      />\n    </label>\n    <cws-admin-trade-unit-select\n      label=\"Trade unit\"\n      [allowAny]=\"true\"\n      [everyLocation]=\"true\"\n      [value]=\"locationInput()\"\n      (valueChange)=\"locationInput.set($event)\"\n    />\n    <label class=\"cws:block\">\n      <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Commodity</span>\n      <input\n        class=\"scoular-form-input cws:mt-1 cws:w-full\"\n        [value]=\"commodityInput()\"\n        (input)=\"commodityInput.set($any($event.target).value)\"\n        placeholder=\"Any\"\n        data-testid=\"builder-commodity\"\n      />\n    </label>\n    <div>\n      <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" data-testid=\"builder-open\">Open</button>\n    </div>\n  </form>\n  }\n\n  @switch (loadState()) {\n    @case ('idle') {\n      <p class=\"scoular-card cws:p-4 cws:text-sm\">Choose the dimensions and Open to build their form.</p>\n    }\n    @case ('loading') {\n      <p role=\"status\" class=\"scoular-card cws:p-4 cws:text-sm\">Loading the form…</p>\n    }\n    @case ('error') {\n      <p role=\"alert\" class=\"scoular-card cws:p-4 cws:text-sm cws:text-red-700 cws:dark:text-red-300\">\n        The form could not be loaded. {{ loadError() }}\n      </p>\n    }\n    @default {\n      @if (document(); as doc) {\n        <!-- The toolbar: what is open, the row, undo, redo, discard, save (F9, F13). -->\n        <div class=\"scoular-card cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:p-3\" data-testid=\"builder-toolbar\">\n          <p class=\"cws:mr-auto cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" data-testid=\"builder-row\">\n            <span class=\"cws:block cws:font-semibold cws:text-slate-900 cws:dark:text-white\" data-testid=\"builder-dimensions\">{{ openedOn() }}</span>\n            @if (ownRow(); as row) {\n              Editing configuration row {{ row.id }}, version {{ row.version }}.\n            } @else {\n              No row at these dimensions yet: the form below is inherited ({{ inheritedBadge() }}). Saving creates the row.\n            }\n            {{ placedCount() }} fields placed.\n          </p>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"!history()?.canUndo || readOnly()\" (click)=\"undo()\" data-testid=\"builder-undo\">\n            Undo\n          </button>\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"!history()?.canRedo || readOnly()\" (click)=\"redo()\" data-testid=\"builder-redo\">\n            Redo\n          </button>\n          <label class=\"cws:flex cws:items-center cws:gap-1 cws:text-sm\">\n            <span class=\"cws:sr-only\">Start from</span>\n            <select\n              class=\"scoular-form-input cws:text-sm\"\n              [disabled]=\"readOnly()\"\n              (change)=\"seedFrom($any($event.target).value); $any($event.target).value = ''\"\n              data-testid=\"builder-seed\"\n            >\n              <option value=\"\">Start from…</option>\n              <option value=\"default\">The default</option>\n              <option value=\"scratch\" [title]=\"scratchDescription\">Scratch (empty form)</option>\n              @for (row of seedRows(); track row.id) {\n                <option [value]=\"row.id\">Row {{ row.id }}: {{ row.dimensionKey }}</option>\n              }\n            </select>\n          </label>\n          <!-- The draft as JSON (2026-10-30): one menu, so the toolbar keeps its width. Import is refused read-only. -->\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-secondary\"\n            aria-haspopup=\"menu\"\n            [cdkMenuTriggerFor]=\"jsonMenu\"\n            data-testid=\"builder-json\"\n          >\n            JSON\n          </button>\n          <ng-template #jsonMenu>\n            <div cdkMenu class=\"scoular-dropdown cws:static cws:mt-1 cws:min-w-48\" aria-label=\"JSON\">\n              <button type=\"button\" cdkMenuItem class=\"scoular-dropdown-item\" (cdkMenuItemTriggered)=\"copyJson()\" data-testid=\"builder-json-copy\">\n                Copy JSON\n              </button>\n              <button type=\"button\" cdkMenuItem class=\"scoular-dropdown-item\" (cdkMenuItemTriggered)=\"downloadJson()\" data-testid=\"builder-json-download\">\n                Download JSON\n              </button>\n              <button\n                type=\"button\"\n                cdkMenuItem\n                class=\"scoular-dropdown-item cws:flex-col cws:items-start cws:gap-0\"\n                [class.cws:cursor-not-allowed]=\"readOnly()\"\n                [class.cws:opacity-60]=\"readOnly()\"\n                [cdkMenuItemDisabled]=\"readOnly()\"\n                (cdkMenuItemTriggered)=\"importJson()\"\n                data-testid=\"builder-json-import\"\n              >\n                <span>Import JSON…</span>\n                @if (readOnly()) {\n                  <span class=\"cws:max-w-64 cws:text-xs cws:whitespace-normal cws:text-slate-500 cws:dark:text-slate-400\">Importing needs the settings permission in this trade unit.</span>\n                }\n              </button>\n            </div>\n          </ng-template>\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-secondary\"\n            [disabled]=\"saving()\"\n            title=\"Close the builder without saving, back to the dimensions\"\n            (click)=\"discard()\"\n            data-testid=\"builder-discard\"\n          >\n            Discard\n          </button>\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-primary\"\n            [disabled]=\"readOnly() || saving() || (!dirty() && ownRow() !== null)\"\n            (click)=\"save()\"\n            data-testid=\"builder-save\"\n          >\n            @if (saving()) { Saving… } @else { Save }\n          </button>\n        </div>\n\n        @if (readOnly()) {\n          <!-- F16 -->\n          <p role=\"status\" class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"builder-read-only\">\n            You can look at this form. Changing it needs the settings permission in this trade unit.\n          </p>\n        }\n\n        @if (outcome(); as result) {\n          <div\n            role=\"status\"\n            class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:text-sm\"\n            [class.cws:text-red-700]=\"result.failed\"\n            data-testid=\"builder-outcome\"\n          >\n            <span class=\"cws:whitespace-pre-line\">{{ result.text }}</span>\n            @if (result.conflict) {\n              <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"reloadAfterConflict()\" data-testid=\"builder-reload\">\n                Reload\n              </button>\n            }\n          </div>\n        }\n\n        <!--\n          🔴 select-none on the whole builder (Known Issue 44): a press inside a leftover text selection is a\n          SELECTION drag, which the browser announces with pointercancel, so without it the gesture works once and\n          then stops. The shared helper cannot apply this class itself.\n\n          Three columns from xl: the fields, the form's layout, and the live preview. The two outer columns are\n          sticky with their own scroll, so the preview stays in view however long the layout grows. From lg the\n          fields and the layout share the row and the preview sits under them; below lg each is full width, the\n          layout first after a short field list.\n        -->\n        <div\n          class=\"cws:grid cws:select-none cws:gap-4 cws:lg:grid-cols-[14rem_minmax(0,1fr)] cws:xl:grid-cols-[15rem_minmax(0,1fr)_minmax(0,1fr)] cws:2xl:grid-cols-[16rem_minmax(0,1fr)_minmax(0,1.15fr)]\"\n          (pointerdown)=\"onPointerDown($event)\"\n          data-testid=\"builder\"\n        >\n          <!--\n            F5: the palette, the field library. Search, a filter by whether a field is on the form, and the\n            registry's groups, each foldable; a search shows its matches in every group, folded or not. Every entry\n            is a drag source onto the layout, and an unplaced one has Place as its keyboard path.\n          -->\n          <aside\n            class=\"scoular-card cws:flex cws:max-h-80 cws:min-w-0 cws:flex-col cws:overflow-hidden cws:lg:sticky cws:lg:top-4 cws:lg:max-h-[calc(100vh-2rem)] cws:lg:self-start\"\n            aria-label=\"Field palette\"\n            data-testid=\"builder-palette\"\n          >\n            <div class=\"cws:shrink-0 cws:space-y-2 cws:border-b cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n              <div class=\"cws:flex cws:items-baseline cws:justify-between cws:gap-2\">\n                <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-800 cws:dark:text-slate-100\">Fields</h3>\n                <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"builder-palette-count\">{{ placedCount() }} of {{ fieldCount() }} placed</span>\n              </div>\n              <label class=\"cws:block\">\n                <span class=\"cws:sr-only\">Search fields</span>\n                <input\n                  #paletteSearchInput\n                  class=\"scoular-form-input cws:w-full cws:text-sm\"\n                  placeholder=\"Search fields\"\n                  [value]=\"paletteSearch()\"\n                  (input)=\"paletteSearch.set($any($event.target).value)\"\n                  data-testid=\"builder-palette-search\"\n                />\n              </label>\n              <div role=\"group\" aria-label=\"Show fields\" class=\"cws:flex cws:rounded-md cws:bg-slate-100 cws:p-0.5 cws:dark:bg-slate-900\">\n                @for (option of paletteFilters; track option.id) {\n                  <button\n                    type=\"button\"\n                    class=\"cws:flex-1 cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-slate-600 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white\"\n                    [class.cws:bg-white]=\"paletteFilter() === option.id\"\n                    [class.cws:shadow-sm]=\"paletteFilter() === option.id\"\n                    [class.cws:text-slate-900]=\"paletteFilter() === option.id\"\n                    [class.cws:dark:bg-slate-700]=\"paletteFilter() === option.id\"\n                    [class.cws:dark:text-white]=\"paletteFilter() === option.id\"\n                    [attr.aria-pressed]=\"paletteFilter() === option.id\"\n                    (click)=\"paletteFilter.set(option.id)\"\n                    [attr.data-testid]=\"'builder-palette-filter-' + option.id\"\n                  >\n                    {{ option.label }}\n                  </button>\n                }\n              </div>\n              @if (!readOnly() && placeTarget(); as target) {\n                <p class=\"cws:truncate cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"builder-place-target\">\n                  Place adds to <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">{{ target.label }}</span>\n                </p>\n              }\n            </div>\n\n            <div class=\"cws:min-h-0 cws:flex-1 cws:overflow-y-auto cws:px-2 cws:pt-1 cws:pb-2\">\n              @for (group of palette(); track group.id) {\n                <div class=\"cws:mt-1\" [attr.data-group]=\"group.id\" data-testid=\"builder-palette-group\">\n                  <h4>\n                    <button\n                      type=\"button\"\n                      class=\"cws:flex cws:w-full cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:py-1 cws:text-left cws:text-[11px] cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:hover:bg-slate-100 cws:hover:text-slate-800 cws:disabled:cursor-default cws:disabled:hover:bg-transparent cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-100\"\n                      [attr.aria-label]=\"group.label + ' fields'\"\n                      [attr.aria-expanded]=\"group.expanded\"\n                      [attr.aria-controls]=\"'builder-palette-group-' + group.id\"\n                      [disabled]=\"searching()\"\n                      [title]=\"searching() ? 'A search shows every match; clear it to fold the group' : ''\"\n                      (click)=\"toggleGroup(group.id)\"\n                    >\n                      <svg\n                        aria-hidden=\"true\"\n                        viewBox=\"0 0 16 16\"\n                        class=\"cws:size-3 cws:shrink-0 cws:transition-transform\"\n                        [class.cws:-rotate-90]=\"!group.expanded\"\n                        fill=\"none\"\n                        stroke=\"currentColor\"\n                        stroke-width=\"2\"\n                        stroke-linecap=\"round\"\n                        stroke-linejoin=\"round\"\n                      >\n                        <path d=\"M4 6l4 4 4-4\" />\n                      </svg>\n                      <span class=\"cws:min-w-0 cws:flex-1 cws:truncate\">{{ group.label }}</span>\n                      <span class=\"cws:font-normal cws:tracking-normal cws:normal-case\">{{ group.fields.length }}</span>\n                    </button>\n                  </h4>\n                  @if (group.expanded) {\n                    <ul [id]=\"'builder-palette-group-' + group.id\">\n                      @for (entry of group.fields; track entry.id) {\n                        @let placed = entry.place !== null;\n                        <li\n                          class=\"cws:group cws:flex cws:items-center cws:gap-1.5 cws:rounded-md cws:py-1 cws:pr-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700/60\"\n                          [class.cws:cursor-grab]=\"!readOnly()\"\n                          [class.cws:opacity-40]=\"dragging()?.kind === 'palette' && dragging()?.id === entry.id\"\n                          data-drag=\"palette\"\n                          [attr.data-id]=\"entry.id\"\n                          [attr.data-placed]=\"placed\"\n                          data-testid=\"builder-palette-entry\"\n                        >\n                          @if (!readOnly()) {\n                            <span\n                              aria-hidden=\"true\"\n                              class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                            >⠿</span>\n                          }\n                          <span class=\"cws:min-w-0 cws:flex-1\">\n                            <span\n                              class=\"cws:block cws:truncate\"\n                              [class.cws:text-slate-900]=\"!placed\"\n                              [class.cws:dark:text-slate-100]=\"!placed\"\n                              [class.cws:text-slate-500]=\"placed\"\n                              [class.cws:dark:text-slate-400]=\"placed\"\n                            >\n                              {{ entry.label }}\n                            </span>\n                            <span class=\"cws:flex cws:items-center cws:gap-1 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n                              <span\n                                aria-hidden=\"true\"\n                                class=\"cws:size-1.5 cws:shrink-0 cws:rounded-full\"\n                                [class.cws:bg-emerald-500]=\"placed\"\n                                [class.cws:ring-1]=\"!placed\"\n                                [class.cws:ring-slate-400]=\"!placed\"\n                              ></span>\n                              <span class=\"cws:truncate\">{{ entry.place ?? 'Unplaced' }}</span>\n                            </span>\n                          </span>\n                          @if (!placed && !readOnly()) {\n                            <!-- The keyboard path for a palette drag: place it where \"Place adds to\" says. -->\n                            <button\n                              type=\"button\"\n                              class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-scoular-blue cws:hover:bg-white cws:dark:text-sky-400 cws:dark:hover:bg-slate-800\"\n                              [attr.aria-label]=\"'Place ' + entry.label\"\n                              (click)=\"placeFromPalette(entry.id)\"\n                            >\n                              Place\n                            </button>\n                          }\n                        </li>\n                      }\n                    </ul>\n                  }\n                </div>\n              } @empty {\n                <p class=\"cws:px-1 cws:py-3 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"builder-palette-none\">\n                  No fields match{{ searching() ? ' the search' : '' }}{{ paletteFilter() === 'all' ? '' : ' among the ' + (paletteFilter() === 'placed' ? 'placed' : 'unplaced') + ' fields' }}.\n                </p>\n              }\n\n              <!--\n                The grids (2026-10-29): each collection block, placed when it sits on one of the form's tabs. Dragged\n                onto a tab, or onto anywhere in the shown tab's layout, it moves to that tab; an unplaced one has Place,\n                which puts it on the shown tab. Never removed: the configuration cannot hide a grid.\n              -->\n              @if (paletteGrids(); as group) {\n                <div class=\"cws:mt-1\" [attr.data-group]=\"group.id\" data-testid=\"builder-palette-group\">\n                  <h4>\n                    <button\n                      type=\"button\"\n                      class=\"cws:flex cws:w-full cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:py-1 cws:text-left cws:text-[11px] cws:font-semibold cws:tracking-wider cws:text-slate-500 cws:uppercase cws:hover:bg-slate-100 cws:hover:text-slate-800 cws:disabled:cursor-default cws:disabled:hover:bg-transparent cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-100\"\n                      aria-label=\"Grids\"\n                      [attr.aria-expanded]=\"group.expanded\"\n                      aria-controls=\"builder-palette-group-grids\"\n                      [disabled]=\"searching()\"\n                      [title]=\"searching() ? 'A search shows every match; clear it to fold the group' : ''\"\n                      (click)=\"toggleGroup(group.id)\"\n                    >\n                      <svg\n                        aria-hidden=\"true\"\n                        viewBox=\"0 0 16 16\"\n                        class=\"cws:size-3 cws:shrink-0 cws:transition-transform\"\n                        [class.cws:-rotate-90]=\"!group.expanded\"\n                        fill=\"none\"\n                        stroke=\"currentColor\"\n                        stroke-width=\"2\"\n                        stroke-linecap=\"round\"\n                        stroke-linejoin=\"round\"\n                      >\n                        <path d=\"M4 6l4 4 4-4\" />\n                      </svg>\n                      <span class=\"cws:min-w-0 cws:flex-1 cws:truncate\">{{ group.label }}</span>\n                      <span class=\"cws:font-normal cws:tracking-normal cws:normal-case\">{{ group.grids.length }}</span>\n                    </button>\n                  </h4>\n                  @if (group.expanded) {\n                    <ul id=\"builder-palette-group-grids\">\n                      @for (entry of group.grids; track entry.id) {\n                        @let placed = entry.place !== null;\n                        <li\n                          class=\"cws:group cws:flex cws:items-center cws:gap-1.5 cws:rounded-md cws:py-1 cws:pr-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700/60\"\n                          [class.cws:cursor-grab]=\"!readOnly()\"\n                          [class.cws:opacity-40]=\"dragging()?.kind === 'block' && dragging()?.id === entry.id\"\n                          data-drag=\"block\"\n                          [attr.data-id]=\"entry.id\"\n                          [attr.data-placed]=\"placed\"\n                          data-testid=\"builder-palette-grid\"\n                        >\n                          @if (!readOnly()) {\n                            <span\n                              aria-hidden=\"true\"\n                              class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                            >⠿</span>\n                          }\n                          <span class=\"cws:min-w-0 cws:flex-1\">\n                            <span\n                              class=\"cws:block cws:truncate\"\n                              [class.cws:text-slate-900]=\"!placed\"\n                              [class.cws:dark:text-slate-100]=\"!placed\"\n                              [class.cws:text-slate-500]=\"placed\"\n                              [class.cws:dark:text-slate-400]=\"placed\"\n                            >\n                              {{ entry.label }}\n                            </span>\n                            <span class=\"cws:flex cws:items-center cws:gap-1 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\n                              <span\n                                aria-hidden=\"true\"\n                                class=\"cws:size-1.5 cws:shrink-0 cws:rounded-full\"\n                                [class.cws:bg-emerald-500]=\"placed\"\n                                [class.cws:ring-1]=\"!placed\"\n                                [class.cws:ring-slate-400]=\"!placed\"\n                              ></span>\n                              <span class=\"cws:truncate\">{{ entry.place ?? 'Unplaced' }}</span>\n                            </span>\n                          </span>\n                          @if (!placed && !readOnly() && shownTabInfo(); as tab) {\n                            <button\n                              type=\"button\"\n                              class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-scoular-blue cws:hover:bg-white cws:dark:text-sky-400 cws:dark:hover:bg-slate-800\"\n                              [attr.aria-label]=\"'Place the ' + entry.label + ' grid on ' + tab.label\"\n                              (click)=\"placeGrid(entry.id)\"\n                            >\n                              Place\n                            </button>\n                          }\n                        </li>\n                      }\n                    </ul>\n                  }\n                </div>\n              }\n            </div>\n          </aside>\n\n          <!--\n            The form layout: the tab strip, then the shown tab's sections as headed lists of compact rows, then its\n            grids. One surface with separators between rows, rather than a card per section and a box per field.\n            Dragging is the main way to arrange it; every drag also has a keyboard path (Alt and an arrow) and a\n            \"Move to\" in the item's ⋯ menu.\n          -->\n          <div class=\"scoular-card cws:min-w-0 cws:self-start cws:overflow-hidden\" data-testid=\"builder-canvas\">\n            <div\n              role=\"toolbar\"\n              aria-label=\"Tabs\"\n              class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-x-0.5 cws:border-b cws:border-slate-200 cws:bg-slate-50 cws:px-2 cws:pt-1.5 cws:dark:border-slate-700 cws:dark:bg-slate-900/40\"\n              [class.cws:ring-2]=\"invalid().tabs\"\n              [class.cws:ring-inset]=\"invalid().tabs\"\n              [class.cws:ring-red-600]=\"invalid().tabs\"\n              [attr.data-invalid]=\"invalid().tabs ? 'true' : null\"\n              data-testid=\"builder-tab-strip\"\n            >\n              @for (tab of tabs(); track tab.id; let index = $index) {\n                @let shown = tab.id === shownTab();\n                @let over = overKey() === 'tab:' + tab.id;\n                <span\n                  class=\"cws:-mb-px cws:inline-flex cws:items-center cws:gap-1 cws:rounded-t-md cws:border-b-2 cws:px-2.5 cws:py-1.5 cws:text-sm cws:ring-scoular-blue\"\n                  [class.cws:border-scoular-blue]=\"shown\"\n                  [class.cws:bg-white]=\"shown && !over\"\n                  [class.cws:dark:bg-slate-800]=\"shown && !over\"\n                  [class.cws:font-semibold]=\"shown\"\n                  [class.cws:text-slate-900]=\"shown\"\n                  [class.cws:dark:text-white]=\"shown\"\n                  [class.cws:border-transparent]=\"!shown\"\n                  [class.cws:text-slate-600]=\"!shown\"\n                  [class.cws:dark:text-slate-300]=\"!shown\"\n                  [class.cws:hover:text-slate-900]=\"!shown\"\n                  [class.cws:dark:hover:text-white]=\"!shown\"\n                  [class.cws:bg-sky-100]=\"over\"\n                  [class.cws:dark:bg-sky-900]=\"over\"\n                  [class.cws:ring-2]=\"isSelected('tab', tab.id)\"\n                  [class.cws:ring-inset]=\"isSelected('tab', tab.id)\"\n                  [class.cws:cursor-grab]=\"!readOnly()\"\n                  [class.cws:opacity-50]=\"dragging()?.kind === 'tab' && dragging()?.id === tab.id\"\n                  data-drag=\"tab\"\n                  [attr.data-id]=\"tab.id\"\n                  data-drop=\"tab\"\n                  [attr.data-key]=\"'tab:' + tab.id\"\n                  [attr.data-tab]=\"tab.id\"\n                  [attr.data-index]=\"index\"\n                  data-testid=\"builder-tab\"\n                >\n                  <!--\n                    data-drag-grip: a press on the label may become a tab drag; a plain click still shows the tab. A\n                    field or a section dragged onto a tab lands at the end of its first section, and one that rests\n                    on it for a moment shows the tab, so it can be dropped in a section there.\n                  -->\n                  <button\n                    type=\"button\"\n                    data-drag-grip\n                    [class.cws:cursor-grab]=\"!readOnly()\"\n                    (click)=\"activeTab.set(tab.id); select({ kind: 'tab', id: tab.id }, $event)\"\n                    [attr.aria-pressed]=\"shown\"\n                  >\n                    {{ tab.label }}\n                  </button>\n                  @if (empty().tabs.has(tab.id)) {\n                    <span class=\"cws:text-xs cws:font-normal cws:text-amber-700 cws:dark:text-amber-300\" data-testid=\"builder-empty-tab\">(empty)</span>\n                  }\n                  @if (changed().tabs.has(tab.id)) {\n                    <span class=\"cws:size-1.5 cws:rounded-full cws:bg-scoular-blue cws:dark:bg-sky-400\" title=\"Edited\"></span>\n                    <span class=\"cws:sr-only\">edited</span>\n                  }\n                </span>\n              }\n              @if (!readOnly()) {\n                <button\n                  type=\"button\"\n                  class=\"cws:mb-1 cws:ml-1 cws:rounded cws:px-2 cws:py-1 cws:text-sm cws:text-scoular-blue cws:hover:bg-slate-200/60 cws:dark:text-sky-400 cws:dark:hover:bg-slate-700\"\n                  (click)=\"addTab()\"\n                  data-testid=\"builder-add-tab\"\n                >\n                  <span aria-hidden=\"true\">+</span> Add tab\n                </button>\n              }\n            </div>\n\n            @if (shownTabInfo(); as tab) {\n              @if (!readOnly()) {\n                <div class=\"cws:flex cws:justify-end cws:gap-3 cws:px-3 cws:pt-2 cws:text-xs\">\n                  <button type=\"button\" class=\"cws:text-slate-600 cws:hover:text-scoular-blue cws:hover:underline cws:dark:text-slate-300 cws:dark:hover:text-sky-400\" (click)=\"renameTab(tab.id, tab.label)\">\n                    Rename tab\n                  </button>\n                  <button type=\"button\" class=\"cws:text-red-700 cws:hover:underline cws:dark:text-red-300\" (click)=\"deleteTab(tab.id, tab.label)\">Delete tab</button>\n                </div>\n              }\n\n              @for (section of shownSections(); track section.id; let sectionIndex = $index) {\n                @let sectionSelected = isSelected('section', section.id);\n                <section\n                  class=\"cws:relative cws:px-3 cws:pt-2.5 cws:pb-1\"\n                  [class.cws:bg-sky-50]=\"sectionSelected\"\n                  [class.cws:dark:bg-sky-950]=\"sectionSelected\"\n                  [class.cws:ring-2]=\"invalid().sections.has(section.id)\"\n                  [class.cws:ring-inset]=\"invalid().sections.has(section.id)\"\n                  [class.cws:ring-red-600]=\"invalid().sections.has(section.id)\"\n                  [class.cws:opacity-50]=\"dragging()?.kind === 'section' && dragging()?.id === section.id\"\n                  [attr.data-invalid]=\"invalid().sections.has(section.id) ? 'true' : null\"\n                  [attr.aria-label]=\"'Section ' + section.label\"\n                  data-testid=\"builder-section\"\n                >\n                  @if (overKey() === 'section:' + section.id) {\n                    <span\n                      class=\"cws:pointer-events-none cws:absolute cws:inset-x-2 cws:top-0 cws:z-10 cws:h-0.5 cws:rounded cws:bg-scoular-blue\"\n                      data-testid=\"builder-drop-line\"\n                      data-edge=\"before\"\n                    ></span>\n                  }\n                  <!-- The heading is a drag handle for the section, and a drop target: a field dropped on it goes first in the section. -->\n                  <header\n                    class=\"cws:group cws:flex cws:items-center cws:gap-1.5 cws:pb-1\"\n                    [class.cws:cursor-grab]=\"!readOnly()\"\n                    data-drag=\"section\"\n                    [attr.data-id]=\"section.id\"\n                    data-drop=\"section\"\n                    [attr.data-key]=\"'section:' + section.id\"\n                    [attr.data-tab]=\"tab.id\"\n                    [attr.data-section]=\"section.id\"\n                    [attr.data-index]=\"sectionIndex\"\n                    data-testid=\"builder-section-header\"\n                  >\n                    @if (!readOnly()) {\n                      <span\n                        aria-hidden=\"true\"\n                        class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                      >⠿</span>\n                    }\n                    <button\n                      type=\"button\"\n                      data-drag-grip\n                      class=\"cws:text-xs cws:font-semibold cws:tracking-wider cws:text-slate-600 cws:uppercase cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:text-white\"\n                      [class.cws:cursor-grab]=\"!readOnly()\"\n                      (click)=\"select({ kind: 'section', id: section.id }, $event)\"\n                    >\n                      {{ section.label }}\n                    </button>\n                    @if (empty().sections.has(section.id)) {\n                      <span class=\"cws:text-xs cws:text-amber-700 cws:dark:text-amber-300\" data-testid=\"builder-empty-section\">(no fields)</span>\n                    }\n                    @if (changed().sections.has(section.id)) {\n                      <span class=\"cws:text-xs cws:text-scoular-blue cws:dark:text-sky-400\">edited</span>\n                    } @else if (inheritedBadge(); as badge) {\n                      <span class=\"cws:rounded cws:bg-slate-100 cws:px-1 cws:text-[11px] cws:text-slate-500 cws:dark:bg-slate-700 cws:dark:text-slate-300\" data-testid=\"builder-inherited\">\n                        {{ badge }}\n                      </span>\n                    }\n                    @if (!readOnly()) {\n                      <span class=\"cws:ml-auto cws:flex cws:items-center cws:gap-1\">\n                        <button\n                          type=\"button\"\n                          class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-900 cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white\"\n                          (click)=\"renameSection(section.id, section.label)\"\n                        >\n                          Rename\n                        </button>\n                        <cms-builder-item-menu\n                          [label]=\"'Actions for section ' + section.label\"\n                          moveLabel=\"Move to tab\"\n                          [targets]=\"tabTargets().get(tab.id) ?? []\"\n                          [actions]=\"sectionActions().get(section.id) ?? []\"\n                          (moveTo)=\"moveSectionTo(section.id, $event)\"\n                        />\n                      </span>\n                    }\n                  </header>\n\n                  <ul class=\"cws:divide-y cws:divide-slate-100 cws:border-t cws:border-slate-100 cws:dark:divide-slate-700/70 cws:dark:border-slate-700/70\">\n                    @for (name of section.fields; track name; let fieldIndex = $index) {\n                      @if (fieldBehaviour(name); as behaviour) {\n                        @let fieldSelected = isSelected('field', name);\n                        @let lifted = (dragging()?.kind === 'field' || dragging()?.kind === 'palette') && dragging()?.id === name;\n                        <!-- A compound group (the contract number) is one row: always shown and required, its ticks locked. -->\n                        @let groupLocked = groupLock(name);\n                        @let flagLocked = groupLocked ?? (ctrmRequired().has(name) ? ctrmRequiredReason : null);\n                        @let rowInvalidNow = rowInvalid(name);\n                        <li\n                          class=\"cws:group cws:relative cws:flex cws:items-center cws:gap-1.5 cws:py-1 cws:pr-0.5 cws:text-sm\"\n                          [class.cws:cursor-grab]=\"!readOnly()\"\n                          [class.cws:hover:bg-slate-50]=\"!fieldSelected\"\n                          [class.cws:dark:hover:bg-slate-700/40]=\"!fieldSelected\"\n                          [class.cws:bg-sky-100]=\"fieldSelected\"\n                          [class.cws:dark:bg-sky-950]=\"fieldSelected\"\n                          [class.cws:bg-red-50]=\"rowInvalidNow\"\n                          [class.cws:dark:bg-red-950]=\"rowInvalidNow\"\n                          [class.cws:opacity-40]=\"lifted\"\n                          [attr.data-dragging]=\"lifted ? 'true' : null\"\n                          [attr.data-invalid]=\"rowInvalidNow ? 'true' : null\"\n                          [attr.data-group]=\"groupLocked === null ? null : 'true'\"\n                          data-drag=\"field\"\n                          [attr.data-id]=\"name\"\n                          data-drop=\"field\"\n                          [attr.data-key]=\"'field:' + name\"\n                          [attr.data-section]=\"section.id\"\n                          [attr.data-index]=\"fieldIndex\"\n                          data-testid=\"builder-field\"\n                        >\n                          @if (overKey() === 'field:' + name || overKey() === 'after:' + name) {\n                            <!-- The insertion line: above the row on its upper half, below it on its lower half. -->\n                            <span\n                              class=\"cws:pointer-events-none cws:absolute cws:inset-x-0 cws:z-10 cws:h-0.5 cws:rounded cws:bg-scoular-blue\"\n                              [class.cws:-top-px]=\"overKey() === 'field:' + name\"\n                              [class.cws:-bottom-px]=\"overKey() === 'after:' + name\"\n                              [attr.data-edge]=\"overKey() === 'after:' + name ? 'after' : 'before'\"\n                              data-testid=\"builder-drop-line\"\n                            ></span>\n                          }\n                          @if (!readOnly()) {\n                            <span\n                              aria-hidden=\"true\"\n                              class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                              data-testid=\"builder-grip\"\n                            >⠿</span>\n                          }\n                          <!-- data-drag-grip: a press on the name may become a drag; a plain click selects the field. -->\n                          <button\n                            type=\"button\"\n                            data-drag-grip\n                            class=\"cws:min-w-0 cws:flex-1 cws:truncate cws:text-left cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\"\n                            [class.cws:cursor-grab]=\"!readOnly()\"\n                            (click)=\"select({ kind: 'field', id: name }, $event)\"\n                          >\n                            {{ rowLabel(name) }}\n                            @if (groupLocked !== null || behaviour.required) {\n                              <span class=\"cws:text-red-700 cws:dark:text-red-300\" aria-label=\"required\">*</span>\n                            }\n                          </button>\n                          @if (rowChanged(name)) {\n                            <span class=\"cws:text-[11px] cws:text-scoular-blue cws:dark:text-sky-400\">edited</span>\n                          }\n                          <!-- F7's quick toggles, kept on the row but quieter than the name. -->\n                          <span class=\"cws:flex cws:shrink-0 cws:items-center cws:gap-2.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n                            <label class=\"cws:flex cws:items-center cws:gap-1\">\n                              <input\n                                type=\"checkbox\"\n                                class=\"cws:size-3.5\"\n                                [checked]=\"behaviour.visible\"\n                                [disabled]=\"readOnly() || flagLocked !== null\"\n                                [attr.title]=\"flagLocked\"\n                                (change)=\"toggleVisible(name)\"\n                              />\n                              Visible\n                            </label>\n                            <label class=\"cws:flex cws:items-center cws:gap-1\">\n                              <input\n                                type=\"checkbox\"\n                                class=\"cws:size-3.5\"\n                                [checked]=\"groupLocked !== null || behaviour.required\"\n                                [disabled]=\"readOnly() || flagLocked !== null\"\n                                [attr.title]=\"flagLocked\"\n                                (change)=\"toggleRequired(name)\"\n                              />\n                              Required\n                            </label>\n                          </span>\n                          @if (!readOnly()) {\n                            <!-- Move to, Move up and down, Properties and Remove: the row's secondary actions (2026-10-29). -->\n                            <cms-builder-item-menu\n                              [label]=\"'Actions for ' + rowLabel(name)\"\n                              [targets]=\"sectionTargets().get(section.id) ?? []\"\n                              [actions]=\"fieldActions().get(name) ?? []\"\n                              (moveTo)=\"moveFieldTo(name, $event)\"\n                            />\n                          }\n                        </li>\n                      }\n                    }\n                    <!-- The end of the section: a drop zone while a field is dragged, and otherwise the way to add one. -->\n                    @if (fieldDrag()) {\n                      <li class=\"cws:py-0.5\" data-drop=\"section-end\" [attr.data-key]=\"'end:' + section.id\" [attr.data-section]=\"section.id\">\n                        <span\n                          class=\"cws:block cws:rounded cws:border cws:border-dashed cws:px-2 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\n                          [class.cws:border-scoular-blue]=\"overKey() === 'end:' + section.id\"\n                          [class.cws:bg-sky-50]=\"overKey() === 'end:' + section.id\"\n                          [class.cws:dark:bg-sky-950]=\"overKey() === 'end:' + section.id\"\n                          [class.cws:border-slate-300]=\"overKey() !== 'end:' + section.id\"\n                          [class.cws:dark:border-slate-600]=\"overKey() !== 'end:' + section.id\"\n                        >\n                          Drop at the end of {{ section.label }}\n                        </span>\n                      </li>\n                    } @else if (!readOnly()) {\n                      <li data-drop=\"section-end\" [attr.data-key]=\"'end:' + section.id\" [attr.data-section]=\"section.id\">\n                        <button\n                          type=\"button\"\n                          class=\"cws:my-0.5 cws:rounded cws:px-1 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-sky-400\"\n                          [attr.aria-label]=\"'Add a field to ' + section.label\"\n                          (click)=\"addFieldTo(section.id)\"\n                          data-testid=\"builder-add-field\"\n                        >\n                          <span aria-hidden=\"true\">+</span> Add field\n                        </button>\n                      </li>\n                    }\n                  </ul>\n                </section>\n              }\n\n              <!-- F8: collection blocks, moved between tabs as whole blocks. -->\n              @for (block of shownBlocks(); track block.collection) {\n                <div\n                  class=\"cws:group cws:mx-3 cws:mt-2 cws:flex cws:items-center cws:gap-1.5 cws:rounded-md cws:bg-slate-50 cws:py-1.5 cws:pr-1 cws:text-sm cws:dark:bg-slate-900/40\"\n                  [class.cws:cursor-grab]=\"!readOnly()\"\n                  [class.cws:ring-2]=\"isSelected('block', block.collection) || invalid().collections.has(block.collection)\"\n                  [class.cws:ring-scoular-blue]=\"!invalid().collections.has(block.collection)\"\n                  [class.cws:ring-red-600]=\"invalid().collections.has(block.collection)\"\n                  [class.cws:opacity-50]=\"dragging()?.kind === 'block' && dragging()?.id === block.collection\"\n                  data-drag=\"block\"\n                  [attr.data-id]=\"block.collection\"\n                  data-testid=\"builder-block\"\n                >\n                  @if (!readOnly()) {\n                    <span\n                      aria-hidden=\"true\"\n                      class=\"cws:w-4 cws:shrink-0 cws:text-center cws:leading-none cws:text-slate-300 cws:group-hover:text-slate-500 cws:dark:text-slate-600 cws:dark:group-hover:text-slate-400\"\n                    >⠿</span>\n                  }\n                  <button\n                    type=\"button\"\n                    data-drag-grip\n                    class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\"\n                    [class.cws:cursor-grab]=\"!readOnly()\"\n                    (click)=\"select({ kind: 'block', id: block.collection }, $event)\"\n                  >\n                    {{ block.label }}\n                  </button>\n                  <span class=\"cws:mr-auto cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">A grid of its own</span>\n                  @if (!readOnly()) {\n                    <cms-builder-item-menu\n                      [label]=\"'Actions for the ' + block.label + ' grid'\"\n                      moveLabel=\"Move to tab\"\n                      [targets]=\"tabTargets().get(tab.id) ?? []\"\n                      [actions]=\"gridActions\"\n                      (moveTo)=\"moveBlockTo(block, $event)\"\n                    />\n                  }\n                </div>\n              }\n\n              <!--\n                The end of the tab, while a section or a grid is dragged, so it can be dropped after the last section. A\n                grid dragged anywhere on the tab lands here, because a grid shows after its tab's sections (2026-10-29).\n              -->\n              @if (dragging()?.kind === 'section' || dragging()?.kind === 'block') {\n                <div\n                  class=\"cws:mx-3 cws:mt-2 cws:rounded cws:border cws:border-dashed cws:p-2 cws:text-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\n                  [class.cws:border-scoular-blue]=\"overKey() === 'tab-end:' + tab.id\"\n                  [class.cws:bg-sky-50]=\"overKey() === 'tab-end:' + tab.id\"\n                  [class.cws:dark:bg-sky-950]=\"overKey() === 'tab-end:' + tab.id\"\n                  [class.cws:border-slate-300]=\"overKey() !== 'tab-end:' + tab.id\"\n                  [class.cws:dark:border-slate-600]=\"overKey() !== 'tab-end:' + tab.id\"\n                  data-drop=\"tab-end\"\n                  [attr.data-key]=\"'tab-end:' + tab.id\"\n                  [attr.data-tab]=\"tab.id\"\n                  data-testid=\"builder-tab-end\"\n                >\n                  @if (dragging()?.kind === 'block') {\n                    The grid goes here: a grid shows after its tab's sections\n                  } @else {\n                    Drop a section here\n                  }\n                </div>\n              }\n\n              @if (!readOnly()) {\n                <div class=\"cws:px-3 cws:pt-1 cws:pb-3\">\n                  <button\n                    type=\"button\"\n                    class=\"cws:rounded cws:px-1 cws:py-0.5 cws:text-sm cws:font-medium cws:text-scoular-blue cws:hover:bg-slate-100 cws:dark:text-sky-400 cws:dark:hover:bg-slate-700\"\n                    (click)=\"addSection(tab.id)\"\n                    data-testid=\"builder-add-section\"\n                  >\n                    <span aria-hidden=\"true\">+</span> Add section\n                  </button>\n                </div>\n              } @else {\n                <div class=\"cws:pb-2\"></div>\n              }\n            }\n          </div>\n\n          <!--\n            The right column: an editing panel (the selected item's properties, F7, or the trade unit's settings,\n            F15) over the live preview (F10). The preview is always mounted, so it stays on screen while a property\n            changes; the panel takes at most half the column's height on a wide screen and scrolls inside it.\n          -->\n          <div\n            class=\"cws:flex cws:min-w-0 cws:flex-col cws:gap-3 cws:lg:col-span-2 cws:xl:sticky cws:xl:top-4 cws:xl:col-span-1 cws:xl:max-h-[calc(100vh-2rem)] cws:xl:self-start\"\n            data-testid=\"builder-side\"\n          >\n            <div class=\"scoular-card cws:flex cws:shrink-0 cws:flex-col cws:overflow-hidden cws:xl:max-h-[45vh]\">\n              <div class=\"cws:flex cws:items-center cws:gap-1 cws:px-2 cws:py-1.5\">\n                <div role=\"group\" aria-label=\"Editing panel\" class=\"cws:flex cws:gap-1\">\n                  @for (view of inspectorViews; track view.id) {\n                    <button\n                      type=\"button\"\n                      class=\"cws:rounded-md cws:px-2.5 cws:py-1 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:bg-slate-100 cws:hover:text-slate-900 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white\"\n                      [class.cws:bg-slate-100]=\"inspector() === view.id\"\n                      [class.cws:text-slate-900]=\"inspector() === view.id\"\n                      [class.cws:dark:bg-slate-700]=\"inspector() === view.id\"\n                      [class.cws:dark:text-white]=\"inspector() === view.id\"\n                      [attr.aria-pressed]=\"inspector() === view.id\"\n                      (click)=\"toggleInspector(view.id)\"\n                      [attr.data-testid]=\"'builder-side-' + view.id\"\n                    >\n                      {{ view.label }}\n                    </button>\n                  }\n                </div>\n                @if (inspector() !== null) {\n                  <button\n                    type=\"button\"\n                    class=\"cws:ml-auto cws:rounded cws:p-1 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-800 cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-white\"\n                    aria-label=\"Close the panel\"\n                    title=\"Close the panel\"\n                    (click)=\"inspector.set(null)\"\n                    data-testid=\"builder-side-close\"\n                  >\n                    <svg aria-hidden=\"true\" viewBox=\"0 0 16 16\" class=\"cws:size-4\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\">\n                      <path d=\"M4 4l8 8M12 4l-8 8\" />\n                    </svg>\n                  </button>\n                } @else {\n                  <span class=\"cws:ml-auto cws:truncate cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Select a field to edit it</span>\n                }\n              </div>\n              @if (inspector() !== null) {\n                <div class=\"cws:min-h-0 cws:overflow-y-auto cws:border-t cws:border-slate-200 cws:dark:border-slate-700\">\n                  @if (registry(); as reg) {\n                    @if (inspector() === 'properties') {\n                      <cms-builder-properties\n                        [document]=\"doc\"\n                        [registry]=\"reg\"\n                        [selection]=\"propertiesSelection()\"\n                        [readOnly]=\"readOnly()\"\n                        [ctrmRequired]=\"ctrmRequired()\"\n                        (op)=\"run($event)\"\n                      />\n                    } @else {\n                      <cms-builder-settings [document]=\"doc\" [registry]=\"reg\" [readOnly]=\"readOnly()\" (op)=\"run($event)\" />\n                    }\n                  }\n                </div>\n              }\n            </div>\n            <cms-builder-preview\n              class=\"cws:block cws:min-h-0 cws:xl:flex-1\"\n              [document]=\"doc\"\n              [resolutionKey]=\"resolutionKey()\"\n              (problemsChange)=\"problems.set($event)\"\n            />\n          </div>\n        </div>\n\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Keyboard: select a card or section, then Alt and an arrow key moves it; Ctrl+Z undoes and Ctrl+Y redoes.\n          <a class=\"cws:text-scoular-blue cws:underline cws:dark:text-sky-400\" routerLink=\"rows\">Every configuration row</a>\n        </p>\n      }\n    }\n  }\n</section>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { paletteSearchInput: [{
		type: i0.ViewChild,
		args: ["paletteSearchInput", { isSignal: true }]
	}] }
});
function sameDimensions(row, dimensions) {
	const same = (stored, chosen) => (stored ?? "").trim().toUpperCase() === chosen.trim().toUpperCase();
	return same(row.contractTypeClass, dimensions.contractTypeClass) && same(row.locationCode, dimensions.locationCode) && same(row.commodityCode, dimensions.commodityCode);
}
function previewDimensionsOf(dimensions) {
	return {
		...dimensions.contractTypeClass === "" ? {} : { contractTypeClass: dimensions.contractTypeClass },
		...dimensions.locationCode === "" ? {} : { locationCode: dimensions.locationCode },
		...dimensions.commodityCode === "" ? {} : { commodityCode: dimensions.commodityCode }
	};
}
function countOf(count, noun) {
	return `${count} ${noun}${count === 1 ? "" : "s"}`;
}
function todayIso() {
	const now = /* @__PURE__ */ new Date();
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
const formBuilderLeaveGuard = (component) => component.canLeave();
function withRegistryFieldsOnly(document, registry) {
	if (registry === null) return document;
	if (Object.keys(document.fields).filter((name) => !(name in registry.fields)).length === 0) return document;
	const fields = Object.fromEntries(Object.entries(document.fields).filter(([name]) => name in registry.fields));
	return {
		...document,
		fields
	};
}
var PersonResolver = class {
	state = signal({ status: "empty" }, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	states = new BehaviorSubject({ status: "empty" });
	entries = new Subject();
	constructor(directory, destroyRef, onChange = () => void 0, pauseMs = 400) {
		this.entries.pipe(switchMap(({ text, now }) => resolve(directory, text, now, pauseMs)), takeUntilDestroyed(destroyRef)).subscribe((state) => {
			this.state.set(state);
			this.states.next(state);
			onChange(state);
		});
	}
	entered(value) {
		this.entries.next({
			text: value.trim(),
			now: false
		});
	}
	committed(value) {
		const text = value.trim();
		const current = this.states.value;
		if (current.status !== "empty" && current.status !== "waiting" && current.text === text) return;
		if (current.status === "empty" && text === "") return;
		this.entries.next({
			text,
			now: true
		});
	}
	settled(value) {
		this.committed(value);
		return this.states.pipe(filter((state) => state.status !== "waiting" && state.status !== "looking"), take(1));
	}
	reset() {
		this.entries.next({
			text: "",
			now: true
		});
	}
};
function resolve(directory, text, now, pauseMs) {
	if (text === "") return of({ status: "empty" });
	if (isEntraObjectId(text)) return of({
		status: "objectId",
		text,
		objectId: text
	});
	if (!looksLikeUpn(text)) return of({
		status: "neither",
		text
	});
	if (directory === null) return of({
		status: "unavailable",
		text,
		correlationId: null,
		offered: false
	});
	const lookup = concat(of({
		status: "looking",
		text
	}), defer(() => directory.lookUpByUpn(text)).pipe(map((answer) => fromLookup(text, answer))));
	return now ? lookup : concat(of({
		status: "waiting",
		text
	}), timer(pauseMs).pipe(switchMap(() => lookup)));
}
function fromLookup(text, answer) {
	switch (answer.kind) {
		case "found": return {
			status: "found",
			text,
			user: answer.user
		};
		case "notFound": return {
			status: "notFound",
			text,
			correlationId: answer.correlationId ?? null
		};
		case "invalid": return {
			status: "invalid",
			text,
			message: answer.message,
			correlationId: answer.correlationId ?? null
		};
		default: return {
			status: "unavailable",
			text,
			correlationId: answer.correlationId ?? null,
			offered: true
		};
	}
}
function lookupOutcome(state) {
	switch (state.status) {
		case "notFound": return mutationFailed({
			message: `${NO_USER_FOUND} ${PENDING_BY_EMAIL}`,
			correlationId: state.correlationId
		});
		case "invalid": return mutationFailed({
			message: state.message,
			correlationId: state.correlationId
		});
		case "unavailable": return state.offered ? mutationFailed({
			message: `${DIRECTORY_UNAVAILABLE} ${PENDING_BY_EMAIL}`,
			correlationId: state.correlationId
		}) : mutationRefused(`${DIRECTORY_NOT_OFFERED} ${PENDING_BY_EMAIL}`);
		default: return null;
	}
}
const PENDING_BY_EMAIL = "A scoular.com address can still be given the role: it waits as pending and takes effect the first time they sign in, within 30 days. A typo can't be caught until then, so check the address.";
function personToAssign(state, typedUpn) {
	switch (state.status) {
		case "objectId": return {
			objectId: state.objectId,
			upn: typedUpn.trim(),
			label: typedUpn.trim() || state.objectId
		};
		case "found": return {
			objectId: state.user.objectId,
			upn: state.user.upn,
			label: state.user.displayName || state.user.upn
		};
		case "notFound":
		case "unavailable": return {
			email: state.text.trim().toLowerCase(),
			label: state.text.trim().toLowerCase()
		};
		case "invalid": return { refusal: state.message };
		default: return { refusal: PERSON_REFUSAL };
	}
}
function notATradeUnitMessage(codes) {
	return `${codes.join(", ")} is not a CTRM trade unit. Pick one from the list.`;
}
function listOf(codes) {
	return codes.length <= 1 ? codes.join("") : `${codes.slice(0, -1).join(", ")} and ${codes[codes.length - 1]}`;
}
function tradeUnitLabel(code) {
	return isAllTradeUnits(code) ? "All trade units" : code;
}
function assignedSentence(who, answer, defaultTradeUnit) {
	const named = answer.added.filter((code) => !isAllTradeUnits(code));
	const everywhere = answer.added.some(isAllTradeUnits);
	const parts = [];
	if (answer.added.length === 0) parts.push(`Nothing changed for ${who}.`);
	else parts.push(`Role assigned to ${who} in ${everywhere ? "every trade unit" : listOf(named)}.`);
	if (defaultTradeUnit !== null && answer.rows.some((row) => row.isDefault && row.tradeUnit === defaultTradeUnit)) parts.push(`${defaultTradeUnit} is their default trade unit.`);
	const held = answer.skipped.filter((skip) => skip.reason === "exists").map((skip) => tradeUnitLabel(skip.tradeUnit));
	const covered = answer.skipped.filter((skip) => skip.reason === "coveredByAllTradeUnits").map((skip) => skip.tradeUnit);
	if (held.length > 0) parts.push(`${listOf(held)} ${held.length === 1 ? "was" : "were"} already held; skipped.`);
	if (covered.length > 0) parts.push(`${listOf(covered)} ${covered.length === 1 ? "is" : "are"} already covered by this role in every trade unit; skipped.`);
	return parts.join(" ");
}
function pendingUntil(row) {
	return row.expiresAtUtc.slice(0, 10);
}
function pendingSentence(email, answer) {
	const rows = answer.pending ?? [];
	const given = [...answer.added, ...answer.renewed ?? []];
	const units = given.some(isAllTradeUnits) ? "every trade unit" : listOf(given.filter((code) => !isAllTradeUnits(code)));
	const until = rows.filter((row) => given.includes(row.tradeUnit)).map(pendingUntil).sort().at(-1);
	const parts = [`Saved as pending for ${email} in ${units}: it takes effect the first time they sign in` + (until === void 0 ? "." : `, if they do by ${until}.`)];
	if ((answer.renewed ?? []).length > 0) parts.push(`${listOf(answer.renewed ?? [])} ${(answer.renewed ?? []).length === 1 ? "was" : "were"} already pending; renewed.`);
	parts.push("A typo can't be caught until then, so check the address.");
	return parts.join(" ");
}
var RolesPageComponent = class RolesPageComponent {
	view = input("all", {
		...ngDevMode ? { debugName: "view" } : /* istanbul ignore next */ {},
		transform: (value) => value ?? "all"
	});
	showPermissions = computed(() => this.view() === "all" || this.view() === "permissions", ...ngDevMode ? [{ debugName: "showPermissions" }] : /* istanbul ignore next */ []);
	showRoles = computed(() => this.view() === "all" || this.view() === "roles", ...ngDevMode ? [{ debugName: "showRoles" }] : /* istanbul ignore next */ []);
	showAssignments = computed(() => this.view() === "all" || this.view() === "assignments", ...ngDevMode ? [{ debugName: "showAssignments" }] : /* istanbul ignore next */ []);
	routed = computed(() => this.view() !== "all", ...ngDevMode ? [{ debugName: "routed" }] : /* istanbul ignore next */ []);
	area = adminArea("roles");
	access = inject(AdminScope);
	refused = computed(() => this.access.knownNotAdmin(), ...ngDevMode ? [{ debugName: "refused" }] : /* istanbul ignore next */ []);
	roleActions = computed(() => {
		const busy = this.roleBusy();
		return new Map(this.roleRows().map((role) => {
			const refusal = () => this.systemReason(role) ?? (busy ? "A role change is in progress" : false);
			const actions = [{
				label: "Edit",
				run: (row) => this.editRole(row),
				disabled: refusal
			}, {
				label: "Delete",
				run: (row) => this.deleteRole(row),
				disabled: refusal
			}];
			return [role.id, actions];
		}));
	}, ...ngDevMode ? [{ debugName: "roleActions" }] : /* istanbul ignore next */ []);
	assignmentKey(row) {
		return `${row.userObjectId}|${row.roleId}|${row.tradeUnit}`;
	}
	assignmentActions = computed(() => {
		const refusal = () => this.assignmentBusy() ? "An assignment change is in progress" : false;
		return new Map(this.assignments().map((assignment) => {
			const actions = [];
			if (!assignment.isDefault && !isAllTradeUnits(assignment.tradeUnit)) actions.push({
				label: "Make default",
				run: (row) => this.setDefault(row),
				disabled: refusal
			});
			actions.push({
				label: "Revoke",
				run: (row) => this.revoke(row),
				disabled: refusal
			});
			return [this.assignmentKey(assignment), actions];
		}));
	}, ...ngDevMode ? [{ debugName: "assignmentActions" }] : /* istanbul ignore next */ []);
	pendingKey(row) {
		return `${row.email}|${row.roleId}|${row.tradeUnit}`;
	}
	pendingActions = computed(() => {
		const refusal = () => this.assignmentBusy() ? "An assignment change is in progress" : false;
		return new Map(this.pendingRows().map((row) => {
			const actions = this.source?.revokePending === void 0 ? [] : [{
				label: "Revoke",
				run: (pending) => this.revokePending(pending),
				disabled: refusal
			}];
			return [this.pendingKey(row), actions];
		}));
	}, ...ngDevMode ? [{ debugName: "pendingActions" }] : /* istanbul ignore next */ []);
	catalogSource = inject(PERMISSION_CATALOG_SOURCE, { optional: true }) ?? new SamplePermissionCatalogSource();
	source = inject(ROLE_ADMIN_SOURCE, { optional: true });
	confirm = injectConfirm();
	destroyRef = inject(DestroyRef);
	answer = toSignal(this.catalogSource.get());
	catalog = computed(() => {
		const answer = this.answer();
		return answer?.status === "loaded" ? answer.value : null;
	}, ...ngDevMode ? [{ debugName: "catalog" }] : /* istanbul ignore next */ []);
	permissions = computed(() => this.catalog()?.entries ?? [], ...ngDevMode ? [{ debugName: "permissions" }] : /* istanbul ignore next */ []);
	isBuiltInCopy = computed(() => this.catalog()?.origin === SIMULATED_PERMISSION_CATALOG.origin, ...ngDevMode ? [{ debugName: "isBuiltInCopy" }] : /* istanbul ignore next */ []);
	offered = this.source !== null;
	rolesState = signal({ status: "loading" }, ...ngDevMode ? [{ debugName: "rolesState" }] : /* istanbul ignore next */ []);
	roleRows = signal([], ...ngDevMode ? [{ debugName: "roleRows" }] : /* istanbul ignore next */ []);
	storeOrigin = signal(null, ...ngDevMode ? [{ debugName: "storeOrigin" }] : /* istanbul ignore next */ []);
	roleEditor = signal(null, ...ngDevMode ? [{ debugName: "roleEditor" }] : /* istanbul ignore next */ []);
	roleBusy = signal(false, ...ngDevMode ? [{ debugName: "roleBusy" }] : /* istanbul ignore next */ []);
	roleOutcome = signal(null, ...ngDevMode ? [{ debugName: "roleOutcome" }] : /* istanbul ignore next */ []);
	roleFieldErrors = signal({}, ...ngDevMode ? [{ debugName: "roleFieldErrors" }] : /* istanbul ignore next */ []);
	rolesProblem = computed(() => {
		const state = this.rolesState();
		return state.status === "unavailable" || state.status === "failed" ? state.message : null;
	}, ...ngDevMode ? [{ debugName: "rolesProblem" }] : /* istanbul ignore next */ []);
	parentChoices = computed(() => {
		const editing = this.roleEditor()?.role?.id;
		return this.roleRows().filter((role) => role.id !== editing);
	}, ...ngDevMode ? [{ debugName: "parentChoices" }] : /* istanbul ignore next */ []);
	filter = { person: "" };
	filterUnit = signal([], ...ngDevMode ? [{ debugName: "filterUnit" }] : /* istanbul ignore next */ []);
	assignmentsState = signal({ status: "idle" }, ...ngDevMode ? [{ debugName: "assignmentsState" }] : /* istanbul ignore next */ []);
	assignments = signal([], ...ngDevMode ? [{ debugName: "assignments" }] : /* istanbul ignore next */ []);
	pendingRows = signal([], ...ngDevMode ? [{ debugName: "pendingRows" }] : /* istanbul ignore next */ []);
	pendingUntil = pendingUntil;
	assignmentBusy = signal(false, ...ngDevMode ? [{ debugName: "assignmentBusy" }] : /* istanbul ignore next */ []);
	assignmentOutcome = signal(null, ...ngDevMode ? [{ debugName: "assignmentOutcome" }] : /* istanbul ignore next */ []);
	assignmentFieldErrors = signal({}, ...ngDevMode ? [{ debugName: "assignmentFieldErrors" }] : /* istanbul ignore next */ []);
	filterError = signal(null, ...ngDevMode ? [{ debugName: "filterError" }] : /* istanbul ignore next */ []);
	assignment = emptyAssignment();
	directory = inject(USER_DIRECTORY_SOURCE, { optional: true });
	assignee = new PersonResolver(this.directory, this.destroyRef, (state) => this.assigneeChanged(state));
	filterPerson = new PersonResolver(this.directory, this.destroyRef);
	upnFromDirectory = signal(false, ...ngDevMode ? [{ debugName: "upnFromDirectory" }] : /* istanbul ignore next */ []);
	assigneeDismissed = signal(null, ...ngDevMode ? [{ debugName: "assigneeDismissed" }] : /* istanbul ignore next */ []);
	filterDismissed = signal(null, ...ngDevMode ? [{ debugName: "filterDismissed" }] : /* istanbul ignore next */ []);
	assigneeOutcome = computed(() => {
		const state = this.assignee.state();
		return state === this.assigneeDismissed() ? null : lookupOutcome(state);
	}, ...ngDevMode ? [{ debugName: "assigneeOutcome" }] : /* istanbul ignore next */ []);
	filterOutcome = computed(() => {
		const state = this.filterPerson.state();
		return state === this.filterDismissed() ? null : lookupOutcome(state);
	}, ...ngDevMode ? [{ debugName: "filterOutcome" }] : /* istanbul ignore next */ []);
	assigneePending = computed(() => {
		const status = this.assignee.state().status;
		return status === "notFound" || status === "unavailable";
	}, ...ngDevMode ? [{ debugName: "assigneePending" }] : /* istanbul ignore next */ []);
	directoryMode = signal(null, ...ngDevMode ? [{ debugName: "directoryMode" }] : /* istanbul ignore next */ []);
	assignAll = signal(false, ...ngDevMode ? [{ debugName: "assignAll" }] : /* istanbul ignore next */ []);
	assignUnits = signal([], ...ngDevMode ? [{ debugName: "assignUnits" }] : /* istanbul ignore next */ []);
	assignDefault = signal("", ...ngDevMode ? [{ debugName: "assignDefault" }] : /* istanbul ignore next */ []);
	person = signal(null, ...ngDevMode ? [{ debugName: "person" }] : /* istanbul ignore next */ []);
	notATradeUnitMessage = notATradeUnitMessage;
	tradeUnitLabel = tradeUnitLabel;
	locationOptions = computed(() => {
		const scope = this.access.scope();
		const onboarded = new Set(scope.onboarded);
		return [...this.access.locations() ?? []].filter((location) => !isAllTradeUnits(location.code)).sort((left, right) => left.code.localeCompare(right.code)).map((location) => ({
			code: location.code,
			label: `${location.code}${location.name === null ? "" : ` · ${location.name}`}` + (scope.known ? onboarded.has(location.code) ? " · onboarded" : " · not onboarded" : "")
		}));
	}, ...ngDevMode ? [{ debugName: "locationOptions" }] : /* istanbul ignore next */ []);
	locationNote = computed(() => this.access.locations() === null ? "The trade-unit list is not available here, so no trade unit can be chosen right now." : null, ...ngDevMode ? [{ debugName: "locationNote" }] : /* istanbul ignore next */ []);
	filterOptions = computed(() => [{
		code: ALL_TRADE_UNITS,
		label: "All trade units (roles held in every trade unit)"
	}, ...this.locationOptions()], ...ngDevMode ? [{ debugName: "filterOptions" }] : /* istanbul ignore next */ []);
	anyChosen = computed(() => this.assignAll() || this.assignUnits().length > 0, ...ngDevMode ? [{ debugName: "anyChosen" }] : /* istanbul ignore next */ []);
	defaultChoices = computed(() => {
		const options = this.locationOptions();
		if (this.assignAll()) return options;
		return this.assignUnits().map((code) => options.find((option) => option.code === code) ?? {
			code,
			label: code
		}).filter((option) => !isAllTradeUnits(option.code));
	}, ...ngDevMode ? [{ debugName: "defaultChoices" }] : /* istanbul ignore next */ []);
	personDefault = computed(() => {
		const person = this.person();
		return person?.status === "loaded" ? person.rows.find((row) => row.isDefault && !isAllTradeUnits(row.tradeUnit))?.tradeUnit ?? null : null;
	}, ...ngDevMode ? [{ debugName: "personDefault" }] : /* istanbul ignore next */ []);
	defaultRequired = computed(() => this.personDefault() === null, ...ngDevMode ? [{ debugName: "defaultRequired" }] : /* istanbul ignore next */ []);
	shownFilter = null;
	assignmentsProblem = computed(() => {
		const state = this.assignmentsState();
		return state.status === "unavailable" || state.status === "failed" ? state.message : null;
	}, ...ngDevMode ? [{ debugName: "assignmentsProblem" }] : /* istanbul ignore next */ []);
	constructor() {
		this.loadRoles();
	}
	permissionName(key) {
		return this.permissions().find((permission) => permission.key === key)?.name ?? key;
	}
	roleName(id) {
		return id === null ? "" : this.roleRows().find((role) => role.id === id)?.displayName ?? id;
	}
	systemReason(role) {
		return role.isSystem ? "The built-in Administrator role cannot be changed or deleted." : null;
	}
	loadRoles() {
		const source = this.source;
		if (source === null) return;
		this.rolesState.set({ status: "loading" });
		source.listRoles().pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			switch (answer.kind) {
				case "done":
					this.roleRows.set(answer.value.rows);
					this.storeOrigin.set(answer.value.storeOrigin);
					this.rolesState.set({ status: "loaded" });
					break;
				case "unavailable":
					this.rolesState.set({
						status: "unavailable",
						message: answer.reason
					});
					break;
				default: this.rolesState.set({
					status: "failed",
					message: answer.message
				});
			}
		});
	}
	newRole() {
		this.openRole({
			role: null,
			name: "",
			displayName: "",
			description: "",
			parentRoleId: null,
			permissionKeys: []
		});
	}
	editRole(role) {
		if (role.isSystem) return;
		this.openRole({
			role,
			name: role.name,
			displayName: role.displayName,
			description: role.description,
			parentRoleId: role.parentRoleId,
			permissionKeys: [...role.permissionKeys]
		});
	}
	cancelRole() {
		this.roleEditor.set(null);
		this.roleFieldErrors.set({});
		this.roleOutcome.set(null);
	}
	hasPermission(editor, key) {
		return editor.permissionKeys.includes(key);
	}
	togglePermission(editor, key, granted) {
		editor.permissionKeys = granted ? [.../* @__PURE__ */ new Set([...editor.permissionKeys, key])] : editor.permissionKeys.filter((candidate) => candidate !== key);
	}
	saveRole() {
		const source = this.source;
		const editor = this.roleEditor();
		if (source === null || editor === null) return;
		const shared = {
			displayName: editor.displayName.trim(),
			description: editor.description.trim(),
			parentRoleId: editor.parentRoleId || null,
			permissionKeys: [...editor.permissionKeys]
		};
		const request = editor.role === null ? source.createRole({
			name: editor.name.trim(),
			...shared
		}) : source.updateRole(editor.role, shared);
		const label = shared.displayName || (editor.role === null ? editor.name.trim() : editor.role.displayName);
		this.runRole(request, `Role "${label}" ${editor.role === null ? "created" : "saved"}.`, () => this.roleEditor.set(null));
	}
	deleteRole(role) {
		const source = this.source;
		if (source === null || role.isSystem) return;
		this.confirm({
			title: "Delete this role?",
			message: `"${role.displayName}" will be deleted. The server refuses if anyone holds it or another role inherits from it.`,
			confirmLabel: "Delete role",
			cancelLabel: "Keep role",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) this.runRole(source.deleteRole(role), `Role "${role.displayName}" deleted.`);
		});
	}
	openRole(editor) {
		this.roleEditor.set(editor);
		this.roleFieldErrors.set({});
		this.roleOutcome.set(null);
	}
	runRole(request, success, onDone) {
		this.roleBusy.set(true);
		this.roleOutcome.set(null);
		this.roleFieldErrors.set({});
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.roleBusy.set(false);
			switch (answer.kind) {
				case "done":
					onDone?.();
					this.roleOutcome.set(mutationSucceeded(success));
					this.loadRoles();
					break;
				case "unavailable":
					this.roleOutcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "refused":
					this.roleOutcome.set(mutationFailed(answer));
					break;
				case "failed":
					this.roleFieldErrors.set(answer.fieldErrors ?? {});
					this.roleOutcome.set(mutationFailed(answer));
			}
		});
	}
	loadAssignments() {
		const source = this.source;
		if (source === null) return;
		const tradeUnit = this.filterUnit()[0] ?? "";
		const typed = this.filter.person.trim();
		this.filterError.set(null);
		if (typed === "") {
			this.readAssignments(source, {
				tradeUnit,
				userObjectId: ""
			});
			return;
		}
		this.filterPerson.settled(typed).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => {
			switch (state.status) {
				case "objectId":
					this.readAssignments(source, {
						tradeUnit,
						userObjectId: state.objectId
					});
					break;
				case "found":
					this.readAssignments(source, {
						tradeUnit,
						userObjectId: state.user.objectId
					});
					break;
				case "notFound":
				case "invalid":
				case "unavailable":
					this.filterDismissed.set(null);
					break;
				default: this.filterError.set(PERSON_REFUSAL);
			}
		});
	}
	readAssignments(source, filter) {
		this.assignmentsState.set({ status: "loading" });
		source.listAssignments(filter).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			switch (answer.kind) {
				case "done":
					this.shownFilter = filter;
					this.directoryMode.set(answer.value.directory ?? null);
					this.assignments.set(answer.value.rows);
					this.pendingRows.set(answer.value.pending ?? []);
					this.assignmentsState.set({ status: "loaded" });
					break;
				case "unavailable":
					this.assignmentsState.set({
						status: "unavailable",
						message: answer.reason
					});
					break;
				default: this.assignmentsState.set({
					status: "failed",
					message: answer.message
				});
			}
		});
	}
	assign() {
		const source = this.source;
		if (source === null) return;
		this.assignee.settled(this.assignment.person).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => this.assignAs(source, state));
	}
	assignAs(source, state) {
		const form = this.assignment;
		const person = personToAssign(state, form.userUpn);
		if ("refusal" in person) {
			this.assignmentFieldErrors.set({ userObjectId: [person.refusal] });
			this.assignmentOutcome.set(mutationRefused(`Not assigned. ${person.refusal}`));
			return;
		}
		const all = this.assignAll();
		const units = all ? [] : [...this.assignUnits()];
		if (!all && units.length === 0) {
			const reason = "Choose at least one trade unit, or tick All trade units.";
			this.assignmentFieldErrors.set({ tradeUnits: [reason] });
			this.assignmentOutcome.set(mutationRefused(`Not assigned. ${reason}`));
			return;
		}
		const chosenDefault = this.defaultChoices().some((option) => option.code === this.assignDefault()) ? this.assignDefault() : "";
		if (chosenDefault === "" && this.defaultRequired()) {
			const reason = this.assignAll() ? "Choose their default trade unit. All trade units cannot be a default, and they have none yet." : "Choose their default trade unit: they have none yet.";
			this.assignmentFieldErrors.set({ defaultTradeUnit: [reason] });
			this.assignmentOutcome.set(mutationRefused(`Not assigned. ${reason}`));
			return;
		}
		const defaultTradeUnit = chosenDefault === "" ? null : chosenDefault;
		if ("email" in person) {
			this.runPendingAssignment(source.assign({
				userObjectId: null,
				userUpn: person.email,
				roleId: form.roleId,
				expiresAtUtc: form.expiresOn ? `${form.expiresOn}T00:00:00Z` : null,
				...all ? { allTradeUnits: true } : { tradeUnits: units },
				...defaultTradeUnit === null ? {} : { defaultTradeUnit }
			}), person.email);
			return;
		}
		this.runAssignment(source.assign({
			userObjectId: person.objectId,
			userUpn: person.upn,
			roleId: form.roleId,
			expiresAtUtc: form.expiresOn ? `${form.expiresOn}T00:00:00Z` : null,
			...all ? { allTradeUnits: true } : { tradeUnits: units },
			...defaultTradeUnit === null ? {} : { defaultTradeUnit }
		}), person.objectId, (answer) => answer.rows, (answer) => assignedSentence(person.label, answer, defaultTradeUnit), () => this.clearAssignmentForm());
	}
	assigneeChanged(state) {
		this.assigneeDismissed.set(null);
		if (state.status === "found") {
			this.assignment.userUpn = state.user.upn;
			this.upnFromDirectory.set(true);
		} else if (this.upnFromDirectory()) {
			this.assignment.userUpn = "";
			this.upnFromDirectory.set(false);
		}
		this.lookUpPerson(state.status === "objectId" ? state.objectId : state.status === "found" ? state.user.objectId : "");
	}
	setAssignAll(all) {
		this.assignAll.set(all);
		this.assignUnits.set([]);
		this.assignDefault.set("");
	}
	setAssignUnits(codes) {
		this.assignUnits.set(codes);
		if (!codes.includes(this.assignDefault())) this.assignDefault.set("");
	}
	setFilterUnit(codes) {
		this.filterUnit.set(codes.slice(-1));
	}
	lookUpPerson(value) {
		const source = this.source;
		const objectId = value.trim();
		if (source === null || !isEntraObjectId(objectId)) {
			this.person.set(null);
			return;
		}
		if (this.person()?.objectId.toLowerCase() === objectId.toLowerCase()) return;
		this.person.set({
			status: "loading",
			objectId
		});
		source.listAssignments({ userObjectId: objectId }).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			if (this.person()?.objectId !== objectId) return;
			this.person.set(answer.kind === "done" ? {
				status: "loaded",
				objectId,
				rows: answer.value.rows
			} : {
				status: "failed",
				objectId
			});
		});
	}
	setDefault(row) {
		const source = this.source;
		if (source !== null) this.runAssignment(source.setDefault(row.userObjectId, row.tradeUnit), row.userObjectId, (rows) => rows, () => `${row.tradeUnit} is now the default trade unit for ${row.userUpn}.`);
	}
	revoke(row) {
		const source = this.source;
		if (source === null) return;
		if (!isAllTradeUnits(row.tradeUnit)) {
			this.confirmRevoke(row, `${row.userUpn} will no longer hold "${row.roleDisplayName}" in ${row.tradeUnit}.` + (row.isDefault ? " It is their default trade unit, so the server moves the default." : ""));
			return;
		}
		source.listAssignments({ userObjectId: row.userObjectId }).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			const companion = (answer.kind === "done" ? answer.value.rows : this.assignments()).find((candidate) => candidate.userObjectId.toLowerCase() === row.userObjectId.toLowerCase() && candidate.roleId === row.roleId && candidate.isDefault && !isAllTradeUnits(candidate.tradeUnit));
			this.confirmRevoke(row, "This removes the role in every trade unit. Continue?" + (companion === void 0 ? "" : ` Their default trade unit's row, "${row.roleDisplayName}" in ${companion.tradeUnit}, stays.`));
		});
	}
	confirmRevoke(row, message) {
		const source = this.source;
		if (source === null) return;
		this.confirm({
			title: "Revoke this role?",
			message,
			confirmLabel: "Revoke",
			cancelLabel: "Keep it",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed) this.runAssignment(source.revoke(row), row.userObjectId, (rows) => rows, () => `"${row.roleDisplayName}" revoked from ${row.userUpn} in ` + (isAllTradeUnits(row.tradeUnit) ? "every trade unit." : `${row.tradeUnit}.`));
		});
	}
	runPendingAssignment(request, email) {
		this.runWrite(request, (answer) => {
			if (answer.outcome !== "pending") {
				this.showRowsOf(answer.rows[0]?.userObjectId ?? "", answer.rows);
				return assignedSentence(email, answer, null);
			}
			this.showPendingOf(email, answer.pending ?? []);
			return pendingSentence(email, answer);
		}, () => this.clearAssignmentForm());
	}
	revokePending(row) {
		const source = this.source;
		if (source?.revokePending === void 0) return;
		this.confirm({
			title: "Revoke this pending role?",
			message: `${row.email} has not signed in yet. They will not get "${row.roleDisplayName}" in ${tradeUnitLabel(row.tradeUnit)} when they do.`,
			confirmLabel: "Revoke",
			cancelLabel: "Keep it",
			destructive: true
		}).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((confirmed) => {
			if (confirmed && source.revokePending !== void 0) this.runWrite(source.revokePending(row), (rows) => {
				this.showPendingOf(row.email, rows);
				return `Pending "${row.roleDisplayName}" for ${row.email} in ${tradeUnitLabel(row.tradeUnit)} revoked.`;
			});
		});
	}
	showPendingOf(email, rows) {
		const address = email.toLowerCase();
		const kept = this.shownFilter?.tradeUnit ? rows.filter((row) => row.tradeUnit === this.shownFilter?.tradeUnit) : rows;
		this.pendingRows.set([...this.pendingRows().filter((row) => row.email.toLowerCase() !== address), ...kept]);
	}
	showRowsOf(userObjectId, rows) {
		const user = userObjectId.toLowerCase();
		const kept = this.shownFilter?.tradeUnit ? rows.filter((row) => row.tradeUnit === this.shownFilter?.tradeUnit) : rows;
		this.assignments.set([...this.assignments().filter((row) => row.userObjectId.toLowerCase() !== user), ...kept]);
		this.assignmentsState.set({ status: "loaded" });
	}
	clearAssignmentForm() {
		Object.assign(this.assignment, emptyAssignment());
		this.assignAll.set(false);
		this.assignUnits.set([]);
		this.assignDefault.set("");
		this.assignee.reset();
		this.person.set(null);
	}
	runWrite(request, onDone, after) {
		this.assignmentBusy.set(true);
		this.assignmentOutcome.set(null);
		this.assignmentFieldErrors.set({});
		request.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((answer) => {
			this.assignmentBusy.set(false);
			switch (answer.kind) {
				case "done": {
					const sentence = onDone(answer.value);
					after?.();
					this.assignmentOutcome.set(mutationSucceeded(sentence));
					break;
				}
				case "unavailable":
					this.assignmentOutcome.set(mutationFailed({ message: answer.reason }));
					break;
				case "refused":
					this.assignmentOutcome.set(mutationFailed(answer));
					break;
				case "failed":
					this.assignmentFieldErrors.set(answer.fieldErrors ?? {});
					this.assignmentOutcome.set(mutationFailed(answer));
			}
		});
	}
	runAssignment(request, userObjectId, rowsOf, success, onDone) {
		this.runWrite(request, (value) => {
			this.showRowsOf(userObjectId, rowsOf(value));
			return success(value);
		}, onDone);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RolesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: RolesPageComponent,
		isStandalone: true,
		selector: "cws-roles-page",
		inputs: { view: {
			classPropertyName: "view",
			publicName: "view",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <!-- #825: the Roles and permissions page of the Admin section, with its three tabs. -->\n  <cms-page-header\n    title=\"Roles and permissions\"\n    description=\"Permissions are grouped into named roles and held per trade unit, rather than ticked per person.\"\n  >\n    @if (!refused() && showRoles() && offered && rolesState().status === 'loaded' && roleEditor() === null) {\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"newRole()\">New role</button>\n    }\n  </cms-page-header>\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Roles and permissions views\" />\n  }\n\n  @if (refused()) {\n    <!--\n      #696, #825: role administration is Admin-only by design, and the navigation already leaves it out\n      for an account KNOWN not to hold Admin. This is the bookmark and the pasted URL: the reason, not\n      the panel. The server refuses the calls either way.\n    -->\n    <p class=\"scoular-alert scoular-alert-info\" role=\"note\" data-testid=\"roles-refused\">\n      Role administration needs the Admin role on this application.\n    </p>\n  } @else {\n\n  <!--\n    🔴 THE CONTROL. Not decoration, and not removable without the ruling it names.\n\n    The stopgap contract-writer policy has already been read TWICE as though this matrix were\n    built. Seven tidy checkboxes are the most convincing possible version of that mistake, so the\n    screen states what it is above the content -- every load, not once per session.\n  -->\n  <div\n    class=\"cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:dark:border-amber-800 cws:dark:bg-amber-950\"\n    role=\"note\"\n    data-testid=\"provisional-banner\"\n  >\n    <p class=\"cws:text-sm cws:font-semibold cws:text-amber-900 cws:dark:text-amber-200\">\n      Provisional — this permission set is not agreed yet\n    </p>\n    <!--\n      ⚠ No issue number in this sentence, deliberately, and the tracking reference lives in the\n      component's doc comment instead. `user-facing-copy.spec.ts` refuses internal identifiers in\n      user-visible copy and it is right to: an administrator cannot open an issue, so \"#138\" tells\n      them a decision exists and gives them no way to reach it. What they CAN act on is the shape\n      of the caveat, which is what this says.\n    -->\n    <p class=\"cws:mt-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\n      The seven permissions below are believed correct but are awaiting a business decision. That\n      decision may change which roles hold which permissions, or the granularity itself — so treat\n      anything configured here as a draft, and do not rely on it to describe who can do what today.\n      Enforcement across the application is not wired to these rows yet.\n    </p>\n  </div>\n\n  @if (showPermissions()) {\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n    <!-- \"permissions\", not \"seven\": the list is the server's now (#401), and #138 may change the count. -->\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">The provisional permissions</h3>\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n      Each gates the actions named beside it, for the trade unit the role is held on.\n    </p>\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n      <summary class=\"cws:cursor-pointer\">What is not gated</summary>\n      <p class=\"cws:mt-1\">\n        An administrator flag overrides all of them. Reading a contract is deliberately not gated: any\n        assigned user may read any contract, and the form goes read-only rather than invisible.\n      </p>\n    </details>\n\n    @if (isBuiltInCopy()) {\n      <!--\n        #401: the server's list could not be read, so the application's own copy is shown. Said, so\n        the copy is never mistaken for the server's answer.\n      -->\n      <p\n        class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\"\n        role=\"status\"\n        data-testid=\"catalog-origin\"\n      >\n        Shown from the application's built-in copy: the server's list could not be read just now.\n      </p>\n    }\n\n    <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\n      <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n        <tr>\n          <th class=\"cws:py-1\">Permission</th>\n          <th class=\"cws:py-1\">Stored as</th>\n          <th class=\"cws:py-1\">Gates</th>\n        </tr>\n      </thead>\n      <tbody data-testid=\"permission-rows\">\n        @for (permission of permissions(); track permission.key) {\n          <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n            <td class=\"cws:py-1 cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ permission.name }}</td>\n            <td class=\"cws:py-1 cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</td>\n            <td class=\"cws:py-1\">{{ permission.description }}</td>\n          </tr>\n        }\n      </tbody>\n    </table>\n  </div>\n  }\n\n  @if (showRoles()) {\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Roles</h3>\n    <!--\n      ⚠ 01 §5 rules the role list a workshop item that \"must not be invented here\", so the client\n      seeds none. An administrator creates them. Behind a disclosure since #825: it explains a short\n      list rather than changing what anyone does here.\n    -->\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n      <summary class=\"cws:cursor-pointer\">Why only the built-in Administrator?</summary>\n      <p class=\"cws:mt-1\" data-testid=\"catalog-empty\">\n        None are shipped by default beyond the built-in Administrator. The role names the business is\n        considering — Trader, Merchandiser Assistant, Approver, Accounting &amp; Control, CWS\n        Administrator — are a workshop decision, so they are not pre-created here. The schema is\n        ready: a role is a row, and adding one needs no deployment.\n      </p>\n    </details>\n\n    @if (!offered) {\n      <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"roles-not-offered\">\n        Role administration is not offered here.\n      </p>\n    } @else {\n      @if (storeOrigin() === 'InMemory') {\n        <!-- The server is running without its database: rows are lost on restart. -->\n        <p class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" role=\"status\" data-testid=\"roles-not-durable\">\n          These roles and assignments are held in memory on the server and are lost when it restarts.\n        </p>\n      }\n\n      @if (rolesProblem(); as problem) {\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"roles-problem\">\n          <div class=\"scoular-alert-description\">\n            {{ problem }}\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Try again</button>\n          </div>\n        </div>\n      }\n\n      <!--\n        #803: the last role write. A failure is the server's sentence as-is (a stale version, the\n        built-in role, a held or inherited role), with its reference and a Reload.\n      -->\n      <div class=\"cws:mt-2\" data-testid=\"role-notice\">\n        <cms-status-message [outcome]=\"roleOutcome()\" (dismissed)=\"roleOutcome.set(null)\">\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Reload</button>\n        </cms-status-message>\n      </div>\n\n      @if (roleEditor(); as editor) {\n        <form\n          class=\"cws:mt-3 cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\n          data-testid=\"role-editor\"\n          (ngSubmit)=\"saveRole()\"\n        >\n          <h4 class=\"cws:text-sm cws:font-semibold\">{{ editor.role === null ? 'New role' : 'Edit ' + editor.role.displayName }}</h4>\n          <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-2\">\n            <label class=\"cws:block cws:text-xs\">\n              <span class=\"cws:font-medium\">Name</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"name\"\n                [(ngModel)]=\"editor.name\"\n                [disabled]=\"editor.role !== null\"\n                aria-describedby=\"role-name-hint role-name-errors\"\n              />\n            </label>\n            <label class=\"cws:block cws:text-xs\">\n              <span class=\"cws:font-medium\">Display name</span>\n              <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"displayName\" [(ngModel)]=\"editor.displayName\" aria-describedby=\"role-displayName-errors\" />\n            </label>\n          </div>\n          <p id=\"role-name-hint\" class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            A PascalCase identifier, such as ContractWriter. It cannot be changed after the role is created.\n          </p>\n          @for (field of ['name', 'displayName', 'description', 'parentRoleId', 'permissionKeys']; track field) {\n            @if (roleFieldErrors()[field]; as reasons) {\n              <p [id]=\"'role-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700\" role=\"alert\">{{ reasons.join(' ') }}</p>\n            }\n          }\n          <label class=\"cws:block cws:text-xs\">\n            <span class=\"cws:font-medium\">Description</span>\n            <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"description\" [(ngModel)]=\"editor.description\" />\n          </label>\n          <label class=\"cws:block cws:text-xs\">\n            <span class=\"cws:font-medium\">Inherits from</span>\n            <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"parentRoleId\" [(ngModel)]=\"editor.parentRoleId\">\n              <option [ngValue]=\"null\">Nothing</option>\n              @for (choice of parentChoices(); track choice.id) {\n                <option [ngValue]=\"choice.id\">{{ choice.displayName }}</option>\n              }\n            </select>\n          </label>\n          <fieldset class=\"cws:text-xs\">\n            <legend class=\"cws:font-medium\">Permissions</legend>\n            <!-- The whole set goes back on save: the server replaces it, it does not merge. -->\n            @for (permission of permissions(); track permission.key) {\n              <label class=\"cws:mt-1 cws:flex cws:items-center cws:gap-2\">\n                <input\n                  type=\"checkbox\"\n                  [name]=\"'permission-' + permission.key\"\n                  [checked]=\"hasPermission(editor, permission.key)\"\n                  (change)=\"togglePermission(editor, permission.key, $any($event.target).checked)\"\n                />\n                <span>{{ permission.name }}</span>\n                <span class=\"cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</span>\n              </label>\n            }\n          </fieldset>\n          <div class=\"cws:flex cws:gap-2\">\n            <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"roleBusy()\">\n              {{ editor.role === null ? 'Create role' : 'Save role' }}\n            </button>\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelRole()\">Cancel</button>\n          </div>\n        </form>\n      }\n\n      @if (rolesState().status === 'loading') {\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading roles…</p>\n      }\n\n      @if (rolesState().status === 'loaded') {\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Role</th>\n              <th class=\"cws:py-1\">Permissions</th>\n              <th class=\"cws:py-1\">Inherits from</th>\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"role-rows\">\n            @for (role of roleRows(); track role.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:align-top cws:dark:border-slate-800\">\n                <td class=\"cws:py-1\">\n                  <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ role.displayName }}</span>\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ role.name }}</span>\n                  @if (role.isSystem) {\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Built in</span>\n                  }\n                </td>\n                <td class=\"cws:py-1\">\n                  @for (key of role.permissionKeys; track key; let last = $last) {\n                    {{ permissionName(key) }}{{ last ? '' : ', ' }}\n                  } @empty {\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">None</span>\n                  }\n                </td>\n                <td class=\"cws:py-1\">{{ roleName(role.parentRoleId) }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <!-- #825: Edit and Delete behind the row's menu. Delete still asks first. -->\n                  <cms-row-menu [row]=\"role\" [actions]=\"roleActions().get(role.id) ?? []\" [label]=\"'Actions for ' + role.displayName\" />\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n    }\n  </div>\n  }\n\n  @if (offered && showAssignments()) {\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Who holds which role</h3>\n      <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        A role is held per trade unit, and each user has exactly one default trade unit. Find a user by\n        their email address, which is looked up in the directory, or enter their Entra object id. The\n        object id is what is stored; the email address is kept for reading. An address the directory\n        cannot find yet is saved as pending, and takes effect the first time that person signs in.\n      </p>\n      @if (directoryMode() === 'Simulated') {\n        <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"directory-simulated\">\n          The directory is simulated on this server: only its sample users can be found by email address.\n        </p>\n      }\n\n      <form class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-3\" data-testid=\"assignment-filter\" (ngSubmit)=\"loadAssignments()\">\n        <!--\n          #1104: one trade unit from the location list, or \"All trade units\" for the rows that grant a\n          role in every trade unit. A second pick replaces the first; empty is any trade unit.\n        -->\n        <cws-admin-code-picker\n          class=\"cws:w-72 cws:text-xs\"\n          data-testid=\"filter-trade-unit\"\n          label=\"Trade unit\"\n          name=\"filterTradeUnit\"\n          [codes]=\"filterUnit()\"\n          [options]=\"filterOptions()\"\n          [unknownMessage]=\"notATradeUnitMessage\"\n          emptyMeaning=\"Any trade unit.\"\n          searchPlaceholder=\"Type a code, a name, or All\"\n          (codesChange)=\"setFilterUnit($event)\"\n        />\n        <div class=\"cws:text-xs\">\n          <label class=\"cws:block\">\n            <span class=\"cws:block cws:font-medium\">User email or object id</span>\n            <!-- #1107: an address is resolved through the directory, and the rows are read by its object id. -->\n            <input\n              class=\"scoular-form-input cws:mt-1 cws:w-96\"\n              name=\"filterPerson\"\n              autocomplete=\"off\"\n              [(ngModel)]=\"filter.person\"\n              (ngModelChange)=\"filterPerson.entered($event)\"\n              (blur)=\"filterPerson.committed(filter.person)\"\n              aria-describedby=\"filter-person-help filter-error\"\n            />\n          </label>\n          <p id=\"filter-person-help\" class=\"cws:mt-1 cws:w-96 cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"filter-person\">\n            @if (filterPerson.state(); as state) {\n              @switch (state.status) {\n                @case ('waiting') { <span role=\"status\">Looking them up…</span> }\n                @case ('looking') { <span role=\"status\">Looking them up…</span> }\n                @case ('found') {\n                  @if (state.status === 'found') {\n                    <span data-testid=\"filter-person-match\">\n                      <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ state.user.displayName || state.user.upn }}</span>\n                      · <span class=\"cws:font-mono\">{{ state.user.objectId }}</span>\n                    </span>\n                  }\n                }\n              }\n            }\n          </p>\n        </div>\n        <button type=\"submit\" class=\"scoular-btn scoular-btn-secondary\">Show assignments</button>\n      </form>\n      @if (filterError(); as error) {\n        <p id=\"filter-error\" class=\"cws:mt-1 cws:text-xs cws:text-red-700\" role=\"alert\">{{ error }}</p>\n      }\n      @if (filterOutcome(); as outcome) {\n        <!-- #1107: the filter's address could not be resolved. Nothing is read for it. -->\n        <div class=\"cws:mt-2\" data-testid=\"filter-lookup-notice\">\n          <cms-status-message [outcome]=\"outcome\" (dismissed)=\"filterDismissed.set(filterPerson.state())\" />\n        </div>\n      }\n\n      @if (assignmentsProblem(); as problem) {\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"assignments-problem\">\n          <div class=\"scoular-alert-description\">{{ problem }}</div>\n        </div>\n      }\n\n      <!-- #803: the last assignment write. A failure is the server's sentence as-is, with its reference. -->\n      <div class=\"cws:mt-2\" data-testid=\"assignment-notice\">\n        <cms-status-message [outcome]=\"assignmentOutcome()\" (dismissed)=\"assignmentOutcome.set(null)\" />\n      </div>\n\n      @if (assignmentsState().status === 'loading') {\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading assignments…</p>\n      }\n\n      @if (assignmentsState().status === 'loaded') {\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">User</th>\n              <th class=\"cws:py-1\">Role</th>\n              <th class=\"cws:py-1\">Trade unit</th>\n              <th class=\"cws:py-1\">Expires</th>\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"assignment-rows\">\n            @for (row of assignments(); track row.userObjectId + row.roleId + row.tradeUnit) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1\" data-testid=\"assignment-user\">\n                  <!-- #1107: the directory's name when it could say, then the UPN, then the stored object id. -->\n                  @if (row.userDisplayName) {\n                    <span class=\"cws:block cws:font-medium\" data-testid=\"assignment-user-name\">{{ row.userDisplayName }}</span>\n                  }\n                  <span class=\"cws:block\">{{ row.userUpn }}</span>\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ row.userObjectId }}</span>\n                </td>\n                <td class=\"cws:py-1\">{{ row.roleDisplayName }}</td>\n                <td class=\"cws:py-1\" data-testid=\"assignment-trade-unit\">\n                  {{ tradeUnitLabel(row.tradeUnit) }}\n                  @if (row.isDefault) {\n                    <span class=\"cws:ml-1 cws:font-semibold\" data-testid=\"default-marker\">Default</span>\n                  }\n                </td>\n                <td class=\"cws:py-1\">{{ row.expiresAtUtc ? (row.isExpired ? 'Expired ' : '') + row.expiresAtUtc.slice(0, 10) : 'Never' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <!-- #825: Make default and Revoke behind the row's menu. Revoke still asks first. -->\n                  <cms-row-menu\n                    [row]=\"row\"\n                    [actions]=\"assignmentActions().get(assignmentKey(row)) ?? []\"\n                    [label]=\"'Actions for ' + row.roleDisplayName + ' in ' + tradeUnitLabel(row.tradeUnit) + ' for ' + row.userUpn\"\n                  />\n                </td>\n              </tr>\n            } @empty {\n              <tr><td colspan=\"5\" class=\"cws:py-2 cws:text-slate-500 cws:dark:text-slate-400\">No assignments match.</td></tr>\n            }\n          </tbody>\n        </table>\n      }\n\n      @if (pendingRows().length > 0) {\n        <!--\n          #1244: roles given by email that wait for the person's first sign-in. Apart from the table above,\n          because they grant nothing yet. Each waits 30 days; giving it again renews it.\n        -->\n        <div class=\"cws:mt-4\" data-testid=\"pending-section\">\n          <h4 class=\"cws:text-sm cws:font-semibold\">Pending — not signed in yet</h4>\n          <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            These take effect the first time the person signs in with that address. Until then they grant\n            nothing, and a mistyped address simply never signs in: check the address, or revoke it.\n          </p>\n          <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n              <tr>\n                <th class=\"cws:py-1\">Email</th>\n                <th class=\"cws:py-1\">Role</th>\n                <th class=\"cws:py-1\">Trade unit</th>\n                <th class=\"cws:py-1\">Waiting until</th>\n                <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\n              </tr>\n            </thead>\n            <tbody data-testid=\"pending-rows\">\n              @for (row of pendingRows(); track pendingKey(row)) {\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                  <td class=\"cws:py-1\">\n                    <span class=\"cws:block\">{{ row.email }}</span>\n                    <span class=\"cws:block cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"pending-status\">Pending — not signed in yet</span>\n                  </td>\n                  <td class=\"cws:py-1\">{{ row.roleDisplayName }}</td>\n                  <td class=\"cws:py-1\">\n                    {{ tradeUnitLabel(row.tradeUnit) }}\n                    @if (row.isDefault) {\n                      <span class=\"cws:ml-1 cws:font-semibold\">Default if they have none</span>\n                    }\n                  </td>\n                  <td class=\"cws:py-1\" data-testid=\"pending-until\">\n                    {{ row.isExpired ? 'Expired ' + pendingUntil(row) + '. Assign it again to renew.' : pendingUntil(row) }}\n                  </td>\n                  <td class=\"cws:py-1 cws:text-right\">\n                    <cms-row-menu\n                      [row]=\"row\"\n                      [actions]=\"pendingActions().get(pendingKey(row)) ?? []\"\n                      [label]=\"'Actions for pending ' + row.roleDisplayName + ' in ' + tradeUnitLabel(row.tradeUnit) + ' for ' + row.email\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      }\n\n      <form\n        class=\"cws:mt-4 cws:grid cws:gap-3 cws:border-t cws:border-slate-100 cws:pt-3 cws:md:grid-cols-3 cws:dark:border-slate-800\"\n        data-testid=\"assignment-form\"\n        (ngSubmit)=\"assign()\"\n      >\n        <h4 class=\"cws:text-sm cws:font-semibold cws:md:col-span-3\">Assign a role</h4>\n        <!--\n          #1107: an email address or an object id. An address is looked up when typing pauses or the field\n          is left; the match is shown below it, and the assignment sends the match's object id and UPN.\n        -->\n        <div class=\"cws:text-xs\">\n          <label class=\"cws:block\">\n            <span class=\"cws:font-medium\">User email or object id</span>\n            <input\n              class=\"scoular-form-input cws:mt-1 cws:w-full\"\n              name=\"person\"\n              autocomplete=\"off\"\n              [(ngModel)]=\"assignment.person\"\n              (ngModelChange)=\"assignee.entered($event)\"\n              (blur)=\"assignee.committed(assignment.person)\"\n              aria-describedby=\"assign-person-help assign-userObjectId-errors\"\n            />\n          </label>\n          <p id=\"assign-person-help\" class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"assign-person\">\n            @if (assignee.state(); as state) {\n              @switch (state.status) {\n                @case ('waiting') { <span role=\"status\">Looking them up…</span> }\n                @case ('looking') { <span role=\"status\">Looking them up…</span> }\n                @case ('found') {\n                  @if (state.status === 'found') {\n                    <span data-testid=\"person-match\">\n                      Found: <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ state.user.displayName || state.user.upn }}</span>\n                      · <span class=\"cws:font-mono\">{{ state.user.objectId }}</span>\n                      <!-- #1244: found among the people who have signed in; the role is assigned now, not left pending. -->\n                      @if (state.user.source === 'knownUsers') {\n                        <span class=\"cws:block\" data-testid=\"person-known\">Has signed in to CWS, so the role is assigned now.</span>\n                      }\n                    </span>\n                  }\n                }\n                @case ('objectId') { An object id, assigned as entered. }\n                @default { An email address is looked up in the directory; an object id is used as entered. }\n              }\n            }\n          </p>\n        </div>\n        <div class=\"cws:text-xs\">\n          <label class=\"cws:block\">\n            <span class=\"cws:font-medium\">User email (for display)</span>\n            <!-- #1107: filled from the directory, and read-only, while a match is shown. -->\n            <input\n              class=\"scoular-form-input cws:mt-1 cws:w-full\"\n              name=\"userUpn\"\n              [(ngModel)]=\"assignment.userUpn\"\n              [readonly]=\"upnFromDirectory()\"\n              [attr.aria-describedby]=\"upnFromDirectory() ? 'assign-upn-help' : null\"\n            />\n          </label>\n          @if (upnFromDirectory()) {\n            <p id=\"assign-upn-help\" class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"upn-from-directory\">\n              From the directory. Change the person above to change it.\n            </p>\n          }\n        </div>\n        @if (assigneeOutcome(); as outcome) {\n          <!-- #1107: the directory has no answer for the address. Since #1244 it can still be assigned, as pending, and the notice says so. -->\n          <div class=\"cws:md:col-span-3\" data-testid=\"person-lookup-notice\">\n            <cms-status-message [outcome]=\"outcome\" (dismissed)=\"assigneeDismissed.set(assignee.state())\" />\n          </div>\n        }\n        <label class=\"cws:block cws:text-xs\">\n          <span class=\"cws:font-medium\">Role</span>\n          <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"roleId\" [(ngModel)]=\"assignment.roleId\">\n            <option value=\"\">Choose…</option>\n            @for (role of roleRows(); track role.id) {\n              <option [value]=\"role.id\">{{ role.displayName }}</option>\n            }\n          </select>\n        </label>\n        <label class=\"cws:block cws:text-xs\">\n          <span class=\"cws:font-medium\">Expires on (optional)</span>\n          <input type=\"date\" class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"expiresOn\" [(ngModel)]=\"assignment.expiresOn\" />\n        </label>\n\n        <!--\n          #1104: the trade units, picked from CTRM's location list (C-21's flat list, with typeahead and\n          Enter on the typed match, #840). Nothing is sent as free text: a code the list does not hold is\n          refused at the control. \"All trade units\" is one row on the server, not one per location.\n        -->\n        <div class=\"cws:space-y-2 cws:text-xs cws:md:col-span-3\" data-testid=\"assign-trade-units\">\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\n            <input\n              type=\"checkbox\"\n              name=\"allTradeUnits\"\n              [checked]=\"assignAll()\"\n              (change)=\"setAssignAll($any($event.target).checked)\"\n              aria-describedby=\"assign-all-help\"\n            />\n            <span class=\"cws:font-medium\">All trade units</span>\n          </label>\n          <div id=\"assign-all-help\" class=\"cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"assign-all-help\">\n            <p>\n              Grants the role's permissions in every trade unit, including trade units onboarded later.\n              It is stored once, not once per trade unit.\n            </p>\n            <ul class=\"cws:mt-1 cws:list-disc cws:pl-4\">\n              <li>\n                For a role that manages settings, it also covers form configuration that applies to every\n                trade unit (rows with no trade unit), which otherwise only an administrator can change.\n              </li>\n              <li>It does not onboard any trade unit, so changes there still wait until that trade unit is onboarded.</li>\n              <li>\n                A default trade unit is still chosen below. It is stored as this role in that one trade\n                unit, and it stays if the role in every trade unit is revoked.\n              </li>\n            </ul>\n          </div>\n\n          <cws-admin-code-picker\n            label=\"Trade units\"\n            name=\"tradeUnits\"\n            [codes]=\"assignUnits()\"\n            [options]=\"locationOptions()\"\n            [unknownMessage]=\"notATradeUnitMessage\"\n            [disabled]=\"assignAll()\"\n            [emptyMeaning]=\"assignAll() ? 'Every trade unit, as one assignment.' : 'Pick one or more trade units.'\"\n            [note]=\"locationNote()\"\n            describedBy=\"assign-tradeUnits-errors\"\n            [invalid]=\"!!assignmentFieldErrors()['tradeUnits'] || !!assignmentFieldErrors()['tradeUnit']\"\n            (codesChange)=\"setAssignUnits($event)\"\n          />\n\n          @if (anyChosen()) {\n            <!-- #1104: replaces \"Make this their default trade unit\". Required only when they have none yet. -->\n            <label class=\"cws:block\" data-testid=\"assign-default\">\n              <span class=\"cws:block cws:font-medium\">Default trade unit{{ defaultRequired() ? '' : ' (optional)' }}</span>\n              <select\n                class=\"scoular-form-select cws:mt-1 cws:w-full cws:md:w-96\"\n                name=\"defaultTradeUnit\"\n                [attr.aria-required]=\"defaultRequired()\"\n                aria-describedby=\"assign-default-help assign-defaultTradeUnit-errors\"\n                (change)=\"assignDefault.set($any($event.target).value)\"\n              >\n                <option value=\"\" [selected]=\"assignDefault() === ''\" [disabled]=\"defaultRequired()\">\n                  {{ defaultRequired() ? 'Choose their default trade unit' : 'Keep their default, ' + personDefault() }}\n                </option>\n                @for (choice of defaultChoices(); track choice.code) {\n                  <option [value]=\"choice.code\" [selected]=\"choice.code === assignDefault()\">{{ choice.label }}</option>\n                }\n              </select>\n              <span id=\"assign-default-help\" class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\">\n                @switch (person()?.status) {\n                  @case ('loaded') {\n                    {{ defaultRequired() ? 'They have no default trade unit yet, so one is required.' : 'Choose one only to move their default.' }}\n                  }\n                  @case ('failed') {\n                    Their current trade units could not be read, so a default is asked for.\n                  }\n                  @default {\n                    @if (assigneePending()) {\n                      They have not signed in yet. This becomes their default only if they have none when they do.\n                    } @else {\n                      Required for someone with no default trade unit yet. Enter their email address or object id to check.\n                    }\n                  }\n                }\n              </span>\n            </label>\n          }\n        </div>\n\n        @for (field of ['userObjectId', 'userUpn', 'roleId', 'tradeUnits', 'tradeUnit', 'allTradeUnits', 'defaultTradeUnit', 'expiresAtUtc']; track field) {\n          @if (assignmentFieldErrors()[field]; as reasons) {\n            <p [id]=\"'assign-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700 cws:md:col-span-3\" role=\"alert\" [attr.data-testid]=\"'assign-error-' + field\">{{ reasons.join(' ') }}</p>\n          }\n        }\n        <div class=\"cws:md:col-span-3\">\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"assignmentBusy()\">Assign role</button>\n        </div>\n      </form>\n    </div>\n  }\n  }\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: AdminCodePickerComponent,
				selector: "cws-admin-code-picker",
				inputs: [
					"label",
					"name",
					"codes",
					"options",
					"unknownMessage",
					"emptyMeaning",
					"note",
					"searchPlaceholder",
					"freePlaceholder",
					"describedBy",
					"invalid",
					"disabled"
				],
				outputs: ["codesChange"]
			},
			{
				kind: "component",
				type: AdminTabsComponent,
				selector: "cws-admin-tabs",
				inputs: ["views", "label"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: RowMenuComponent,
				selector: "cms-row-menu",
				inputs: [
					"row",
					"actions",
					"label"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RolesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-roles-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AdminCodePickerComponent,
				AdminTabsComponent,
				FormsModule,
				PageHeaderComponent,
				RowMenuComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-4\">\n  <!-- #825: the Roles and permissions page of the Admin section, with its three tabs. -->\n  <cms-page-header\n    title=\"Roles and permissions\"\n    description=\"Permissions are grouped into named roles and held per trade unit, rather than ticked per person.\"\n  >\n    @if (!refused() && showRoles() && offered && rolesState().status === 'loaded' && roleEditor() === null) {\n      <button cmsPageHeaderActions type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"newRole()\">New role</button>\n    }\n  </cms-page-header>\n\n  @if (routed()) {\n    <cws-admin-tabs [views]=\"area.views\" label=\"Roles and permissions views\" />\n  }\n\n  @if (refused()) {\n    <!--\n      #696, #825: role administration is Admin-only by design, and the navigation already leaves it out\n      for an account KNOWN not to hold Admin. This is the bookmark and the pasted URL: the reason, not\n      the panel. The server refuses the calls either way.\n    -->\n    <p class=\"scoular-alert scoular-alert-info\" role=\"note\" data-testid=\"roles-refused\">\n      Role administration needs the Admin role on this application.\n    </p>\n  } @else {\n\n  <!--\n    🔴 THE CONTROL. Not decoration, and not removable without the ruling it names.\n\n    The stopgap contract-writer policy has already been read TWICE as though this matrix were\n    built. Seven tidy checkboxes are the most convincing possible version of that mistake, so the\n    screen states what it is above the content -- every load, not once per session.\n  -->\n  <div\n    class=\"cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-4 cws:py-3 cws:dark:border-amber-800 cws:dark:bg-amber-950\"\n    role=\"note\"\n    data-testid=\"provisional-banner\"\n  >\n    <p class=\"cws:text-sm cws:font-semibold cws:text-amber-900 cws:dark:text-amber-200\">\n      Provisional — this permission set is not agreed yet\n    </p>\n    <!--\n      ⚠ No issue number in this sentence, deliberately, and the tracking reference lives in the\n      component's doc comment instead. `user-facing-copy.spec.ts` refuses internal identifiers in\n      user-visible copy and it is right to: an administrator cannot open an issue, so \"#138\" tells\n      them a decision exists and gives them no way to reach it. What they CAN act on is the shape\n      of the caveat, which is what this says.\n    -->\n    <p class=\"cws:mt-1 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\">\n      The seven permissions below are believed correct but are awaiting a business decision. That\n      decision may change which roles hold which permissions, or the granularity itself — so treat\n      anything configured here as a draft, and do not rely on it to describe who can do what today.\n      Enforcement across the application is not wired to these rows yet.\n    </p>\n  </div>\n\n  @if (showPermissions()) {\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n    <!-- \"permissions\", not \"seven\": the list is the server's now (#401), and #138 may change the count. -->\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">The provisional permissions</h3>\n    <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n      Each gates the actions named beside it, for the trade unit the role is held on.\n    </p>\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n      <summary class=\"cws:cursor-pointer\">What is not gated</summary>\n      <p class=\"cws:mt-1\">\n        An administrator flag overrides all of them. Reading a contract is deliberately not gated: any\n        assigned user may read any contract, and the form goes read-only rather than invisible.\n      </p>\n    </details>\n\n    @if (isBuiltInCopy()) {\n      <!--\n        #401: the server's list could not be read, so the application's own copy is shown. Said, so\n        the copy is never mistaken for the server's answer.\n      -->\n      <p\n        class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\"\n        role=\"status\"\n        data-testid=\"catalog-origin\"\n      >\n        Shown from the application's built-in copy: the server's list could not be read just now.\n      </p>\n    }\n\n    <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\n      <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n        <tr>\n          <th class=\"cws:py-1\">Permission</th>\n          <th class=\"cws:py-1\">Stored as</th>\n          <th class=\"cws:py-1\">Gates</th>\n        </tr>\n      </thead>\n      <tbody data-testid=\"permission-rows\">\n        @for (permission of permissions(); track permission.key) {\n          <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n            <td class=\"cws:py-1 cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ permission.name }}</td>\n            <td class=\"cws:py-1 cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</td>\n            <td class=\"cws:py-1\">{{ permission.description }}</td>\n          </tr>\n        }\n      </tbody>\n    </table>\n  </div>\n  }\n\n  @if (showRoles()) {\n  <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n    <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Roles</h3>\n    <!--\n      ⚠ 01 §5 rules the role list a workshop item that \"must not be invented here\", so the client\n      seeds none. An administrator creates them. Behind a disclosure since #825: it explains a short\n      list rather than changing what anyone does here.\n    -->\n    <details class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n      <summary class=\"cws:cursor-pointer\">Why only the built-in Administrator?</summary>\n      <p class=\"cws:mt-1\" data-testid=\"catalog-empty\">\n        None are shipped by default beyond the built-in Administrator. The role names the business is\n        considering — Trader, Merchandiser Assistant, Approver, Accounting &amp; Control, CWS\n        Administrator — are a workshop decision, so they are not pre-created here. The schema is\n        ready: a role is a row, and adding one needs no deployment.\n      </p>\n    </details>\n\n    @if (!offered) {\n      <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"roles-not-offered\">\n        Role administration is not offered here.\n      </p>\n    } @else {\n      @if (storeOrigin() === 'InMemory') {\n        <!-- The server is running without its database: rows are lost on restart. -->\n        <p class=\"cws:mt-2 cws:text-xs cws:text-amber-800 cws:dark:text-amber-300\" role=\"status\" data-testid=\"roles-not-durable\">\n          These roles and assignments are held in memory on the server and are lost when it restarts.\n        </p>\n      }\n\n      @if (rolesProblem(); as problem) {\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"roles-problem\">\n          <div class=\"scoular-alert-description\">\n            {{ problem }}\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Try again</button>\n          </div>\n        </div>\n      }\n\n      <!--\n        #803: the last role write. A failure is the server's sentence as-is (a stale version, the\n        built-in role, a held or inherited role), with its reference and a Reload.\n      -->\n      <div class=\"cws:mt-2\" data-testid=\"role-notice\">\n        <cms-status-message [outcome]=\"roleOutcome()\" (dismissed)=\"roleOutcome.set(null)\">\n          <button type=\"button\" class=\"scoular-btn scoular-btn-secondary cws:mt-2\" (click)=\"loadRoles()\">Reload</button>\n        </cms-status-message>\n      </div>\n\n      @if (roleEditor(); as editor) {\n        <form\n          class=\"cws:mt-3 cws:space-y-3 cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\"\n          data-testid=\"role-editor\"\n          (ngSubmit)=\"saveRole()\"\n        >\n          <h4 class=\"cws:text-sm cws:font-semibold\">{{ editor.role === null ? 'New role' : 'Edit ' + editor.role.displayName }}</h4>\n          <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-2\">\n            <label class=\"cws:block cws:text-xs\">\n              <span class=\"cws:font-medium\">Name</span>\n              <input\n                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                name=\"name\"\n                [(ngModel)]=\"editor.name\"\n                [disabled]=\"editor.role !== null\"\n                aria-describedby=\"role-name-hint role-name-errors\"\n              />\n            </label>\n            <label class=\"cws:block cws:text-xs\">\n              <span class=\"cws:font-medium\">Display name</span>\n              <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"displayName\" [(ngModel)]=\"editor.displayName\" aria-describedby=\"role-displayName-errors\" />\n            </label>\n          </div>\n          <p id=\"role-name-hint\" class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            A PascalCase identifier, such as ContractWriter. It cannot be changed after the role is created.\n          </p>\n          @for (field of ['name', 'displayName', 'description', 'parentRoleId', 'permissionKeys']; track field) {\n            @if (roleFieldErrors()[field]; as reasons) {\n              <p [id]=\"'role-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700\" role=\"alert\">{{ reasons.join(' ') }}</p>\n            }\n          }\n          <label class=\"cws:block cws:text-xs\">\n            <span class=\"cws:font-medium\">Description</span>\n            <input class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"description\" [(ngModel)]=\"editor.description\" />\n          </label>\n          <label class=\"cws:block cws:text-xs\">\n            <span class=\"cws:font-medium\">Inherits from</span>\n            <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"parentRoleId\" [(ngModel)]=\"editor.parentRoleId\">\n              <option [ngValue]=\"null\">Nothing</option>\n              @for (choice of parentChoices(); track choice.id) {\n                <option [ngValue]=\"choice.id\">{{ choice.displayName }}</option>\n              }\n            </select>\n          </label>\n          <fieldset class=\"cws:text-xs\">\n            <legend class=\"cws:font-medium\">Permissions</legend>\n            <!-- The whole set goes back on save: the server replaces it, it does not merge. -->\n            @for (permission of permissions(); track permission.key) {\n              <label class=\"cws:mt-1 cws:flex cws:items-center cws:gap-2\">\n                <input\n                  type=\"checkbox\"\n                  [name]=\"'permission-' + permission.key\"\n                  [checked]=\"hasPermission(editor, permission.key)\"\n                  (change)=\"togglePermission(editor, permission.key, $any($event.target).checked)\"\n                />\n                <span>{{ permission.name }}</span>\n                <span class=\"cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ permission.key }}</span>\n              </label>\n            }\n          </fieldset>\n          <div class=\"cws:flex cws:gap-2\">\n            <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"roleBusy()\">\n              {{ editor.role === null ? 'Create role' : 'Save role' }}\n            </button>\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelRole()\">Cancel</button>\n          </div>\n        </form>\n      }\n\n      @if (rolesState().status === 'loading') {\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading roles…</p>\n      }\n\n      @if (rolesState().status === 'loaded') {\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Role</th>\n              <th class=\"cws:py-1\">Permissions</th>\n              <th class=\"cws:py-1\">Inherits from</th>\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"role-rows\">\n            @for (role of roleRows(); track role.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:align-top cws:dark:border-slate-800\">\n                <td class=\"cws:py-1\">\n                  <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-slate-100\">{{ role.displayName }}</span>\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ role.name }}</span>\n                  @if (role.isSystem) {\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">Built in</span>\n                  }\n                </td>\n                <td class=\"cws:py-1\">\n                  @for (key of role.permissionKeys; track key; let last = $last) {\n                    {{ permissionName(key) }}{{ last ? '' : ', ' }}\n                  } @empty {\n                    <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">None</span>\n                  }\n                </td>\n                <td class=\"cws:py-1\">{{ roleName(role.parentRoleId) }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <!-- #825: Edit and Delete behind the row's menu. Delete still asks first. -->\n                  <cms-row-menu [row]=\"role\" [actions]=\"roleActions().get(role.id) ?? []\" [label]=\"'Actions for ' + role.displayName\" />\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n    }\n  </div>\n  }\n\n  @if (offered && showAssignments()) {\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Who holds which role</h3>\n      <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        A role is held per trade unit, and each user has exactly one default trade unit. Find a user by\n        their email address, which is looked up in the directory, or enter their Entra object id. The\n        object id is what is stored; the email address is kept for reading. An address the directory\n        cannot find yet is saved as pending, and takes effect the first time that person signs in.\n      </p>\n      @if (directoryMode() === 'Simulated') {\n        <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"directory-simulated\">\n          The directory is simulated on this server: only its sample users can be found by email address.\n        </p>\n      }\n\n      <form class=\"cws:mt-3 cws:flex cws:flex-wrap cws:items-end cws:gap-3\" data-testid=\"assignment-filter\" (ngSubmit)=\"loadAssignments()\">\n        <!--\n          #1104: one trade unit from the location list, or \"All trade units\" for the rows that grant a\n          role in every trade unit. A second pick replaces the first; empty is any trade unit.\n        -->\n        <cws-admin-code-picker\n          class=\"cws:w-72 cws:text-xs\"\n          data-testid=\"filter-trade-unit\"\n          label=\"Trade unit\"\n          name=\"filterTradeUnit\"\n          [codes]=\"filterUnit()\"\n          [options]=\"filterOptions()\"\n          [unknownMessage]=\"notATradeUnitMessage\"\n          emptyMeaning=\"Any trade unit.\"\n          searchPlaceholder=\"Type a code, a name, or All\"\n          (codesChange)=\"setFilterUnit($event)\"\n        />\n        <div class=\"cws:text-xs\">\n          <label class=\"cws:block\">\n            <span class=\"cws:block cws:font-medium\">User email or object id</span>\n            <!-- #1107: an address is resolved through the directory, and the rows are read by its object id. -->\n            <input\n              class=\"scoular-form-input cws:mt-1 cws:w-96\"\n              name=\"filterPerson\"\n              autocomplete=\"off\"\n              [(ngModel)]=\"filter.person\"\n              (ngModelChange)=\"filterPerson.entered($event)\"\n              (blur)=\"filterPerson.committed(filter.person)\"\n              aria-describedby=\"filter-person-help filter-error\"\n            />\n          </label>\n          <p id=\"filter-person-help\" class=\"cws:mt-1 cws:w-96 cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"filter-person\">\n            @if (filterPerson.state(); as state) {\n              @switch (state.status) {\n                @case ('waiting') { <span role=\"status\">Looking them up…</span> }\n                @case ('looking') { <span role=\"status\">Looking them up…</span> }\n                @case ('found') {\n                  @if (state.status === 'found') {\n                    <span data-testid=\"filter-person-match\">\n                      <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ state.user.displayName || state.user.upn }}</span>\n                      · <span class=\"cws:font-mono\">{{ state.user.objectId }}</span>\n                    </span>\n                  }\n                }\n              }\n            }\n          </p>\n        </div>\n        <button type=\"submit\" class=\"scoular-btn scoular-btn-secondary\">Show assignments</button>\n      </form>\n      @if (filterError(); as error) {\n        <p id=\"filter-error\" class=\"cws:mt-1 cws:text-xs cws:text-red-700\" role=\"alert\">{{ error }}</p>\n      }\n      @if (filterOutcome(); as outcome) {\n        <!-- #1107: the filter's address could not be resolved. Nothing is read for it. -->\n        <div class=\"cws:mt-2\" data-testid=\"filter-lookup-notice\">\n          <cms-status-message [outcome]=\"outcome\" (dismissed)=\"filterDismissed.set(filterPerson.state())\" />\n        </div>\n      }\n\n      @if (assignmentsProblem(); as problem) {\n        <div class=\"scoular-alert scoular-alert-error cws:mt-2\" role=\"alert\" data-testid=\"assignments-problem\">\n          <div class=\"scoular-alert-description\">{{ problem }}</div>\n        </div>\n      }\n\n      <!-- #803: the last assignment write. A failure is the server's sentence as-is, with its reference. -->\n      <div class=\"cws:mt-2\" data-testid=\"assignment-notice\">\n        <cms-status-message [outcome]=\"assignmentOutcome()\" (dismissed)=\"assignmentOutcome.set(null)\" />\n      </div>\n\n      @if (assignmentsState().status === 'loading') {\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">Loading assignments…</p>\n      }\n\n      @if (assignmentsState().status === 'loaded') {\n        <table class=\"cws:mt-3 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">User</th>\n              <th class=\"cws:py-1\">Role</th>\n              <th class=\"cws:py-1\">Trade unit</th>\n              <th class=\"cws:py-1\">Expires</th>\n              <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"assignment-rows\">\n            @for (row of assignments(); track row.userObjectId + row.roleId + row.tradeUnit) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1\" data-testid=\"assignment-user\">\n                  <!-- #1107: the directory's name when it could say, then the UPN, then the stored object id. -->\n                  @if (row.userDisplayName) {\n                    <span class=\"cws:block cws:font-medium\" data-testid=\"assignment-user-name\">{{ row.userDisplayName }}</span>\n                  }\n                  <span class=\"cws:block\">{{ row.userUpn }}</span>\n                  <span class=\"cws:block cws:font-mono cws:text-slate-500 cws:dark:text-slate-400\">{{ row.userObjectId }}</span>\n                </td>\n                <td class=\"cws:py-1\">{{ row.roleDisplayName }}</td>\n                <td class=\"cws:py-1\" data-testid=\"assignment-trade-unit\">\n                  {{ tradeUnitLabel(row.tradeUnit) }}\n                  @if (row.isDefault) {\n                    <span class=\"cws:ml-1 cws:font-semibold\" data-testid=\"default-marker\">Default</span>\n                  }\n                </td>\n                <td class=\"cws:py-1\">{{ row.expiresAtUtc ? (row.isExpired ? 'Expired ' : '') + row.expiresAtUtc.slice(0, 10) : 'Never' }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <!-- #825: Make default and Revoke behind the row's menu. Revoke still asks first. -->\n                  <cms-row-menu\n                    [row]=\"row\"\n                    [actions]=\"assignmentActions().get(assignmentKey(row)) ?? []\"\n                    [label]=\"'Actions for ' + row.roleDisplayName + ' in ' + tradeUnitLabel(row.tradeUnit) + ' for ' + row.userUpn\"\n                  />\n                </td>\n              </tr>\n            } @empty {\n              <tr><td colspan=\"5\" class=\"cws:py-2 cws:text-slate-500 cws:dark:text-slate-400\">No assignments match.</td></tr>\n            }\n          </tbody>\n        </table>\n      }\n\n      @if (pendingRows().length > 0) {\n        <!--\n          #1244: roles given by email that wait for the person's first sign-in. Apart from the table above,\n          because they grant nothing yet. Each waits 30 days; giving it again renews it.\n        -->\n        <div class=\"cws:mt-4\" data-testid=\"pending-section\">\n          <h4 class=\"cws:text-sm cws:font-semibold\">Pending — not signed in yet</h4>\n          <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            These take effect the first time the person signs in with that address. Until then they grant\n            nothing, and a mistyped address simply never signs in: check the address, or revoke it.\n          </p>\n          <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n            <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n              <tr>\n                <th class=\"cws:py-1\">Email</th>\n                <th class=\"cws:py-1\">Role</th>\n                <th class=\"cws:py-1\">Trade unit</th>\n                <th class=\"cws:py-1\">Waiting until</th>\n                <th class=\"cws:py-1\"><span class=\"cws:sr-only\">Actions</span></th>\n              </tr>\n            </thead>\n            <tbody data-testid=\"pending-rows\">\n              @for (row of pendingRows(); track pendingKey(row)) {\n                <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                  <td class=\"cws:py-1\">\n                    <span class=\"cws:block\">{{ row.email }}</span>\n                    <span class=\"cws:block cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"pending-status\">Pending — not signed in yet</span>\n                  </td>\n                  <td class=\"cws:py-1\">{{ row.roleDisplayName }}</td>\n                  <td class=\"cws:py-1\">\n                    {{ tradeUnitLabel(row.tradeUnit) }}\n                    @if (row.isDefault) {\n                      <span class=\"cws:ml-1 cws:font-semibold\">Default if they have none</span>\n                    }\n                  </td>\n                  <td class=\"cws:py-1\" data-testid=\"pending-until\">\n                    {{ row.isExpired ? 'Expired ' + pendingUntil(row) + '. Assign it again to renew.' : pendingUntil(row) }}\n                  </td>\n                  <td class=\"cws:py-1 cws:text-right\">\n                    <cms-row-menu\n                      [row]=\"row\"\n                      [actions]=\"pendingActions().get(pendingKey(row)) ?? []\"\n                      [label]=\"'Actions for pending ' + row.roleDisplayName + ' in ' + tradeUnitLabel(row.tradeUnit) + ' for ' + row.email\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      }\n\n      <form\n        class=\"cws:mt-4 cws:grid cws:gap-3 cws:border-t cws:border-slate-100 cws:pt-3 cws:md:grid-cols-3 cws:dark:border-slate-800\"\n        data-testid=\"assignment-form\"\n        (ngSubmit)=\"assign()\"\n      >\n        <h4 class=\"cws:text-sm cws:font-semibold cws:md:col-span-3\">Assign a role</h4>\n        <!--\n          #1107: an email address or an object id. An address is looked up when typing pauses or the field\n          is left; the match is shown below it, and the assignment sends the match's object id and UPN.\n        -->\n        <div class=\"cws:text-xs\">\n          <label class=\"cws:block\">\n            <span class=\"cws:font-medium\">User email or object id</span>\n            <input\n              class=\"scoular-form-input cws:mt-1 cws:w-full\"\n              name=\"person\"\n              autocomplete=\"off\"\n              [(ngModel)]=\"assignment.person\"\n              (ngModelChange)=\"assignee.entered($event)\"\n              (blur)=\"assignee.committed(assignment.person)\"\n              aria-describedby=\"assign-person-help assign-userObjectId-errors\"\n            />\n          </label>\n          <p id=\"assign-person-help\" class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"assign-person\">\n            @if (assignee.state(); as state) {\n              @switch (state.status) {\n                @case ('waiting') { <span role=\"status\">Looking them up…</span> }\n                @case ('looking') { <span role=\"status\">Looking them up…</span> }\n                @case ('found') {\n                  @if (state.status === 'found') {\n                    <span data-testid=\"person-match\">\n                      Found: <span class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ state.user.displayName || state.user.upn }}</span>\n                      · <span class=\"cws:font-mono\">{{ state.user.objectId }}</span>\n                      <!-- #1244: found among the people who have signed in; the role is assigned now, not left pending. -->\n                      @if (state.user.source === 'knownUsers') {\n                        <span class=\"cws:block\" data-testid=\"person-known\">Has signed in to CWS, so the role is assigned now.</span>\n                      }\n                    </span>\n                  }\n                }\n                @case ('objectId') { An object id, assigned as entered. }\n                @default { An email address is looked up in the directory; an object id is used as entered. }\n              }\n            }\n          </p>\n        </div>\n        <div class=\"cws:text-xs\">\n          <label class=\"cws:block\">\n            <span class=\"cws:font-medium\">User email (for display)</span>\n            <!-- #1107: filled from the directory, and read-only, while a match is shown. -->\n            <input\n              class=\"scoular-form-input cws:mt-1 cws:w-full\"\n              name=\"userUpn\"\n              [(ngModel)]=\"assignment.userUpn\"\n              [readonly]=\"upnFromDirectory()\"\n              [attr.aria-describedby]=\"upnFromDirectory() ? 'assign-upn-help' : null\"\n            />\n          </label>\n          @if (upnFromDirectory()) {\n            <p id=\"assign-upn-help\" class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"upn-from-directory\">\n              From the directory. Change the person above to change it.\n            </p>\n          }\n        </div>\n        @if (assigneeOutcome(); as outcome) {\n          <!-- #1107: the directory has no answer for the address. Since #1244 it can still be assigned, as pending, and the notice says so. -->\n          <div class=\"cws:md:col-span-3\" data-testid=\"person-lookup-notice\">\n            <cms-status-message [outcome]=\"outcome\" (dismissed)=\"assigneeDismissed.set(assignee.state())\" />\n          </div>\n        }\n        <label class=\"cws:block cws:text-xs\">\n          <span class=\"cws:font-medium\">Role</span>\n          <select class=\"scoular-form-select cws:mt-1 cws:w-full\" name=\"roleId\" [(ngModel)]=\"assignment.roleId\">\n            <option value=\"\">Choose…</option>\n            @for (role of roleRows(); track role.id) {\n              <option [value]=\"role.id\">{{ role.displayName }}</option>\n            }\n          </select>\n        </label>\n        <label class=\"cws:block cws:text-xs\">\n          <span class=\"cws:font-medium\">Expires on (optional)</span>\n          <input type=\"date\" class=\"scoular-form-input cws:mt-1 cws:w-full\" name=\"expiresOn\" [(ngModel)]=\"assignment.expiresOn\" />\n        </label>\n\n        <!--\n          #1104: the trade units, picked from CTRM's location list (C-21's flat list, with typeahead and\n          Enter on the typed match, #840). Nothing is sent as free text: a code the list does not hold is\n          refused at the control. \"All trade units\" is one row on the server, not one per location.\n        -->\n        <div class=\"cws:space-y-2 cws:text-xs cws:md:col-span-3\" data-testid=\"assign-trade-units\">\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\n            <input\n              type=\"checkbox\"\n              name=\"allTradeUnits\"\n              [checked]=\"assignAll()\"\n              (change)=\"setAssignAll($any($event.target).checked)\"\n              aria-describedby=\"assign-all-help\"\n            />\n            <span class=\"cws:font-medium\">All trade units</span>\n          </label>\n          <div id=\"assign-all-help\" class=\"cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"assign-all-help\">\n            <p>\n              Grants the role's permissions in every trade unit, including trade units onboarded later.\n              It is stored once, not once per trade unit.\n            </p>\n            <ul class=\"cws:mt-1 cws:list-disc cws:pl-4\">\n              <li>\n                For a role that manages settings, it also covers form configuration that applies to every\n                trade unit (rows with no trade unit), which otherwise only an administrator can change.\n              </li>\n              <li>It does not onboard any trade unit, so changes there still wait until that trade unit is onboarded.</li>\n              <li>\n                A default trade unit is still chosen below. It is stored as this role in that one trade\n                unit, and it stays if the role in every trade unit is revoked.\n              </li>\n            </ul>\n          </div>\n\n          <cws-admin-code-picker\n            label=\"Trade units\"\n            name=\"tradeUnits\"\n            [codes]=\"assignUnits()\"\n            [options]=\"locationOptions()\"\n            [unknownMessage]=\"notATradeUnitMessage\"\n            [disabled]=\"assignAll()\"\n            [emptyMeaning]=\"assignAll() ? 'Every trade unit, as one assignment.' : 'Pick one or more trade units.'\"\n            [note]=\"locationNote()\"\n            describedBy=\"assign-tradeUnits-errors\"\n            [invalid]=\"!!assignmentFieldErrors()['tradeUnits'] || !!assignmentFieldErrors()['tradeUnit']\"\n            (codesChange)=\"setAssignUnits($event)\"\n          />\n\n          @if (anyChosen()) {\n            <!-- #1104: replaces \"Make this their default trade unit\". Required only when they have none yet. -->\n            <label class=\"cws:block\" data-testid=\"assign-default\">\n              <span class=\"cws:block cws:font-medium\">Default trade unit{{ defaultRequired() ? '' : ' (optional)' }}</span>\n              <select\n                class=\"scoular-form-select cws:mt-1 cws:w-full cws:md:w-96\"\n                name=\"defaultTradeUnit\"\n                [attr.aria-required]=\"defaultRequired()\"\n                aria-describedby=\"assign-default-help assign-defaultTradeUnit-errors\"\n                (change)=\"assignDefault.set($any($event.target).value)\"\n              >\n                <option value=\"\" [selected]=\"assignDefault() === ''\" [disabled]=\"defaultRequired()\">\n                  {{ defaultRequired() ? 'Choose their default trade unit' : 'Keep their default, ' + personDefault() }}\n                </option>\n                @for (choice of defaultChoices(); track choice.code) {\n                  <option [value]=\"choice.code\" [selected]=\"choice.code === assignDefault()\">{{ choice.label }}</option>\n                }\n              </select>\n              <span id=\"assign-default-help\" class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\">\n                @switch (person()?.status) {\n                  @case ('loaded') {\n                    {{ defaultRequired() ? 'They have no default trade unit yet, so one is required.' : 'Choose one only to move their default.' }}\n                  }\n                  @case ('failed') {\n                    Their current trade units could not be read, so a default is asked for.\n                  }\n                  @default {\n                    @if (assigneePending()) {\n                      They have not signed in yet. This becomes their default only if they have none when they do.\n                    } @else {\n                      Required for someone with no default trade unit yet. Enter their email address or object id to check.\n                    }\n                  }\n                }\n              </span>\n            </label>\n          }\n        </div>\n\n        @for (field of ['userObjectId', 'userUpn', 'roleId', 'tradeUnits', 'tradeUnit', 'allTradeUnits', 'defaultTradeUnit', 'expiresAtUtc']; track field) {\n          @if (assignmentFieldErrors()[field]; as reasons) {\n            <p [id]=\"'assign-' + field + '-errors'\" class=\"cws:text-xs cws:text-red-700 cws:md:col-span-3\" role=\"alert\" [attr.data-testid]=\"'assign-error-' + field\">{{ reasons.join(' ') }}</p>\n          }\n        }\n        <div class=\"cws:md:col-span-3\">\n          <button type=\"submit\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"assignmentBusy()\">Assign role</button>\n        </div>\n      </form>\n    </div>\n  }\n  }\n</section>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { view: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "view",
			required: false
		}]
	}] }
});
function emptyAssignment() {
	return {
		person: "",
		userUpn: "",
		roleId: "",
		expiresOn: ""
	};
}
var TradeUnitValuesPageComponent = class TradeUnitValuesPageComponent {
	source = inject(TRADE_UNIT_VALUES_ADMIN_SOURCE, { optional: true });
	tradeUnit = signal("", ...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	values = signal([], ...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	months = signal([], ...ngDevMode ? [{ debugName: "months" }] : /* istanbul ignore next */ []);
	loaded = signal(false, ...ngDevMode ? [{ debugName: "loaded" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	error = signal(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	refusal = signal(null, ...ngDevMode ? [{ debugName: "refusal" }] : /* istanbul ignore next */ []);
	monthError = computed(() => this.refusal()?.fieldErrors["marketMonth"]?.join(" ") ?? null, ...ngDevMode ? [{ debugName: "monthError" }] : /* istanbul ignore next */ []);
	componentName = "";
	value = "";
	include = true;
	commodity = "";
	marketMonth = "";
	hasTradeUnit = computed(() => this.tradeUnit().trim() !== "", ...ngDevMode ? [{ debugName: "hasTradeUnit" }] : /* istanbul ignore next */ []);
	refuse(reason) {
		const refusal = adminRefusalOf(reason);
		this.refusal.set(refusal);
		this.error.set(refusal.message);
	}
	load() {
		const unit = this.tradeUnit().trim();
		const source = this.source;
		if (unit === "" || source === null) return;
		this.busy.set(true);
		this.error.set(null);
		this.refusal.set(null);
		Promise.all([firstValueFrom(source.values(unit)), firstValueFrom(source.marketMonths(unit))]).then(([values, months]) => {
			this.values.set(values);
			this.months.set(months);
			this.loaded.set(true);
		}).catch((reason) => this.refuse(reason)).finally(() => this.busy.set(false));
	}
	addValue() {
		const unit = this.tradeUnit().trim();
		if (unit === "" || this.componentName.trim() === "" || this.value.trim() === "") {
			this.outcome.set(mutationRefused("Trade unit, component and value are all required."));
			return;
		}
		const added = `${this.value.trim()} ${this.include ? "offered" : "withheld"} for ${this.componentName.trim()} at ${unit}.`;
		this.send(added, (source) => source.upsertValue({
			tradeUnit: unit,
			componentName: this.componentName.trim(),
			value: this.value.trim(),
			include: this.include
		})).then((ok) => {
			if (ok) {
				this.value = "";
				this.load();
			}
		});
	}
	toggleOffered(row) {
		const include = !row.include;
		const changed = `${row.value} ${include ? "offered" : "withheld"} for ${row.componentName} at ${row.tradeUnit}.`;
		this.send(changed, (source) => source.upsertValue({
			tradeUnit: row.tradeUnit,
			componentName: row.componentName,
			value: row.value,
			include
		})).then((ok) => ok && this.load());
	}
	removeValue(row) {
		this.send(`${row.value} removed from ${row.componentName}.`, (source) => source.removeValue(row)).then((ok) => ok && this.load());
	}
	addMonth() {
		const unit = this.tradeUnit().trim();
		if (unit === "" || this.commodity.trim() === "" || this.marketMonth.trim() === "") {
			this.outcome.set(mutationRefused("Trade unit, commodity and month are all required."));
			return;
		}
		const month = `Month ${this.marketMonth.trim()} added for ${this.commodity.trim()} at ${unit}.`;
		this.send(month, (source) => source.addMonth({
			tradeUnit: unit,
			commodity: this.commodity.trim(),
			marketMonth: this.marketMonth.trim()
		})).then((ok) => {
			if (ok) {
				this.marketMonth = "";
				this.load();
			}
		});
	}
	removeMonth(row) {
		this.send(`Month ${row.marketMonth} removed from ${row.commodity}.`, (source) => source.removeMonth(row)).then((ok) => ok && this.load());
	}
	async send(success, write) {
		const source = this.source;
		if (source === null) return false;
		this.busy.set(true);
		this.error.set(null);
		this.refusal.set(null);
		this.outcome.set(null);
		try {
			await firstValueFrom(write(source));
			this.outcome.set(mutationSucceeded(success));
			return true;
		} catch (reason) {
			const refusal = adminRefusalOf(reason);
			this.refusal.set(refusal);
			this.outcome.set(mutationFailed(refusal));
			return false;
		} finally {
			this.busy.set(false);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TradeUnitValuesPageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TradeUnitValuesPageComponent,
		isStandalone: true,
		selector: "cws-trade-unit-values-page",
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-4\">\n  <!-- #825: a page of its own in the Admin section; its primary action is Load, beside the picker. -->\n  <cms-page-header\n    title=\"Trade unit values\"\n    description=\"What a trade unit offers: the allowed values per field, and the market months per commodity, on its contracts.\"\n  />\n\n  <!--\n    Kept visible: it decides what an administrator tries here. CTRM refuses a value it did not offer,\n    so a month or code added here would fail on save with nothing on the screen able to explain why.\n  -->\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n    This can only take options away, never add them: CTRM refuses a value it did not offer.\n  </p>\n\n  <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\n    <!-- #696: the holder's own trade units, or every location for an Admin. No free text where a list exists. -->\n    <cws-admin-trade-unit-select\n      class=\"cws:w-72\"\n      label=\"Trade unit\"\n      [value]=\"tradeUnit()\"\n      (valueChange)=\"tradeUnit.set($event)\"\n    />\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-primary\"\n      [disabled]=\"!hasTradeUnit() || busy() || source === null\"\n      (click)=\"load()\"\n    >\n      {{ busy() ? 'Working…' : 'Load' }}\n    </button>\n  </div>\n\n  @if (source === null) {\n    <!-- A host that mounts adminRoutes() without TRADE_UNIT_VALUES_ADMIN_SOURCE: say so, rather than a Load that cannot work. -->\n    <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"values-unavailable\">\n      Trade unit values can't be managed here.\n    </p>\n  }\n\n  @if (error(); as message) {\n    <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\n      {{ message }}\n    </p>\n  }\n\n  <!-- #803: the last write's outcome, with the server's reference on a refusal. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\n\n  @if (loaded()) {\n    <!-- F8.2 -->\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Allowed values</h3>\n\n      @if (values().length === 0) {\n        <!--\n          🔴 The counter-intuitive state, said in words. An empty allow-list screen normally means\n          \"nothing is permitted\"; here it means the opposite, and an administrator who assumed the\n          usual reading would key in every value by hand to \"fix\" a trade unit that is already\n          working correctly.\n        -->\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"values-empty\">\n          Nothing configured, so every value CTRM offers is available on this trade unit. Adding a\n          row here starts an allow-list and everything not on it stops being offered.\n        </p>\n      } @else {\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Field</th>\n              <th class=\"cws:py-1\">Value</th>\n              <th class=\"cws:py-1\">Offered</th>\n              <th class=\"cws:py-1\">Last changed</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"values-rows\">\n            @for (row of values(); track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1\">{{ row.componentName }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.value }}</td>\n                <td class=\"cws:py-1\">{{ row.include ? 'Yes' : 'No — excluded' }}</td>\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\n                <td class=\"cws:py-1\">\n                  <div class=\"cws:flex cws:justify-end cws:gap-2\">\n                    <!-- #399: change a row's Offered flag in place; the server's PUT updates it on the row's own key. -->\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"(row.include ? 'Withhold ' : 'Offer ') + row.value + ' for ' + row.componentName\"\n                      [disabled]=\"busy()\"\n                      (click)=\"toggleOffered(row)\"\n                    >\n                      {{ row.include ? 'Withhold' : 'Offer' }}\n                    </button>\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Remove ' + row.value + ' from ' + row.componentName\"\n                      [disabled]=\"busy()\"\n                      (click)=\"removeValue(row)\"\n                    >\n                      Remove\n                    </button>\n                  </div>\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n\n      <cms-form-row class=\"cws:mt-3\">\n        <label cmsFormRowField=\"Field\">\n          <input class=\"scoular-form-input cws:w-56\" [(ngModel)]=\"componentName\" name=\"componentName\"\n                 placeholder=\"e.g. PriceTypeCode\" />\n        </label>\n        <label cmsFormRowField=\"Value\">\n          <input class=\"scoular-form-input cws:w-32\" [(ngModel)]=\"value\" name=\"value\" placeholder=\"e.g. P\" />\n        </label>\n        <label cmsFormRowActions class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\n          <input type=\"checkbox\" [(ngModel)]=\"include\" name=\"include\" />\n          Offered\n        </label>\n        <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addValue()\">\n          Add value\n        </button>\n      </cms-form-row>\n    </div>\n\n    <!-- F8.5 -->\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Market months</h3>\n\n      @if (months().length === 0) {\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"months-empty\">\n          Nothing configured, so every month CTRM returns for a commodity is offered. Adding a row\n          narrows the list to what is listed here for that commodity.\n        </p>\n      } @else {\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Commodity</th>\n              <th class=\"cws:py-1\">Month</th>\n              <th class=\"cws:py-1\">Last changed</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"months-rows\">\n            @for (row of months(); track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.commodity }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.marketMonth }}</td>\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <button\n                    type=\"button\"\n                    class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                    [attr.aria-label]=\"'Remove ' + row.marketMonth + ' from ' + row.commodity\"\n                    [disabled]=\"busy()\"\n                    (click)=\"removeMonth(row)\"\n                  >\n                    Remove\n                  </button>\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n\n      <cms-form-row class=\"cws:mt-3\">\n        <label cmsFormRowField=\"Commodity\">\n          <input class=\"scoular-form-input cws:w-32\" [(ngModel)]=\"commodity\" name=\"commodity\" placeholder=\"e.g. YC\" />\n        </label>\n        <!--\n          CTRM's months are one letter with no year (#695): Z is December. The field and its reason are\n          one column, so the reason sits under the input rather than pushing the button along the row.\n        -->\n        <div class=\"cws:flex cws:flex-col cws:gap-1\">\n          <label cmsFormRowField=\"Month\">\n            <input\n              class=\"scoular-form-input cws:w-32\"\n              [(ngModel)]=\"marketMonth\"\n              name=\"marketMonth\"\n              placeholder=\"e.g. Z\"\n              [attr.aria-invalid]=\"monthError() !== null ? 'true' : null\"\n              [attr.aria-describedby]=\"monthError() !== null ? 'tu-month-error' : null\"\n            />\n          </label>\n          @if (monthError(); as reason) {\n            <!-- #696: the server names what CTRM does offer, so the reason sits by the field, outside its label. -->\n            <span id=\"tu-month-error\" class=\"cws:block cws:max-w-md cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              {{ reason }}\n            </span>\n          }\n        </div>\n        <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addMonth()\">\n          Add month\n        </button>\n      </cms-form-row>\n    </div>\n  }\n</section>\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: AdminTradeUnitSelectComponent,
				selector: "cws-admin-trade-unit-select",
				inputs: [
					"label",
					"value",
					"allowAny",
					"everyLocation"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: FormRowComponent,
				selector: "cms-form-row"
			},
			{
				kind: "component",
				type: FormRowFieldComponent,
				selector: "label[cmsFormRowField]",
				inputs: ["cmsFormRowField"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TradeUnitValuesPageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-trade-unit-values-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				AdminTradeUnitSelectComponent,
				FormRowComponent,
				FormRowFieldComponent,
				PageHeaderComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-4\">\n  <!-- #825: a page of its own in the Admin section; its primary action is Load, beside the picker. -->\n  <cms-page-header\n    title=\"Trade unit values\"\n    description=\"What a trade unit offers: the allowed values per field, and the market months per commodity, on its contracts.\"\n  />\n\n  <!--\n    Kept visible: it decides what an administrator tries here. CTRM refuses a value it did not offer,\n    so a month or code added here would fail on save with nothing on the screen able to explain why.\n  -->\n  <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\">\n    This can only take options away, never add them: CTRM refuses a value it did not offer.\n  </p>\n\n  <div class=\"cws:flex cws:flex-wrap cws:items-end cws:gap-3\">\n    <!-- #696: the holder's own trade units, or every location for an Admin. No free text where a list exists. -->\n    <cws-admin-trade-unit-select\n      class=\"cws:w-72\"\n      label=\"Trade unit\"\n      [value]=\"tradeUnit()\"\n      (valueChange)=\"tradeUnit.set($event)\"\n    />\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-primary\"\n      [disabled]=\"!hasTradeUnit() || busy() || source === null\"\n      (click)=\"load()\"\n    >\n      {{ busy() ? 'Working…' : 'Load' }}\n    </button>\n  </div>\n\n  @if (source === null) {\n    <!-- A host that mounts adminRoutes() without TRADE_UNIT_VALUES_ADMIN_SOURCE: say so, rather than a Load that cannot work. -->\n    <p class=\"cws:text-sm cws:text-slate-600 cws:dark:text-slate-300\" data-testid=\"values-unavailable\">\n      Trade unit values can't be managed here.\n    </p>\n  }\n\n  @if (error(); as message) {\n    <p class=\"cws:rounded cws:bg-rose-50 cws:px-3 cws:py-2 cws:text-xs cws:text-rose-800 cws:dark:bg-rose-950 cws:dark:text-rose-300\" role=\"alert\">\n      {{ message }}\n    </p>\n  }\n\n  <!-- #803: the last write's outcome, with the server's reference on a refusal. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\n\n  @if (loaded()) {\n    <!-- F8.2 -->\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Allowed values</h3>\n\n      @if (values().length === 0) {\n        <!--\n          🔴 The counter-intuitive state, said in words. An empty allow-list screen normally means\n          \"nothing is permitted\"; here it means the opposite, and an administrator who assumed the\n          usual reading would key in every value by hand to \"fix\" a trade unit that is already\n          working correctly.\n        -->\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"values-empty\">\n          Nothing configured, so every value CTRM offers is available on this trade unit. Adding a\n          row here starts an allow-list and everything not on it stops being offered.\n        </p>\n      } @else {\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Field</th>\n              <th class=\"cws:py-1\">Value</th>\n              <th class=\"cws:py-1\">Offered</th>\n              <th class=\"cws:py-1\">Last changed</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"values-rows\">\n            @for (row of values(); track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1\">{{ row.componentName }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.value }}</td>\n                <td class=\"cws:py-1\">{{ row.include ? 'Yes' : 'No — excluded' }}</td>\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\n                <td class=\"cws:py-1\">\n                  <div class=\"cws:flex cws:justify-end cws:gap-2\">\n                    <!-- #399: change a row's Offered flag in place; the server's PUT updates it on the row's own key. -->\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"(row.include ? 'Withhold ' : 'Offer ') + row.value + ' for ' + row.componentName\"\n                      [disabled]=\"busy()\"\n                      (click)=\"toggleOffered(row)\"\n                    >\n                      {{ row.include ? 'Withhold' : 'Offer' }}\n                    </button>\n                    <button\n                      type=\"button\"\n                      class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                      [attr.aria-label]=\"'Remove ' + row.value + ' from ' + row.componentName\"\n                      [disabled]=\"busy()\"\n                      (click)=\"removeValue(row)\"\n                    >\n                      Remove\n                    </button>\n                  </div>\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n\n      <cms-form-row class=\"cws:mt-3\">\n        <label cmsFormRowField=\"Field\">\n          <input class=\"scoular-form-input cws:w-56\" [(ngModel)]=\"componentName\" name=\"componentName\"\n                 placeholder=\"e.g. PriceTypeCode\" />\n        </label>\n        <label cmsFormRowField=\"Value\">\n          <input class=\"scoular-form-input cws:w-32\" [(ngModel)]=\"value\" name=\"value\" placeholder=\"e.g. P\" />\n        </label>\n        <label cmsFormRowActions class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\n          <input type=\"checkbox\" [(ngModel)]=\"include\" name=\"include\" />\n          Offered\n        </label>\n        <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addValue()\">\n          Add value\n        </button>\n      </cms-form-row>\n    </div>\n\n    <!-- F8.5 -->\n    <div class=\"cws:rounded cws:border cws:border-slate-200 cws:p-3 cws:dark:border-slate-700\">\n      <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Market months</h3>\n\n      @if (months().length === 0) {\n        <p class=\"cws:mt-2 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" data-testid=\"months-empty\">\n          Nothing configured, so every month CTRM returns for a commodity is offered. Adding a row\n          narrows the list to what is listed here for that commodity.\n        </p>\n      } @else {\n        <table class=\"cws:mt-2 cws:w-full cws:text-left cws:text-xs\">\n          <thead class=\"cws:text-slate-500 cws:dark:text-slate-400\">\n            <tr>\n              <th class=\"cws:py-1\">Commodity</th>\n              <th class=\"cws:py-1\">Month</th>\n              <th class=\"cws:py-1\">Last changed</th>\n              <th class=\"cws:py-1\"></th>\n            </tr>\n          </thead>\n          <tbody data-testid=\"months-rows\">\n            @for (row of months(); track row.id) {\n              <tr class=\"cws:border-t cws:border-slate-100 cws:dark:border-slate-800\">\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.commodity }}</td>\n                <td class=\"cws:py-1 cws:font-mono\">{{ row.marketMonth }}</td>\n                <td class=\"cws:py-1 cws:text-slate-500 cws:dark:text-slate-400\">{{ row.modifiedByUpn }}</td>\n                <td class=\"cws:py-1 cws:text-right\">\n                  <button\n                    type=\"button\"\n                    class=\"scoular-btn scoular-btn-secondary scoular-btn-sm\"\n                    [attr.aria-label]=\"'Remove ' + row.marketMonth + ' from ' + row.commodity\"\n                    [disabled]=\"busy()\"\n                    (click)=\"removeMonth(row)\"\n                  >\n                    Remove\n                  </button>\n                </td>\n              </tr>\n            }\n          </tbody>\n        </table>\n      }\n\n      <cms-form-row class=\"cws:mt-3\">\n        <label cmsFormRowField=\"Commodity\">\n          <input class=\"scoular-form-input cws:w-32\" [(ngModel)]=\"commodity\" name=\"commodity\" placeholder=\"e.g. YC\" />\n        </label>\n        <!--\n          CTRM's months are one letter with no year (#695): Z is December. The field and its reason are\n          one column, so the reason sits under the input rather than pushing the button along the row.\n        -->\n        <div class=\"cws:flex cws:flex-col cws:gap-1\">\n          <label cmsFormRowField=\"Month\">\n            <input\n              class=\"scoular-form-input cws:w-32\"\n              [(ngModel)]=\"marketMonth\"\n              name=\"marketMonth\"\n              placeholder=\"e.g. Z\"\n              [attr.aria-invalid]=\"monthError() !== null ? 'true' : null\"\n              [attr.aria-describedby]=\"monthError() !== null ? 'tu-month-error' : null\"\n            />\n          </label>\n          @if (monthError(); as reason) {\n            <!-- #696: the server names what CTRM does offer, so the reason sits by the field, outside its label. -->\n            <span id=\"tu-month-error\" class=\"cws:block cws:max-w-md cws:text-xs cws:text-rose-700 cws:dark:text-rose-300\">\n              {{ reason }}\n            </span>\n          }\n        </div>\n        <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" [disabled]=\"busy()\" (click)=\"addMonth()\">\n          Add month\n        </button>\n      </cms-form-row>\n    </div>\n  }\n</section>\n"
		}]
	}]
});
function adminRoutes() {
	return [
		{
			path: "",
			pathMatch: "full",
			title: "Admin",
			component: AdminOverviewComponent
		},
		{
			path: "form-configuration",
			title: "Form configuration",
			children: [
				{
					path: "",
					component: FormBuilderPageComponent,
					canDeactivate: [formBuilderLeaveGuard]
				},
				{
					path: "rows",
					component: FormConfigAdminPageComponent,
					data: { view: "rows" }
				},
				{
					path: "preview",
					component: FormConfigAdminPageComponent,
					data: { view: "preview" }
				}
			]
		},
		{
			path: "trade-unit-values",
			title: "Trade unit values",
			component: TradeUnitValuesPageComponent
		},
		{
			path: "contract-templates",
			title: "Contract templates",
			children: [
				{
					path: "",
					component: ContractTemplatesPageComponent
				},
				{
					path: "new",
					component: ContractTemplateEditorComponent
				},
				{
					path: ":id",
					component: ContractTemplateEditorComponent
				}
			]
		},
		{
			path: "addendums",
			title: "Addendums",
			children: [{
				path: "",
				component: AddendumTemplatesPageComponent,
				data: { view: "templates" }
			}, {
				path: "types",
				component: AddendumTemplatesPageComponent,
				data: { view: "types" }
			}]
		},
		{
			path: "basis-locations",
			title: "Basis locations",
			children: [
				{
					path: "",
					component: BasisLocationsPageComponent,
					data: { view: "terms" }
				},
				{
					path: "places",
					component: BasisLocationsPageComponent,
					data: { view: "places" }
				},
				{
					path: "regions",
					component: BasisLocationsPageComponent,
					data: { view: "regions" }
				},
				{
					path: "trade-units",
					component: BasisLocationsPageComponent,
					data: { view: "trade-units" }
				},
				{
					path: "hta",
					component: BasisLocationsPageComponent,
					data: { view: "hta" }
				}
			]
		},
		{
			path: "roles",
			title: "Roles and permissions",
			children: [
				{
					path: "",
					component: RolesPageComponent,
					data: { view: "roles" }
				},
				{
					path: "assignments",
					component: RolesPageComponent,
					data: { view: "assignments" }
				},
				{
					path: "permissions",
					component: RolesPageComponent,
					data: { view: "permissions" }
				}
			]
		},
		{
			path: "**",
			redirectTo: ""
		}
	];
}
function widthLabelOf(componentName, halfWidth) {
	if (CONTRACT_LAYOUT_FIXED_WIDTH_FIELDS[componentName] === true) return "Fixed width";
	if (halfWidth === void 0) return CONTRACT_LAYOUT_HALF_FIELDS[componentName] === true ? "Automatic (compact)" : "Automatic width";
	return halfWidth ? "Compact" : "Normal";
}
function previewPresentation(componentName, registryLabel, presentation) {
	const layoutNote = CONTRACT_LAYOUT_FIELD_NOTES[componentName] ?? null;
	return {
		half: presentation?.halfWidth ?? CONTRACT_LAYOUT_HALF_FIELDS[componentName] === true,
		widthLabel: widthLabelOf(componentName, presentation?.halfWidth),
		labelHidden: presentation?.labelHidden ?? CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS[componentName] === true,
		label: presentation?.label ?? registryLabel,
		description: presentation?.tooltipEnabled === false ? null : presentation?.tooltipDescription ?? layoutNote
	};
}
function withSetPresentationOnly(fields) {
	const out = {};
	for (const [name, behaviour] of Object.entries(fields)) {
		const { presentation, ...flags } = behaviour;
		const kept = Object.fromEntries(Object.entries(presentation ?? {}).filter(([, value]) => value !== void 0 && value !== null && !(typeof value === "string" && value.trim() === "")));
		out[name] = Object.keys(kept).length === 0 ? flags : {
			...flags,
			presentation: kept
		};
	}
	return out;
}
const COLLECTION_COPIES = {
	excludeFromCopy: false,
	excludeFromTemplateCopy: false
};
function collectionLabel(name) {
	const words = name.replace(/_/g, " ").trim();
	return words === "" ? name : words.charAt(0).toUpperCase() + words.slice(1);
}
function changedCollections(offered, current, baseline) {
	if (offered === void 0) return null;
	const changed = {};
	for (const [name, collection] of Object.entries(offered)) {
		const now = {
			...COLLECTION_COPIES,
			...current[name]
		};
		const was = {
			...COLLECTION_COPIES,
			...baseline[name]
		};
		if (collection.copyable && (now.excludeFromCopy !== was.excludeFromCopy || now.excludeFromTemplateCopy !== was.excludeFromTemplateCopy)) changed[name] = {
			excludeFromCopy: now.excludeFromCopy,
			excludeFromTemplateCopy: now.excludeFromTemplateCopy
		};
	}
	return Object.keys(changed).length === 0 ? null : changed;
}
const REMARK_TYPE_DEFAULT = {
	visible: true,
	required: false
};
function changedRemarkTypes(offered, current, baseline) {
	if (offered === void 0) return null;
	const changed = {};
	for (const { code } of offered) {
		const now = {
			...REMARK_TYPE_DEFAULT,
			...current[code]
		};
		const was = {
			...REMARK_TYPE_DEFAULT,
			...baseline[code]
		};
		if (now.visible !== was.visible || now.required !== was.required) changed[code] = {
			visible: now.visible,
			required: now.required
		};
	}
	return Object.keys(changed).length === 0 ? null : changed;
}
function isIsoDate(value) {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
	if (match === null) return false;
	const [year, month, day] = [
		Number(match[1]),
		Number(match[2]),
		Number(match[3])
	];
	const date = new Date(Date.UTC(year, month - 1, day));
	return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}
function localIsoToday() {
	const now = /* @__PURE__ */ new Date();
	return [
		now.getFullYear(),
		String(now.getMonth() + 1).padStart(2, "0"),
		String(now.getDate()).padStart(2, "0")
	].join("-");
}
var FormConfigEditorComponent = class FormConfigEditorComponent {
	source = inject(FORM_CONFIG_ADMIN_SOURCE);
	editing = input(null, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	saved = output();
	cancelled = output();
	contractTypeClass = "";
	locationCode = "";
	commodityCode = "";
	effectiveFrom = "";
	effectiveError = signal(null, ...ngDevMode ? [{ debugName: "effectiveError" }] : /* istanbul ignore next */ []);
	autoCalculationMode = "None";
	pendingContractsEnabled = false;
	everyTradeUnitPending = signal(false, ...ngDevMode ? [{ debugName: "everyTradeUnitPending" }] : /* istanbul ignore next */ []);
	setLocation(code) {
		this.locationCode = code;
		this.everyTradeUnitPending.set(false);
	}
	asksBeforeEveryTradeUnit() {
		if (this.locationCode.trim() !== "") return false;
		const editing = this.editing();
		return editing === null || editing.locationCode !== null;
	}
	homeGridColumns = signal(null, ...ngDevMode ? [{ debugName: "homeGridColumns" }] : /* istanbul ignore next */ []);
	columnsNotKept = signal(false, ...ngDevMode ? [{ debugName: "columnsNotKept" }] : /* istanbul ignore next */ []);
	lockedColumnKeys = [PINNED_GRID_COLUMN];
	allColumnKeys = CONTRACT_GRID_COLUMNS.map((column) => column.key);
	homeGridColumnFields = computed(() => {
		const headers = new Map(CONTRACT_GRID_COLUMNS.map((column) => [column.key, column.header]));
		return gridColumnChoices(this.allColumnKeys, null, this.homeGridColumns()).map((choice) => ({
			key: choice.key,
			header: headers.get(choice.key) ?? choice.key,
			included: choice.shown
		}));
	}, ...ngDevMode ? [{ debugName: "homeGridColumnFields" }] : /* istanbul ignore next */ []);
	onHomeGridColumnsChange(fields) {
		this.homeGridColumns.set(userGridColumnKeys(fields.map((f) => ({
			key: f.key,
			shown: f.included
		}))));
	}
	resetHomeGridColumns() {
		this.homeGridColumns.set(null);
	}
	collectionFlags = signal({}, ...ngDevMode ? [{ debugName: "collectionFlags" }] : /* istanbul ignore next */ []);
	collectionBaseline = signal({}, ...ngDevMode ? [{ debugName: "collectionBaseline" }] : /* istanbul ignore next */ []);
	collectionRows = computed(() => {
		const offered = this.registry()?.collections;
		if (offered === void 0) return null;
		const flags = this.collectionFlags();
		return Object.entries(offered).map(([name, collection]) => ({
			name,
			label: collectionLabel(name),
			copyable: collection.copyable,
			excludeFromCopy: flags[name]?.excludeFromCopy ?? false
		}));
	}, ...ngDevMode ? [{ debugName: "collectionRows" }] : /* istanbul ignore next */ []);
	setCollectionExcluded(name, excludeFromCopy) {
		if (this.registry()?.collections?.[name]?.copyable !== true) return;
		this.collectionFlags.update((all) => ({
			...all,
			[name]: {
				...COLLECTION_COPIES,
				...all[name],
				excludeFromCopy
			}
		}));
	}
	startCollectionsFrom(collections) {
		this.collectionFlags.set(collections ?? {});
		this.collectionBaseline.set(collections ?? {});
	}
	remarkFlags = signal({}, ...ngDevMode ? [{ debugName: "remarkFlags" }] : /* istanbul ignore next */ []);
	remarkBaseline = signal({}, ...ngDevMode ? [{ debugName: "remarkBaseline" }] : /* istanbul ignore next */ []);
	remarkRows = computed(() => {
		const offered = this.registry()?.remarkTypes;
		if (offered === void 0) return null;
		const flags = this.remarkFlags();
		return offered.map((type) => ({
			code: type.code,
			label: type.label,
			...REMARK_TYPE_DEFAULT,
			...flags[type.code]
		}));
	}, ...ngDevMode ? [{ debugName: "remarkRows" }] : /* istanbul ignore next */ []);
	setRemarkFlag(code, flag, value) {
		this.remarkFlags.update((all) => {
			const now = {
				...REMARK_TYPE_DEFAULT,
				...all[code]
			};
			if (flag === "visible" && !value && now.required) return all;
			const next = flag === "required" ? {
				...now,
				required: value,
				visible: value || now.visible
			} : {
				...now,
				visible: value
			};
			return {
				...all,
				[code]: next
			};
		});
	}
	startRemarksFrom(remarkTypes) {
		this.remarkFlags.set(remarkTypes ?? {});
		this.remarkBaseline.set(remarkTypes ?? {});
	}
	seedTradeUnit = "";
	seededFrom = signal(null, ...ngDevMode ? [{ debugName: "seededFrom" }] : /* istanbul ignore next */ []);
	seedNotice = signal(null, ...ngDevMode ? [{ debugName: "seedNotice" }] : /* istanbul ignore next */ []);
	baseSections = signal(null, ...ngDevMode ? [{ debugName: "baseSections" }] : /* istanbul ignore next */ []);
	startingPoint = 0;
	saving = signal(false, ...ngDevMode ? [{ debugName: "saving" }] : /* istanbul ignore next */ []);
	outcome = signal(null, ...ngDevMode ? [{ debugName: "outcome" }] : /* istanbul ignore next */ []);
	filter = signal("", ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	registry = signal(null, ...ngDevMode ? [{ debugName: "registry" }] : /* istanbul ignore next */ []);
	behaviours = signal({}, ...ngDevMode ? [{ debugName: "behaviours" }] : /* istanbul ignore next */ []);
	constraintSource = inject(CONSTRAINT_SOURCE, { optional: true });
	constraintDocument = toSignal(this.constraintSource === null ? of(null) : this.constraintSource.document().pipe(map((snapshot) => snapshot.document), catchError(() => of(null))), { initialValue: null });
	ctrmRequired = computed(() => ctrmRequiredComponents(this.registry(), this.constraintDocument()), ...ngDevMode ? [{ debugName: "ctrmRequired" }] : /* istanbul ignore next */ []);
	ctrmRequiredReason = CTRM_REQUIRED_REASON;
	lockedBehaviours = computed(() => {
		const required = this.ctrmRequired();
		const all = this.behaviours();
		if (required.size === 0) return all;
		const next = { ...all };
		for (const name of required) if (next[name] !== void 0) next[name] = {
			...next[name],
			visible: true,
			required: true
		};
		return next;
	}, ...ngDevMode ? [{ debugName: "lockedBehaviours" }] : /* istanbul ignore next */ []);
	tabs = signal([], ...ngDevMode ? [{ debugName: "tabs" }] : /* istanbul ignore next */ []);
	ready = computed(() => this.registry() !== null, ...ngDevMode ? [{ debugName: "ready" }] : /* istanbul ignore next */ []);
	isNew = computed(() => this.editing() === null, ...ngDevMode ? [{ debugName: "isNew" }] : /* istanbul ignore next */ []);
	ngOnInit() {
		this.source.registry().subscribe((state) => {
			if (state.status === "loaded") {
				this.registry.set(state.value);
				this.seed();
			} else if (state.status === "error") this.outcome.set(mutationFailed(state.error));
		});
	}
	editableTabs = computed(() => withSectionTabs(this.tabs(), this.editableSections(), this.registry()?.tabs ?? []), ...ngDevMode ? [{ debugName: "editableTabs" }] : /* istanbul ignore next */ []);
	sectionVisibility = signal({}, ...ngDevMode ? [{ debugName: "sectionVisibility" }] : /* istanbul ignore next */ []);
	toggleSection(sectionId, visible) {
		this.sectionVisibility.set({
			...this.sectionVisibility(),
			[sectionId]: visible
		});
	}
	sectionVisible(sectionId) {
		return this.sectionVisibility()[sectionId] ?? this.registry()?.sections.find((section) => section.id === sectionId)?.visible ?? true;
	}
	editableSections = computed(() => {
		const registry = this.registry();
		const visibility = this.sectionVisibility();
		const registrySections = registry?.sections ?? [];
		const base = this.baseSections();
		return (base === null ? registrySections : [...base, ...registrySections.filter((section) => !base.some((known) => known.id === section.id))]).map((section) => ({
			...section,
			visible: visibility[section.id] ?? section.visible
		}));
	}, ...ngDevMode ? [{ debugName: "editableSections" }] : /* istanbul ignore next */ []);
	emptyTabWarning = computed(() => {
		const emptied = emptiedTabs(this.editableTabs(), this.editableSections());
		return emptied.length === 0 ? null : emptied.map((tab) => tab.label).join(", ");
	}, ...ngDevMode ? [{ debugName: "emptyTabWarning" }] : /* istanbul ignore next */ []);
	sections = computed(() => {
		const registry = this.registry();
		if (registry === null) return [];
		const behaviours = this.lockedBehaviours();
		const needle = this.filter().trim().toLowerCase();
		return [...this.editableSections()].sort((left, right) => left.order - right.order).map((section) => ({
			id: section.id,
			label: section.label,
			tab: section.tab,
			fields: Object.entries(registry.fields).filter(([, field]) => field.section === section.id).filter(([componentName, field]) => needle === "" || componentName.toLowerCase().includes(needle) || field.label.toLowerCase().includes(needle) || field.ctrmField.toLowerCase().includes(needle)).map(([componentName, field]) => this.toEditorField(componentName, field, behaviours[componentName])).sort((left, right) => left.behaviour.order - right.behaviour.order)
		})).filter((section) => section.fields.length > 0);
	}, ...ngDevMode ? [{ debugName: "sections" }] : /* istanbul ignore next */ []);
	reorderBlockedReason = computed(() => this.filter().trim() === "" ? null : "Clear the search to reorder — moving a field while the list is filtered would place it against rows you cannot see.", ...ngDevMode ? [{ debugName: "reorderBlockedReason" }] : /* istanbul ignore next */ []);
	moveField(sectionId, componentName, delta) {
		const ordered = this.orderedIn(sectionId);
		if (ordered === null) return;
		const from = ordered.indexOf(componentName);
		const to = from + delta;
		if (from === -1 || to < 0 || to >= ordered.length) return;
		ordered.splice(to, 0, ...ordered.splice(from, 1));
		this.applyOrder(ordered, componentName);
	}
	placeField(sectionId, componentName, onto) {
		const ordered = this.orderedIn(sectionId);
		if (ordered === null) return;
		const from = ordered.indexOf(componentName);
		const to = ordered.indexOf(onto);
		if (from === -1 || to === -1 || from === to) return;
		ordered.splice(to, 0, ...ordered.splice(from, 1));
		this.applyOrder(ordered, componentName);
	}
	orderedIn(sectionId) {
		const registry = this.registry();
		if (this.reorderBlockedReason() !== null || registry === null) return null;
		const behaviours = this.behaviours();
		return Object.entries(registry.fields).filter(([, field]) => field.section === sectionId).map(([name, field]) => ({
			name,
			order: behaviours[name]?.order ?? field.order
		})).sort((left, right) => left.order - right.order).map((entry) => entry.name);
	}
	applyOrder(ordered, moved) {
		const behaviours = { ...this.behaviours() };
		ordered.forEach((name, index) => {
			const existing = behaviours[name];
			if (existing !== void 0) behaviours[name] = {
				...existing,
				order: index + 1
			};
		});
		this.behaviours.set(behaviours);
		this.movedField.set(moved);
	}
	draggingField = signal(null, ...ngDevMode ? [{ debugName: "draggingField" }] : /* istanbul ignore next */ []);
	dropField = signal(null, ...ngDevMode ? [{ debugName: "dropField" }] : /* istanbul ignore next */ []);
	dragSection = null;
	gesture = new PointerDragGesture({
		handleSelector: "[data-drag-field]",
		source: (handle) => rowRef(handle, "data-drag-field", "data-drag-section"),
		target: (x, y) => {
			const row = elementUnder(x, y, "[data-drop-field]");
			return row === null ? null : rowRef(row, "data-drop-field", "data-drop-section");
		},
		started: (source) => {
			this.dragSection = source.section;
			this.draggingField.set(source.field);
		},
		over: (target) => this.dropField.set(target !== null && target.section === this.dragSection && target.field !== this.draggingField() ? target.field : null),
		ended: () => {
			this.dragSection = null;
			this.draggingField.set(null);
			this.dropField.set(null);
		},
		dropped: (source, target) => {
			if (source.section === target.section) this.placeField(source.section, source.field, target.field);
		}
	});
	constructor() {
		inject(DestroyRef).onDestroy(() => this.gesture.cancel());
	}
	onRowPointerDown(event) {
		this.gesture.press(event);
	}
	movedField = signal(null, ...ngDevMode ? [{ debugName: "movedField" }] : /* istanbul ignore next */ []);
	requiredCount = computed(() => Object.values(this.lockedBehaviours()).filter((behaviour) => behaviour.required).length, ...ngDevMode ? [{ debugName: "requiredCount" }] : /* istanbul ignore next */ []);
	hiddenCount = computed(() => Object.values(this.lockedBehaviours()).filter((behaviour) => !behaviour.visible).length, ...ngDevMode ? [{ debugName: "hiddenCount" }] : /* istanbul ignore next */ []);
	setRequired(componentName, required) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				required,
				visible: required ? true : all[componentName].visible
			}
		}));
	}
	setVisible(componentName, visible) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				visible
			}
		}));
	}
	setFlag(componentName, flag, value) {
		this.behaviours.update((all) => ({
			...all,
			[componentName]: {
				...all[componentName],
				[flag]: value
			}
		}));
	}
	openPresentation = signal(null, ...ngDevMode ? [{ debugName: "openPresentation" }] : /* istanbul ignore next */ []);
	togglePresentation(componentName) {
		this.openPresentation.update((open) => open === componentName ? null : componentName);
	}
	previewOf(field) {
		return previewPresentation(field.componentName, field.label, field.behaviour.presentation);
	}
	layoutDefault(componentName) {
		return {
			half: CONTRACT_LAYOUT_HALF_FIELDS[componentName] === true,
			labelHidden: CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS[componentName] === true,
			note: CONTRACT_LAYOUT_FIELD_NOTES[componentName] ?? null
		};
	}
	setPresentation(componentName, key, value) {
		this.behaviours.update((all) => {
			const current = { ...all[componentName].presentation ?? {} };
			if (value === void 0 || typeof value === "string" && value.trim() === "") delete current[key];
			else current[key] = value;
			const { presentation: _old, ...flags } = all[componentName];
			return {
				...all,
				[componentName]: Object.keys(current).length === 0 ? flags : {
					...flags,
					presentation: current
				}
			};
		});
	}
	setPresentationFlag(componentName, key, choice) {
		this.setPresentation(componentName, key, choice === "" ? void 0 : choice === "true");
	}
	flagChoice(value) {
		return value === void 0 ? "" : String(value);
	}
	resetPresentation(componentName) {
		this.behaviours.update((all) => {
			const { presentation: _old, ...flags } = all[componentName];
			return {
				...all,
				[componentName]: flags
			};
		});
	}
	setTabVisible(id, visible) {
		this.tabs.set(this.editableTabs().map((tab) => tab.id === id ? {
			...tab,
			visible
		} : tab));
	}
	setTabLabel(id, label) {
		this.tabs.set(this.editableTabs().map((tab) => tab.id === id ? {
			...tab,
			label
		} : tab));
	}
	copyFromCurrent() {
		const ticket = ++this.startingPoint;
		this.seededFrom.set(null);
		this.baseSections.set(null);
		this.seedNotice.set(null);
		this.source.preview({
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			...this.locationCode !== "" ? { locationCode: this.locationCode } : {},
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {}
		}).subscribe((state) => {
			if (state.status !== "loaded" || ticket !== this.startingPoint) return;
			const next = { ...this.behaviours() };
			for (const section of state.value.config.sections) for (const field of section.fields) {
				const current = next[field.componentName];
				if (current !== void 0) next[field.componentName] = {
					...current,
					visible: field.behaviour.visible,
					required: field.behaviour.required,
					readOnly: field.behaviour.readOnly
				};
			}
			this.behaviours.set(next);
			this.tabs.set(state.value.config.tabs);
			this.baseSections.set(sectionsOf$1(state.value.config.sections, this.registry()?.sections ?? []));
			this.sectionVisibility.set(visibilityOf(this.baseSections() ?? []));
			this.autoCalculationMode = state.value.tradeUnitAttributes.autoCalculationMode;
			this.pendingContractsEnabled = state.value.tradeUnitAttributes.pendingContractsEnabled;
			this.homeGridColumns.set(state.value.tradeUnitAttributes.homeGridColumns ?? null);
			if (this.editing() === null) {
				this.startCollectionsFrom(state.value.config.collections);
				this.startRemarksFrom(state.value.config.remarkTypes);
			} else {
				this.collectionFlags.set(state.value.config.collections ?? {});
				this.remarkFlags.set(state.value.config.remarkTypes ?? {});
			}
		});
	}
	save(everyTradeUnitConfirmed = false) {
		const registry = this.registry();
		const effectiveFrom = this.effectiveFrom;
		if (effectiveFrom === null || !isIsoDate(effectiveFrom)) {
			this.effectiveError.set("An effective date is required — it is what decides when this row starts applying.");
			this.outcome.set(mutationRefused("The configuration was not saved. The reason is beside the effective date."));
			return;
		}
		if (registry === null) return;
		if (!everyTradeUnitConfirmed && this.asksBeforeEveryTradeUnit()) {
			this.everyTradeUnitPending.set(true);
			return;
		}
		this.everyTradeUnitPending.set(false);
		this.saving.set(true);
		this.outcome.set(null);
		const collections = changedCollections(registry.collections, this.collectionFlags(), this.collectionBaseline());
		const remarkTypes = changedRemarkTypes(registry.remarkTypes, this.remarkFlags(), this.remarkBaseline());
		const document = {
			schemaVersion: registry.schemaVersion,
			tabs: this.editableTabs(),
			sections: this.editableSections(),
			fields: withSetPresentationOnly(this.lockedBehaviours()),
			attributes: {
				autoCalculationMode: this.autoCalculationMode,
				pendingContractsEnabled: this.pendingContractsEnabled,
				...this.homeGridColumns() !== null ? { homeGridColumns: this.homeGridColumns() } : {}
			},
			...collections !== null ? { collections } : {},
			...remarkTypes !== null ? { remarkTypes } : {}
		};
		const submission = {
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			...this.locationCode !== "" ? { locationCode: this.locationCode } : {},
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {},
			effectiveFrom,
			config: document
		};
		const editing = this.editing();
		const seed = this.seededFrom();
		if (editing !== null) {
			this.submit(this.source.update(editing.id, editing.rowVersion, submission));
			return;
		}
		if (seed === null) {
			this.submit(this.source.create(submission));
			return;
		}
		this.source.get(seed.id).subscribe((state) => {
			if (state.status === "error") {
				this.saving.set(false);
				this.outcome.set(mutationFailed({
					message: `The configuration you seeded from (trade unit ${seed.tradeUnit}) could not be re-read, so this row was not created. Try again, or seed again.`,
					correlationId: state.error.correlationId
				}));
				return;
			}
			if (state.status !== "loaded") return;
			if (state.value.rowVersion !== seed.rowVersion || !state.value.isActive) {
				this.saving.set(false);
				this.outcome.set(mutationRefused(`The configuration for trade unit ${seed.tradeUnit} changed after you seeded from it, so this row was not created — it would have copied a version that no longer exists. Seed again to start from its current settings.`));
				return;
			}
			this.submit(this.source.create(submission));
		});
	}
	submit(request) {
		request.subscribe((state) => {
			if (state.status === "loaded") {
				this.saving.set(false);
				if (this.homeGridColumns() !== null && state.value.config?.attributes?.homeGridColumns === void 0) {
					this.columnsNotKept.set(true);
					return;
				}
				this.saved.emit();
			} else if (state.status === "error") {
				this.saving.set(false);
				this.outcome.set(mutationFailed({
					message: `The configuration was not saved.\n${state.error.message}`,
					correlationId: state.error.correlationId
				}));
			}
		});
	}
	seedFromTradeUnit() {
		const tradeUnit = this.seedTradeUnit.trim();
		this.seedNotice.set(null);
		if (tradeUnit === "") {
			this.seedNotice.set("Enter the trade unit to seed from.");
			return;
		}
		if (tradeUnit === this.locationCode.trim()) {
			this.seedNotice.set(`This row already applies to trade unit ${tradeUnit}. Pick a different trade unit to copy from.`);
			return;
		}
		const ticket = ++this.startingPoint;
		this.source.preview({
			...this.contractTypeClass !== "" ? { contractTypeClass: this.contractTypeClass } : {},
			locationCode: tradeUnit,
			...this.commodityCode !== "" ? { commodityCode: this.commodityCode } : {}
		}).subscribe((resolved) => {
			if (ticket !== this.startingPoint) return;
			if (resolved.status === "error") {
				this.seedNotice.set(`Trade unit ${tradeUnit} could not be resolved: ${resolved.error.message}`);
				return;
			}
			if (resolved.status !== "loaded") return;
			const id = resolved.value.provenance.configId;
			if (id === null) {
				this.seedNotice.set(`Trade unit ${tradeUnit} has no configuration of its own — it resolves to the built-in default, which is where a new row already starts. Nothing was copied.`);
				return;
			}
			this.source.get(id).subscribe((row) => {
				if (ticket !== this.startingPoint) return;
				if (row.status === "error") this.seedNotice.set(`Trade unit ${tradeUnit}'s configuration could not be read: ${row.error.message}`);
				else if (row.status === "loaded") this.adoptSeed(tradeUnit, row.value);
			});
		});
	}
	adoptSeed(tradeUnit, detail) {
		const registry = this.registry();
		if (registry === null) return;
		this.tabs.set(detail.config.tabs);
		this.baseSections.set(detail.config.sections);
		this.sectionVisibility.set(visibilityOf(detail.config.sections));
		this.behaviours.set(this.completeFrom(registry, detail.config.fields));
		this.autoCalculationMode = detail.config.attributes.autoCalculationMode;
		this.pendingContractsEnabled = detail.config.attributes.pendingContractsEnabled;
		this.homeGridColumns.set(detail.config.attributes.homeGridColumns ?? null);
		this.collectionFlags.set(detail.config.collections ?? {});
		this.remarkFlags.set(detail.config.remarkTypes ?? {});
		this.seededFrom.set({
			id: detail.id,
			rowVersion: detail.rowVersion,
			tradeUnit,
			dimensionKey: detail.dimensionKey,
			version: detail.version
		});
	}
	cancel() {
		this.cancelled.emit();
	}
	seed() {
		const registry = this.registry();
		if (registry === null) return;
		const editing = this.editing();
		if (editing !== null) {
			this.contractTypeClass = editing.contractTypeClass ?? "";
			this.locationCode = editing.locationCode ?? "";
			this.commodityCode = editing.commodityCode ?? "";
			this.effectiveFrom = editing.effectiveFrom;
			this.autoCalculationMode = editing.config.attributes.autoCalculationMode;
			this.pendingContractsEnabled = editing.config.attributes.pendingContractsEnabled;
			this.homeGridColumns.set(editing.config.attributes.homeGridColumns ?? null);
			this.tabs.set(editing.config.tabs);
			this.baseSections.set(editing.config.sections);
			this.sectionVisibility.set(visibilityOf(editing.config.sections));
			this.startCollectionsFrom(editing.config.collections);
			this.startRemarksFrom(editing.config.remarkTypes);
			this.behaviours.set(this.completeFrom(registry, editing.config.fields));
			return;
		}
		this.effectiveFrom = localIsoToday();
		this.behaviours.set(this.completeFrom(registry, {}));
		this.tabs.set(registry.tabs);
		this.sectionVisibility.set(visibilityOf(registry.sections));
		this.copyFromCurrent();
	}
	completeFrom(registry, stored) {
		const all = {};
		const names = [...Object.keys(stored).filter((name) => name in registry.fields), ...Object.keys(registry.fields).filter((name) => !(name in stored))];
		for (const componentName of names) {
			const field = registry.fields[componentName];
			all[componentName] = stored[componentName] ?? {
				visible: true,
				required: field.systemRequired,
				readOnly: field.readOnly,
				borderWarning: false,
				excludeFromCopy: false,
				excludeFromTemplateCopy: false,
				section: field.section,
				order: field.order
			};
		}
		return all;
	}
	toEditorField(componentName, field, behaviour) {
		return {
			componentName,
			label: field.label,
			ctrmField: field.ctrmField,
			ctrmReadOnly: field.readOnly,
			locked: !field.configurable,
			ctrmRequired: this.ctrmRequired().has(componentName),
			behaviour: behaviour ?? {
				visible: true,
				required: field.systemRequired,
				readOnly: field.readOnly,
				borderWarning: false,
				excludeFromCopy: false,
				excludeFromTemplateCopy: false,
				section: field.section,
				order: field.order
			}
		};
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormConfigEditorComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormConfigEditorComponent,
		isStandalone: true,
		selector: "cms-form-config-editor",
		inputs: { editing: {
			classPropertyName: "editing",
			publicName: "editing",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		outputs: {
			saved: "saved",
			cancelled: "cancelled"
		},
		providers: [AdminScope],
		ngImport: i0,
		template: "<section class=\"cws:space-y-5\">\n  <header class=\"cws:space-y-1\">\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n      {{ isNew() ? 'New configuration' : 'Edit configuration' }}\n    </h3>\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n      A row applies to every contract matching the dimensions below — leave one empty to mean\n      <em>any</em>. The most specific matching row wins <strong>whole</strong>: nothing is merged\n      from less specific rows, which is why this form starts from whatever currently applies.\n    </p>\n  </header>\n\n  <!-- #803: why the editor cannot go on, with the server's reference or why there is none. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\n\n  @if (!ready()) {\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">\n      Loading the field registry…\n    </p>\n  } @else {\n    <!-- Dimensions -->\n    <div class=\"scoular-card cws:space-y-4 cws:p-4\">\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\n        <label class=\"cws:space-y-1\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Applies to contract type\n          </span>\n          <input\n            class=\"scoular-form-input cws:w-full\"\n            name=\"editorType\"\n            placeholder=\"Any\"\n            [(ngModel)]=\"contractTypeClass\"\n          />\n        </label>\n\n        <!--\n          #696: a holder picks from the trade units they manage; \"any trade unit\" (a blank location) is\n          offered to an Admin only, because the server refuses it to everyone else (AdminRequired, #700).\n        -->\n        <cws-admin-trade-unit-select\n          label=\"Applies to trade unit\"\n          [allowAny]=\"true\"\n          [value]=\"locationCode\"\n          (valueChange)=\"setLocation($event)\"\n        />\n\n        <label class=\"cws:space-y-1\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to commodity</span>\n          <input\n            class=\"scoular-form-input cws:w-full\"\n            name=\"editorCommodity\"\n            placeholder=\"Any\"\n            [(ngModel)]=\"commodityCode\"\n          />\n        </label>\n\n        <!--\n          🔴 The shared C3 control. See the pricing screen for why the native input went.\n\n          ⚠ The required marker and `aria-required` are the CONTROL's now. This label carried a\n          literal `*` in its text and no `aria-required` at all, so the field announced itself as\n          optional to a screen reader while looking required to everyone else.\n        -->\n        <cms-date-input\n          label=\"Effective from\"\n          controlId=\"editor-effective\"\n          [required]=\"true\"\n          name=\"editorEffective\"\n          [(ngModel)]=\"effectiveFrom\"\n          [errorMessage]=\"effectiveError()\"\n          (ngModelChange)=\"effectiveError.set(null)\"\n        />\n      </div>\n\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"copyFromCurrent()\">\n          Copy from what currently applies\n        </button>\n        <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Reloads the field settings below from the configuration in force for these dimensions —\n          do this after changing them.\n        </span>\n      </div>\n\n      <!--\n        F8.1 — seed from trade unit. New rows only: an existing row already has its own settings, and\n        overwriting them with another trade unit's is an edit, not a starting point.\n\n        ⚠ The source is re-read before the create and its rowVersion compared, so the status line\n        says so: an administrator who leaves the form open for an hour is told why the create was\n        refused, rather than discovering a clone of settings that were since changed.\n      -->\n      @if (isNew()) {\n        <cms-form-row>\n          <label cmsFormRowField=\"Seed from trade unit\">\n            <input\n              class=\"scoular-form-input cws:w-40\"\n              name=\"editorSeedFrom\"\n              placeholder=\"e.g. 4090\"\n              [(ngModel)]=\"seedTradeUnit\"\n            />\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"seedFromTradeUnit()\">\n            Seed from this trade unit\n          </button>\n        </cms-form-row>\n        <!-- Under the row rather than in it, where a wrapped sentence pushed the button off the input's line. -->\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Copies that trade unit's configuration exactly — every field, section, tab and attribute —\n          as this row's starting point. The dimensions above stay this row's.\n        </p>\n\n        @if (seededFrom(); as seed) {\n          <p\n            role=\"status\"\n            class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-200\"\n          >\n            Seeded from trade unit {{ seed.tradeUnit }} — configuration row #{{ seed.id }}\n            ({{ seed.dimensionKey }}, version {{ seed.version }}). It is read again before this row\n            is created, and the create is refused if it has changed since.\n          </p>\n        }\n\n        @if (seedNotice(); as notice) {\n          <p\n            role=\"alert\"\n            class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\n          >\n            {{ notice }}\n          </p>\n        }\n      }\n\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        A future effective date is allowed and is how a change is staged: the row sits dormant until\n        that date, then takes over from the one before it. Editing an old contract always applies\n        today's rules.\n      </p>\n    </div>\n\n    <!-- Trade unit attributes -->\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Trade unit behaviour</h4>\n\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2\">\n        <label class=\"cws:space-y-1\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Contract auto-calculation\n          </span>\n          <select\n            class=\"scoular-form-input cws:w-full\"\n            name=\"editorAutoCalc\"\n            [(ngModel)]=\"autoCalculationMode\"\n          >\n            <option value=\"None\">None — both Price and Basis stay editable</option>\n            <option value=\"Price\">Price — computed from its components and locked</option>\n            <option value=\"Basis\">Basis — computed from its components and locked</option>\n          </select>\n        </label>\n\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2\">\n          <input\n            type=\"checkbox\"\n            name=\"editorPending\"\n            [(ngModel)]=\"pendingContractsEnabled\"\n          />\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Pending contracts enabled\n          </span>\n        </label>\n      </div>\n\n      <!--\n        The home grid's columns (docs/02 §2.1, F4.1a, #748). Every column until a list is set; the\n        contract number cannot be taken off. Users narrow and reorder within this on their own grid.\n      -->\n      <div class=\"cws:space-y-2\" data-home-grid-columns>\n        <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Home grid columns\n            <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\n              — {{ homeGridColumns() === null ? 'every column (no list set)' : 'this list, in this order' }}\n            </span>\n          </span>\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-secondary cws:text-xs\"\n            [disabled]=\"homeGridColumns() === null\"\n            (click)=\"resetHomeGridColumns()\"\n          >\n            Reset to all\n          </button>\n        </div>\n        <cms-export-fields\n          [fields]=\"homeGridColumnFields()\"\n          [lockedKeys]=\"lockedColumnKeys\"\n          noun=\"columns\"\n          listLabel=\"Home grid columns, in order\"\n          emptyMessage=\"Select at least one column.\"\n          (fieldsChange)=\"onHomeGridColumnsChange($event)\"\n        />\n      </div>\n\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        <strong>None</strong> is the honest default for a trade unit nobody has configured — picking\n        Price or Basis makes the rule compute a value and lock the field, which looks like working\n        configuration if it was only a guess.\n      </p>\n    </div>\n\n    <!-- Tabs -->\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Tabs</h4>\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        Which tabs this configuration shows, and what they are called. A hidden tab is not on the\n        screen at all. This is what replaces the legacy application's per-location tabs, which were\n        conditions written into its screen rather than configuration.\n      </p>\n\n      <div class=\"cws:space-y-2\">\n        @for (tab of editableTabs(); track tab.id) {\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\n            <label class=\"cws:flex cws:items-center cws:gap-2\">\n              <input\n                type=\"checkbox\"\n                [checked]=\"tab.visible\"\n                (change)=\"setTabVisible(tab.id, $any($event.target).checked)\"\n                [attr.aria-label]=\"'Show the ' + tab.label + ' tab'\"\n              />\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Show</span>\n            </label>\n\n            <input\n              class=\"scoular-form-input\"\n              [value]=\"tab.label\"\n              (change)=\"setTabLabel(tab.id, $any($event.target).value)\"\n              [attr.aria-label]=\"'Label for the ' + tab.id + ' tab'\"\n            />\n\n            <code class=\"cws:text-xs cws:text-slate-400\">{{ tab.id }}</code>\n          </div>\n        }\n      </div>\n    </div>\n\n    <!-- The field grid -->\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields</h4>\n\n        <div class=\"cws:flex cws:items-center cws:gap-3\">\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            {{ requiredCount() }} required · {{ hiddenCount() }} hidden\n          </span>\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\n            <span class=\"sr-only\">Filter fields</span>\n            <input\n              class=\"scoular-form-input\"\n              name=\"editorFilter\"\n              placeholder=\"Filter fields…\"\n              [ngModel]=\"filter()\"\n              (ngModelChange)=\"filter.set($event)\"\n            />\n          </label>\n        </div>\n      </div>\n\n      <!--\n        Both states are stated where the administrator is working rather than discovered at save.\n        The reorder one explains a disabled control, which is the only honest way to disable\n        something; the empty-tab one reports a state this editor can now create and the record\n        screen does not resolve away.\n      -->\n      @if (reorderBlockedReason(); as reason) {\n        <p class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\">\n          {{ reason }}\n        </p>\n      }\n\n      @if (emptyTabWarning(); as emptied) {\n        <p\n          role=\"status\"\n          class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\n        >\n          Every section is hidden on: {{ emptied }} — so the tab itself will not appear on the\n          record screen. Leave a section visible if you want the tab to stay.\n        </p>\n      }\n\n      @for (section of sections(); track section.id) {\n        <details class=\"cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\" [open]=\"filter() !== ''\">\n          <summary class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-sm cws:font-medium\">\n            {{ section.label }}\n            <span class=\"cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\n              ({{ section.fields.length }} fields · {{ section.tab }} tab)\n            </span>\n          </summary>\n\n          <!--\n            F8.3 — section enablement, in the section's own header rather than on a separate screen,\n            because \"is this section on for this trade unit\" is the same question as \"what is in it\".\n\n            ⚠ The label is a real `<label>` wrapping the input, so the whole phrase is the hit target\n            and a screen reader announces the section name with the state. `stopPropagation` keeps a\n            click on it from toggling the `<details>` it sits inside — without it, turning a section\n            off would also collapse the rows you turned off.\n          -->\n          <div class=\"cws:border-b cws:border-slate-200 cws:px-3 cws:py-2 cws:dark:border-slate-700\">\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\n              <input\n                type=\"checkbox\"\n                [checked]=\"sectionVisible(section.id)\"\n                (click)=\"$event.stopPropagation()\"\n                (change)=\"toggleSection(section.id, $any($event.target).checked)\"\n              />\n              <span>\n                Section visible on the {{ section.tab }} tab\n                @if (!sectionVisible(section.id)) {\n                  <span class=\"cws:ml-1 cws:text-amber-700 cws:dark:text-amber-400\">\n                    — hidden for this trade unit\n                  </span>\n                }\n              </span>\n            </label>\n          </div>\n\n          <div class=\"cws:overflow-x-auto\">\n            <table class=\"cws:w-full cws:text-sm\">\n              <caption class=\"sr-only\">{{ section.label }} field settings</caption>\n              <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\n                <tr>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Order</th>\n                  <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Field</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Read-only</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Warn</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No copy</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No template</th>\n                </tr>\n              </thead>\n              <!--\n                🔴 `select-none` is REQUIRED on the CONTAINER of anything draggable — Known Issue 44:\n                a press inside a leftover text selection is taken by the browser as a selection drag,\n                announced with `pointercancel`, so the gesture works once per session and then\n                silently stops. jsdom cannot test it, so the class is the anchor (the spec reads it\n                off `data-drag-rows`) and the playground screenshot is the proof.\n\n                The press is bound here rather than per row: the shared gesture follows the pointer\n                on the window from there, and hit-tests the row under it (`data-drop-field`).\n              -->\n              <tbody data-drag-rows class=\"cws:select-none\" (pointerdown)=\"onRowPointerDown($event)\">\n                @for (field of section.fields; track field.componentName; let idx = $index) {\n                  <tr\n                    class=\"cws:select-none cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\"\n                    [class.cws:bg-slate-100]=\"draggingField() === field.componentName\"\n                    [class.cws:dark:bg-slate-800]=\"draggingField() === field.componentName\"\n                    [class.cws:border-t-2]=\"dropField() === field.componentName\"\n                    [class.cws:border-t-scoular-blue]=\"dropField() === field.componentName\"\n                    [attr.data-drop-field]=\"field.componentName\"\n                    [attr.data-drop-section]=\"section.id\"\n                    [attr.data-dragging]=\"draggingField() === field.componentName ? 'true' : null\"\n                    [attr.data-drop-here]=\"dropField() === field.componentName ? 'true' : null\"\n                  >\n                    <td class=\"cws:whitespace-nowrap cws:px-2 cws:py-1.5\">\n                      <!--\n                        The drag grip (F8.1). `aria-hidden` with no tab stop: it is an affordance\n                        for the pointer, and the arrows beside it are the keyboard's route to the\n                        same move. Absent while the list is filtered, for the reason the arrows are\n                        disabled — see `reorderBlockedReason`.\n                      -->\n                      @if (reorderBlockedReason() === null) {\n                        <span\n                          aria-hidden=\"true\"\n                          title=\"Drag to reorder\"\n                          class=\"cws:mr-1 cws:inline-block cws:cursor-grab cws:touch-none cws:px-1 cws:text-slate-400\"\n                          [attr.data-drag-field]=\"field.componentName\"\n                          [attr.data-drag-section]=\"section.id\"\n                        >⠿</span>\n                      }\n                      <!--\n                        The keyboard path, and it is the primary one rather than a fallback: this\n                        grid is 111 rows and the people who configure it do so from a keyboard.\n                        Buttons rather than a numeric input, because \"one place up\" is the operation\n                        an administrator actually wants and a free-text order invites collisions.\n                      -->\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\n                        [disabled]=\"idx === 0 || reorderBlockedReason() !== null\"\n                        [attr.aria-label]=\"'Move ' + field.label + ' up'\"\n                        (click)=\"moveField(section.id, field.componentName, -1)\"\n                      >\n                        ↑\n                      </button>\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\n                        [disabled]=\"idx === section.fields.length - 1 || reorderBlockedReason() !== null\"\n                        [attr.aria-label]=\"'Move ' + field.label + ' down'\"\n                        (click)=\"moveField(section.id, field.componentName, 1)\"\n                      >\n                        ↓\n                      </button>\n                    </td>\n                    <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\n                      {{ field.label }}\n                      <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ field.ctrmField }}</code>\n\n                      @if (field.locked) {\n                        <!--\n                          Shown locked rather than hidden. A field absent from this grid reads as\n                          \"not configurable in this version\"; a locked row with a reason reads as\n                          \"not yours to change\", which is what it is.\n                        -->\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n                          — system field: resolution keys on it\n                        </span>\n                      } @else if (field.ctrmRequired) {\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n                          — {{ ctrmRequiredReason }}\n                        </span>\n                      } @else if (field.ctrmReadOnly) {\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">\n                          — CTRM refuses this on a write, so it cannot be required\n                        </span>\n                      }\n                      <!-- #221: width, heading and description for this trade unit. -->\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn-ghost cws:ml-1 cws:px-1 cws:py-0.5 cws:text-xs\"\n                        [attr.aria-expanded]=\"openPresentation() === field.componentName\"\n                        [attr.aria-label]=\"field.label + ' presentation'\"\n                        (click)=\"togglePresentation(field.componentName)\"\n                      >\n                        Presentation{{ field.behaviour.presentation ? ' (set)' : '' }}\n                      </button>\n                    </th>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.visible\"\n                        [disabled]=\"field.locked || field.ctrmRequired || field.behaviour.required\"\n                        (change)=\"setVisible(field.componentName, $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' visible'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <!--\n                        Disabled for a CTRM read-only field and for the drivers: requiring the\n                        first demands the impossible, and the second is already required and not\n                        the admin's to relax.\n                      -->\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.required\"\n                        [disabled]=\"field.locked || field.ctrmRequired || field.ctrmReadOnly\"\n                        (change)=\"setRequired(field.componentName, $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' required'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.readOnly\"\n                        [disabled]=\"field.ctrmReadOnly\"\n                        (change)=\"setFlag(field.componentName, 'readOnly', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' read only'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.borderWarning\"\n                        (change)=\"setFlag(field.componentName, 'borderWarning', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' border warning'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.excludeFromCopy\"\n                        (change)=\"setFlag(field.componentName, 'excludeFromCopy', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' exclude from copy'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.excludeFromTemplateCopy\"\n                        (change)=\"setFlag(field.componentName, 'excludeFromTemplateCopy', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' exclude from template copy'\"\n                      />\n                    </td>\n                  </tr>\n                  @if (openPresentation() === field.componentName) {\n                    <!--\n                      #221: the five presentation settings. Each starts at \"the layout's\", which sends\n                      nothing, so a row saved without touching these stores no presentation at all.\n                      No drop-target attributes, so the drag gesture ignores this row.\n                    -->\n                    @let layout = layoutDefault(field.componentName);\n                    @let current = field.behaviour.presentation;\n                    @let preview = previewOf(field);\n                    <tr class=\"cws:bg-slate-50 cws:dark:bg-slate-900\" [attr.data-presentation-for]=\"field.componentName\">\n                      <td colspan=\"8\" class=\"cws:px-3 cws:py-3\">\n                        <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-[1fr_1fr]\">\n                          <div class=\"cws:grid cws:gap-2 cws:text-xs\">\n                            <!--\n                              An explicit label per control, not a wrapping one: a <label> around a\n                              <select> puts the selected option into the accessible name (\"Width\n                              Layout's (full)\"), which a screen reader then reads on every change.\n                            -->\n                            @let pid = 'presentation-' + field.componentName;\n                            <div>\n                              @if (preview.widthLabel === 'Fixed width') {\n                                <span class=\"cws:block cws:font-medium\">Width</span>\n                                <span class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\" [attr.data-width-fixed]=\"field.componentName\">\n                                  Fixed: the contract number always takes one normal field.\n                                </span>\n                              } @else {\n                                <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-width'\">Width</label>\n                                <select\n                                  class=\"scoular-form-select cws:mt-1\"\n                                  [id]=\"pid + '-width'\"\n                                  [value]=\"flagChoice(current?.halfWidth)\"\n                                  (change)=\"setPresentationFlag(field.componentName, 'halfWidth', $any($event.target).value)\"\n                                >\n                                  <option value=\"\">Automatic ({{ layout.half ? 'compact' : 'from the field' }})</option>\n                                  <option value=\"true\">Compact: a short box, for a code or flag</option>\n                                  <option value=\"false\">Normal: one column</option>\n                                </select>\n                              }\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-heading'\">Heading</label>\n                              <select\n                                class=\"scoular-form-select cws:mt-1\"\n                                [id]=\"pid + '-heading'\"\n                                [value]=\"flagChoice(current?.labelHidden)\"\n                                (change)=\"setPresentationFlag(field.componentName, 'labelHidden', $any($event.target).value)\"\n                              >\n                                <option value=\"\">Layout's ({{ layout.labelHidden ? 'hidden' : 'shown' }})</option>\n                                <option value=\"false\">Shown</option>\n                                <option value=\"true\">Hidden (still read by screen readers)</option>\n                              </select>\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-label'\">Heading text</label>\n                              <input\n                                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                                [id]=\"pid + '-label'\"\n                                [value]=\"current?.label ?? ''\"\n                                [placeholder]=\"field.label\"\n                                (change)=\"setPresentation(field.componentName, 'label', $any($event.target).value)\"\n                              />\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-tooltip'\">Description</label>\n                              <select\n                                class=\"scoular-form-select cws:mt-1\"\n                                [id]=\"pid + '-tooltip'\"\n                                [value]=\"flagChoice(current?.tooltipEnabled)\"\n                                (change)=\"setPresentationFlag(field.componentName, 'tooltipEnabled', $any($event.target).value)\"\n                              >\n                                <option value=\"\">Layout's ({{ layout.note === null ? 'none' : 'shown' }})</option>\n                                <option value=\"true\">Shown</option>\n                                <option value=\"false\">Hidden</option>\n                              </select>\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-description'\">Description text</label>\n                              <textarea\n                                class=\"scoular-form-textarea cws:mt-1 cws:w-full\"\n                                [id]=\"pid + '-description'\"\n                                rows=\"2\"\n                                [value]=\"current?.tooltipDescription ?? ''\"\n                                [placeholder]=\"layout.note ?? 'No description in the layout'\"\n                                (change)=\"setPresentation(field.componentName, 'tooltipDescription', $any($event.target).value)\"\n                              ></textarea>\n                            </div>\n                            <div>\n                              <button\n                                type=\"button\"\n                                class=\"scoular-btn scoular-btn-secondary\"\n                                [disabled]=\"current === undefined\"\n                                (click)=\"resetPresentation(field.componentName)\"\n                              >\n                                Reset to layout\n                              </button>\n                            </div>\n                          </div>\n\n                          <!-- The preview: how the heading, width and description will render. -->\n                          <div class=\"cws:text-xs\" [attr.data-presentation-preview]=\"field.componentName\">\n                            <p class=\"cws:font-medium\">Preview</p>\n                            <div class=\"cws:mt-1 cws:grid cws:grid-cols-2 cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-2 cws:dark:border-slate-600\">\n                              <div [class.cws:col-span-2]=\"!preview.half\" [class.cws:col-span-1]=\"preview.half\">\n                                @if (preview.labelHidden) {\n                                  <span class=\"sr-only\">{{ preview.label }}</span>\n                                  <span class=\"cws:italic cws:text-slate-400\" aria-hidden=\"true\">Heading hidden</span>\n                                } @else {\n                                  <span class=\"cws:font-medium\">{{ preview.label }}</span>\n                                }\n                                <span class=\"cws:mt-1 cws:block cws:h-8 cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:dark:bg-slate-800\"></span>\n                                @if (preview.description !== null) {\n                                  <span class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\">\n                                    {{ preview.half ? 'ⓘ ' : '' }}{{ preview.description }}\n                                  </span>\n                                }\n                              </div>\n                            </div>\n                            <p class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\">\n                              {{ preview.widthLabel }} ·\n                              heading {{ preview.labelHidden ? 'hidden' : 'shown' }} ·\n                              {{ preview.description === null ? 'no description' : (preview.half ? 'description in the ⓘ tooltip' : 'description under the field') }}\n                            </p>\n                          </div>\n                        </div>\n                      </td>\n                    </tr>\n                  }\n                }\n              </tbody>\n            </table>\n          </div>\n        </details>\n      }\n\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        Ticking <strong>Required</strong> also ticks <strong>Visible</strong> and locks it — a field\n        somebody must fill in cannot be one they cannot see. The save enforces requiredness against\n        the contract as it will reach CTRM, so a field the user never touched still counts as filled\n        if CTRM already holds a value for it.\n      </p>\n    </div>\n\n    <!--\n      #1000: the collection copy flags (#959). Rendered only when the registry offers collections, so\n      a server without #959 shows nothing here rather than an error. Only Exclude from copy: the\n      template flag is stored but not shown until templates carry collections, and Visible, Required\n      and Read-only mean nothing for a whole collection (ruled 2026-10-20).\n    -->\n    @if (collectionRows(); as collections) {\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-collections-on-copy>\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Collections on copy</h4>\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Which of a contract's collections a copy leaves out, for this configuration. Every collection\n          is copied until it is excluded here.\n        </p>\n\n        <div class=\"cws:overflow-x-auto\">\n          <table class=\"cws:w-full cws:text-sm\">\n            <caption class=\"sr-only\">Collection copy settings</caption>\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\n              <tr>\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Collection</th>\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Exclude from copy</th>\n              </tr>\n            </thead>\n            <tbody>\n              @for (collection of collections; track collection.name) {\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-collection]=\"collection.name\">\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\n                    {{ collection.label }}\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ collection.name }}</code>\n                    @if (!collection.copyable) {\n                      <!-- Shown disabled with the reason, rather than hidden: the server refuses a set flag on it. -->\n                      <span\n                        class=\"cws:ml-1 cws:text-xs cws:text-slate-400\"\n                        [id]=\"'collection-not-copied-' + collection.name\"\n                      >\n                        — CTRM does not accept this on a write, so a copy never carries it.\n                      </span>\n                    }\n                  </th>\n                  <td class=\"cws:px-2 cws:py-1.5\">\n                    <input\n                      type=\"checkbox\"\n                      [checked]=\"collection.excludeFromCopy\"\n                      [disabled]=\"!collection.copyable\"\n                      (change)=\"setCollectionExcluded(collection.name, $any($event.target).checked)\"\n                      [attr.aria-label]=\"'Exclude the ' + collection.name + ' collection from copy'\"\n                      [attr.aria-describedby]=\"collection.copyable ? null : 'collection-not-copied-' + collection.name\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      </div>\n    }\n\n    <!--\n      #1006 (ruled 2026-10-21, option (a)): one row per CTRM remark type, each with Visible and Required.\n      Rendered only when the registry offers remark types (#1022), so a server without it shows nothing\n      here rather than an error. Required ticks Visible and locks it, as it does for a field.\n    -->\n    @if (remarkRows(); as remarks) {\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-remark-types>\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Remarks</h4>\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Which remark types the record screen offers, and which must be filled in before a contract\n          can be saved. A hidden type's stored remark is kept: it is only not shown for editing.\n        </p>\n\n        <div class=\"cws:overflow-x-auto\">\n          <table class=\"cws:w-full cws:text-sm\">\n            <caption class=\"sr-only\">Remark type settings</caption>\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\n              <tr>\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Remark type</th>\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\n              </tr>\n            </thead>\n            <tbody>\n              @for (remark of remarks; track remark.code) {\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-remark-type]=\"remark.code\">\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\n                    {{ remark.label }}\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ remark.code }}</code>\n                  </th>\n                  <td class=\"cws:px-2 cws:py-1.5\">\n                    <input\n                      type=\"checkbox\"\n                      [checked]=\"remark.visible\"\n                      [disabled]=\"remark.required\"\n                      (change)=\"setRemarkFlag(remark.code, 'visible', $any($event.target).checked)\"\n                      [attr.aria-label]=\"remark.label + ' remark visible'\"\n                    />\n                  </td>\n                  <td class=\"cws:px-2 cws:py-1.5\">\n                    <input\n                      type=\"checkbox\"\n                      [checked]=\"remark.required\"\n                      (change)=\"setRemarkFlag(remark.code, 'required', $any($event.target).checked)\"\n                      [attr.aria-label]=\"remark.label + ' remark required'\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      </div>\n    }\n\n    @if (columnsNotKept()) {\n      <!--\n        #748: the row WAS saved; only the column list was not kept. Saving again would repeat the\n        save, so the only action offered is to close, and the list has to wait for #747.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-columns-not-kept>\n        <div class=\"scoular-alert-title\">Saved, except the home grid columns</div>\n        <div class=\"scoular-alert-description\">\n          The rest of this configuration was saved. The server did not keep the column list, because it\n          cannot store one yet, so this trade unit's grid still shows every column.\n        </div>\n      </div>\n    }\n\n    @if (everyTradeUnitPending()) {\n      <!--\n        #844: a row for every trade unit takes a second, deliberate click. The Dev walk made one by\n        mistake with a seed set, so the seed is named: seeding copies settings, it does not pick the\n        trade unit the row applies to.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-every-trade-unit>\n        <div class=\"scoular-alert-title\">This configuration applies to every trade unit</div>\n        <div class=\"scoular-alert-description cws:space-y-2\">\n          <p>\n            @if (seededFrom(); as seed) {\n              Its settings are copied from trade unit {{ seed.tradeUnit }}, but it applies to every trade unit.\n            }\n            \"Applies to trade unit\" is set to any trade unit, so from its effective date this row is used\n            for every trade unit that has no more specific row of its own. To configure one trade unit,\n            pick it under \"Applies to trade unit\".\n          </p>\n          <div class=\"cws:flex cws:flex-wrap cws:gap-3\">\n            <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"saving()\" (click)=\"save(true)\">\n              {{ isNew() ? 'Create for every trade unit' : 'Save for every trade unit' }}\n            </button>\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"everyTradeUnitPending.set(false)\">\n              Go back\n            </button>\n          </div>\n        </div>\n      </div>\n    }\n\n    <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\n      @if (columnsNotKept()) {\n        <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"saved.emit()\">\n          Close\n        </button>\n      }\n\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary\"\n        [class.cws:hidden]=\"columnsNotKept()\"\n        [disabled]=\"saving() || columnsNotKept()\"\n        (click)=\"save()\"\n      >\n        {{ saving() ? 'Saving…' : isNew() ? 'Create configuration' : 'Save changes' }}\n      </button>\n\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-secondary\"\n        (click)=\"cancel()\"\n      >\n        Cancel\n      </button>\n    </div>\n  }\n</section>\n",
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: DateInputComponent,
				selector: "cms-date-input",
				inputs: [
					"label",
					"controlId",
					"required",
					"requiredMarker",
					"hideLabel",
					"readOnly",
					"plain",
					"help",
					"marker",
					"display",
					"skipTab",
					"borderWarning",
					"warningText",
					"errorMessage"
				]
			},
			{
				kind: "component",
				type: ExportFieldsComponent,
				selector: "cms-export-fields",
				inputs: [
					"fields",
					"lockedKeys",
					"noun",
					"listLabel",
					"emptyMessage"
				],
				outputs: ["fieldsChange"]
			},
			{
				kind: "component",
				type: AdminTradeUnitSelectComponent,
				selector: "cws-admin-trade-unit-select",
				inputs: [
					"label",
					"value",
					"allowAny",
					"everyLocation"
				],
				outputs: ["valueChange"]
			},
			{
				kind: "component",
				type: FormRowComponent,
				selector: "cms-form-row"
			},
			{
				kind: "component",
				type: FormRowFieldComponent,
				selector: "label[cmsFormRowField]",
				inputs: ["cmsFormRowField"]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormConfigEditorComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-form-config-editor",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				DateInputComponent,
				ExportFieldsComponent,
				AdminTradeUnitSelectComponent,
				FormRowComponent,
				FormRowFieldComponent,
				StatusMessageComponent
			],
			providers: [AdminScope],
			template: "<section class=\"cws:space-y-5\">\n  <header class=\"cws:space-y-1\">\n    <h3 class=\"cws:text-base cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\n      {{ isNew() ? 'New configuration' : 'Edit configuration' }}\n    </h3>\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n      A row applies to every contract matching the dimensions below — leave one empty to mean\n      <em>any</em>. The most specific matching row wins <strong>whole</strong>: nothing is merged\n      from less specific rows, which is why this form starts from whatever currently applies.\n    </p>\n  </header>\n\n  <!-- #803: why the editor cannot go on, with the server's reference or why there is none. -->\n  <cms-status-message [outcome]=\"outcome()\" (dismissed)=\"outcome.set(null)\" />\n\n  @if (!ready()) {\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\" role=\"status\">\n      Loading the field registry…\n    </p>\n  } @else {\n    <!-- Dimensions -->\n    <div class=\"scoular-card cws:space-y-4 cws:p-4\">\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2 cws:xl:grid-cols-4\">\n        <label class=\"cws:space-y-1\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Applies to contract type\n          </span>\n          <input\n            class=\"scoular-form-input cws:w-full\"\n            name=\"editorType\"\n            placeholder=\"Any\"\n            [(ngModel)]=\"contractTypeClass\"\n          />\n        </label>\n\n        <!--\n          #696: a holder picks from the trade units they manage; \"any trade unit\" (a blank location) is\n          offered to an Admin only, because the server refuses it to everyone else (AdminRequired, #700).\n        -->\n        <cws-admin-trade-unit-select\n          label=\"Applies to trade unit\"\n          [allowAny]=\"true\"\n          [value]=\"locationCode\"\n          (valueChange)=\"setLocation($event)\"\n        />\n\n        <label class=\"cws:space-y-1\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Applies to commodity</span>\n          <input\n            class=\"scoular-form-input cws:w-full\"\n            name=\"editorCommodity\"\n            placeholder=\"Any\"\n            [(ngModel)]=\"commodityCode\"\n          />\n        </label>\n\n        <!--\n          🔴 The shared C3 control. See the pricing screen for why the native input went.\n\n          ⚠ The required marker and `aria-required` are the CONTROL's now. This label carried a\n          literal `*` in its text and no `aria-required` at all, so the field announced itself as\n          optional to a screen reader while looking required to everyone else.\n        -->\n        <cms-date-input\n          label=\"Effective from\"\n          controlId=\"editor-effective\"\n          [required]=\"true\"\n          name=\"editorEffective\"\n          [(ngModel)]=\"effectiveFrom\"\n          [errorMessage]=\"effectiveError()\"\n          (ngModelChange)=\"effectiveError.set(null)\"\n        />\n      </div>\n\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\n        <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"copyFromCurrent()\">\n          Copy from what currently applies\n        </button>\n        <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Reloads the field settings below from the configuration in force for these dimensions —\n          do this after changing them.\n        </span>\n      </div>\n\n      <!--\n        F8.1 — seed from trade unit. New rows only: an existing row already has its own settings, and\n        overwriting them with another trade unit's is an edit, not a starting point.\n\n        ⚠ The source is re-read before the create and its rowVersion compared, so the status line\n        says so: an administrator who leaves the form open for an hour is told why the create was\n        refused, rather than discovering a clone of settings that were since changed.\n      -->\n      @if (isNew()) {\n        <cms-form-row>\n          <label cmsFormRowField=\"Seed from trade unit\">\n            <input\n              class=\"scoular-form-input cws:w-40\"\n              name=\"editorSeedFrom\"\n              placeholder=\"e.g. 4090\"\n              [(ngModel)]=\"seedTradeUnit\"\n            />\n          </label>\n          <button cmsFormRowActions type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"seedFromTradeUnit()\">\n            Seed from this trade unit\n          </button>\n        </cms-form-row>\n        <!-- Under the row rather than in it, where a wrapped sentence pushed the button off the input's line. -->\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Copies that trade unit's configuration exactly — every field, section, tab and attribute —\n          as this row's starting point. The dimensions above stay this row's.\n        </p>\n\n        @if (seededFrom(); as seed) {\n          <p\n            role=\"status\"\n            class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-200\"\n          >\n            Seeded from trade unit {{ seed.tradeUnit }} — configuration row #{{ seed.id }}\n            ({{ seed.dimensionKey }}, version {{ seed.version }}). It is read again before this row\n            is created, and the create is refused if it has changed since.\n          </p>\n        }\n\n        @if (seedNotice(); as notice) {\n          <p\n            role=\"alert\"\n            class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\n          >\n            {{ notice }}\n          </p>\n        }\n      }\n\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        A future effective date is allowed and is how a change is staged: the row sits dormant until\n        that date, then takes over from the one before it. Editing an old contract always applies\n        today's rules.\n      </p>\n    </div>\n\n    <!-- Trade unit attributes -->\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Trade unit behaviour</h4>\n\n      <div class=\"cws:grid cws:gap-3 cws:sm:grid-cols-2\">\n        <label class=\"cws:space-y-1\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Contract auto-calculation\n          </span>\n          <select\n            class=\"scoular-form-input cws:w-full\"\n            name=\"editorAutoCalc\"\n            [(ngModel)]=\"autoCalculationMode\"\n          >\n            <option value=\"None\">None — both Price and Basis stay editable</option>\n            <option value=\"Price\">Price — computed from its components and locked</option>\n            <option value=\"Basis\">Basis — computed from its components and locked</option>\n          </select>\n        </label>\n\n        <label class=\"cws:flex cws:items-end cws:gap-2 cws:pb-2\">\n          <input\n            type=\"checkbox\"\n            name=\"editorPending\"\n            [(ngModel)]=\"pendingContractsEnabled\"\n          />\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Pending contracts enabled\n          </span>\n        </label>\n      </div>\n\n      <!--\n        The home grid's columns (docs/02 §2.1, F4.1a, #748). Every column until a list is set; the\n        contract number cannot be taken off. Users narrow and reorder within this on their own grid.\n      -->\n      <div class=\"cws:space-y-2\" data-home-grid-columns>\n        <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\n          <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\n            Home grid columns\n            <span class=\"cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\n              — {{ homeGridColumns() === null ? 'every column (no list set)' : 'this list, in this order' }}\n            </span>\n          </span>\n          <button\n            type=\"button\"\n            class=\"scoular-btn scoular-btn-secondary cws:text-xs\"\n            [disabled]=\"homeGridColumns() === null\"\n            (click)=\"resetHomeGridColumns()\"\n          >\n            Reset to all\n          </button>\n        </div>\n        <cms-export-fields\n          [fields]=\"homeGridColumnFields()\"\n          [lockedKeys]=\"lockedColumnKeys\"\n          noun=\"columns\"\n          listLabel=\"Home grid columns, in order\"\n          emptyMessage=\"Select at least one column.\"\n          (fieldsChange)=\"onHomeGridColumnsChange($event)\"\n        />\n      </div>\n\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        <strong>None</strong> is the honest default for a trade unit nobody has configured — picking\n        Price or Basis makes the rule compute a value and lock the field, which looks like working\n        configuration if it was only a guess.\n      </p>\n    </div>\n\n    <!-- Tabs -->\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\n      <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Tabs</h4>\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        Which tabs this configuration shows, and what they are called. A hidden tab is not on the\n        screen at all. This is what replaces the legacy application's per-location tabs, which were\n        conditions written into its screen rather than configuration.\n      </p>\n\n      <div class=\"cws:space-y-2\">\n        @for (tab of editableTabs(); track tab.id) {\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\n            <label class=\"cws:flex cws:items-center cws:gap-2\">\n              <input\n                type=\"checkbox\"\n                [checked]=\"tab.visible\"\n                (change)=\"setTabVisible(tab.id, $any($event.target).checked)\"\n                [attr.aria-label]=\"'Show the ' + tab.label + ' tab'\"\n              />\n              <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Show</span>\n            </label>\n\n            <input\n              class=\"scoular-form-input\"\n              [value]=\"tab.label\"\n              (change)=\"setTabLabel(tab.id, $any($event.target).value)\"\n              [attr.aria-label]=\"'Label for the ' + tab.id + ' tab'\"\n            />\n\n            <code class=\"cws:text-xs cws:text-slate-400\">{{ tab.id }}</code>\n          </div>\n        }\n      </div>\n    </div>\n\n    <!-- The field grid -->\n    <div class=\"scoular-card cws:space-y-3 cws:p-4\">\n      <div class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3\">\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Fields</h4>\n\n        <div class=\"cws:flex cws:items-center cws:gap-3\">\n          <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n            {{ requiredCount() }} required · {{ hiddenCount() }} hidden\n          </span>\n          <label class=\"cws:flex cws:items-center cws:gap-2\">\n            <span class=\"sr-only\">Filter fields</span>\n            <input\n              class=\"scoular-form-input\"\n              name=\"editorFilter\"\n              placeholder=\"Filter fields…\"\n              [ngModel]=\"filter()\"\n              (ngModelChange)=\"filter.set($event)\"\n            />\n          </label>\n        </div>\n      </div>\n\n      <!--\n        Both states are stated where the administrator is working rather than discovered at save.\n        The reorder one explains a disabled control, which is the only honest way to disable\n        something; the empty-tab one reports a state this editor can now create and the record\n        screen does not resolve away.\n      -->\n      @if (reorderBlockedReason(); as reason) {\n        <p class=\"cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:text-xs cws:text-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\">\n          {{ reason }}\n        </p>\n      }\n\n      @if (emptyTabWarning(); as emptied) {\n        <p\n          role=\"status\"\n          class=\"cws:rounded cws:bg-amber-50 cws:px-3 cws:py-2 cws:text-xs cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\n        >\n          Every section is hidden on: {{ emptied }} — so the tab itself will not appear on the\n          record screen. Leave a section visible if you want the tab to stay.\n        </p>\n      }\n\n      @for (section of sections(); track section.id) {\n        <details class=\"cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\" [open]=\"filter() !== ''\">\n          <summary class=\"cws:cursor-pointer cws:px-3 cws:py-2 cws:text-sm cws:font-medium\">\n            {{ section.label }}\n            <span class=\"cws:text-xs cws:font-normal cws:text-slate-500 cws:dark:text-slate-400\">\n              ({{ section.fields.length }} fields · {{ section.tab }} tab)\n            </span>\n          </summary>\n\n          <!--\n            F8.3 — section enablement, in the section's own header rather than on a separate screen,\n            because \"is this section on for this trade unit\" is the same question as \"what is in it\".\n\n            ⚠ The label is a real `<label>` wrapping the input, so the whole phrase is the hit target\n            and a screen reader announces the section name with the state. `stopPropagation` keeps a\n            click on it from toggling the `<details>` it sits inside — without it, turning a section\n            off would also collapse the rows you turned off.\n          -->\n          <div class=\"cws:border-b cws:border-slate-200 cws:px-3 cws:py-2 cws:dark:border-slate-700\">\n            <label class=\"cws:flex cws:items-center cws:gap-2 cws:text-xs\">\n              <input\n                type=\"checkbox\"\n                [checked]=\"sectionVisible(section.id)\"\n                (click)=\"$event.stopPropagation()\"\n                (change)=\"toggleSection(section.id, $any($event.target).checked)\"\n              />\n              <span>\n                Section visible on the {{ section.tab }} tab\n                @if (!sectionVisible(section.id)) {\n                  <span class=\"cws:ml-1 cws:text-amber-700 cws:dark:text-amber-400\">\n                    — hidden for this trade unit\n                  </span>\n                }\n              </span>\n            </label>\n          </div>\n\n          <div class=\"cws:overflow-x-auto\">\n            <table class=\"cws:w-full cws:text-sm\">\n              <caption class=\"sr-only\">{{ section.label }} field settings</caption>\n              <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\n                <tr>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Order</th>\n                  <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Field</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Read-only</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Warn</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No copy</th>\n                  <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">No template</th>\n                </tr>\n              </thead>\n              <!--\n                🔴 `select-none` is REQUIRED on the CONTAINER of anything draggable — Known Issue 44:\n                a press inside a leftover text selection is taken by the browser as a selection drag,\n                announced with `pointercancel`, so the gesture works once per session and then\n                silently stops. jsdom cannot test it, so the class is the anchor (the spec reads it\n                off `data-drag-rows`) and the playground screenshot is the proof.\n\n                The press is bound here rather than per row: the shared gesture follows the pointer\n                on the window from there, and hit-tests the row under it (`data-drop-field`).\n              -->\n              <tbody data-drag-rows class=\"cws:select-none\" (pointerdown)=\"onRowPointerDown($event)\">\n                @for (field of section.fields; track field.componentName; let idx = $index) {\n                  <tr\n                    class=\"cws:select-none cws:border-b cws:border-slate-100 cws:last:border-0 cws:dark:border-slate-800\"\n                    [class.cws:bg-slate-100]=\"draggingField() === field.componentName\"\n                    [class.cws:dark:bg-slate-800]=\"draggingField() === field.componentName\"\n                    [class.cws:border-t-2]=\"dropField() === field.componentName\"\n                    [class.cws:border-t-scoular-blue]=\"dropField() === field.componentName\"\n                    [attr.data-drop-field]=\"field.componentName\"\n                    [attr.data-drop-section]=\"section.id\"\n                    [attr.data-dragging]=\"draggingField() === field.componentName ? 'true' : null\"\n                    [attr.data-drop-here]=\"dropField() === field.componentName ? 'true' : null\"\n                  >\n                    <td class=\"cws:whitespace-nowrap cws:px-2 cws:py-1.5\">\n                      <!--\n                        The drag grip (F8.1). `aria-hidden` with no tab stop: it is an affordance\n                        for the pointer, and the arrows beside it are the keyboard's route to the\n                        same move. Absent while the list is filtered, for the reason the arrows are\n                        disabled — see `reorderBlockedReason`.\n                      -->\n                      @if (reorderBlockedReason() === null) {\n                        <span\n                          aria-hidden=\"true\"\n                          title=\"Drag to reorder\"\n                          class=\"cws:mr-1 cws:inline-block cws:cursor-grab cws:touch-none cws:px-1 cws:text-slate-400\"\n                          [attr.data-drag-field]=\"field.componentName\"\n                          [attr.data-drag-section]=\"section.id\"\n                        >⠿</span>\n                      }\n                      <!--\n                        The keyboard path, and it is the primary one rather than a fallback: this\n                        grid is 111 rows and the people who configure it do so from a keyboard.\n                        Buttons rather than a numeric input, because \"one place up\" is the operation\n                        an administrator actually wants and a free-text order invites collisions.\n                      -->\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\n                        [disabled]=\"idx === 0 || reorderBlockedReason() !== null\"\n                        [attr.aria-label]=\"'Move ' + field.label + ' up'\"\n                        (click)=\"moveField(section.id, field.componentName, -1)\"\n                      >\n                        ↑\n                      </button>\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn-ghost cws:px-1 cws:py-0.5 cws:text-xs\"\n                        [disabled]=\"idx === section.fields.length - 1 || reorderBlockedReason() !== null\"\n                        [attr.aria-label]=\"'Move ' + field.label + ' down'\"\n                        (click)=\"moveField(section.id, field.componentName, 1)\"\n                      >\n                        ↓\n                      </button>\n                    </td>\n                    <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\n                      {{ field.label }}\n                      <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ field.ctrmField }}</code>\n\n                      @if (field.locked) {\n                        <!--\n                          Shown locked rather than hidden. A field absent from this grid reads as\n                          \"not configurable in this version\"; a locked row with a reason reads as\n                          \"not yours to change\", which is what it is.\n                        -->\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n                          — system field: resolution keys on it\n                        </span>\n                      } @else if (field.ctrmRequired) {\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n                          — {{ ctrmRequiredReason }}\n                        </span>\n                      } @else if (field.ctrmReadOnly) {\n                        <span class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">\n                          — CTRM refuses this on a write, so it cannot be required\n                        </span>\n                      }\n                      <!-- #221: width, heading and description for this trade unit. -->\n                      <button\n                        type=\"button\"\n                        class=\"scoular-btn-ghost cws:ml-1 cws:px-1 cws:py-0.5 cws:text-xs\"\n                        [attr.aria-expanded]=\"openPresentation() === field.componentName\"\n                        [attr.aria-label]=\"field.label + ' presentation'\"\n                        (click)=\"togglePresentation(field.componentName)\"\n                      >\n                        Presentation{{ field.behaviour.presentation ? ' (set)' : '' }}\n                      </button>\n                    </th>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.visible\"\n                        [disabled]=\"field.locked || field.ctrmRequired || field.behaviour.required\"\n                        (change)=\"setVisible(field.componentName, $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' visible'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <!--\n                        Disabled for a CTRM read-only field and for the drivers: requiring the\n                        first demands the impossible, and the second is already required and not\n                        the admin's to relax.\n                      -->\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.required\"\n                        [disabled]=\"field.locked || field.ctrmRequired || field.ctrmReadOnly\"\n                        (change)=\"setRequired(field.componentName, $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' required'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.readOnly\"\n                        [disabled]=\"field.ctrmReadOnly\"\n                        (change)=\"setFlag(field.componentName, 'readOnly', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' read only'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.borderWarning\"\n                        (change)=\"setFlag(field.componentName, 'borderWarning', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' border warning'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.excludeFromCopy\"\n                        (change)=\"setFlag(field.componentName, 'excludeFromCopy', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' exclude from copy'\"\n                      />\n                    </td>\n\n                    <td class=\"cws:px-2 cws:py-1.5\">\n                      <input\n                        type=\"checkbox\"\n                        [checked]=\"field.behaviour.excludeFromTemplateCopy\"\n                        (change)=\"setFlag(field.componentName, 'excludeFromTemplateCopy', $any($event.target).checked)\"\n                        [attr.aria-label]=\"field.label + ' exclude from template copy'\"\n                      />\n                    </td>\n                  </tr>\n                  @if (openPresentation() === field.componentName) {\n                    <!--\n                      #221: the five presentation settings. Each starts at \"the layout's\", which sends\n                      nothing, so a row saved without touching these stores no presentation at all.\n                      No drop-target attributes, so the drag gesture ignores this row.\n                    -->\n                    @let layout = layoutDefault(field.componentName);\n                    @let current = field.behaviour.presentation;\n                    @let preview = previewOf(field);\n                    <tr class=\"cws:bg-slate-50 cws:dark:bg-slate-900\" [attr.data-presentation-for]=\"field.componentName\">\n                      <td colspan=\"8\" class=\"cws:px-3 cws:py-3\">\n                        <div class=\"cws:grid cws:gap-3 cws:md:grid-cols-[1fr_1fr]\">\n                          <div class=\"cws:grid cws:gap-2 cws:text-xs\">\n                            <!--\n                              An explicit label per control, not a wrapping one: a <label> around a\n                              <select> puts the selected option into the accessible name (\"Width\n                              Layout's (full)\"), which a screen reader then reads on every change.\n                            -->\n                            @let pid = 'presentation-' + field.componentName;\n                            <div>\n                              @if (preview.widthLabel === 'Fixed width') {\n                                <span class=\"cws:block cws:font-medium\">Width</span>\n                                <span class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\" [attr.data-width-fixed]=\"field.componentName\">\n                                  Fixed: the contract number always takes one normal field.\n                                </span>\n                              } @else {\n                                <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-width'\">Width</label>\n                                <select\n                                  class=\"scoular-form-select cws:mt-1\"\n                                  [id]=\"pid + '-width'\"\n                                  [value]=\"flagChoice(current?.halfWidth)\"\n                                  (change)=\"setPresentationFlag(field.componentName, 'halfWidth', $any($event.target).value)\"\n                                >\n                                  <option value=\"\">Automatic ({{ layout.half ? 'compact' : 'from the field' }})</option>\n                                  <option value=\"true\">Compact: a short box, for a code or flag</option>\n                                  <option value=\"false\">Normal: one column</option>\n                                </select>\n                              }\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-heading'\">Heading</label>\n                              <select\n                                class=\"scoular-form-select cws:mt-1\"\n                                [id]=\"pid + '-heading'\"\n                                [value]=\"flagChoice(current?.labelHidden)\"\n                                (change)=\"setPresentationFlag(field.componentName, 'labelHidden', $any($event.target).value)\"\n                              >\n                                <option value=\"\">Layout's ({{ layout.labelHidden ? 'hidden' : 'shown' }})</option>\n                                <option value=\"false\">Shown</option>\n                                <option value=\"true\">Hidden (still read by screen readers)</option>\n                              </select>\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-label'\">Heading text</label>\n                              <input\n                                class=\"scoular-form-input cws:mt-1 cws:w-full\"\n                                [id]=\"pid + '-label'\"\n                                [value]=\"current?.label ?? ''\"\n                                [placeholder]=\"field.label\"\n                                (change)=\"setPresentation(field.componentName, 'label', $any($event.target).value)\"\n                              />\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-tooltip'\">Description</label>\n                              <select\n                                class=\"scoular-form-select cws:mt-1\"\n                                [id]=\"pid + '-tooltip'\"\n                                [value]=\"flagChoice(current?.tooltipEnabled)\"\n                                (change)=\"setPresentationFlag(field.componentName, 'tooltipEnabled', $any($event.target).value)\"\n                              >\n                                <option value=\"\">Layout's ({{ layout.note === null ? 'none' : 'shown' }})</option>\n                                <option value=\"true\">Shown</option>\n                                <option value=\"false\">Hidden</option>\n                              </select>\n                            </div>\n                            <div>\n                              <label class=\"cws:block cws:font-medium\" [for]=\"pid + '-description'\">Description text</label>\n                              <textarea\n                                class=\"scoular-form-textarea cws:mt-1 cws:w-full\"\n                                [id]=\"pid + '-description'\"\n                                rows=\"2\"\n                                [value]=\"current?.tooltipDescription ?? ''\"\n                                [placeholder]=\"layout.note ?? 'No description in the layout'\"\n                                (change)=\"setPresentation(field.componentName, 'tooltipDescription', $any($event.target).value)\"\n                              ></textarea>\n                            </div>\n                            <div>\n                              <button\n                                type=\"button\"\n                                class=\"scoular-btn scoular-btn-secondary\"\n                                [disabled]=\"current === undefined\"\n                                (click)=\"resetPresentation(field.componentName)\"\n                              >\n                                Reset to layout\n                              </button>\n                            </div>\n                          </div>\n\n                          <!-- The preview: how the heading, width and description will render. -->\n                          <div class=\"cws:text-xs\" [attr.data-presentation-preview]=\"field.componentName\">\n                            <p class=\"cws:font-medium\">Preview</p>\n                            <div class=\"cws:mt-1 cws:grid cws:grid-cols-2 cws:gap-2 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:p-2 cws:dark:border-slate-600\">\n                              <div [class.cws:col-span-2]=\"!preview.half\" [class.cws:col-span-1]=\"preview.half\">\n                                @if (preview.labelHidden) {\n                                  <span class=\"sr-only\">{{ preview.label }}</span>\n                                  <span class=\"cws:italic cws:text-slate-400\" aria-hidden=\"true\">Heading hidden</span>\n                                } @else {\n                                  <span class=\"cws:font-medium\">{{ preview.label }}</span>\n                                }\n                                <span class=\"cws:mt-1 cws:block cws:h-8 cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:dark:bg-slate-800\"></span>\n                                @if (preview.description !== null) {\n                                  <span class=\"cws:mt-1 cws:block cws:text-slate-500 cws:dark:text-slate-400\">\n                                    {{ preview.half ? 'ⓘ ' : '' }}{{ preview.description }}\n                                  </span>\n                                }\n                              </div>\n                            </div>\n                            <p class=\"cws:mt-1 cws:text-slate-500 cws:dark:text-slate-400\">\n                              {{ preview.widthLabel }} ·\n                              heading {{ preview.labelHidden ? 'hidden' : 'shown' }} ·\n                              {{ preview.description === null ? 'no description' : (preview.half ? 'description in the ⓘ tooltip' : 'description under the field') }}\n                            </p>\n                          </div>\n                        </div>\n                      </td>\n                    </tr>\n                  }\n                }\n              </tbody>\n            </table>\n          </div>\n        </details>\n      }\n\n      <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n        Ticking <strong>Required</strong> also ticks <strong>Visible</strong> and locks it — a field\n        somebody must fill in cannot be one they cannot see. The save enforces requiredness against\n        the contract as it will reach CTRM, so a field the user never touched still counts as filled\n        if CTRM already holds a value for it.\n      </p>\n    </div>\n\n    <!--\n      #1000: the collection copy flags (#959). Rendered only when the registry offers collections, so\n      a server without #959 shows nothing here rather than an error. Only Exclude from copy: the\n      template flag is stored but not shown until templates carry collections, and Visible, Required\n      and Read-only mean nothing for a whole collection (ruled 2026-10-20).\n    -->\n    @if (collectionRows(); as collections) {\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-collections-on-copy>\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Collections on copy</h4>\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Which of a contract's collections a copy leaves out, for this configuration. Every collection\n          is copied until it is excluded here.\n        </p>\n\n        <div class=\"cws:overflow-x-auto\">\n          <table class=\"cws:w-full cws:text-sm\">\n            <caption class=\"sr-only\">Collection copy settings</caption>\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\n              <tr>\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Collection</th>\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Exclude from copy</th>\n              </tr>\n            </thead>\n            <tbody>\n              @for (collection of collections; track collection.name) {\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-collection]=\"collection.name\">\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\n                    {{ collection.label }}\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ collection.name }}</code>\n                    @if (!collection.copyable) {\n                      <!-- Shown disabled with the reason, rather than hidden: the server refuses a set flag on it. -->\n                      <span\n                        class=\"cws:ml-1 cws:text-xs cws:text-slate-400\"\n                        [id]=\"'collection-not-copied-' + collection.name\"\n                      >\n                        — CTRM does not accept this on a write, so a copy never carries it.\n                      </span>\n                    }\n                  </th>\n                  <td class=\"cws:px-2 cws:py-1.5\">\n                    <input\n                      type=\"checkbox\"\n                      [checked]=\"collection.excludeFromCopy\"\n                      [disabled]=\"!collection.copyable\"\n                      (change)=\"setCollectionExcluded(collection.name, $any($event.target).checked)\"\n                      [attr.aria-label]=\"'Exclude the ' + collection.name + ' collection from copy'\"\n                      [attr.aria-describedby]=\"collection.copyable ? null : 'collection-not-copied-' + collection.name\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      </div>\n    }\n\n    <!--\n      #1006 (ruled 2026-10-21, option (a)): one row per CTRM remark type, each with Visible and Required.\n      Rendered only when the registry offers remark types (#1022), so a server without it shows nothing\n      here rather than an error. Required ticks Visible and locks it, as it does for a field.\n    -->\n    @if (remarkRows(); as remarks) {\n      <div class=\"scoular-card cws:space-y-3 cws:p-4\" data-remark-types>\n        <h4 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">Remarks</h4>\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\n          Which remark types the record screen offers, and which must be filled in before a contract\n          can be saved. A hidden type's stored remark is kept: it is only not shown for editing.\n        </p>\n\n        <div class=\"cws:overflow-x-auto\">\n          <table class=\"cws:w-full cws:text-sm\">\n            <caption class=\"sr-only\">Remark type settings</caption>\n            <thead class=\"cws:border-y cws:border-slate-200 cws:text-left cws:text-xs cws:dark:border-slate-700\">\n              <tr>\n                <th scope=\"col\" class=\"cws:px-3 cws:py-2 cws:font-medium\">Remark type</th>\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Visible</th>\n                <th scope=\"col\" class=\"cws:px-2 cws:py-2 cws:font-medium\">Required</th>\n              </tr>\n            </thead>\n            <tbody>\n              @for (remark of remarks; track remark.code) {\n                <tr class=\"cws:border-b cws:border-slate-100 cws:dark:border-slate-800\" [attr.data-remark-type]=\"remark.code\">\n                  <th scope=\"row\" class=\"cws:px-3 cws:py-1.5 cws:text-left cws:font-normal\">\n                    {{ remark.label }}\n                    <code class=\"cws:ml-1 cws:text-xs cws:text-slate-400\">{{ remark.code }}</code>\n                  </th>\n                  <td class=\"cws:px-2 cws:py-1.5\">\n                    <input\n                      type=\"checkbox\"\n                      [checked]=\"remark.visible\"\n                      [disabled]=\"remark.required\"\n                      (change)=\"setRemarkFlag(remark.code, 'visible', $any($event.target).checked)\"\n                      [attr.aria-label]=\"remark.label + ' remark visible'\"\n                    />\n                  </td>\n                  <td class=\"cws:px-2 cws:py-1.5\">\n                    <input\n                      type=\"checkbox\"\n                      [checked]=\"remark.required\"\n                      (change)=\"setRemarkFlag(remark.code, 'required', $any($event.target).checked)\"\n                      [attr.aria-label]=\"remark.label + ' remark required'\"\n                    />\n                  </td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      </div>\n    }\n\n    @if (columnsNotKept()) {\n      <!--\n        #748: the row WAS saved; only the column list was not kept. Saving again would repeat the\n        save, so the only action offered is to close, and the list has to wait for #747.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-columns-not-kept>\n        <div class=\"scoular-alert-title\">Saved, except the home grid columns</div>\n        <div class=\"scoular-alert-description\">\n          The rest of this configuration was saved. The server did not keep the column list, because it\n          cannot store one yet, so this trade unit's grid still shows every column.\n        </div>\n      </div>\n    }\n\n    @if (everyTradeUnitPending()) {\n      <!--\n        #844: a row for every trade unit takes a second, deliberate click. The Dev walk made one by\n        mistake with a seed set, so the seed is named: seeding copies settings, it does not pick the\n        trade unit the row applies to.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"alert\" data-every-trade-unit>\n        <div class=\"scoular-alert-title\">This configuration applies to every trade unit</div>\n        <div class=\"scoular-alert-description cws:space-y-2\">\n          <p>\n            @if (seededFrom(); as seed) {\n              Its settings are copied from trade unit {{ seed.tradeUnit }}, but it applies to every trade unit.\n            }\n            \"Applies to trade unit\" is set to any trade unit, so from its effective date this row is used\n            for every trade unit that has no more specific row of its own. To configure one trade unit,\n            pick it under \"Applies to trade unit\".\n          </p>\n          <div class=\"cws:flex cws:flex-wrap cws:gap-3\">\n            <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" [disabled]=\"saving()\" (click)=\"save(true)\">\n              {{ isNew() ? 'Create for every trade unit' : 'Save for every trade unit' }}\n            </button>\n            <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"everyTradeUnitPending.set(false)\">\n              Go back\n            </button>\n          </div>\n        </div>\n      </div>\n    }\n\n    <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-3\">\n      @if (columnsNotKept()) {\n        <button type=\"button\" class=\"scoular-btn scoular-btn-primary\" (click)=\"saved.emit()\">\n          Close\n        </button>\n      }\n\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-primary\"\n        [class.cws:hidden]=\"columnsNotKept()\"\n        [disabled]=\"saving() || columnsNotKept()\"\n        (click)=\"save()\"\n      >\n        {{ saving() ? 'Saving…' : isNew() ? 'Create configuration' : 'Save changes' }}\n      </button>\n\n      <button\n        type=\"button\"\n        class=\"scoular-btn scoular-btn-secondary\"\n        (click)=\"cancel()\"\n      >\n        Cancel\n      </button>\n    </div>\n  }\n</section>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		editing: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editing",
				required: false
			}]
		}],
		saved: [{
			type: i0.Output,
			args: ["saved"]
		}],
		cancelled: [{
			type: i0.Output,
			args: ["cancelled"]
		}]
	}
});
function rowRef(element, fieldAttribute, sectionAttribute) {
	const field = element.getAttribute(fieldAttribute);
	const section = element.getAttribute(sectionAttribute);
	return field === null || section === null || field === "" || section === "" ? null : {
		field,
		section
	};
}
function visibilityOf(sections) {
	const map = {};
	for (const section of sections) map[section.id] = section.visible;
	return map;
}
function sectionsOf$1(resolved, layout) {
	return resolved.map((section, index) => ({
		id: section.componentName,
		label: section.label,
		tab: section.tab,
		order: layout.find((known) => known.id === section.componentName)?.order ?? index + 1,
		visible: section.visible
	}));
}
function withSectionTabs(tabs, sections, layoutTabs) {
	const missing = layoutTabs.filter((tab) => !tabs.some((known) => known.id === tab.id) && sections.some((section) => section.tab === tab.id));
	return missing.length === 0 ? tabs : [...tabs, ...missing];
}
export { ADMIN_AREAS, AddendumTemplatesPageComponent, AdminPageComponent, BUILT_IN_SAMPLE_VALUES, BasisLocationsPageComponent, BuilderHistory, ContractTemplateEditorComponent, ContractTemplatesPageComponent, FORM_BUILDER_SAMPLE_VALUES, FormBuilderPageComponent, FormConfigAdminPageComponent, FormConfigEditorComponent, NOT_ONBOARDED_EXPLANATION, RolesPageComponent, SETTINGS_MANAGE, SYSTEM_TAB_IDS, TAB_HOVER_MS, UNDO_LIMIT, adminArea, adminRoutes, apply, assignedSentence, blockTab, emptyItems, fieldsOf, formBuilderLeaveGuard, idFromLabel, notATradeUnitMessage, orderedTabs, pendingSentence, pendingUntil, placedFieldsOf, previewPresentation, sectionsOf, tradeUnitLabel, typeNotAvailableMessage, unknownTradeUnitsMessage, unknownTypesMessage, withSetPresentationOnly };

//# sourceMappingURL=cws-features-admin.mjs.map
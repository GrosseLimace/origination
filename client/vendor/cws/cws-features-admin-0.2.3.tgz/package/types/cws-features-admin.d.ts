import * as i0 from "@angular/core";
import { DestroyRef, InjectionToken, OnInit } from "@angular/core";
import { Routes } from "@angular/router";
import { AddendumFieldMapping, AddendumTemplate, AddendumType, BasisLegacyEdits, BasisLocationPlaceRow, BasisLocationRegionRow, BasisLocationTermRow, BasisLocationTradeUnitSetting, BasisPlaceRule, CollectionBlock, ConfigCollectionBehaviour, ConfigDocument, ConfigFieldBehaviour, ConfigRemarkTypeBehaviour, ConfigSection, ConfigTab, ContractTemplate, DirectoryUser, FormConfigAuditTrail, FormConfigBundle, FormConfigDetail, FormConfigListResponse, FormConfigPreview, FormConfigRegistry, FormConfigResolutionKey, FormConfigRow, PendingRoleAssignment, RegistryField, Role, RoleAssignment, RoleAssignmentAnswer, UserDirectorySource } from "@cws/domain-contracts";
import { ConstraintDocument, ContractForm, FieldPresentation } from "@cws/shared-form-engine";
import { ExportField, GridRowAction, MutationOutcome, RemoteData } from "@cws/shared-ui";
import { Observable } from "rxjs";
/**
 * **How much of the Admin section's width a page needs** (the form builder, 2026-10-28).
 *
 * Provided by `AdminPageComponent` for its routed pages, and read by nothing outside this library. A page that
 * needs the section's whole width sets `wide` while it does, and the section's navigation steps aside for it.
 * The form builder is the one page that does, while a form is open on its canvas; its own heading, tabs and
 * pickers step aside in its template, and Discard brings all of it back.
 *
 * ⚠ Scoped to the section on purpose: the workspace's own layout (its top bar and the content area's width) is
 * not this library's to change, and every other admin page and screen is left exactly as it was.
 *
 * Optional to a page that injects it, so the builder mounted on its own (a spec, the playground) still works.
 */
declare class AdminLayout {
  /** `true` while a page needs the whole width: the section's navigation is hidden. */
  readonly wide: import("@angular/core").WritableSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<AdminLayout, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * **The Admin section's shell** (#825): the section's own navigation beside a routed page.
 *
 * Admin used to be one page stacking four unrelated areas. Each is now a route of its own (see
 * `adminRoutes()`), and this frames them: an Overview link, then each area this account may use, from
 * the one list the overview reads too (`ADMIN_AREAS`). A side list on a wide screen; a scrolling row
 * above the page on a narrow one.
 *
 * ⚠ **Kept as `AdminPageComponent`, selector `cms-admin-page`**, though it is now a shell: the class
 * is published, and the embedding host's provider closure is keyed on it.
 *
 * Provides `AdminScope` for the section, read once (#696): the navigation and the overview hide an
 * Admin-only area from an account KNOWN not to hold Admin, and the pages read the same answer.
 *
 * ⚠ The links are relative to this component's route, so under a host they stay inside its prefix.
 */
export declare class AdminPageComponent {
  private readonly access;
  /** Whether a page has asked for the section's whole width (the form builder, with a form open). */
  protected readonly layout: AdminLayout;
  protected readonly gridClass: import("@angular/core").Signal<"cws:grid cws:gap-6" | "cws:grid cws:gap-6 cws:lg:grid-cols-[13rem_minmax(0,1fr)]">;
  /** The areas this account may use. Unknown is not "not Admin": the server decides. */
  protected readonly areas: import("@angular/core").Signal<import("@cws/features-admin").AdminArea[]>;
  protected readonly linkClass = "cws:block cws:whitespace-nowrap cws:rounded cws:px-3 cws:py-2 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60 cws:aria-[current=page]:bg-slate-100 cws:aria-[current=page]:text-scoular-blue cws:dark:aria-[current=page]:bg-slate-700 cws:dark:aria-[current=page]:text-sky-300";
  static ɵfac: i0.ɵɵFactoryDeclaration<AdminPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AdminPageComponent, "cms-admin-page", never, {}, {}, never, never, true, never>;
}
/**
 * **The Admin section's pages, as children of `AdminPageComponent`** (#825).
 *
 * One route per administrative job, from `ADMIN_AREAS`; an area's tabs are child routes, so each is
 * linkable and Back moves between them. A page receives its tab as `data.view`, bound to its `view`
 * input by `withComponentInputBinding()` (the router feature the workspace already requires of a host).
 * Mounted on its own, without a `view`, a page renders every view at once, as it did on the old single
 * page, which is what its spec and the playground's single-page routes rely on.
 *
 * ⚠ A path the section does not have lands on the overview rather than on a blank outlet.
 *
 * A function, like `cwsRoutes()`, so every caller gets its own array.
 */
export declare function adminRoutes(): Routes;
/**
 * **The Admin section's areas, in one place** (#825).
 *
 * The shell's navigation, the overview's cards and the route table all read this list, so the three
 * cannot disagree about what Admin contains, what an area is called, or who sees it.
 *
 * Each area is one administrative job, with a route of its own. `views` are the tabs inside one job:
 * closely related views that share its title and purpose, each with a route of its own as well, so a
 * tab can be linked to and the browser's Back button moves between them.
 */
export interface AdminView {
  /** The view's segment under its area. `''` is the area's default view. */
  readonly path: string;
  readonly label: string;
}
export interface AdminArea {
  /** The area's segment under `admin`. */
  readonly path: string;
  readonly title: string;
  /** One sentence for the overview card and the navigation's description. */
  readonly summary: string;
  /**
   * Shown only to an account that is not KNOWN to lack the Admin role (#696). Unknown still sees it,
   * because hiding an Admin's area while `/me` is slow would be the worse failure; the server decides.
   */
  readonly adminOnly: boolean;
  /** The area's tabs, or none. */
  readonly views: readonly AdminView[];
}
export declare const ADMIN_AREAS: readonly AdminArea[];
/** An area by its path. Throws for a path the list does not hold, which is a programming error. */
export declare function adminArea(path: string): AdminArea;
/**
 * **The placeholders in a template's text, and the field each one prints** (#924).
 *
 * Pure, so the page, the mapping list and the preview read one answer, and each rule here can be shown
 * to fire against a fixture built to break it.
 *
 * ### 🔴 The pattern is the server's, character for character
 *
 * `AddendumRules.PlaceholderPattern` is `\{\{\s*(?<name>[A-Za-z0-9_]+)\s*(?:\|\s*(?<print>[a-z]+)\s*)?\}\}`:
 * a name, then an optional print type after a bar (`{{ settle_date | date }}`, #1045). A placeholder this
 * screen did not see would reach the server unmapped and be refused there; one it saw that the server
 * does not would be mapped for nothing. The e-signature anchors (`{{sig__es_:signer1:signature}}`)
 * carry colons, so neither side matches them. Group 1 is the name either way; the print type is the
 * server's to apply, so nothing here reads it.
 */
declare const PLACEHOLDER_PATTERN: RegExp;
/** The placeholder names in a template's text, each once, in the order they first appear. */
declare function templatePlaceholders(content: string | null | undefined): string[];
/**
 * The mapping the editor holds: placeholder to field. `''` is a placeholder the administrator left
 * with no field on purpose, which is different from one never touched (absent), because only an
 * untouched one takes a suggestion.
 */
type PlaceholderMappings = Readonly<Record<string, string>>;
/** The editor's mappings from a template's saved ones. */
declare function mappingsOf(fields: readonly AddendumFieldMapping[]): PlaceholderMappings;
/** One line of the placeholder list. */
interface PlaceholderRow {
  readonly placeholder: string;
  /** The field it prints, or `''` for none yet. */
  readonly field: string;
  /**
   * `false` for a mapping a saved template carries whose placeholder is no longer in the text. Kept,
   * and sent, until removed: dropping it on an unrelated save would change the template's version.
   */
  readonly inText: boolean;
  /** The field came from a name match, not from a pick. Shown, so it is never mistaken for a choice. */
  readonly suggested: boolean;
}
/**
 * The list the screen shows: every placeholder in the text, in order, then every saved mapping whose
 * placeholder the text no longer holds.
 *
 * `suggest` names the field a placeholder's own name matches exactly, if any. It fills only a
 * placeholder the administrator has not touched.
 */
declare function placeholderRows(content: string | null | undefined, mappings: PlaceholderMappings, suggest?: (placeholder: string) => string | null): PlaceholderRow[];
/** The placeholders in the text that print nothing yet: the server refuses these, so the screen does first. */
declare function unmappedPlaceholders(rows: readonly PlaceholderRow[]): string[];
/**
 * The server's sentence for unmapped placeholders (`AddendumRules.FieldProblems`), sorted as it sorts
 * them, so the refusal reads the same whichever side says it.
 */
declare function unmappedPlaceholdersMessage(placeholders: readonly string[]): string;
/**
 * What a save sends as `fields`: every mapped row, in the list's order (the text's, then the kept
 * mappings). The same `{ placeholder, field }` pairs as the old box sent. ⚠ Order carries nothing: the
 * server sorts by placeholder before it compares or stores (`AddendumAdminService.TemplateDraft`), so a
 * template opened and saved unchanged keeps its version.
 */
declare function fieldsOf$1(rows: readonly PlaceholderRow[]): AddendumFieldMapping[];
/** One field the picker offers. */
interface FieldOption {
  readonly value: string;
  readonly label: string;
}
/** A group of them, one `<optgroup>`. */
interface FieldOptionGroup {
  readonly label: string;
  readonly options: readonly FieldOption[];
}
/**
 * The CWS `addendum_*` fields a template's special types carry, one group per product.
 *
 * With no picked type that selects a product (none picked yet, or a StoneX type), every product's
 * fields are offered, each under its product's name, because hiding them all would leave nothing to
 * pick while the types are still being chosen.
 */
declare function addendumFieldGroups(specialTypes: readonly string[]): FieldOptionGroup[];
/** One field the server fills in itself, so neither the trader nor CTRM supplies it. */
interface ServerSuppliedField {
  readonly field: string;
  readonly label: string;
  /** Address line 2 and phone: an empty one drops its line. Every other field refuses a blank at render. */
  readonly optional: boolean;
  /** What the preview prints for it: invented, and recognisable as such. */
  readonly sample: string;
}
/** One group of them, offered under its own heading. */
interface ServerSuppliedFieldGroup {
  readonly label: string;
  readonly fields: readonly ServerSuppliedField[];
}
/**
 * **The fields the server supplies at render** (#1027, #1037; #1038): the contract customer's
 * merchandising name and address from the GraphQL customer master, and the addendum date the server
 * stamps.
 *
 * 🔴 **The authority is the server's `AddendumRules`** (`src/Scoular.Contracts.Application/Addendums/
 * AddendumRules.cs`: `AddendumDateField`, `CustomerFields`, `OptionalCustomerFields`), which refuses
 * any other `customer.*` or dotted field by name. No route serves the list, so this is the frontend's
 * ONE copy, and `addendum-placeholders.spec.ts` holds it to that file: a field added or renamed there
 * turns the spec red rather than leaving the picker a field short. Nothing else on the frontend may
 * restate these names; read them from here.
 */
declare const SERVER_SUPPLIED_FIELD_GROUPS: readonly ServerSuppliedFieldGroup[];
/** The server-supplied fields as picker groups, offered after the `addendum_*` fields and before CTRM's. */
declare function serverFieldGroups(): FieldOptionGroup[];
/**
 * Whether the server refuses a CTRM field on a template (`AddendumRules.FieldProblems`).
 *
 * - A field `constraints.json` flags `rewrittenOnWrite`: the addendum would print the value sent, not
 *   the one CTRM stores.
 * - A description of such a code (`AddendumRules.DescriptionsOfRewrittenCodes`: `text_description`,
 *   `language_description`, `price_market_month_description`, `hedge_market_month_description`). Read
 *   from the document as `<base>_description` describing `<base>` or `<base>_code`, so the list is not
 *   restated here. ⚠ The server's table stays the authority, and a spec pins these four.
 */
declare function refusedOnTemplate(document: ConstraintDocument, field: string): boolean;
/**
 * The CTRM fields a template may print: every `GET /meta/constraints` field the server accepts on a
 * template, by name. Never a hand-written list (ADR-7).
 */
declare function ctrmFieldGroup(document: ConstraintDocument): FieldOptionGroup;
/**
 * The field a placeholder's own name matches exactly, among those offered: `{{contract_number}}` to
 * `contract_number`, or `{{call_strike}}` to `addendum_call_strike`. Anything less than exact is left to
 * the administrator.
 */
declare function suggestedField(placeholder: string, groups: readonly FieldOptionGroup[]): string | null;
/** One run of the preview: template text, a sample value, or a placeholder that would print blank. */
interface PreviewSegment {
  readonly kind: 'text' | 'value' | 'missing';
  readonly text: string;
}
/**
 * A sample value for a field, by what kind of value it holds. Invented and recognisable as such: a
 * text value is the field's own name in brackets, so nothing in a preview can be read as real data.
 */
declare function sampleValueFor(field: string, document: ConstraintDocument | null): string;
/**
 * The draft as it would read with sample values (#924): each mapped placeholder replaced by a sample
 * of its field, each unmapped one marked. The anchors pass through, as they do on the server.
 */
declare function previewSegments(content: string, rows: readonly PlaceholderRow[], document: ConstraintDocument | null): PreviewSegment[];
/** A placeholder's field, as the list reports a change to it. */
interface PlaceholderFieldChange {
  readonly placeholder: string;
  readonly field: string;
}
/**
 * **The template's placeholders, each with the field it prints** (#924). Replaces the free-text
 * `placeholder = field` box.
 *
 * The rows come from the text as it is typed (`placeholderRows`), so nothing is typed twice. Each has
 * a picker of the fields on offer: the special types' `addendum_*` fields, the ones the server fills
 * in itself (#1038), then CTRM's from `GET /meta/constraints`. A row with no field says so here, before Save, because it would print blank.
 *
 * - **With no CTRM list** (`ctrmListed` false: no constraint source, or it could not be read), each row
 *   is a text box suggesting the `addendum_*` fields, and the server stays the check. Never an empty
 *   picker, which would leave a CTRM field impossible to choose.
 * - **A field the lists do not hold** (a template saved against an older list) is shown and kept,
 *   flagged, never dropped: dropping it would change the template on an unrelated save.
 * - **A saved mapping whose placeholder left the text** is listed below the rest, with a Remove. It is
 *   kept until removed, for the same reason.
 */
declare class AddendumPlaceholderFieldsComponent {
  readonly rows: import("@angular/core").InputSignal<readonly PlaceholderRow[]>;
  readonly groups: import("@angular/core").InputSignal<readonly FieldOptionGroup[]>;
  /** Whether CTRM's fields are among the groups. Without them each row is a text box. */
  readonly ctrmListed: import("@angular/core").InputSignal<boolean>;
  readonly describedBy: import("@angular/core").InputSignal<string | null>;
  readonly invalid: import("@angular/core").InputSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly fieldChange: import("@angular/core").OutputEmitterRef<PlaceholderFieldChange>;
  readonly removed: import("@angular/core").OutputEmitterRef<string>;
  protected readonly listId: string;
  protected readonly example = "{{contract_number}}";
  protected readonly offered: import("@angular/core").Signal<Set<string>>;
  protected braces(placeholder: string): string;
  protected pick(placeholder: string, field: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AddendumPlaceholderFieldsComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AddendumPlaceholderFieldsComponent, "cws-addendum-placeholder-fields", never, {
    "rows": {
      "alias": "rows";
      "required": true;
      "isSignal": true;
    };
    "groups": {
      "alias": "groups";
      "required": true;
      "isSignal": true;
    };
    "ctrmListed": {
      "alias": "ctrmListed";
      "required": false;
      "isSignal": true;
    };
    "describedBy": {
      "alias": "describedBy";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "fieldChange": "fieldChange";
    "removed": "removed";
  }, never, never, true, never>;
}
/** One code a picker offers, with the words shown for it. */
interface CodeOption {
  readonly code: string;
  readonly label: string;
}
/**
 * **Several codes picked from a list, with typeahead** (#814). No free text where a list exists.
 *
 * The codes picked show as chips, each with its own Remove. The search box narrows the list and is
 * never the value: Enter adds the highlighted match, or the code typed exactly; a code the list does
 * not hold is refused here with `unknownMessage`, the server's own sentence, so it is said before
 * Save rather than after it.
 *
 * - **Keyboard:** the arrow keys and Home/End move the highlighted match (`aria-activedescendant`),
 *   Enter adds it, Escape closes the list, and Backspace in an empty box removes the last chip.
 * - **Mouse:** a click on the box opens the list, which its dropdown caret promises (2026-10-28).
 * - **A code already picked that the list does not hold** (a template saved before a location went)
 *   is shown and flagged, never dropped: dropping it would change the template on an unrelated save.
 * - **With no list** (`options` is `null`, a host without the source), it is the comma-separated text
 *   box it replaces, and the server stays the only check.
 *
 * ⚠ The server's checks stay the authority. This says their sentences earlier; it decides nothing
 * they do not.
 */
declare class AdminCodePickerComponent {
  readonly label: import("@angular/core").InputSignal<string>;
  /** The form name, for the input. */
  readonly name: import("@angular/core").InputSignal<string | null>;
  readonly codes: import("@angular/core").InputSignal<readonly string[]>;
  /** What may be picked, or `null` when no list is available here (then it is a text box). */
  readonly options: import("@angular/core").InputSignal<readonly CodeOption[] | null>;
  /** The sentence for codes the list does not hold, as the server words it. */
  readonly unknownMessage: import("@angular/core").InputSignal<(codes: readonly string[]) => string>;
  /** Said under the picker when nothing is picked, e.g. what an empty list means. */
  readonly emptyMeaning: import("@angular/core").InputSignal<string | null>;
  /** Said under the picker always, e.g. that the list comes from a simulator. */
  readonly note: import("@angular/core").InputSignal<string | null>;
  readonly searchPlaceholder: import("@angular/core").InputSignal<string>;
  readonly freePlaceholder: import("@angular/core").InputSignal<string | null>;
  readonly describedBy: import("@angular/core").InputSignal<string | null>;
  readonly invalid: import("@angular/core").InputSignal<boolean>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly codesChange: import("@angular/core").OutputEmitterRef<readonly string[]>;
  protected readonly labelId: string;
  protected readonly listId: string;
  protected readonly term: import("@angular/core").WritableSignal<string>;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  protected readonly active: import("@angular/core").WritableSignal<number>;
  protected readonly refusal: import("@angular/core").WritableSignal<string | null>;
  /** The options that match what is typed, not already picked, at most {@link MAX_MATCHES}. */
  protected readonly matches: import("@angular/core").Signal<readonly CodeOption[]>;
  protected readonly activeId: import("@angular/core").Signal<string | null>;
  protected optionId(index: number): string;
  protected known(code: string): boolean;
  protected chipLabel(code: string): string;
  protected onInput(value: string): void;
  protected onKeydown(event: KeyboardEvent): void;
  /**
   * Enter: the code typed exactly wins, then the highlighted match; anything else is refused with
   * the server's sentence and nothing is added.
   */
  private commit;
  protected add(code: string): void;
  protected remove(code: string): void;
  /**
   * The text box's own text, with no list. Kept as typed while it still parses to the same codes, so
   * typing "MNC, " is not rewritten to "MNC" under the caret before the next code is typed.
   */
  protected readonly freeText: import("@angular/core").WritableSignal<string>;
  protected onFreeInput(value: string): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<AdminCodePickerComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AdminCodePickerComponent, "cws-admin-code-picker", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "name": {
      "alias": "name";
      "required": false;
      "isSignal": true;
    };
    "codes": {
      "alias": "codes";
      "required": false;
      "isSignal": true;
    };
    "options": {
      "alias": "options";
      "required": false;
      "isSignal": true;
    };
    "unknownMessage": {
      "alias": "unknownMessage";
      "required": true;
      "isSignal": true;
    };
    "emptyMeaning": {
      "alias": "emptyMeaning";
      "required": false;
      "isSignal": true;
    };
    "note": {
      "alias": "note";
      "required": false;
      "isSignal": true;
    };
    "searchPlaceholder": {
      "alias": "searchPlaceholder";
      "required": false;
      "isSignal": true;
    };
    "freePlaceholder": {
      "alias": "freePlaceholder";
      "required": false;
      "isSignal": true;
    };
    "describedBy": {
      "alias": "describedBy";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "codesChange": "codesChange";
  }, never, never, true, never>;
}
/** The Addendums page's views (#825). */
export type AddendumsView = 'all' | 'templates' | 'types';
/** What a list is doing. `unavailable` is a host whose API does not offer the route. */
type ListState$2 = {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
} | {
  readonly status: 'unavailable';
  readonly reason: string;
} | {
  readonly status: 'failed';
  readonly message: string;
  readonly correlationId?: string;
};
/** The editor's working copy. Plain fields, `ngModel`-bound and read only on Save. */
interface TemplateEditor {
  id: number | null;
  version: number | null;
  /** The `rowVersion` the editor opened on, sent back on `If-Match`. Null for a new template. */
  rowVersion: string | null;
  name: string;
  /** Special-type codes, picked from the addendum types (#814). */
  specialTypes: string[];
  language: string;
  contentFormat: string;
  /** CTRM location codes, picked from the location list (#814). Empty serves every trade unit. */
  tradeUnits: string[];
  active: boolean;
}
/**
 * The editor fields a `400`'s `errors.<key>` can land on, keyed as the server keys them
 * (`AddendumRules`). A key outside this list (`If-Match`, `actor`) is not a field, so its reason is
 * shown with the form's own error instead of being dropped.
 */
declare const EDITOR_FIELDS: readonly ["name", "specialTypes", "language", "tradeUnits", "contentFormat", "templateContent", "fields"];
type EditorField$1 = (typeof EDITOR_FIELDS)[number];
/**
 * The server's sentences for codes it does not know (`AddendumAdminService`), said here first (#814).
 * The trade-unit one drops the server's internal correction tag, which means nothing to a user.
 */
export declare function unknownTypesMessage(codes: readonly string[]): string;
export declare function unknownTradeUnitsMessage(codes: readonly string[]): string;
/**
 * What "not onboarded" means, said under the trade units wherever the indicator shows (#924). An
 * addendum is generated by a contract save, and a save is refused in a trade unit with no form
 * configuration, so a template is not used there until the trade unit is onboarded.
 */
export declare const NOT_ONBOARDED_EXPLANATION: string;
/** The sentence for a picked special type Legal has not made available (#924). */
export declare function typeNotAvailableMessage(code: string): string;
/**
 * **Addendum templates (F10.3b).** List, create, edit, deactivate and delete, with the version shown.
 *
 * ### 🔴 Save is refused HERE, before any request, when the anchors are wrong
 *
 * Legal requires a separate signature anchor and initials anchor on every template, and the signing
 * matcher refuses the `sig10__es_` form. A template that reached the server without them would be
 * refused there at best, and at worst stored and used, producing a document nobody can sign where
 * Legal requires. So the rule runs on Save and its reasons sit beside the content field, where the
 * administrator is looking when they paste in the approved text.
 *
 * ### The #624 contract (ADR-19, #676)
 *
 * A template serves one or more special types, carries a language and a content format, and maps
 * each placeholder to a field. Edits, deactivations and deletes go back on the `rowVersion` the list
 * gave; a stale one is a `409`, shown as *changed since you opened it* with a Reload, and never
 * retried. A `400`'s reasons land beside the field the server named.
 *
 * A host whose API lacks the routes still gets *not available yet*, never an empty table, which would
 * read as "there are no templates".
 *
 * The addendum types sit above the templates, in `AddendumTypesSectionComponent` (#798): code,
 * display name, family and whether Legal has made them available, created and edited there. A
 * template is offered on a record only for an available type.
 *
 * ⚠ **Deactivate and Delete are different on purpose.** Deactivating keeps the template and its
 * version history and stops it being offered on a record; deleting removes it, so it asks first.
 *
 * ### #924: set up from one form
 *
 * - **Placeholders are read from the content as it is typed**, each with a field picker
 *   (`AddendumPlaceholderFieldsComponent`): the special types' `addendum_*` fields, and CTRM's from
 *   `GET /meta/constraints` (`CONSTRAINT_SOURCE`, optional; without it, or when it cannot be read, each
 *   row is a text box). One with no field is shown before Save and refused there with the server's
 *   sentence. What is sent is the same `fields` list as before, so templates load and save unchanged.
 * - **Preview** shows the draft's text with sample values, here, before anything is saved. It is the
 *   text, not the PDF: the server previews only a SAVED template, from a contract.
 * - **Each required anchor is ticked off as it is typed.** Save still refuses a missing one.
 * - **#1038:** the picker also offers the fields the server fills in itself (the customer master and
 *   the addendum date, `SERVER_SUPPLIED_FIELD_GROUPS`), and "This text has no initials line" sends
 *   `initialsAnchorOptional`, which waives the initials anchor only. It is always sent, so re-saving a
 *   template that has no initials line keeps it so.
 * - **Where it is offered:** a picked special type that is not available says so with a Make
 *   available (after asking, because availability is Legal's approval), and "not onboarded" is
 *   explained under the trade units.
 */
export declare class AddendumTemplatesPageComponent {
  /**
   * Which of the page's views to show (#825): the templates, the types, or `all` of it as on the old
   * single Admin page. The Admin routes set it from `data.view`; mounted on its own the page shows both.
   */
  readonly view: import("@angular/core").InputSignalWithTransform<AddendumsView, AddendumsView | null | undefined>;
  protected readonly showTemplates: import("@angular/core").Signal<boolean>;
  protected readonly showTypes: import("@angular/core").Signal<boolean>;
  /** True when routed as one of the section's tabs, which is when the tabs are shown. */
  protected readonly routed: import("@angular/core").Signal<boolean>;
  protected readonly area: import("@cws/features-admin").AdminArea;
  private readonly source;
  private readonly typeSource;
  /** CTRM's field list for the placeholder pickers (#924). Optional: without it the rows are text boxes. */
  private readonly constraintSource;
  private readonly access;
  /**
   * The addendum types, read each time the editor opens so a type created above is offered at once
   * (#814). `null` while unread or when not available here; the picker is then a text box.
   */
  private readonly types;
  /** The special types on offer, each saying whether Legal has approved it. Unapproved stays pickable. */
  protected readonly typeOptions: import("@angular/core").Signal<readonly CodeOption[] | null>;
  /** Every CTRM location, with the onboarded indicator when `/me` has answered (#696). */
  protected readonly tradeUnitOptions: import("@angular/core").Signal<readonly CodeOption[] | null>;
  /**
   * Said under the trade units when the list is the simulator's (#814): on Dev that is a handful of
   * locations, and a real one such as 2087 is refused there. Read from the list, never hard-coded.
   */
  protected readonly tradeUnitNote: import("@angular/core").Signal<string | null>;
  protected readonly unknownTypesMessage: typeof unknownTypesMessage;
  protected readonly unknownTradeUnitsMessage: typeof unknownTradeUnitsMessage;
  protected readonly typeNotAvailableMessage: typeof typeNotAvailableMessage;
  /**
   * Why the template writes are not offered, or `null`. Every template route is Admin-only on the
   * server, so an account KNOWN not to hold the role sees them disabled with this reason rather than
   * meeting a 403 (#696). Unknown is not refused: the server decides then.
   */
  protected readonly writesRefused: import("@angular/core").Signal<"Needs the Admin role" | null>;
  private readonly confirm;
  private readonly destroyRef;
  /** The three anchors, for the editor's help text. From the domain library, never retyped. */
  protected readonly anchors: string[];
  protected readonly contentFormats: readonly ["text/plain", "text/x-cws-addendum"];
  /**
   * #1115: the markup's authoring reference (grammar, the `@cws 1` first line, the `|date` and
   * `|number` print types, and that authors never escape values), from the host's links: the shell
   * configures `docs/addendumns/MARKUP.md` on GHE. `null` renders no link.
   */
  protected readonly markupReferenceUrl: string | null;
  protected readonly offered: boolean;
  protected readonly state: import("@angular/core").WritableSignal<ListState$2>;
  protected readonly unavailableReason: import("@angular/core").Signal<string | null>;
  protected readonly failure: import("@angular/core").Signal<{
    readonly status: "failed";
    readonly message: string;
    readonly correlationId?: string;
  } | null>;
  protected readonly templates: import("@angular/core").WritableSignal<readonly AddendumTemplate[]>;
  protected readonly editor: import("@angular/core").WritableSignal<TemplateEditor | null>;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  /** The template text being edited. A signal, so the placeholders and anchors follow it as it is typed (#924). */
  protected readonly content: import("@angular/core").WritableSignal<string>;
  /** Placeholder to field, as picked. Absent is untouched; `''` is no field, on purpose. */
  private readonly mappings;
  /** CTRM's constraint document, read once when an editor first opens; `null` when not available here. */
  private readonly constraints;
  private constraintsRequested;
  /** Whether CTRM's fields are on offer. Without them each placeholder's field is typed. */
  protected readonly ctrmListed: import("@angular/core").Signal<boolean>;
  /**
   * The fields a placeholder may print: the picked types' `addendum_*` fields, then the ones the server
   * fills in itself (the customer master and the addendum date, #1038), then CTRM's.
   */
  protected readonly fieldGroups: import("@angular/core").Signal<FieldOptionGroup[]>;
  /** Every placeholder in the text, with its field, then the saved mappings the text no longer uses. */
  protected readonly placeholderRows: import("@angular/core").Signal<PlaceholderRow[]>;
  /** Placeholders that would print blank: shown as they appear, and refused on Save. */
  protected readonly unmapped: import("@angular/core").Signal<string[]>;
  /** Whether the preview is open. It follows the text and the picks while it is. */
  protected readonly previewOpen: import("@angular/core").WritableSignal<boolean>;
  protected readonly preview: import("@angular/core").Signal<PreviewSegment[]>;
  /**
   * "This text has no initials line" (#1038), the template's `initialsAnchorOptional`. A signal, so
   * the anchor checklist follows it. Only the initials anchor is waived, as on the server.
   */
  protected readonly initialsOptional: import("@angular/core").WritableSignal<boolean>;
  /**
   * Each anchor, and whether the text holds it yet (#924). With no initials line the initials anchor
   * is listed as not required rather than as missing (#1038).
   */
  protected readonly anchorChecks: import("@angular/core").Signal<{
    anchor: string;
    present: boolean;
    required: boolean;
  }[]>;
  /**
   * The picked special types Legal has not made available (#924): the template is not offered for
   * them. A code the list does not know is the picker's to flag, so it is not repeated here.
   */
  protected readonly unavailableTypes: import("@angular/core").Signal<AddendumType[]>;
  /** Whether the type writes behind Make available are wired here at all. */
  protected readonly typeWritesOffered: boolean;
  /**
   * Each template's actions, for its ⋯ menu (#825; they were three inline buttons). Deactivate on an
   * active template only, as before; Delete still asks first (`remove`). Every write is refused with
   * the same reason the buttons gave: in flight, or the Admin role (#696).
   */
  protected readonly templateActions: import("@angular/core").Signal<Map<number, GridRowAction<AddendumTemplate>[]>>;
  /** Why the editor's content would be refused here, before any request. Shown beside the content. */
  protected readonly anchorProblems: import("@angular/core").WritableSignal<readonly string[]>;
  /** A field's reasons, from this screen's own checks or a server `400`, keyed as the server keys them. */
  protected readonly fieldErrors: import("@angular/core").WritableSignal<Partial<Record<"name" | "specialTypes" | "language" | "tradeUnits" | "contentFormat" | "templateContent" | "fields", readonly string[]>>>;
  /** Everything said beside the content field: the anchor checks here, then the server's reasons. */
  protected readonly contentProblems: import("@angular/core").Signal<string[]>;
  /**
   * The last write's outcome (#803): its success, or its failure with the server's reference. A
   * field's own reasons still sit beside the field; this says whether anything was saved.
   */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /** A `409`: the failure offers a Reload. It is never retried. */
  protected readonly reloadOffered: import("@angular/core").WritableSignal<boolean>;
  constructor();
  /** Reads the addendum types for the special-type picker. A failure leaves the text box. */
  private loadTypes;
  /**
   * Reads CTRM's constraint document once, for the placeholder pickers (#924). 🔴 **Fails soft**: a
   * failed read leaves the rows as text boxes with a sentence saying so, never an error over the form,
   * because the server checks every field on Save whether or not this list was read.
   */
  private loadConstraints;
  protected load(): void;
  /** After a `409`: drop the stale editor and read the current rows. Nothing was saved. */
  protected reload(): void;
  protected errorsFor(field: EditorField$1): readonly string[];
  protected startCreate(): void;
  protected startEdit(template: AddendumTemplate): void;
  protected cancelEdit(): void;
  /** A placeholder's field, picked or typed. */
  protected setField(change: PlaceholderFieldChange): void;
  /** Drops a saved mapping whose placeholder the text no longer holds. */
  protected removeMapping(placeholder: string): void;
  protected togglePreview(): void;
  /**
   * Makes a picked special type available from the template form (#924), so one template can be made
   * usable without leaving it. 🔴 **It asks first**: availability is Legal's approval of the type, and
   * once it is set every active template for the type is offered on a record. A `409` re-reads the
   * types and is never retried.
   */
  protected makeAvailable(type: AddendumType): void;
  protected clearOutcome(): void;
  /**
   * Validates, then sends. 🔴 **Nothing is sent while the anchors are wrong** — the refusal is the
   * point, so it returns before the source is touched. The same for a blank name, no special type,
   * or a placeholder with no field (#924), which would print blank.
   */
  protected save(): void;
  protected deactivate(template: AddendumTemplate): void;
  /** Deletes after asking. The confirmation names the template, so the answer is not a guess. */
  protected remove(template: AddendumTemplate): void;
  protected tradeUnitsLabel(template: AddendumTemplate): string;
  /** A picker's new codes, into the editor's working copy. */
  protected setCodes(field: 'specialTypes' | 'tradeUnits', codes: readonly string[]): void;
  private open;
  /**
   * Sends one write, then re-reads the list: the server's version number is the one shown.
   *
   * A `400` puts each `errors.<field>` beside its field; a key that is no field (`If-Match`) is said
   * with the form. A `409` is the conflict, with its Reload.
   */
  private run;
  static ɵfac: i0.ɵɵFactoryDeclaration<AddendumTemplatesPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<AddendumTemplatesPageComponent, "cws-addendum-templates-page", never, {
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The form-configuration page's views (#825). */
export type FormConfigView = 'all' | 'rows' | 'preview';
/**
 * **Form configuration administration** (ADR-17, implementation brief §10.5).
 *
 * Two halves, and the second is the valuable one.
 *
 * ### The list
 *
 * Every configuration row including inactive ones, with its dimensions rendered as *Any* where they
 * are null — because a blank cell in a dimension column reads as missing data when it actually means
 * "this row applies to everything". Deactivating is soft and sends the row's `rowVersion`, so a
 * concurrent edit is a message rather than a silent overwrite.
 *
 * ### 🔑 The preview tool, and why it is not optional
 *
 * Pick any combination of dimensions and see **which row wins and why**. The resolution rules are
 * match-count-first with a significance tie-break over up to three dimensions and an effective date
 * (brief §6) — which is simple to state and genuinely hard to hold in your head once a dozen rows
 * exist. Without a preview, an admin's only way to check their work is to open a real contract and
 * infer the answer from the fields, and the answer they most need is for a combination no contract
 * they have to hand happens to be.
 *
 * It calls the **same** `resolve` endpoint the record screen calls, deliberately: a preview with its
 * own copy of the ranking rules would be a second answer to "which configuration wins", and the one
 * place an admin looks to check their work is the last place that should be able to disagree with
 * production.
 *
 * ### What this screen does NOT do yet
 *
 * There is no editor here. Creating and updating rows are `POST`/`PUT` on the same API and the
 * validation is already server-side with RFC 7807 errors — the missing piece is a field-by-field
 * grid with Required auto-checking Visible and non-configurable rows locked, which is real UI work
 * and is stated as absent rather than half-built. Read-and-preview is what makes the configuration
 * already in the database *legible*, which is the part nothing else provides.
 */
export declare class FormConfigAdminPageComponent {
  private readonly source;
  /**
   * Which of the page's views to show (#825): the configuration rows, the preview tool, or `all` of
   * it as on the old single Admin page. The Admin routes set it from `data.view`; mounted on its own
   * the page shows everything, so its spec and the playground's route are unchanged.
   */
  readonly view: import("@angular/core").InputSignalWithTransform<FormConfigView, FormConfigView | null | undefined>;
  protected readonly showRows: import("@angular/core").Signal<boolean>;
  protected readonly showPreview: import("@angular/core").Signal<boolean>;
  /** True when routed as one of the section's tabs, which is when the tabs are shown. */
  protected readonly routed: import("@angular/core").Signal<boolean>;
  protected readonly area: import("@cws/features-admin").AdminArea;
  /** Bumped after a deactivate, and by Retry, so the list genuinely re-reads. */
  private readonly attempt;
  protected readonly listState: import("@angular/core").WritableSignal<RemoteData<FormConfigListResponse>>;
  protected readonly rows: import("@angular/core").Signal<readonly FormConfigRow[]>;
  /**
   * Whether the rows came from a durable store.
   *
   * Said out loud for the same reason the grid names its data origin: no deployed environment has a
   * connection string today, so the honest answer is usually "in memory, gone on restart" — and an
   * admin who saves a configuration that vanishes on the next deploy without being told is owed an
   * explanation nobody can give them afterwards.
   */
  protected readonly storeOrigin: import("@angular/core").Signal<string | null>;
  protected readonly notDurable: import("@angular/core").Signal<boolean>;
  protected previewType: string;
  protected previewLocation: string;
  protected previewCommodity: string;
  protected previewContract: string;
  protected readonly previewState: import("@angular/core").WritableSignal<RemoteData<FormConfigPreview> | null>;
  /** What the preview resolved to, or null before anything has been previewed. */
  protected readonly preview: import("@angular/core").Signal<FormConfigPreview | null>;
  /**
   * The provenance sentence — the answer the tool exists to give.
   *
   * Says which dimensions matched rather than only the rank number: "rank 4" is meaningless to
   * anybody who has not read §6, and "matched this location and this commodity" is the same fact in
   * a form that needs no reference.
   */
  protected readonly previewProvenance: import("@angular/core").Signal<string | null>;
  /** Required fields in the resolved configuration, which is what an admin most often checks. */
  protected readonly previewRequired: import("@angular/core").Signal<readonly string[]>;
  /** Fields the resolved configuration hides — the other half of "what did I actually change?". */
  protected readonly previewHidden: import("@angular/core").Signal<readonly string[]>;
  /**
   * The tabs the preview reports.
   *
   * 🔴 **Runs the same cascade the record screen runs** (F8.3, ruled 2026-09-24): a tab whose every
   * section is hidden is dropped here too. This filtered on `tab.visible` alone, which made the
   * preview *confidently wrong* — it promised a tab the record screen was about to drop, and a
   * preview that disagrees with the thing it previews is worse than no preview.
   */
  protected readonly previewTabs: import("@angular/core").Signal<readonly string[]>;
  /**
   * Which row's history is open, or `null`. One at a time: the trail is fetched on demand rather
   * than with the list, because a list of 50 rows would otherwise pull 50 full document histories
   * to render 50 collapsed summaries nobody has opened.
   */
  protected readonly auditRowId: import("@angular/core").WritableSignal<number | null>;
  protected readonly auditState: import("@angular/core").WritableSignal<RemoteData<FormConfigAuditTrail>>;
  /**
   * The failure message, or empty.
   *
   * A computed rather than two `auditState()` reads in the template: narrowing does not survive
   * between two calls of the same signal, so the template form does not compile — and the shape
   * that would have compiled (`$any`) would have suppressed the check rather than satisfied it.
   */
  protected readonly auditError: import("@angular/core").Signal<string>;
  /**
   * The trail as the screen renders it: newest first, each entry paired with the diff against its
   * predecessor.
   *
   * 🔴 **The pairing happens BEFORE the reversal, and the order of those two steps is the whole
   * correctness of this screen.** The server serves oldest-first because the *before* of entry
   * *n* is entry *n−1*; reversing first and then pairing would diff every entry against its
   * successor and report every change backwards, with nothing to say so.
   */
  /** #700: the trail left out entries from trade units this account does not manage. */
  protected readonly auditPartial: import("@angular/core").Signal<boolean>;
  protected readonly auditEntries: import("@angular/core").Signal<{
    entry: import("@cws/domain-contracts").FormConfigAuditEntry;
    isOldest: boolean;
    changes: readonly import("@cws/domain-contracts").ConfigChange[];
  }[]>;
  protected toggleAudit(row: FormConfigRow): void;
  private readonly router;
  private readonly route;
  /**
   * Each row's actions, for its ⋯ menu (#825; they were three inline buttons). Edit and Deactivate on
   * an active row only, as before; History on every row, because the audit outlives its subject
   * (F8.6). Built once per row per change, so a menu's actions keep their identity between renders.
   * Edit opens the form builder on the row's dimensions; the checkbox editor is retired from this screen.
   */
  protected readonly rowActions: import("@angular/core").Signal<Map<number, GridRowAction<FormConfigRow>[]>>;
  /** New configuration: the form builder, to choose the dimensions there. */
  protected startNew(): void;
  /** Edit: the form builder, opened on the row's dimensions. */
  protected edit(row: FormConfigRow): void;
  /**
   * The last list-level write's outcome (#803): a deactivate. Its failure sits here, beside the list, with
   * Reload; it no longer replaces the list.
   */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  constructor();
  protected reload(): void;
  protected runPreview(): void;
  /** Deactivates a row and reloads, so the list cannot show a row that is no longer active. */
  protected deactivate(row: FormConfigRow): void;
  /** `Any` rather than a blank cell — a null dimension means "applies to everything". */
  protected dimension(value: string | null): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormConfigAdminPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormConfigAdminPageComponent, "cms-form-config-admin-page", never, {
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The presentation members the editor sets; each is absent until an administrator sets it (#221). */
type PresentationKey = keyof FieldPresentation;
/**
 * How a field will be drawn on the record screen, for the editor's preview (#221): the layout's
 * value wherever the row sets nothing.
 */
export interface PresentationPreview {
  readonly half: boolean;
  /** The width in words: `Compact`, `Normal`, `Automatic`, or fixed for a group member (2026-10-29). */
  readonly widthLabel: string;
  readonly labelHidden: boolean;
  readonly label: string;
  /** The description shown, or `null` when none is. */
  readonly description: string | null;
}
/**
 * A field's presentation as it will render: the row's settings over the layout's (#221). The same
 * precedence `presentationMaps` applies on the record screen.
 */
export declare function previewPresentation(componentName: string, registryLabel: string, presentation: FieldPresentation | undefined): PresentationPreview;
/**
 * The field map as it goes on the wire: a `presentation` block only where something was set.
 *
 * 🔴 **An empty block is dropped, and so is every unset member**, so saving a row through the editor
 * never freezes today's layout values into it (the 2026-09-09 field-order lesson, #221).
 */
export declare function withSetPresentationOnly(fields: Readonly<Record<string, ConfigFieldBehaviour>>): Record<string, ConfigFieldBehaviour>;
/** One editable field row, joined from the registry and the document being edited. */
interface EditorField {
  readonly componentName: string;
  readonly label: string;
  readonly ctrmField: string;
  /** CTRM refuses this on a write — it can never be required, and the row says why. */
  readonly ctrmReadOnly: boolean;
  /** A driver or the contract number: visibility and requiredness are not the admin's to change. */
  readonly locked: boolean;
  /** CTRM refuses it blank on every save (2026-10-29): Visible and Required are locked on. */
  readonly ctrmRequired: boolean;
  readonly behaviour: ConfigFieldBehaviour;
}
/** One row of the "Collections on copy" block (#1000), joined from the registry and the document. */
interface EditorCollection {
  /** The CTRM collection name, from the registry. Never re-typed here. */
  readonly name: string;
  readonly label: string;
  /** `false`: a copy can never carry it, so its box is disabled with the reason. */
  readonly copyable: boolean;
  readonly excludeFromCopy: boolean;
}
/** One row of the "Remarks" block (#1006), joined from the registry and the document. */
interface EditorRemarkType {
  /** CTRM's `remark_type` code, from the registry. Never re-typed here. */
  readonly code: string;
  readonly label: string;
  readonly visible: boolean;
  readonly required: boolean;
}
/** Fields grouped as the layout groups them, so the grid reads like the screen it configures. */
interface EditorSection {
  readonly id: string;
  readonly label: string;
  readonly tab: string;
  readonly fields: readonly EditorField[];
}
/**
 * @deprecated Retired from the Admin screens by the form builder (2026-10-28, F14): `FormBuilderPageComponent`
 * sets everything this editor set, which `form-builder-parity.spec.ts` checks setting by setting. It stays
 * exported only because every change to the published `@cws/*` surface is additive (F18); no screen mounts it.
 */
export declare class FormConfigEditorComponent implements OnInit {
  private readonly source;
  /** The row to edit, or `null` to create a new one. */
  readonly editing: import("@angular/core").InputSignal<FormConfigDetail | null>;
  /** Raised after a successful save, so the list reloads and the editor closes. */
  readonly saved: import("@angular/core").OutputEmitterRef<void>;
  /** Raised on Cancel. */
  readonly cancelled: import("@angular/core").OutputEmitterRef<void>;
  protected contractTypeClass: string;
  protected locationCode: string;
  protected commodityCode: string;
  /**
   * ISO `yyyy-MM-dd`, or `null`/`''` when there is none. ⚠ `cms-date-input` writes `null` for text it
   * cannot parse, as well as for an empty field, so "blank" alone is not the test (#626).
   */
  protected effectiveFrom: string | null;
  /** The effective date's refusal, shown on the field; cleared as soon as the date changes. */
  protected readonly effectiveError: import("@angular/core").WritableSignal<string | null>;
  protected autoCalculationMode: string;
  protected pendingContractsEnabled: boolean;
  /**
   * Set while a save of a row for EVERY trade unit waits on the administrator's say-so (#844).
   *
   * 🔴 **The Dev walk made one by mistake (2026-10-12, row d1).** "Applies to trade unit" was left at
   * Any while a seed was set, and the create took over every Dev contract until the row was
   * deactivated. Such a row is still allowed, because an Admin needs one; it just takes a second,
   * deliberate click. Asked for a new row and for an edit that takes a trade unit's row to Any, and
   * not for an edit of a row that already applies to every trade unit.
   */
  protected readonly everyTradeUnitPending: import("@angular/core").WritableSignal<boolean>;
  /** The trade unit picker's change: picking one answers the question, so it is dropped. */
  protected setLocation(code: string): void;
  /** Whether this save would make a row for every trade unit that is not one already. */
  private asksBeforeEveryTradeUnit;
  /** The trade unit's column list, or `null` for every column. Sent only when set. */
  protected readonly homeGridColumns: import("@angular/core").WritableSignal<readonly string[] | null>;
  /**
   * Set when a save went through but the server's answer does not carry the list that was sent.
   *
   * 🔴 Until #747 the server does not know the attribute and drops it on save with no error, so a
   * save would look complete while keeping nothing. The answer IS the stored row, so its absence
   * there is the read-back.
   */
  protected readonly columnsNotKept: import("@angular/core").WritableSignal<boolean>;
  protected readonly lockedColumnKeys: readonly string[];
  private readonly allColumnKeys;
  /** The picker's list: the set columns first, in order, then the rest unticked. */
  protected readonly homeGridColumnFields: import("@angular/core").Signal<readonly ExportField[]>;
  protected onHomeGridColumnsChange(fields: readonly ExportField[]): void;
  protected resetHomeGridColumns(): void;
  /** The collection copy flags as edited. A missing entry is the default: the collection copies. */
  private readonly collectionFlags;
  /**
   * The flags the starting point carried: the row's own when editing, the resolution's for a new row.
   * The save sends only what differs from this (see {@link changedCollections}).
   */
  private readonly collectionBaseline;
  /**
   * One row per registry collection, in the registry's order, or `null` when the registry offers none.
   *
   * ⚠ **`null` is a server without #959** (PR #991): its registry has no `collections`, and the block
   * is not rendered at all rather than shown empty or as an error.
   */
  protected readonly collectionRows: import("@angular/core").Signal<readonly EditorCollection[] | null>;
  /** Ticks or clears one collection's Exclude from copy. Refused for a collection a copy never carries. */
  protected setCollectionExcluded(name: string, excludeFromCopy: boolean): void;
  /** Takes a starting point's collection flags as both the edited state and the baseline. */
  private startCollectionsFrom;
  /** Each remark type's flags as edited. A missing entry is the default: shown and optional. */
  private readonly remarkFlags;
  /** The flags the starting point carried, as {@link collectionBaseline} is for collections. */
  private readonly remarkBaseline;
  /**
   * One row per registry remark type, in the registry's order, or `null` when the registry offers none.
   *
   * ⚠ **`null` is a server without #1022**: its registry has no `remarkTypes`, and the block is not
   * rendered at all rather than shown empty or as an error.
   */
  protected readonly remarkRows: import("@angular/core").Signal<readonly EditorRemarkType[] | null>;
  /**
   * Ticks or clears one remark type's Visible or Required.
   *
   * The field grid's rule (see the note under it): **Required also ticks Visible and locks it**, since a
   * remark somebody must fill in cannot be one they cannot see. Clearing Visible is refused while
   * Required holds it.
   */
  protected setRemarkFlag(code: string, flag: keyof ConfigRemarkTypeBehaviour, value: boolean): void;
  /** Takes a starting point's remark flags as both the edited state and the baseline. */
  private startRemarksFrom;
  /** The trade unit typed into the seed box. */
  protected seedTradeUnit: string;
  /**
   * The row this new configuration was seeded from, or `null` when it was not.
   *
   * 🔴 **Carries the source's `rowVersion`, and that is the point of keeping it.** `POST
   * /form-configurations` does not evaluate `If-Match` — it has no source to be stale against — so
   * the guard against cloning a source that changed after it was copied lives here: {@link save}
   * reads the source again and compares this token, the same opaque value `If-Match` carries on an
   * update, before it creates anything.
   */
  protected readonly seededFrom: import("@angular/core").WritableSignal<{
    readonly id: number;
    readonly rowVersion: string;
    readonly tradeUnit: string;
    readonly dimensionKey: string;
    readonly version: number;
  } | null>;
  /** Why a seed was refused, or `null`. Not {@link error}: nothing was saved or failed to save. */
  protected readonly seedNotice: import("@angular/core").WritableSignal<string | null>;
  /**
   * The starting point's own sections, so what is saved keeps their placement exactly: the row
   * being edited, the row seeded from, or the resolution a new row copies.
   *
   * 🔴 **#792: an edit used to leave this `null`, so the save sent the LAYOUT's sections.** Dev's
   * rows put `pricing` on the `contract` tab and have no `pricing` tab; the editor sent
   * `pricing -> pricing` beside the row's tabs and the server refused every save (rule 5). `null`
   * now means only "nothing loaded yet", and falls back to the registry.
   */
  private readonly baseSections;
  /**
   * Which starting point is current. Every load of one — the open-time resolve, "Copy from what
   * currently applies", a seed — takes the next number, and an answer is adopted only if its number
   * is still current.
   *
   * 🔴 **Without it a slow resolve overwrites a seed.** A new row resolves as it opens; over HTTP
   * that answer can land after the administrator has seeded, and adopting it would replace the
   * seeded settings with the parent's while the screen still said "Seeded from trade unit …".
   */
  private startingPoint;
  protected readonly saving: import("@angular/core").WritableSignal<boolean>;
  /**
   * Why the editor cannot go on, as one outcome (#803): the registry that could not be read, a save
   * the server refused (with its reference), or a refusal made here before any request. A success
   * closes the editor, and the page announces it.
   */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /**
   * Field search, because 111 rows across 11 sections is not a list you scroll.
   *
   * 🔴 **A signal, and it was a plain property until 2026-09-23 — which meant the search had never
   * worked.** `sections()` is a `computed` reading this; a computed over a non-signal caches on
   * first evaluation and is never invalidated, so typing re-ran change detection, the template
   * called `sections()`, and got the same cached list back every time. The box accepted input and
   * filtered nothing.
   *
   * ⚠ **Nothing caught it because nothing tested it** — the screen looks completely normal, since a
   * filter that matches everything and a filter that is ignored render identically. It surfaced only
   * when the reorder guard needed to react to the same field and its banner would not appear.
   *
   * ⚠ Bound as `[ngModel]` + `(ngModelChange)` rather than the banana-in-a-box: `[(ngModel)]` writes
   * through to the property, which would replace the signal with a string.
   */
  protected readonly filter: import("@angular/core").WritableSignal<string>;
  private readonly registry;
  private readonly behaviours;
  private readonly constraintSource;
  /** The CTRM constraint document, or `null` without a source or when it cannot be read (2026-10-29). */
  private readonly constraintDocument;
  /** The fields CTRM refuses blank on every save, by component name, from the document's `required` member. */
  private readonly ctrmRequired;
  protected readonly ctrmRequiredReason = "Required by CTRM on every save";
  /**
   * The behaviours as the grid shows them and Save sends them: a CTRM-required field visible and required
   * whatever the stored row says, so a save repairs a row that said otherwise. The stored row is not rewritten
   * on open.
   */
  private readonly lockedBehaviours;
  private readonly tabs;
  protected readonly ready: import("@angular/core").Signal<boolean>;
  protected readonly isNew: import("@angular/core").Signal<boolean>;
  /**
   * 🔴 The registry fetch is here and NOT in the constructor, and that is a correctness fix
   * rather than a style preference.
   *
   * Signal inputs are not populated during construction. With an HTTP registry the response always
   * arrives after the input is set, so seeding from the constructor LOOKED correct — but a
   * synchronous source (a test stub, or a cached response) seeded before {@link editing} existed,
   * so the editor silently opened a blank NEW row while claiming to edit an existing one. That is
   * the same shape as the 2026-09-01 defect where synchronous mocks could not express a real
   * ordering race; here the mock exposed it instead.
   */
  ngOnInit(): void;
  /**
   * The editable tab list.
   *
   * Tabs are configuration (D7) — this is what replaces the legacy app's per-location BIO/FOG tabs,
   * which were `If(location = 4090)` conditionals in a template. Label and visibility are editable;
   * the id is not, because sections reference it.
   */
  protected readonly editableTabs: import("@angular/core").Signal<readonly ConfigTab[]>;
  /**
   * Section enablement per trade unit (F8.3).
   *
   * 🔴 **Held as editable state, where `save()` used to submit `registry.sections` verbatim.** That
   * pass-through is why nothing could turn a section off: the document has carried
   * `sections[].visible` since ADR-17 and the resolve projection has always emitted it, so the
   * storage and the consumer were both ready and only the editor was writing the seed's answer back
   * over the administrator's.
   *
   * ⚠ **A hidden section does NOT hide its tab, and that is the current behaviour rather than a
   * decision this makes.** The record screen filters tabs on `tab.visible` alone, so hiding every
   * section on a tab leaves the tab present and empty. {@link emptyTabWarning} surfaces that state
   * instead of pretending it cannot happen — see its own note.
   */
  protected readonly sectionVisibility: import("@angular/core").WritableSignal<Readonly<Record<string, boolean>>>;
  /** Toggles one section on or off for this configuration row. */
  protected toggleSection(sectionId: string, visible: boolean): void;
  /**
   * Whether a section is on, for the template.
   *
   * Reads the registry's own default when this row has said nothing, so a section added to the
   * layout after the row was written shows its layout state rather than defaulting to hidden.
   */
  protected sectionVisible(sectionId: string): boolean;
  /** The sections as they will be stored — the starting point's own, carrying this row's visibility. */
  protected readonly editableSections: import("@angular/core").Signal<{
    visible: boolean;
    id: string;
    label: string;
    tab: string;
    order: number;
  }[]>;
  /**
   * Tabs left with no visible section, named.
   *
   * ✅ **RULED 2026-09-24 (JFrisbie): it cascades.** The record screen and the preview tool both
   * drop an emptied tab now, so this is no longer a warning standing in for a decision — it tells
   * the administrator what *will* happen, at the moment they cause it.
   *
   * 🔑 **The predicate is {@link emptiedTabs}, shared with both of them rather than copied.** That
   * is what makes this message and the record screen's behaviour the same statement: a warning
   * computed from its own second copy of the rule could say "Shipping will be hidden" about a tab
   * the record screen kept, and nothing would report the disagreement. The Remarks guard lives
   * there too.
   */
  protected readonly emptyTabWarning: import("@angular/core").Signal<string | null>;
  /** The field grid, grouped by section and narrowed by the search box. */
  protected readonly sections: import("@angular/core").Signal<readonly EditorSection[]>;
  /**
   * Why reorder is unavailable right now, or `null` when it is available.
   *
   * 🔴 **Reorder is refused while the search box has content, and that is a correctness guard rather
   * than caution.** The grid shows a *filtered* section; "move up" against a filtered list either
   * swaps with the row above on screen — which is not the row above in the document — or silently
   * jumps the field past rows the administrator cannot see. Both write an order nobody chose.
   *
   * Refusing with a stated reason is the honest third option, and it is cheap to satisfy: clear the
   * search and the buttons come back.
   */
  protected readonly reorderBlockedReason: import("@angular/core").Signal<"Clear the search to reorder — moving a field while the list is filtered would place it against rows you cannot see." | null>;
  /**
   * Moves a field one place within its section — **the keyboard path**.
   *
   * Renumbering and the full-membership rule live in {@link applyOrder} and {@link orderedIn}, shared
   * with the drag ({@link placeField}), so the two gestures cannot disagree about what a move writes.
   */
  protected moveField(sectionId: string, componentName: string, delta: -1 | 1): void;
  /**
   * Moves a field to the position of another in the same section — **the drag** (F8.1).
   *
   * 🔑 **The same persistence path as the arrows, on purpose.** It computes a new sequence and hands
   * it to {@link applyOrder}, which is the one place a section is renumbered; the arrows do exactly
   * the same. So a drag and the equivalent key presses produce the same document, the save goes
   * through the same `If-Match` update, and there is no second renumbering rule to drift.
   *
   * The semantics are the export field picker's: the dragged field takes the target row's index, so
   * dropping on the last row makes it last and dropping on the first makes it first.
   */
  protected placeField(sectionId: string, componentName: string, onto: string): void;
  /**
   * A section's FULL membership in its current order, or `null` when reorder is unavailable.
   *
   * ⚠ Full membership, not the rendered rows. They are the same list while
   * {@link reorderBlockedReason} is null, which is the only time this answers, but taking the full
   * list means a future caller cannot reintroduce the filtered-reorder bug by accident.
   */
  private orderedIn;
  /**
   * Writes a section's new sequence, renumbered contiguously from 1.
   *
   * ⚠ **Renumbers the whole section rather than swapping two numbers.** The seed's orders are not
   * guaranteed dense or unique — they are the layout's, and nothing has ever required them to be —
   * so a swap can be a no-op between two fields that share a number, which reads on screen as the
   * control doing nothing. Renumbering from the resulting sequence makes the write describe exactly
   * what the grid shows.
   */
  private applyOrder;
  /** The field being dragged, so its row can show it. */
  protected readonly draggingField: import("@angular/core").WritableSignal<string | null>;
  /** The row the dragged field would land on, or `null` when the pointer is over no valid target. */
  protected readonly dropField: import("@angular/core").WritableSignal<string | null>;
  /** The section the drag began in; a drop is only valid inside it. */
  private dragSection;
  /**
   * **The drag, through the shared gesture** — never a copy of it (Known Issue 44).
   *
   * `PointerDragGesture` is the filter chip row's pointer implementation, extracted into shared-ui:
   * pointer events rather than HTML5 drag-and-drop, window listeners only while a press is followed,
   * and every way out (release, `pointercancel`, Escape, losing the window) ending it. What is here
   * is only what is specific to these rows — the grip names a field, a row names a drop — and the
   * rows' container carries `select-none`, which the gesture cannot apply for us.
   *
   * ⚠ The grip is only rendered while {@link reorderBlockedReason} is null, so a filtered list offers
   * nothing to press; {@link placeField} checks again regardless.
   */
  private readonly gesture;
  constructor();
  /** Bound on the rows' container, so it sees a press on any grip. */
  protected onRowPointerDown(event: PointerEvent): void;
  /**
   * The field that moved last, so the row can announce itself and keep focus.
   *
   * Without it a keyboard user presses the button, the list re-sorts under them, and focus lands
   * wherever the DOM happens to put it — which on a 111-row grid means losing your place entirely.
   */
  protected readonly movedField: import("@angular/core").WritableSignal<string | null>;
  /** Counts for the summary line, so an admin can see what they have done at a glance. */
  protected readonly requiredCount: import("@angular/core").Signal<number>;
  protected readonly hiddenCount: import("@angular/core").Signal<number>;
  /**
   * Ticks Required, and ticks Visible with it.
   *
   * Rule 2 made visible in the control rather than discovered at save: the server rejects
   * `required: true, visible: false` rather than silently fixing it, precisely so a document
   * always says what its author meant — which only works if the author cannot express the
   * contradiction.
   */
  protected setRequired(componentName: string, required: boolean): void;
  protected setVisible(componentName: string, visible: boolean): void;
  protected setFlag(componentName: string, flag: 'readOnly' | 'borderWarning' | 'excludeFromCopy' | 'excludeFromTemplateCopy', value: boolean): void;
  /** The field whose presentation controls are open, if any. */
  protected readonly openPresentation: import("@angular/core").WritableSignal<string | null>;
  protected togglePresentation(componentName: string): void;
  protected previewOf(field: EditorField): PresentationPreview;
  /** The layout's value for one setting, so a blank control can say what it falls back to. */
  protected layoutDefault(componentName: string): {
    readonly half: boolean;
    readonly labelHidden: boolean;
    readonly note: string | null;
  };
  /**
   * Sets one presentation member, or clears it back to the layout's value with `undefined`.
   * A tri-state select sends `''` for "the layout's", which clears too.
   */
  protected setPresentation(componentName: string, key: PresentationKey, value: boolean | string | undefined): void;
  /** A tri-state select's value: `''` is the layout's, otherwise `true` or `false`. */
  protected setPresentationFlag(componentName: string, key: 'halfWidth' | 'labelHidden' | 'tooltipEnabled', choice: string): void;
  protected flagChoice(value: boolean | undefined): string;
  /** Puts a field's presentation back to the layout's, which is what re-syncing it means. */
  protected resetPresentation(componentName: string): void;
  protected setTabVisible(id: string, visible: boolean): void;
  protected setTabLabel(id: string, label: string): void;
  /**
   * Loads whatever currently resolves for the dimensions typed in, as the starting point.
   *
   * Offered as a button as well as on open, because the dimensions can change after the editor is
   * open and the sensible starting point changes with them.
   */
  protected copyFromCurrent(): void;
  /** @param everyTradeUnitConfirmed The administrator confirmed a row for every trade unit (#844). */
  protected save(everyTradeUnitConfirmed?: boolean): void;
  /** Follows a create or update to its end. */
  private submit;
  /**
   * **Seeds this new row from another trade unit's configuration** (F8.1).
   *
   * Two reads, and both are needed. The resolve endpoint answers *which* row wins for the source
   * trade unit — the same answer the record screen gets, so "that trade unit's configuration" means
   * what its users actually see. Then that row is read whole, because the resolve payload carries
   * only visible/required/read-only per field and no order: seeding from it would silently reset the
   * other three flags and the whole field order.
   *
   * The type and commodity typed for the new row are kept for the source's resolve, so seeding a
   * CORN row copies the source's CORN configuration rather than its all-commodities one.
   */
  protected seedFromTradeUnit(): void;
  /**
   * Takes a stored row's document as this row's starting point, wholesale.
   *
   * 🔴 **Nothing is re-derived.** Tabs, sections, fields (in the source's own key order) and
   * attributes are the source's, so the document saved is byte-identical to the source's except the
   * dimensions it is saved under. Registry fields the source predates are completed at their
   * defaults, the same rule every stored row gets on read (§5.1 rule 7).
   */
  private adoptSeed;
  protected cancel(): void;
  /** Seeds the form: an existing row's own document, or the current resolution for a new one. */
  private seed;
  private completeFrom;
  private toEditorField;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormConfigEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormConfigEditorComponent, "cms-form-config-editor", never, {
    "editing": {
      "alias": "editing";
      "required": false;
      "isSignal": true;
    };
  }, {
    "saved": "saved";
    "cancelled": "cancelled";
  }, never, never, true, never>;
}
/**
 * What the screen knows of the person typed into a person field (#1107).
 *
 * - `objectId`: a GUID, used as entered with no lookup (C-13: that is the stored key).
 * - `waiting`: an address, looked up after a short pause; `looking`: the lookup is in flight.
 * - `found`: the directory's match, whose object id and UPN are what an assignment sends.
 * - `notFound`, `invalid`, `unavailable`: the directory's answer. `offered: false` is a host with no
 *   directory at all, which is said differently from a directory that could not be reached.
 * - `neither`: not an address and not an object id. Nothing is looked up.
 */
type PersonResolution = {
  readonly status: 'empty';
} | {
  readonly status: 'neither';
  readonly text: string;
} | {
  readonly status: 'objectId';
  readonly text: string;
  readonly objectId: string;
} | {
  readonly status: 'waiting' | 'looking';
  readonly text: string;
} | {
  readonly status: 'found';
  readonly text: string;
  readonly user: DirectoryUser;
} | {
  readonly status: 'notFound';
  readonly text: string;
  readonly correlationId: string | null;
} | {
  readonly status: 'invalid';
  readonly text: string;
  readonly message: string;
  readonly correlationId: string | null;
} | {
  readonly status: 'unavailable';
  readonly text: string;
  readonly correlationId: string | null;
  readonly offered: boolean;
};
/** How long typing must pause before an address is looked up. Leaving the field looks it up at once. */
declare const PERSON_LOOKUP_PAUSE_MS = 400;
/**
 * **Resolves a person field: an object id as entered, an address through the directory** (#1107).
 *
 * 🔴 **One lookup at a time, and a newer entry cancels an older one.** Every entry goes through one
 * `switchMap`, so a lookup still in flight when the text changes is unsubscribed, and its answer can
 * never land against the newer entry. That is the whole reason this is a stream rather than a call.
 */
declare class PersonResolver {
  /** The current resolution, for a template. */
  readonly state: import("@angular/core").WritableSignal<PersonResolution>;
  private readonly states;
  private readonly entries;
  constructor(directory: UserDirectorySource | null, destroyRef: DestroyRef, onChange?: (state: PersonResolution) => void, pauseMs?: number);
  /** The text changed: an address is looked up once typing pauses. */
  entered(value: string): void;
  /** The field was left: an address still waiting for the pause is looked up now. One already asked is not asked again. */
  committed(value: string): void;
  /** The settled resolution for `value`, starting its lookup now if it is still waiting. */
  settled(value: string): Observable<PersonResolution>;
  /** Back to empty, after the form is cleared. */
  reset(): void;
}
/**
 * What a settled resolution says, through `cms-status-message`, or `null` when there is nothing to
 * say. A lookup that was sent ends with the server's reference line; "not offered" sent nothing.
 */
declare function lookupOutcome(state: PersonResolution): MutationOutcome | null;
/**
 * #1244: said whenever an address could not be resolved, because it can still be assigned. Plain about the
 * one thing the screen cannot do: a mistyped address is accepted, and simply never signs in.
 */
declare const PENDING_BY_EMAIL: string;
/**
 * The person to assign: the object id and the UPN to send, and who to name in the sentence; or, for an
 * address the directory could not find or reach, the address alone (#1244), which the server saves as pending.
 */
type ResolvedPerson = {
  readonly objectId: string;
  readonly upn: string;
  readonly label: string;
} | {
  readonly email: string;
  readonly label: string;
} | {
  readonly refusal: string;
};
/**
 * 🔴 **What an assignment sends for a settled resolution.** A match sends the DIRECTORY'S object id
 * and UPN, never the typed text; an object id sends itself beside the UPN typed for display.
 *
 * #1244: an address the directory does not know, or could not be asked about, is sent as the address
 * alone and saved as pending; it is never sent as an object id (C-13). A refused address (a guest) and
 * anything that is neither are refused here, before any request.
 */
declare function personToAssign(state: PersonResolution, typedUpn: string): ResolvedPerson;
/** The Roles and permissions page's views (#825). */
export type RolesView = 'all' | 'roles' | 'assignments' | 'permissions';
/** The role being created or edited. Mutated by the form's bindings, like the template editor's. */
interface RoleEditor {
  readonly role: Role | null;
  name: string;
  displayName: string;
  description: string;
  parentRoleId: string | null;
  permissionKeys: string[];
}
/**
 * The assignment being added. The trade units, "all trade units" and the default are signals on the
 * component rather than here, because the controls that read them are computed from them (#1104).
 */
interface AssignmentForm {
  /** What was typed in the person field: an email address (UPN) or an object id (#1107). Never sent as-is. */
  person: string;
  userUpn: string;
  roleId: string;
  expiresOn: string;
}
/** What the screen knows of the person in the form: their rows, read by object id (#1104). */
type PersonRows = {
  readonly status: 'loaded';
  readonly objectId: string;
  readonly rows: readonly RoleAssignment[];
} | {
  readonly status: 'loading' | 'failed';
  readonly objectId: string;
};
/** Said for a code the trade-unit list does not hold. A code is picked, never typed through. */
export declare function notATradeUnitMessage(codes: readonly string[]): string;
/** A trade unit as an administrator reads it: `*` is "All trade units" (#1104). */
export declare function tradeUnitLabel(code: string): string;
/**
 * The success sentence for an assignment, in our words, from what the server says it did (#1104):
 * what was added, which unit is the default, and what was skipped and why.
 */
export declare function assignedSentence(who: string, answer: RoleAssignmentAnswer, defaultTradeUnit: string | null): string;
/** The day a pending row stops waiting, as the screen shows every date here: `YYYY-MM-DD`. */
export declare function pendingUntil(row: PendingRoleAssignment): string;
/**
 * #1244: the sentence for an assignment saved as pending. It says when it takes effect, until when it
 * waits, and, plainly, that a typo cannot be caught until the person signs in.
 */
export declare function pendingSentence(email: string, answer: RoleAssignmentAnswer): string;
type ListState$1 = {
  readonly status: 'idle' | 'loading' | 'loaded';
} | {
  readonly status: 'unavailable' | 'failed';
  readonly message: string;
};
/**
 * **Roles and permissions (F8.4), bound to the role admin API (#429).**
 *
 * 🔴 **The banner is a control, not decoration.** The seven permissions are provisional pending
 * the business ruling on issue #138, and the stopgap `CwsContractWriter` policy has already been
 * read **twice** as though this matrix were built. A screen that creates roles and assigns them is
 * the most convincing possible version of that mistake, so the screen says what it is, above the
 * content, every time. The row stays 🔄 on #138 whatever is built here.
 *
 * ### 🔑 The permission↔role mapping is the server's rows
 *
 * Each role's `permissionKeys` come from `GET /admin/roles` and go back whole on update (the server
 * replaces the set). The permission list comes from `GET /admin/permissions` through
 * `PERMISSION_CATALOG_SOURCE`. Nothing here branches on a particular permission or role, so #138's
 * ruling changes data, not this screen.
 *
 * ### ⚠ What this screen deliberately does NOT do
 *
 * It ships no role catalogue. 01 §5 rules the role list *"a workshop item and must not be invented
 * here"*. An administrator creates roles; the client seeds none.
 *
 * ### The server's rules, as the screen meets them
 *
 * - The built-in `Admin` role (`isSystem`) has its Edit and Delete disabled rather than letting the
 *   call answer `409`.
 * - A `409` (stale version, a held or inherited role) and a `503` (CTRM could not check the trade
 *   unit) show the server's sentence as-is.
 * - An object id that is not a GUID is refused here, before any request (C-13).
 * - After an assignment write the screen re-renders from the rows the server returns, rather than
 *   predicting where the default went.
 *
 * ### #1104: one, several or all trade units, in one request
 *
 * - The trade units are picked from CTRM's location list (`cws-admin-code-picker`), never typed
 *   through: a code the list does not hold is refused at the control, and with no list nothing can
 *   be picked. "All trade units" sends `allTradeUnits` and no codes, and the server keeps one `*` row.
 * - The default trade unit is its own control, required only when the person is known to have none,
 *   and it never offers `*`. Under "all" the server stores it as a companion row.
 * - A duplicate is skipped and named in the success sentence, no longer a `409`.
 * - A `*` row reads "All trade units", is never offered as a default, and its revoke says it removes
 *   the role everywhere, and that the default's row stays when there is one.
 *
 * ### #1107: a person by email address, resolved to the object id
 *
 * - The person field takes a UPN or an object id. An object id goes through as before, with no lookup;
 *   an address is looked up (`USER_DIRECTORY_SOURCE`) when typing pauses or the field is left, one
 *   lookup at a time, a newer entry cancelling an older one (`PersonResolver`).
 * - A match is shown beside the field, fills the display email from the directory (read-only while it
 *   is shown), and an assignment then sends the directory's object id and UPN, never the typed text.
 * - Not found, a refused address and an unreachable directory are said through `cms-status-message`
 *   and refuse the assignment before any request. Unreachable says to enter the object id, which still
 *   works. Neither an address nor an object id is refused as before.
 * - The user filter takes an address the same way and lists that person's rows by object id.
 *
 * ### #1244: an address the directory cannot resolve is saved as pending
 *
 * - Not found, unreachable, or no directory at all: the assignment is sent with the address and no object
 *   id, and the server saves it as pending. It grants nothing until the person's first sign-in binds it to
 *   their object id. The lookup's notice and the success sentence both say so, and say that a typo cannot
 *   be caught until then.
 * - Pending rows are listed apart from the assignments, "Pending — not signed in yet", with the date they
 *   stop waiting, and each can be revoked. The object-id entry is unchanged.
 */
export declare class RolesPageComponent {
  /**
   * Which of the page's views to show (#825): roles, assignments, the permission list, or `all` of it
   * as on the old single Admin page. The Admin routes set it from `data.view`; mounted on its own the
   * page shows everything. The provisional banner is on every view.
   */
  readonly view: import("@angular/core").InputSignalWithTransform<RolesView, RolesView | null | undefined>;
  protected readonly showPermissions: import("@angular/core").Signal<boolean>;
  protected readonly showRoles: import("@angular/core").Signal<boolean>;
  protected readonly showAssignments: import("@angular/core").Signal<boolean>;
  /** True when routed as one of the section's tabs, which is when the tabs are shown. */
  protected readonly routed: import("@angular/core").Signal<boolean>;
  protected readonly area: import("@cws/features-admin").AdminArea;
  /**
   * #696, #825: an account KNOWN not to hold Admin gets the reason rather than the panel. Provided by
   * this page (#1104), over optional sources, so a host or spec without `/me` sees it as before.
   */
  private readonly access;
  protected readonly refused: import("@angular/core").Signal<boolean>;
  /** Each role's actions, for its ⋯ menu (#825). Refused with the reason the buttons gave. */
  protected readonly roleActions: import("@angular/core").Signal<Map<string, GridRowAction<Role>[]>>;
  /** One assignment's key: a user holds a role once per trade unit. */
  protected assignmentKey(row: RoleAssignment): string;
  /** Each assignment's actions, for its ⋯ menu (#825). Make default only where it is not already. */
  protected readonly assignmentActions: import("@angular/core").Signal<Map<string, GridRowAction<RoleAssignment>[]>>;
  /** One pending row's key: an address holds a role once per trade unit. */
  protected pendingKey(row: PendingRoleAssignment): string;
  /** #1244: each pending row's Revoke, when the source offers it. */
  protected readonly pendingActions: import("@angular/core").Signal<Map<string, GridRowAction<PendingRoleAssignment>[]>>;
  private readonly catalogSource;
  private readonly source;
  private readonly confirm;
  private readonly destroyRef;
  private readonly answer;
  /** The catalogue once it has answered; the built-in copy until then is never shown as the API's. */
  private readonly catalog;
  /** The permissions to render. Empty while the catalogue is loading. */
  protected readonly permissions: import("@angular/core").Signal<readonly import("@cws/domain-contracts").PermissionCatalogEntry[]>;
  /** True when the permissions are the built-in copy rather than the server's answer. */
  protected readonly isBuiltInCopy: import("@angular/core").Signal<boolean>;
  protected readonly offered: boolean;
  protected readonly rolesState: import("@angular/core").WritableSignal<ListState$1>;
  /**
   * The roles an administrator manages. ⚠ Named `roleRows`, never `roles`: a feature library calling
   * a signal of that name is what `feature-reads-no-roles.spec.ts` refuses, because it reads as a
   * screen checking the caller's own roles. These are rows, not the caller's grants.
   */
  protected readonly roleRows: import("@angular/core").WritableSignal<readonly Role[]>;
  protected readonly storeOrigin: import("@angular/core").WritableSignal<string | null>;
  protected readonly roleEditor: import("@angular/core").WritableSignal<RoleEditor | null>;
  protected readonly roleBusy: import("@angular/core").WritableSignal<boolean>;
  /**
   * The last role write's outcome (#803): a success, or the server's sentence as-is (a stale version,
   * the built-in role, a held or inherited role) with its reference and a Reload.
   */
  protected readonly roleOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly roleFieldErrors: import("@angular/core").WritableSignal<Readonly<Record<string, readonly string[]>>>;
  protected readonly rolesProblem: import("@angular/core").Signal<string | null>;
  /** Roles an edited role could inherit from: every role but itself. */
  protected readonly parentChoices: import("@angular/core").Signal<Role[]>;
  /** The filter's person: an email address or an object id (#1107). */
  protected readonly filter: {
    person: string;
  };
  /** The filter's trade unit: none, one location, or `*` for the rows that grant every trade unit (#1104). */
  protected readonly filterUnit: import("@angular/core").WritableSignal<readonly string[]>;
  protected readonly assignmentsState: import("@angular/core").WritableSignal<ListState$1>;
  protected readonly assignments: import("@angular/core").WritableSignal<readonly RoleAssignment[]>;
  /** #1244: the roles given by email and not yet bound, apart from the assignments because they grant nothing. */
  protected readonly pendingRows: import("@angular/core").WritableSignal<readonly PendingRoleAssignment[]>;
  protected readonly pendingUntil: typeof pendingUntil;
  protected readonly assignmentBusy: import("@angular/core").WritableSignal<boolean>;
  /** The last assignment write's outcome (#803), with the server's reference on a failure. */
  protected readonly assignmentOutcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  protected readonly assignmentFieldErrors: import("@angular/core").WritableSignal<Readonly<Record<string, readonly string[]>>>;
  protected readonly filterError: import("@angular/core").WritableSignal<string | null>;
  protected readonly assignment: AssignmentForm;
  private readonly directory;
  /** The assignment form's person. A settled match or object id reads that person's rows. */
  protected readonly assignee: PersonResolver;
  /** The filter's person, resolved the same way. */
  protected readonly filterPerson: PersonResolver;
  /** True while the display email shows the directory's UPN, which is when it is read-only. */
  protected readonly upnFromDirectory: import("@angular/core").WritableSignal<boolean>;
  /** A lookup outcome the administrator dismissed, so it is not shown again for the same answer. */
  protected readonly assigneeDismissed: import("@angular/core").WritableSignal<PersonResolution | null>;
  protected readonly filterDismissed: import("@angular/core").WritableSignal<PersonResolution | null>;
  protected readonly assigneeOutcome: import("@angular/core").Signal<MutationOutcome | null>;
  protected readonly filterOutcome: import("@angular/core").Signal<MutationOutcome | null>;
  /** #1244: the person field holds an address the directory could not resolve, so assigning saves it as pending. */
  protected readonly assigneePending: import("@angular/core").Signal<boolean>;
  /** Which directory the server reads names from, once the list has said. `Simulated` is said on screen. */
  protected readonly directoryMode: import("@angular/core").WritableSignal<string | null>;
  /** "All trade units": one `*` row on the server. Ticking it clears and disables the list. */
  protected readonly assignAll: import("@angular/core").WritableSignal<boolean>;
  /** The trade units picked. Only codes the location list holds can get here. */
  protected readonly assignUnits: import("@angular/core").WritableSignal<readonly string[]>;
  /** The default trade unit chosen, or `''` to leave the person's default where it is. Never `*`. */
  protected readonly assignDefault: import("@angular/core").WritableSignal<string>;
  /** The person in the form's rows, read by object id, so the screen knows whether they have a default. */
  protected readonly person: import("@angular/core").WritableSignal<PersonRows | null>;
  protected readonly notATradeUnitMessage: typeof notATradeUnitMessage;
  protected readonly tradeUnitLabel: typeof tradeUnitLabel;
  /**
   * Every CTRM location, with the onboarded indicator once `/me` has answered. A unit that is not
   * onboarded can still be granted, and its chip says so. Never `null`: with no list nothing can be
   * picked, rather than the picker falling back to free text.
   */
  protected readonly locationOptions: import("@angular/core").Signal<readonly CodeOption[]>;
  /** Said under the picker when the location list is not available, which is why nothing can be picked. */
  protected readonly locationNote: import("@angular/core").Signal<"The trade-unit list is not available here, so no trade unit can be chosen right now." | null>;
  /** The filter's choices: "All trade units" lists the `*` rows, then every location. */
  protected readonly filterOptions: import("@angular/core").Signal<readonly CodeOption[]>;
  /** Whether any trade unit is chosen, which is when the default control is shown. */
  protected readonly anyChosen: import("@angular/core").Signal<boolean>;
  /** The default's choices: the units chosen, or every location under "All". Never `*`. */
  protected readonly defaultChoices: import("@angular/core").Signal<readonly CodeOption[]>;
  /** The person's current default, when their rows have been read and they have one. */
  protected readonly personDefault: import("@angular/core").Signal<string | null>;
  /**
   * The default is required unless the person is KNOWN to have one (C-15 c: exactly one default, and
   * `*` cannot be it). Unknown asks, because "they probably have one" would leave a person with none.
   */
  protected readonly defaultRequired: import("@angular/core").Signal<boolean>;
  /** The filter the shown rows were read with, so a write's returned rows are kept to it. */
  private shownFilter;
  protected readonly assignmentsProblem: import("@angular/core").Signal<string | null>;
  constructor();
  protected permissionName(key: string): string;
  protected roleName(id: string | null): string;
  protected systemReason(role: Role): string | null;
  protected loadRoles(): void;
  protected newRole(): void;
  protected editRole(role: Role): void;
  protected cancelRole(): void;
  protected hasPermission(editor: RoleEditor, key: string): boolean;
  protected togglePermission(editor: RoleEditor, key: string, granted: boolean): void;
  protected saveRole(): void;
  protected deleteRole(role: Role): void;
  private openRole;
  /** One role write, then a re-read: the version shown is always the server's. */
  private runRole;
  protected loadAssignments(): void;
  private readAssignments;
  protected assign(): void;
  private assignAs;
  /**
   * The person field settled (#1107). A match or an object id reads that person's rows, so the default
   * control knows whether it is required; a match also fills the display email from the directory.
   */
  private assigneeChanged;
  /** The "All trade units" box: ticking it clears the chosen set, and the list is disabled. */
  protected setAssignAll(all: boolean): void;
  /** The picked set changed: a default no longer among them is dropped rather than sent. */
  protected setAssignUnits(codes: readonly string[]): void;
  /** The filter is single: the last code picked replaces the one before it. */
  protected setFilterUnit(codes: readonly string[]): void;
  /**
   * The person's object id changed, typed or resolved from an address (#1107): once it is a whole GUID,
   * read that person's rows, so the default control knows whether it is required. Nothing is read for
   * a partial id or an unresolved address.
   */
  private lookUpPerson;
  protected setDefault(row: RoleAssignment): void;
  protected revoke(row: RoleAssignment): void;
  private confirmRevoke;
  /**
   * #1244: an assignment by email. A server whose directory found the person after all answers `bound`,
   * which is shown like any assignment; otherwise the address's pending rows replace the ones shown for it.
   */
  private runPendingAssignment;
  protected revokePending(row: PendingRoleAssignment): void;
  /** The address's pending rows, replaced by what the server answered. */
  private showPendingOf;
  /** A user's rows, replaced by what the server answered, kept to the filter the list was read with. */
  private showRowsOf;
  private clearAssignmentForm;
  /** One assignment-area write: busy while it runs, then its outcome through `cms-status-message`. */
  private runWrite;
  /**
   * One assignment write. The server answers all of that user's rows, so the user's shown rows
   * are replaced by them (kept to the filter the list was read with), never patched by guesswork.
   */
  private runAssignment;
  static ɵfac: i0.ɵɵFactoryDeclaration<RolesPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RolesPageComponent, "cws-roles-page", never, {
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The page's tabs (`ADMIN_AREAS`), bound from the route's `data.view`; `all` mounted on its own. */
export type BasisLocationsView = 'terms' | 'places' | 'regions' | 'trade-units' | 'hta' | 'all';
/**
 * **Basis locations (#1218; the routes are #598's, merged in #1214)**: the price terms, places and
 * regions the record screen composes a basis location from, each trade unit's rule, and the special
 * types on which a term alone is allowed.
 *
 * ### 🔴 Retire, never edit (D11)
 *
 * A contract's basis location is CTRM's text, read back into a selection by matching it against these
 * lists. Editing a row in place would change what every contract carrying its text reads back as, so a
 * row is retired and a new one added. A retire carries the row's `rowVersion` as `If-Match`; a stale
 * one is refused, and the screen reloads rather than retrying.
 *
 * ### What the server's words are for
 *
 * - **A `409` is shown verbatim.** A D17 collision names the live code, print token or text in the way.
 * - **A setting's `warnings` are shown after a save.** The setting row is the unit's switch to
 *   enforcement, so a rule no live place or region can satisfy refuses every create in the unit.
 * - **Widths are the server's.** The 11-character city while BASIS is live is refused by the add-place
 *   route, naming the composed text and its length; nothing here repeats the arithmetic (ADR-7).
 */
export declare class BasisLocationsPageComponent {
  private readonly source;
  /** Which view to show (#825's pattern): the routes set it from `data.view`; on its own the page shows all. */
  readonly view: import("@angular/core").InputSignalWithTransform<BasisLocationsView, BasisLocationsView | null | undefined>;
  /** True when routed as one of the area's tabs, which is when the tabs are shown. */
  protected readonly routed: import("@angular/core").Signal<boolean>;
  protected readonly area: import("@cws/features-admin").AdminArea;
  protected readonly offered: boolean;
  protected shows(view: BasisLocationsView): boolean;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  /** The last write's outcome (#803): its success, or the server's refusal with its reference. */
  protected readonly outcome: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /** The last refusal's field-scoped reasons, keyed as the server keys them. */
  protected readonly fieldErrors: import("@angular/core").WritableSignal<Readonly<Record<string, readonly string[]>>>;
  /** Whether the lists show retired rows too. */
  protected readonly includeRetired: import("@angular/core").WritableSignal<boolean>;
  protected readonly terms: import("@angular/core").WritableSignal<readonly BasisLocationTermRow[] | null>;
  protected readonly places: import("@angular/core").WritableSignal<readonly BasisLocationPlaceRow[] | null>;
  protected readonly regions: import("@angular/core").WritableSignal<readonly BasisLocationRegionRow[] | null>;
  protected readonly listError: import("@angular/core").WritableSignal<string | null>;
  protected termCode: string;
  protected termPrintToken: string;
  protected termIncoTerms: string;
  protected placeCity: string;
  protected placeState: string;
  protected regionCode: string;
  protected regionPrintToken: string;
  protected regionStates: string;
  protected readonly tradeUnit: import("@angular/core").WritableSignal<string>;
  protected readonly setting: import("@angular/core").WritableSignal<BasisLocationTradeUnitSetting | null>;
  protected readonly settingWarnings: import("@angular/core").WritableSignal<readonly string[]>;
  protected readonly placeRule: import("@angular/core").WritableSignal<BasisPlaceRule>;
  protected readonly legacyEdits: import("@angular/core").WritableSignal<BasisLegacyEdits>;
  protected readonly rules: readonly {
    readonly value: BasisPlaceRule;
    readonly label: string;
  }[];
  /** 🔴 `CtrmBuilt` allows only `Allow`, so the other choice is not offered with it. */
  protected readonly legacyChoices: import("@angular/core").Signal<readonly BasisLegacyEdits[]>;
  protected readonly htaCodes: import("@angular/core").WritableSignal<readonly string[] | null>;
  protected htaText: string;
  constructor();
  protected errorFor(member: string): string | null;
  protected setIncludeRetired(value: boolean): void;
  protected loadLists(): void;
  protected addTerm(): void;
  protected addPlace(): void;
  protected addRegion(): void;
  protected retireTerm(row: BasisLocationTermRow): void;
  protected retirePlace(row: BasisLocationPlaceRow): void;
  protected retireRegion(row: BasisLocationRegionRow): void;
  protected loadSetting(): void;
  protected choosePlaceRule(value: string): void;
  protected chooseLegacyEdits(value: string): void;
  /** Saves the unit's rule, on its own `rowVersion` once it has a row. */
  protected saveSetting(): void;
  protected loadHta(): void;
  protected saveHta(): void;
  private showSetting;
  private read;
  /**
   * Sends a write and says how it came out. On a `409` the lists are read again, never the write
   * retried: retrying would overwrite the change the conflict just reported.
   */
  private write;
  static ɵfac: i0.ɵɵFactoryDeclaration<BasisLocationsPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BasisLocationsPageComponent, "cws-basis-locations-page", never, {
    "view": {
      "alias": "view";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/** The permission a template write needs (ADR-22 (6), T14). */
declare const TEMPLATES_MANAGE = "templates:manage";
/**
 * **Who may write contract templates, as the SPA reads `/me`** (2026-10-28, T14).
 *
 * `templates:manage` in the trade unit; `isAdmin` and an all-trade-units grant count (`holdsPermission`,
 * the server's `CallerPermissions.Has`). ⚠ A UI hint, never enforcement: the server decides.
 *
 * 🔴 **Unknown is not "no".** Without a `/me` source, or before it answers, the write actions stay
 * offered and the server answers for itself, the admin screens' rule since #696: hiding an Admin's
 * actions because `/me` was slow is the worse failure.
 */
declare class ContractTemplatesAccess {
  private readonly source;
  private readonly me;
  /** `/me`'s answer, or `undefined` while it is unknown. `null` while it is loading. */
  readonly known: import("@angular/core").Signal<boolean>;
  /** Whether the account may write templates in `tradeUnit`. */
  canManage(tradeUnit: string): boolean;
  /** The account's default trade unit, to open the list on, or `''`. */
  readonly defaultTradeUnit: import("@angular/core").Signal<string>;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractTemplatesAccess, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/** How many values a template sets: the list's "fields set". */
declare function fieldsSetOf(template: ContractTemplate): number;
/** How many fields a template asks for: the list's "fields to complete". */
declare function fieldsToCompleteOf(template: ContractTemplate): number;
type ListState = {
  readonly status: 'idle';
} | {
  readonly status: 'loading';
} | {
  readonly status: 'loaded';
  readonly templates: readonly ContractTemplate[];
} | {
  readonly status: 'error';
};
/**
 * **Contract templates, the list** (2026-10-28, T9).
 *
 * A trade unit's templates: name, how many fields each sets and asks for, when it was last used, and
 * who changed it last. New and Edit open the editor; Rename and Retire happen here, each under the
 * `If-Match` of the version listed, and a `409` says the template changed and reads the list again
 * rather than retrying a version this user has not seen (#872).
 *
 * Reads are open to any CWS user (C-14); the write actions need `templates:manage` in the trade unit
 * (T14), and without it the list says why and offers none.
 */
export declare class ContractTemplatesPageComponent {
  protected readonly source: import("@cws/domain-contracts").ContractTemplateSource | null;
  private readonly access;
  private readonly confirm;
  private readonly destroyRef;
  protected readonly tradeUnit: import("@angular/core").WritableSignal<string>;
  protected readonly list: import("@angular/core").WritableSignal<ListState>;
  protected readonly renaming: import("@angular/core").WritableSignal<number | null>;
  protected readonly renameText: import("@angular/core").WritableSignal<string>;
  protected readonly busy: import("@angular/core").WritableSignal<boolean>;
  protected readonly outcome: import("@angular/core").WritableSignal<string | null>;
  protected readonly outcomeFailed: import("@angular/core").WritableSignal<boolean>;
  protected readonly templates: import("@angular/core").Signal<readonly ContractTemplate[]>;
  protected readonly canManage: import("@angular/core").Signal<boolean>;
  protected readonly fieldsSet: typeof fieldsSetOf;
  protected readonly fieldsToComplete: typeof fieldsToCompleteOf;
  constructor();
  protected dated(value: string | null | undefined): string | null;
  protected startRename(template: ContractTemplate): void;
  /**
   * Renames under `If-Match`. PUT replaces the whole template (#872), so the values and the fields to
   * complete go back exactly as they were read.
   */
  protected saveRename(template: ContractTemplate): void;
  protected retire(template: ContractTemplate): void;
  /** A `409` means someone changed the template since it was listed: say so and read again, never retry. */
  private refused;
  private say;
  private load;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractTemplatesPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractTemplatesPageComponent, "cws-contract-templates-page", never, {}, {}, never, never, true, never>;
}
/** One row of the checklist (T11). */
interface ChecklistField {
  readonly componentName: string;
  readonly ctrmField: string;
  readonly label: string;
}
interface ChecklistSection {
  readonly id: string;
  readonly label: string;
  readonly fields: readonly ChecklistField[];
}
/**
 * **The contract template editor** (2026-10-28, T10 to T12, T4).
 *
 * 🔴 **The real contract form, and nothing that reaches CTRM.** `cms-contract-form` over the trade
 * unit's configuration, resolved exactly as a create resolves it: from the trade unit plus the
 * template's own contract type and commodity, re-resolved when either changes, the other values carried
 * across. Rules fire and lookups are live, and requiredness never blocks a save here. This component
 * injects no contract number, write or detail source, so no number is reserved, no pending contract is
 * made and nothing is written to CTRM.
 *
 * Beside the form, a checklist of every visible, writable field, grouped by section and searchable: the
 * fields a trader is asked to complete (T11). 🔴 **A required field the values leave blank is always
 * asked for (T4)**: checked and locked, from `validationSummary`, the computation that holds the create
 * screen's Save, so the two cannot disagree. A locked field that gains a value unlocks and keeps only
 * what the builder chose.
 */
export declare class ContractTemplateEditorComponent {
  private readonly templates;
  private readonly configs;
  private readonly host;
  private readonly access;
  private readonly destroyRef;
  /** The template's id, from the `:id` route; absent on New. */
  readonly id: import("@angular/core").InputSignal<string | undefined>;
  /** `?tradeUnit=`, from the list. On New it is the default; on Edit it says where to find the template. */
  readonly tradeUnitParam: import("@angular/core").InputSignal<string | undefined>;
  protected readonly tradeUnit: import("@angular/core").WritableSignal<string>;
  protected readonly name: import("@angular/core").WritableSignal<string>;
  /** The template as read or as last saved: what a save replaces, under its `If-Match`. */
  protected readonly current: import("@angular/core").WritableSignal<ContractTemplate | null>;
  protected readonly loadState: import("@angular/core").WritableSignal<"error" | "loading" | "loaded" | "missing" | "new">;
  /** The values the form is built from: the template's, then whatever was carried over a re-resolve. */
  protected readonly startingValues: import("@angular/core").WritableSignal<Readonly<Record<string, unknown>>>;
  private readonly drivers;
  /** The fields the builder checked, by component name. */
  protected readonly checked: import("@angular/core").WritableSignal<ReadonlySet<string>>;
  protected readonly search: import("@angular/core").WritableSignal<string>;
  protected readonly saving: import("@angular/core").WritableSignal<boolean>;
  protected readonly outcome: import("@angular/core").WritableSignal<string | null>;
  protected readonly outcomeFailed: import("@angular/core").WritableSignal<boolean>;
  protected readonly isNew: import("@angular/core").Signal<boolean>;
  protected readonly canManage: import("@angular/core").Signal<boolean>;
  private readonly resolutionKey;
  protected readonly configState: import("@angular/core").Signal<RemoteData<FormConfigBundle> | null>;
  /** The last loaded configuration, kept while a re-resolve is in flight, as the record screen does (#197). */
  protected readonly bundle: import("@angular/core").WritableSignal<FormConfigBundle | null>;
  /** Rebuilds the form when the configuration changes, never when it re-resolves to the same row. */
  protected readonly formKey: import("@angular/core").Signal<string>;
  protected readonly form: import("@angular/core").WritableSignal<ContractForm | null>;
  protected readonly presentation: import("@angular/core").Signal<import("@cws/shared-form-engine").FieldPresentationMaps>;
  protected readonly readOnlyFields: Readonly<Record<string, boolean>>;
  protected readonly wideFields: Readonly<Record<string, boolean>>;
  protected readonly groupHeadings: Readonly<Record<string, string>>;
  protected readonly fieldCtrmNames: Readonly<Record<string, string>>;
  protected readonly initialValues: import("@angular/core").Signal<Record<string, import("@cws/shared-form-engine").ContractFieldValue>>;
  /** Every visible, writable field of the resolved configuration, by section, in layout order (T3). */
  private readonly checklistAll;
  protected readonly checklist: import("@angular/core").Signal<readonly ChecklistSection[]>;
  /**
   * T4: the fields required and still blank, which a create from this template must therefore ask for.
   * `validationSummary`, filtered on `required`: the create screen filters the same items on `blocking`
   * too, which only adds "visible", and every checklist field is visible.
   */
  protected readonly locked: import("@angular/core").Signal<ReadonlySet<string>>;
  /**
   * Listed fields this form does not show (configured off for this trade unit, or hidden by a rule
   * right now), as CTRM names. 🔴 **Carried through a save rather than dropped**: losing them would
   * change what the template asks for without anyone choosing to, and the field may come back.
   */
  protected readonly carriedPrompts: import("@angular/core").Signal<readonly string[]>;
  /** What a save sends: every checked or locked field in layout order, then the carried ones. */
  protected readonly promptFields: import("@angular/core").Signal<readonly string[]>;
  /** T12: the existing deep link, once the template has an id. */
  protected readonly previewHref: import("@angular/core").Signal<string | null>;
  constructor();
  protected onTradeUnit(unit: string): void;
  protected onFormReady(form: ContractForm): void;
  protected isChecked(field: ChecklistField): boolean;
  protected toggle(field: ChecklistField, on: boolean): void;
  /** Saves the values on the form and the checked list; a template that exists is replaced under `If-Match`. */
  protected save(): void;
  private savedMessage;
  private refusal;
  private labelOf;
  private say;
  private open;
  static ɵfac: i0.ɵɵFactoryDeclaration<ContractTemplateEditorComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<ContractTemplateEditorComponent, "cws-contract-template-editor", never, {
    "id": {
      "alias": "id";
      "required": false;
      "isSignal": true;
    };
    "tradeUnitParam": {
      "alias": "tradeUnit";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * **The form builder's draft model** (the form builder, ruled 2026-10-28).
 *
 * Every change the builder makes is a pure operation, `apply(document, op, rules) -> document`. Nothing here
 * touches Angular or the DOM, so each operation and its inverse through undo is tested as a table, and the
 * canvas, the keyboard paths and the properties panel all go through the same functions.
 *
 * ### The rules carried over from the checkbox editor
 *
 * - A field the registry marks **not configurable** (the drivers, the contract number) cannot be hidden, and a
 *   system-required one cannot be made optional.
 * - **Required needs visible**: required on turns visible on; visible off turns required off. The server refuses
 *   the other combination (rule 2), so the builder never produces it.
 * - A field CTRM refuses on a write (**read-only**) cannot be required (rule 4).
 * - A field CTRM refuses **blank on every save** (`BuilderRules.ctrmRequired`, 2026-10-29) stays visible and
 *   required, as a driver does.
 * - A member of a **compound group** (the contract number's four boxes, `field-groups.ts`, 2026-10-29) stays
 *   visible. Its Required is left as stored: the suffix is usually blank and the number is issued by the system.
 *
 * ### Placement
 *
 * Every registry field always has an entry and a section. A field is **placed** when it is visible: the canvas
 * shows visible fields, and a hidden one is in the palette as "not placed" (F5). Dragging it onto the canvas
 * places it and makes it visible.
 */
/** The six flags, as the properties panel and the quick toggles set them. */
export type FieldFlags = Pick<ConfigFieldBehaviour, 'visible' | 'required' | 'readOnly' | 'borderWarning' | 'excludeFromCopy' | 'excludeFromTemplateCopy'>;
/** What an operation needs to know about the registry, to keep the editor's rules. */
export interface BuilderRules {
  readonly fields: Readonly<Record<string, RegistryField>>;
  /**
   * The fields, by component name, CTRM's write refuses blank on every save (2026-10-29): kept visible and
   * required. From the constraint document's `required` member, never hand-written. Absent locks nothing.
   */
  readonly ctrmRequired?: ReadonlySet<string>;
}
export type BuilderOp = {
  readonly kind: 'placeField';
  readonly field: string;
  readonly section: string;
  readonly index: number;
} | {
  readonly kind: 'moveField';
  readonly field: string;
  readonly section: string;
  readonly index: number;
} | {
  readonly kind: 'addTab';
  readonly label: string;
} | {
  readonly kind: 'renameTab';
  readonly tab: string;
  readonly label: string;
} | {
  readonly kind: 'moveTab';
  readonly tab: string;
  readonly index: number;
} | {
  readonly kind: 'deleteTab';
  readonly tab: string;
} | {
  readonly kind: 'addSection';
  readonly tab: string;
  readonly label: string;
} | {
  readonly kind: 'renameSection';
  readonly section: string;
  readonly label: string;
} | {
  readonly kind: 'moveSection';
  readonly section: string;
  readonly tab: string;
  readonly index: number;
} | {
  readonly kind: 'deleteSection';
  readonly section: string;
} | {
  readonly kind: 'setFieldFlags';
  readonly field: string;
  readonly flags: Partial<FieldFlags>;
} | {
  readonly kind: 'setPresentation';
  readonly field: string;
  readonly presentation: FieldPresentation;
} | {
  readonly kind: 'moveCollection';
  readonly collection: string;
  readonly tab: string;
} | {
  readonly kind: 'setCollectionFlags';
  readonly collection: string;
  readonly flags: Partial<Pick<ConfigCollectionBehaviour, 'excludeFromCopy' | 'excludeFromTemplateCopy'>>;
} | {
  readonly kind: 'setRemarkType';
  readonly code: string;
  readonly behaviour: ConfigRemarkTypeBehaviour;
} | {
  readonly kind: 'setHomeGridColumns';
  readonly columns: readonly string[] | undefined;
} | {
  readonly kind: 'setTabVisible';
  readonly tab: string;
  readonly visible: boolean;
} | {
  readonly kind: 'setSectionVisible';
  readonly section: string;
  readonly visible: boolean;
} | {
  readonly kind: 'setAttributes';
  readonly attributes: Partial<Pick<ConfigDocument['attributes'], 'autoCalculationMode' | 'pendingContractsEnabled'>>;
} | {
  readonly kind: 'replace';
  readonly document: ConfigDocument;
};
/** The three tabs the record screen appends itself. Never a user tab. */
export declare const SYSTEM_TAB_IDS: ReadonlySet<string>;
/** Applies one operation. An operation that cannot apply returns the document unchanged (same reference). */
export declare function apply(document: ConfigDocument, op: BuilderOp, rules: BuilderRules): ConfigDocument;
/** Tabs in display order. */
export declare function orderedTabs(document: ConfigDocument): readonly ConfigTab[];
/** A tab's sections in display order. */
export declare function sectionsOf(document: ConfigDocument, tab: string): readonly ConfigSection[];
/** A section's fields in display order, every field (placed or not). */
export declare function fieldsOf(document: ConfigDocument, section: string): readonly string[];
/** A section's placed (visible) fields in display order: what the canvas shows. */
export declare function placedFieldsOf(document: ConfigDocument, section: string): readonly string[];
/** Tabs with no sections, and sections with no placed field: allowed, flagged (F4). */
export declare function emptyItems(document: ConfigDocument): {
  readonly tabs: ReadonlySet<string>;
  readonly sections: ReadonlySet<string>;
};
/** The tab a collection block sits on in this document. */
export declare function blockTab(document: ConfigDocument, block: CollectionBlock): string;
/**
 * An id for a new tab or section, from its label: lower case, anything else a hyphen, at most 40 characters,
 * never a system tab, and suffixed `-2`, `-3`… on a clash. Never shown (F3).
 */
export declare function idFromLabel(label: string, taken: ReadonlySet<string>, fallback: string): string;
/** The most snapshots undo keeps (F9). */
export declare const UNDO_LIMIT = 100;
/**
 * Undo and redo over document snapshots. Framework-free; the page keeps one in a signal.
 *
 * ⚠ A no-op operation (one that returns the same document) records nothing, so Undo is never a press that
 * appears to do nothing.
 */
export declare class BuilderHistory {
  readonly present: ConfigDocument;
  private readonly past;
  private readonly future;
  private constructor();
  static start(document: ConfigDocument): BuilderHistory;
  get canUndo(): boolean;
  get canRedo(): boolean;
  /** How many undo steps are held. */
  get depth(): number;
  apply(op: BuilderOp, rules: BuilderRules): BuilderHistory;
  undo(): BuilderHistory;
  redo(): BuilderHistory;
}
/** One destination in the menu's "Move to" list. `current` is where the item sits now, offered disabled. */
interface BuilderMenuTarget {
  readonly id: string;
  readonly label: string;
  readonly current?: boolean;
}
/** One action in the menu. A `refusal` disables it and is shown as text under its label, as `cms-row-menu` does. */
interface BuilderMenuAction {
  readonly label: string;
  readonly run: () => void;
  readonly refusal?: string | null;
  /** Listed last, after the destinations, in red. */
  readonly destructive?: boolean;
}
/**
 * **A canvas item's secondary actions behind a ⋯ button** (the form builder, 2026-10-29): a field's, a section's
 * or a grid's "Move to", and the actions that are not worth a button on every row.
 *
 * ### Why not `cms-row-menu`
 *
 * `cms-row-menu` is a flat list of actions, and "Move to" needs its destinations, which can be a dozen sections.
 * So this is the same CDK menu with the same `scoular-dropdown` look, with the destinations as a labelled group
 * that scrolls inside the menu. The CDK supplies the menu pattern: arrow keys between items, Escape back to the
 * button, a click elsewhere closing it, and an overlay the builder's scrolling columns cannot clip.
 *
 * ⚠ **A group, not a submenu.** A CDK submenu opens on mouseenter and its trigger toggles on click, so pointing
 * at "Move to" and clicking it opens and at once closes the destinations.
 *
 * 🔴 A refused action stays in the menu, disabled, with its reason as text (#816's rule); `cdkMenuItemDisabled`
 * keeps it focusable, and {@link runAction} checks again.
 */
declare class BuilderItemMenuComponent {
  /** The button's accessible name, naming the item: "Actions for Trade unit". */
  readonly label: import("@angular/core").InputSignal<string>;
  /** The destinations' heading and group name: "Move to", "Move to tab". */
  readonly moveLabel: import("@angular/core").InputSignal<string>;
  /** Where the item can move. None leaves the group out. */
  readonly targets: import("@angular/core").InputSignal<readonly BuilderMenuTarget[]>;
  readonly actions: import("@angular/core").InputSignal<readonly BuilderMenuAction[]>;
  /** A destination was chosen. */
  readonly moveTo: import("@angular/core").OutputEmitterRef<string>;
  /** The actions before the destinations; the destructive ones come after them. */
  protected readonly leading: import("@angular/core").Signal<BuilderMenuAction[]>;
  protected readonly trailing: import("@angular/core").Signal<BuilderMenuAction[]>;
  protected runAction(action: BuilderMenuAction): void;
  protected choose(target: BuilderMenuTarget): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<BuilderItemMenuComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<BuilderItemMenuComponent, "cms-builder-item-menu", never, {
    "label": {
      "alias": "label";
      "required": true;
      "isSignal": true;
    };
    "moveLabel": {
      "alias": "moveLabel";
      "required": false;
      "isSignal": true;
    };
    "targets": {
      "alias": "targets";
      "required": false;
      "isSignal": true;
    };
    "actions": {
      "alias": "actions";
      "required": false;
      "isSignal": true;
    };
  }, {
    "moveTo": "moveTo";
  }, never, never, true, never>;
}
/** The permission a configuration write needs in the trade unit, as the routes require (F16). */
export declare const SETTINGS_MANAGE = "settings:manage";
/** How long a dragged field or section rests over a tab before the tab is shown, so it can land in a section there. */
export declare const TAB_HOVER_MS = 600;
/** What the builder is editing: dimensions, each blank for "any". */
export interface BuilderDimensions {
  readonly contractTypeClass: string;
  readonly locationCode: string;
  readonly commodityCode: string;
}
/** What is selected on the canvas, for the keyboard paths and the properties panel. */
export type BuilderSelection = {
  readonly kind: 'field';
  readonly id: string;
} | {
  readonly kind: 'section';
  readonly id: string;
} | {
  readonly kind: 'tab';
  readonly id: string;
} | {
  readonly kind: 'block';
  readonly id: string;
};
/** A drag source, read off `data-drag` and `data-id`. */
interface DragSource {
  readonly kind: 'field' | 'palette' | 'section' | 'tab' | 'block';
  readonly id: string;
}
/** A drop target, read off `data-drop`. `key` identifies the element for the insertion marker. */
interface DropTarget {
  readonly kind: 'field' | 'section-end' | 'section' | 'tab' | 'tab-end';
  readonly key: string;
  readonly section?: string;
  readonly tab?: string;
  readonly index: number;
}
type LoadState = 'idle' | 'loading' | 'loaded' | 'error';
type PaletteFilter = 'all' | 'unplaced' | 'placed';
/** One field in the palette: `place` is "Tab › Section" when it is on the form, `null` when it is not. */
interface PaletteEntry {
  readonly id: string;
  readonly label: string;
  readonly place: string | null;
}
/**
 * **The form builder** (ruled by JFrisbie 2026-10-28, F1 to F20): the form-configuration screen as a
 * drag-and-drop canvas over the configuration model that exists today.
 *
 * ### What it edits
 *
 * The row at the chosen dimensions (F1). When there is none yet, the canvas starts from what those dimensions
 * resolve to, badged as inherited, and the first save creates the row. Every change is a pure operation from
 * `builder-document.ts`, held in an undo history (F9); nothing is written until Save.
 *
 * ### One gesture for the palette and the canvas
 *
 * The shared pointer-drag helper (F11, never HTML5 drag-and-drop: Known Issue 44) is attached to the builder's
 * container, so a palette entry, a field card, a section header, a tab chip and a collection block are all
 * sources of one gesture, read off `data-drag`, and every drop target is read off `data-drop`. The container is
 * `select-none`, which the helper cannot apply itself. Every drag has a keyboard path: the selected item moves
 * with Alt and the arrow keys, and "Move to…" lists every destination.
 */
export declare class FormBuilderPageComponent {
  private readonly source;
  private readonly meSource;
  private readonly constraintSource;
  private readonly route;
  private readonly router;
  private readonly destroyRef;
  /** The builder's own dialogs, in place of the browser's `prompt` and `confirm` (2026-10-28). */
  private readonly confirm;
  private readonly prompt;
  private readonly importDialog;
  private readonly dom;
  protected readonly area: import("@cws/features-admin").AdminArea;
  protected readonly blocks: readonly CollectionBlock[];
  /** What the pickers hold; applied with Open so a half-typed code does not load a row per keystroke. */
  protected readonly typeInput: import("@angular/core").WritableSignal<string>;
  protected readonly locationInput: import("@angular/core").WritableSignal<string>;
  protected readonly commodityInput: import("@angular/core").WritableSignal<string>;
  /** The dimensions the canvas is open on, or `null` before the first Open and after Discard. */
  readonly dimensions: import("@angular/core").WritableSignal<BuilderDimensions | null>;
  /**
   * Whether a form is open (or opening) on the canvas. While it is, the builder takes the section's whole width:
   * its heading goes screen-reader only, the area's tabs and the pickers step aside, and `AdminLayout` hides the
   * section's navigation. Discard is the way back. A load that fails returns to the pickers.
   */
  protected readonly editing: import("@angular/core").Signal<boolean>;
  /** The open dimensions as the toolbar names them, since the pickers are out of sight. */
  protected readonly openedOn: import("@angular/core").Signal<string>;
  protected readonly registry: import("@angular/core").WritableSignal<FormConfigRegistry | null>;
  protected readonly rows: import("@angular/core").WritableSignal<readonly FormConfigRow[]>;
  protected readonly loadState: import("@angular/core").WritableSignal<LoadState>;
  protected readonly loadError: import("@angular/core").WritableSignal<string | null>;
  /** The row at exactly these dimensions, or `null` when saving will create it. */
  readonly ownRow: import("@angular/core").WritableSignal<FormConfigDetail | null>;
  /** Where an inherited canvas came from, for the badge: a row id, or `null` for the built-in default. */
  protected readonly inheritedFrom: import("@angular/core").WritableSignal<number | null>;
  /** The document the canvas opened on: Discard returns to it, and the badges compare against it. */
  private readonly baseline;
  readonly history: import("@angular/core").WritableSignal<BuilderHistory | null>;
  /**
   * The draft as the canvas, the panels and Save see it: the history's present with every lock applied
   * (2026-10-29). A stored row that left a CTRM-required field optional or hidden is shown required and visible,
   * and saved that way, while the history and the baseline keep what was read, so opening it is not a change.
   */
  readonly document: import("@angular/core").Signal<ConfigDocument | null>;
  readonly dirty: import("@angular/core").Signal<boolean>;
  /**
   * The CTRM constraint document, for the fields its write refuses blank on every save (2026-10-29). `null`
   * without a source or when it cannot be read, which locks nothing: the server is still the judge.
   */
  private readonly constraintDocument;
  /** Those fields, by component name: Visible and Required locked on, Remove refused. */
  readonly ctrmRequired: import("@angular/core").Signal<ReadonlySet<string>>;
  protected readonly ctrmRequiredReason = "Required by CTRM on every save";
  protected readonly rules: import("@angular/core").Signal<BuilderRules>;
  /** The tab the canvas shows. */
  readonly activeTab: import("@angular/core").WritableSignal<string | null>;
  readonly selection: import("@angular/core").WritableSignal<BuilderSelection | null>;
  /**
   * The editing panel above the preview: the selected item's properties, the trade unit's settings, or closed.
   * The live preview (F10) is not one of the choices: it stays mounted and on screen beside the canvas, so
   * editing a property shows its effect without switching away (2026-10-29).
   */
  readonly inspector: import("@angular/core").WritableSignal<"properties" | "settings" | null>;
  protected readonly inspectorViews: ({
    id: "properties";
    label: string;
  } | {
    id: "settings";
    label: string;
  })[];
  /** Opens a panel, or closes it when it is the one open. */
  protected toggleInspector(view: 'properties' | 'settings'): void;
  /** The dimensions as the preview resolves them: blank is any, so absent. */
  protected readonly resolutionKey: import("@angular/core").Signal<FormConfigResolutionKey>;
  /** The server's problems with the draft, from the preview (F2), keyed as a save's are. */
  readonly problems: import("@angular/core").WritableSignal<Readonly<Record<string, readonly string[]>> | null>;
  /** Canvas items a refusal names, so each is marked where it sits. */
  protected readonly invalid: import("@angular/core").Signal<{
    fields: Set<string>;
    sections: Set<string>;
    collections: Set<string>;
    tabs: boolean;
  }>;
  protected readonly tabs: import("@angular/core").Signal<readonly import("@cws/domain-contracts").ConfigTab[]>;
  protected readonly shownTab: import("@angular/core").Signal<string>;
  protected readonly shownSections: import("@angular/core").Signal<{
    fields: readonly string[];
    id: string;
    label: string;
    tab: string;
    order: number;
    visible: boolean;
  }[]>;
  /** The collection blocks on the shown tab (F8). */
  protected readonly shownBlocks: import("@angular/core").Signal<CollectionBlock[]>;
  protected readonly empty: import("@angular/core").Signal<{
    readonly tabs: ReadonlySet<string>;
    readonly sections: ReadonlySet<string>;
  }>;
  /** Items that differ from what the canvas opened on (F1's "edited here"). */
  protected readonly changed: import("@angular/core").Signal<{
    readonly fields: ReadonlySet<string>;
    readonly sections: ReadonlySet<string>;
    readonly tabs: ReadonlySet<string>;
  }>;
  /** The badge an unchanged item carries while the dimensions have no row of their own (F1). */
  protected readonly inheritedBadge: import("@angular/core").Signal<string | null>;
  protected readonly paletteSearch: import("@angular/core").WritableSignal<string>;
  /** Which fields the palette lists: every one, only those not on the form, or only those on it. */
  readonly paletteFilter: import("@angular/core").WritableSignal<PaletteFilter>;
  protected readonly paletteFilters: readonly {
    readonly id: PaletteFilter;
    readonly label: string;
  }[];
  /** The registry groups folded shut. A search shows its matches in every group regardless. */
  protected readonly collapsedGroups: import("@angular/core").WritableSignal<ReadonlySet<string>>;
  protected readonly searching: import("@angular/core").Signal<boolean>;
  protected toggleGroup(group: string): void;
  /**
   * Every registry field the search and the filter let through, grouped by its registry section, with where it
   * is placed now. Placement is the model's own rule, not an inference: a field is placed when it is visible in
   * a section that exists, and a field has exactly one entry, so it is placed once or not at all.
   */
  protected readonly palette: import("@angular/core").Signal<{
    id: string;
    label: string;
    expanded: boolean;
    fields: PaletteEntry[];
  }[]>;
  /** A compound group's members after its first, which the canvas and the palette show as the group's one item. */
  private readonly foldedMembers;
  /** The palette's item count, for its "placed of" line: a compound group counts once. */
  protected readonly fieldCount: import("@angular/core").Signal<number>;
  protected readonly placedCount: import("@angular/core").Signal<number>;
  /**
   * The grids (collection blocks) the search and the filter let through, as one more palette group (2026-10-29).
   * A grid is placed when the tab it sits on is one of the form's: the configuration's `tab`, else its layout tab.
   * A form without that tab and no placement shows the grid nowhere, so it is Unplaced, and Place puts it on a tab.
   */
  protected readonly paletteGrids: import("@angular/core").Signal<{
    id: string;
    label: string;
    expanded: boolean;
    grids: PaletteEntry[];
  } | null>;
  /** Places an unplaced grid on the shown tab, the palette's keyboard path for a grid. */
  protected placeGrid(collection: string): void;
  private readonly me;
  /**
   * Whether this account may save the open dimensions. A row for every trade unit needs the permission
   * everywhere, as the routes require. With no `/me` source (a host without it) the server stays the judge.
   */
  readonly canWrite: import("@angular/core").Signal<boolean>;
  protected readonly saving: import("@angular/core").WritableSignal<boolean>;
  protected readonly outcome: import("@angular/core").WritableSignal<{
    readonly text: string;
    readonly failed: boolean;
    readonly conflict: boolean;
  } | null>;
  /** The drop target the pointer is over, for the insertion marker. */
  protected readonly overKey: import("@angular/core").WritableSignal<string | null>;
  protected readonly dragging: import("@angular/core").WritableSignal<DragSource | null>;
  private readonly gesture;
  protected readonly readOnly: import("@angular/core").Signal<boolean>;
  /** The section's layout, when the builder is mounted under `AdminPageComponent`; absent on its own. */
  private readonly layout;
  constructor();
  /** Opens the canvas on the pickers' dimensions, asking first when there are unsaved changes. */
  open(): void;
  private load;
  private start;
  private fail;
  protected reloadRows(): void;
  /** Applies one operation to the draft. Every canvas, keyboard and panel change comes through here. */
  run(op: BuilderOp): void;
  undo(): void;
  redo(): void;
  /**
   * Drops the draft and closes the builder, back to the pickers as they were before Open (their values kept) and
   * the section's navigation. Offered with no changes too, as the way back from the full-width canvas; nothing
   * was written, so there is nothing to ask. Opening again reads the saved form.
   */
  discard(): void;
  protected addTab(): void;
  protected renameTab(tab: string, current: string): void;
  protected deleteTab(tab: string, label: string): void;
  protected addSection(tab: string): void;
  protected renameSection(section: string, current: string): void;
  protected deleteSection(section: string, label: string): void;
  /** Asks for a name in the builder's dialog; `then` runs with it, and Cancel changes nothing. */
  private ask;
  /** Asks before a delete in the shared confirmation, styled destructive; `then` runs on Confirm only. */
  private confirmDelete;
  /**
   * Where the palette's Place puts a field: the selected section, the selected field's section, or the shown
   * tab's first section. The palette names it, so the keyboard path says where it goes.
   */
  protected readonly placeTarget: import("@angular/core").Signal<{
    id: string;
    label: string;
  } | null>;
  /** Places a palette field at the end of {@link placeTarget} (Enter). */
  protected placeFromPalette(field: string): void;
  protected toggleVisible(field: string): void;
  /**
   * Takes a field off the canvas, back to the palette (Remove from form, in its row's menu). In this model a field is
   * placed when it is visible, so a remove hides it: it keeps its section and order, so Place returns it there,
   * and as one operation it is undoable and counts as an unsaved change. Required goes off with it (rule 2).
   */
  protected removeField(field: string): void;
  /**
   * Why a field cannot come off the canvas, or `null` when it can. A field the registry marks not configurable
   * (a driver, the contract number) is always on the contract form (rule 3), so its menu item is disabled, saying so.
   */
  protected removeBlocked(field: string): string | null;
  /**
   * Why a canvas row that is a compound group (the contract number) cannot be hidden, made optional or removed, or
   * `null` for any other row. The group is always shown and required: the contract key as a whole is required.
   */
  protected groupLock(row: string): string | null;
  /** A canvas row's name: a compound group's heading, else the field's label. */
  protected rowLabel(row: string): string;
  /** The fields a canvas row stands for, for its "edited" and refusal marks. */
  private membersOf;
  protected rowChanged(row: string): boolean;
  protected rowInvalid(row: string): boolean;
  /**
   * What the properties panel is given: the selection, except a compound group's row, which has no properties of
   * its own to set (its members' widths are fixed and its heading is the layout's).
   */
  protected readonly propertiesSelection: import("@angular/core").Signal<BuilderSelection | null>;
  protected toggleRequired(field: string): void;
  /** What a drop means. `null` when the pair means nothing (a tab onto a field). */
  dropOp(source: DragSource, target: DropTarget): BuilderOp | null;
  protected onPointerDown(event: PointerEvent): void;
  /** The tab a dragged item is resting over, and the timer that will show it. */
  private tabHover;
  /**
   * A field, a section or a grid resting over another tab for {@link TAB_HOVER_MS} shows that tab, so the drag
   * can go on into one of its sections. A tab being reordered never switches the shown tab.
   */
  private hoverTab;
  private clearTabHover;
  /** Whether a field (from the canvas or the palette) is being dragged, which turns each section's end into a drop zone. */
  protected readonly fieldDrag: import("@angular/core").Signal<boolean>;
  protected onKeydown(event: KeyboardEvent): void;
  /** Alt and an arrow on the selected item: up and down within its parent, left and right to the next parent. */
  keyboardOp(key: string): BuilderOp | null;
  /** The "Move to…" destinations for the selected field: every section, labelled with its tab. */
  protected readonly moveTargets: import("@angular/core").Signal<{
    id: string;
    label: string;
  }[]>;
  /** The tab the canvas shows, with its label. */
  protected readonly shownTabInfo: import("@angular/core").Signal<import("@cws/domain-contracts").ConfigTab | null>;
  /** Each section's "Move to" destinations for its fields: every section, its own marked as where they are. */
  protected readonly sectionTargets: import("@angular/core").Signal<Map<string, readonly BuilderMenuTarget[]>>;
  /** Each tab's "Move to tab" destinations for its sections and grids: every tab, its own marked. */
  protected readonly tabTargets: import("@angular/core").Signal<Map<string, readonly BuilderMenuTarget[]>>;
  /**
   * Each placed field's ⋯ actions besides Move to: its properties, a step up or down (the menu's form of Alt and
   * an arrow), and Remove, which hides it back to the palette and is refused, saying why, on a field every
   * contract form shows.
   */
  protected readonly fieldActions: import("@angular/core").Signal<Map<string, readonly BuilderMenuAction[]>>;
  /** Each section's ⋯ actions besides Move to tab. */
  protected readonly sectionActions: import("@angular/core").Signal<Map<string, readonly BuilderMenuAction[]>>;
  /** A grid's ⋯ actions besides Move to tab: Remove, refused with the reason, since a grid cannot be hidden. */
  protected readonly gridActions: readonly BuilderMenuAction[];
  private readonly paletteSearchInput;
  /**
   * "+ Add field" under a section: selects the section, so the palette's Place puts a field there, lists the
   * fields not yet on the form, and takes the focus to the palette's search.
   */
  protected addFieldTo(section: string): void;
  /** Moves a canvas row (a field, or a compound group whole) to the end of a section. */
  protected moveFieldTo(field: string, section: string): void;
  private runOp;
  protected moveSectionTo(section: string, tab: string): void;
  protected moveBlockTo(block: CollectionBlock, tab: string): void;
  protected select(selection: BuilderSelection, event?: Event): void;
  protected isSelected(kind: BuilderSelection['kind'], id: string): boolean;
  protected fieldLabel(field: string): string;
  protected fieldBehaviour(field: string): import("@cws/domain-contracts").ConfigFieldBehaviour | undefined;
  protected allFieldsOf(section: string): readonly string[];
  /** Rows other than this one, to start from. */
  protected readonly seedRows: import("@angular/core").Signal<FormConfigRow[]>;
  /** What Scratch leaves on the form, for the option's title and the note after it runs. */
  protected readonly scratchDescription = "One new tab and section with only the fields every contract form shows. Every other field is Unplaced in the field list, ready to drag in.";
  /** Replaces the draft with another row's document, the default, or a scratch form. Undoable. */
  protected seedFrom(rowId: string): void;
  /** The download's file name, from the open dimensions: `form-config-any-0210-any.json`. */
  protected jsonFileName(): string;
  /**
   * Copies the draft as JSON: the document a Save would send, with the locks and the registry filter applied, so it
   * imports back to the same draft. A refused clipboard downloads it instead, saying so.
   */
  copyJson(): Promise<void>;
  /** Downloads the draft as JSON, through a Blob and an object URL (no inline script, so the CSP allows it). */
  downloadJson(): void;
  /**
   * Opens Import JSON. A document that passes the dialog's checks replaces the draft as one operation, so it is
   * undoable, counts as unsaved, and the live preview shows it; the server stays the judge on Save.
   */
  protected importJson(): void;
  save(): void;
  /** After a 409: read the row again, discarding the draft (the change it would have overwritten wins). */
  protected reloadAfterConflict(): void;
  /**
   * The route guard's question. `true` lets the navigation go. A plain `true` when nothing is unsaved, so an
   * unguarded navigation stays immediate; otherwise the shared confirmation's answer.
   */
  canLeave(): Observable<boolean> | boolean;
  protected onBeforeUnload(event: BeforeUnloadEvent): void;
  private confirmDiscard;
  protected openRows(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<FormBuilderPageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<FormBuilderPageComponent, "cms-form-builder-page", never, {}, {}, never, never, true, never>;
}
/** The unsaved-changes guard for the builder's route (F9). */
export declare const formBuilderLeaveGuard: (component: FormBuilderPageComponent) => Observable<boolean> | boolean;
/**
 * **The values the form builder's preview renders with** (the form builder, 2026-10-28, F10), keyed by
 * component name.
 *
 * A host that has a sample contract provides it (the playground provides its sample record's values); without
 * one the preview uses {@link BUILT_IN_SAMPLE_VALUES}, so the pane is never a form of blanks. The values only
 * illustrate the layout: nothing is saved, and none of them is a real contract, customer or person.
 */
export declare const FORM_BUILDER_SAMPLE_VALUES: InjectionToken<Readonly<Record<string, unknown>>>;
/** Invented values for the commonest fields. Never live data (CLAUDE.md). */
export declare const BUILT_IN_SAMPLE_VALUES: Readonly<Record<string, unknown>>;
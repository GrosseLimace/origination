import { ContractListPage, ContractListQuery, ContractListStatus, ContractSummary, contractRowTone } from "@cws/domain-contracts";
import { AppliedView, ExportField, ExportOutcome, FilterGroup, GridColumn, GridColumnsKeptIn, GridRowAction, GridSort, MutationOutcome, RemoteData, ServerExport } from "@cws/shared-ui";
import * as i0 from "@angular/core";
/**
 * **The contract workspace's portfolio cards** — what the book looks like, before the rows.
 *
 * Modelled on the approval queue's `approvalMetrics` and deliberately sharing its vocabulary: the two
 * screens sit one click apart, so a figure that means something different on each is worse than a
 * figure missing from one.
 *
 * ### 🔴 Every card states the BASIS of its figure, because this screen never holds the whole book
 *
 * `DEFAULT_PAGE_SIZE` is 50 and `MAX_PAGE_SIZE` is 200, and the page size is escalated only while
 * filtering locally — so against a trade unit with 880 open contracts this screen holds at most 200
 * of them, and `home-page.component.ts` says so in as many words: *"Neither size makes this
 * complete."*
 *
 * A card summing quantity over the rows held would therefore total 50 of 880 and present it as the
 * portfolio. That is the complete-looking-but-incomplete answer this project keeps recording — the
 * same shape as CR-4's truncated read and as a grid that sorts one page and calls itself sorted.
 *
 * So the counts come from the **denominator the footer already uses** (the server's `totalCount`, or
 * the matched count while filtering locally), and every derived figure names how many contracts it
 * covers when that is fewer than the whole set.
 *
 * 🔑 **The real fix is a server-side aggregate and it is not ours.** `ContractListProjector` already
 * fetches and filters the entire status set in process, so it holds every row these cards want to
 * total. Four numbers on the envelope would make all five complete. Proposed, not built.
 *
 * ### ⚠ Quantity is NOT summed across units
 *
 * Every row carries its own `quantityUom`. Adding bushels to pounds is wrong by a factor of 56 and
 * looks entirely plausible — CTRM stores pounds where the API returns bushels, measured 2026-09-02.
 * Where the set is one unit the total is stated with it; where it is mixed the card **refuses to
 * state a total**, because a guessed figure is worse than an absent one. Same rule, same reason, as
 * the approval queue.
 *
 * ### ⚠ "Needs attention" is the grid's own definition, not a second one
 *
 * It counts the rows {@link contractRowTone} tints. That function is what decides a row is
 * actionable today, so the card and the tinted rows cannot disagree — a card reading 5 above three
 * tinted rows would read as the card being broken. It follows that a status CTRM sends that we have
 * never seen does NOT count: unknown values are deliberately neutral there, because telling a trader
 * a contract needs attention on no evidence is the dangerous direction.
 */
interface PortfolioMetric {
  /** Card heading. */
  readonly label: string;
  /** The figure, already formatted. `'—'` where no honest figure exists. */
  readonly value: string;
  /**
   * What the figure covers, in a few words.
   *
   * 🔴 **Load-bearing rather than decoration.** On the derived cards it carries the definition, and
   * on the totals it carries how much of the book the figure covers. A reader who takes a partial
   * total for the portfolio total would quote it in a meeting.
   */
  readonly hint: string;
  /** Draws attention. Reserved for the cards that mean "act on this", and only when non-zero. */
  readonly urgent?: boolean;
}
/** Ship periods opening within this many days count as imminent. */
declare const SHIPPING_SOON_DAYS = 30;
/**
 * Builds the five cards.
 *
 * @param rows The contracts this screen is holding, already filtered and searched.
 * @param total The denominator the footer reports — the server's count, or the matched count while
 *   filtering locally. Passed in rather than derived here so the card and the footer cannot drift.
 * @param today The day to measure ship periods against. An argument, so this stays a pure function
 *   with deterministic tests and only the caller knows what day it is.
 * @param status Which list the rows came from. It chooses the CTRM procedure that answered, so the
 *   count card names it: the closed list read "Open contracts" on the QA walk (#841).
 */
declare function contractPortfolioMetrics(rows: readonly ContractSummary[], total: number, today: Date, status?: ContractListStatus): readonly PortfolioMetric[];
/**
 * **F4.1a — the home contract workspace** (docs/02 §2, docs/02a §6.1).
 *
 * The grid is the trader's operating hub, so the important behaviour here is what happens *before*
 * there are rows: `contract/list` requires a `location` or `customer`, so with no active trade unit
 * the grid **cannot be called at all** (#40 finding 2, correction C-15). That is a hard precondition,
 * not a default — so this page renders a typed empty state with the trade-unit choice as its primary
 * action and issues no request until one is chosen. Building it the other way round passes locally
 * against the simulator and fails entirely on live data.
 *
 * Three deliberate limits, each recorded because each looks like an omission:
 *
 * 1. **The trade unit is the shell's, not this screen's.** It arrives through
 *    `TRADE_UNIT_CONTEXT` because switching it re-resolves form config, permissions and reference
 *    data (docs/02 §1.1) — a copy held here could disagree with the contract form. The screen still
 *    reads the location *list*, but only to name the active scope in its heading.
 * 2. **Sorting asks the server to order the whole result set, and says so when it did not.** The sort
 *    chain is part of the query, so a header click re-issues the request with `sort=price:desc,…`; the
 *    response's `appliedSort` is what confirms the server ordered all 880 rows rather than the 50 it
 *    handed back. Until the API gains that parameter it ignores it silently and the grid falls back to
 *    ordering the loaded page, with {@link sortScopeNote} on screen saying so. The client-side sort is
 *    kept in both states deliberately — see {@link sortRows}.
 * 3. 🔴 **Status is no longer selectable, and the grid therefore shows OPEN contracts only.**
 *    The dropdown was removed at JFrisbie's direction on 2026-09-10, and the consequence was raised
 *    before it was: status chose which CTRM *procedure* the request reached, so removing the control
 *    does not widen the view — it fixes it. **Closed and unapproved contracts are unreachable from
 *    this screen.** `query().status` still carries the value, {@link fromRouteParams} still reads it
 *    and the request still sends it, so restoring a control is a template change; nothing about the
 *    request plumbing was deleted.
 */
export declare class HomePageComponent {
  private readonly source;
  /**
   * #888: the save that a Save-and-close from a record opened here left for this grid. Taken once,
   * as the screen is built, so a reload or a later visit does not say it again.
   */
  protected readonly arrivedAfterSave: import("@angular/core").WritableSignal<MutationOutcome | null>;
  /**
   * The server export (F4.3c), or `null` where none is provided.
   *
   * Optional on purpose: a host that provides no export source gets the in-screen export this page
   * always had, and the note still says which path ran. The shell provides the HTTP one; the
   * playground and the tests decide for themselves.
   */
  private readonly exportSource;
  private readonly locationSource;
  /**
   * The active trade unit, owned by the shell (docs/02 §1.1).
   *
   * Read through a token rather than held here: switching re-resolves form config, permissions
   * and reference data, so it is application context. A copy on this screen could disagree with
   * the contract form about which unit is active.
   */
  private readonly tradeUnit;
  private readonly permissions;
  /**
   * The row actions of docs/02 §2.2 this caller may use — Open is not among them, because Open
   * is the row itself.
   *
   * 🔴 **An empty array removes the column entirely**, which is the behaviour being relied on:
   * `DataGridComponent.hasActions` is `actions().length > 0`, so a reader with no write rights
   * gets a grid of the same shape they had before this existed rather than a column of refusals.
   * A disabled Edit on every row of a 50-row page is 50 promises the account cannot keep.
   *
   * ⚠ **Row ACTIVATION is deliberately not gated.** Double-click and Enter open the record for
   * everyone, because reading a contract needs only `User` (correction C-14 keeps reads
   * un-scoped). Gating the actions and the activation together would be the easy mistake and
   * would make the workspace useless to the population it is mostly for.
   *
   * ✅ **§2.2's other Edit gate — disabled for a Closed contract and for an intercompany purchase —
   * is built (F4.3a criterion (a)), and it is the OPPOSITE shape from the gating above on purpose.**
   * Unavailable to *this account* is hidden, per the paragraph above. Unavailable to *everyone* is
   * disabled with the reason as the button's title, because "why not this one" is the first
   * question on a grid where some rows can be edited and some cannot. The rule is
   * `editRefusalFor` in `@cws/domain-contracts`, keyed on the row's own `isClosed` and
   * `isIntercompany` — never derived from the status filter, which would be a different rule
   * wearing the same name — and an unknown intercompany verdict leaves Edit live (fail open).
   * The grid's access-key path honours the same refusal, so the letter is dead where the button is.
   *
   * ⚠ Copy is deliberately NOT gated the same way, though §2.2 reads *"same as Edit"* for it. Copying
   * a closed contract into a new one is a plausible use, so that reading is raised for a ruling
   * rather than applied literally.
   */
  protected readonly rowActions: import("@angular/core").Signal<readonly GridRowAction<ContractSummary>[]>;
  /** docs/02a §7's band, measured on this screen's own box rather than the window (§8). */
  private readonly layoutRoot;
  protected readonly layoutBand: import("@angular/core").Signal<import("@cws/shared-ui").LayoutBand>;
  /**
   * Every way out of this grid (E9 PR 4, F9.10). The screen states an intent and the host's route
   * table decides where it goes, so a workspace mounted under a host's prefix stays inside it.
   */
  private readonly hostContext;
  /**
   * 🔴 **Only for the same-page query write below, and the source-scan guard allows nothing else.**
   * `navigate([], { relativeTo })` keeps the current path, prefix included, which
   * `home-page.prefix.spec.ts` proves under `/workbench/cws`. Leaving the grid goes through
   * {@link hostContext}.
   */
  private readonly router;
  private readonly route;
  /**
   * Every column the grid defines. Search, the filter builder and sorting read THIS set, never the
   * visible one: tying search to column configuration would make the same query find different rows
   * for different users, which was declined on purpose (see the template's search note).
   */
  protected readonly columns: readonly GridColumn<ContractSummary>[];
  /**
   * What the export offers: the grid's columns plus Customer name, directly after Customer ID (#768).
   * The grid shows the customer as one column (the id); the file carries the id and the name.
   */
  protected readonly exportColumns: readonly GridColumn<ContractSummary>[];
  /** Optional: a host without them shows every column, exactly as before #748. */
  private readonly tradeUnitColumnsSource;
  private readonly columnPreference;
  private readonly allColumnKeys;
  private readonly activeTradeUnit;
  /** The trade unit's `homeGridColumns`, or `null` for every column (absent, loading or failed). */
  private readonly tradeUnitColumns;
  /** The stored choice for the active trade unit, re-read whenever the trade unit changes. */
  private readonly storedUserColumns;
  /** The user's choice: the stored one, until they change it on this screen. */
  private readonly userColumns;
  /** Where the last change on this screen was kept, for the menu's status line. */
  protected readonly columnsKeptIn: import("@angular/core").WritableSignal<GridColumnsKeptIn>;
  /** #803: the reference a column choice kept nowhere carries, or why it has none. */
  protected readonly columnsFailure: import("@angular/core").WritableSignal<{
    readonly correlationId: string | null;
    readonly sent: boolean;
  } | null>;
  /**
   * docs/02a §7's priority columns, applied below 1300 (#759). `null` in the full layout. A choice
   * made in the Columns menu wins over it at every width.
   */
  private readonly condensedColumnKeys;
  /** The visible keys, in display order. */
  protected readonly visibleColumnKeys: import("@angular/core").Signal<string[]>;
  /**
   * The export's starting fields (#768): the visible keys, with Customer name ticked directly after
   * Customer ID whenever the grid shows the customer. A hidden customer leaves both unticked.
   */
  protected readonly exportVisibleKeys: import("@angular/core").Signal<string[]>;
  /** What the grid renders. */
  protected readonly visibleColumns: import("@angular/core").Signal<GridColumn<ContractSummary>[]>;
  /** What the column menu lists: every allowed column, shown first in display order. */
  protected readonly columnMenuFields: import("@angular/core").Signal<readonly ExportField[]>;
  protected readonly lockedColumnKeys: readonly string[];
  protected onColumnsChange(fields: readonly ExportField[]): void;
  protected onColumnsReset(): void;
  private keepColumns;
  /** Passed to the view selector, so the storage key has exactly one definition. */
  protected readonly savedFilterScope: "contracts";
  /** Passed to the grid, which stays ignorant of what an unapproved contract is. */
  protected readonly rowTone: typeof contractRowTone;
  /**
   * The location list, used only to name the active trade unit in the heading.
   *
   * The *picker* is the shell's. This screen still needs the list because the shell hands it a code
   * and a code alone does not identify a location to a reader — "0210" means nothing without
   * "Omaha Terminal" beside it.
   */
  private readonly locationData;
  protected readonly locations: import("@angular/core").Signal<readonly import("@cws/domain-contracts").CtrmLocation[]>;
  /**
   * The workspace state as it arrived in the URL.
   *
   * Read from the **snapshot**, once, rather than reactively — and that is what makes the two-way sync
   * safe. This component writes the URL as its filters change; reading the same parameters reactively
   * would feed that write straight back in as an input, and the loop would either fight the user's
   * typing or spin. A routed component is destroyed and rebuilt when the route changes, so the snapshot
   * is read exactly when there is new state to read.
   */
  private readonly initialState;
  private readonly savedFilters;
  /**
   * The filter and sort to open on — the URL's, or the user's default view when the URL says nothing.
   *
   * 🔴 **A link always wins.** The default is applied only on a *bare* arrival, because a URL
   * carrying state is a deliberate view someone chose or was sent, and overriding it would mean a
   * pasted link showed one thing for the sender and another for the recipient. That is the whole
   * point of the workspace being linkable.
   *
   * ⚠ **Resolved ONCE, in a field initialiser, not in an effect.** The effect in the constructor
   * writes this screen's state to the URL; applying the default from an effect would race that write
   * and could re-apply on every navigation. Field order matters here: this sits above the `filter`
   * and `sorts` signals because it is their initial value.
   *
   * ⚠ Consequence worth knowing: clearing a default view lasts for the session, not for ever. The
   * next bare arrival applies it again — which is what "default" means, and what someone who set one
   * is asking for.
   */
  private readonly initialView;
  private resolveInitialView;
  /** Filters owned by this screen. The trade unit is not among them — the shell owns that. */
  private readonly filters;
  /**
   * The row to select and focus on arrival, or `null`.
   *
   * Set only by a return trip from the contract detail screen. The grid honours it once, so it restores
   * where the user was and then stays out of the way — which is what lets `ArrowDown` move to the *next*
   * record immediately (JFrisbie, 2026-08-27).
   */
  protected readonly focusKey: import("@angular/core").WritableSignal<string | null>;
  /**
   * Identity for the grid's row tracking, and the key {@link focusKey} is matched against.
   *
   * **Must be the contract number, not the row object.** Coming back from the detail screen re-fetches,
   * so the object for a given contract is a different one than the row the user left — object identity
   * would never match and the focus would silently not restore.
   */
  protected readonly trackByContract: (row: ContractSummary) => string;
  /**
   * Declared after the signals it reads, deliberately.
   *
   * Angular effects are lazy, so registering this in a constructor above `filters` would work — the body
   * does not run until after the fields are initialised. It is placed here anyway because "works because
   * of initialisation timing" is not a property a reader should have to reconstruct.
   */
  constructor();
  /**
   * The active sort chain, in priority order. Empty means the server's own newest-first ordering.
   *
   * Multi-column since 2026-08-26: each header click appends a column or advances the one it names,
   * so activation order is priority.
   *
   * Declared above {@link query} because it is one of that computed's inputs. It reads as a view
   * concern and is not one — the chain goes to the server.
   */
  protected readonly sorts: import("@angular/core").WritableSignal<readonly GridSort<string>[]>;
  /**
   * The request, assembled from this screen's filters, the shell's trade unit and the active sort.
   *
   * The sort is *part of the query* rather than a purely local view concern, which is the change that
   * makes "sort all records" possible at all: a header click now re-issues the request instead of
   * rearranging the rows already in the browser.
   */
  /**
   * The dynamic filter — any column, combined with All or Any.
   *
   * 🔴 **Replaces the four-filter panel, and the four were a server capability leaking into the UI.**
   * `ContractListQuery` accepts commodity, customer id, trader initials and market zone, so those
   * were the four offered — while the grid showed 24 columns and the panel's own footer explained
   * that filtering the rest "needs CR-4". It never did: `ContractListProjector` fetches the whole
   * status set from CTRM and filters **in process**, so a filter parameter reduces the JSON sent to
   * the browser and not the CTRM read. Evaluating the same rules here costs CTRM nothing extra.
   *
   * Restored from the URL so a filter is linkable, survives a reload, and comes back with the
   * breadcrumb.
   */
  protected readonly filter: import("@angular/core").WritableSignal<FilterGroup>;
  /**
   * What actually goes to the server.
   *
   * 🔴 **Two things are pushed down and the rest are not**, which is the only way to keep this both
   * correct and cheap:
   *
   * • `status` and `tradeUnit` must go — they select the CTRM procedure and its scope, and the call
   *   is refused without one.
   * • An `equals` rule on one of the four fields the server declares is pushed down **only when the
   *   combinator is All**, and only from the TOP LEVEL. Under Any, narrowing at the source would
   *   remove rows a different rule
   *   would have matched — the server ANDs, so pushing one arm of an OR is simply wrong.
   *
   * Everything else is evaluated here. ⚠ **Pushed-down rules are re-evaluated locally too**, which
   * is deliberate: it makes {@link matched} the single definition of what the filter means, so the
   * screen cannot disagree with the server about its own filter.
   *
   * **A rule inside a nested group is never pushed down, and that is correctness rather than a
   * simplification.** A new group always takes the OPPOSITE combinator to its parent, so a rule
   * nested under an All group is by construction an arm of an Any -- the exact case the bullet
   * above refuses at the top level. Pushing it would narrow the CTRM read and drop rows the Any
   * should have matched, with nothing on screen saying so.
   *
   * The loop skips group nodes EXPLICITLY. It used to skip them by accident -- a group carries no
   * `columnKey`, so the lookup missed -- which is the right answer for no reason, and one
   * refactor away from silently losing rows.
   */
  private readonly pushdown;
  /**
   * True when a rule or the search term has to be applied here rather than by the server.
   *
   * Drives the page size, which is the one place this costs something — see {@link query}.
   */
  protected readonly filtersLocally: import("@angular/core").Signal<boolean>;
  /**
   * Whether the server export reproduces this screen's filter (#439, ruled 2026-10-02).
   *
   * True with no search and every live rule a top-level `equals` under All on a column in
   * {@link EXPORT_PUSHDOWN_COLUMNS}. Those rules already reach the server through {@link pushdown},
   * and the server's match is never wider than this screen's, so its file equals the screen.
   */
  private readonly serverReproducesFilter;
  protected readonly query: import("@angular/core").Signal<ContractListQuery>;
  /** Bumped by Retry so a retry genuinely re-issues the request. */
  private readonly attempt;
  /** True until a trade unit is chosen — the state that blocks the request entirely. */
  protected readonly needsScope: import("@angular/core").Signal<boolean>;
  private readonly data;
  /**
   * Page 1, then every remaining page in order, answered as ONE page holding every row (#785).
   *
   * Sequential rather than parallel for the reason {@link exportAllRows} gives: the first read can
   * miss the BFF cache, and several concurrent misses is the load pattern spike 1 warned about. Only
   * the first read carries `refresh`; the rest are served from what it just re-read.
   *
   * 🔴 **A failed page stops the read and keeps what arrived**, rather than failing the screen or
   * presenting a short list as complete. The answer then holds fewer rows than `totalCount`, so
   * {@link filterIsPartial} is true and the screen says the result is partial, including when it is
   * empty ({@link emptyMessage}).
   */
  private listEveryPage;
  /**
   * What the async container renders.
   *
   * While no trade unit is chosen the state is forced to `loaded` with an empty page, so the
   * container shows the empty state and its primary action rather than a spinner that will never
   * resolve — an indefinite skeleton is how "you must choose something" gets mistaken for a hang.
   */
  protected readonly state: import("@angular/core").Signal<RemoteData<ContractListPage>>;
  protected readonly page: import("@angular/core").Signal<ContractListPage | null>;
  /**
   * A read is in flight — spins the toolbar's refresh icon and refuses a second press.
   *
   * Read off the request state rather than tracked as its own flag, so it cannot disagree with what
   * the grid is doing. Note it is true for the *first* load too, not only for a refresh: the button
   * is disabled while the initial page arrives, which is correct, and a flag set only by `refresh()`
   * would leave it pressable during the load that is already running.
   */
  protected readonly isRefreshing: import("@angular/core").Signal<boolean>;
  /**
   * Whether the server ordered the **whole** result set the way this screen asked.
   *
   * Read from the response rather than assumed from the request, because an unknown query parameter is
   * ignored in silence: the pre-change API returns page 1 of its own newest-first order and looks, from
   * here, exactly like a server that sorted 880 rows. `appliedSort` is the echo that separates the two.
   */
  protected readonly serverSorted: import("@angular/core").Signal<boolean>;
  /** The page's rows in the order the grid should show them. */
  /**
   * Every fetched row that satisfies the filter and the search, sorted.
   *
   * Search runs across **every column the grid renders** rather than the three the server matched —
   * which is what makes the box useful on payment terms, origin, zone and the rest.
   */
  protected readonly matched: import("@angular/core").Signal<readonly ContractSummary[]>;
  /**
   * The rows on screen.
   *
   * 🔴 **Two paging modes, and the boolean that chooses between them is the honest part.** Unfiltered,
   * the server pages and this returns what it sent — unchanged behaviour. Filtering locally, the
   * server's `totalPages` describes the *unfiltered* set and would be a lie about the result, so the
   * matched set is paged here instead. Reporting the server's page count over a locally filtered
   * result is precisely the complete-looking-but-incomplete answer this project keeps recording.
   */
  protected readonly rows: import("@angular/core").Signal<readonly ContractSummary[]>;
  /** The page within a locally filtered result. Separate from the server's, which means nothing there. */
  private readonly localPageSignal;
  private readonly localPage;
  private readonly localTotalPages;
  /** How many rows arrived, so the footer can say what was searched to find the matches. */
  protected readonly fetchedCount: import("@angular/core").Signal<number>;
  /**
   * True when the server held rows it did not send while a local filter was running.
   *
   * ⚠ This is what turns "12 matches" from a claim about the trade unit into a claim about what was
   * read. Without it a filter over a 880-contract location would present the matches from 200 rows
   * as the whole answer.
   */
  protected readonly filterIsPartial: import("@angular/core").Signal<boolean>;
  /**
   * Applies the active sort chain to whatever rows it is given.
   *
   * Extracted so the **export uses the identical ordering as the screen**. Before this, "All pages"
   * concatenated the server's rows and ignored the sort entirely, so a user who sorted by price
   * descending and exported got a newest-first spreadsheet — the export silently disagreed with what
   * they were looking at, which is the kind of difference that only surfaces when two people compare
   * files.
   *
   * Delegates to `compareBySorts` so each column's own `sortValue` is honoured — sorting on the
   * *displayed* text put 10/5/26 before 9/12/25 and 10.0000 before 6.4275.
   *
   * **Applied unconditionally, including when the server has already sorted, and that is deliberate.**
   * Re-sorting an already-sorted page by the same chain is a no-op, because `Array.prototype.sort` is
   * stable in modern engines and rows the chain cannot distinguish keep the order the server sent. So
   * one code path covers both servers: today it *is* the sort, and afterwards it is a cheap idempotent
   * pass over at most `pageSize` rows. Branching on {@link serverSorted} here would buy nothing and
   * would give the two states different orderings to disagree about.
   */
  private sortRows;
  protected readonly isEmpty: import("@angular/core").Signal<boolean>;
  /** The chosen location, or null. */
  private readonly activeLocation;
  /**
   * The page heading — names the active scope rather than repeating the shell's title.
   *
   * Both the code and the name, because neither alone identifies a trade unit to a reader: the code
   * is what CTRM uses and what appears on a contract, the name is what a trader recognises.
   */
  protected readonly scopeLabel: import("@angular/core").Signal<string>;
  protected readonly scopeDescription: import("@angular/core").Signal<string>;
  /**
   * 🔴 **"No contracts match" is said only when every contract was read** (#785). When a page could
   * not be read, an empty result is a claim about part of the trade unit, so it says how much was
   * read and that a match may exist. The caution beside a non-empty result is in the template.
   */
  protected readonly emptyMessage: import("@angular/core").Signal<string>;
  /**
   * Shown when the rows did not come from CTRM.
   *
   * Gated on a request having actually happened: the placeholder page used before a trade unit is
   * chosen has to name *some* origin to satisfy the type, and letting that drive the banner would
   * announce "simulated data" on a screen showing no data at all.
   */
  protected readonly isSimulated: import("@angular/core").Signal<boolean>;
  /**
   * One line per standing notice, and — because the panel counts these — the number it reports.
   *
   * 🔴 **This list and the panel's projected content must stay in step.** The count comes from here
   * while the detail is projected markup, so a notice added to the template and not to this list is
   * one the header does not count and a collapsed reader never learns about.
   *
   * ⚠ Empty is the usual case on this screen, and the panel renders nothing at all when it is —
   * a permanent "Notices (0)" would be furniture.
   */
  protected readonly noticeSummaries: import("@angular/core").Signal<string[]>;
  /**
   * The row-cap sentence when CTRM returned its maximum (#662), else `null`.
   *
   * 🔴 Only an explicit `true` shows anything. `null` (a server that does not say) and `false` both
   * show nothing, and the grid never claims to be complete. Gated on a request having happened, like
   * {@link isSimulated}.
   */
  protected readonly rowCapMessage: import("@angular/core").Signal<string | null>;
  /**
   * The customer directory is being refused by the field policy (#328, #240).
   *
   * 🔴 **`=== 'Redacted'`, and every part of that is deliberate.**
   *
   * `Unavailable` is **excluded**: it is a transport blip or a timeout, it clears on its own, and the
   * designed behaviour is to fall back to ids without saying anything. A notice that fires on a blip
   * is one people learn to ignore, and this is the panel that also carries the simulated-data
   * warning — so it would erode that too (#328 criterion 5).
   *
   * `undefined` is **excluded**: it means the server sent no verdict, which is silence rather than an
   * answer. Treating it as a problem would light this up against every older API.
   *
   * ⚠ **And the condition is the verdict, never a null name.** A null `customerName` is the normal
   * case on `open`/`closed` — `OpenDS` carries no name member at all — so keying on it would make the
   * notice permanent on the workspace and mean nothing.
   */
  protected readonly customerNamesRedacted: import("@angular/core").Signal<boolean>;
  /**
   * The portfolio cards above the filter bar.
   *
   * 🔴 **The denominator is the one the footer reports**, passed in rather than re-derived, so the
   * "Open contracts" card and the "1–50 of 880" beneath the grid cannot disagree. Two independent
   * answers to "how many contracts" on one screen is worse than either.
   *
   * ⚠ `new Date()` is read here rather than inside the derivation, which takes it as an argument —
   * so the metrics are a pure function with deterministic tests and only this line knows what day
   * it is. Same arrangement as the approval queue.
   */
  protected readonly metrics: import("@angular/core").Signal<readonly PortfolioMetric[]>;
  /**
   * What the View selector calls the unfiltered view: the status the URL chose, never a fixed
   * "Open" (#841). The closed list is reachable by URL, and it read "All Open Contracts" on the walk.
   */
  protected readonly baselineLabel: import("@angular/core").Signal<string>;
  protected readonly rangeLabel: import("@angular/core").Signal<string>;
  /** The page number and count the pagers show — the server's, or the local one while filtering. */
  protected readonly displayPage: import("@angular/core").Signal<number>;
  protected readonly displayTotalPages: import("@angular/core").Signal<number>;
  protected readonly canPagePrevious: import("@angular/core").Signal<boolean>;
  protected readonly canPageNext: import("@angular/core").Signal<boolean>;
  /**
   * How many filters are narrowing the grid, for the filter button's badge.
   *
   * **Status is excluded deliberately.** It is always set — `contract/list` requires it — so counting
   * it would mean the button permanently reads "1" and the badge would stop meaning "you have
   * narrowed this". Trade unit is excluded for the same reason: it is a precondition, and it is
   * already displayed in the shell's own control.
   *
   * Search is excluded because it has its own visible box; a term you can see in the input does not
   * need a second indicator.
   */
  /**
   * The badge on the Filters button — how many rules are actually filtering.
   *
   * ⚠ Counts the **builder's** rules now, not the four query fields it replaced. Counting the query
   * would double-count a pushed-down rule (it appears in both) and miss every rule on the other
   * twenty columns, so the badge would understate a filter of six rules as two.
   */
  protected readonly activeFilterCount: import("@angular/core").Signal<number>;
  /** A one-line summary of the filter, for the button's tooltip. */
  protected readonly filterSummary: import("@angular/core").Signal<string>;
  /**
   * What the search box shows.
   *
   * Read from {@link filters} rather than from {@link query}, which blanks `search` on purpose so it
   * is not sent to a server that matches only three fields. Binding the box to the query would have
   * left it permanently empty — you could type, the grid would filter, and the text would disappear.
   */
  protected readonly searchTerm: import("@angular/core").Signal<string>;
  /**
   * Says so when a sort only reordered the page in front of you.
   *
   * **Shown only when the server did not sort**, which is what {@link serverSorted} decides from the
   * response rather than from hope. Once the API applies the chain across the result set the note is
   * both wrong and alarming, so it has to disappear on the same signal that makes it untrue.
   *
   * It is not decoration while it lasts: a trader who sorts by price descending to find the highest
   * price on an 18-page result would otherwise get the highest price *on page 1* and no reason to doubt
   * it.
   *
   * **The old wording blamed CR-4 (#31) and that was wrong.** CR-4 asks *CTRM* for filtering and
   * paging; sorting the whole set needs nothing from CTRM, because `ContractListProjector` already
   * fetches every row for the status and sorts them all before paging. It is a BFF parameter, filed as
   * **#99** — which is why this note no longer points at a CR that would not have delivered it.
   */
  protected readonly sortScopeNote: import("@angular/core").Signal<string | null>;
  /**
   * Applies a view chosen in the selector.
   *
   * 🔴 **`sort === null` means "leave the sort alone" and `[]` means "clear it".** Reading the empty
   * array as "nothing to restore" would make selecting an unsorted view silently inherit the
   * previous view's sort — which is the defect this distinction exists to prevent.
   *
   * ⚠ **Corrected 2026-09-14: only the baseline sends `null` now.** This note used to say a view
   * saved without its sorting must not disturb the current sort; selecting any saved view now clears
   * the sort unless that view carries one (JFrisbie), so a saved view sends `[]`. The branch below is
   * unchanged — it already did the right thing with an empty array.
   */
  protected onViewChange(view: AppliedView): void;
  protected search(term: string): void;
  /** One of the four server-supported narrowing filters. Blank clears it rather than sending `''`. */
  protected setFilter(key: 'customerId' | 'commodity' | 'traderInitials' | 'marketZone', value: string): void;
  /**
   * Clears the four narrowing filters, leaving status, trade unit and search alone.
   *
   * Status stays because clearing a required parameter is not a state the request can be in, and the
   * search box stays because it is visible — silently emptying a control the user can see is worse
   * than leaving it.
   */
  protected clearFilters(): void;
  /**
   * Jumps to an absolute page, clamped to the result.
   *
   * Clamped here rather than trusted from the caller: the pager disables its own buttons at the ends,
   * but the grid's PgUp/PgDn and a future deep link both reach this too, and a page beyond the last
   * would render an empty grid that reads as "no matches".
   */
  protected goToPage(page: number): void;
  protected stepPage(step: -1 | 1): void;
  /**
   * Applies a filter from the builder.
   *
   * Resets the local page: page 3 of a narrower result is an empty grid that reads as "no matches"
   * when the matches are on page 1.
   */
  protected onFilterChange(group: FilterGroup): void;
  /**
   * Set when an export could not complete, so the failure is on screen rather than silent.
   *
   * ⚠ Rendered **below the toolbar** rather than inside the export panel. An all-pages export
   * fails after the panel has closed, so a message inside it would be a message nobody sees.
   */
  protected readonly exportError: import("@angular/core").WritableSignal<string | null>;
  /**
   * What the last export did — which path wrote the file, how many rows, and why the in-screen
   * export ran if the server stood aside (F4.3c).
   *
   * 🔴 **Always shown, never only on fallback.** Two files that look alike and were built differently
   * is the class of difference that surfaces only when two people compare spreadsheets; a note that
   * appeared only when something went sideways would leave the ordinary case unexplained.
   */
  protected readonly exportOutcome: import("@angular/core").WritableSignal<ExportOutcome | null>;
  /**
   * What the last server export's headers said about CTRM's row cap (#662). Read only beside a
   * `server` outcome, and set by every server export, so it never describes an older file.
   */
  private readonly serverExportRowCap;
  /**
   * The sentence after "Exported N rows by the server." (#662).
   *
   * 🔴 **"Complete" only on an explicit `false`.** `true` gives the row-cap sentence. `null` (an
   * absent header) gives nothing at all, because an unknown is not a claim either way.
   */
  protected readonly serverExportCompleteness: import("@angular/core").Signal<string | null>;
  protected onExportFailed(message: string | null): void;
  protected onExportCompleted(outcome: ExportOutcome): void;
  /**
   * Names an export file — `contracts-0210-open-page-1.csv`.
   *
   * Names the scope rather than just the date: a downloads folder holding four exports of
   * different trade units is the normal case, and `contracts.csv (3)` says nothing about which is
   * which. No timestamp — the filesystem already has one, and a name that changes every second
   * stops the browser offering to replace the previous export.
   *
   * ⚠ **An arrow property rather than a method**, because it is passed to `cms-grid-export` as an
   * input: a plain method would arrive unbound and `this.query()` would throw on the first export.
   */
  protected readonly exportFilename: (scope: "page" | "all") => string;
  /**
   * Every row behind the current filter, or `null` when they could not all be fetched.
   *
   * **This costs one request per 200 rows.** `MAX_PAGE_SIZE` is 200 and `contract/list` has no
   * server-side filtering or paging (CR-4, #31), so an 880-row trade unit is five requests.
   * docs/02 §2.3 specifies a *streamed server export* instead, which becomes the obviously right
   * implementation the moment CR-4 lands.
   *
   * ⚠ **The CTRM cost is not five full reads.** PR #80 added a BFF list cache keyed on the CTRM
   * *scope* — status, customer, trade unit — and deliberately **not** on paging or sort, so pages
   * 2…N are re-projections of one cached row set rather than five 780 KB round trips. Still
   * sequential rather than parallel: the *first* request can miss, and five concurrent misses is
   * exactly the load pattern spike 1 warned about.
   *
   * 🔴 **Returns `null` rather than a short list when a page fails.** Partial data exported as
   * though it were complete is worse than no export: a trader reconciling against a short
   * spreadsheet has no way to know rows are missing. The shared control writes nothing on `null`.
   *
   * 🔴 **The filter, the search AND the sort are re-applied here**, and leaving any of them out
   * would be a real defect rather than an omission. This fetches every page and then formats what
   * it got, so without them an all-pages export of a filtered grid would hand back every row in
   * the trade unit — the rows the user had just excluded — and the spreadsheet would silently
   * disagree with the screen. That is the bug already fixed once here for *sorting*, where the
   * export ignored the sort and a trader who ordered by price descending got a newest-first file.
   *
   * ✅ And it makes the export BETTER than the view: the screen filters one page, while this has
   * fetched them all — so a filtered export is complete even when the grid says its own result may
   * not be.
   *
   * ⚠ **Filtered against ALL columns, written with only the selected ones.** The two must not be
   * the same list: a user who filters on Commodity and then excludes Commodity from the export
   * still wants the rows that filter matched. Narrowing the match to the export selection would
   * silently *widen* the result set, which is the inverse of the sort defect and just as invisible.
   * The column selection is applied by the shared control, deliberately after this returns.
   */
  protected readonly exportAllRows: () => Promise<readonly ContractSummary[] | null>;
  /**
   * The server export for "All pages" (F4.3c — docs/02 §2.3, §8): `GET /contracts/export` with
   * **the grid's own query and sort** and the picked fields, streamed and saved as served.
   *
   * 🔴 **The export must equal the screen, and that decides when this stands aside.** This screen
   * deliberately does not send `search` (see {@link query}) and applies every filter rule the server
   * cannot take here, so while either is active the server cannot reproduce what is on screen. Then
   * {@link exportAllRows} runs instead — it fetches every page and applies the same rules — and the
   * note says why. The same when the server is unavailable: the route has not landed, the network,
   * the server. A refusal is different and stands alone: nothing is built here in its place.
   *
   * ⚠ An arrow property for the same reason {@link exportFilename} is: it is passed as an input.
   */
  protected readonly serverExport: ServerExport | null;
  /**
   * An empty chain is the state after the last sorted column was cycled out.
   *
   * `rows()` then returns the page untouched, which is the server's newest-first order from
   * `ContractListProjector`. That is what makes clearing the sort meaningful here rather than a state
   * with no ordering at all.
   *
   * **Returns to page 1**, for the same reason a filter change does: once the sort orders the whole
   * result set, page 4 of "price descending" is an arbitrary slice of the middle, and the reason to
   * sort by price at all is to see the extreme. Staying put would answer a question nobody asked.
   *
   * The page reset goes through `filters` rather than `patch`, because the sort chain lives in its own
   * signal — `query` composes the two.
   */
  protected onSortChange(sorts: readonly GridSort[]): void;
  /**
   * Opens the contract detail screen.
   *
   * **One handler for both gestures.** The grid emits `rowActivate` for a double-click *and* for Enter
   * on the selected row, so double-click and Enter cannot drift apart into two code paths that behave
   * differently (JFrisbie, 2026-08-27).
   *
   * ✅ **Through the host contract since E9 PR 4 (F9.10).** This used to call the root `Router` at
   * `/contracts/{n}`, which embedded drives the *host's* router at a path the host may not publish
   * (docs/02 §1a). It now asks `CMS_HOST_CONTEXT`, as the Add contract anchor does; the two were
   * solved together, as the anchor's old note predicted.
   */
  protected onRowActivate(row: ContractSummary): void;
  /**
   * This grid's exact state, packed for the record screen's breadcrumb.
   *
   * 🔴 Extracted so the three ways into the record — activate, Edit, and the record's own
   * Cancel — cannot disagree about what "back" means. They were one call site when this was
   * inline; they are three now, and three copies of a query-string builder is how a breadcrumb
   * quietly starts returning people to page 1.
   */
  private returnTo;
  /**
   * Edit this contract.
   *
   * ⚠ Carries the same packed `returnTo` as {@link onRowActivate}, so Cancel on the record comes
   * back to this exact grid state rather than to an unfiltered first page. Without it the two
   * ways into the record would behave differently, which is the kind of difference nobody
   * reports and everybody notices.
   */
  protected openEdit(row: ContractSummary): void;
  /**
   * Start a new contract seeded from this one — BR-041, and the same route the record screen
   * offers, so there is one copy implementation rather than two.
   *
   * ⚠ **No `returnTo`.** A copy is a create, and abandoning a create should land the user on the
   * workspace rather than back on somebody else's contract as though they had been editing it.
   * The record screen's own copy item reasons the same way; keep them in step.
   */
  protected openCopy(row: ContractSummary): void;
  /**
   * Price this contract — docs/02 §2.2, opening the pricing screen for it.
   *
   * 🔴 **`from` matters more here than `returnTo` does, and it is the half that is invisible when
   * omitted.** Both per-contract screens default their breadcrumb to their *own* queue —
   * `recordOrigin(…, 'pricing')` — because until now the queue was the only way in. Arriving from
   * the workspace without saying so leaves the user looking at a crumb back to the Pricing queue,
   * a screen they never visited, with their grid state gone. Nothing looks broken, which is the
   * failure `record-origin.ts` was written for; this is the second journey it warned would come.
   *
   * ⚠ `returnTo` then carries *which* workspace to go back to, and it is the same packed value the
   * record screen gets, from the same builder — so all four ways out of this grid cannot disagree
   * about what "back" means.
   */
  protected openPricing(row: ContractSummary): void;
  /**
   * Review this contract for approval — docs/02 §2.2.
   *
   * ⚠ **Same two parameters as {@link openPricing} and for the same reasons.** §2.2 gates this on
   * *"ContractApproval **+ contract awaiting approval**"*, and only the first half is enforced here:
   * `ContractSummary.traderApprovalStatus` exists and is on the wire, but nothing records whether it
   * is populated on the `open` status this grid defaults to — its sibling `traderInitials` is
   * documented as null on `open` and `closed` for the same underlying reason. Gating on a field that
   * may be uniformly null would hide Approve from every row of the default view, so the condition is
   * **raised rather than guessed**, exactly as §2.2's Closed and intercompany conditions are.
   */
  protected openApproval(row: ContractSummary): void;
  /** Power BI (docs/02 §8, #756): `null` renders no link at all. Checked at provide time. */
  protected readonly powerBiUrl: string | null;
  /** The Add contract anchor's intent, href, and click (the record screen's `follow` shape). */
  private readonly newContractIntent;
  protected readonly newContractHref: import("@angular/core").Signal<string>;
  /**
   * A plain left click is handed to the host. A modified or middle click is left to the browser,
   * which opens the host's href in a new tab: that is why Add contract stays a real anchor.
   */
  protected followNewContract(event: MouseEvent): void;
  protected retry(): void;
  /**
   * Re-read the current result — the toolbar's refresh.
   *
   * The same mechanism as {@link retry}, deliberately, and the reason both exist is that they are
   * different *affordances* rather than different behaviour: Retry appears inside a failed state and
   * Refresh sits in the toolbar of a working one. Sharing {@link reissue} is what stops one of them
   * later growing a query reset the other does not have.
   *
   * 🔑 **Filters, sort and page survive because nothing here touches them.** `query()` is untouched,
   * so the re-issued request is byte-identical to the last one. A refresh that rebuilt the query — or
   * called `patch()`, which resets to page 1 — would silently drop the user back to the top of an
   * unsorted first page, which is what people mean when they say a refresh "lost my place".
   */
  protected refresh(): void;
  /**
   * Bump the attempt counter, which is the only input to the request pipeline besides the query.
   *
   * 🔴 **It is also what asks the server to bypass its 60-second cache** (#294) — see {@link data}
   * for why the bypass is derived from this number moving rather than from a flag of its own. Both
   * callers are deliberate user actions on a screen that is already showing them something, which is
   * the only traffic that should ever bypass; everything else reaches the pipeline by changing the
   * query instead, and changing the query does not touch this.
   */
  private reissue;
  /** Any filter change resets to page 1 — staying on page 4 of a narrower result set shows nothing. */
  private patch;
  static ɵfac: i0.ɵɵFactoryDeclaration<HomePageComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HomePageComponent, "cms-home-page", never, {}, {}, never, never, true, never>;
}
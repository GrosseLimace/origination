import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, computed, effect, inject, linkedSignal, signal, viewChild } from "@angular/core";
import { toObservable, toSignal } from "@angular/core/rxjs-interop";
import { AsyncContainerComponent, ClearSortButtonComponent, DataGridComponent, FilterBuilderComponent, FilterSelectComponent, GridColumnMenuComponent, GridExportComponent, GridToolbarComponent, NoticesPanelComponent, PageHeaderComponent, PagerComponent, RefreshButtonComponent, SAVED_FILTER_SCOPES, SAVED_FILTER_STORE, SearchShortcutDirective, StatusMessageComponent, activeRuleCount, compareBySorts, describeGroup, downloadBlob, injectConfirm, isLive, isRuleNode, matchesGroup, matchesSearch, observeLayoutBand, priorityColumnKeys, remoteLoading, savedViewColumnsOf } from "@cws/shared-ui";
import { ActivatedRoute, Router } from "@angular/router";
import { CMS_HOST_CONTEXT } from "@cws/core-host-context";
import { PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { distinctUntilChanged, filter, firstValueFrom, map, of, scan, switchMap, take } from "rxjs";
import { CONTRACT_EXPORT_OFFERED_COLUMNS, CONTRACT_EXPORT_SOURCE, CONTRACT_GRID_COLUMNS, CONTRACT_LIST_SOURCE, CUSTOMER_NAME_EXPORT_COLUMN, CWS_EXTERNAL_LINKS, DEFAULT_PAGE_SIZE, GRID_COLUMN_PREFERENCE_SOURCE, HOME_GRID_COLUMNS_SOURCE, LOCATION_SOURCE, MAX_PAGE_SIZE, PINNED_GRID_COLUMN, PRICING_SOURCE, RECORD_ORIGIN_PARAM, RecordJourneyStore, SERVER_EXPORT_FIELD_KEYS, SaveAnnouncementStore, approvalStatusTone, approveRefusalFor, contractRowTone, editRefusalFor, formatQuantity, fromRouteParams, gridColumnChoices, gridColumnLayout, hasScope, isDefaultGridColumns, isServerSorted, listCompletenessNotice, listEveryPage, localDay, recordJourneyState, rowCapNotice, savedLayoutColumnKeys, startRecordJourney, summarizeContracts, toRouteParams, toSortParam, userGridColumnKeys, visibleGridColumnKeys } from "@cws/domain-contracts";
function cardBasis(page, read) {
	if (rowCapNotice(page.rowCapReached, page.rowCap) !== null) return `CTRM's ${page.rowCap === null ? "row maximum" : `${formatQuantity(page.rowCap)}-row maximum`}: may not be every contract`;
	if (page.listComplete === false) {
		const matched = page.ctrmMatchedCount;
		return matched === null || matched === void 0 ? "CTRM did not return every contract it matched." : `Only ${formatQuantity(page.totalCount)} of the ${formatQuantity(matched)} contracts CTRM matched were read.`;
	}
	if (read < page.totalCount) return `Only ${formatQuantity(read)} of ${formatQuantity(page.totalCount)} contracts loaded; refresh to read the rest.`;
	return null;
}
function quantityCard(totals, pick, unknownHint, wholeHint, basis) {
	if (totals.length > 1) return {
		value: "—",
		hint: basis ?? "Mixed units — no single total"
	};
	if (totals.length === 0) return {
		value: "0",
		hint: basis ?? wholeHint
	};
	const [only] = totals;
	const value = pick(only);
	if (value === null) return {
		value: "—",
		hint: basis ?? unknownHint
	};
	return {
		value: `${formatQuantity(value)}${only.uom === "" ? "" : ` ${only.uom}`}`,
		hint: basis ?? wholeHint
	};
}
function contractPortfolioMetrics(summary, scope, status = "Open") {
	const { basis } = scope;
	const across = `Across all ${formatQuantity(scope.total)}`;
	const quantity = quantityCard(summary.quantityByUom, (total) => total.quantity, "Unknown: a contract has no quantity", across, basis);
	const open = quantityCard(summary.quantityByUom, (total) => total.openQuantity, "Unknown: a contract has no open quantity", across, basis);
	const periods = summary.shipPeriods;
	const shippingSoon = periods === null ? null : periods.ended + periods.open + periods.beginningSoon;
	const attention = summary.traderApprovalStatusCounts.filter((count) => approvalStatusTone(count.status) !== null).reduce((sum, count) => sum + count.count, 0);
	const [count, contractQuantity, openQuantity, shipping, needsAttention] = portfolioLabels(status);
	return [
		{
			label: count,
			value: formatQuantity(scope.total),
			hint: basis ?? (scope.filtered ? "Matching the search and filters" : "In this trade unit")
		},
		{
			label: contractQuantity,
			...quantity
		},
		{
			label: openQuantity,
			...open
		},
		{
			label: shipping,
			value: shippingSoon === null ? "—" : formatQuantity(shippingSoon),
			hint: basis ?? "Ship period opens soon or has opened",
			urgent: (shippingSoon ?? 0) > 0
		},
		{
			label: needsAttention,
			value: formatQuantity(attention),
			hint: basis ?? "Rejected, unapproved or pending",
			urgent: attention > 0
		}
	];
}
function portfolioLabels(status = "Open") {
	return [
		`${status} contracts`,
		"Contract quantity",
		"Open quantity",
		`Shipping within 30 days`,
		"Needs attention"
	];
}
const PUSHDOWN_FIELDS = {
	commodity: "commodity",
	traderInitials: "traderInitials",
	marketZone: "marketZone"
};
const EXPORT_PUSHDOWN_COLUMNS = /* @__PURE__ */ new Set(["commodity", "marketZone"]);
const SAVED_FILTER_SCOPE = SAVED_FILTER_SCOPES.contracts;
const COPY_WITH_PRICING_CONFIRM = "Creating the copy spends a new contract number, whatever then happens to the prices. Each price sequence is then posted unapproved and read back; any not copied are listed for you to retry.";
const COPY_WITH_PRICING_UNAVAILABLE = "Not available here — this application has no pricing connection";
var HomePageComponent = class HomePageComponent {
	source = inject(CONTRACT_LIST_SOURCE);
	arrivedAfterSave = signal(inject(SaveAnnouncementStore).takeForOrigin("contracts"), ...ngDevMode ? [{ debugName: "arrivedAfterSave" }] : /* istanbul ignore next */ []);
	exportSource = inject(CONTRACT_EXPORT_SOURCE, { optional: true });
	locationSource = inject(LOCATION_SOURCE);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	permissions = inject(PERMISSION_CONTEXT);
	rowActions = computed(() => {
		const actions = [];
		if (this.permissions.canWriteContracts()) actions.push({
			label: "Edit",
			tone: "outline",
			accessKey: "e",
			hidden: (row) => editRefusalFor(row) !== false,
			run: (row) => this.openEdit(row)
		}, {
			label: "Copy contract",
			tone: "secondary",
			accessKey: "c",
			run: (row) => this.openCopy(row)
		}, {
			label: "Copy contract w/ pricing",
			tone: "secondary",
			disabled: () => this.pricingCopyOffered ? false : COPY_WITH_PRICING_UNAVAILABLE,
			run: (row) => this.openCopyWithPricing(row)
		});
		if (this.permissions.canEditPricing()) actions.push({
			label: "Prices",
			tone: "secondary",
			accessKey: "p",
			run: (row) => this.openPricing(row)
		});
		if (this.permissions.canApproveContracts()) actions.push({
			label: "Approve",
			tone: "secondary",
			accessKey: "a",
			hidden: (row) => approveRefusalFor(row) !== false,
			run: (row) => this.openApproval(row)
		});
		return this.layoutBand() === "read-mostly" ? actions.filter((action) => action.label === "Approve") : actions;
	}, ...ngDevMode ? [{ debugName: "rowActions" }] : /* istanbul ignore next */ []);
	layoutRoot = viewChild("layoutRoot", ...ngDevMode ? [{ debugName: "layoutRoot" }] : /* istanbul ignore next */ []);
	layoutBand = observeLayoutBand(this.layoutRoot);
	hostContext = inject(CMS_HOST_CONTEXT);
	router = inject(Router);
	route = inject(ActivatedRoute);
	columns = CONTRACT_GRID_COLUMNS;
	exportColumns = CONTRACT_EXPORT_OFFERED_COLUMNS;
	tradeUnitColumnsSource = inject(HOME_GRID_COLUMNS_SOURCE, { optional: true });
	columnPreference = inject(GRID_COLUMN_PREFERENCE_SOURCE, { optional: true });
	allColumnKeys = CONTRACT_GRID_COLUMNS.map((column) => column.key);
	activeTradeUnit = computed(() => this.tradeUnit.code(), ...ngDevMode ? [{ debugName: "activeTradeUnit" }] : /* istanbul ignore next */ []);
	tradeUnitColumns = toSignal(toObservable(this.activeTradeUnit).pipe(switchMap((tradeUnit) => this.tradeUnitColumnsSource === null || tradeUnit === null ? of(null) : this.tradeUnitColumnsSource.forTradeUnit(tradeUnit))), { initialValue: null });
	storedUserColumns = toSignal(toObservable(this.activeTradeUnit).pipe(switchMap((tradeUnit) => this.columnPreference === null || tradeUnit === null ? of(null) : this.columnPreference.get(tradeUnit).pipe(map((answer) => answer.status === "available" ? answer.columns : null)))), { initialValue: null });
	userColumns = linkedSignal(() => this.storedUserColumns(), ...ngDevMode ? [{ debugName: "userColumns" }] : /* istanbul ignore next */ []);
	sessionColumns = signal(null, ...ngDevMode ? [{ debugName: "sessionColumns" }] : /* istanbul ignore next */ []);
	effectiveUserColumns = computed(() => {
		const session = this.sessionColumns();
		return session === null ? this.userColumns() : savedLayoutColumnKeys(this.allColumnKeys, this.tradeUnitColumns(), session);
	}, ...ngDevMode ? [{ debugName: "effectiveUserColumns" }] : /* istanbul ignore next */ []);
	columnsKeptIn = signal(null, ...ngDevMode ? [{ debugName: "columnsKeptIn" }] : /* istanbul ignore next */ []);
	columnsFailure = signal(null, ...ngDevMode ? [{ debugName: "columnsFailure" }] : /* istanbul ignore next */ []);
	condensedColumnKeys = computed(() => this.layoutBand() === "full" ? null : priorityColumnKeys(CONTRACT_GRID_COLUMNS), ...ngDevMode ? [{ debugName: "condensedColumnKeys" }] : /* istanbul ignore next */ []);
	visibleColumnKeys = computed(() => visibleGridColumnKeys(this.allColumnKeys, this.tradeUnitColumns(), this.effectiveUserColumns(), this.condensedColumnKeys()), ...ngDevMode ? [{ debugName: "visibleColumnKeys" }] : /* istanbul ignore next */ []);
	savedViewColumnLayout = computed(() => {
		const user = this.effectiveUserColumns();
		const tradeUnit = this.tradeUnitColumns();
		const condensed = this.condensedColumnKeys();
		return {
			current: gridColumnLayout(this.allColumnKeys, tradeUnit, user, condensed),
			isDefault: isDefaultGridColumns(this.allColumnKeys, tradeUnit, user, condensed)
		};
	}, ...ngDevMode ? [{ debugName: "savedViewColumnLayout" }] : /* istanbul ignore next */ []);
	exportVisibleKeys = computed(() => this.visibleColumnKeys().flatMap((key) => key === "customerId" ? [key, CUSTOMER_NAME_EXPORT_COLUMN.key] : [key]), ...ngDevMode ? [{ debugName: "exportVisibleKeys" }] : /* istanbul ignore next */ []);
	visibleColumns = computed(() => {
		const byKey = new Map(CONTRACT_GRID_COLUMNS.map((column) => [column.key, column]));
		return this.visibleColumnKeys().map((key) => byKey.get(key)).filter((column) => column !== void 0);
	}, ...ngDevMode ? [{ debugName: "visibleColumns" }] : /* istanbul ignore next */ []);
	columnMenuFields = computed(() => {
		const headers = new Map(CONTRACT_GRID_COLUMNS.map((column) => [column.key, column.header]));
		return gridColumnChoices(this.allColumnKeys, this.tradeUnitColumns(), this.effectiveUserColumns(), this.condensedColumnKeys()).map((choice) => ({
			key: choice.key,
			header: headers.get(choice.key) ?? choice.key,
			included: choice.shown
		}));
	}, ...ngDevMode ? [{ debugName: "columnMenuFields" }] : /* istanbul ignore next */ []);
	lockedColumnKeys = [PINNED_GRID_COLUMN];
	onColumnsChange(fields) {
		if (this.sessionColumns() !== null) {
			this.keepForSession(savedViewColumnsOf(fields));
			return;
		}
		this.keepColumns(userGridColumnKeys(fields.map((field) => ({
			key: field.key,
			shown: field.included
		}))));
	}
	onColumnsReset() {
		if (this.sessionColumns() !== null) {
			this.keepForSession({
				order: [],
				hidden: []
			});
			return;
		}
		this.keepColumns(null);
	}
	keepForSession(columns) {
		this.sessionColumns.set(columns);
		this.columnsKeptIn.set("session");
		this.columnsFailure.set(null);
	}
	keepColumns(columns) {
		this.userColumns.set(columns);
		const tradeUnit = this.activeTradeUnit();
		if (this.columnPreference === null || tradeUnit === null) {
			this.columnsKeptIn.set("failed");
			this.columnsFailure.set({
				correlationId: null,
				sent: false
			});
			return;
		}
		this.columnPreference.save(tradeUnit, columns).pipe(take(1)).subscribe((outcome) => {
			const failed = outcome === "failed" || typeof outcome === "object";
			this.columnsKeptIn.set(outcome === "saved" ? "account" : failed ? "failed" : "browser");
			this.columnsFailure.set(failed ? {
				correlationId: typeof outcome === "object" ? outcome.correlationId : null,
				sent: true
			} : null);
		});
	}
	savedFilterScope = SAVED_FILTER_SCOPE;
	rowTone = contractRowTone;
	locationData = toSignal(this.locationSource.list(), { initialValue: remoteLoading() });
	locations = computed(() => {
		const data = this.locationData();
		return data.status === "loaded" ? data.value.locations : [];
	}, ...ngDevMode ? [{ debugName: "locations" }] : /* istanbul ignore next */ []);
	initialState = fromRouteParams(inject(ActivatedRoute).snapshot.queryParamMap);
	savedFilters = inject(SAVED_FILTER_STORE);
	initialView = this.resolveInitialView();
	resolveInitialView() {
		const fromUrl = {
			filter: this.initialState.filter,
			sorts: this.initialState.sorts
		};
		if (!(Object.keys(toRouteParams(this.initialState.query, fromUrl.sorts, null, fromUrl.filter)).length === 0)) return fromUrl;
		const defaultId = this.savedFilters.defaultId(SAVED_FILTER_SCOPE);
		if (defaultId === null) return fromUrl;
		const saved = this.savedFilters.list(SAVED_FILTER_SCOPE).find((candidate) => candidate.id === defaultId);
		return saved === void 0 ? fromUrl : {
			filter: saved.group,
			sorts: saved.sort ?? fromUrl.sorts,
			columns: saved.columns
		};
	}
	filters = signal(this.initialState.query, ...ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []);
	focusKey = signal(this.initialState.focus, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	trackByContract = (row) => row.contractNumber;
	constructor() {
		this.sessionColumns.set(this.initialView.columns ?? null);
		effect(() => {
			this.router.navigate([], {
				relativeTo: this.route,
				queryParams: toRouteParams(this.filters(), this.sorts(), null, this.filter()),
				replaceUrl: true
			});
		});
	}
	sorts = signal(this.initialView.sorts, ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	filter = signal(this.initialView.filter, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	pushdown = computed(() => {
		const group = this.filter();
		if (group.combinator !== "and") return {};
		const pushed = {};
		for (const rule of group.rules) {
			if (!isRuleNode(rule)) continue;
			const field = PUSHDOWN_FIELDS[rule.columnKey];
			if (field !== void 0 && rule.operator === "equals" && rule.value.trim() !== "") pushed[field] = rule.value.trim();
		}
		return pushed;
	}, ...ngDevMode ? [{ debugName: "pushdown" }] : /* istanbul ignore next */ []);
	filtersLocally = computed(() => activeRuleCount(this.filter()) > 0 || (this.filters().search ?? "").trim() !== "", ...ngDevMode ? [{ debugName: "filtersLocally" }] : /* istanbul ignore next */ []);
	serverReproducesFilter = computed(() => {
		if ((this.filters().search ?? "").trim() !== "") return false;
		const group = this.filter();
		const live = group.rules.filter(isLive);
		if (live.length === 0) return true;
		return group.combinator === "and" && live.every((node) => isRuleNode(node) && node.operator === "equals" && EXPORT_PUSHDOWN_COLUMNS.has(node.columnKey));
	}, ...ngDevMode ? [{ debugName: "serverReproducesFilter" }] : /* istanbul ignore next */ []);
	query = computed(() => ({
		...this.filters(),
		search: void 0,
		...this.pushdown(),
		tradeUnit: this.tradeUnit.code() ?? void 0,
		sort: toSortParam(this.sorts()),
		...this.filtersLocally() ? {
			page: 1,
			pageSize: MAX_PAGE_SIZE
		} : {}
	}), ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	attempt = signal(0, ...ngDevMode ? [{ debugName: "attempt" }] : /* istanbul ignore next */ []);
	needsScope = computed(() => !hasScope(this.query()), ...ngDevMode ? [{ debugName: "needsScope" }] : /* istanbul ignore next */ []);
	data = toSignal(toObservable(computed(() => ({
		query: this.query(),
		attempt: this.attempt(),
		everyPage: this.filtersLocally()
	}))).pipe(distinctUntilChanged((left, right) => JSON.stringify(left) === JSON.stringify(right)), scan((previous, next) => ({
		...next,
		refresh: next.attempt !== previous.attempt
	}), {
		query: this.query(),
		attempt: 0,
		everyPage: false,
		refresh: false
	}), switchMap(({ query, refresh, everyPage }) => !hasScope(query) ? [remoteLoading()] : everyPage ? this.listEveryPage(query, refresh) : this.source.list(query, {
		refresh,
		asOf: localDay(/* @__PURE__ */ new Date())
	}))), { initialValue: remoteLoading() });
	listEveryPage(query, refresh) {
		return listEveryPage(this.source, query, { refresh });
	}
	state = computed(() => this.needsScope() ? {
		status: "loaded",
		value: emptyPage(this.query())
	} : this.data(), ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	page = computed(() => {
		const state = this.state();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	isRefreshing = computed(() => this.state().status === "loading", ...ngDevMode ? [{ debugName: "isRefreshing" }] : /* istanbul ignore next */ []);
	serverSorted = computed(() => isServerSorted(this.query().sort, this.page()?.appliedSort), ...ngDevMode ? [{ debugName: "serverSorted" }] : /* istanbul ignore next */ []);
	matched = computed(() => {
		const term = (this.filters().search ?? "").trim();
		const group = this.filter();
		const kept = (this.page()?.rows ?? []).filter((row) => matchesGroup(row, this.columns, group) && matchesSearch(row, this.columns, term));
		return this.sortRows(kept);
	}, ...ngDevMode ? [{ debugName: "matched" }] : /* istanbul ignore next */ []);
	rows = computed(() => {
		if (!this.filtersLocally()) return this.matched();
		const start = (this.localPage() - 1) * DEFAULT_PAGE_SIZE;
		return this.matched().slice(start, start + DEFAULT_PAGE_SIZE);
	}, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	localPageSignal = signal(1, ...ngDevMode ? [{ debugName: "localPageSignal" }] : /* istanbul ignore next */ []);
	localPage = computed(() => Math.min(Math.max(this.localPageSignal(), 1), this.localTotalPages()), ...ngDevMode ? [{ debugName: "localPage" }] : /* istanbul ignore next */ []);
	localTotalPages = computed(() => Math.max(1, Math.ceil(this.matched().length / DEFAULT_PAGE_SIZE)), ...ngDevMode ? [{ debugName: "localTotalPages" }] : /* istanbul ignore next */ []);
	fetchedCount = computed(() => this.page()?.rows.length ?? 0, ...ngDevMode ? [{ debugName: "fetchedCount" }] : /* istanbul ignore next */ []);
	filterIsPartial = computed(() => this.filtersLocally() && (this.page()?.totalCount ?? 0) > this.fetchedCount(), ...ngDevMode ? [{ debugName: "filterIsPartial" }] : /* istanbul ignore next */ []);
	sortRows(rows) {
		const sorts = this.sorts();
		if (sorts.length === 0) return rows;
		return [...rows].sort((left, right) => compareBySorts(this.columns, sorts, left, right));
	}
	isEmpty = computed(() => this.rows().length === 0, ...ngDevMode ? [{ debugName: "isEmpty" }] : /* istanbul ignore next */ []);
	activeLocation = computed(() => {
		const code = this.query().tradeUnit;
		return this.locations().find((location) => location.code === code) ?? null;
	}, ...ngDevMode ? [{ debugName: "activeLocation" }] : /* istanbul ignore next */ []);
	scopeLabel = computed(() => {
		const location = this.activeLocation();
		return location ? `${location.code} — ${location.name ?? "Unnamed location"}` : "Contract list";
	}, ...ngDevMode ? [{ debugName: "scopeLabel" }] : /* istanbul ignore next */ []);
	scopeDescription = computed(() => {
		const location = this.activeLocation();
		return location ? [location.companyName, location.divisionName].filter(Boolean).join(" · ") : "Choose a trade unit to begin.";
	}, ...ngDevMode ? [{ debugName: "scopeDescription" }] : /* istanbul ignore next */ []);
	emptyMessage = computed(() => {
		if (this.needsScope()) return "Choose a trade unit in the top bar to load contracts.";
		if (this.filterIsPartial()) return `No match in the ${this.fetchedCount()} contracts loaded, of ${this.page()?.totalCount ?? 0} in this trade unit. The rest could not be loaded, so a match may exist; try again.`;
		return "No contracts match these filters.";
	}, ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	isSimulated = computed(() => !this.needsScope() && this.page()?.dataOrigin === "Simulated", ...ngDevMode ? [{ debugName: "isSimulated" }] : /* istanbul ignore next */ []);
	noticeSummaries = computed(() => this.showSystemNotices() ? [
		...this.isSimulated() ? ["Simulated rows, not read from CTRM"] : [],
		...this.customerNamesRedacted() ? ["Customer names are unavailable"] : [],
		...this.rowCapMessage() ? ["CTRM may have sent fewer rows than exist"] : []
	] : [], ...ngDevMode ? [{ debugName: "noticeSummaries" }] : /* istanbul ignore next */ []);
	showSystemNotices = computed(() => this.permissions.canSeeSystemNotices?.() ?? false, ...ngDevMode ? [{ debugName: "showSystemNotices" }] : /* istanbul ignore next */ []);
	rowCapMessage = computed(() => {
		const page = this.page();
		return this.needsScope() || !page ? null : listCompletenessNotice(page);
	}, ...ngDevMode ? [{ debugName: "rowCapMessage" }] : /* istanbul ignore next */ []);
	listKnownIncomplete = computed(() => this.page()?.listComplete === false, ...ngDevMode ? [{ debugName: "listKnownIncomplete" }] : /* istanbul ignore next */ []);
	customerNamesRedacted = computed(() => this.page()?.customerNames === "Redacted", ...ngDevMode ? [{ debugName: "customerNamesRedacted" }] : /* istanbul ignore next */ []);
	liveMetrics = computed(() => {
		const state = this.state();
		if (state.status !== "loaded") return null;
		const page = state.value;
		const status = this.query().status;
		const asOf = localDay(/* @__PURE__ */ new Date());
		if (this.filtersLocally()) {
			const matched = this.matched();
			const scope = {
				total: matched.length,
				basis: cardBasis(page, page.rows.length),
				filtered: true
			};
			return contractPortfolioMetrics(summarizeContracts(matched, asOf), scope, status);
		}
		if (page.summary) {
			const scope = {
				total: page.summary.rows,
				basis: cardBasis(page, page.totalCount),
				filtered: false
			};
			return contractPortfolioMetrics(page.summary, scope, status);
		}
		const pageOnly = page.rows.length < page.totalCount ? `This page only: ${page.rows.length} of ${page.totalCount}` : cardBasis(page, page.totalCount);
		return contractPortfolioMetrics(summarizeContracts(page.rows, asOf), {
			total: page.totalCount,
			basis: pageOnly,
			filtered: false
		}, status);
	}, ...ngDevMode ? [{ debugName: "liveMetrics" }] : /* istanbul ignore next */ []);
	resultKey = computed(() => JSON.stringify({
		...this.query(),
		page: void 0,
		sort: void 0,
		search: this.filters().search ?? "",
		filter: this.filter()
	}), ...ngDevMode ? [{ debugName: "resultKey" }] : /* istanbul ignore next */ []);
	metrics = linkedSignal({
		...ngDevMode ? { debugName: "metrics" } : /* istanbul ignore next */ {},
		source: () => ({
			key: this.resultKey(),
			metrics: this.liveMetrics()
		}),
		computation: (next, previous) => next.metrics ?? (previous !== void 0 && previous.source.key === next.key ? previous.value : null)
	});
	metricLabels = computed(() => portfolioLabels(this.query().status), ...ngDevMode ? [{ debugName: "metricLabels" }] : /* istanbul ignore next */ []);
	baselineLabel = computed(() => "All Contracts", ...ngDevMode ? [{ debugName: "baselineLabel" }] : /* istanbul ignore next */ []);
	rangeLabel = computed(() => {
		if (this.filtersLocally()) {
			const total = this.matched().length;
			if (total === 0) return "";
			return `${(this.localPage() - 1) * DEFAULT_PAGE_SIZE + 1}–${Math.min(this.localPage() * DEFAULT_PAGE_SIZE, total)} of ${total}`;
		}
		const page = this.page();
		if (!page || page.totalCount === 0) return "";
		return `${(page.page - 1) * page.pageSize + 1}–${Math.min(page.page * page.pageSize, page.totalCount)} of ${page.totalCount}`;
	}, ...ngDevMode ? [{ debugName: "rangeLabel" }] : /* istanbul ignore next */ []);
	displayPage = computed(() => this.filtersLocally() ? this.localPage() : this.page()?.page ?? 1, ...ngDevMode ? [{ debugName: "displayPage" }] : /* istanbul ignore next */ []);
	displayTotalPages = computed(() => this.filtersLocally() ? this.localTotalPages() : this.page()?.totalPages ?? 1, ...ngDevMode ? [{ debugName: "displayTotalPages" }] : /* istanbul ignore next */ []);
	canPagePrevious = computed(() => (this.page()?.page ?? 1) > 1, ...ngDevMode ? [{ debugName: "canPagePrevious" }] : /* istanbul ignore next */ []);
	canPageNext = computed(() => {
		const page = this.page();
		return page ? page.page < page.totalPages : false;
	}, ...ngDevMode ? [{ debugName: "canPageNext" }] : /* istanbul ignore next */ []);
	activeFilterCount = computed(() => activeRuleCount(this.filter()), ...ngDevMode ? [{ debugName: "activeFilterCount" }] : /* istanbul ignore next */ []);
	filterSummary = computed(() => describeGroup(this.columns, this.filter()), ...ngDevMode ? [{ debugName: "filterSummary" }] : /* istanbul ignore next */ []);
	searchTerm = computed(() => this.filters().search ?? "", ...ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []);
	sortScopeNote = computed(() => {
		const page = this.page();
		if (this.sorts().length === 0 || !page || page.totalPages <= 1 || this.serverSorted()) return null;
		return `Sorted within this page (${page.pageSize} of ${page.totalCount}). Sorting the full result set needs the API's sort parameter.`;
	}, ...ngDevMode ? [{ debugName: "sortScopeNote" }] : /* istanbul ignore next */ []);
	onViewChange(view) {
		this.filter.set(view.group);
		this.sorts.set(view.sort);
		if (view.columns !== void 0) {
			this.sessionColumns.set(view.columns);
			this.columnsKeptIn.set(null);
			this.columnsFailure.set(null);
		}
		this.localPageSignal.set(1);
	}
	search(term) {
		this.patch({ search: term || void 0 });
	}
	setFilter(key, value) {
		this.patch({ [key]: value.trim() || void 0 });
	}
	clearFilters() {
		this.patch({
			customerId: void 0,
			commodity: void 0,
			traderInitials: void 0,
			marketZone: void 0
		});
	}
	goToPage(page) {
		if (this.filtersLocally()) {
			this.localPageSignal.set(Math.min(Math.max(page, 1), this.localTotalPages()));
			return;
		}
		const total = this.page()?.totalPages ?? 1;
		const target = Math.min(Math.max(page, 1), Math.max(total, 1));
		if (target !== (this.page()?.page ?? 1)) this.filters.update((query) => ({
			...query,
			page: target
		}));
	}
	stepPage(step) {
		if (this.filtersLocally()) {
			this.goToPage(this.localPage() + step);
			return;
		}
		const page = this.page();
		if (!page) return;
		const next = page.page + step;
		if (next >= 1 && next <= page.totalPages) this.filters.update((query) => ({
			...query,
			page: next
		}));
	}
	onFilterChange(group) {
		this.filter.set(group);
		this.localPageSignal.set(1);
	}
	exportError = signal(null, ...ngDevMode ? [{ debugName: "exportError" }] : /* istanbul ignore next */ []);
	exportOutcome = signal(null, ...ngDevMode ? [{ debugName: "exportOutcome" }] : /* istanbul ignore next */ []);
	serverExportRowCap = signal({
		reached: null,
		cap: null,
		listComplete: null
	}, ...ngDevMode ? [{ debugName: "serverExportRowCap" }] : /* istanbul ignore next */ []);
	serverExportCompleteness = computed(() => {
		const { reached, cap, listComplete } = this.serverExportRowCap();
		if (listComplete === true) return "Every contract in the trade unit is in the file.";
		if (listComplete === false) return "This file is incomplete: CTRM did not return every contract it matched.";
		return reached === false ? "The file is complete." : rowCapNotice(reached, cap);
	}, ...ngDevMode ? [{ debugName: "serverExportCompleteness" }] : /* istanbul ignore next */ []);
	onExportFailed(message) {
		this.exportError.set(message);
		if (message !== null) this.exportOutcome.set(null);
	}
	onExportCompleted(outcome) {
		this.exportOutcome.set(outcome);
		this.exportError.set(null);
	}
	exportFilename = (scope) => {
		const query = this.query();
		const suffix = scope === "page" ? `page-${this.page()?.page ?? 1}` : "all";
		return `contracts-${query.tradeUnit ?? "all"}-${query.status.toLowerCase()}-${suffix}`;
	};
	exportAllRows = async () => {
		const first = this.page();
		if (!first) return null;
		const collected = [];
		const pages = Math.max(1, Math.ceil(first.totalCount / MAX_PAGE_SIZE));
		for (let page = 1; page <= pages; page += 1) {
			const state = await firstValueFrom(this.source.list({
				...this.query(),
				page,
				pageSize: MAX_PAGE_SIZE
			}).pipe(filter((value) => value.status !== "loading")));
			if (state.status !== "loaded") return null;
			collected.push(...state.value.rows);
		}
		const term = (this.filters().search ?? "").trim();
		const group = this.filter();
		const kept = collected.filter((row) => matchesGroup(row, this.columns, group) && matchesSearch(row, this.columns, term));
		return this.sortRows(kept);
	};
	serverExport = this.exportSource === null ? null : async (_scope, fields) => {
		if (!this.serverReproducesFilter()) return {
			ran: "skipped",
			reason: "A filter or search is applied on this screen, so the file was built here to match it."
		};
		if (fields.some((field) => !SERVER_EXPORT_FIELD_KEYS.has(field))) return {
			ran: "skipped",
			reason: "Commodity code and the price type and zone descriptions are not in the server's file yet, so the file was built here."
		};
		const source = this.exportSource;
		if (source === null) return {
			ran: "skipped",
			reason: "No server export is configured."
		};
		const result = await firstValueFrom(source.export({
			query: this.query(),
			fields
		}));
		this.serverExportRowCap.set(result.kind === "csv" ? {
			reached: result.rowCapReached,
			cap: result.rowCap,
			listComplete: result.listComplete ?? null
		} : {
			reached: null,
			cap: null,
			listComplete: null
		});
		switch (result.kind) {
			case "csv":
				downloadBlob(result.filename ?? `${this.exportFilename("all")}.csv`, result.csv);
				return { ran: "server" };
			case "unavailable": return {
				ran: "skipped",
				reason: result.reason
			};
			case "refused": return {
				ran: "failed",
				message: result.message
			};
		}
	};
	onSortChange(sorts) {
		this.sorts.set(sorts);
		this.filters.update((query) => ({
			...query,
			page: 1
		}));
	}
	onRowActivate(row) {
		this.hostContext.navigate({
			kind: "contract",
			contractNumber: row.contractNumber,
			params: { returnTo: this.returnTo(row) },
			state: recordJourneyState(this.startJourney(row))
		});
	}
	journeys = inject(RecordJourneyStore);
	startJourney(row) {
		const snapshot = {
			origin: "contracts",
			kind: "contract",
			label: "Contracts"
		};
		if (this.filtersLocally()) {
			const keys = this.matched().map((each) => each.contractNumber);
			return this.journeys.begin(startRecordJourney({
				...snapshot,
				keys,
				index: Math.max(0, keys.indexOf(row.contractNumber))
			}));
		}
		const page = this.page();
		const held = this.rows().map((each) => each.contractNumber);
		const offset = page === null ? 0 : (page.page - 1) * page.pageSize;
		const total = Math.max(page?.totalCount ?? held.length, offset + held.length);
		const journey = startRecordJourney({
			...snapshot,
			keys: held,
			offset,
			total,
			index: offset + Math.max(0, held.indexOf(row.contractNumber))
		});
		return this.journeys.begin(journey, page !== null && total > held.length ? this.everyKeyInOrder(page.pageSize) : void 0);
	}
	everyKeyInOrder(pageSize) {
		return this.listEveryPage({
			...this.query(),
			page: 1,
			pageSize: MAX_PAGE_SIZE
		}, false).pipe(filter((state) => state.status !== "loading"), take(1), filter((state) => state.status === "loaded"), map((state) => {
			const rows = state.value.rows;
			const keys = [];
			for (let start = 0; start < rows.length; start += pageSize) keys.push(...this.sortRows(rows.slice(start, start + pageSize)).map((each) => each.contractNumber));
			return keys;
		}));
	}
	returnTo(row) {
		return new URLSearchParams(toRouteParams(this.filters(), this.sorts(), row.contractNumber, this.filter())).toString();
	}
	openEdit(row) {
		this.hostContext.navigate({
			kind: "contract",
			contractNumber: row.contractNumber,
			mode: "edit",
			params: { returnTo: this.returnTo(row) }
		});
	}
	openCopy(row) {
		this.hostContext.navigate({
			kind: "new-contract",
			params: { copyFrom: row.contractNumber }
		});
	}
	pricingCopyOffered = inject(PRICING_SOURCE, { optional: true }) !== null;
	confirm = injectConfirm();
	openCopyWithPricing(row) {
		this.confirm({
			title: `Copy ${row.contractNumber} with pricing?`,
			message: COPY_WITH_PRICING_CONFIRM,
			confirmLabel: "Copy with pricing"
		}).pipe(take(1), filter((confirmed) => confirmed)).subscribe(() => this.hostContext.navigate({
			kind: "new-contract",
			params: {
				copyFrom: row.contractNumber,
				withPricing: "true"
			}
		}));
	}
	openPricing(row) {
		this.hostContext.navigate({
			kind: "review",
			origin: "pricing",
			contractNumber: row.contractNumber,
			params: {
				[RECORD_ORIGIN_PARAM]: "contracts",
				returnTo: this.returnTo(row)
			}
		});
	}
	openApproval(row) {
		this.hostContext.navigate({
			kind: "review",
			origin: "approvals",
			contractNumber: row.contractNumber,
			params: {
				[RECORD_ORIGIN_PARAM]: "contracts",
				returnTo: this.returnTo(row)
			}
		});
	}
	powerBiUrl = inject(CWS_EXTERNAL_LINKS).powerBi ?? null;
	newContractIntent = {
		kind: "new-contract",
		params: {}
	};
	newContractHref = computed(() => this.hostContext.hrefFor(this.newContractIntent), ...ngDevMode ? [{ debugName: "newContractHref" }] : /* istanbul ignore next */ []);
	followNewContract(event) {
		if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		this.hostContext.navigate(this.newContractIntent);
	}
	retry() {
		this.reissue();
	}
	refresh() {
		this.reissue();
	}
	reissue() {
		this.attempt.update((attempt) => attempt + 1);
	}
	patch(change) {
		this.filters.update((query) => ({
			...query,
			...change,
			page: 1
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: HomePageComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: HomePageComponent,
		isStandalone: true,
		selector: "cms-home-page",
		viewQueries: [{
			propertyName: "layoutRoot",
			first: true,
			predicate: ["layoutRoot"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<!--\n  `#layoutRoot` is what docs/02a §7's band is measured on (#759): this screen's own box, a block\n  element, never the window, so a host that gives CWS 900 px gets the 900 px layout (§8).\n-->\n<section #layoutRoot class=\"cws:space-y-4\">\n  <!--\n    The heading names the active scope rather than repeating \"Contracts\", so the page says which\n    trade unit is being shown. The h2-versus-h1 reasoning lives on the shared component now, along\n    with the `self-start` alignment of the actions — both were this screen's, and both were the\n    shape every other screen should have had.\n  -->\n  <cms-page-header [title]=\"scopeLabel()\" [description]=\"scopeDescription()\">\n    <ng-container cmsPageHeaderActions>\n      <!--\n        Power BI (docs/02 §2.3, §8; #756), before Add contract so the primary action stays last.\n        Workspace configuration: absent means no link at all, never a disabled stub. A new tab with\n        `noopener noreferrer`, because it leaves CWS and must not be able to reach back into it.\n      -->\n      @if (powerBiUrl; as url) {\n        <a\n          [href]=\"url\"\n          target=\"_blank\"\n          rel=\"noopener noreferrer\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          data-testid=\"power-bi-link\"\n        >\n          Power BI\n          <span class=\"cws:sr-only\">(opens in a new tab)</span>\n        </a>\n      }\n      <!--\n        Creating a contract belongs to this screen rather than the shell's top bar: it acts on the\n        list you are looking at, where the shell's chrome is for moving between areas of the\n        application (docs/02a §6.1). Sitting beside the trade-unit control also puts it next to the\n        thing that scopes it.\n\n        An anchor rather than a button, so middle-click, Ctrl+click and \"copy link address\" work.\n\n        Its href and its click both come from the host contract (E9 PR 4, F9.10): this used to be a\n        routerLink to the shell's /contracts/new, which embedded drives the host's router at a path the\n        host may not publish (docs/02 §1a). A plain click asks the host; a modified click is left to the\n        browser, which opens the host's href.\n      -->\n      <!--\n        Sized to match Export data and the pager (JFrisbie, 2026-08-26), which are all\n        `scoular-btn scoular-btn-secondary`. Two deliberate details:\n\n        1. **`scoular-btn-sm` is dropped rather than overridden.** It is the only thing that made this\n           button smaller — `px-2.5 py-1 text-xs` against the base `px-4 py-2 text-sm`.\n           ✅ **Updated 2026-09-16:** the original reason was that the design system's CSS was\n           unlayered, so a Tailwind `h-[38px]` or `px-4` could not have beaten it at all.\n           `components.css` now sits in `@layer components` and a utility would win — but dropping the\n           class is still the right version, because matching a design-system control by wearing the\n           same classes it wears survives the design system changing its own padding, and an\n           overriding utility does not.\n        2. **`border border-transparent` is load-bearing, not decoration.** `scoular-btn-secondary`\n           carries `border border-slate-200`; `scoular-btn-primary` carries no border at all, so at\n           identical padding a primary button is **2px shorter** than the controls beside it. A\n           transparent border of the same width restores the box without touching the blue.\n\n        The colour is untouched: `scoular-btn-primary` is `bg-scoular-blue`, and the size variants\n        set only padding and font size, so nothing here changes the blue.\n      -->\n      <a\n        [attr.href]=\"newContractHref()\"\n        (click)=\"followNewContract($event)\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n      >\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\n        Add contract\n      </a>\n    </ng-container>\n  </cms-page-header>\n\n  <!-- #888: the save a Save-and-close from a record opened here came back with, said once. -->\n  <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\n\n  <!--\n    Standing notices, in the shared collapsible panel — the same one the approval queue and both\n    pricing screens use (JFrisbie, 2026-09-14). It renders nothing at all when there is nothing to\n    say, which on this screen is the usual case.\n\n    ⚠ **The export failure below the filter is deliberately NOT in here.** This panel is for standing\n    conditions — environment, data origin, capability gaps — and never for the outcome of something\n    the user just did. A failed export belongs beside the control that produced it; behind a\n    collapsed panel it is a message nobody sees.\n  -->\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\n    @if (isSimulated()) {\n      <!--\n        Not decoration. A demo that silently shows generated data is how generated data gets quoted\n        as a production readout — the API stamps every simulated response for exactly this reason.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">Simulated data</div>\n        <div class=\"scoular-alert-description\">\n          These contracts are generated locally, not read from CTRM.\n        </div>\n      </div>\n    }\n    @if (customerNamesRedacted()) {\n      <!--\n        🔴 The customer directory is refusing us (#328). Without this the column falls back to ids,\n        which is exactly what it showed before the directory existed — so the regression and the\n        original gap are indistinguishable and nobody would see it go.\n\n        ⚠ The wording names no internal identifier, per the 2026-09-17 copy guard, and it says what\n        the user can rely on rather than what is broken: the ids are correct, so the screen is usable\n        and the contracts are right. It also says it will not clear on its own, because it will not —\n        this is a configuration entry that needs a person, unlike a transient lookup failure, which\n        deliberately raises nothing.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\n        <div class=\"scoular-alert-description\">\n          The customer directory is not answering for this application, so the Customer column falls\n          back to account numbers. The contracts and their numbers are unaffected. This will not\n          clear by retrying — please report it.\n        </div>\n      </div>\n    }\n    @if (rowCapMessage(); as message) {\n      <!--\n        #662: CTRM truncates at a fixed array size and does not say so; the server counts what came\n        back (#450). Shown only on an explicit true: a server that does not say gets no notice and\n        no claim of completeness. #1116: when the server knows the list is short (listComplete\n        false) the title drops \"may be\"; the sentence itself starts \"This list is incomplete\", so\n        the title does not repeat it.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">\n          {{ listKnownIncomplete() ? 'Not every contract was read' : 'This list may be incomplete' }}\n        </div>\n        <div class=\"scoular-alert-description\">{{ message }}</div>\n      </div>\n    }\n  </cms-notices-panel>\n\n  <!--\n    🔴 **The portfolio cards** (JFrisbie, 2026-09-16) — what the book looks like before any\n    filtering, matching the approval queue's summary strip one click away.\n\n    `scoular-card` for the surface and the same type scale as the approvals cards, deliberately:\n    the two screens are a click apart, and a second card style would read as a second kind of\n    thing. The markup is duplicated rather than extracted into a shared component **for now** —\n    two consumers is where the standards say to centralise, and that is the next change rather\n    than this one, because extracting it while the metric shapes are still settling would freeze\n    an API across two features on one day's evidence.\n\n    ⚠ **Gated on a trade unit.** Without one the screen issues no request at all, so the cards\n    would render five zeroes — which reads as \"an empty book\" rather than \"nothing asked for\".\n    Same gate, same reason, as the approval queue's strip.\n\n    🔴 Colour is never the only carrier: the urgent cards are distinguished by their LABEL as much\n    as by the tint, because roughly 1 in 12 men has a colour vision deficiency (02a §4). \"Needs\n    attention\" says what it is with the colour removed.\n  -->\n  <!--\n    #1147: every figure is over the WHOLE filtered result, so while it is still arriving (pages 2 to N\n    of a search, or a new status or scope) each card shows its label over a skeleton rather than a\n    partial total. `aria-busy` tells a screen reader the figures are coming; the hidden \"Loading\" is\n    what it reads in place of each.\n  -->\n  @if (!needsScope()) {\n    <dl\n      class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:md:grid-cols-3 cws:xl:grid-cols-5\"\n      aria-label=\"Portfolio figures\"\n      [attr.aria-busy]=\"metrics() === null ? 'true' : null\"\n    >\n      @if (metrics() === null) {\n        @for (label of metricLabels(); track label) {\n          <div class=\"scoular-card cws:px-4 cws:py-3\">\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ label }}</dt>\n            <dd class=\"cws:mt-1\">\n              <span class=\"cws:sr-only\">Loading</span>\n              <span class=\"cws:block cws:h-8 cws:w-24 cws:animate-pulse cws:rounded-md cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></span>\n            </dd>\n            <dd class=\"cws:mt-0.5\">\n              <span class=\"cws:block cws:h-3 cws:w-28 cws:animate-pulse cws:rounded cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></span>\n            </dd>\n          </div>\n        }\n      }\n      @for (metric of metrics() ?? []; track metric.label) {\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\n\n          <dd\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\n            [class]=\"\n              metric.urgent\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\n                : 'cws:text-slate-900 cws:dark:text-white'\n            \"\n          >\n            {{ metric.value }}\n          </dd>\n\n          <!-- A second `<dd>`, not a `<p>`: a `<div>` in a `<dl>` holds only `<dt>`/`<dd>` (#764). -->\n          <dd class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</dd>\n        </div>\n      }\n    </dl>\n  }\n\n  <!--\n    Filter bar (02a §6.1): a wide free-text search, then the status the request is scoped to.\n\n    🔴 The \"Filters\" dropdown that stood here is gone (JFrisbie, 2026-09-10, to a screenshot). The\n    filter now lives **inline below this bar** as chips plus an editor row, because a filter you can\n    only see by opening something is a filter people forget is applied — and an empty grid with a\n    hidden filter behind it is the single most confusing state this screen can be in.\n  -->\n  <cms-grid-toolbar>\n    <!--\n      `flex-1` with a floor and a ceiling: search is the control on this bar people use most, so it\n      takes the free space rather than sitting at input default width. The max stops it stretching to\n      an unreadable line length on a wide monitor.\n    -->\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-2xl\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <!--\n        🔴 `[value]` is bound to `searchTerm()`, NOT to `query().search`.\n\n        `query()` deliberately blanks `search` — the term is applied across every column here rather\n        than sent to a server that matches three — so binding the box to the query would render it\n        permanently empty: you could type, the grid would filter, and the text would vanish. Caught\n        by a test asserting the box reflects a term restored from the URL.\n      -->\n      <!--\n        ⚠ The placeholder named four fields and the search has never been limited to four:\n        `matchesSearch` tests **every column the grid renders** (`columns.some(...)`). The wording\n        was inherited from the server-side search it replaced, which does match three — so the box\n        had been under-claiming its own behaviour, which is the #196 class of defect with the sign\n        flipped.\n      -->\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        placeholder=\"Search every column\"\n        [value]=\"searchTerm()\"\n        (input)=\"search($any($event.target).value)\"\n      />\n    </label>\n\n    <!--\n      `scoular-btn` without `-sm`, so the box model matches `scoular-form-input` exactly: both are\n      `px-4 py-2 text-sm` with a 1px border, which is what makes the three controls the same height\n      without a hard-coded pixel value that would drift when the design system changes its padding.\n    -->\n    <!--\n      The view selector, where the Status dropdown used to be (JFrisbie, 2026-09-10).\n\n      🔴 **Status is deliberately no longer selectable, and the consequence is real.** It selected\n      which CTRM *procedure* the request reached — `open`/`closed` are `OpenDS`, `unapproved` is a\n      different one returning `dsCon` — so removing the control does not narrow a filter, it fixes\n      the request to **open** contracts. Closed and unapproved are unreachable from this screen\n      until a control returns. Raised and accepted; `query().status` still carries the value, the URL\n      still round-trips it, and the request still sends it, so restoring the control is a template\n      change rather than a rebuild.\n\n      ⚠ Which is also why the baseline is called **\"All Open Contracts\"** rather than \"All\n      Contracts\": `contract/list` has no all-statuses option and refuses the call, so a bare \"All\"\n      would claim more than the grid can show — the defect #196 is open about. Since #841 the label\n      names whichever status the URL chose (\"All Closed Contracts\" on `?status=Closed`). Since 2026-10-23 it is \"All Contracts\" whatever the status (JFrisbie); the first card still names the status.\n\n      Width lives here rather than on the control: `.scoular-form-input` is `@apply w-full` and the\n      design system compiles unlayered, so a `w-*` on the button itself would lose. Seventh instance.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [baselineLabel]=\"baselineLabel()\"\n        [columnLayout]=\"savedViewColumnLayout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <!--\n      \"+ Add filter\", beside the view selector rather than on a row of its own (JFrisbie,\n      2026-09-10, to a screenshot).\n\n      🔴 **The button is here and the editor it opens is still the builder's.** It calls\n      `builder.beginAdd()` through the template reference below, so the editor's open/closed state\n      keeps exactly one owner. Lifting that state up here would mean this button had to know that\n      committing a rule closes the editor and that clicking a chip re-opens it — two components\n      sharing one flag, which is how they end up disagreeing.\n\n      `items-end` on the row aligns it with the bottom of the two labelled controls beside it, so all\n      three sit on one baseline despite only two having captions.\n    -->\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline\"\n      (click)=\"builder.beginAdd()\"\n    >\n      + Add filter\n    </button>\n\n\n    <!--\n      Clear sort, beside Add filter and only while there is a sort to clear.\n\n      Shared with both work queues as `cms-clear-sort-button`. It carries the reasoning that used\n      to live here: rendered conditionally rather than shipped disabled, and a badge whose `h-5` is\n      what keeps the button the same height as its neighbours once a count appears.\n\n      No `defaultSorts` here, so clearing means no sort at all -- this grid arrives in the order the\n      server sent it. The queues pass their own arrival ordering instead.\n    -->\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"onSortChange($event)\" />\n\n    <!--\n      Export, on the same row as search and filters but pushed hard right by `ml-auto`.\n\n      Right-aligned rather than next to the filters because it acts on the *result* of everything to\n      its left — reading order is narrow, then narrow, then take what you have. `ml-auto` rather than\n      a spacer element so it still sits correctly when the bar wraps on a narrow viewport.\n    -->\n    <!--\n      Columns, pushed right with the export it shapes (F4.1a, #748): show, hide and reorder within what\n      the trade unit allows. The export then starts from what this leaves visible (docs/02 §8).\n    -->\n    <cms-grid-column-menu\n      class=\"cws:ml-auto\"\n      [fields]=\"columnMenuFields()\"\n      [lockedKeys]=\"lockedColumnKeys\"\n      [keptIn]=\"columnsKeptIn()\"\n      [failure]=\"columnsFailure()\"\n      (fieldsChange)=\"onColumnsChange($event)\"\n      (reset)=\"onColumnsReset()\"\n    />\n\n    <!-- The export's own columns (#768): the grid's, plus Customer name beside Customer ID. -->\n    <cms-grid-export\n      [columns]=\"exportColumns\"\n      [visibleKeys]=\"exportVisibleKeys()\"\n      [pageRows]=\"rows()\"\n      [totalCount]=\"page()?.totalCount ?? 0\"\n      [allRows]=\"exportAllRows\"\n      [filename]=\"exportFilename\"\n      [disabled]=\"isEmpty()\"\n      [serverExport]=\"serverExport\"\n      (failed)=\"onExportFailed($event)\"\n      (completed)=\"onExportCompleted($event)\"\n    />\n\n    <!--\n      Refresh, between Export and the pager (JFrisbie, 2026-09-03).\n\n      It re-issues the SAME query, so filters, sort and the current page all survive — see\n      `refresh()`. That is the whole point of it sitting here rather than being a link back to an\n      unfiltered workspace.\n\n      ⚠ **It is not guaranteed to re-read CTRM.** The BFF caches the contract list for 60s per\n      caller and scope (`Ctrm:ContractListCacheTtl`), and exposes no way for a client to ask it not\n      to — so inside that window this returns the same rows it already had. The button is still\n      honest about what it does (re-ask the server) and the cache is doing what it was built for;\n      it just means \"refresh\" is not a promise of freshness until the API offers a bypass. Raised for\n      the backend lane rather than worked around here, because a cache-busting parameter the server\n      ignores would be worse than no button.\n    -->\n    <cms-refresh-button\n      label=\"Refresh contracts\"\n      [busy]=\"isRefreshing()\"\n      [disabled]=\"needsScope()\"\n      (refresh)=\"refresh()\"\n    />\n\n    <!--\n      A second pager, so advancing a page does not mean scrolling to the bottom of 50 rows first.\n      Same component as the footer's, not a copy — two hand-written copies drift, and one gains a\n      disabled state or a label the other does not.\n    -->\n    <cms-pager\n      [page]=\"displayPage()\"\n      [totalPages]=\"displayTotalPages()\"\n      position=\"top\"\n      (goTo)=\"goToPage($event)\"\n    />\n  </cms-grid-toolbar>\n\n  <!--\n    The filter, inline and always visible — chips for what is applied, an editor row for building\n    the next rule.\n\n    🔴 Below the toolbar rather than inside a dropdown, which is the substance of the redesign. The\n    chips are the answer to \"why is this grid showing so little\", and that question is asked *while\n    looking at the grid* — so the answer has to be on the page rather than one click away.\n  -->\n  <!--\n    ⚠ `#builder` is read by the \"+ Add filter\" button on the toolbar above, and\n    `[showAddButton]=\"false\"` is what stops a second one rendering here. The two go together — drop\n    either and the screen has no way to open the editor, or two ways in two places.\n\n    The component renders **nothing at all** when there are no rules and the editor is closed, which\n    is why removing its own button leaves no empty band above the grid.\n  -->\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onFilterChange($event)\"\n  />\n\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    Which path wrote the last export (F4.3c). Beside the export failure and for the same reason:\n    it is the outcome of something the user just did, so it belongs by the control rather than in\n    the collapsible notices panel. Shown after every export, not only after a fallback — a note\n    that appeared only when something went sideways would leave the ordinary case unexplained.\n  -->\n  @if (exportOutcome(); as outcome) {\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\" aria-label=\"Export result\">\n      <div class=\"scoular-alert-description\">\n        @if (outcome.ran === 'server') {\n          Exported {{ outcome.rows }} rows by the server.\n          @if (serverExportCompleteness(); as completeness) {\n            {{ completeness }}\n          }\n        } @else if (outcome.reason) {\n          Exported {{ outcome.rows }} rows from this screen. {{ outcome.reason }}\n        } @else {\n          Exported {{ outcome.rows }} rows from this screen, as shown.\n        }\n      </div>\n    </div>\n  }\n\n  <cms-async-container\n    [data]=\"state()\"\n    [empty]=\"isEmpty()\"\n    [emptyMessage]=\"emptyMessage()\"\n    loadingLabel=\"Loading contracts\"\n    (retry)=\"retry()\"\n  >\n    <!--\n      `trackBy` on the contract NUMBER rather than the row object is what makes `focusKey` able to match\n      at all: returning from the detail screen re-fetches, so the object for a given contract is a\n      different one than the row the user left, and object identity would never match.\n    -->\n    <!--\n      🔴 **Striped WITH tones, which the grid's own remarks warn against — measured before doing it**\n      (JFrisbie, 2026-09-15). This is the only grid that declares a `rowTone`, and the standing rule\n      was that a toned grid must not stripe, because a shaded row could then mean \"rejected\" or just\n      \"even\".\n\n      ✅ **The mechanism was never the risk.** `rowClassFor` emits the stripe only when the tone is\n      empty, so a tinted row keeps its tint — the two cannot fight, and a toned row is simply never\n      striped.\n\n      🔑 **What settled the ambiguity is that the cues separate by HUE, not by lightness.** Composited\n      over white and measured in Edge: the stripe lands on `rgb(250, 251, 253)` — cool, blue-leaning —\n      while `negative` is `rgb(254, 248, 246)` and `caution` is `rgb(255, 253, 242)`, both warm. The\n      tone-versus-stripe separations (9 and 12) are *larger* than the stripe-versus-plain one (7), so\n      a tinted row does not read as a striped one. Dark mode is more comfortable still: tones sit 25–28\n      from the stripe against its 11 from plain.\n\n      ⚠ **The residual, stated rather than smoothed over: in light mode every one of these washes is\n      faint**, so the distinction rests on hue. That is acceptable here only because the tint was never\n      the carrier — the 2026-09-03 tuning pass that softened these deliberately describes the tint as a\n      hint that \"competed with the status pill that says the same thing in words\". **The pill is the\n      answer for anyone who cannot separate the hues**, and it is in every toned row. 🔴 Do not\n      strengthen the tints to widen the gap: that pass softened them for a reason.\n\n      ⚠ **The zebra rhythm is irregular here and that is inherent**, not a defect — a tone displaces a\n      stripe, so with roughly a third of rows unapproved the alternation breaks wherever a tinted row\n      sits. Judged acceptable from a rendered 12-row sample at that ratio.\n    -->\n    <!-- The VISIBLE columns (F4.1a, #748); search, filters and sorting still read every column. -->\n    <cms-data-grid\n      [rows]=\"rows()\"\n      [columns]=\"visibleColumns()\"\n      [columnMenu]=\"false\"\n      label=\"Contracts\"\n      [striped]=\"true\"\n      [sorts]=\"sorts()\"\n      [rowTone]=\"rowTone\"\n      [actions]=\"rowActions()\"\n      [rowLabel]=\"trackByContract\"\n      [trackBy]=\"trackByContract\"\n      [focusKey]=\"focusKey()\"\n      (sortChange)=\"onSortChange($event)\"\n      activateLabel=\"Open\"\n      (rowActivate)=\"onRowActivate($event)\"\n      (pageStep)=\"stepPage($event)\"\n    />\n\n    <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\n      <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n        <p>{{ rangeLabel() }}</p>\n        <!--\n          Every column is sortable now, but the server still has no sort parameter, so the sort is\n          applied to the current page only. On a multi-page result that is a materially different\n          thing from sorting the result set, and a trader looking for the highest price would\n          otherwise get the highest price on page 1 with no reason to doubt it.\n        -->\n        @if (sortScopeNote(); as note) {\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">{{ note }}</p>\n        }\n\n        <!--\n          🔴 What the filter was applied to. This is the honest half of client-side filtering and it\n          is not optional.\n\n          A rule can only match rows that arrived, so on a trade unit with more contracts than one\n          page holds, \"12 matches\" is a claim about what was read and not about the trade unit. A\n          filter builder that presented the first number as the second would be the\n          complete-looking-but-incomplete answer this project keeps recording — the same shape as\n          CR-4 (#31) on the CTRM side.\n\n          Shown only while filtering locally and only when the server held rows back, so an ordinary\n          filtered view of a small trade unit says nothing extra.\n        -->\n        @if (filterIsPartial()) {\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n            Matched against the {{ fetchedCount() }} contracts loaded, of\n            {{ page()?.totalCount ?? 0 }} in this trade unit — there may be more matches than are\n            listed.\n          </p>\n        }\n      </div>\n\n      <cms-pager\n        [page]=\"displayPage()\"\n        [totalPages]=\"displayTotalPages()\"\n        position=\"bottom\"\n        (goTo)=\"goToPage($event)\"\n      />\n    </footer>\n\n    <!--\n      The \"Opening SC1240000 — the contract view is F4.1b\" placeholder was here. It has been replaced\n      by real navigation to `/contracts/{number}` (2026-08-27), so there is nothing to stand in for.\n    -->\n    <!--\n      No primary action here any more: the trade-unit control lives in the shell top bar, and a\n      feature library reaching out to focus a shell control would be the wrong direction of\n      dependency. The message names where to go instead.\n    -->\n  </cms-async-container>\n</section>\n",
		dependencies: [
			{
				kind: "component",
				type: AsyncContainerComponent,
				selector: "cms-async-container",
				inputs: [
					"data",
					"empty",
					"emptyMessage",
					"loadingLabel"
				],
				outputs: ["retry"]
			},
			{
				kind: "component",
				type: ClearSortButtonComponent,
				selector: "cms-clear-sort-button",
				inputs: ["sorts", "defaultSorts"],
				outputs: ["clear"]
			},
			{
				kind: "component",
				type: DataGridComponent,
				selector: "cms-data-grid",
				inputs: [
					"rows",
					"columns",
					"columnMenu",
					"columnsKey",
					"lockedColumns",
					"label",
					"striped",
					"actions",
					"actionsHeader",
					"actionsWidth",
					"rowLabel",
					"activateLabel",
					"selectable",
					"sorts",
					"rowTone",
					"trackBy",
					"focusKey"
				],
				outputs: [
					"sortChange",
					"rowActivate",
					"cellCopy",
					"pageStep",
					"rowToggle",
					"selectAll"
				]
			},
			{
				kind: "component",
				type: FilterBuilderComponent,
				selector: "cms-filter-builder",
				inputs: [
					"columns",
					"filter",
					"showAddButton"
				],
				outputs: ["filterChange"]
			},
			{
				kind: "component",
				type: FilterSelectComponent,
				selector: "cms-filter-select",
				inputs: [
					"scope",
					"filter",
					"sorts",
					"baselineLabel",
					"columnLayout"
				],
				outputs: ["viewChange"]
			},
			{
				kind: "directive",
				type: SearchShortcutDirective,
				selector: "input[cmsSearchShortcut]"
			},
			{
				kind: "component",
				type: GridColumnMenuComponent,
				selector: "cms-grid-column-menu",
				inputs: [
					"fields",
					"lockedKeys",
					"keptIn",
					"failure",
					"disabled",
					"resetLabel"
				],
				outputs: ["fieldsChange", "reset"]
			},
			{
				kind: "component",
				type: GridExportComponent,
				selector: "cms-grid-export",
				inputs: [
					"columns",
					"visibleKeys",
					"pageRows",
					"totalCount",
					"allRows",
					"filename",
					"disabled",
					"serverExport"
				],
				outputs: ["completed", "failed"]
			},
			{
				kind: "component",
				type: GridToolbarComponent,
				selector: "cms-grid-toolbar"
			},
			{
				kind: "component",
				type: NoticesPanelComponent,
				selector: "cms-notices-panel",
				inputs: [
					"summaries",
					"heading",
					"systemNotices",
					"initiallyExpanded"
				]
			},
			{
				kind: "component",
				type: StatusMessageComponent,
				selector: "cms-status-message",
				inputs: ["outcome", "dismissMs"],
				outputs: ["dismissed"]
			},
			{
				kind: "component",
				type: PagerComponent,
				selector: "cms-pager",
				inputs: [
					"page",
					"totalPages",
					"position"
				],
				outputs: ["goTo"]
			},
			{
				kind: "component",
				type: RefreshButtonComponent,
				selector: "cms-refresh-button",
				inputs: [
					"label",
					"busy",
					"disabled"
				],
				outputs: ["refresh"]
			},
			{
				kind: "component",
				type: PageHeaderComponent,
				selector: "cms-page-header",
				inputs: ["title", "description"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: HomePageComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-home-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncContainerComponent,
				ClearSortButtonComponent,
				DataGridComponent,
				FilterBuilderComponent,
				FilterSelectComponent,
				SearchShortcutDirective,
				GridColumnMenuComponent,
				GridExportComponent,
				GridToolbarComponent,
				NoticesPanelComponent,
				StatusMessageComponent,
				PagerComponent,
				RefreshButtonComponent,
				PageHeaderComponent
			],
			template: "<!--\n  `#layoutRoot` is what docs/02a §7's band is measured on (#759): this screen's own box, a block\n  element, never the window, so a host that gives CWS 900 px gets the 900 px layout (§8).\n-->\n<section #layoutRoot class=\"cws:space-y-4\">\n  <!--\n    The heading names the active scope rather than repeating \"Contracts\", so the page says which\n    trade unit is being shown. The h2-versus-h1 reasoning lives on the shared component now, along\n    with the `self-start` alignment of the actions — both were this screen's, and both were the\n    shape every other screen should have had.\n  -->\n  <cms-page-header [title]=\"scopeLabel()\" [description]=\"scopeDescription()\">\n    <ng-container cmsPageHeaderActions>\n      <!--\n        Power BI (docs/02 §2.3, §8; #756), before Add contract so the primary action stays last.\n        Workspace configuration: absent means no link at all, never a disabled stub. A new tab with\n        `noopener noreferrer`, because it leaves CWS and must not be able to reach back into it.\n      -->\n      @if (powerBiUrl; as url) {\n        <a\n          [href]=\"url\"\n          target=\"_blank\"\n          rel=\"noopener noreferrer\"\n          class=\"scoular-btn scoular-btn-secondary\"\n          data-testid=\"power-bi-link\"\n        >\n          Power BI\n          <span class=\"cws:sr-only\">(opens in a new tab)</span>\n        </a>\n      }\n      <!--\n        Creating a contract belongs to this screen rather than the shell's top bar: it acts on the\n        list you are looking at, where the shell's chrome is for moving between areas of the\n        application (docs/02a §6.1). Sitting beside the trade-unit control also puts it next to the\n        thing that scopes it.\n\n        An anchor rather than a button, so middle-click, Ctrl+click and \"copy link address\" work.\n\n        Its href and its click both come from the host contract (E9 PR 4, F9.10): this used to be a\n        routerLink to the shell's /contracts/new, which embedded drives the host's router at a path the\n        host may not publish (docs/02 §1a). A plain click asks the host; a modified click is left to the\n        browser, which opens the host's href.\n      -->\n      <!--\n        Sized to match Export data and the pager (JFrisbie, 2026-08-26), which are all\n        `scoular-btn scoular-btn-secondary`. Two deliberate details:\n\n        1. **`scoular-btn-sm` is dropped rather than overridden.** It is the only thing that made this\n           button smaller — `px-2.5 py-1 text-xs` against the base `px-4 py-2 text-sm`.\n           ✅ **Updated 2026-09-16:** the original reason was that the design system's CSS was\n           unlayered, so a Tailwind `h-[38px]` or `px-4` could not have beaten it at all.\n           `components.css` now sits in `@layer components` and a utility would win — but dropping the\n           class is still the right version, because matching a design-system control by wearing the\n           same classes it wears survives the design system changing its own padding, and an\n           overriding utility does not.\n        2. **`border border-transparent` is load-bearing, not decoration.** `scoular-btn-secondary`\n           carries `border border-slate-200`; `scoular-btn-primary` carries no border at all, so at\n           identical padding a primary button is **2px shorter** than the controls beside it. A\n           transparent border of the same width restores the box without touching the blue.\n\n        The colour is untouched: `scoular-btn-primary` is `bg-scoular-blue`, and the size variants\n        set only padding and font size, so nothing here changes the blue.\n      -->\n      <a\n        [attr.href]=\"newContractHref()\"\n        (click)=\"followNewContract($event)\"\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\n      >\n        <span aria-hidden=\"true\" class=\"cws:text-base cws:leading-none\">+</span>\n        Add contract\n      </a>\n    </ng-container>\n  </cms-page-header>\n\n  <!-- #888: the save a Save-and-close from a record opened here came back with, said once. -->\n  <cms-status-message [outcome]=\"arrivedAfterSave()\" (dismissed)=\"arrivedAfterSave.set(null)\" />\n\n  <!--\n    Standing notices, in the shared collapsible panel — the same one the approval queue and both\n    pricing screens use (JFrisbie, 2026-09-14). It renders nothing at all when there is nothing to\n    say, which on this screen is the usual case.\n\n    ⚠ **The export failure below the filter is deliberately NOT in here.** This panel is for standing\n    conditions — environment, data origin, capability gaps — and never for the outcome of something\n    the user just did. A failed export belongs beside the control that produced it; behind a\n    collapsed panel it is a message nobody sees.\n  -->\n  <cms-notices-panel [summaries]=\"noticeSummaries()\">\n    @if (isSimulated()) {\n      <!--\n        Not decoration. A demo that silently shows generated data is how generated data gets quoted\n        as a production readout — the API stamps every simulated response for exactly this reason.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">Simulated data</div>\n        <div class=\"scoular-alert-description\">\n          These contracts are generated locally, not read from CTRM.\n        </div>\n      </div>\n    }\n    @if (customerNamesRedacted()) {\n      <!--\n        🔴 The customer directory is refusing us (#328). Without this the column falls back to ids,\n        which is exactly what it showed before the directory existed — so the regression and the\n        original gap are indistinguishable and nobody would see it go.\n\n        ⚠ The wording names no internal identifier, per the 2026-09-17 copy guard, and it says what\n        the user can rely on rather than what is broken: the ids are correct, so the screen is usable\n        and the contracts are right. It also says it will not clear on its own, because it will not —\n        this is a configuration entry that needs a person, unlike a transient lookup failure, which\n        deliberately raises nothing.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">Showing account numbers instead of customer names</div>\n        <div class=\"scoular-alert-description\">\n          The customer directory is not answering for this application, so the Customer column falls\n          back to account numbers. The contracts and their numbers are unaffected. This will not\n          clear by retrying — please report it.\n        </div>\n      </div>\n    }\n    @if (rowCapMessage(); as message) {\n      <!--\n        #662: CTRM truncates at a fixed array size and does not say so; the server counts what came\n        back (#450). Shown only on an explicit true: a server that does not say gets no notice and\n        no claim of completeness. #1116: when the server knows the list is short (listComplete\n        false) the title drops \"may be\"; the sentence itself starts \"This list is incomplete\", so\n        the title does not repeat it.\n      -->\n      <div class=\"scoular-alert scoular-alert-warning\" role=\"status\">\n        <div class=\"scoular-alert-title\">\n          {{ listKnownIncomplete() ? 'Not every contract was read' : 'This list may be incomplete' }}\n        </div>\n        <div class=\"scoular-alert-description\">{{ message }}</div>\n      </div>\n    }\n  </cms-notices-panel>\n\n  <!--\n    🔴 **The portfolio cards** (JFrisbie, 2026-09-16) — what the book looks like before any\n    filtering, matching the approval queue's summary strip one click away.\n\n    `scoular-card` for the surface and the same type scale as the approvals cards, deliberately:\n    the two screens are a click apart, and a second card style would read as a second kind of\n    thing. The markup is duplicated rather than extracted into a shared component **for now** —\n    two consumers is where the standards say to centralise, and that is the next change rather\n    than this one, because extracting it while the metric shapes are still settling would freeze\n    an API across two features on one day's evidence.\n\n    ⚠ **Gated on a trade unit.** Without one the screen issues no request at all, so the cards\n    would render five zeroes — which reads as \"an empty book\" rather than \"nothing asked for\".\n    Same gate, same reason, as the approval queue's strip.\n\n    🔴 Colour is never the only carrier: the urgent cards are distinguished by their LABEL as much\n    as by the tint, because roughly 1 in 12 men has a colour vision deficiency (02a §4). \"Needs\n    attention\" says what it is with the colour removed.\n  -->\n  <!--\n    #1147: every figure is over the WHOLE filtered result, so while it is still arriving (pages 2 to N\n    of a search, or a new status or scope) each card shows its label over a skeleton rather than a\n    partial total. `aria-busy` tells a screen reader the figures are coming; the hidden \"Loading\" is\n    what it reads in place of each.\n  -->\n  @if (!needsScope()) {\n    <dl\n      class=\"cws:grid cws:grid-cols-2 cws:gap-3 cws:md:grid-cols-3 cws:xl:grid-cols-5\"\n      aria-label=\"Portfolio figures\"\n      [attr.aria-busy]=\"metrics() === null ? 'true' : null\"\n    >\n      @if (metrics() === null) {\n        @for (label of metricLabels(); track label) {\n          <div class=\"scoular-card cws:px-4 cws:py-3\">\n            <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ label }}</dt>\n            <dd class=\"cws:mt-1\">\n              <span class=\"cws:sr-only\">Loading</span>\n              <span class=\"cws:block cws:h-8 cws:w-24 cws:animate-pulse cws:rounded-md cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></span>\n            </dd>\n            <dd class=\"cws:mt-0.5\">\n              <span class=\"cws:block cws:h-3 cws:w-28 cws:animate-pulse cws:rounded cws:bg-slate-100 cws:dark:bg-slate-700\" aria-hidden=\"true\"></span>\n            </dd>\n          </div>\n        }\n      }\n      @for (metric of metrics() ?? []; track metric.label) {\n        <div class=\"scoular-card cws:px-4 cws:py-3\">\n          <dt class=\"cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.label }}</dt>\n\n          <dd\n            class=\"cws:mt-1 cws:text-2xl cws:font-semibold cws:tabular-nums\"\n            [class]=\"\n              metric.urgent\n                ? 'cws:text-amber-700 cws:dark:text-amber-400'\n                : 'cws:text-slate-900 cws:dark:text-white'\n            \"\n          >\n            {{ metric.value }}\n          </dd>\n\n          <!-- A second `<dd>`, not a `<p>`: a `<div>` in a `<dl>` holds only `<dt>`/`<dd>` (#764). -->\n          <dd class=\"cws:mt-0.5 cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">{{ metric.hint }}</dd>\n        </div>\n      }\n    </dl>\n  }\n\n  <!--\n    Filter bar (02a §6.1): a wide free-text search, then the status the request is scoped to.\n\n    🔴 The \"Filters\" dropdown that stood here is gone (JFrisbie, 2026-09-10, to a screenshot). The\n    filter now lives **inline below this bar** as chips plus an editor row, because a filter you can\n    only see by opening something is a filter people forget is applied — and an empty grid with a\n    hidden filter behind it is the single most confusing state this screen can be in.\n  -->\n  <cms-grid-toolbar>\n    <!--\n      `flex-1` with a floor and a ceiling: search is the control on this bar people use most, so it\n      takes the free space rather than sitting at input default width. The max stops it stretching to\n      an unreadable line length on a wide monitor.\n    -->\n    <label class=\"cws:flex cws:min-w-64 cws:flex-1 cws:flex-col cws:gap-1 cws:text-sm cws:sm:max-w-2xl\">\n      <span class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-300\">Search</span>\n      <!--\n        🔴 `[value]` is bound to `searchTerm()`, NOT to `query().search`.\n\n        `query()` deliberately blanks `search` — the term is applied across every column here rather\n        than sent to a server that matches three — so binding the box to the query would render it\n        permanently empty: you could type, the grid would filter, and the text would vanish. Caught\n        by a test asserting the box reflects a term restored from the URL.\n      -->\n      <!--\n        ⚠ The placeholder named four fields and the search has never been limited to four:\n        `matchesSearch` tests **every column the grid renders** (`columns.some(...)`). The wording\n        was inherited from the server-side search it replaced, which does match three — so the box\n        had been under-claiming its own behaviour, which is the #196 class of defect with the sign\n        flipped.\n      -->\n      <input\n        type=\"search\"\n        cmsSearchShortcut\n        class=\"scoular-form-input cws:w-full\"\n        placeholder=\"Search every column\"\n        [value]=\"searchTerm()\"\n        (input)=\"search($any($event.target).value)\"\n      />\n    </label>\n\n    <!--\n      `scoular-btn` without `-sm`, so the box model matches `scoular-form-input` exactly: both are\n      `px-4 py-2 text-sm` with a 1px border, which is what makes the three controls the same height\n      without a hard-coded pixel value that would drift when the design system changes its padding.\n    -->\n    <!--\n      The view selector, where the Status dropdown used to be (JFrisbie, 2026-09-10).\n\n      🔴 **Status is deliberately no longer selectable, and the consequence is real.** It selected\n      which CTRM *procedure* the request reached — `open`/`closed` are `OpenDS`, `unapproved` is a\n      different one returning `dsCon` — so removing the control does not narrow a filter, it fixes\n      the request to **open** contracts. Closed and unapproved are unreachable from this screen\n      until a control returns. Raised and accepted; `query().status` still carries the value, the URL\n      still round-trips it, and the request still sends it, so restoring the control is a template\n      change rather than a rebuild.\n\n      ⚠ Which is also why the baseline is called **\"All Open Contracts\"** rather than \"All\n      Contracts\": `contract/list` has no all-statuses option and refuses the call, so a bare \"All\"\n      would claim more than the grid can show — the defect #196 is open about. Since #841 the label\n      names whichever status the URL chose (\"All Closed Contracts\" on `?status=Closed`). Since 2026-10-23 it is \"All Contracts\" whatever the status (JFrisbie); the first card still names the status.\n\n      Width lives here rather than on the control: `.scoular-form-input` is `@apply w-full` and the\n      design system compiles unlayered, so a `w-*` on the button itself would lose. Seventh instance.\n    \n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\n    shapes has a second justification that has nothing to do with layers. See the header of the\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\n    the shell, so an embedded host may still supply the old cascade.\n    -->\n    <div class=\"cws:w-56\">\n      <cms-filter-select\n        [scope]=\"savedFilterScope\"\n        [filter]=\"filter()\"\n        [sorts]=\"sorts()\"\n        [baselineLabel]=\"baselineLabel()\"\n        [columnLayout]=\"savedViewColumnLayout()\"\n        (viewChange)=\"onViewChange($event)\"\n      />\n    </div>\n\n    <!--\n      \"+ Add filter\", beside the view selector rather than on a row of its own (JFrisbie,\n      2026-09-10, to a screenshot).\n\n      🔴 **The button is here and the editor it opens is still the builder's.** It calls\n      `builder.beginAdd()` through the template reference below, so the editor's open/closed state\n      keeps exactly one owner. Lifting that state up here would mean this button had to know that\n      committing a rule closes the editor and that clicking a chip re-opens it — two components\n      sharing one flag, which is how they end up disagreeing.\n\n      `items-end` on the row aligns it with the bottom of the two labelled controls beside it, so all\n      three sit on one baseline despite only two having captions.\n    -->\n    <button\n      type=\"button\"\n      class=\"scoular-btn scoular-btn-outline\"\n      (click)=\"builder.beginAdd()\"\n    >\n      + Add filter\n    </button>\n\n\n    <!--\n      Clear sort, beside Add filter and only while there is a sort to clear.\n\n      Shared with both work queues as `cms-clear-sort-button`. It carries the reasoning that used\n      to live here: rendered conditionally rather than shipped disabled, and a badge whose `h-5` is\n      what keeps the button the same height as its neighbours once a count appears.\n\n      No `defaultSorts` here, so clearing means no sort at all -- this grid arrives in the order the\n      server sent it. The queues pass their own arrival ordering instead.\n    -->\n    <cms-clear-sort-button [sorts]=\"sorts()\" (clear)=\"onSortChange($event)\" />\n\n    <!--\n      Export, on the same row as search and filters but pushed hard right by `ml-auto`.\n\n      Right-aligned rather than next to the filters because it acts on the *result* of everything to\n      its left — reading order is narrow, then narrow, then take what you have. `ml-auto` rather than\n      a spacer element so it still sits correctly when the bar wraps on a narrow viewport.\n    -->\n    <!--\n      Columns, pushed right with the export it shapes (F4.1a, #748): show, hide and reorder within what\n      the trade unit allows. The export then starts from what this leaves visible (docs/02 §8).\n    -->\n    <cms-grid-column-menu\n      class=\"cws:ml-auto\"\n      [fields]=\"columnMenuFields()\"\n      [lockedKeys]=\"lockedColumnKeys\"\n      [keptIn]=\"columnsKeptIn()\"\n      [failure]=\"columnsFailure()\"\n      (fieldsChange)=\"onColumnsChange($event)\"\n      (reset)=\"onColumnsReset()\"\n    />\n\n    <!-- The export's own columns (#768): the grid's, plus Customer name beside Customer ID. -->\n    <cms-grid-export\n      [columns]=\"exportColumns\"\n      [visibleKeys]=\"exportVisibleKeys()\"\n      [pageRows]=\"rows()\"\n      [totalCount]=\"page()?.totalCount ?? 0\"\n      [allRows]=\"exportAllRows\"\n      [filename]=\"exportFilename\"\n      [disabled]=\"isEmpty()\"\n      [serverExport]=\"serverExport\"\n      (failed)=\"onExportFailed($event)\"\n      (completed)=\"onExportCompleted($event)\"\n    />\n\n    <!--\n      Refresh, between Export and the pager (JFrisbie, 2026-09-03).\n\n      It re-issues the SAME query, so filters, sort and the current page all survive — see\n      `refresh()`. That is the whole point of it sitting here rather than being a link back to an\n      unfiltered workspace.\n\n      ⚠ **It is not guaranteed to re-read CTRM.** The BFF caches the contract list for 60s per\n      caller and scope (`Ctrm:ContractListCacheTtl`), and exposes no way for a client to ask it not\n      to — so inside that window this returns the same rows it already had. The button is still\n      honest about what it does (re-ask the server) and the cache is doing what it was built for;\n      it just means \"refresh\" is not a promise of freshness until the API offers a bypass. Raised for\n      the backend lane rather than worked around here, because a cache-busting parameter the server\n      ignores would be worse than no button.\n    -->\n    <cms-refresh-button\n      label=\"Refresh contracts\"\n      [busy]=\"isRefreshing()\"\n      [disabled]=\"needsScope()\"\n      (refresh)=\"refresh()\"\n    />\n\n    <!--\n      A second pager, so advancing a page does not mean scrolling to the bottom of 50 rows first.\n      Same component as the footer's, not a copy — two hand-written copies drift, and one gains a\n      disabled state or a label the other does not.\n    -->\n    <cms-pager\n      [page]=\"displayPage()\"\n      [totalPages]=\"displayTotalPages()\"\n      position=\"top\"\n      (goTo)=\"goToPage($event)\"\n    />\n  </cms-grid-toolbar>\n\n  <!--\n    The filter, inline and always visible — chips for what is applied, an editor row for building\n    the next rule.\n\n    🔴 Below the toolbar rather than inside a dropdown, which is the substance of the redesign. The\n    chips are the answer to \"why is this grid showing so little\", and that question is asked *while\n    looking at the grid* — so the answer has to be on the page rather than one click away.\n  -->\n  <!--\n    ⚠ `#builder` is read by the \"+ Add filter\" button on the toolbar above, and\n    `[showAddButton]=\"false\"` is what stops a second one rendering here. The two go together — drop\n    either and the screen has no way to open the editor, or two ways in two places.\n\n    The component renders **nothing at all** when there are no rules and the editor is closed, which\n    is why removing its own button leaves no empty band above the grid.\n  -->\n  <cms-filter-builder\n    #builder\n    [columns]=\"columns\"\n    [filter]=\"filter()\"\n    [showAddButton]=\"false\"\n    (filterChange)=\"onFilterChange($event)\"\n  />\n\n  @if (exportError(); as error) {\n    <div class=\"scoular-alert scoular-alert-error\" role=\"alert\">\n      <div class=\"scoular-alert-description\">{{ error }}</div>\n    </div>\n  }\n\n  <!--\n    Which path wrote the last export (F4.3c). Beside the export failure and for the same reason:\n    it is the outcome of something the user just did, so it belongs by the control rather than in\n    the collapsible notices panel. Shown after every export, not only after a fallback — a note\n    that appeared only when something went sideways would leave the ordinary case unexplained.\n  -->\n  @if (exportOutcome(); as outcome) {\n    <div class=\"scoular-alert scoular-alert-info\" role=\"status\" aria-label=\"Export result\">\n      <div class=\"scoular-alert-description\">\n        @if (outcome.ran === 'server') {\n          Exported {{ outcome.rows }} rows by the server.\n          @if (serverExportCompleteness(); as completeness) {\n            {{ completeness }}\n          }\n        } @else if (outcome.reason) {\n          Exported {{ outcome.rows }} rows from this screen. {{ outcome.reason }}\n        } @else {\n          Exported {{ outcome.rows }} rows from this screen, as shown.\n        }\n      </div>\n    </div>\n  }\n\n  <cms-async-container\n    [data]=\"state()\"\n    [empty]=\"isEmpty()\"\n    [emptyMessage]=\"emptyMessage()\"\n    loadingLabel=\"Loading contracts\"\n    (retry)=\"retry()\"\n  >\n    <!--\n      `trackBy` on the contract NUMBER rather than the row object is what makes `focusKey` able to match\n      at all: returning from the detail screen re-fetches, so the object for a given contract is a\n      different one than the row the user left, and object identity would never match.\n    -->\n    <!--\n      🔴 **Striped WITH tones, which the grid's own remarks warn against — measured before doing it**\n      (JFrisbie, 2026-09-15). This is the only grid that declares a `rowTone`, and the standing rule\n      was that a toned grid must not stripe, because a shaded row could then mean \"rejected\" or just\n      \"even\".\n\n      ✅ **The mechanism was never the risk.** `rowClassFor` emits the stripe only when the tone is\n      empty, so a tinted row keeps its tint — the two cannot fight, and a toned row is simply never\n      striped.\n\n      🔑 **What settled the ambiguity is that the cues separate by HUE, not by lightness.** Composited\n      over white and measured in Edge: the stripe lands on `rgb(250, 251, 253)` — cool, blue-leaning —\n      while `negative` is `rgb(254, 248, 246)` and `caution` is `rgb(255, 253, 242)`, both warm. The\n      tone-versus-stripe separations (9 and 12) are *larger* than the stripe-versus-plain one (7), so\n      a tinted row does not read as a striped one. Dark mode is more comfortable still: tones sit 25–28\n      from the stripe against its 11 from plain.\n\n      ⚠ **The residual, stated rather than smoothed over: in light mode every one of these washes is\n      faint**, so the distinction rests on hue. That is acceptable here only because the tint was never\n      the carrier — the 2026-09-03 tuning pass that softened these deliberately describes the tint as a\n      hint that \"competed with the status pill that says the same thing in words\". **The pill is the\n      answer for anyone who cannot separate the hues**, and it is in every toned row. 🔴 Do not\n      strengthen the tints to widen the gap: that pass softened them for a reason.\n\n      ⚠ **The zebra rhythm is irregular here and that is inherent**, not a defect — a tone displaces a\n      stripe, so with roughly a third of rows unapproved the alternation breaks wherever a tinted row\n      sits. Judged acceptable from a rendered 12-row sample at that ratio.\n    -->\n    <!-- The VISIBLE columns (F4.1a, #748); search, filters and sorting still read every column. -->\n    <cms-data-grid\n      [rows]=\"rows()\"\n      [columns]=\"visibleColumns()\"\n      [columnMenu]=\"false\"\n      label=\"Contracts\"\n      [striped]=\"true\"\n      [sorts]=\"sorts()\"\n      [rowTone]=\"rowTone\"\n      [actions]=\"rowActions()\"\n      [rowLabel]=\"trackByContract\"\n      [trackBy]=\"trackByContract\"\n      [focusKey]=\"focusKey()\"\n      (sortChange)=\"onSortChange($event)\"\n      activateLabel=\"Open\"\n      (rowActivate)=\"onRowActivate($event)\"\n      (pageStep)=\"stepPage($event)\"\n    />\n\n    <footer class=\"cws:flex cws:flex-wrap cws:items-center cws:justify-between cws:gap-3 cws:pt-3\">\n      <div class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\n        <p>{{ rangeLabel() }}</p>\n        <!--\n          Every column is sortable now, but the server still has no sort parameter, so the sort is\n          applied to the current page only. On a multi-page result that is a materially different\n          thing from sorting the result set, and a trader looking for the highest price would\n          otherwise get the highest price on page 1 with no reason to doubt it.\n        -->\n        @if (sortScopeNote(); as note) {\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">{{ note }}</p>\n        }\n\n        <!--\n          🔴 What the filter was applied to. This is the honest half of client-side filtering and it\n          is not optional.\n\n          A rule can only match rows that arrived, so on a trade unit with more contracts than one\n          page holds, \"12 matches\" is a claim about what was read and not about the trade unit. A\n          filter builder that presented the first number as the second would be the\n          complete-looking-but-incomplete answer this project keeps recording — the same shape as\n          CR-4 (#31) on the CTRM side.\n\n          Shown only while filtering locally and only when the server held rows back, so an ordinary\n          filtered view of a small trade unit says nothing extra.\n        -->\n        @if (filterIsPartial()) {\n          <p class=\"cws:mt-0.5 cws:text-xs cws:text-amber-700 cws:dark:text-amber-400\">\n            Matched against the {{ fetchedCount() }} contracts loaded, of\n            {{ page()?.totalCount ?? 0 }} in this trade unit — there may be more matches than are\n            listed.\n          </p>\n        }\n      </div>\n\n      <cms-pager\n        [page]=\"displayPage()\"\n        [totalPages]=\"displayTotalPages()\"\n        position=\"bottom\"\n        (goTo)=\"goToPage($event)\"\n      />\n    </footer>\n\n    <!--\n      The \"Opening SC1240000 — the contract view is F4.1b\" placeholder was here. It has been replaced\n      by real navigation to `/contracts/{number}` (2026-08-27), so there is nothing to stand in for.\n    -->\n    <!--\n      No primary action here any more: the trade-unit control lives in the shell top bar, and a\n      feature library reaching out to focus a shell control would be the wrong direction of\n      dependency. The message names where to go instead.\n    -->\n  </cms-async-container>\n</section>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { layoutRoot: [{
		type: i0.ViewChild,
		args: ["layoutRoot", { isSignal: true }]
	}] }
});
function emptyPage(query) {
	return {
		rows: [],
		totalCount: 0,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: 1,
		dataOrigin: "Simulated",
		filteredInProcess: false,
		rowCapReached: null,
		rowCap: null,
		warnings: []
	};
}
export { HomePageComponent };

//# sourceMappingURL=cws-features-home.mjs.map
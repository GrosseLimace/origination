import { ControlPattern, DynamicFieldComponent, FormBuilderService } from "@cws/shared-form-engine";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Injectable, InjectionToken, computed, inject, input, output, signal } from "@angular/core";
import { Subject, catchError, combineLatest, delay, from, map, of, shareReplay, startWith, tap } from "rxjs";
import { HttpClient, HttpErrorResponse, HttpParams } from "@angular/common/http";
import { takeUntilDestroyed, toSignal } from "@angular/core/rxjs-interop";
import { EMPTY_FILTER, applyExportFields, compareBySorts, isRuleNode, remoteError, remoteLoaded, remoteLoading, toCsv } from "@cws/shared-ui";
import { NgTemplateOutlet } from "@angular/common";
import * as i1 from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { CdkConnectedOverlay, CdkOverlayOrigin, Overlay } from "@angular/cdk/overlay";
import { TRADE_UNIT_CONTEXT } from "@cws/core-state";
import { ProblemKind, parseProblem, problemFrom } from "@cws/core-http";
const CONTRACT_CODE_PREFIX_LABELS = {
	BI: "Billing instructions",
	CT: "Contract type",
	CU: "Transportation unit type",
	DE: "Domestic/export",
	FA: "Special type",
	GG: "Grades to govern",
	GR: "Governing trade rule",
	GT: "Grade",
	PD: "Premium/discount scale",
	PS: "Price type",
	PT: "Payment terms",
	PZ: "Position zone",
	RC: "Routing",
	ST: "Ship period type",
	TC: "Transportation type",
	UM: "Unit of measure",
	WG: "Weights to govern"
};
const CONTRACT_CODE_PREFIXES = [
	"BI",
	"CT",
	"CU",
	"DE",
	"FA",
	"GG",
	"GR",
	"GT",
	"PD",
	"PS",
	"PT",
	"PZ",
	"RC",
	"ST",
	"TC",
	"UM",
	"WG"
];
const CONTRACT_TABS = [
	{
		id: "contract",
		label: "Contract Info"
	},
	{
		id: "pricing",
		label: "Pricing & Quantity"
	},
	{
		id: "shipping",
		label: "Shipping Info"
	},
	{
		id: "remarks",
		label: "Remarks"
	},
	{
		id: "additional",
		label: "Additional fields"
	}
];
const LOG_TAB = {
	id: "log",
	label: "Log"
};
const DOCUMENTS_TAB = {
	id: "documents",
	label: "Documents"
};
function toContractTabId(value) {
	if (value === LOG_TAB.id) return LOG_TAB.id;
	if (value === DOCUMENTS_TAB.id) return DOCUMENTS_TAB.id;
	return CONTRACT_TABS.some((tab) => tab.id === value) ? value : "contract";
}
const CONTRACT_LAYOUT_SECTIONS = [
	{
		id: "identity",
		tab: "contract",
		title: "Contract",
		fields: [
			{
				componentName: "ContractPrefixType",
				ctrmField: "contract_prefix_type",
				groupHeading: "Contract number",
				label: "Contract number prefix — type",
				labelHidden: true,
				controlPattern: ControlPattern.TextWithCounter,
				half: true,
				note: "Character 1 of the contract key — the sale/purchase prefix."
			},
			{
				componentName: "ContractPrefixCommodity",
				ctrmField: "contract_prefix_commodity",
				label: "Contract number prefix — commodity",
				labelHidden: true,
				controlPattern: ControlPattern.TextWithCounter,
				half: true,
				note: "Character 2 of the key — the commodity’s CAK group code (C for YELLOW CORN). Typed for now; it should derive from the commodity (C-16)."
			},
			{
				componentName: "ContractNumber",
				ctrmField: "contract_number",
				label: "Contract number",
				labelHidden: true,
				controlPattern: ControlPattern.TextWithCounter,
				note: "The 7-character number only, not the whole key. Issued automatically once the two prefixes above are set, where the trade unit has that enabled — and always editable, so your own format can replace it."
			},
			{
				componentName: "ContractSuffix",
				ctrmField: "contract_suffix",
				label: "Contract number suffix",
				controlPattern: ControlPattern.TextWithCounter,
				note: "Character 10 of the key, and usually empty."
			},
			{
				componentName: "ContractDate",
				ctrmField: "contract_date",
				label: "Contract date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			},
			{
				componentName: "Location",
				ctrmField: "location",
				label: "Trade unit",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Locations"
			},
			{
				componentName: "CommodityCode",
				ctrmField: "commodity_code",
				label: "Commodity",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Commodities"
			},
			{
				componentName: "TraderInitials",
				ctrmField: "trader_initials",
				label: "Trader",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives the trader’s name from these initials; the name itself is not sent on a write."
			},
			{
				componentName: "AlternateAddressLocation",
				ctrmField: "alternate_address_location",
				label: "Alternate address location",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TextCode",
				ctrmField: "text_code",
				label: "Text code",
				controlPattern: ControlPattern.QuantityDecimal
			},
			{
				componentName: "LanguageCode",
				ctrmField: "language_code",
				label: "Language code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM has no callable reference route for this code yet, so it is typed rather than picked. An empty combo would be a closed list of nothing."
			},
			{
				componentName: "ContractCommodityDescription",
				ctrmField: "contract_commodity_description",
				label: "Contract commodity description",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives this from its paired code. What you type here may be discarded on save — send the code, not the words."
			},
			{
				componentName: "ContractTypeCode",
				ctrmField: "contract_type_code",
				label: "Contract type code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:CT"
			},
			{
				componentName: "SpecialType",
				ctrmField: "special_type",
				label: "Special type",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:FA"
			},
			{
				componentName: "DomesticExportCode",
				ctrmField: "domestic_export_code",
				label: "Domestic export code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:DE"
			},
			{
				componentName: "QuoteId",
				ctrmField: "quote_id",
				label: "Quote id",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "ContractStyle",
				ctrmField: "contract_style",
				label: "Contract style",
				controlPattern: ControlPattern.TextWithCounter
			}
		]
	},
	{
		id: "customer",
		tab: "contract",
		title: "Customer",
		fields: [
			{
				componentName: "CustomerId",
				ctrmField: "customer_id",
				label: "Customer id",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "CustomerName",
				ctrmField: "customer_name",
				label: "Customer name",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				emptyNote: "Filled in from the customer directory when a customer id is entered"
			},
			{
				componentName: "CustomerContract",
				ctrmField: "customer_contract",
				label: "Customer contract",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "CustomerMerchant",
				ctrmField: "customer_merchant",
				label: "Customer merchant",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PaymentTermsCode",
				ctrmField: "payment_terms_code",
				label: "Payment terms",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PT",
				descriptionField: "payment_terms_description",
				note: "Code list needs the parameterised reference route."
			},
			{
				componentName: "AdvisingBankNumber",
				ctrmField: "advising_bank_number",
				label: "Advising bank number",
				controlPattern: ControlPattern.QuantityDecimal
			}
		]
	},
	{
		id: "pricing",
		tab: "pricing",
		title: "Pricing",
		description: "Header prices. Individual price sequences are added after the contract exists.",
		fields: [
			{
				componentName: "PriceTypeCode",
				ctrmField: "price_type_code",
				label: "Price type",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PS"
			},
			{
				componentName: "Price",
				ctrmField: "price",
				label: "Price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "BasisPrice",
				ctrmField: "basis_price",
				label: "Basis price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "HedgePrice",
				ctrmField: "hedge_price",
				label: "Hedge price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "FreightAdjustment",
				ctrmField: "freight_adj",
				label: "Freight adjustment",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "BasisMarketMonth",
				ctrmField: "price_market_month",
				label: "Basis market month",
				controlPattern: ControlPattern.TextWithCounter,
				note: "Month list needs the parameterised reference route."
			},
			{
				componentName: "HedgeMarketMonth",
				ctrmField: "hedge_market_month",
				label: "Hedge market month",
				controlPattern: ControlPattern.TextWithCounter,
				note: "Month list needs the parameterised reference route."
			},
			{
				componentName: "ContractCurrency",
				ctrmField: "contract_currency",
				label: "Currency",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "MarketZone",
				ctrmField: "market_zone",
				label: "Market zone",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "MarketZones"
			},
			{
				componentName: "BasisLocation",
				ctrmField: "basis_location",
				label: "Basis location",
				controlPattern: ControlPattern.TextWithCounter,
				wide: true
			},
			{
				componentName: "PriceMarketCode",
				ctrmField: "price_market_code",
				label: "Price market code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM has no callable reference route for this code yet, so it is typed rather than picked. An empty combo would be a closed list of nothing."
			},
			{
				componentName: "HedgeMarketCode",
				ctrmField: "hedge_market_code",
				label: "Hedge market code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM has no callable reference route for this code yet, so it is typed rather than picked. An empty combo would be a closed list of nothing."
			},
			{
				componentName: "BrokerCurrency",
				ctrmField: "broker_currency",
				label: "Broker currency",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PremiumDiscountScaleCode",
				ctrmField: "premium_discount_scale_code",
				label: "Premium discount scale code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PD"
			},
			{
				componentName: "PremiumDiscountDescription",
				ctrmField: "premium_discount_description",
				label: "Premium discount description",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives this from its paired code. What you type here may be discarded on save — send the code, not the words."
			},
			{
				componentName: "IowaPriceLaterFlag",
				ctrmField: "iowa_price_later_flag",
				label: "Iowa price later flag",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			},
			{
				componentName: "IowaExerciseDate",
				ctrmField: "iowa_exercise_date",
				label: "Iowa exercise date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "quantity",
		tab: "pricing",
		title: "Quantity",
		fields: [
			{
				componentName: "Quantity",
				ctrmField: "quantity",
				label: "Quantity",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "quantity"
			},
			{
				componentName: "QuantityUnitOfMeasure",
				ctrmField: "quantity_uom",
				label: "Unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			},
			{
				componentName: "PriceUnitOfMeasure",
				ctrmField: "price_uom",
				label: "Price unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			},
			{
				componentName: "FreightAdjustmentUnitOfMeasure",
				ctrmField: "freight_adj_uom",
				label: "Freight adj. unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			},
			{
				componentName: "DescriptiveQuantity",
				ctrmField: "descriptive_quantity",
				label: "Descriptive quantity",
				controlPattern: ControlPattern.TextWithCounter,
				wide: true
			},
			{
				componentName: "NumberOfLoads",
				ctrmField: "number_of_loads",
				label: "Number of loads",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "WeightsToGovernCode",
				ctrmField: "weights_to_govern_code",
				label: "Weights to govern code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:WG",
				descriptionField: "weights_to_govern_description"
			},
			{
				componentName: "MaximumWeight",
				ctrmField: "maximum_weight",
				label: "Maximum weight",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "quantity"
			},
			{
				componentName: "MaximumWeightUom",
				ctrmField: "maximum_weight_uom",
				label: "Maximum weight unit of measure",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TolerenceMore",
				ctrmField: "tolerence_more",
				label: "Tolerance more",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "TolerenceLess",
				ctrmField: "tolerence_less",
				label: "Tolerance less",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			}
		]
	},
	{
		id: "logistics",
		tab: "shipping",
		title: "Shipping and logistics",
		gap: "Shipment dates are per ship period, and ship periods are a collection this screen does not carry yet — up to 12 of them, each with its own begin, end, late pickup and early delivery.",
		fields: [
			{
				componentName: "OriginCode",
				ctrmField: "origin_code",
				label: "Origin code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "Code list needs the parameterised reference route."
			},
			{
				componentName: "OriginName",
				ctrmField: "origin_name",
				label: "Origin",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				note: "Derived by CTRM from the origin code above, and not sent on a write."
			},
			{
				componentName: "DestinationCode",
				ctrmField: "destination_code",
				label: "Destination code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "Code list needs the parameterised reference route."
			},
			{
				componentName: "DestinationName",
				ctrmField: "destination_name",
				label: "Destination",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				note: "Derived by CTRM from the destination code above, and not sent on a write."
			},
			{
				componentName: "LatestShipmentDate",
				ctrmField: "latest_shipment_date",
				label: "Latest shipment date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			},
			{
				componentName: "ShipPeriodTypeCode",
				ctrmField: "ship_period_type_code",
				label: "Ship period type",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:ST"
			},
			{
				componentName: "ShipPeriodDescription",
				ctrmField: "ship_period_description",
				label: "Ship period description",
				controlPattern: ControlPattern.MultilineNote,
				wide: true
			},
			{
				componentName: "IncoTermsCode",
				ctrmField: "inco_terms_code",
				label: "Incoterms",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "IncoTermsDescription",
				ctrmField: "inco_terms_description",
				label: "Incoterms description",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				wide: true,
				note: "Derived by CTRM from the Incoterms code above, and not sent on a write."
			},
			{
				componentName: "NamedPlaceCode",
				ctrmField: "named_place_code",
				label: "Named place code",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "NamedPlace",
				ctrmField: "named_place",
				label: "Named place",
				controlPattern: ControlPattern.TextWithCounter,
				readOnly: true,
				wide: true,
				note: "Derived by CTRM from the named place code above, and not sent on a write."
			},
			{
				componentName: "PositionZoneCode",
				ctrmField: "position_zone_code",
				label: "Position zone code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:PZ"
			},
			{
				componentName: "TransportationTypeCode",
				ctrmField: "transportation_type_code",
				label: "Transportation type code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:TC"
			},
			{
				componentName: "TransportationUnits",
				ctrmField: "transportation_units",
				label: "Transportation units",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "TransportationUnitTypeCode",
				ctrmField: "transportation_unit_type_code",
				label: "Transportation unit type code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:CU"
			},
			{
				componentName: "RoutingCode",
				ctrmField: "routing_code",
				label: "Routing code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:RC",
				descriptionField: "routing_description"
			},
			{
				componentName: "PrintInco",
				ctrmField: "print_inco",
				label: "Print inco",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PartialShipmentAllowed",
				ctrmField: "partial_shipment_allowed",
				label: "Partial shipment allowed",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TransshipmentAllowed",
				ctrmField: "transshipment_allowed",
				label: "Transshipment allowed",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "TransportationModeNumber",
				ctrmField: "transportation_mode_number",
				label: "Transportation mode number",
				controlPattern: ControlPattern.QuantityDecimal
			},
			{
				componentName: "EquipmentConstraint",
				ctrmField: "equipment_constraint",
				label: "Equipment constraint",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "FreeTime",
				ctrmField: "free_time",
				label: "Free time",
				controlPattern: ControlPattern.TextWithCounter,
				kind: "number"
			},
			{
				componentName: "OtmDomain",
				ctrmField: "otm_domain",
				label: "OTM domain",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "RampCode1",
				ctrmField: "ramp_code_1",
				label: "Ramp code 1",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "RampCode2",
				ctrmField: "ramp_code_2",
				label: "Ramp code 2",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "RampCode3",
				ctrmField: "ramp_code_3",
				label: "Ramp code 3",
				controlPattern: ControlPattern.TextWithCounter
			}
		]
	},
	{
		id: "broker",
		tab: "contract",
		title: "Broker",
		description: "All four or none — a half-filled broker block is a commission that cannot be settled.",
		fields: [
			{
				componentName: "BrokerId",
				ctrmField: "broker_id",
				label: "Broker id",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "BrokerContract",
				ctrmField: "broker_contract",
				label: "Broker contract",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "BrokerRate",
				ctrmField: "broker_rate",
				label: "Broker rate",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "BrokerUnitOfMeasure",
				ctrmField: "broker_uom",
				label: "Broker unit of measure",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:UM"
			}
		]
	},
	{
		id: "quality",
		tab: "contract",
		title: "Quality and grading",
		fields: [
			{
				componentName: "GradeCode",
				ctrmField: "grade_code",
				label: "Grade code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:GT"
			},
			{
				componentName: "GradesToGovernCode",
				ctrmField: "grades_to_govern_code",
				label: "Grades to govern code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:GG",
				descriptionField: "grades_to_govern_description"
			},
			{
				componentName: "FoodForHumanConsumption",
				ctrmField: "food_for_human_consumption",
				label: "Food for human consumption",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "GmoCertificateQty",
				ctrmField: "gmo_certificate_qty",
				label: "GMO certificate quantity",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "quantity"
			}
		]
	},
	{
		id: "settlement",
		tab: "shipping",
		title: "Payment and billing",
		fields: [
			{
				componentName: "BillingInstructionsCode",
				ctrmField: "billing_instructions_code",
				label: "Billing instructions code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:BI",
				descriptionField: "billing_instructions_description"
			},
			{
				componentName: "FreightPaymentCode",
				ctrmField: "freight_payment_code",
				label: "Freight payment code",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM has no callable reference route for this code yet, so it is typed rather than picked. An empty combo would be a closed list of nothing."
			},
			{
				componentName: "FreightPaymentTerms",
				ctrmField: "freight_payment_terms",
				label: "Freight payment terms",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "LetterOfCreditOpen",
				ctrmField: "letter_of_credit_open",
				label: "Letter of credit open",
				controlPattern: ControlPattern.TextWithCounter,
				kind: "date"
			},
			{
				componentName: "LetterOfCreditExpiration",
				ctrmField: "letter_of_credit_expiration",
				label: "Letter of credit expiration",
				controlPattern: ControlPattern.TextWithCounter,
				kind: "date"
			}
		]
	},
	{
		id: "packaging",
		tab: "shipping",
		title: "Packaging",
		fields: [
			{
				componentName: "PackageDescription",
				ctrmField: "package_description",
				label: "Package description",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives this from its paired code. What you type here may be discarded on save — send the code, not the words."
			},
			{
				componentName: "PackagingNumber",
				ctrmField: "packaging_number",
				label: "Packaging number",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "number"
			},
			{
				componentName: "PackagingUom",
				ctrmField: "packaging_uom",
				label: "Packaging unit of measure",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PackagingDescription",
				ctrmField: "packaging_description",
				label: "Packaging description",
				controlPattern: ControlPattern.TextWithCounter,
				note: "CTRM derives this from its paired code. What you type here may be discarded on save — send the code, not the words."
			}
		]
	},
	{
		id: "terms",
		tab: "additional",
		title: "Trade terms and options",
		fields: [
			{
				componentName: "GoverningTradeRuleCode",
				ctrmField: "governing_trade_rule_code",
				label: "Governing trade rule code",
				controlPattern: ControlPattern.SearchableCodeCombo,
				referenceSet: "Codes:GR",
				descriptionField: "governing_trade_rule_description"
			},
			{
				componentName: "AutoRelease",
				ctrmField: "auto_release",
				label: "Auto release",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "PurchasedForInventory",
				ctrmField: "purchased_for_inventory",
				label: "Purchased for inventory",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "ImexCertificate",
				ctrmField: "imex_certificate",
				label: "IMEX certificate",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "OfferToPurchaseExpireDate",
				ctrmField: "offer_to_purchase_expire_date",
				label: "Offer to purchase expire date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			},
			{
				componentName: "ProvisionalDate",
				ctrmField: "provisional_date",
				label: "Provisional date",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "other",
		tab: "additional",
		title: "Additional CTRM fields",
		gap: "Fields the CTRM contract structure accepts that no business rule names. They are here because the write surface is 108 fields and a form that silently carried 90 of them would look complete; grouping them apart is the honest alternative to inventing a home for each. The grouping is not yet confirmed by the business.",
		fields: [
			{
				componentName: "BuyersEquipment",
				ctrmField: "buyers_equipment",
				label: "Buyers equipment",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			},
			{
				componentName: "AddFuel",
				ctrmField: "add_fuel",
				label: "Add fuel",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			},
			{
				componentName: "AddFreight",
				ctrmField: "add_freight",
				label: "Add freight",
				controlPattern: ControlPattern.ToggleFlag,
				note: "A CTRM Y/N character flag. Y and N are the values observed on an accepted write."
			}
		]
	}
];
const CONTRACT_LAYOUT_FIELDS = CONTRACT_LAYOUT_SECTIONS.flatMap((section) => section.fields);
const CONTRACT_WRITABLE_FIELDS = CONTRACT_LAYOUT_FIELDS.filter((field) => field.readOnly !== true);
const CONTRACT_READ_ONLY_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.readOnly === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_EMPTY_NOTES = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.emptyNote !== void 0).map((field) => [field.componentName, field.emptyNote]));
const CONTRACT_LAYOUT_FIELD_NOTES = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.note !== void 0).map((field) => [field.componentName, field.note]));
const CONTRACT_LAYOUT_SECTION_NOTES = Object.fromEntries(CONTRACT_LAYOUT_SECTIONS.filter((section) => section.gap !== void 0 || section.description !== void 0).map((section) => [section.id, section.gap ?? section.description]));
const CONTRACT_LAYOUT_WIDE_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.wide === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_HALF_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.half === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_GROUP_HEADINGS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.groupHeading !== void 0).map((field) => [field.componentName, field.groupHeading]));
const CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.filter((field) => field.labelHidden === true).map((field) => [field.componentName, true]));
const CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.map((field) => [field.componentName, field.ctrmField]));
const CONTRACT_LAYOUT_CTRM_FIELDS = CONTRACT_LAYOUT_FIELDS.map((field) => field.ctrmField);
const STATIC_ALLOWED_VALUES = { ContractPrefixType: [{
	code: "S",
	description: "Sale"
}, {
	code: "P",
	description: "Purchase"
}] };
function savedCodeDescriptions(values) {
	const saved = /* @__PURE__ */ new Map();
	for (const field of CONTRACT_LAYOUT_FIELDS) {
		if (field.descriptionField === void 0) continue;
		const code = textOf(values[field.ctrmField]);
		const description = textOf(values[field.descriptionField]);
		if (code !== "" && description !== "") saved.set(field.componentName, {
			code,
			description
		});
	}
	return saved;
}
function textOf(value) {
	return typeof value === "string" ? value.trim() : "";
}
function destinationOf(field) {
	return field.destination ?? "ctrm";
}
const FAMILY_B_ADDENDUM_FIELD_SETS = [
	{
		id: "min-price-call",
		title: "Minimum price with a call",
		specialTypes: ["MNC", "MNP"],
		fields: [
			{
				componentName: "AddendumCallExchange",
				cwsField: "addendum_call_exchange",
				destination: "cws",
				label: "Call exchange",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "AddendumCallMonth",
				cwsField: "addendum_call_month",
				destination: "cws",
				label: "Call month",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "AddendumCallStrike",
				cwsField: "addendum_call_strike",
				destination: "cws",
				label: "Call strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumCallPremium",
				cwsField: "addendum_call_premium",
				destination: "cws",
				label: "Call premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumOptionExpiration",
				cwsField: "addendum_option_expiration",
				destination: "cws",
				label: "Option expiration",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "min-max",
		title: "Min/Max",
		specialTypes: ["XPC"],
		fields: [
			{
				componentName: "AddendumPutStrike",
				cwsField: "addendum_put_strike",
				destination: "cws",
				label: "Put strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumPutPremium",
				cwsField: "addendum_put_premium",
				destination: "cws",
				label: "Put premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumMinMaxCallStrike",
				cwsField: "addendum_minmax_call_strike",
				destination: "cws",
				label: "Call strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumMinMaxCallPremium",
				cwsField: "addendum_minmax_call_premium",
				destination: "cws",
				label: "Call premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumNetPremium",
				cwsField: "addendum_net_premium",
				destination: "cws",
				label: "Net premium",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumMinMaxExpiration",
				cwsField: "addendum_minmax_expiration",
				destination: "cws",
				label: "Option expiration",
				controlPattern: ControlPattern.MaskedDate,
				kind: "date"
			}
		]
	},
	{
		id: "premium-advance",
		title: "Premium advance",
		specialTypes: ["PREM"],
		fields: [
			{
				componentName: "AddendumPremiumCallMonth",
				cwsField: "addendum_premium_call_month",
				destination: "cws",
				label: "Call month",
				controlPattern: ControlPattern.TextWithCounter
			},
			{
				componentName: "AddendumPremiumStrike",
				cwsField: "addendum_premium_strike",
				destination: "cws",
				label: "Strike price",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			},
			{
				componentName: "AddendumPremiumReceived",
				cwsField: "addendum_premium_received",
				destination: "cws",
				label: "Premium received",
				controlPattern: ControlPattern.QuantityDecimal,
				kind: "price"
			}
		]
	}
];
function addendumFieldSetFor(specialType) {
	const code = (specialType ?? "").trim();
	if (code === "") return null;
	return FAMILY_B_ADDENDUM_FIELD_SETS.find((set) => set.specialTypes.includes(code)) ?? null;
}
function addendumFieldSetOf(template) {
	let parsed;
	try {
		parsed = JSON.parse(template.fieldMapJson);
	} catch {
		return null;
	}
	if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return null;
	const mapped = Object.values(parsed).filter((value) => typeof value === "string");
	if (mapped.length === 0) return null;
	return FAMILY_B_ADDENDUM_FIELD_SETS.find((candidate) => {
		const names = new Set(candidate.fields.map((field) => field.cwsField));
		return mapped.every((name) => names.has(name));
	})?.id ?? null;
}
const CWS_CONTRACT_FIELDS = FAMILY_B_ADDENDUM_FIELD_SETS.flatMap((set) => set.fields);
function fieldDestinationViolations(input) {
	const violations = [];
	const layoutComponents = new Set(input.layout.map((field) => field.componentName));
	const layoutCtrmFields = new Set(input.layout.flatMap((field) => field.ctrmField === void 0 ? [] : [field.ctrmField]));
	for (const field of input.layout) if (destinationOf(field) !== "ctrm" || field.cwsField !== void 0) violations.push(`Layout row ${field.componentName} is declared as stored by CWS. The contract layout holds CTRM fields only; a CWS field belongs in its own field set.`);
	const seenCwsComponents = /* @__PURE__ */ new Set();
	for (const field of input.cwsFields) {
		const name = field.componentName;
		const stored = (field.cwsField ?? "").trim();
		if (destinationOf(field) !== "cws" || field.ctrmField !== void 0) violations.push(`CWS field ${name} carries a CTRM key or a CTRM destination.`);
		else if (stored === "") violations.push(`CWS field ${name} has no storage name.`);
		else if (input.ctrmFieldNames.has(stored)) violations.push(`CWS field ${name} is stored as "${stored}", which is a CTRM field in constraints.json. A CTRM field must not be re-homed to CWS; fix the CTRM name instead.`);
		else if (layoutCtrmFields.has(stored)) violations.push(`CWS field ${name} is stored as "${stored}", which a contract layout row maps to CTRM.`);
		if (layoutComponents.has(name)) violations.push(`CWS field ${name} shares a component name with a contract layout row, so its value would be read into the CTRM payload.`);
		else if (seenCwsComponents.has(name)) violations.push(`CWS field ${name} is declared twice.`);
		seenCwsComponents.add(name);
	}
	return violations;
}
const ADDENDUM_SIGNATURE_ANCHOR = "{{sig__es_:signer1:signature}}";
const ADDENDUM_DATE_ANCHOR = "{{dte__es_:signer1:date}}";
const ADDENDUM_INITIALS_ANCHOR = "{{Int_es_:signer1:initials}}";
const REFUSED_SIGNATURE_FORM = /sig10__es_/i;
function addendumAnchorProblems(templateContent) {
	const content = templateContent ?? "";
	const problems = [];
	if (REFUSED_SIGNATURE_FORM.test(content)) problems.push(`The template uses the sig10__es_ signature form, which the signing service refuses. Replace it with ${ADDENDUM_SIGNATURE_ANCHOR}.`);
	if (!content.includes("{{sig__es_:signer1:signature}}")) problems.push(`The template has no signature anchor. Add ${ADDENDUM_SIGNATURE_ANCHOR}.`);
	if (!content.includes("{{dte__es_:signer1:date}}")) problems.push(`The template has no signature date anchor. Add ${ADDENDUM_DATE_ANCHOR}.`);
	if (!content.includes("{{Int_es_:signer1:initials}}")) problems.push(`The template has no initials anchor. Add ${ADDENDUM_INITIALS_ANCHOR}.`);
	return problems;
}
const GROUP_TITLES = {
	contract: "Contract",
	additional: "Additional documents",
	attachments: "Attachments",
	addendums: "Addendums",
	other: "Other"
};
const GROUP_ORDER = [
	"contract",
	"additional",
	"attachments",
	"addendums",
	"other"
];
const CONTRACT_ROLES = [
	"draft",
	"approved",
	"confirmed"
];
function hasFirstApproval(documents) {
	return documents.some((document) => document.role === "approved" || document.role === "confirmed");
}
function groupContractDocuments(documents) {
	const approved = hasFirstApproval(documents);
	const buckets = new Map(GROUP_ORDER.map((id) => [id, []]));
	let heldBack = 0;
	for (const document of documents) if (document.provenance === "rjoAddendum") buckets.get("addendums").push(document);
	else if (CONTRACT_ROLES.includes(document.role)) {
		if (approved) buckets.get("contract").push(document);
		else heldBack++;
	} else if (document.role === "additional") buckets.get("additional").push(document);
	else if (document.role === "attachment") buckets.get("attachments").push(document);
	else buckets.get("other").push(document);
	buckets.set("contract", [...buckets.get("contract")].sort(byContractRole));
	buckets.set("additional", [...buckets.get("additional")].sort(byAppearance));
	buckets.set("addendums", [...buckets.get("addendums")].sort(byAppearance));
	return {
		groups: GROUP_ORDER.filter((id) => buckets.get(id).length > 0).map((id) => ({
			id,
			title: GROUP_TITLES[id],
			documents: buckets.get(id)
		})),
		heldBack,
		approved
	};
}
function byContractRole(left, right) {
	return CONTRACT_ROLES.indexOf(left.role) - CONTRACT_ROLES.indexOf(right.role);
}
function byAppearance(left, right) {
	const a = left.appearanceSequence ?? Number.POSITIVE_INFINITY;
	const b = right.appearanceSequence ?? Number.POSITIVE_INFINITY;
	return a === b ? 0 : a < b ? -1 : 1;
}
const CWS_CONTRACT_EVENTS_VERSION = "1.0.0";
var CwsContractEvents = class CwsContractEvents {
	subject = new Subject();
	events$ = this.subject.asObservable();
	emit(event) {
		this.subject.next(event);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: CwsContractEvents,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: CwsContractEvents,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: CwsContractEvents,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const INVALID_PARAM_ALIASES = {};
const COMPONENT_BY_CTRM_FIELD = Object.fromEntries(CONTRACT_LAYOUT_FIELDS.map((field) => [field.ctrmField, field.componentName]));
function looksLikeCtrmFieldName(name) {
	return /^[a-z][a-z0-9_]*$/.test(name);
}
function classifyInvalidParam(name) {
	const aliased = INVALID_PARAM_ALIASES[name] ?? name;
	const componentName = COMPONENT_BY_CTRM_FIELD[aliased];
	if (componentName !== void 0) return {
		kind: "control",
		ctrmField: aliased,
		componentName
	};
	return looksLikeCtrmFieldName(aliased) ? {
		kind: "unrenderedField",
		ctrmField: aliased
	} : {
		kind: "form",
		name
	};
}
function classifyInvalidParams(errors) {
	const controls = [];
	const unrenderedFields = [];
	const formReasons = [];
	for (const [name, reasons] of Object.entries(errors)) {
		const target = classifyInvalidParam(name);
		switch (target.kind) {
			case "control":
				controls.push({
					ctrmField: target.ctrmField,
					componentName: target.componentName,
					reasons
				});
				break;
			case "unrenderedField":
				unrenderedFields.push({
					ctrmField: target.ctrmField,
					reasons
				});
				break;
			case "form": formReasons.push(...reasons.map((reason) => `${target.name}: ${reason}`));
		}
	}
	return {
		controls,
		unrenderedFields,
		formReasons
	};
}
function positionalCode(customerId) {
	return customerId.slice(2, 7).trim();
}
function industryCodeSaysIntercompany(code) {
	return typeof code === "string" && code.toUpperCase().includes("IC");
}
function classifyIntercompany(facts) {
	if (industryCodeSaysIntercompany(facts.customerIndustryCode)) return {
		intercompany: true,
		branch: 1
	};
	const raw = facts.customerId ?? "";
	const code = raw.trim() === "" ? "" : positionalCode(raw);
	const codes = [...facts.locationCodes].map((value) => value.trim()).filter((value) => value !== "");
	if (code === "" || codes.length === 0) return {
		intercompany: false,
		reason: "cannotClassify"
	};
	return codes.includes(code) ? {
		intercompany: true,
		branch: 3
	} : {
		intercompany: false,
		reason: "noMatch"
	};
}
function isIntercompanyPurchase(verdict, contractPrefixType) {
	return verdict.intercompany && contractPrefixType?.trim().toUpperCase() === "P";
}
const CONTRACTS_API_URL = new InjectionToken("CONTRACTS_API_URL");
const REFERENCE_ROUTES = {
	codes: "Codes",
	commodities: "Commodities",
	marketCodes: "MarketCodes",
	marketMonths: "MarketMonths",
	marketZones: "MarketZones"
};
const AVAILABILITY_STATES = [
	"Available",
	"Closed",
	"NightRun",
	"Unreachable",
	"Unknown"
];
const WRITES_ALLOWED = ["Available"];
function writesBlockedBy(state) {
	return !WRITES_ALLOWED.includes(state);
}
function toAvailabilityState(value) {
	return typeof value === "string" && AVAILABILITY_STATES.includes(value) ? value : "Unknown";
}
const NOTICES = {
	Available: {
		title: "CTRM is available",
		detail: "Contracts can be read and saved as normal."
	},
	NightRun: {
		title: "CTRM is running its night job",
		detail: "Changes to contracts in CTRM are paused until the night run ends. Reading is unaffected, and templates and other Contract Workspace settings can still be saved."
	},
	Closed: {
		title: "CTRM is closed",
		detail: "CTRM is not accepting changes at the moment, so contracts cannot be saved. Reading is unaffected."
	},
	Unreachable: {
		title: "CTRM cannot be reached",
		detail: "Contracts cannot be saved while the connection is down. This is worth reporting if it persists."
	},
	Unknown: {
		title: "CTRM status is unknown",
		detail: "The status of CTRM could not be established, so saving is unavailable as a precaution. Reading is unaffected."
	}
};
function availabilityNotice(state) {
	const known = toAvailabilityState(state);
	return {
		...NOTICES[known],
		blocksWrites: writesBlockedBy(known)
	};
}
const BROKER_STAGE_CAUTION = "CTRM works this out rather than recording it, and defaults it to confirmed. A contract with no broker, or one edited since its last confirmation, shows as settled here — read it as nothing outstanding rather than as a broker having signed.";
const AFFIRMATIVE = [
	"approved",
	"confirmed",
	"complete",
	"completed",
	"yes"
];
function confirmationProgress(header) {
	const approval = stateOf(header.traderApprovalStatus);
	const customer = stateOf(header.customerConfirmStatus);
	const broker = stateOf(header.brokerConfirmStatus);
	return [
		{
			key: "approval",
			label: labelFor(approval, "Approved", "Not approved yet", "Approval status unclear"),
			value: trimmed(header.traderApprovalStatus),
			state: approval,
			caution: null
		},
		{
			key: "customer",
			label: labelFor(customer, "Customer confirmed", "Awaiting customer", "Customer status unclear"),
			value: trimmed(header.customerConfirmStatus),
			state: customer,
			caution: null
		},
		{
			key: "broker",
			label: labelFor(broker, "Broker: nothing outstanding", "Awaiting broker", "Broker status unclear"),
			value: trimmed(header.brokerConfirmStatus),
			state: broker,
			caution: BROKER_STAGE_CAUTION
		}
	];
}
function trimmed(value) {
	const text = (value ?? "").trim();
	return text === "" ? null : text;
}
function stateOf(value) {
	const text = trimmed(value);
	if (text === null) return "outstanding";
	return AFFIRMATIVE.includes(text.toLowerCase()) ? "complete" : "unknown";
}
function labelFor(state, complete, outstanding, unclear) {
	switch (state) {
		case "complete": return complete;
		case "outstanding": return outstanding;
		default: return unclear;
	}
}
var ConfirmationProgressComponent = class ConfirmationProgressComponent {
	header = input.required(...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	stages = computed(() => confirmationProgress(this.header()), ...ngDevMode ? [{ debugName: "stages" }] : /* istanbul ignore next */ []);
	brokerCaution = computed(() => this.stages().find((stage) => stage.key === "broker")?.caution ?? null, ...ngDevMode ? [{ debugName: "brokerCaution" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ConfirmationProgressComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ConfirmationProgressComponent,
		isStandalone: true,
		selector: "cms-confirmation-progress",
		inputs: { header: {
			classPropertyName: "header",
			publicName: "header",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0,
		template: `
    <ol class="cws:flex cws:flex-wrap cws:items-stretch cws:gap-2">
      @for (stage of stages(); track stage.key) {
        <li
          class="cws:flex cws:items-center cws:gap-2 cws:rounded cws:border cws:px-2.5 cws:py-1.5 cws:text-xs"
          [class.cws:border-emerald-300]="stage.state === 'complete'"
          [class.cws:bg-emerald-50]="stage.state === 'complete'"
          [class.cws:text-emerald-900]="stage.state === 'complete'"
          [class.cws:border-slate-300]="stage.state === 'outstanding'"
          [class.cws:bg-slate-50]="stage.state === 'outstanding'"
          [class.cws:text-slate-700]="stage.state === 'outstanding'"
          [class.cws:border-amber-300]="stage.state === 'unknown'"
          [class.cws:bg-amber-50]="stage.state === 'unknown'"
          [class.cws:text-amber-900]="stage.state === 'unknown'"
          [attr.title]="stage.caution"
        >
          <span aria-hidden="true">
            @switch (stage.state) {
              @case ('complete') { ✓ }
              @case ('outstanding') { · }
              @default { ? }
            }
          </span>
          <span class="cws:font-medium">{{ stage.label }}</span>
          @if (stage.value !== null && stage.state !== 'complete') {
            <!-- CTRM's own word, so a neutral stage says what it did not recognise. -->
            <span class="cws:font-mono cws:opacity-75">{{ stage.value }}</span>
          }
        </li>
      }
    </ol>

    @if (brokerCaution(); as caution) {
      <!--
        🔴 Rendered as TEXT, not only as a tooltip. A title attribute is invisible on a touch device
        and to anybody who does not hover, and this is the sentence that stops a lit broker segment
        being read as a broker having signed (#124).
      -->
      <p class="cws:mt-1.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ caution }}</p>
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ConfirmationProgressComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-confirmation-progress",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <ol class="cws:flex cws:flex-wrap cws:items-stretch cws:gap-2">
      @for (stage of stages(); track stage.key) {
        <li
          class="cws:flex cws:items-center cws:gap-2 cws:rounded cws:border cws:px-2.5 cws:py-1.5 cws:text-xs"
          [class.cws:border-emerald-300]="stage.state === 'complete'"
          [class.cws:bg-emerald-50]="stage.state === 'complete'"
          [class.cws:text-emerald-900]="stage.state === 'complete'"
          [class.cws:border-slate-300]="stage.state === 'outstanding'"
          [class.cws:bg-slate-50]="stage.state === 'outstanding'"
          [class.cws:text-slate-700]="stage.state === 'outstanding'"
          [class.cws:border-amber-300]="stage.state === 'unknown'"
          [class.cws:bg-amber-50]="stage.state === 'unknown'"
          [class.cws:text-amber-900]="stage.state === 'unknown'"
          [attr.title]="stage.caution"
        >
          <span aria-hidden="true">
            @switch (stage.state) {
              @case ('complete') { ✓ }
              @case ('outstanding') { · }
              @default { ? }
            }
          </span>
          <span class="cws:font-medium">{{ stage.label }}</span>
          @if (stage.value !== null && stage.state !== 'complete') {
            <!-- CTRM's own word, so a neutral stage says what it did not recognise. -->
            <span class="cws:font-mono cws:opacity-75">{{ stage.value }}</span>
          }
        </li>
      }
    </ol>

    @if (brokerCaution(); as caution) {
      <!--
        🔴 Rendered as TEXT, not only as a tooltip. A title attribute is invisible on a touch device
        and to anybody who does not hover, and this is the sentence that stops a lit broker segment
        being read as a broker having signed (#124).
      -->
      <p class="cws:mt-1.5 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400">{{ caution }}</p>
    }
  `
		}]
	}],
	propDecorators: { header: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "header",
			required: true
		}]
	}] }
});
const AVAILABILITY_SOURCE = new InjectionToken("AVAILABILITY_SOURCE");
var HttpAvailabilitySource = class HttpAvailabilitySource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answer = this.fetch();
	get() {
		return this.answer;
	}
	fetch() {
		return this.http.get(`${this.baseUrl}/availability`).pipe(map((body) => ({
			state: toAvailabilityState(body?.state),
			message: typeof body?.message === "string" ? body.message : null
		})), catchError(() => of({
			state: "Unknown",
			message: null
		})), startWith({
			state: "Unknown",
			message: null
		}), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpAvailabilitySource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpAvailabilitySource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpAvailabilitySource,
	decorators: [{ type: Injectable }]
});
var AvailabilityGate = class AvailabilityGate {
	source = inject(AVAILABILITY_SOURCE, { optional: true });
	current = toSignal(this.source?.get() ?? of(NOT_OFFERED), { initialValue: this.source === null ? NOT_OFFERED : UNKNOWN });
	isOffered = this.source !== null;
	state = computed(() => this.current().state, ...ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []);
	message = computed(() => this.current().message, ...ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []);
	notice = computed(() => availabilityNotice(this.state()), ...ngDevMode ? [{ debugName: "notice" }] : /* istanbul ignore next */ []);
	writesBlocked = computed(() => writesBlockedBy(this.state()), ...ngDevMode ? [{ debugName: "writesBlocked" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AvailabilityGate,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AvailabilityGate
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: AvailabilityGate,
	decorators: [{ type: Injectable }]
});
const UNKNOWN = {
	state: "Unknown",
	message: null
};
const NOT_OFFERED = {
	state: "Available",
	message: null
};
var SampleAvailabilitySource = class SampleAvailabilitySource {
	answer = {
		state: "Available",
		message: null
	};
	get() {
		return of(this.answer);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleAvailabilitySource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleAvailabilitySource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleAvailabilitySource,
	decorators: [{ type: Injectable }]
});
const ME_SOURCE = new InjectionToken("ME_SOURCE");
function defaultTradeUnitOf(me) {
	if (me === null) return null;
	return (me.defaultTradeUnit === null ? void 0 : me.tradeUnits.find((unit) => unit.code === me.defaultTradeUnit)) ?? me.tradeUnits.find((unit) => unit.isDefault) ?? null;
}
var HttpMeSource = class HttpMeSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answer = this.fetch();
	get() {
		return this.answer;
	}
	fetch() {
		return this.http.get(`${this.baseUrl}/me`).pipe(map((me) => remoteLoaded({
			oid: me.user?.objectId ?? "",
			upn: me.user?.userName ?? null,
			isAdmin: me.isAdmin === true,
			defaultTradeUnit: me.defaultTradeUnit ?? null,
			status: me.status === "Available" ? "Available" : "Unavailable",
			tradeUnits: (me.tradeUnits ?? []).map((unit) => ({
				code: unit.code,
				isDefault: unit.isDefault === true,
				onboarded: unit.onboarded === true,
				permissions: unit.permissions ?? []
			}))
		})), catchError(() => of(remoteError({ message: "Your trade units could not be loaded right now." }))), startWith(remoteLoading()), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpMeSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpMeSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpMeSource,
	decorators: [{ type: Injectable }]
});
var SampleMeSource = class SampleMeSource {
	answer = remoteLoaded(SAMPLE_ME);
	get() {
		return of(this.answer);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleMeSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleMeSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleMeSource,
	decorators: [{ type: Injectable }]
});
const SAMPLE_ME = {
	oid: "00000000-0000-0000-0000-000000000000",
	upn: "spec@scoular.com",
	isAdmin: false,
	defaultTradeUnit: "0210",
	status: "Available",
	tradeUnits: [
		{
			code: "0210",
			isDefault: true,
			onboarded: true,
			permissions: ["contracts:update"]
		},
		{
			code: "2087",
			isDefault: false,
			onboarded: true,
			permissions: []
		},
		{
			code: "4090",
			isDefault: false,
			onboarded: false,
			permissions: []
		}
	]
};
const CONTRACT_IDEMPOTENCY_KEY = new InjectionToken("CONTRACT_IDEMPOTENCY_KEY", {
	providedIn: "root",
	factory: () => () => crypto.randomUUID()
});
const CONTRACT_WRITE_SOURCE = new InjectionToken("CONTRACT_WRITE_SOURCE");
var HttpContractWriteSource = class HttpContractWriteSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get contractsUrl() {
		return `${this.baseUrl}/contracts`;
	}
	fields(contractNumber) {
		return this.http.get(`${this.contractsUrl}/${encodeURIComponent(contractNumber)}/fields`).pipe(map((response) => ({
			...response,
			fields: response.fields ?? {}
		})));
	}
	create(fields, collections, options) {
		const key = options?.idempotencyKey;
		return this.http.post(this.contractsUrl, bodyFor(fields, collections), key === void 0 ? {} : { headers: { "Idempotency-Key": key } });
	}
	update(contractNumber, fields, collections) {
		return this.http.put(`${this.contractsUrl}/${encodeURIComponent(contractNumber)}`, bodyFor(fields, collections));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractWriteSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractWriteSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractWriteSource,
	decorators: [{ type: Injectable }]
});
function bodyFor(fields, collections) {
	return collections === void 0 ? { fields } : {
		fields,
		collections
	};
}
const RECORD_DRAFT_STORE = new InjectionToken("RECORD_DRAFT_STORE", {
	providedIn: "root",
	factory: () => new SessionRecordDraftStore()
});
const DRAFT_STORAGE = new InjectionToken("DRAFT_STORAGE", {
	providedIn: "root",
	factory: () => sessionStorage
});
const DRAFT_CLOCK = new InjectionToken("DRAFT_CLOCK", {
	providedIn: "root",
	factory: () => () => /* @__PURE__ */ new Date()
});
const PREFIX = "cws.record-draft";
function draftStorageKey(key) {
	return `${PREFIX}:${key.mode}:${key.tradeUnit}:${key.contractNumber}`;
}
var SessionRecordDraftStore = class {
	storage = inject(DRAFT_STORAGE);
	now = inject(DRAFT_CLOCK);
	read(key) {
		const raw = this.readRaw(draftStorageKey(key));
		if (raw === null) return null;
		try {
			const parsed = JSON.parse(raw);
			if (!isDraft(parsed)) return null;
			const { idempotencyKey, ...rest } = parsed;
			return typeof idempotencyKey === "string" && idempotencyKey.trim() !== "" ? {
				...rest,
				idempotencyKey
			} : rest;
		} catch {
			return null;
		}
	}
	write(key, values, idempotencyKey) {
		if (Object.keys(values).length === 0) {
			this.clear(key);
			return;
		}
		const draft = idempotencyKey === void 0 ? {
			values,
			savedAt: this.now().toISOString()
		} : {
			values,
			savedAt: this.now().toISOString(),
			idempotencyKey
		};
		try {
			this.storage.setItem(draftStorageKey(key), JSON.stringify(draft));
		} catch {}
	}
	clear(key) {
		try {
			this.storage.removeItem(draftStorageKey(key));
		} catch {}
	}
	readRaw(storageKey) {
		try {
			return this.storage.getItem(storageKey);
		} catch {
			return null;
		}
	}
};
function isDraft(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return typeof candidate.savedAt === "string" && typeof candidate.values === "object" && candidate.values !== null && !Array.isArray(candidate.values);
}
const CONTRACT_NUMBER_SOURCE = new InjectionToken("CONTRACT_NUMBER_SOURCE");
var HttpContractNumberSource = class HttpContractNumberSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get numbersUrl() {
		return `${this.baseUrl}/contract-numbers`;
	}
	issue(request) {
		return this.http.post(this.numbersUrl, {
			prefixType: request.prefixType,
			prefixCommodity: request.prefixCommodity,
			suffix: request.suffix ?? null
		});
	}
	check(contractNumber) {
		return this.http.get(`${this.numbersUrl}/${encodeURIComponent(contractNumber)}`);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractNumberSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractNumberSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractNumberSource,
	decorators: [{ type: Injectable }]
});
const UNSET_DATE = "0001-01-01";
const TRUTHY_FLAGS = /* @__PURE__ */ new Set([
	"Y",
	"y",
	"T",
	"true"
]);
function coerceForControl(value, controlPattern) {
	if (value === null || value === void 0 || value === "") return null;
	switch (controlPattern) {
		case ControlPattern.QuantityDecimal: {
			const numeric = typeof value === "number" ? value : Number(String(value).replace(/,/g, ""));
			return Number.isFinite(numeric) ? numeric : null;
		}
		case ControlPattern.MaskedDate: {
			const iso = toIsoDate(value);
			return iso === UNSET_DATE ? null : iso;
		}
		case ControlPattern.ToggleFlag: return typeof value === "boolean" ? value : TRUTHY_FLAGS.has(String(value).trim());
		default: return typeof value === "string" ? value.trim() : String(value);
	}
}
function toIsoDate(value) {
	const text = String(value).trim();
	if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
	const packed = /^(\d{4})(\d{2})(\d{2})$/.exec(text);
	return packed === null ? text : `${packed[1]}-${packed[2]}-${packed[3]}`;
}
function seedFromCtrmValues(values) {
	const seeded = {};
	for (const field of CONTRACT_LAYOUT_FIELDS) {
		const coerced = coerceForControl(values[field.ctrmField], field.controlPattern);
		if (coerced !== null) seeded[field.componentName] = coerced;
	}
	return seeded;
}
const CONTRACT_COPY_IDENTITY_FIELDS = ["contract_number", "contract_suffix"];
const IDENTITY_FIELDS = new Set(CONTRACT_COPY_IDENTITY_FIELDS);
function copyExclusions(config) {
	const excluded = /* @__PURE__ */ new Set();
	for (const section of config?.sections ?? []) for (const field of section.fields) if (field.behaviour.excludeFromCopy) excluded.add(field.componentName);
	return excluded;
}
function copyableValues(sourceValues, excluded = /* @__PURE__ */ new Set()) {
	const copied = {};
	for (const field of CONTRACT_WRITABLE_FIELDS) {
		if (IDENTITY_FIELDS.has(field.ctrmField) || excluded.has(field.componentName)) continue;
		const coerced = coerceForControl(sourceValues[field.ctrmField], field.controlPattern);
		if (coerced !== null) copied[field.componentName] = coerced;
	}
	return copied;
}
const RECORD_ORIGIN_PARAM = "from";
const ORIGINS = {
	contracts: {
		label: "Contracts",
		path: "/"
	},
	approvals: {
		label: "Approvals",
		path: "/approvals",
		review: {
			label: "Review",
			path: (contractNumber) => `/approvals/${contractNumber}`
		}
	},
	pricing: {
		label: "Pricing",
		path: "/pricing",
		review: {
			label: "Prices",
			path: (contractNumber) => `/pricing/${contractNumber}`
		}
	}
};
function recordOrigin(value, fallback = "contracts") {
	return ORIGINS[recordOriginKey(value, fallback)];
}
function recordOriginKey(value, fallback = "contracts") {
	return isRecordOrigin(value) ? value : fallback;
}
function isRecordOrigin(value) {
	return value === "approvals" || value === "pricing" || value === "contracts";
}
function recordTrail(origin, contractNumber) {
	const queue = {
		label: origin.label,
		path: origin.path
	};
	if (origin.review === void 0 || contractNumber.trim() === "") return [queue];
	return [queue, {
		label: origin.review.label,
		path: origin.review.path(contractNumber)
	}];
}
function wholeDaysBetween(iso, today) {
	if (iso === null || iso === "") return null;
	const parsed = Date.parse(`${iso.slice(0, 10)}T00:00:00Z`);
	if (Number.isNaN(parsed)) return null;
	const midnight = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
	return Math.round((midnight - parsed) / 864e5);
}
const FORM_CONFIG_SOURCE = new InjectionToken("FORM_CONFIG_SOURCE");
function emptiedTabs(tabs, sections) {
	const tabsWithAVisibleSection = new Set(sections.filter((section) => section.visible).map((section) => section.tab));
	return tabs.filter((tab) => tab.visible).filter((tab) => sections.some((section) => section.tab === tab.id)).filter((tab) => !tabsWithAVisibleSection.has(tab.id));
}
function tabsAfterCascade(tabs, sections) {
	const dropped = new Set(emptiedTabs(tabs, sections).map((tab) => tab.id));
	return tabs.filter((tab) => tab.visible && !dropped.has(tab.id));
}
const ADDED = "(added)";
const REMOVED = "(removed)";
const FIELD_PROPERTIES = [
	"visible",
	"required",
	"readOnly",
	"borderWarning",
	"excludeFromCopy",
	"excludeFromTemplateCopy",
	"section",
	"order"
];
const SECTION_PROPERTIES = [
	"label",
	"tab",
	"order",
	"visible"
];
const TAB_PROPERTIES = [
	"label",
	"order",
	"visible"
];
function diffConfigDocuments(before, after) {
	if (before === null) return [];
	return [
		...diffFields(before.fields ?? {}, after.fields ?? {}),
		...diffKeyed("section", before.sections ?? [], after.sections ?? [], SECTION_PROPERTIES),
		...diffKeyed("tab", before.tabs ?? [], after.tabs ?? [], TAB_PROPERTIES),
		...diffAttributes(before, after)
	];
}
function diffFields(before, after) {
	const changes = [];
	for (const name of union(Object.keys(before), Object.keys(after))) {
		const was = before[name];
		const now = after[name];
		if (was === void 0 || now === void 0) {
			changes.push(whole("field", name, was, now));
			continue;
		}
		for (const property of FIELD_PROPERTIES) if (was[property] !== now[property]) changes.push({
			scope: "field",
			subject: name,
			property,
			before: render(was[property]),
			after: render(now[property])
		});
	}
	return changes;
}
function diffKeyed(scope, before, after, properties) {
	const changes = [];
	const byId = (items) => new Map(items.map((item) => [item.id, item]));
	const was = byId(before);
	const now = byId(after);
	for (const id of union([...was.keys()], [...now.keys()])) {
		const a = was.get(id);
		const b = now.get(id);
		if (a === void 0 || b === void 0) {
			changes.push(whole(scope, id, a, b));
			continue;
		}
		for (const property of properties) if (a[property] !== b[property]) changes.push({
			scope,
			subject: id,
			property: String(property),
			before: render(a[property]),
			after: render(b[property])
		});
	}
	return changes;
}
function diffAttributes(before, after) {
	const changes = [];
	const was = before.attributes;
	const now = after.attributes;
	if (was === void 0 || now === void 0) return changes;
	for (const property of ["autoCalculationMode", "pendingContractsEnabled"]) if (was[property] !== now[property]) changes.push({
		scope: "attribute",
		subject: property,
		property: "",
		before: render(was[property]),
		after: render(now[property])
	});
	return changes;
}
function whole(scope, subject, was, now) {
	return {
		scope,
		subject,
		property: was === void 0 ? ADDED : REMOVED,
		before: was === void 0 ? "" : "present",
		after: now === void 0 ? "" : "present"
	};
}
function union(first, second) {
	return [.../* @__PURE__ */ new Set([...first, ...second])];
}
function render(value) {
	if (value === null || value === void 0 || value === "") return "—";
	return String(value);
}
function normaliseCode(value) {
	return (value ?? "").trim().toUpperCase();
}
function narrowToConfigured(offered, configured) {
	if (configured.length === 0) return offered;
	const included = new Set(configured.filter((row) => row.include).map((row) => normaliseCode(row.value)));
	const excluded = new Set(configured.filter((row) => !row.include).map((row) => normaliseCode(row.value)));
	return offered.filter((option) => {
		const code = normaliseCode(option.code);
		if (excluded.has(code)) return false;
		return included.size === 0 || included.has(code);
	});
}
const TRADE_UNIT_VALUES_SOURCE = new InjectionToken("TRADE_UNIT_VALUES_SOURCE");
var HttpTradeUnitValuesSource = class HttpTradeUnitValuesSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	cache = /* @__PURE__ */ new Map();
	values(tradeUnit) {
		return this.fetch("values", tradeUnit);
	}
	marketMonths(tradeUnit) {
		return this.fetch("market-months", tradeUnit);
	}
	fetch(set, tradeUnit) {
		const key = `${set}:${tradeUnit}`;
		const cached = this.cache.get(key);
		if (cached !== void 0) return cached;
		const stream = this.http.get(`${this.baseUrl}/trade-unit-values/${set}`, { params: { tradeUnit } }).pipe(map((response) => response.rows ?? []), catchError(() => of([])), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
		this.cache.set(key, stream);
		return stream;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpTradeUnitValuesSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpTradeUnitValuesSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpTradeUnitValuesSource,
	decorators: [{ type: Injectable }]
});
var ContractFormComponent = class ContractFormComponent {
	formBuilder = inject(FormBuilderService);
	config = input.required(...ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []);
	tradeUnit = input.required(...ngDevMode ? [{ debugName: "tradeUnit" }] : /* istanbul ignore next */ []);
	facts = input({
		prefixType: "S",
		isClosed: false,
		isIntercompany: false,
		userCanEdit: true
	}, ...ngDevMode ? [{ debugName: "facts" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	instanceId = input("", ...ngDevMode ? [{ debugName: "instanceId" }] : /* istanbul ignore next */ []);
	visibleSections = input(null, ...ngDevMode ? [{ debugName: "visibleSections" }] : /* istanbul ignore next */ []);
	fieldNotes = input({}, ...ngDevMode ? [{ debugName: "fieldNotes" }] : /* istanbul ignore next */ []);
	emptyNotes = input({}, ...ngDevMode ? [{ debugName: "emptyNotes" }] : /* istanbul ignore next */ []);
	sectionNotes = input({}, ...ngDevMode ? [{ debugName: "sectionNotes" }] : /* istanbul ignore next */ []);
	wideFields = input({}, ...ngDevMode ? [{ debugName: "wideFields" }] : /* istanbul ignore next */ []);
	halfFields = input({}, ...ngDevMode ? [{ debugName: "halfFields" }] : /* istanbul ignore next */ []);
	fieldCtrmNames = input({}, ...ngDevMode ? [{ debugName: "fieldCtrmNames" }] : /* istanbul ignore next */ []);
	hiddenLabelFields = input({}, ...ngDevMode ? [{ debugName: "hiddenLabelFields" }] : /* istanbul ignore next */ []);
	groupHeadings = input({}, ...ngDevMode ? [{ debugName: "groupHeadings" }] : /* istanbul ignore next */ []);
	readOnlyFields = input({}, ...ngDevMode ? [{ debugName: "readOnlyFields" }] : /* istanbul ignore next */ []);
	initialValues = input({}, ...ngDevMode ? [{ debugName: "initialValues" }] : /* istanbul ignore next */ []);
	defaultValues = input({}, ...ngDevMode ? [{ debugName: "defaultValues" }] : /* istanbul ignore next */ []);
	ready = output();
	fieldBlur = output();
	onFieldFocusOut(componentName) {
		this.fieldBlur.emit(componentName);
	}
	form = signal(null, ...ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []);
	sections = computed(() => {
		const shown = this.visibleSections();
		return [...this.config().sections].filter((section) => section.visible).filter((section) => shown === null || shown.includes(section.componentName)).sort((a, b) => a.order - b.order).map((section) => ({
			...section,
			fields: [...section.fields].filter((field) => this.isFieldShown(field)).sort((a, b) => a.order - b.order)
		})).filter((section) => section.fields.length > 0);
	}, ...ngDevMode ? [{ debugName: "sections" }] : /* istanbul ignore next */ []);
	controlFor(componentName) {
		return this.form()?.control(componentName);
	}
	rowsFor(section) {
		const rows = [];
		for (const field of section.fields) {
			const previous = rows.at(-1);
			if (this.halfFields()[field.componentName] === true && previous !== void 0 && previous.fields.length === 1 && this.halfFields()[previous.fields[0].componentName] === true) {
				previous.fields.push(field);
				continue;
			}
			rows.push({
				key: field.componentName,
				fields: [field]
			});
		}
		return rows;
	}
	noteFor(componentName) {
		const note = this.fieldNotes()[componentName];
		if (note !== void 0) return note;
		const emptyNote = this.emptyNotes()[componentName];
		if (emptyNote === void 0) return;
		const value = this.controlFor(componentName)?.value;
		return value === null || value === void 0 || value === "" ? emptyNote : void 0;
	}
	tooltipFor(componentName) {
		const note = this.noteFor(componentName);
		if (note === void 0) return null;
		return {
			note,
			ctrmField: this.fieldCtrmNames()[componentName] ?? componentName
		};
	}
	isFieldShown(field) {
		return this.fieldStates().get(field.componentName)?.visible ?? field.behaviour.visible;
	}
	fieldStates = computed(() => {
		const built = this.form();
		if (built === null) return /* @__PURE__ */ new Map();
		const viewOnly = this.readOnly();
		const refused = this.readOnlyFields();
		const merged = /* @__PURE__ */ new Map();
		for (const [componentName, state] of built.states()) {
			const inactive = viewOnly || refused[componentName] === true;
			merged.set(componentName, inactive && !state.readOnly ? {
				...state,
				readOnly: true
			} : state);
		}
		return merged;
	}, ...ngDevMode ? [{ debugName: "fieldStates" }] : /* istanbul ignore next */ []);
	idPrefix = computed(() => this.instanceId() === "" ? "" : `${this.instanceId()}-`, ...ngDevMode ? [{ debugName: "idPrefix" }] : /* istanbul ignore next */ []);
	ngOnInit() {
		const built = this.formBuilder.build(this.config(), this.tradeUnit(), this.facts());
		const prefill = this.initialValues();
		built.seed(prefill);
		for (const componentName of Object.keys(prefill)) built.control(componentName)?.markAsPristine();
		if (!this.readOnly()) {
			const applicable = {};
			for (const [componentName, value] of Object.entries(this.defaultValues())) {
				const control = built.control(componentName);
				if (control === void 0 || control.value !== null && control.value !== "") continue;
				applicable[componentName] = value;
			}
			built.seed(applicable);
			for (const componentName of Object.keys(applicable)) built.control(componentName)?.markAsDirty();
		}
		this.form.set(built);
		this.ready.emit(built);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ContractFormComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ContractFormComponent,
		isStandalone: true,
		selector: "cms-contract-form",
		inputs: {
			config: {
				classPropertyName: "config",
				publicName: "config",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			tradeUnit: {
				classPropertyName: "tradeUnit",
				publicName: "tradeUnit",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			facts: {
				classPropertyName: "facts",
				publicName: "facts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			instanceId: {
				classPropertyName: "instanceId",
				publicName: "instanceId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			visibleSections: {
				classPropertyName: "visibleSections",
				publicName: "visibleSections",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fieldNotes: {
				classPropertyName: "fieldNotes",
				publicName: "fieldNotes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyNotes: {
				classPropertyName: "emptyNotes",
				publicName: "emptyNotes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sectionNotes: {
				classPropertyName: "sectionNotes",
				publicName: "sectionNotes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wideFields: {
				classPropertyName: "wideFields",
				publicName: "wideFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			halfFields: {
				classPropertyName: "halfFields",
				publicName: "halfFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			fieldCtrmNames: {
				classPropertyName: "fieldCtrmNames",
				publicName: "fieldCtrmNames",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hiddenLabelFields: {
				classPropertyName: "hiddenLabelFields",
				publicName: "hiddenLabelFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			groupHeadings: {
				classPropertyName: "groupHeadings",
				publicName: "groupHeadings",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnlyFields: {
				classPropertyName: "readOnlyFields",
				publicName: "readOnlyFields",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initialValues: {
				classPropertyName: "initialValues",
				publicName: "initialValues",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			defaultValues: {
				classPropertyName: "defaultValues",
				publicName: "defaultValues",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			ready: "ready",
			fieldBlur: "fieldBlur"
		},
		host: { classAttribute: "cws:block" },
		providers: [FormBuilderService],
		ngImport: i0,
		template: "@if (form(); as contractForm) {\r\n  <!--\r\n    novalidate: validation is the form engine's, driven by constraints.json and the rules. The\r\n    browser's own bubbles would compete with the inline messages and say different things.\r\n  -->\r\n  <form [formGroup]=\"contractForm.group\" novalidate>\r\n    <!--\r\n      🔴 SECTIONS ARE FULL WIDTH AND STACKED, and the fields inside them run in a wide responsive\r\n      grid. That inversion is the main readability fix of 2026-09-01 and it is worth stating, because\r\n      the previous version looks more organised and reads far worse.\r\n\r\n      It was `lg:grid-cols-2` cards, each with `sm:grid-cols-2` fields — so on a wide screen the page\r\n      carried **four columns of label/value pairs that did not line up with each other**, because each\r\n      card sized its own two columns independently. Two adjacent cards of unequal length then left\r\n      ragged whitespace down the middle, and the eye had no consistent column to follow. JFrisbie's\r\n      words were \"the layout is a little confusing\".\r\n\r\n      Full-width cards give every field on the page the same column grid, so the columns align all the\r\n      way down and a section heading reads as a horizontal rule between groups. The shell is 1800px, so\r\n      `2xl:grid-cols-4` uses the width the record screen actually has instead of wasting half of it.\r\n    -->\r\n    <div class=\"cws:space-y-4\">\r\n      @for (section of sections(); track section.componentName) {\r\n        <!--\r\n          ⚠ `data-section` is load-bearing rather than a test hook: `Ctrl+PgDn` / `Ctrl+PgUp`\r\n          (docs/02a §4.2) step between sections and need something addressable to scroll to and focus\r\n          into. Keyed on `componentName` because that is the identity the configuration orders by —\r\n          the visible label is a presentation string a trade unit may change.\r\n        -->\r\n        <div\r\n          [attr.data-section]=\"section.componentName\"\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <!-- h3, matching the rest of the record screen: the shell owns the h1 and the page the h2. -->\r\n          <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n            {{ section.label }}\r\n          </h3>\r\n\r\n          @if (sectionNotes()[section.componentName]; as note) {\r\n            <!--\r\n              What the section deliberately does not carry — shipment dates living in a collection,\r\n              a customer name no route returns. Stated inside the section it applies to, because a\r\n              gap named at the top of the page is a gap nobody connects to the field in front of\r\n              them.\r\n            -->\r\n            <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ note }}</p>\r\n          }\r\n\r\n          <!--\r\n            Fields are emitted in configured order and the grid flows in DOM order, so tab order\r\n            follows field order without any tabindex (02a §4.2).\r\n\r\n            ⚠ The column count climbs with the viewport and the ORDER does not change with it — CSS\r\n            grid fills row-major, so field 1 is top-left at every breakpoint. A `grid-flow-col` would\r\n            reorder the fields as the window resized, which is the one thing a form must not do.\r\n          -->\r\n          <div\r\n            class=\"cws:mt-3 cws:grid cws:gap-x-6 cws:gap-y-3 cws:border-t cws:border-slate-100 cws:pt-4 cws:sm:grid-cols-2 cws:xl:grid-cols-3 cws:2xl:grid-cols-4 cws:dark:border-slate-700/60\"\r\n          >\r\n            <!--\r\n              Rows, not fields. A row is one ordinary field, or a PAIR of half fields sharing a single\r\n              grid cell — see `rowsFor`. Iterating fields directly cannot express the pair, because two\r\n              adjacent cells are two columns however narrow their contents are.\r\n            -->\r\n            @for (row of rowsFor(section); track row.key) {\r\n              <!--\r\n                A group heading, rendered above the field that introduces the group and spanning the\r\n                grid's full width so the members below read as one identifier (#196).\r\n\r\n                🔴 `aria-hidden`, and that is the whole point of the mechanism. Every field in the\r\n                group carries its own `sr-only` label naming itself, so the heading is decoration for\r\n                sighted readers only — announcing it as well would repeat \"Contract number\" on each of\r\n                the four controls. Previously the heading WAS the first field's label, which is what\r\n                left two inputs sharing one accessible name.\r\n              -->\r\n              @if (groupHeadings()[row.fields[0].componentName]; as heading) {\r\n                <p\r\n                  class=\"scoular-form-label cws:col-span-full cws:-mb-1\"\r\n                  aria-hidden=\"true\"\r\n                >\r\n                  {{ heading }}\r\n                </p>\r\n              }\r\n\r\n              @if (row.fields.length > 1) {\r\n                <!--\r\n                  Two half-width boxes inside one column. `gap-x-3` is half the grid's own `gap-x-6`,\r\n                  so the pair reads as one field's worth of space rather than as two fields that\r\n                  happen to be close.\r\n                -->\r\n                <div class=\"cws:grid cws:grid-cols-2 cws:items-start cws:gap-x-3\">\r\n                  @for (field of row.fields; track field.componentName) {\r\n                    <ng-container [ngTemplateOutlet]=\"cell\" [ngTemplateOutletContext]=\"{ field }\" />\r\n                  }\r\n                </div>\r\n              } @else {\r\n                <!--\r\n                  A wide field takes two columns at every breakpoint rather than the whole row.\r\n                  `col-span-2` alone would have made it full-width at `sm` (2 columns) and a third of\r\n                  a row at `2xl` (4 columns) — the same class meaning something different at each\r\n                  size. Two columns is \"this value needs more room than a code\", which is what the\r\n                  flag actually says.\r\n                -->\r\n                <div [class.cws:sm:col-span-2]=\"wideFields()[row.fields[0].componentName]\">\r\n                  <ng-container\r\n                    [ngTemplateOutlet]=\"cell\"\r\n                    [ngTemplateOutletContext]=\"{ field: row.fields[0] }\"\r\n                  />\r\n                </div>\r\n              }\r\n            }\r\n          </div>\r\n        </div>\r\n      }\r\n    </div>\r\n  </form>\r\n}\r\n\r\n<!--\r\n  One field's cell, single-sourced so an ordinary field and a half field cannot drift apart.\r\n\r\n  `fieldStates()`, not `contractForm.states()`. The engine's state says what configuration and the\r\n  rules make of the field; this map is the same thing with the screen's read-only overrides folded in\r\n  — view mode, and the fields CTRM refuses on a write. Reading the engine's map directly here is what\r\n  would make view mode editable, so the indirection is load-bearing rather than a wrapper.\r\n-->\r\n<ng-template #cell let-field=\"field\">\r\n  @if (controlFor(field.componentName); as control) {\r\n    @if (fieldStates().get(field.componentName); as state) {\r\n      <!--\r\n        A half field becomes a flex ROW: the control, then the \"i\" to the RIGHT of the input box.\r\n\r\n        ⚠ It used to be `absolute bottom-2 right-2` inside the cell, and that was wrong in a way only a\r\n        screenshot showed: paired cells stretch to equal height, so when one label wrapped the taller\r\n        cell dragged the \"i\" down BELOW the shorter input. A flex row cannot do that -- the button is a\r\n        sibling of the control, so it tracks the input rather than the cell.\r\n\r\n        `items-end` lines the button up with the bottom of the input, and `pb-2` lifts it to the\r\n        input's vertical middle. `min-w-0` on the control is what lets the label inside it truncate:\r\n        without it a flex item refuses to shrink below its content and the label wraps again.\r\n      -->\r\n      <div\r\n        [class.cws:flex]=\"halfFields()[field.componentName]\"\r\n        [class.cws:items-end]=\"halfFields()[field.componentName]\"\r\n        [class.cws:gap-1]=\"halfFields()[field.componentName]\"\r\n      >\r\n        <div\r\n          [class.cws:min-w-0]=\"halfFields()[field.componentName]\"\r\n          [class.cws:flex-1]=\"halfFields()[field.componentName]\"\r\n          (focusout)=\"onFieldFocusOut(field.componentName)\"\r\n        >\r\n          <cms-dynamic-field\r\n            [field]=\"field\"\r\n            [state]=\"state\"\r\n            [control]=\"control\"\r\n            [idPrefix]=\"idPrefix()\"\r\n            [hideLabel]=\"hiddenLabelFields()[field.componentName] === true\"\r\n          />\r\n\r\n          @if (!halfFields()[field.componentName] && noteFor(field.componentName); as note) {\r\n            <!--\r\n              Help text, not an error. `aria-describedby` is not wired here because\r\n              <cms-dynamic-field> owns the control's id and its own description element; adding a\r\n              second describedby from outside would need the renderer to accept one, which is a change\r\n              to the shared control rather than to this screen. Sighted and screen-reader users both\r\n              get the text in reading order.\r\n            -->\r\n            <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              {{ note }}\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        @if (halfFields()[field.componentName]) {\r\n          @if (tooltipFor(field.componentName); as tip) {\r\n            <!--\r\n              🔴 A half field's help text moves into an \"i\" rather than under the control, because at\r\n              half width there is no room for a sentence -- and truncated help is worse than none.\r\n\r\n              CSS-only, and deliberately: `group-hover` AND `group-focus-within` means it opens for a\r\n              pointer and for the keyboard without a click handler or a signal. `type=\"button\"` stops\r\n              it submitting the form, and the panel carries `role=\"tooltip\"` with the button pointing\r\n              at it through `aria-describedby`, so a screen reader reads the description on focus\r\n              rather than only on hover. A `title` attribute would have been shorter and is neither\r\n              styleable nor reliably announced.\r\n            -->\r\n            <span class=\"cws:group cws:relative cws:shrink-0 cws:pb-2 cws:leading-none\">\r\n              <button\r\n                type=\"button\"\r\n                class=\"cws:flex cws:h-4 cws:w-4 cws:items-center cws:justify-center cws:rounded-full cws:border cws:border-slate-300 cws:text-[10px] cws:font-semibold cws:text-slate-500 cws:hover:border-slate-400 cws:hover:text-slate-700 cws:focus:outline-2 cws:focus:outline-offset-1 cws:focus:outline-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-400 cws:dark:hover:text-slate-200\"\r\n                [attr.aria-label]=\"'About ' + field.label\"\r\n                [attr.aria-describedby]=\"idPrefix() + field.componentName + '-tip'\"\r\n              >\r\n                i\r\n              </button>\r\n\r\n              <span\r\n                role=\"tooltip\"\r\n                [id]=\"idPrefix() + field.componentName + '-tip'\"\r\n                class=\"cws:pointer-events-none cws:absolute cws:right-0 cws:bottom-6 cws:z-20 cws:hidden cws:w-56 cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:p-2 cws:text-xs cws:font-normal cws:text-slate-600 cws:shadow-lg cws:group-focus-within:block cws:group-hover:block cws:dark:border-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\"\r\n              >\r\n                <span class=\"cws:block cws:font-mono cws:text-[10px] cws:text-slate-500 cws:dark:text-slate-400\">{{\r\n                  tip.ctrmField\r\n                }}</span>\r\n                {{ tip.note }}\r\n              </span>\r\n            </span>\r\n          }\r\n        }\r\n      </div>\r\n    }\r\n  }\r\n</ng-template>\r\n",
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.FormGroupDirective,
				selector: "[formGroup]",
				inputs: ["formGroup"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: DynamicFieldComponent,
				selector: "cms-dynamic-field",
				inputs: [
					"field",
					"state",
					"control",
					"idPrefix",
					"hideLabel"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ContractFormComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-contract-form",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				NgTemplateOutlet,
				ReactiveFormsModule,
				DynamicFieldComponent
			],
			providers: [FormBuilderService],
			host: { class: "cws:block" },
			template: "@if (form(); as contractForm) {\r\n  <!--\r\n    novalidate: validation is the form engine's, driven by constraints.json and the rules. The\r\n    browser's own bubbles would compete with the inline messages and say different things.\r\n  -->\r\n  <form [formGroup]=\"contractForm.group\" novalidate>\r\n    <!--\r\n      🔴 SECTIONS ARE FULL WIDTH AND STACKED, and the fields inside them run in a wide responsive\r\n      grid. That inversion is the main readability fix of 2026-09-01 and it is worth stating, because\r\n      the previous version looks more organised and reads far worse.\r\n\r\n      It was `lg:grid-cols-2` cards, each with `sm:grid-cols-2` fields — so on a wide screen the page\r\n      carried **four columns of label/value pairs that did not line up with each other**, because each\r\n      card sized its own two columns independently. Two adjacent cards of unequal length then left\r\n      ragged whitespace down the middle, and the eye had no consistent column to follow. JFrisbie's\r\n      words were \"the layout is a little confusing\".\r\n\r\n      Full-width cards give every field on the page the same column grid, so the columns align all the\r\n      way down and a section heading reads as a horizontal rule between groups. The shell is 1800px, so\r\n      `2xl:grid-cols-4` uses the width the record screen actually has instead of wasting half of it.\r\n    -->\r\n    <div class=\"cws:space-y-4\">\r\n      @for (section of sections(); track section.componentName) {\r\n        <!--\r\n          ⚠ `data-section` is load-bearing rather than a test hook: `Ctrl+PgDn` / `Ctrl+PgUp`\r\n          (docs/02a §4.2) step between sections and need something addressable to scroll to and focus\r\n          into. Keyed on `componentName` because that is the identity the configuration orders by —\r\n          the visible label is a presentation string a trade unit may change.\r\n        -->\r\n        <div\r\n          [attr.data-section]=\"section.componentName\"\r\n          class=\"cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-4 cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:shadow-none\"\r\n        >\r\n          <!-- h3, matching the rest of the record screen: the shell owns the h1 and the page the h2. -->\r\n          <h3 class=\"cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n            {{ section.label }}\r\n          </h3>\r\n\r\n          @if (sectionNotes()[section.componentName]; as note) {\r\n            <!--\r\n              What the section deliberately does not carry — shipment dates living in a collection,\r\n              a customer name no route returns. Stated inside the section it applies to, because a\r\n              gap named at the top of the page is a gap nobody connects to the field in front of\r\n              them.\r\n            -->\r\n            <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">{{ note }}</p>\r\n          }\r\n\r\n          <!--\r\n            Fields are emitted in configured order and the grid flows in DOM order, so tab order\r\n            follows field order without any tabindex (02a §4.2).\r\n\r\n            ⚠ The column count climbs with the viewport and the ORDER does not change with it — CSS\r\n            grid fills row-major, so field 1 is top-left at every breakpoint. A `grid-flow-col` would\r\n            reorder the fields as the window resized, which is the one thing a form must not do.\r\n          -->\r\n          <div\r\n            class=\"cws:mt-3 cws:grid cws:gap-x-6 cws:gap-y-3 cws:border-t cws:border-slate-100 cws:pt-4 cws:sm:grid-cols-2 cws:xl:grid-cols-3 cws:2xl:grid-cols-4 cws:dark:border-slate-700/60\"\r\n          >\r\n            <!--\r\n              Rows, not fields. A row is one ordinary field, or a PAIR of half fields sharing a single\r\n              grid cell — see `rowsFor`. Iterating fields directly cannot express the pair, because two\r\n              adjacent cells are two columns however narrow their contents are.\r\n            -->\r\n            @for (row of rowsFor(section); track row.key) {\r\n              <!--\r\n                A group heading, rendered above the field that introduces the group and spanning the\r\n                grid's full width so the members below read as one identifier (#196).\r\n\r\n                🔴 `aria-hidden`, and that is the whole point of the mechanism. Every field in the\r\n                group carries its own `sr-only` label naming itself, so the heading is decoration for\r\n                sighted readers only — announcing it as well would repeat \"Contract number\" on each of\r\n                the four controls. Previously the heading WAS the first field's label, which is what\r\n                left two inputs sharing one accessible name.\r\n              -->\r\n              @if (groupHeadings()[row.fields[0].componentName]; as heading) {\r\n                <p\r\n                  class=\"scoular-form-label cws:col-span-full cws:-mb-1\"\r\n                  aria-hidden=\"true\"\r\n                >\r\n                  {{ heading }}\r\n                </p>\r\n              }\r\n\r\n              @if (row.fields.length > 1) {\r\n                <!--\r\n                  Two half-width boxes inside one column. `gap-x-3` is half the grid's own `gap-x-6`,\r\n                  so the pair reads as one field's worth of space rather than as two fields that\r\n                  happen to be close.\r\n                -->\r\n                <div class=\"cws:grid cws:grid-cols-2 cws:items-start cws:gap-x-3\">\r\n                  @for (field of row.fields; track field.componentName) {\r\n                    <ng-container [ngTemplateOutlet]=\"cell\" [ngTemplateOutletContext]=\"{ field }\" />\r\n                  }\r\n                </div>\r\n              } @else {\r\n                <!--\r\n                  A wide field takes two columns at every breakpoint rather than the whole row.\r\n                  `col-span-2` alone would have made it full-width at `sm` (2 columns) and a third of\r\n                  a row at `2xl` (4 columns) — the same class meaning something different at each\r\n                  size. Two columns is \"this value needs more room than a code\", which is what the\r\n                  flag actually says.\r\n                -->\r\n                <div [class.cws:sm:col-span-2]=\"wideFields()[row.fields[0].componentName]\">\r\n                  <ng-container\r\n                    [ngTemplateOutlet]=\"cell\"\r\n                    [ngTemplateOutletContext]=\"{ field: row.fields[0] }\"\r\n                  />\r\n                </div>\r\n              }\r\n            }\r\n          </div>\r\n        </div>\r\n      }\r\n    </div>\r\n  </form>\r\n}\r\n\r\n<!--\r\n  One field's cell, single-sourced so an ordinary field and a half field cannot drift apart.\r\n\r\n  `fieldStates()`, not `contractForm.states()`. The engine's state says what configuration and the\r\n  rules make of the field; this map is the same thing with the screen's read-only overrides folded in\r\n  — view mode, and the fields CTRM refuses on a write. Reading the engine's map directly here is what\r\n  would make view mode editable, so the indirection is load-bearing rather than a wrapper.\r\n-->\r\n<ng-template #cell let-field=\"field\">\r\n  @if (controlFor(field.componentName); as control) {\r\n    @if (fieldStates().get(field.componentName); as state) {\r\n      <!--\r\n        A half field becomes a flex ROW: the control, then the \"i\" to the RIGHT of the input box.\r\n\r\n        ⚠ It used to be `absolute bottom-2 right-2` inside the cell, and that was wrong in a way only a\r\n        screenshot showed: paired cells stretch to equal height, so when one label wrapped the taller\r\n        cell dragged the \"i\" down BELOW the shorter input. A flex row cannot do that -- the button is a\r\n        sibling of the control, so it tracks the input rather than the cell.\r\n\r\n        `items-end` lines the button up with the bottom of the input, and `pb-2` lifts it to the\r\n        input's vertical middle. `min-w-0` on the control is what lets the label inside it truncate:\r\n        without it a flex item refuses to shrink below its content and the label wraps again.\r\n      -->\r\n      <div\r\n        [class.cws:flex]=\"halfFields()[field.componentName]\"\r\n        [class.cws:items-end]=\"halfFields()[field.componentName]\"\r\n        [class.cws:gap-1]=\"halfFields()[field.componentName]\"\r\n      >\r\n        <div\r\n          [class.cws:min-w-0]=\"halfFields()[field.componentName]\"\r\n          [class.cws:flex-1]=\"halfFields()[field.componentName]\"\r\n          (focusout)=\"onFieldFocusOut(field.componentName)\"\r\n        >\r\n          <cms-dynamic-field\r\n            [field]=\"field\"\r\n            [state]=\"state\"\r\n            [control]=\"control\"\r\n            [idPrefix]=\"idPrefix()\"\r\n            [hideLabel]=\"hiddenLabelFields()[field.componentName] === true\"\r\n          />\r\n\r\n          @if (!halfFields()[field.componentName] && noteFor(field.componentName); as note) {\r\n            <!--\r\n              Help text, not an error. `aria-describedby` is not wired here because\r\n              <cms-dynamic-field> owns the control's id and its own description element; adding a\r\n              second describedby from outside would need the renderer to accept one, which is a change\r\n              to the shared control rather than to this screen. Sighted and screen-reader users both\r\n              get the text in reading order.\r\n            -->\r\n            <p class=\"cws:mt-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              {{ note }}\r\n            </p>\r\n          }\r\n        </div>\r\n\r\n        @if (halfFields()[field.componentName]) {\r\n          @if (tooltipFor(field.componentName); as tip) {\r\n            <!--\r\n              🔴 A half field's help text moves into an \"i\" rather than under the control, because at\r\n              half width there is no room for a sentence -- and truncated help is worse than none.\r\n\r\n              CSS-only, and deliberately: `group-hover` AND `group-focus-within` means it opens for a\r\n              pointer and for the keyboard without a click handler or a signal. `type=\"button\"` stops\r\n              it submitting the form, and the panel carries `role=\"tooltip\"` with the button pointing\r\n              at it through `aria-describedby`, so a screen reader reads the description on focus\r\n              rather than only on hover. A `title` attribute would have been shorter and is neither\r\n              styleable nor reliably announced.\r\n            -->\r\n            <span class=\"cws:group cws:relative cws:shrink-0 cws:pb-2 cws:leading-none\">\r\n              <button\r\n                type=\"button\"\r\n                class=\"cws:flex cws:h-4 cws:w-4 cws:items-center cws:justify-center cws:rounded-full cws:border cws:border-slate-300 cws:text-[10px] cws:font-semibold cws:text-slate-500 cws:hover:border-slate-400 cws:hover:text-slate-700 cws:focus:outline-2 cws:focus:outline-offset-1 cws:focus:outline-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-400 cws:dark:hover:text-slate-200\"\r\n                [attr.aria-label]=\"'About ' + field.label\"\r\n                [attr.aria-describedby]=\"idPrefix() + field.componentName + '-tip'\"\r\n              >\r\n                i\r\n              </button>\r\n\r\n              <span\r\n                role=\"tooltip\"\r\n                [id]=\"idPrefix() + field.componentName + '-tip'\"\r\n                class=\"cws:pointer-events-none cws:absolute cws:right-0 cws:bottom-6 cws:z-20 cws:hidden cws:w-56 cws:rounded cws:border cws:border-slate-200 cws:bg-white cws:p-2 cws:text-xs cws:font-normal cws:text-slate-600 cws:shadow-lg cws:group-focus-within:block cws:group-hover:block cws:dark:border-slate-600 cws:dark:bg-slate-800 cws:dark:text-slate-300\"\r\n              >\r\n                <span class=\"cws:block cws:font-mono cws:text-[10px] cws:text-slate-500 cws:dark:text-slate-400\">{{\r\n                  tip.ctrmField\r\n                }}</span>\r\n                {{ tip.note }}\r\n              </span>\r\n            </span>\r\n          }\r\n        }\r\n      </div>\r\n    }\r\n  }\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		config: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "config",
				required: true
			}]
		}],
		tradeUnit: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tradeUnit",
				required: true
			}]
		}],
		facts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "facts",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		instanceId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "instanceId",
				required: false
			}]
		}],
		visibleSections: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visibleSections",
				required: false
			}]
		}],
		fieldNotes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldNotes",
				required: false
			}]
		}],
		emptyNotes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyNotes",
				required: false
			}]
		}],
		sectionNotes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sectionNotes",
				required: false
			}]
		}],
		wideFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wideFields",
				required: false
			}]
		}],
		halfFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "halfFields",
				required: false
			}]
		}],
		fieldCtrmNames: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldCtrmNames",
				required: false
			}]
		}],
		hiddenLabelFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hiddenLabelFields",
				required: false
			}]
		}],
		groupHeadings: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "groupHeadings",
				required: false
			}]
		}],
		readOnlyFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnlyFields",
				required: false
			}]
		}],
		initialValues: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initialValues",
				required: false
			}]
		}],
		defaultValues: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "defaultValues",
				required: false
			}]
		}],
		ready: [{
			type: i0.Output,
			args: ["ready"]
		}],
		fieldBlur: [{
			type: i0.Output,
			args: ["fieldBlur"]
		}]
	}
});
const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 200;
const hasScope = (query) => Boolean(query.tradeUnit?.trim() || query.customerId?.trim());
const initialQuery = () => ({
	status: "Open",
	page: 1,
	pageSize: 50
});
const CONTRACT_LIST_SOURCE = new InjectionToken("CONTRACT_LIST_SOURCE");
function toSortParam(sorts) {
	if (sorts.length === 0) return;
	return sorts.map((sort) => `${sort.key}:${sort.direction}`).join(",");
}
function parseSortParam(sort) {
	if (!sort) return [];
	return sort.split(",").map((entry) => entry.trim()).filter((entry) => entry !== "").map((entry) => {
		const [key, direction] = entry.split(":");
		return {
			key: key.trim(),
			direction: direction?.trim() === "desc" ? "desc" : "asc"
		};
	}).filter((sortEntry) => sortEntry.key !== "");
}
function isServerSorted(requested, applied) {
	return requested !== void 0 && applied === requested;
}
const REDACTION_LITERAL = "[REDACTED]";
function isRedactedName(value) {
	return value?.trim().toUpperCase() === REDACTION_LITERAL;
}
function customerDisplayName(name, id, absent = "") {
	return (isRedactedName(name) ? null : name?.trim()) || id?.trim() || absent;
}
var SampleContractListSource = class SampleContractListSource {
	all = buildContracts();
	list(query, _options) {
		if (!hasScope(query)) throw new Error("A trade unit or a customer is required. CTRM does not serve an unfiltered contract list.");
		return of(remoteLoaded(project(this.all, query)));
	}
	loading() {
		return of(remoteLoading());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleContractListSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleContractListSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleContractListSource,
	decorators: [{ type: Injectable }]
});
function project(rows, query) {
	const matched = rows.filter((row) => matches(row, query)).sort(compare);
	const skip = (query.page - 1) * query.pageSize;
	return {
		rows: matched.slice(skip, skip + query.pageSize),
		totalCount: matched.length,
		page: query.page,
		pageSize: query.pageSize,
		totalPages: matched.length <= 0 ? 1 : Math.ceil(matched.length / query.pageSize),
		dataOrigin: "Simulated",
		filteredInProcess: true,
		warnings: []
	};
}
function matches(row, query) {
	return is(row.customerId, query.customerId) && is(row.tradeUnit, query.tradeUnit) && is(row.commodity, query.commodity) && is(row.traderInitials, query.traderInitials) && is(row.marketZone, query.marketZone) && matchesSearch(row, query.search);
}
const is = (value, filter) => !filter?.trim() || value?.toLowerCase() === filter.trim().toLowerCase();
function matchesSearch(row, search) {
	const term = search?.trim().toLowerCase();
	if (!term) return true;
	return [
		row.contractNumber,
		row.customerId,
		row.customerName,
		row.customerContract,
		row.commodity,
		row.traderInitials,
		row.trader
	].some((value) => value?.toLowerCase().includes(term));
}
function compare(left, right) {
	const byDate = (right.contractDate ?? "").localeCompare(left.contractDate ?? "");
	return byDate !== 0 ? byDate : left.contractNumber.localeCompare(right.contractNumber);
}
const COMMODITIES = [
	["CRN", "Corn"],
	["SBN", "Soybeans"],
	["WHT", "Wheat"],
	["SRG", "Grain Sorghum"],
	["SBM", "Soybean Meal"],
	["OAT", "Oats"]
];
const SAMPLE_LOCATIONS = [
	{
		code: "0210",
		name: "Omaha Terminal",
		companyCode: "20",
		companyName: "THE SCOULAR COMPANY",
		divisionCode: "10",
		divisionName: "MERCHANDISING"
	},
	{
		code: "0315",
		name: "Council Bluffs Elevator",
		companyCode: "20",
		companyName: "THE SCOULAR COMPANY",
		divisionCode: "35",
		divisionName: "OPERATIONS"
	},
	{
		code: "0428",
		name: "Salina Processing",
		companyCode: "20",
		companyName: "THE SCOULAR COMPANY",
		divisionCode: "50",
		divisionName: "COMMODITY MARKETING DIVISION"
	},
	{
		code: "0533",
		name: "Kansas City Rail",
		companyCode: "22",
		companyName: "SCOULAR CANADA, ULC",
		divisionCode: "35",
		divisionName: "SCOULAR CANADA LTD"
	},
	{
		code: "0641",
		name: "Sioux City Elevator",
		companyCode: "42",
		companyName: "SCOULAR CANADA, ULC",
		divisionCode: "10",
		divisionName: "MERCHANDISING"
	},
	{
		code: "0755",
		name: "Topeka Elevator",
		companyCode: "30",
		companyName: "TSC CANADIAN DOLLARS",
		divisionCode: "50",
		divisionName: "COMMODITY MARKETING DIVISION"
	}
];
const MARKET_ZONES = [
	"CIF",
	"PNW",
	"EMS",
	"WMS"
];
const PRICE_TYPES = [
	"FLAT",
	"BASIS",
	"HTA",
	"MIN"
];
const APPROVAL_STATUSES = [
	"Approved",
	"Approved",
	"Approved",
	"Unapproved",
	"Rejected"
];
const DESTINATIONS = [
	"Blair Processing",
	"NOLA Export",
	"Tacoma Export",
	"Hereford Feedlot",
	"Guadalajara Mill"
];
const TRADERS = [
	["JRB", "J. Brandt"],
	["MKD", "M. Delgado"],
	["TAO", "T. Osei"],
	["LNP", "L. Novak"],
	["SRW", "S. Whitfield"]
];
const SAMPLE_CUSTOMERS = [
	["1004421", "Prairie Feed Cooperative"],
	["1004612", "Midland Grain Partners"],
	["1005108", "Cornerstone Milling"],
	["1005733", "Great Plains Ethanol"],
	["1006204", "Rivergate Trading"],
	["1006990", "Northline Poultry"]
];
const PAYMENT_TERMS = [
	"Net 10 days",
	"Net 30 days",
	"Cash against documents"
];
const CONTRACT_COUNT = 240;
function mulberry32(seed) {
	let state = seed;
	return () => {
		state = state + 1831565813 | 0;
		let t = state;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function buildContracts(today = /* @__PURE__ */ new Date("2026-08-21T00:00:00Z")) {
	const random = mulberry32(20260819);
	const pick = (items) => items[Math.floor(random() * items.length)];
	const between = (min, max) => min + Math.floor(random() * (max - min));
	const rows = [];
	for (let index = 0; index < CONTRACT_COUNT; index += 1) {
		const [commodityCode, commodityName] = pick(COMMODITIES);
		const location = pick(SAMPLE_LOCATIONS);
		const [initials, traderName] = pick(TRADERS);
		const [customerId, customerName] = pick(SAMPLE_CUSTOMERS);
		const contractDate = addDays(today, -between(1, 540));
		const quantity = 500 * between(1, 60);
		const basisPrice = round(random() * 1.6 - .6, 4);
		const futuresPrice = round(4.1 + random() * 3.4, 4);
		const priceType = pick(PRICE_TYPES);
		const isPriced = priceType !== "BASIS";
		const priced = isPriced ? quantity : 500 * between(0, Math.max(quantity / 500, 1));
		const shipped = 500 * between(0, Math.max(priced / 500, 1));
		const number = 124e4 + index * 7;
		const shipBegin = addDays(contractDate, between(20, 120));
		const suffix = index % 11 === 0 ? "-A" : "";
		const prefixType = index % 5 === 2 ? "P" : "S";
		rows.push({
			contractNumber: prefixType + commodityCode[0] + number + suffix,
			tradeUnit: location.code,
			contractDate: isoDate(contractDate),
			customerId,
			customerName,
			customerContract: "PO-" + between(1e4, 99999),
			commodity: commodityName,
			quantity,
			quantityUom: "BU",
			unpricedQuantity: quantity - priced,
			appliedQuantity: shipped,
			openQuantity: quantity - shipped,
			price: isPriced ? round(futuresPrice + basisPrice, 4) : null,
			basisPrice,
			priceTypeCode: priceType,
			paymentTerms: pick(PAYMENT_TERMS),
			marketZone: pick(MARKET_ZONES),
			traderInitials: initials,
			trader: traderName,
			originName: location.name,
			destinationName: pick(DESTINATIONS),
			shipPeriodBegin: isoDate(shipBegin),
			shipPeriodEnd: isoDate(addDays(shipBegin, between(20, 60))),
			traderApprovalStatus: pick(APPROVAL_STATUSES),
			customerConfirmStatus: between(0, 3) === 0 ? "Pending" : "Confirmed",
			brokerConfirmStatus: between(0, 4) === 0 ? "Pending" : null,
			isClosed: index % 9 === 4,
			isIntercompany: index % 13 === 7 ? null : customerId === INTERCOMPANY_CUSTOMER
		});
	}
	return rows;
}
const INTERCOMPANY_CUSTOMER = "1006204";
const addDays = (date, days) => new Date(date.getTime() + days * 24 * 60 * 60 * 1e3);
const isoDate = (date) => date.toISOString().slice(0, 10);
const round = (value, places) => {
	const factor = 10 ** places;
	return Math.round(value * factor) / factor;
};
const CUSTOMER_SOURCE = new InjectionToken("CUSTOMER_SOURCE");
var HttpCustomerSource = class HttpCustomerSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	answers = /* @__PURE__ */ new Map();
	lookup(customerId) {
		const id = customerId.trim();
		if (id === "") return of(remoteLoaded({
			customerId: "",
			name: null,
			availability: "Unknown"
		}));
		let answer = this.answers.get(id);
		if (answer === void 0) {
			answer = this.fetch(id);
			this.answers.set(id, answer);
		}
		return answer;
	}
	fetch(id) {
		return this.http.get(`${this.baseUrl}/customers/${encodeURIComponent(id)}`).pipe(map((lookup) => remoteLoaded(lookup)), catchError((error) => of(remoteError(toRemoteError$5(error)))), tap((state) => {
			if (state.status === "error") this.answers.delete(id);
		}), startWith(remoteLoading()), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpCustomerSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpCustomerSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpCustomerSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError$5(error) {
	if (error instanceof HttpErrorResponse && (error.status === 401 || error.status === 403)) return { message: "You are not signed in, or your account cannot look up customers." };
	return { message: "The customer lookup is not available right now." };
}
const SAMPLE_REDACTED_CUSTOMER_ID = "1009999";
var SampleCustomerSource = class SampleCustomerSource {
	names = new Map(SAMPLE_CUSTOMERS);
	lookup(customerId) {
		const id = customerId.trim();
		if (id === "1009999") return of(remoteLoaded({
			customerId: id,
			name: null,
			availability: "Redacted"
		}));
		const name = this.names.get(id);
		return of(remoteLoaded({
			customerId: id,
			name: name ?? null,
			availability: name === void 0 ? "Unknown" : "Resolved"
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleCustomerSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleCustomerSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleCustomerSource,
	decorators: [{ type: Injectable }]
});
var CustomerCellComponent = class CustomerCellComponent {
	row = input.required(...ngDevMode ? [{ debugName: "row" }] : /* istanbul ignore next */ []);
	source = inject(CUSTOMER_SOURCE, { optional: true });
	overlay = inject(Overlay);
	canLookUp = computed(() => this.source !== null && Boolean(this.row().customerId?.trim()), ...ngDevMode ? [{ debugName: "canLookUp" }] : /* istanbul ignore next */ []);
	destroyRef = inject(DestroyRef);
	subscription = null;
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	lookup = signal(null, ...ngDevMode ? [{ debugName: "lookup" }] : /* istanbul ignore next */ []);
	display = computed(() => customerDisplayName(this.row().customerName, this.row().customerId), ...ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []);
	scroll = this.overlay.scrollStrategies.reposition();
	positions = [{
		originX: "start",
		originY: "bottom",
		overlayX: "start",
		overlayY: "top",
		offsetY: 4
	}, {
		originX: "start",
		originY: "top",
		overlayX: "start",
		overlayY: "bottom",
		offsetY: -4
	}];
	nameOf(value) {
		return isRedactedName(value.name) ? null : value.name?.trim() || null;
	}
	toggle(event) {
		event.stopPropagation();
		if (this.open()) this.close();
		else this.show();
	}
	show() {
		this.open.set(true);
		const id = this.row().customerId?.trim();
		const current = this.lookup();
		const source = this.source;
		if (id && source !== null && (current === null || current.status === "error")) {
			this.subscription?.unsubscribe();
			this.subscription = source.lookup(id).pipe(takeUntilDestroyed(this.destroyRef)).subscribe((state) => this.lookup.set(state));
		}
	}
	close() {
		this.open.set(false);
	}
	stop(event) {
		event.stopPropagation();
	}
	onTriggerKeydown(event) {
		if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") event.stopPropagation();
	}
	onOverlayKeydown(event) {
		if (event.key === "Escape") {
			event.stopPropagation();
			this.close();
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: CustomerCellComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: CustomerCellComponent,
		isStandalone: true,
		selector: "cms-customer-cell",
		inputs: { row: {
			classPropertyName: "row",
			publicName: "row",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { classAttribute: "cws:block cws:min-w-0" },
		ngImport: i0,
		template: "<span class=\"cws:flex cws:min-w-0 cws:items-center cws:gap-1\">\r\n  <!-- The text the column always showed. `title` for the same reason every cell carries one. -->\r\n  <span class=\"truncate\" [attr.title]=\"display() || null\">{{ display() }}</span>\r\n\r\n  @if (canLookUp() && row().customerId; as id) {\r\n    <!--\r\n      The trigger, offered only where a lookup source is provided and the row carries an id. mousedown\r\n      and dblclick are stopped so the grid neither selects the cell nor opens the record; Enter and\r\n      Space are stopped so the row does not treat them as \"open\". `aria-haspopup=\"dialog\"` and\r\n      `aria-expanded` say what the button does before it is pressed.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:shrink-0 cws:rounded cws:px-1 cws:text-xs cws:leading-none cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue\"\r\n      cdkOverlayOrigin\r\n      #origin=\"cdkOverlayOrigin\"\r\n      [attr.aria-label]=\"'Look up customer ' + id\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      aria-haspopup=\"dialog\"\r\n      (mousedown)=\"stop($event)\"\r\n      (dblclick)=\"stop($event)\"\r\n      (click)=\"toggle($event)\"\r\n      (keydown)=\"onTriggerKeydown($event)\"\r\n    >\r\n      ⓘ\r\n    </button>\r\n\r\n    <!--\r\n      A CDK connected overlay rather than an in-cell panel: the cell is `truncate`, so anything inside\r\n      it is clipped to one line. Outside click and Escape both close it.\r\n    -->\r\n    <ng-template\r\n      cdkConnectedOverlay\r\n      [cdkConnectedOverlayOrigin]=\"origin\"\r\n      [cdkConnectedOverlayOpen]=\"open()\"\r\n      [cdkConnectedOverlayPositions]=\"positions\"\r\n      [cdkConnectedOverlayScrollStrategy]=\"scroll\"\r\n      (overlayOutsideClick)=\"close()\"\r\n      (overlayKeydown)=\"onOverlayKeydown($event)\"\r\n    >\r\n      <div\r\n        class=\"scoular-card cws:w-80 cws:p-3 cws:text-sm cws:shadow-lg\"\r\n        role=\"dialog\"\r\n        [attr.aria-label]=\"'Customer ' + id\"\r\n        (mousedown)=\"stop($event)\"\r\n        (dblclick)=\"stop($event)\"\r\n        (click)=\"stop($event)\"\r\n      >\r\n        @if (lookup(); as state) {\r\n          @if (state.status === 'loaded') {\r\n            @switch (state.value.availability) {\r\n              @case ('Resolved') {\r\n                @if (nameOf(state.value); as name) {\r\n                  <p class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ name }}</p>\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                } @else {\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                  <p>The customer directory returned no usable name for this account.</p>\r\n                }\r\n              }\r\n              @case ('Redacted') {\r\n                <!-- A notice, never a blank. It will not clear by retrying, so it says who to ask. -->\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <p class=\"cws:mt-1 cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-2 cws:py-1 cws:text-amber-900 cws:dark:border-amber-700 cws:dark:bg-amber-950 cws:dark:text-amber-200\">\r\n                  The customer's name is withheld for this application. The account number is\r\n                  correct; showing the name needs a person to enable it.\r\n                </p>\r\n              }\r\n              @case ('Unknown') {\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <p>No customer record matches this account number.</p>\r\n              }\r\n            }\r\n          } @else if (state.status === 'error') {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n            <p>{{ state.error.message }}</p>\r\n          } @else {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n          }\r\n        } @else {\r\n          <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n        }\r\n\r\n        <!-- Stated, not built: no contract carries a phone number, and none is invented here. -->\r\n        <p class=\"cws:mt-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400\">\r\n          Teams call: not available. The contract carries no phone number.\r\n        </p>\r\n      </div>\r\n    </ng-template>\r\n  }\r\n</span>\r\n",
		dependencies: [{
			kind: "directive",
			type: CdkConnectedOverlay,
			selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]",
			inputs: [
				"cdkConnectedOverlayOrigin",
				"cdkConnectedOverlayPositions",
				"cdkConnectedOverlayPositionStrategy",
				"cdkConnectedOverlayOffsetX",
				"cdkConnectedOverlayOffsetY",
				"cdkConnectedOverlayWidth",
				"cdkConnectedOverlayHeight",
				"cdkConnectedOverlayMinWidth",
				"cdkConnectedOverlayMinHeight",
				"cdkConnectedOverlayBackdropClass",
				"cdkConnectedOverlayPanelClass",
				"cdkConnectedOverlayViewportMargin",
				"cdkConnectedOverlayScrollStrategy",
				"cdkConnectedOverlayOpen",
				"cdkConnectedOverlayDisableClose",
				"cdkConnectedOverlayTransformOriginOn",
				"cdkConnectedOverlayHasBackdrop",
				"cdkConnectedOverlayLockPosition",
				"cdkConnectedOverlayFlexibleDimensions",
				"cdkConnectedOverlayGrowAfterOpen",
				"cdkConnectedOverlayPush",
				"cdkConnectedOverlayDisposeOnNavigation",
				"cdkConnectedOverlayUsePopover",
				"cdkConnectedOverlayMatchWidth",
				"cdkConnectedOverlay"
			],
			outputs: [
				"backdropClick",
				"positionChange",
				"attach",
				"detach",
				"overlayKeydown",
				"overlayOutsideClick"
			],
			exportAs: ["cdkConnectedOverlay"]
		}, {
			kind: "directive",
			type: CdkOverlayOrigin,
			selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]",
			exportAs: ["cdkOverlayOrigin"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: CustomerCellComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-customer-cell",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [CdkConnectedOverlay, CdkOverlayOrigin],
			host: { class: "cws:block cws:min-w-0" },
			template: "<span class=\"cws:flex cws:min-w-0 cws:items-center cws:gap-1\">\r\n  <!-- The text the column always showed. `title` for the same reason every cell carries one. -->\r\n  <span class=\"truncate\" [attr.title]=\"display() || null\">{{ display() }}</span>\r\n\r\n  @if (canLookUp() && row().customerId; as id) {\r\n    <!--\r\n      The trigger, offered only where a lookup source is provided and the row carries an id. mousedown\r\n      and dblclick are stopped so the grid neither selects the cell nor opens the record; Enter and\r\n      Space are stopped so the row does not treat them as \"open\". `aria-haspopup=\"dialog\"` and\r\n      `aria-expanded` say what the button does before it is pressed.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:shrink-0 cws:rounded cws:px-1 cws:text-xs cws:leading-none cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-scoular-blue\"\r\n      cdkOverlayOrigin\r\n      #origin=\"cdkOverlayOrigin\"\r\n      [attr.aria-label]=\"'Look up customer ' + id\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      aria-haspopup=\"dialog\"\r\n      (mousedown)=\"stop($event)\"\r\n      (dblclick)=\"stop($event)\"\r\n      (click)=\"toggle($event)\"\r\n      (keydown)=\"onTriggerKeydown($event)\"\r\n    >\r\n      ⓘ\r\n    </button>\r\n\r\n    <!--\r\n      A CDK connected overlay rather than an in-cell panel: the cell is `truncate`, so anything inside\r\n      it is clipped to one line. Outside click and Escape both close it.\r\n    -->\r\n    <ng-template\r\n      cdkConnectedOverlay\r\n      [cdkConnectedOverlayOrigin]=\"origin\"\r\n      [cdkConnectedOverlayOpen]=\"open()\"\r\n      [cdkConnectedOverlayPositions]=\"positions\"\r\n      [cdkConnectedOverlayScrollStrategy]=\"scroll\"\r\n      (overlayOutsideClick)=\"close()\"\r\n      (overlayKeydown)=\"onOverlayKeydown($event)\"\r\n    >\r\n      <div\r\n        class=\"scoular-card cws:w-80 cws:p-3 cws:text-sm cws:shadow-lg\"\r\n        role=\"dialog\"\r\n        [attr.aria-label]=\"'Customer ' + id\"\r\n        (mousedown)=\"stop($event)\"\r\n        (dblclick)=\"stop($event)\"\r\n        (click)=\"stop($event)\"\r\n      >\r\n        @if (lookup(); as state) {\r\n          @if (state.status === 'loaded') {\r\n            @switch (state.value.availability) {\r\n              @case ('Resolved') {\r\n                @if (nameOf(state.value); as name) {\r\n                  <p class=\"cws:font-medium cws:text-slate-900 cws:dark:text-white\">{{ name }}</p>\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                } @else {\r\n                  <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                  <p>The customer directory returned no usable name for this account.</p>\r\n                }\r\n              }\r\n              @case ('Redacted') {\r\n                <!-- A notice, never a blank. It will not clear by retrying, so it says who to ask. -->\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <p class=\"cws:mt-1 cws:rounded cws:border cws:border-amber-300 cws:bg-amber-50 cws:px-2 cws:py-1 cws:text-amber-900 cws:dark:border-amber-700 cws:dark:bg-amber-950 cws:dark:text-amber-200\">\r\n                  The customer's name is withheld for this application. The account number is\r\n                  correct; showing the name needs a person to enable it.\r\n                </p>\r\n              }\r\n              @case ('Unknown') {\r\n                <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n                <p>No customer record matches this account number.</p>\r\n              }\r\n            }\r\n          } @else if (state.status === 'error') {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Account {{ id }}</p>\r\n            <p>{{ state.error.message }}</p>\r\n          } @else {\r\n            <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n          }\r\n        } @else {\r\n          <p class=\"cws:text-slate-500 cws:dark:text-slate-400\">Looking up the customer…</p>\r\n        }\r\n\r\n        <!-- Stated, not built: no contract carries a phone number, and none is invented here. -->\r\n        <p class=\"cws:mt-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:text-slate-400\">\r\n          Teams call: not available. The contract carries no phone number.\r\n        </p>\r\n      </div>\r\n    </ng-template>\r\n  }\r\n</span>\r\n"
		}]
	}],
	propDecorators: { row: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "row",
			required: true
		}]
	}] }
});
const ACTIONS = [
	"Create",
	"Update",
	"Approve",
	"Reject",
	"StatusChange",
	"PriceCreate",
	"PriceUpdate",
	"PriceDelete",
	"PriceApprove",
	"Note",
	"EmailUpdate",
	"ConfigChange",
	"TemplateChange",
	"ReservationSwept",
	"AddendumCreate",
	"RoleChange",
	"RoleAssignmentChange"
];
function auditActionOf(value) {
	if (typeof value === "number" && Number.isInteger(value)) return ACTIONS[value] ?? "Unknown";
	if (typeof value === "string") return ACTIONS.find((action) => action === value) ?? "Unknown";
	return "Unknown";
}
const NOTES_WARNING = "NotesErrorSQLCode";
const ACTION_LABELS = {
	Create: "Contract created",
	Update: "Contract updated",
	Approve: "Approved",
	Reject: "Rejected",
	StatusChange: "Status changed",
	PriceCreate: "Price added",
	PriceUpdate: "Price updated",
	PriceDelete: "Price removed",
	PriceApprove: "Price approved",
	Note: "Note added",
	EmailUpdate: "Email updated",
	ConfigChange: "Configuration changed",
	TemplateChange: "Template changed",
	ReservationSwept: "Reserved number released",
	AddendumCreate: "Addendum created",
	RoleChange: "Role changed",
	RoleAssignmentChange: "Role assignment changed",
	Unknown: "Change recorded"
};
function describeAuditAction(action) {
	return ACTION_LABELS[action] ?? ACTION_LABELS.Unknown;
}
function auditChangesOf(detailsJson) {
	if (detailsJson === null || detailsJson.trim() === "") return null;
	let parsed;
	try {
		parsed = JSON.parse(detailsJson);
	} catch {
		return null;
	}
	if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return null;
	const record = parsed;
	const changes = Array.isArray(record.changes) ? record.changes.flatMap((row) => {
		const change = row ?? {};
		return typeof change.field === "string" && change.field.trim() !== "" ? [{
			field: change.field,
			from: valueText(change.from),
			to: valueText(change.to)
		}] : [];
	}) : [];
	const collectionsReplaced = Array.isArray(record.collectionsReplaced) ? record.collectionsReplaced.filter((name) => typeof name === "string" && name.trim() !== "") : [];
	return changes.length === 0 && collectionsReplaced.length === 0 ? null : {
		changes,
		collectionsReplaced
	};
}
function valueText(value) {
	if (value === null || value === void 0) return null;
	return typeof value === "string" || typeof value === "number" || typeof value === "boolean" ? String(value) : null;
}
const CONTRACT_LOG_SOURCE = new InjectionToken("CONTRACT_LOG_SOURCE");
var HttpContractLogSource = class HttpContractLogSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	audit(contractNumber) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/audit`;
		return this.http.get(url).pipe(map((rows) => remoteLoaded(rows.map((row) => toEntry(row)))), catchError(() => of(remoteError({ message: "The history for this contract could not be loaded." }))), startWith(remoteLoading()));
	}
	notifyTrader(contractNumber, message) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/notify-trader`;
		return this.http.post(url, { message });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractLogSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractLogSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractLogSource,
	decorators: [{ type: Injectable }]
});
function toEntry(row) {
	const record = row ?? {};
	return {
		id: typeof record["id"] === "number" ? record["id"] : 0,
		contractNumber: typeof record["contractNumber"] === "string" ? record["contractNumber"] : null,
		tradeUnit: typeof record["tradeUnit"] === "string" ? record["tradeUnit"] : "",
		action: auditActionOf(record["action"]),
		actorUpn: typeof record["actorUpn"] === "string" ? record["actorUpn"] : "",
		timestampUtc: typeof record["timestampUtc"] === "string" ? record["timestampUtc"] : "",
		detailsJson: typeof record["detailsJson"] === "string" ? record["detailsJson"] : null,
		correlationId: typeof record["correlationId"] === "string" ? record["correlationId"] : ""
	};
}
const CLOSE_PROVENANCE_WARNING = "closing rewrites pricing-approval provenance and cannot be undone";
const CONTRACT_STATE_SOURCE = new InjectionToken("CONTRACT_STATE_SOURCE");
var HttpContractStateSource = class HttpContractStateSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	close(contractNumber) {
		return this.post(contractNumber, "close");
	}
	reopen(contractNumber) {
		return this.post(contractNumber, "reopen");
	}
	post(contractNumber, action) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/${action}`;
		return this.http.post(url, null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractStateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractStateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractStateSource,
	decorators: [{ type: Injectable }]
});
function templateValuesOf(template) {
	try {
		const parsed = JSON.parse(template.payloadJson);
		return typeof parsed === "object" && parsed !== null && !Array.isArray(parsed) ? parsed : {};
	} catch {
		return {};
	}
}
const CONTRACT_TEMPLATE_SOURCE = new InjectionToken("CONTRACT_TEMPLATE_SOURCE");
var HttpContractTemplateSource = class HttpContractTemplateSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get templatesUrl() {
		return `${this.baseUrl}/templates`;
	}
	list(tradeUnit) {
		return this.http.get(this.templatesUrl, { params: new HttpParams().set("tradeUnit", tradeUnit) }).pipe(map((templates) => remoteLoaded(templates)), catchError(() => of(remoteError({ message: "The templates for this trade unit could not be loaded." }))), startWith(remoteLoading()));
	}
	save(tradeUnit, name, values) {
		return this.http.post(this.templatesUrl, {
			tradeUnit,
			name,
			payloadJson: JSON.stringify(values)
		});
	}
	rename(id, tradeUnit, name, values) {
		return this.http.put(`${this.templatesUrl}/${id}`, {
			tradeUnit,
			name,
			payloadJson: JSON.stringify(values)
		});
	}
	remove(id) {
		return this.http.delete(`${this.templatesUrl}/${id}`);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractTemplateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractTemplateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractTemplateSource,
	decorators: [{ type: Injectable }]
});
const NOTE_MAX_BYTES = 4e3;
function noteByteLength(note) {
	return new TextEncoder().encode(note).length;
}
function remainingNoteBytes(note) {
	return NOTE_MAX_BYTES - noteByteLength(note);
}
function noteSizeRefusal(note) {
	const over = -remainingNoteBytes(note);
	if (over <= 0) return null;
	return `This note is ${over.toLocaleString("en-US")} characters over the ${NOTE_MAX_BYTES.toLocaleString("en-US")} allowed. Shorten it before saving — a note over the limit stops CTRM returning all of the notes on this contract, not just this one.`;
}
const CLOSED_REFUSAL = "This contract is closed";
const INTERCOMPANY_PURCHASE_REFUSAL = "Intercompany purchase contracts are read-only";
function isPurchaseContract(contractNumber) {
	return contractNumber.trim().charAt(0).toUpperCase() === "P";
}
function editRefusalFor(row) {
	if (row.isClosed) return CLOSED_REFUSAL;
	if (row.isIntercompany === true && isPurchaseContract(row.contractNumber)) return INTERCOMPANY_PURCHASE_REFUSAL;
	return false;
}
const NUMBER_ISSUE_GENERIC_MESSAGE = "CTRM could not issue a contract number. Type one, or try again.";
const MESSAGES = {
	blank: "CTRM was asked for a number without both prefixes. Check the contract type and commodity, then ask again.",
	inUse: "The number CTRM issued already belongs to another contract. Ask again for the next one, or type a number.",
	purged: "The number CTRM issued is marked for removal and cannot be used. Ask again for the next one, or type a number.",
	pendingHold: "The number CTRM issued is being held by an unfinished contract. Ask again for the next one, or type a number.",
	suffixCollision: "That suffix is already used on this contract number. Choose a different suffix, or leave it blank.",
	unknown: NUMBER_ISSUE_GENERIC_MESSAGE
};
function messageForNumberIssueCondition(condition) {
	return MESSAGES[condition] ?? "CTRM could not issue a contract number. Type one, or try again.";
}
function numberIssueConditionOf(error) {
	if (typeof error !== "object" || error === null) return null;
	const body = error.error;
	if (typeof body !== "object" || body === null) return null;
	const condition = body.condition;
	return typeof condition === "string" ? condition : null;
}
const FOCUS_PARAM = "focus";
function toRouteParams(query, sorts, focus, filter) {
	const params = {};
	const defaults = initialQuery();
	const encoded = filter === void 0 ? void 0 : filterToParam(filter);
	if (encoded !== void 0) params[FILTER_PARAM] = encoded;
	if (query.status !== defaults.status) params["status"] = query.status;
	for (const key of [
		"search",
		"commodity",
		"customerId",
		"traderInitials",
		"marketZone",
		"approverType"
	]) {
		const value = query[key]?.trim();
		if (value) params[key] = value;
	}
	if (query.page > 1) params["page"] = String(query.page);
	const sort = toSortParam(sorts);
	if (sort !== void 0) params["sort"] = sort;
	if (focus) params[FOCUS_PARAM] = focus;
	return params;
}
const FILTER_PARAM = "filter";
function filterToParam(group) {
	const active = group.rules.filter(carries);
	return active.length === 0 ? void 0 : JSON.stringify({
		combinator: group.combinator,
		rules: active
	});
}
function filterFromParam(raw) {
	if (!raw) return EMPTY_FILTER;
	try {
		const parsed = JSON.parse(raw);
		if (typeof parsed !== "object" || parsed === null) return EMPTY_FILTER;
		return readGroup(parsed) ?? EMPTY_FILTER;
	} catch {
		return EMPTY_FILTER;
	}
}
function carries(node) {
	return isRuleNode(node) ? node.columnKey !== "" : node.rules.some(carries);
}
function readGroup(value) {
	if (typeof value !== "object" || value === null) return null;
	const candidate = value;
	if (!Array.isArray(candidate.rules)) return null;
	const rules = candidate.rules.map((child) => isRule(child) ? child : readGroup(child)).filter((child) => child !== null);
	return {
		combinator: candidate.combinator === "or" ? "or" : "and",
		rules
	};
}
function isRule(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return typeof candidate.id === "string" && typeof candidate.columnKey === "string" && typeof candidate.operator === "string" && typeof candidate.value === "string";
}
function fromRouteParams(params) {
	const status = params.get("status");
	const page = Number.parseInt(params.get("page") ?? "", 10);
	return {
		query: {
			...initialQuery(),
			status: isStatus(status) ? status : initialQuery().status,
			search: blank(params.get("search")),
			commodity: blank(params.get("commodity")),
			customerId: blank(params.get("customerId")),
			traderInitials: blank(params.get("traderInitials")),
			marketZone: blank(params.get("marketZone")),
			approverType: blank(params.get("approverType")),
			page: Number.isFinite(page) && page > 0 ? page : 1,
			pageSize: 50
		},
		sorts: parseSortParam(params.get("sort")),
		focus: blank(params.get("focus")) ?? null,
		filter: filterFromParam(params.get(FILTER_PARAM))
	};
}
const STATUSES$1 = [
	"Open",
	"Unapproved",
	"Closed"
];
function isStatus(value) {
	return value !== null && STATUSES$1.includes(value);
}
function blank(value) {
	const trimmed = value?.trim();
	return trimmed ? trimmed : void 0;
}
var HttpContractListSource = class HttpContractListSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	list(query, options) {
		return this.http.get(`${this.baseUrl}/contracts`, { params: toContractListParams(query, options) }).pipe(map((page) => remoteLoaded(withGatingFlags(page))), catchError((error) => of(remoteError(toRemoteError$4(error)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractListSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractListSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractListSource,
	decorators: [{ type: Injectable }]
});
function withGatingFlags(page) {
	return {
		...page,
		rows: page.rows.map((row) => ({
			...row,
			isClosed: row.isClosed ?? false,
			isIntercompany: row.isIntercompany === void 0 ? null : row.isIntercompany
		}))
	};
}
function toContractListParams(query, options) {
	let params = new HttpParams().set("status", query.status).set("page", query.page).set("pageSize", query.pageSize);
	if (options?.refresh) params = params.set("refresh", true);
	const optional = [
		["tradeUnit", query.tradeUnit],
		["customerId", query.customerId],
		["commodity", query.commodity],
		["traderInitials", query.traderInitials],
		["approverType", query.approverType],
		["marketZone", query.marketZone],
		["search", query.search],
		["sort", query.sort]
	];
	for (const [key, value] of optional) {
		const trimmed = value?.trim();
		if (trimmed) params = params.set(key, trimmed);
	}
	return params;
}
function toRemoteError$4(error) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 422) return {
			message: problem?.detail ?? problem?.title ?? "That request could not be completed.",
			correlationId: problem?.traceId
		};
		if (error.status === 401 || error.status === 403) return {
			message: "You are not signed in, or your account cannot view contracts.",
			correlationId: problem?.traceId
		};
		return {
			message: "We could not load contracts. Please try again.",
			correlationId: problem?.traceId
		};
	}
	return { message: "We could not load contracts. Please try again." };
}
const CONTRACT_EXPORT_SOURCE = new InjectionToken("CONTRACT_EXPORT_SOURCE");
var HttpContractExportSource = class HttpContractExportSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	export(request) {
		const params = toContractListParams(request.query).delete("page").delete("pageSize").set("fields", request.fields.join(","));
		return this.http.get(`${this.baseUrl}/contracts/export`, {
			params,
			responseType: "blob",
			observe: "response"
		}).pipe(map((response) => ({
			kind: "csv",
			csv: response.body ?? new Blob([], { type: "text/csv" }),
			filename: filenameFrom(response.headers.get("Content-Disposition"))
		})), catchError((error) => toResult(error)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractExportSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractExportSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractExportSource,
	decorators: [{ type: Injectable }]
});
function filenameFrom(disposition) {
	if (!disposition) return null;
	const encoded = /filename\*\s*=\s*utf-8''([^;]+)/i.exec(disposition);
	if (encoded) {
		const value = encoded[1].trim();
		try {
			return decodeURIComponent(value);
		} catch {
			return value;
		}
	}
	const plain = /filename\s*=\s*"?([^";]+)"?/i.exec(disposition);
	return plain ? plain[1].trim() : null;
}
function toResult(error) {
	if (!(error instanceof HttpErrorResponse)) return of({
		kind: "unavailable",
		reason: "The server export is not available right now."
	});
	if (error.status === 404) return of({
		kind: "unavailable",
		reason: "The server does not offer an export yet."
	});
	if (error.status === 0 || error.status >= 500) return of({
		kind: "unavailable",
		reason: "The server export is not available right now."
	});
	if (error.status === 401 || error.status === 403) return of({
		kind: "refused",
		message: "You are not signed in, or your account cannot export contracts."
	});
	return problemFrom$1(error.error).pipe(map((problem) => ({
		kind: "refused",
		message: problem?.detail ?? problem?.title ?? "The server refused the export.",
		...problem?.traceId === void 0 ? {} : { correlationId: problem.traceId }
	})));
}
function problemFrom$1(body) {
	if (body instanceof Blob) return from(body.text()).pipe(map(parseProblem$1), catchError(() => of(null)));
	if (typeof body === "string") return of(parseProblem$1(body));
	return of(isProblem(body) ? body : null);
}
function parseProblem$1(text) {
	try {
		const parsed = JSON.parse(text);
		return isProblem(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function isProblem(value) {
	return typeof value === "object" && value !== null;
}
const quantity = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const price = new Intl.NumberFormat("en-US", {
	minimumFractionDigits: 4,
	maximumFractionDigits: 4
});
function formatQuantity(value) {
	return value === null || value === void 0 ? "" : quantity.format(value);
}
function formatPrice(value) {
	return value === null || value === void 0 ? "" : price.format(value);
}
const MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
function formatContractDate(iso) {
	if (!iso) return "";
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!match) return iso;
	const [, year, month, day] = match;
	const name = MONTHS[Number(month) - 1];
	return name ? `${Number(day)} ${name} ${year}` : iso;
}
function formatShortDate(iso) {
	if (!iso) return "";
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
	if (!match) return iso;
	const [, year, month, day] = match;
	return `${Number(month)}/${Number(day)}/${year.slice(2)}`;
}
function formatShipPeriod(row) {
	const begin = formatContractDate(row.shipPeriodBegin);
	const end = formatContractDate(row.shipPeriodEnd);
	if (begin && end) return begin === end ? begin : `${begin} – ${end}`;
	return begin || end;
}
function formatCustomer(row) {
	return customerDisplayName(row.customerName, row.customerId);
}
function approvalBadge(row) {
	return contractStatusBadge(row.traderApprovalStatus);
}
function confirmBadge(row) {
	return contractStatusBadge(row.customerConfirmStatus);
}
function contractStatusBadge(status) {
	const trimmed = status?.trim();
	if (!trimmed) return null;
	switch (trimmed.toLowerCase()) {
		case "approved":
		case "confirmed": return {
			label: trimmed,
			tone: "positive"
		};
		case "unapproved":
		case "pending": return {
			label: trimmed,
			tone: "caution"
		};
		case "rejected": return {
			label: trimmed,
			tone: "negative"
		};
		default: return {
			label: trimmed,
			tone: "neutral"
		};
	}
}
function contractRowTone(row) {
	switch (row.traderApprovalStatus?.trim().toLowerCase()) {
		case "rejected": return "negative";
		case "unapproved":
		case "pending": return "caution";
		default: return null;
	}
}
const CONTRACT_GRID_COLUMNS = [
	{
		key: "contractNumber",
		header: "Contract",
		sortable: true,
		width: 130,
		format: (row) => row.contractNumber
	},
	{
		key: "contractDate",
		header: "Date",
		sortable: true,
		filterKind: "date",
		width: 90,
		format: (row) => formatShortDate(row.contractDate),
		sortValue: (row) => row.contractDate ?? "",
		tooltip: (row) => formatContractDate(row.contractDate)
	},
	{
		key: "customerId",
		header: "Customer",
		cell: CustomerCellComponent,
		sortable: true,
		width: 180,
		format: formatCustomer
	},
	{
		key: "commodity",
		header: "Commodity",
		sortable: true,
		width: 120,
		format: (row) => row.commodity ?? ""
	},
	{
		key: "quantity",
		header: "Quantity",
		align: "end",
		sortable: true,
		filterKind: "number",
		width: 130,
		format: (row) => row.quantity === null ? "" : `${quantity.format(row.quantity)} ${row.quantityUom ?? ""}`.trim(),
		sortValue: (row) => row.quantity ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "price",
		header: "Price",
		align: "end",
		sortable: true,
		filterKind: "number",
		width: 110,
		format: (row) => row.price === null ? "" : price.format(row.price),
		sortValue: (row) => row.price ?? Number.NEGATIVE_INFINITY
	},
	{
		key: "priceTypeCode",
		header: "Type",
		sortable: true,
		width: 90,
		format: (row) => row.priceTypeCode ?? ""
	},
	{
		key: "marketZone",
		header: "Zone",
		sortable: true,
		width: 90,
		format: (row) => row.marketZone ?? ""
	},
	{
		key: "trader",
		header: "Trader",
		sortable: true,
		width: 140,
		format: (row) => row.trader ?? row.traderInitials ?? ""
	},
	{
		key: "shipPeriod",
		header: "Ship period",
		sortable: true,
		width: 210,
		minWidth: 110,
		format: formatShipPeriod,
		sortValue: (row) => row.shipPeriodBegin ?? ""
	},
	{
		key: "traderApprovalStatus",
		header: "Approval",
		sortable: true,
		width: 130,
		format: (row) => row.traderApprovalStatus ?? "",
		badge: approvalBadge
	}
];
const CONFIRMED_COLUMN = {
	key: "customerConfirmStatus",
	header: "Confirmed",
	sortable: true,
	width: 130,
	format: (row) => row.customerConfirmStatus ?? "",
	badge: confirmBadge
};
var SampleContractExportSource = class SampleContractExportSource {
	all = buildContracts();
	export(request) {
		const { query, fields } = request;
		if (!hasScope(query)) throw new Error("A trade unit or a customer is required. CTRM does not serve an unfiltered contract list.");
		const everything = project(this.all, {
			...query,
			page: 1,
			pageSize: Math.max(1, this.all.length)
		}).rows;
		const sorts = parseSortParam(query.sort);
		const ordered = sorts.length === 0 ? everything : [...everything].sort((left, right) => compareBySorts(CONTRACT_GRID_COLUMNS, sorts, left, right));
		const columns = applyExportFields(CONTRACT_GRID_COLUMNS, fields.map((key) => ({
			key,
			header: "",
			included: true
		})));
		return of({
			kind: "csv",
			csv: new Blob([toCsv(columns, ordered)], { type: "text/csv;charset=utf-8" }),
			filename: null
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleContractExportSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleContractExportSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleContractExportSource,
	decorators: [{ type: Injectable }]
});
const LOCATION_SOURCE = new InjectionToken("LOCATION_SOURCE");
var HttpLocationSource = class HttpLocationSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	cached = null;
	list() {
		this.cached ??= this.fetch();
		return this.cached;
	}
	fetch() {
		return this.http.get(`${this.baseUrl}/locations`).pipe(map((list) => remoteLoaded(list)), catchError((error) => of(remoteError(toRemoteError$3(error)))), tap((state) => {
			if (state.status === "error") this.cached = null;
		}), startWith(remoteLoading()), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpLocationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpLocationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpLocationSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError$3(error) {
	if (error instanceof HttpErrorResponse) {
		const correlationId = error.error?.traceId;
		if (error.status === 401) return {
			message: "Your session has expired. Please sign in again.",
			correlationId
		};
		if (error.status === 403) return {
			message: "Your account does not have a Contract Management System role. Request access, then sign in again.",
			correlationId
		};
		return {
			message: "We could not load the trade unit list. Please try again.",
			correlationId
		};
	}
	return { message: "We could not load the trade unit list. Please try again." };
}
function groupByCompany(locations) {
	const groups = /* @__PURE__ */ new Map();
	for (const location of locations) {
		const code = location.companyCode ?? "";
		const existing = groups.get(code);
		if (existing) existing.locations.push(location);
		else groups.set(code, {
			code,
			name: location.companyName ?? "Unknown company",
			locations: [location]
		});
	}
	return [...groups.values()].sort((left, right) => left.code.localeCompare(right.code));
}
function injectTradeUnitLabel() {
	const context = inject(TRADE_UNIT_CONTEXT);
	const locations = toSignal(inject(LOCATION_SOURCE).list(), { initialValue: remoteLoading() });
	return computed(() => {
		const code = context.code();
		if (!code) return null;
		const state = locations();
		const match = state.status === "loaded" ? state.value.locations.find((location) => location.code === code) : void 0;
		return match?.name ? `${code} · ${match.name}` : code;
	});
}
function injectLocationCodes() {
	const locations = toSignal(inject(LOCATION_SOURCE).list(), { initialValue: remoteLoading() });
	return computed(() => {
		const state = locations();
		return state.status === "loaded" ? state.value.locations.map((location) => location.code) : [];
	});
}
const PRICING_SOURCE = new InjectionToken("PRICING_SOURCE");
const MARKET_REFERENCE_SOURCE = new InjectionToken("MARKET_REFERENCE_SOURCE");
var HttpMarketReferenceSource = class HttpMarketReferenceSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	tradeUnitValues = inject(TRADE_UNIT_VALUES_SOURCE);
	cache = /* @__PURE__ */ new Map();
	marketCodes(location, commodityCode) {
		return this.fetch(REFERENCE_ROUTES.marketCodes, {
			location,
			commodityCode
		});
	}
	marketMonths(location, commodityCode, marketCode) {
		const months = this.fetch(REFERENCE_ROUTES.marketMonths, {
			location,
			commodityCode,
			marketCode,
			languageCode: ""
		});
		return combineLatest([months, this.configuredMonths(location, commodityCode)]).pipe(map(([offered, configured]) => offered === null ? null : narrowToConfigured(offered, configured)));
	}
	configuredMonths(location, commodityCode) {
		const commodity = normaliseCode(commodityCode);
		return this.tradeUnitValues.marketMonths(location).pipe(map((rows) => rows.filter((row) => normaliseCode(row.commodity) === commodity).map((row) => ({
			value: row.marketMonth,
			include: true
		}))), catchError(() => of([])));
	}
	fetch(set, params) {
		const key = `${set}?${new URLSearchParams(params).toString()}`;
		const cached = this.cache.get(key);
		if (cached !== void 0) return cached;
		const stream = this.http.get(`${this.baseUrl}/reference/${set}`, { params }).pipe(map((response) => (response.items ?? []).filter((item) => item.code !== null && item.code.trim() !== "").map((item) => ({
			code: item.code,
			description: item.description ?? item.code
		}))), catchError(() => of([])), startWith(null), shareReplay({
			bufferSize: 1,
			refCount: false
		}));
		this.cache.set(key, stream);
		return stream;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpMarketReferenceSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpMarketReferenceSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpMarketReferenceSource,
	decorators: [{ type: Injectable }]
});
var HttpPricingSource = class HttpPricingSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	contractPrices(contract) {
		return this.http.get(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/prices`).pipe(toRemote());
	}
	unapproved(query) {
		let params = new HttpParams();
		if (query.traderInitials) params = params.set("traderInitials", query.traderInitials);
		if (query.location) params = params.set("location", query.location);
		if (query.approverType) params = params.set("approverType", query.approverType);
		return this.http.get(`${this.baseUrl}/pricing/unapproved`, { params }).pipe(toRemote());
	}
	save(contract, sequences) {
		return this.http.post(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/prices`, { sequences }).pipe(toRemote());
	}
	remove(contract, priceSequence) {
		return this.http.delete(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/prices/${priceSequence}`).pipe(map((result) => remoteLoaded(result)), catchError((error) => {
			if (error instanceof HttpErrorResponse && error.status === 404 && error.error?.prices) return of(remoteLoaded({
				contract: error.error.contract ?? contract,
				acknowledgement: error.error.detail ?? "That price sequence had already been removed.",
				verified: true,
				prices: error.error.prices
			}));
			return of(remoteError(toRemoteError$2(error)));
		}), startWith(remoteLoading()));
	}
	approve(contract, priceSequences) {
		return this.http.post(`${this.baseUrl}/pricing/${encodeURIComponent(contract)}/approvals`, { priceSequences }).pipe(toRemote());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpPricingSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpPricingSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpPricingSource,
	decorators: [{ type: Injectable }]
});
function toRemote() {
	return (source) => source.pipe(map((value) => remoteLoaded(value)), catchError((error) => of(remoteError(toRemoteError$2(error)))), startWith(remoteLoading()));
}
function toRemoteError$2(error) {
	if (error instanceof HttpErrorResponse) {
		const problem = parseProblem(error);
		const formErrors = problem.formErrors.length > 0 ? problem.formErrors : void 0;
		if (problem.detail !== null || problem.title !== null) return {
			message: problem.detail ?? problem.title ?? "",
			correlationId: problem.traceId ?? void 0,
			formErrors
		};
		if (problem.kind === ProblemKind.Forbidden) return {
			message: "You do not have permission to change pricing on this contract.",
			formErrors
		};
		if (error.status === 0) return { message: "We could not reach the server." };
		return {
			message: "We could not complete that pricing request.",
			formErrors
		};
	}
	return { message: "We could not complete that pricing request." };
}
function flatPrice(terms) {
	return (terms.basisPrice ?? 0) + (terms.adjustments ?? 0) + (terms.hedgePrice ?? 0);
}
function flatPriceAgrees(computed, stored) {
	return Math.abs(computed - stored) < 5e-6;
}
const APPROVAL_CONTRACT_SOURCE = new InjectionToken("APPROVAL_CONTRACT_SOURCE");
var HttpApprovalContractSource = class HttpApprovalContractSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get(contractNumber) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}`;
		return this.http.get(url).pipe(map((response) => {
			const header = response.contract?.header;
			if (!header) return remoteError({ message: `Contract ${contractNumber} came back without its header.` });
			return remoteLoaded({
				header,
				dataOrigin: response.dataOrigin ?? "Simulated",
				warnings: response.warnings ?? []
			});
		}), catchError((error) => of(remoteError(toRemoteError$1(error, contractNumber)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpApprovalContractSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpApprovalContractSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpApprovalContractSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError$1(error, contractNumber) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 422 && problem?.detail) return {
			message: problem.detail,
			correlationId: problem.correlationId
		};
		if (error.status === 403) return {
			message: "You do not have access to this contract.",
			correlationId: problem?.correlationId
		};
		return {
			message: `We could not load contract ${contractNumber}. Please try again.`,
			correlationId: problem?.correlationId
		};
	}
	return { message: `We could not load contract ${contractNumber}. Please try again.` };
}
const MAX_ECM_RECIPIENTS = 4;
const APPROVAL_ACTION_SOURCE = new InjectionToken("APPROVAL_ACTION_SOURCE");
var HttpApprovalActionSource = class HttpApprovalActionSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	approve(contractNumber, ecm) {
		return this.post(contractNumber, {
			decision: "Approved",
			...ecm === void 0 ? {} : { ecm }
		});
	}
	reject(contractNumber, reason) {
		return this.post(contractNumber, {
			decision: "Rejected",
			reason
		});
	}
	post(contractNumber, body) {
		return this.http.post(`${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/approval`, body);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpApprovalActionSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpApprovalActionSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpApprovalActionSource,
	decorators: [{ type: Injectable }]
});
var SimulatedApprovalActionSource = class SimulatedApprovalActionSource {
	approve(contractNumber, _ecm) {
		return this.settle(contractNumber, "Approved", "Approved");
	}
	reject(contractNumber, reason) {
		return this.settle(contractNumber, "Rejected", "Rejected", reason);
	}
	settle(contractNumber, decision, status, reason) {
		return of({
			contractNumber,
			decision,
			origin: "Simulated",
			status,
			detail: `Simulated ${decision.toLowerCase()} — CTRM was not contacted.` + (reason === void 0 ? "" : ` Reason recorded locally: ${reason}`)
		}).pipe(delay(400));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SimulatedApprovalActionSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SimulatedApprovalActionSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SimulatedApprovalActionSource,
	decorators: [{ type: Injectable }]
});
const FORM_CONFIG_ADMIN_SOURCE = new InjectionToken("FORM_CONFIG_ADMIN_SOURCE");
var HttpFormConfigAdminSource = class HttpFormConfigAdminSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	list() {
		return this.http.get(`${this.baseUrl}/form-configurations`).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	registry() {
		return this.http.get(`${this.baseUrl}/form-configurations/registry`).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	auditTrail(id) {
		return this.http.get(`${this.baseUrl}/form-configurations/${id}/audit`).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	get(id) {
		return this.http.get(`${this.baseUrl}/form-configurations/${id}`).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	create(submission) {
		return this.http.post(`${this.baseUrl}/form-configurations`, submission).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	update(id, rowVersion, submission) {
		return this.http.put(`${this.baseUrl}/form-configurations/${id}`, submission, { headers: { "If-Match": rowVersion } }).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	preview(dimensions) {
		const params = Object.entries(dimensions).filter(([, value]) => value !== void 0 && value !== "").reduce((carry, [key, value]) => ({
			...carry,
			[key]: value
		}), {});
		return this.http.get(`${this.baseUrl}/form-configurations/resolve`, { params }).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	deactivate(id, rowVersion) {
		return this.http.delete(`${this.baseUrl}/form-configurations/${id}`, { headers: { "If-Match": rowVersion } }).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(describe(error)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpFormConfigAdminSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpFormConfigAdminSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpFormConfigAdminSource,
	decorators: [{ type: Injectable }]
});
function describe(error) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 400 && problem?.errors !== void 0) return {
			message: `The configuration was refused:\n${Object.entries(problem.errors).map(([key, messages]) => `${key.replace("config.fields.", "")}: ${messages.join(" ")}`).join("\n")}`,
			correlationId: problem.traceId
		};
		if (error.status === 401 || error.status === 403) return {
			message: "Form configuration is an administrator function and this account does not hold the Admin role. An empty list here would look like \"no configuration exists\", which is why this says so instead.",
			correlationId: problem?.traceId
		};
		if (error.status === 409) return {
			message: problem?.detail ?? "This configuration changed since the list was loaded. Reload before changing it again.",
			correlationId: problem?.traceId
		};
		return {
			message: problem?.detail ?? "The configuration service could not be reached.",
			correlationId: problem?.traceId
		};
	}
	return { message: "The configuration service could not be reached." };
}
const CONTRACT_DETAIL_SOURCE = new InjectionToken("CONTRACT_DETAIL_SOURCE");
var HttpContractDetailSource = class HttpContractDetailSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get(contractNumber) {
		const url = `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}`;
		return this.http.get(url).pipe(map((response) => remoteLoaded(response)), catchError((error) => of(remoteError(toRemoteError(error, contractNumber)))), startWith(remoteLoading()));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractDetailSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractDetailSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractDetailSource,
	decorators: [{ type: Injectable }]
});
function toRemoteError(error, contractNumber) {
	if (error instanceof HttpErrorResponse) {
		const problem = error.error;
		if (error.status === 422 || error.status === 400) return {
			message: problem?.detail ?? problem?.title ?? `Contract ${contractNumber} could not be loaded.`,
			correlationId: problem?.traceId
		};
		if (error.status === 404) return {
			message: "That contract route is not available. This is a configuration problem rather than a missing contract — CTRM reports an unknown contract as a rejection, not a 404.",
			correlationId: problem?.traceId
		};
		if (error.status === 401 || error.status === 403) return {
			message: "You are not signed in, or your account cannot view contracts.",
			correlationId: problem?.traceId
		};
		return {
			message: `We could not load contract ${contractNumber}. Please try again.`,
			correlationId: problem?.traceId
		};
	}
	return { message: `We could not load contract ${contractNumber}. Please try again.` };
}
const ADDENDUM_TEMPLATE_SOURCE = new InjectionToken("ADDENDUM_TEMPLATE_SOURCE");
const ADDENDUM_GENERATION_SOURCE = new InjectionToken("ADDENDUM_GENERATION_SOURCE");
function draftOf(template) {
	return {
		name: template.name,
		family: template.family,
		tradeUnits: template.tradeUnits,
		templateContent: template.templateContent,
		fieldMapJson: template.fieldMapJson,
		active: template.active
	};
}
var HttpAddendumTemplateSource = class HttpAddendumTemplateSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	get templatesUrl() {
		return `${this.baseUrl}/addendum-templates`;
	}
	list() {
		return settle(this.http.get(this.templatesUrl), "templates");
	}
	create(draft) {
		return settle(this.http.post(this.templatesUrl, draft), "templates");
	}
	update(id, draft) {
		return settle(this.http.put(`${this.templatesUrl}/${id}`, draft), "templates");
	}
	deactivate(template) {
		return this.update(template.id, {
			...draftOf(template),
			active: false
		});
	}
	remove(id) {
		return settle(this.http.delete(`${this.templatesUrl}/${id}`).pipe(map(() => void 0)), "templates");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpAddendumTemplateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpAddendumTemplateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpAddendumTemplateSource,
	decorators: [{ type: Injectable }]
});
var HttpAddendumGenerationSource = class HttpAddendumGenerationSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	generate(contractNumber, request) {
		return settle(this.http.post(`${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/addendums`, request), "generation");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpAddendumGenerationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpAddendumGenerationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpAddendumGenerationSource,
	decorators: [{ type: Injectable }]
});
const UNAVAILABLE = {
	templates: "Addendum templates are not available yet. The server does not offer them.",
	generation: "Generating an addendum is not available yet. The server does not offer it."
};
const FAILED = {
	templates: "The addendum template service could not complete that. Please try again.",
	generation: "The addendum could not be generated. Please try again."
};
function settle(request, subject) {
	return request.pipe(map((value) => ({
		kind: "done",
		value
	})), catchError((error) => of(toCall(error, subject))));
}
function toCall(error, subject) {
	if (!(error instanceof HttpErrorResponse)) return {
		kind: "failed",
		message: FAILED[subject]
	};
	if (error.status === 404 || error.status === 0) return {
		kind: "unavailable",
		reason: UNAVAILABLE[subject]
	};
	const problem = typeof error.error === "object" ? error.error : null;
	const correlationId = problem?.traceId ?? void 0;
	if (error.status === 401 || error.status === 403) return {
		kind: "failed",
		message: "You are not signed in, or your account cannot do that.",
		...correlationId === void 0 ? {} : { correlationId }
	};
	return {
		kind: "failed",
		message: problem?.detail ?? problem?.title ?? FAILED[subject],
		...correlationId === void 0 ? {} : { correlationId }
	};
}
const ADDENDUM_PLACEHOLDER_NOTICE = "PLACEHOLDER, not Legal's approved wording. An administrator replaces this text with the approved template.";
function sampleAddendumTemplate(set, id) {
	const placeholderOf = (cwsField) => cwsField.replace(/^addendum_/, "");
	const lines = set.fields.map((field) => `${field.label}: {{${placeholderOf(field.cwsField)}}}`);
	const fieldMap = Object.fromEntries(set.fields.map((field) => [placeholderOf(field.cwsField), field.cwsField]));
	return {
		id,
		name: `${set.title} (sample)`,
		family: "B",
		tradeUnits: [],
		templateContent: [
			ADDENDUM_PLACEHOLDER_NOTICE,
			"",
			`${set.title} addendum to contract {{contract_number}}`,
			...lines,
			"",
			`Signature: ${ADDENDUM_SIGNATURE_ANCHOR}`,
			`Date: ${ADDENDUM_DATE_ANCHOR}`,
			`Initials: ${ADDENDUM_INITIALS_ANCHOR}`
		].join("\n"),
		fieldMapJson: JSON.stringify(fieldMap),
		version: 1,
		active: true
	};
}
var SampleAddendumTemplateSource = class SampleAddendumTemplateSource {
	templates = FAMILY_B_ADDENDUM_FIELD_SETS.map((set, index) => sampleAddendumTemplate(set, index + 1));
	nextId = this.templates.length + 1;
	list() {
		return of({
			kind: "done",
			value: [...this.templates]
		});
	}
	create(draft) {
		const refusal = refusalOf(draft);
		if (refusal !== null) return of(refusal);
		const template = {
			...draft,
			id: this.nextId++,
			version: 1
		};
		this.templates = [...this.templates, template];
		return of({
			kind: "done",
			value: template
		});
	}
	update(id, draft) {
		const existing = this.templates.find((template) => template.id === id);
		if (existing === void 0) return of({
			kind: "failed",
			message: "That template no longer exists."
		});
		const refusal = refusalOf(draft);
		if (refusal !== null) return of(refusal);
		const template = {
			...draft,
			id,
			version: existing.version + 1
		};
		this.templates = this.templates.map((candidate) => candidate.id === id ? template : candidate);
		return of({
			kind: "done",
			value: template
		});
	}
	deactivate(template) {
		return this.update(template.id, {
			...draftOf(template),
			active: false
		});
	}
	remove(id) {
		this.templates = this.templates.filter((template) => template.id !== id);
		return of({
			kind: "done",
			value: void 0
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleAddendumTemplateSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleAddendumTemplateSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleAddendumTemplateSource,
	decorators: [{ type: Injectable }]
});
var SampleAddendumGenerationSource = class SampleAddendumGenerationSource {
	nextId = 1;
	generate(contractNumber, request) {
		const id = this.nextId++;
		return of({
			kind: "done",
			value: {
				id,
				status: "Generated",
				documentId: `sample-${contractNumber}-${request.templateId}-${id}`
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleAddendumGenerationSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleAddendumGenerationSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleAddendumGenerationSource,
	decorators: [{ type: Injectable }]
});
function refusalOf(draft) {
	const problems = addendumAnchorProblems(draft.templateContent);
	return problems.length === 0 ? null : {
		kind: "failed",
		message: problems.join(" ")
	};
}
const CONTRACT_DOCUMENTS_SOURCE = new InjectionToken("CONTRACT_DOCUMENTS_SOURCE");
function contractDocumentName(document) {
	return document.description?.trim() || document.fileName?.trim() || `Document ${document.documentEntry}`;
}
const CTRM_USER_REFUSALS = /* @__PURE__ */ new Set(["ctrm-user-ambiguous", "ctrm-user-not-found"]);
const ROLES = /* @__PURE__ */ new Set([
	"draft",
	"approved",
	"confirmed",
	"additional",
	"attachment"
]);
const PROVENANCES = /* @__PURE__ */ new Set([
	"generated",
	"otmCopy",
	"termsAndConditions",
	"rjoAddendum",
	"userImported",
	"userAttachment",
	"contractUpload"
]);
const STATUSES = /* @__PURE__ */ new Set([
	"available",
	"pending",
	"expired",
	"notStored"
]);
const LIST_FAILED = "The documents could not be loaded.";
const CONTENT_UNAVAILABLE = "This document can't be opened here yet.";
const CONTENT_FAILED = "The document could not be opened. Please try again.";
var HttpContractDocumentsSource = class HttpContractDocumentsSource {
	http = inject(HttpClient);
	baseUrl = inject(CONTRACTS_API_URL);
	documentsUrl(contractNumber) {
		return `${this.baseUrl}/contracts/${encodeURIComponent(contractNumber)}/documents`;
	}
	list(contractNumber) {
		return this.http.get(this.documentsUrl(contractNumber)).pipe(map((body) => readList(body)), catchError((error) => of(listFailure(error))));
	}
	content(contractNumber, documentEntry) {
		return this.http.get(`${this.documentsUrl(contractNumber)}/${encodeURIComponent(documentEntry)}`, { responseType: "blob" }).pipe(map((blob) => ({
			kind: "done",
			blob
		})), catchError((error) => of(contentFailure(error))));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractDocumentsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: HttpContractDocumentsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: HttpContractDocumentsSource,
	decorators: [{ type: Injectable }]
});
function readList(body) {
	const raw = body !== null && typeof body === "object" ? body : null;
	if (raw === null || !Array.isArray(raw["documents"])) return {
		kind: "failed",
		message: `${LIST_FAILED} The server's answer could not be read.`
	};
	return {
		kind: "loaded",
		response: {
			contract: typeof raw["contract"] === "string" ? raw["contract"] : "",
			documents: raw["documents"].map(readDocument),
			dataOrigin: typeof raw["dataOrigin"] === "string" ? raw["dataOrigin"] : "",
			warnings: Array.isArray(raw["warnings"]) ? raw["warnings"].filter((warning) => typeof warning === "string") : []
		}
	};
}
function readDocument(value) {
	const row = value !== null && typeof value === "object" ? value : {};
	const text = (key) => typeof row[key] === "string" ? row[key] : null;
	const provenance = text("provenance");
	return {
		documentEntry: String(row["documentEntry"] ?? ""),
		role: oneOf(text("role"), ROLES),
		provenance: provenance === null ? null : oneOf(provenance, PROVENANCES),
		documentType: text("documentType"),
		description: text("description"),
		fileName: text("fileName"),
		appearanceSequence: typeof row["appearanceSequence"] === "number" ? row["appearanceSequence"] : null,
		status: oneOf(text("status"), STATUSES),
		createdStamp: text("createdStamp")
	};
}
function oneOf(value, known) {
	return value !== null && known.has(value) ? value : "unknown";
}
function listFailure(error) {
	const problem = problemFrom(error);
	const correlation = problem.traceId === null ? {} : { correlationId: problem.traceId };
	if (problem.status === 403 && problem.type !== null && CTRM_USER_REFUSALS.has(problem.type)) return {
		kind: "refused",
		title: problem.title ?? "Your account cannot read these documents.",
		detail: problem.detail ?? "Please ask the Help Desk to check your CTRM user."
	};
	if (problem.status === 401 || problem.status === 403) return {
		kind: "refused",
		title: "Your account cannot read these documents.",
		detail: problem.detail ?? "You are not signed in, or your account does not have access to this contract."
	};
	return {
		kind: "failed",
		message: problem.detail ?? LIST_FAILED,
		...correlation
	};
}
function contentFailure(error) {
	if (error instanceof HttpErrorResponse && (error.status === 404 || error.status === 0)) return {
		kind: "unavailable",
		reason: CONTENT_UNAVAILABLE
	};
	return {
		kind: "failed",
		message: CONTENT_FAILED
	};
}
const CREATED = "2026-09-01-09.15.00.000000";
const SAMPLE_CONTRACT_DOCUMENTS = [
	sample("2200010", "approved", "generated", "Contract", "Contract.pdf", 0, "available"),
	sample("2200011", "draft", "generated", "Contract draft", "Contract draft.pdf", 0, "available"),
	sample("2200012", "additional", "termsAndConditions", "Terms and conditions", "Terms and conditions.pdf", 10, "available", "T&C PAGES"),
	sample("2200013", "additional", "userImported", "Scale ticket", "Scale ticket.pdf", 20, "pending"),
	sample("2200014", "additional", "rjoAddendum", "RJO Addendum", "RJO Addendum.pdf", 40, "available"),
	{
		...sample("2200015", "additional", "userImported", "Vendor confirmation", null, 50, "notStored"),
		createdStamp: null
	},
	sample("2200016", "attachment", "contractUpload", "Signed contract", "Signed contract.pdf", null, "available"),
	sample("2200017", "attachment", "userAttachment", "Chemical attestation", "Chemical attestation.pdf", null, "expired")
];
function sample(documentEntry, role, provenance, description, fileName, appearanceSequence, status, documentType = null) {
	return {
		documentEntry,
		role,
		provenance,
		documentType,
		description,
		fileName,
		appearanceSequence,
		status,
		createdStamp: CREATED
	};
}
var SampleContractDocumentsSource = class SampleContractDocumentsSource {
	documents = SAMPLE_CONTRACT_DOCUMENTS;
	list(contractNumber) {
		return of({
			kind: "loaded",
			response: {
				contract: contractNumber,
				documents: this.documents,
				dataOrigin: "Simulated",
				warnings: []
			}
		});
	}
	content(contractNumber, documentEntry) {
		const document = this.documents.find((candidate) => candidate.documentEntry === documentEntry);
		if (document === void 0 || document.status !== "available") return of({
			kind: "unavailable",
			reason: "This document can't be opened here yet."
		});
		return of({
			kind: "done",
			blob: new Blob([samplePdf(`${contractDocumentName(document)} - ${contractNumber}`)], { type: "application/pdf" })
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleContractDocumentsSource,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SampleContractDocumentsSource
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SampleContractDocumentsSource,
	decorators: [{ type: Injectable }]
});
function samplePdf(title) {
	const escape = (value) => value.replace(/[^\x20-\x7e]/g, "?").replace(/([\\()])/g, "\\$1");
	const stream = [`BT /F1 18 Tf 72 720 Td (SAMPLE - ${escape(title)}) Tj ET`, "BT /F1 11 Tf 72 696 Td (Playground sample data. This is not a CTRM document.) Tj ET"].join("\n");
	const objects = [
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
		"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
		`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`
	];
	let pdf = "%PDF-1.4\n";
	const offsets = [];
	objects.forEach((body, index) => {
		offsets.push(pdf.length);
		pdf += `${index + 1} 0 obj\n${body}\nendobj\n`;
	});
	const xref = pdf.length;
	pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n` + offsets.map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`).join("") + `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
	return Uint8Array.from(pdf, (character) => character.charCodeAt(0));
}
export { ADDENDUM_DATE_ANCHOR, ADDENDUM_GENERATION_SOURCE, ADDENDUM_INITIALS_ANCHOR, ADDENDUM_PLACEHOLDER_NOTICE, ADDENDUM_SIGNATURE_ANCHOR, ADDENDUM_TEMPLATE_SOURCE, APPROVAL_ACTION_SOURCE, APPROVAL_CONTRACT_SOURCE, AVAILABILITY_SOURCE, AVAILABILITY_STATES, AvailabilityGate, BROKER_STAGE_CAUTION, CLOSED_REFUSAL, CLOSE_PROVENANCE_WARNING, CONFIRMED_COLUMN, CONTRACTS_API_URL, CONTRACT_CODE_PREFIXES, CONTRACT_CODE_PREFIX_LABELS, CONTRACT_COPY_IDENTITY_FIELDS, CONTRACT_DETAIL_SOURCE, CONTRACT_DOCUMENTS_SOURCE, CONTRACT_EXPORT_SOURCE, CONTRACT_GRID_COLUMNS, CONTRACT_IDEMPOTENCY_KEY, CONTRACT_LAYOUT_CTRM_FIELDS, CONTRACT_LAYOUT_CTRM_FIELD_BY_COMPONENT, CONTRACT_LAYOUT_EMPTY_NOTES, CONTRACT_LAYOUT_FIELDS, CONTRACT_LAYOUT_FIELD_NOTES, CONTRACT_LAYOUT_GROUP_HEADINGS, CONTRACT_LAYOUT_HALF_FIELDS, CONTRACT_LAYOUT_HIDDEN_LABEL_FIELDS, CONTRACT_LAYOUT_SECTIONS, CONTRACT_LAYOUT_SECTION_NOTES, CONTRACT_LAYOUT_WIDE_FIELDS, CONTRACT_LIST_SOURCE, CONTRACT_LOG_SOURCE, CONTRACT_NUMBER_SOURCE, CONTRACT_READ_ONLY_FIELDS, CONTRACT_STATE_SOURCE, CONTRACT_TABS, CONTRACT_TEMPLATE_SOURCE, CONTRACT_WRITABLE_FIELDS, CONTRACT_WRITE_SOURCE, CUSTOMER_SOURCE, CWS_CONTRACT_EVENTS_VERSION, CWS_CONTRACT_FIELDS, ConfirmationProgressComponent, ContractFormComponent, CustomerCellComponent, CwsContractEvents, DEFAULT_PAGE_SIZE, DOCUMENTS_TAB, DRAFT_CLOCK, DRAFT_STORAGE, FAMILY_B_ADDENDUM_FIELD_SETS, FILTER_PARAM, FOCUS_PARAM, FORM_CONFIG_ADMIN_SOURCE, FORM_CONFIG_SOURCE, HttpAddendumGenerationSource, HttpAddendumTemplateSource, HttpApprovalActionSource, HttpApprovalContractSource, HttpAvailabilitySource, HttpContractDetailSource, HttpContractDocumentsSource, HttpContractExportSource, HttpContractListSource, HttpContractLogSource, HttpContractNumberSource, HttpContractStateSource, HttpContractTemplateSource, HttpContractWriteSource, HttpCustomerSource, HttpFormConfigAdminSource, HttpLocationSource, HttpMarketReferenceSource, HttpMeSource, HttpPricingSource, HttpTradeUnitValuesSource, INTERCOMPANY_PURCHASE_REFUSAL, INVALID_PARAM_ALIASES, LOCATION_SOURCE, LOG_TAB, MARKET_REFERENCE_SOURCE, MAX_ECM_RECIPIENTS, MAX_PAGE_SIZE, ME_SOURCE, NOTES_WARNING, NOTE_MAX_BYTES, NUMBER_ISSUE_GENERIC_MESSAGE, PRICING_SOURCE, RECORD_DRAFT_STORE, RECORD_ORIGIN_PARAM, REFERENCE_ROUTES, SAMPLE_CONTRACT_DOCUMENTS, SAMPLE_CUSTOMERS, SAMPLE_LOCATIONS, SAMPLE_ME, SAMPLE_REDACTED_CUSTOMER_ID, STATIC_ALLOWED_VALUES, SampleAddendumGenerationSource, SampleAddendumTemplateSource, SampleAvailabilitySource, SampleContractDocumentsSource, SampleContractExportSource, SampleContractListSource, SampleCustomerSource, SampleMeSource, SessionRecordDraftStore, SimulatedApprovalActionSource, TRADE_UNIT_VALUES_SOURCE, addendumAnchorProblems, addendumFieldSetFor, addendumFieldSetOf, auditActionOf, auditChangesOf, availabilityNotice, buildContracts, classifyIntercompany, classifyInvalidParam, classifyInvalidParams, coerceForControl, confirmationProgress, contractDocumentName, contractRowTone, contractStatusBadge, copyExclusions, copyableValues, customerDisplayName, defaultTradeUnitOf, describeAuditAction, destinationOf, diffConfigDocuments, draftOf, draftStorageKey, editRefusalFor, emptiedTabs, fieldDestinationViolations, filenameFrom, filterFromParam, filterToParam, flatPrice, flatPriceAgrees, formatContractDate, formatPrice, formatQuantity, formatShipPeriod, formatShortDate, fromRouteParams, groupByCompany, groupContractDocuments, hasFirstApproval, hasScope, initialQuery, injectLocationCodes, injectTradeUnitLabel, isIntercompanyPurchase, isPurchaseContract, isRedactedName, isServerSorted, looksLikeCtrmFieldName, messageForNumberIssueCondition, narrowToConfigured, normaliseCode, noteByteLength, noteSizeRefusal, numberIssueConditionOf, parseSortParam, project, recordOrigin, recordOriginKey, recordTrail, remainingNoteBytes, sampleAddendumTemplate, samplePdf, savedCodeDescriptions, seedFromCtrmValues, tabsAfterCascade, templateValuesOf, toAvailabilityState, toContractListParams, toContractTabId, toRouteParams, toSortParam, wholeDaysBetween, writesBlockedBy };

//# sourceMappingURL=cws-domain-contracts.mjs.map
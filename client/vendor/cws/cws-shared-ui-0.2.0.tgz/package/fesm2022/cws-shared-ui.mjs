import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, HostListener, Injectable, InjectionToken, afterRenderEffect, computed, effect, forwardRef, inject, input, isDevMode, linkedSignal, output, signal, viewChild } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { CdkTrapFocus } from "@angular/cdk/a11y";
import { CdkConnectedOverlay, CdkOverlayOrigin, Overlay } from "@angular/cdk/overlay";
import { addDays, addMonths, dayOfWeek, fromIsoDate, isRealDate, parseShipPeriodDate, toIsoDate } from "@cws/shared-utils";
import { NgComponentOutlet } from "@angular/common";
import { DIALOG_DATA, Dialog, DialogRef } from "@angular/cdk/dialog";
import { map, of } from "rxjs";
import { RouterLink } from "@angular/router";
const remoteIdle = () => ({ status: "idle" });
const remoteLoading = () => ({ status: "loading" });
const remoteLoaded = (value) => ({
	status: "loaded",
	value
});
const remoteError = (error) => ({
	status: "error",
	error
});
function remoteValue(data) {
	return data.status === "loaded" ? data.value : null;
}
var AsyncContainerComponent = class AsyncContainerComponent {
	data = input.required(...ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []);
	empty = input(false, ...ngDevMode ? [{ debugName: "empty" }] : /* istanbul ignore next */ []);
	emptyMessage = input("No results.", ...ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []);
	loadingLabel = input("Loading", ...ngDevMode ? [{ debugName: "loadingLabel" }] : /* istanbul ignore next */ []);
	retry = output();
	isLoading = computed(() => {
		const status = this.data().status;
		return status === "loading" || status === "idle";
	}, ...ngDevMode ? [{ debugName: "isLoading" }] : /* istanbul ignore next */ []);
	error = computed(() => {
		const data = this.data();
		return data.status === "error" ? data.error : null;
	}, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	showContent = computed(() => this.data().status === "loaded" && !this.empty(), ...ngDevMode ? [{ debugName: "showContent" }] : /* istanbul ignore next */ []);
	showEmpty = computed(() => this.data().status === "loaded" && this.empty(), ...ngDevMode ? [{ debugName: "showEmpty" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: AsyncContainerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: AsyncContainerComponent,
		isStandalone: true,
		selector: "cms-async-container",
		inputs: {
			data: {
				classPropertyName: "data",
				publicName: "data",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			empty: {
				classPropertyName: "empty",
				publicName: "empty",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyMessage: {
				classPropertyName: "emptyMessage",
				publicName: "emptyMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			loadingLabel: {
				classPropertyName: "loadingLabel",
				publicName: "loadingLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { retry: "retry" },
		ngImport: i0,
		template: "@if (isLoading()) {\r\n  <!--\r\n    role=\"status\" + aria-live announces the state change without stealing focus. The visual\r\n    spinner is aria-hidden so a screen reader gets the label once, not twice.\r\n  -->\r\n  <div\r\n    class=\"cws:flex cws:min-h-[50vh] cws:items-center cws:justify-center cws:gap-3\"\r\n    role=\"status\"\r\n    aria-live=\"polite\"\r\n  >\r\n    <span class=\"scoular-spinner\" aria-hidden=\"true\"></span>\r\n    <span class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ loadingLabel() }}</span>\r\n  </div>\r\n} @else if (error(); as remoteError) {\r\n  <!--\r\n    Centred in the content area rather than a full-width banner across the top (JFrisbie, 2026-08-31).\r\n\r\n    A failed load leaves the whole region empty, so the message belongs where the missing content would\r\n    have been — not pinned to the top edge with an acre of blank space under it, which is what the\r\n    screenshot showed. `min-h-[50vh]` is what makes \"centred\" mean centred *on the screen*: with the\r\n    page header and controls above it, the block lands near the middle of a typical viewport. Viewport\r\n    units rather than a fixed height so it holds on a laptop and on an ultrawide.\r\n\r\n    ⚠ **The loading state above carries the same `min-h-[50vh]`, and that is not incidental.** Without\r\n    it the spinner sits near the top and the error then appears halfway down — a jump on every failed\r\n    load, introduced by this change rather than pre-existing. The two states have to occupy the same\r\n    box.\r\n\r\n    role=\"alert\" is kept — a failure is assertive; the user has to know the region did not load.\r\n  -->\r\n  <div\r\n    class=\"cws:flex cws:min-h-[50vh] cws:flex-col cws:items-center cws:justify-center cws:gap-4 cws:px-4 cws:text-center\"\r\n    role=\"alert\"\r\n  >\r\n    <div class=\"cws:space-y-1\">\r\n      <!--\r\n        The design system's own error text colour, on the page background rather than on a tinted\r\n        alert fill. 4.5:1 against white — it clears AA, and only just, so do not lighten it.\r\n      -->\r\n      <p class=\"cws:text-sm cws:font-medium cws:text-scoular-red-dark cws:dark:text-scoular-red\">\r\n        {{ remoteError.message }}\r\n      </p>\r\n      @if (remoteError.correlationId) {\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Reference: <span class=\"cws:font-mono\">{{ remoteError.correlationId }}</span>\r\n        </p>\r\n      }\r\n    </div>\r\n\r\n    <!--\r\n      The same classes as the grid's \"Add Contract\", `border border-transparent` included — retrying is\r\n      the one thing to do from this screen, so it gets the primary treatment rather than the muted\r\n      secondary/small pairing it had.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n      (click)=\"retry.emit()\"\r\n    >\r\n      Retry\r\n    </button>\r\n  </div>\r\n} @else if (showEmpty()) {\r\n  <div class=\"cws:py-8 cws:text-center\">\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ emptyMessage() }}</p>\r\n    <!-- Primary action for the empty state, e.g. \"Clear filters\" (02a §5). -->\r\n    <div class=\"cws:mt-3\"><ng-content select=\"[cmsEmptyAction]\" /></div>\r\n  </div>\r\n} @else if (showContent()) {\r\n  <ng-content />\r\n}\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: AsyncContainerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-async-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "@if (isLoading()) {\r\n  <!--\r\n    role=\"status\" + aria-live announces the state change without stealing focus. The visual\r\n    spinner is aria-hidden so a screen reader gets the label once, not twice.\r\n  -->\r\n  <div\r\n    class=\"cws:flex cws:min-h-[50vh] cws:items-center cws:justify-center cws:gap-3\"\r\n    role=\"status\"\r\n    aria-live=\"polite\"\r\n  >\r\n    <span class=\"scoular-spinner\" aria-hidden=\"true\"></span>\r\n    <span class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ loadingLabel() }}</span>\r\n  </div>\r\n} @else if (error(); as remoteError) {\r\n  <!--\r\n    Centred in the content area rather than a full-width banner across the top (JFrisbie, 2026-08-31).\r\n\r\n    A failed load leaves the whole region empty, so the message belongs where the missing content would\r\n    have been — not pinned to the top edge with an acre of blank space under it, which is what the\r\n    screenshot showed. `min-h-[50vh]` is what makes \"centred\" mean centred *on the screen*: with the\r\n    page header and controls above it, the block lands near the middle of a typical viewport. Viewport\r\n    units rather than a fixed height so it holds on a laptop and on an ultrawide.\r\n\r\n    ⚠ **The loading state above carries the same `min-h-[50vh]`, and that is not incidental.** Without\r\n    it the spinner sits near the top and the error then appears halfway down — a jump on every failed\r\n    load, introduced by this change rather than pre-existing. The two states have to occupy the same\r\n    box.\r\n\r\n    role=\"alert\" is kept — a failure is assertive; the user has to know the region did not load.\r\n  -->\r\n  <div\r\n    class=\"cws:flex cws:min-h-[50vh] cws:flex-col cws:items-center cws:justify-center cws:gap-4 cws:px-4 cws:text-center\"\r\n    role=\"alert\"\r\n  >\r\n    <div class=\"cws:space-y-1\">\r\n      <!--\r\n        The design system's own error text colour, on the page background rather than on a tinted\r\n        alert fill. 4.5:1 against white — it clears AA, and only just, so do not lighten it.\r\n      -->\r\n      <p class=\"cws:text-sm cws:font-medium cws:text-scoular-red-dark cws:dark:text-scoular-red\">\r\n        {{ remoteError.message }}\r\n      </p>\r\n      @if (remoteError.correlationId) {\r\n        <p class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n          Reference: <span class=\"cws:font-mono\">{{ remoteError.correlationId }}</span>\r\n        </p>\r\n      }\r\n    </div>\r\n\r\n    <!--\r\n      The same classes as the grid's \"Add Contract\", `border border-transparent` included — retrying is\r\n      the one thing to do from this screen, so it gets the primary treatment rather than the muted\r\n      secondary/small pairing it had.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n      (click)=\"retry.emit()\"\r\n    >\r\n      Retry\r\n    </button>\r\n  </div>\r\n} @else if (showEmpty()) {\r\n  <div class=\"cws:py-8 cws:text-center\">\r\n    <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ emptyMessage() }}</p>\r\n    <!-- Primary action for the empty state, e.g. \"Clear filters\" (02a §5). -->\r\n    <div class=\"cws:mt-3\"><ng-content select=\"[cmsEmptyAction]\" /></div>\r\n  </div>\r\n} @else if (showContent()) {\r\n  <ng-content />\r\n}\r\n"
		}]
	}],
	propDecorators: {
		data: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "data",
				required: true
			}]
		}],
		empty: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "empty",
				required: false
			}]
		}],
		emptyMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyMessage",
				required: false
			}]
		}],
		loadingLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "loadingLabel",
				required: false
			}]
		}],
		retry: [{
			type: i0.Output,
			args: ["retry"]
		}]
	}
});
var FieldComponent = class FieldComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	hint = input(null, ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	labelFor = input(true, ...ngDevMode ? [{ debugName: "labelFor" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FieldComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: FieldComponent,
		isStandalone: true,
		selector: "cms-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelFor: {
				classPropertyName: "labelFor",
				publicName: "labelFor",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<div class=\"scoular-form-group\">\r\n  <!--\r\n    🔴 When the heading is hidden the row KEEPS its height (`min-h-5`), and that is the whole point.\r\n\r\n    `sr-only` positions absolutely, so putting it on the ROW collapsed 20px of label space and lifted\r\n    the input 28px above its neighbours — measured at 90px against 118px for every labelled field in\r\n    the same grid row. Reserving the space keeps a grouped field aligned with the rest of the row\r\n    while showing no heading of its own.\r\n\r\n    ⚠ The row is `flex justify-between` even when nothing is projected into the aside slot. That is\r\n    not decoration: it is what lets a control add a counter later without the label moving, and with\r\n    an empty slot it lays out identically to a bare label (measured across all six controls).\r\n  -->\r\n  <div class=\"cws:flex cws:items-baseline cws:justify-between cws:gap-3\" [class.cws:min-h-5]=\"hideLabel()\">\r\n    @if (labelFor()) {\r\n      <label\r\n        class=\"scoular-form-label cws:min-w-0\"\r\n        [class.sr-only]=\"hideLabel()\"\r\n        [for]=\"controlId()\"\r\n        [title]=\"label()\"\r\n      >\r\n        <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\r\n          <span class=\"truncate\">{{ label() }}</span>\r\n          @if (required()) {\r\n            <span class=\"cws:shrink-0 cws:text-scoular-red\" aria-hidden=\"true\">*</span>\r\n          }\r\n        </span>\r\n      </label>\r\n    } @else {\r\n      <!--\r\n        A plain <span>, not <label for> — used where the control is not a labelable element. A\r\n        `role=\"switch\"` button is the case this exists for: a <label> pointing at a button is not an\r\n        accessible-name association, so the control takes `aria-labelledby` against this id instead.\r\n      -->\r\n      <span\r\n        class=\"scoular-form-label cws:min-w-0\"\r\n        [class.sr-only]=\"hideLabel()\"\r\n        [id]=\"controlId() + '-label'\"\r\n        [title]=\"label()\"\r\n      >\r\n        <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\r\n          <span class=\"truncate\">{{ label() }}</span>\r\n          @if (required()) {\r\n            <span class=\"cws:shrink-0 cws:text-scoular-red\" aria-hidden=\"true\">*</span>\r\n          }\r\n        </span>\r\n      </span>\r\n    }\r\n\r\n    <!-- The character counter, and anything else that belongs on the label's line. -->\r\n    <ng-content select=\"[cmsFieldAside]\" />\r\n  </div>\r\n\r\n  <!-- The control itself. -->\r\n  <ng-content />\r\n\r\n  <!--\r\n    🔴 Error and hint are mutually exclusive, and the ids are load-bearing: every control's\r\n    `describedBy()` points at `<controlId>-error` or `<controlId>-hint`, so these must be rendered\r\n    here with exactly those ids or the association silently breaks — which is invisible to everyone\r\n    except a screen-reader user.\r\n  -->\r\n  @if (errorMessage(); as message) {\r\n    <p class=\"scoular-form-error\" [id]=\"controlId() + '-error'\">{{ message }}</p>\r\n  } @else if (hint(); as text) {\r\n    <p class=\"scoular-form-helper\" [id]=\"controlId() + '-hint'\">{{ text }}</p>\r\n  }\r\n</div>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: FieldComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: "<div class=\"scoular-form-group\">\r\n  <!--\r\n    🔴 When the heading is hidden the row KEEPS its height (`min-h-5`), and that is the whole point.\r\n\r\n    `sr-only` positions absolutely, so putting it on the ROW collapsed 20px of label space and lifted\r\n    the input 28px above its neighbours — measured at 90px against 118px for every labelled field in\r\n    the same grid row. Reserving the space keeps a grouped field aligned with the rest of the row\r\n    while showing no heading of its own.\r\n\r\n    ⚠ The row is `flex justify-between` even when nothing is projected into the aside slot. That is\r\n    not decoration: it is what lets a control add a counter later without the label moving, and with\r\n    an empty slot it lays out identically to a bare label (measured across all six controls).\r\n  -->\r\n  <div class=\"cws:flex cws:items-baseline cws:justify-between cws:gap-3\" [class.cws:min-h-5]=\"hideLabel()\">\r\n    @if (labelFor()) {\r\n      <label\r\n        class=\"scoular-form-label cws:min-w-0\"\r\n        [class.sr-only]=\"hideLabel()\"\r\n        [for]=\"controlId()\"\r\n        [title]=\"label()\"\r\n      >\r\n        <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\r\n          <span class=\"truncate\">{{ label() }}</span>\r\n          @if (required()) {\r\n            <span class=\"cws:shrink-0 cws:text-scoular-red\" aria-hidden=\"true\">*</span>\r\n          }\r\n        </span>\r\n      </label>\r\n    } @else {\r\n      <!--\r\n        A plain <span>, not <label for> — used where the control is not a labelable element. A\r\n        `role=\"switch\"` button is the case this exists for: a <label> pointing at a button is not an\r\n        accessible-name association, so the control takes `aria-labelledby` against this id instead.\r\n      -->\r\n      <span\r\n        class=\"scoular-form-label cws:min-w-0\"\r\n        [class.sr-only]=\"hideLabel()\"\r\n        [id]=\"controlId() + '-label'\"\r\n        [title]=\"label()\"\r\n      >\r\n        <span class=\"cws:flex cws:min-w-0 cws:items-baseline cws:gap-0.5\">\r\n          <span class=\"truncate\">{{ label() }}</span>\r\n          @if (required()) {\r\n            <span class=\"cws:shrink-0 cws:text-scoular-red\" aria-hidden=\"true\">*</span>\r\n          }\r\n        </span>\r\n      </span>\r\n    }\r\n\r\n    <!-- The character counter, and anything else that belongs on the label's line. -->\r\n    <ng-content select=\"[cmsFieldAside]\" />\r\n  </div>\r\n\r\n  <!-- The control itself. -->\r\n  <ng-content />\r\n\r\n  <!--\r\n    🔴 Error and hint are mutually exclusive, and the ids are load-bearing: every control's\r\n    `describedBy()` points at `<controlId>-error` or `<controlId>-hint`, so these must be rendered\r\n    here with exactly those ids or the association silently breaks — which is invisible to everyone\r\n    except a screen-reader user.\r\n  -->\r\n  @if (errorMessage(); as message) {\r\n    <p class=\"scoular-form-error\" [id]=\"controlId() + '-error'\">{{ message }}</p>\r\n  } @else if (hint(); as text) {\r\n    <p class=\"scoular-form-helper\" [id]=\"controlId() + '-hint'\">{{ text }}</p>\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		labelFor: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelFor",
				required: false
			}]
		}]
	}
});
var QuantityInputComponent = class QuantityInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	unitOfMeasure = input(null, ...ngDevMode ? [{ debugName: "unitOfMeasure" }] : /* istanbul ignore next */ []);
	decimalPlaces = input(2, ...ngDevMode ? [{ debugName: "decimalPlaces" }] : /* istanbul ignore next */ []);
	allowNegative = input(false, ...ngDevMode ? [{ debugName: "allowNegative" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	formula = input(null, ...ngDevMode ? [{ debugName: "formula" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	focused = signal(false, ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	value = signal(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	editingText = signal(null, ...ngDevMode ? [{ debugName: "editingText" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		const ids = [];
		if (this.errorMessage()) ids.push(`${this.controlId()}-error`);
		if (this.formula() || this.warningText()) ids.push(`${this.controlId()}-hint`);
		return ids.length > 0 ? ids.join(" ") : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	hint = computed(() => this.formula() ?? this.warningText(), ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	displayValue = computed(() => {
		if (this.focused()) {
			const editing = this.editingText();
			if (editing !== null) return editing;
			const current = this.value();
			return current === null ? "" : String(current);
		}
		return this.format(this.value());
	}, ...ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "number" && Number.isFinite(value) ? value : null);
		this.editingText.set(null);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onFocus() {
		this.focused.set(true);
		this.editingText.set(null);
	}
	onInput(event) {
		const element = event.target;
		const raw = element.value;
		const cleaned = this.sanitize(raw);
		if (cleaned !== raw) {
			const caret = element.selectionStart ?? raw.length;
			const removedBeforeCaret = caret - this.sanitize(raw.slice(0, caret)).length;
			element.value = cleaned;
			const restored = Math.max(0, caret - removedBeforeCaret);
			element.setSelectionRange(restored, restored);
		}
		this.editingText.set(cleaned);
		this.onChange(this.parse(cleaned));
	}
	sanitize(raw) {
		const allowed = this.allowNegative() ? /[^0-9.,\s-]/g : /[^0-9.,\s]/g;
		const stripped = raw.replace(allowed, "");
		const negative = this.allowNegative() && stripped.startsWith("-");
		const digits = (negative ? stripped.slice(1) : stripped).replace(/-/g, "");
		const firstPoint = digits.indexOf(".");
		const single = firstPoint === -1 ? digits : digits.slice(0, firstPoint + 1) + digits.slice(firstPoint + 1).replace(/\./g, "");
		return negative ? `-${single}` : single;
	}
	onBlur() {
		this.focused.set(false);
		const editing = this.editingText();
		if (editing !== null) {
			this.value.set(this.parse(editing));
			this.editingText.set(null);
		}
		this.onTouched();
	}
	parse(raw) {
		const cleaned = raw.replace(/[,\s]/g, "");
		if (cleaned === "" || cleaned === "-") return null;
		const parsed = Number(cleaned);
		if (!Number.isFinite(parsed)) return null;
		return !this.allowNegative() && parsed < 0 ? Math.abs(parsed) : parsed;
	}
	format(value) {
		if (value === null) return "";
		return value.toLocaleString("en-US", {
			minimumFractionDigits: this.decimalPlaces(),
			maximumFractionDigits: this.decimalPlaces()
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: QuantityInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: QuantityInputComponent,
		isStandalone: true,
		selector: "cms-quantity-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			unitOfMeasure: {
				classPropertyName: "unitOfMeasure",
				publicName: "unitOfMeasure",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			decimalPlaces: {
				classPropertyName: "decimalPlaces",
				publicName: "decimalPlaces",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			allowNegative: {
				classPropertyName: "allowNegative",
				publicName: "allowNegative",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			formula: {
				classPropertyName: "formula",
				publicName: "formula",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => QuantityInputComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"hint()\"\r\n>\r\n\r\n  <div class=\"cws:relative\">\r\n    <!--\r\n      inputmode=\"decimal\" raises the numeric keypad on touch without the spinner buttons and\r\n      silent value-clamping that type=\"number\" brings. Values are parsed explicitly anyway.\r\n      Right-aligned per C4; padded on the right when a UM suffix is rendered inside the control.\r\n    -->\r\n    <input\r\n      class=\"scoular-form-input cws:text-right\"\r\n      [class.error]=\"errorMessage() !== null\"\r\n      [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n      [class.cws:pr-12]=\"unitOfMeasure() !== null\"\r\n      [id]=\"controlId()\"\r\n      type=\"text\"\r\n      inputmode=\"decimal\"\r\n      autocomplete=\"off\"\r\n      [value]=\"displayValue()\"\r\n      [readOnly]=\"readOnly()\"\r\n      [disabled]=\"disabled()\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"hint()\"\r\n      (focus)=\"onFocus()\"\r\n      (input)=\"onInput($event)\"\r\n      (blur)=\"onBlur()\"\r\n    />\r\n\r\n    @if (unitOfMeasure(); as unit) {\r\n      <!-- Decorative: the unit is already part of the label's meaning, so it is not announced twice. -->\r\n      <span\r\n        class=\"cws:pointer-events-none cws:absolute cws:inset-y-0 cws:right-3 cws:flex cws:items-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\r\n        aria-hidden=\"true\"\r\n        >{{ unit }}</span\r\n      >\r\n    }\r\n  </div>\r\n</cms-field>\r\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: QuantityInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-quantity-input",
			imports: [FieldComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => QuantityInputComponent),
				multi: true
			}],
			template: "<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"hint()\"\r\n>\r\n\r\n  <div class=\"cws:relative\">\r\n    <!--\r\n      inputmode=\"decimal\" raises the numeric keypad on touch without the spinner buttons and\r\n      silent value-clamping that type=\"number\" brings. Values are parsed explicitly anyway.\r\n      Right-aligned per C4; padded on the right when a UM suffix is rendered inside the control.\r\n    -->\r\n    <input\r\n      class=\"scoular-form-input cws:text-right\"\r\n      [class.error]=\"errorMessage() !== null\"\r\n      [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n      [class.cws:pr-12]=\"unitOfMeasure() !== null\"\r\n      [id]=\"controlId()\"\r\n      type=\"text\"\r\n      inputmode=\"decimal\"\r\n      autocomplete=\"off\"\r\n      [value]=\"displayValue()\"\r\n      [readOnly]=\"readOnly()\"\r\n      [disabled]=\"disabled()\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"hint()\"\r\n      (focus)=\"onFocus()\"\r\n      (input)=\"onInput($event)\"\r\n      (blur)=\"onBlur()\"\r\n    />\r\n\r\n    @if (unitOfMeasure(); as unit) {\r\n      <!-- Decorative: the unit is already part of the label's meaning, so it is not announced twice. -->\r\n      <span\r\n        class=\"cws:pointer-events-none cws:absolute cws:inset-y-0 cws:right-3 cws:flex cws:items-center cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\"\r\n        aria-hidden=\"true\"\r\n        >{{ unit }}</span\r\n      >\r\n    }\r\n  </div>\r\n</cms-field>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		unitOfMeasure: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "unitOfMeasure",
				required: false
			}]
		}],
		decimalPlaces: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "decimalPlaces",
				required: false
			}]
		}],
		allowNegative: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allowNegative",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		formula: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formula",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}]
	}
});
var TextInputComponent = class TextInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	hideLabel = input(false, ...ngDevMode ? [{ debugName: "hideLabel" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	maxLength = input.required(...ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = signal("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	remaining = computed(() => this.maxLength() - this.value().length, ...ngDevMode ? [{ debugName: "remaining" }] : /* istanbul ignore next */ []);
	nearLimit = computed(() => {
		const threshold = Math.max(5, Math.floor(this.maxLength() * .1));
		return this.remaining() <= threshold;
	}, ...ngDevMode ? [{ debugName: "nearLimit" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		const ids = [`${this.controlId()}-counter`];
		if (this.errorMessage()) ids.push(`${this.controlId()}-error`);
		else if (this.warningText()) ids.push(`${this.controlId()}-hint`);
		return ids.join(" ");
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "string" ? value.slice(0, this.maxLength()) : "");
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		const element = event.target;
		const clamped = element.value.slice(0, this.maxLength());
		if (element.value !== clamped) element.value = clamped;
		this.value.set(clamped);
		this.onChange(clamped === "" ? null : clamped);
	}
	onBlur() {
		this.onTouched();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: TextInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: TextInputComponent,
		isStandalone: true,
		selector: "cms-text-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			hideLabel: {
				classPropertyName: "hideLabel",
				publicName: "hideLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			maxLength: {
				classPropertyName: "maxLength",
				publicName: "maxLength",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => TextInputComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<!--\r\n  The label row, the required marker and the error/hint line come from `cms-field` (2026-09-16).\r\n  This template used to carry all three itself, as did five sibling controls — identically, down to\r\n  the byte. The `min-h-5` row-height fix recorded below now lives there, which is the point: it was\r\n  made here, on the screen where the bug was reported, and four of the six controls never got it.\r\n-->\r\n<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [hideLabel]=\"hideLabel()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n  <ng-container cmsFieldAside>\r\n    <!--\r\n      aria-live=\"polite\" so the count is announced as it changes, but only when it starts to\r\n      matter — announcing every keystroke of a 72-character remark would be unusable.\r\n\r\n      🔴 **Hidden when read-only** (2026-09-03). A remaining-character count answers \"how much more may\r\n      I type\", and in a read-only field the answer is \"none, ever\" — so it was ~100 instances of\r\n      \"255 left\" competing with the labels on the record screen's view mode, which is the primary way a\r\n      contract is *read*. It is the loudest thing on the page and it says nothing.\r\n\r\n      Not merely faded: an `aria-live` region on a value that cannot change is noise for a screen\r\n      reader too, and `maxlength` is not enforced on an input nobody can edit.\r\n    -->\r\n    @if (!readOnly() && !hideLabel()) {\r\n      <span\r\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\r\n        [class.cws:text-slate-500]=\"!nearLimit()\"\r\n        [class.cws:text-scoular-yellow-dark]=\"nearLimit()\"\r\n        [id]=\"controlId() + '-counter'\"\r\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\r\n        >{{ remaining() }} left</span\r\n      >\r\n    }\r\n  </ng-container>\r\n\r\n  <input\r\n    class=\"scoular-form-input\"\r\n    [class.error]=\"errorMessage() !== null\"\r\n    [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n    [id]=\"controlId()\"\r\n    type=\"text\"\r\n    autocomplete=\"off\"\r\n    [value]=\"value()\"\r\n    [attr.maxlength]=\"maxLength()\"\r\n    [readOnly]=\"readOnly()\"\r\n    [disabled]=\"disabled()\"\r\n    [attr.aria-required]=\"required() ? 'true' : null\"\r\n    [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n    [attr.aria-describedby]=\"describedBy()\"\r\n    [attr.title]=\"warningText()\"\r\n    (input)=\"onInput($event)\"\r\n    (blur)=\"onBlur()\"\r\n  />\r\n</cms-field>\r\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: TextInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-text-input",
			imports: [FieldComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => TextInputComponent),
				multi: true
			}],
			template: "<!--\r\n  The label row, the required marker and the error/hint line come from `cms-field` (2026-09-16).\r\n  This template used to carry all three itself, as did five sibling controls — identically, down to\r\n  the byte. The `min-h-5` row-height fix recorded below now lives there, which is the point: it was\r\n  made here, on the screen where the bug was reported, and four of the six controls never got it.\r\n-->\r\n<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [hideLabel]=\"hideLabel()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n  <ng-container cmsFieldAside>\r\n    <!--\r\n      aria-live=\"polite\" so the count is announced as it changes, but only when it starts to\r\n      matter — announcing every keystroke of a 72-character remark would be unusable.\r\n\r\n      🔴 **Hidden when read-only** (2026-09-03). A remaining-character count answers \"how much more may\r\n      I type\", and in a read-only field the answer is \"none, ever\" — so it was ~100 instances of\r\n      \"255 left\" competing with the labels on the record screen's view mode, which is the primary way a\r\n      contract is *read*. It is the loudest thing on the page and it says nothing.\r\n\r\n      Not merely faded: an `aria-live` region on a value that cannot change is noise for a screen\r\n      reader too, and `maxlength` is not enforced on an input nobody can edit.\r\n    -->\r\n    @if (!readOnly() && !hideLabel()) {\r\n      <span\r\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\r\n        [class.cws:text-slate-500]=\"!nearLimit()\"\r\n        [class.cws:text-scoular-yellow-dark]=\"nearLimit()\"\r\n        [id]=\"controlId() + '-counter'\"\r\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\r\n        >{{ remaining() }} left</span\r\n      >\r\n    }\r\n  </ng-container>\r\n\r\n  <input\r\n    class=\"scoular-form-input\"\r\n    [class.error]=\"errorMessage() !== null\"\r\n    [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n    [id]=\"controlId()\"\r\n    type=\"text\"\r\n    autocomplete=\"off\"\r\n    [value]=\"value()\"\r\n    [attr.maxlength]=\"maxLength()\"\r\n    [readOnly]=\"readOnly()\"\r\n    [disabled]=\"disabled()\"\r\n    [attr.aria-required]=\"required() ? 'true' : null\"\r\n    [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n    [attr.aria-describedby]=\"describedBy()\"\r\n    [attr.title]=\"warningText()\"\r\n    (input)=\"onInput($event)\"\r\n    (blur)=\"onBlur()\"\r\n  />\r\n</cms-field>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		hideLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideLabel",
				required: false
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		maxLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLength",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}]
	}
});
var CodeComboComponent = class CodeComboComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	inputElement = viewChild("comboInput", ...ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	activeIndex = signal(-1, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	selectedCode = signal(null, ...ngDevMode ? [{ debugName: "selectedCode" }] : /* istanbul ignore next */ []);
	query = signal(null, ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	selectedOption = computed(() => this.options().find((option) => option.code === this.selectedCode()) ?? null, ...ngDevMode ? [{ debugName: "selectedOption" }] : /* istanbul ignore next */ []);
	displayValue = computed(() => {
		const typed = this.query();
		if (typed !== null) return typed;
		const selected = this.selectedOption();
		if (selected) return `${selected.code} — ${selected.description}`;
		return this.selectedCode() ?? "";
	}, ...ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []);
	filtered = computed(() => {
		const typed = this.query();
		if (typed === null || typed.trim() === "") return this.options();
		const needle = typed.trim().toLowerCase();
		return this.options().filter((option) => option.code.toLowerCase().includes(needle) || option.description.toLowerCase().includes(needle));
	}, ...ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		if (this.errorMessage()) return `${this.controlId()}-error`;
		return this.warningText() ? `${this.controlId()}-hint` : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	optionClass(active) {
		return active ? ACTIVE_OPTION_CLASS : INACTIVE_OPTION_CLASS;
	}
	optionId(index) {
		return `${this.controlId()}-option-${index}`;
	}
	activeOptionId = computed(() => {
		const index = this.activeIndex();
		return this.open() && index >= 0 ? this.optionId(index) : null;
	}, ...ngDevMode ? [{ debugName: "activeOptionId" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.selectedCode.set(typeof value === "string" && value !== "" ? value : null);
		this.query.set(null);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		const raw = event.target.value;
		this.query.set(raw);
		this.open.set(true);
		const exact = this.options().find((option) => option.code.toLowerCase() === raw.trim().toLowerCase());
		if (exact) {
			this.commit(exact, { keepOpen: true });
			return;
		}
		this.activeIndex.set(this.filtered().length > 0 ? 0 : -1);
	}
	onFocus() {
		if (!this.readOnly() && !this.disabled()) {
			this.open.set(true);
			this.activeIndex.set(this.indexOfSelected());
		}
	}
	onKeydown(event) {
		if (this.readOnly() || this.disabled()) return;
		switch (event.key) {
			case "ArrowDown":
				event.preventDefault();
				this.openIfClosed();
				this.move(1);
				break;
			case "ArrowUp":
				event.preventDefault();
				this.openIfClosed();
				this.move(-1);
				break;
			case "Home":
				if (this.open()) {
					event.preventDefault();
					this.activeIndex.set(0);
				}
				break;
			case "End":
				if (this.open()) {
					event.preventDefault();
					this.activeIndex.set(this.filtered().length - 1);
				}
				break;
			case "Enter": {
				if (!this.open()) return;
				const option = this.filtered()[this.activeIndex()];
				if (option) {
					event.preventDefault();
					this.commit(option);
				}
				break;
			}
			case "Escape":
				if (this.open() || this.query() !== null) {
					event.preventDefault();
					this.revert();
				}
				break;
			case "Tab": this.closeAndSettle();
		}
	}
	onOptionClick(option) {
		this.commit(option);
		this.inputElement()?.nativeElement.focus();
	}
	onBlur() {
		this.closeAndSettle();
		this.onTouched();
	}
	openIfClosed() {
		if (!this.open()) {
			this.open.set(true);
			this.activeIndex.set(this.indexOfSelected());
		}
	}
	move(delta) {
		const list = this.filtered();
		if (list.length === 0) {
			this.activeIndex.set(-1);
			return;
		}
		const next = this.activeIndex() + delta;
		this.activeIndex.set((next % list.length + list.length) % list.length);
	}
	indexOfSelected() {
		const index = this.filtered().findIndex((option) => option.code === this.selectedCode());
		return index >= 0 ? index : 0;
	}
	commit(option, options = {}) {
		this.selectedCode.set(option.code);
		this.onChange(option.code);
		if (!options.keepOpen) {
			this.query.set(null);
			this.open.set(false);
			this.activeIndex.set(-1);
		}
	}
	revert() {
		this.query.set(null);
		this.open.set(false);
		this.activeIndex.set(-1);
	}
	closeAndSettle() {
		this.query.set(null);
		this.open.set(false);
		this.activeIndex.set(-1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: CodeComboComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: CodeComboComponent,
		isStandalone: true,
		selector: "cms-code-combo",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => CodeComboComponent),
			multi: true
		}],
		viewQueries: [{
			propertyName: "inputElement",
			first: true,
			predicate: ["comboInput"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n\r\n  <div class=\"cws:relative\">\r\n    <!--\r\n      ARIA combobox pattern: focus never leaves this input. The active option is conveyed by\r\n      aria-activedescendant, so arrow keys announce options without moving DOM focus.\r\n    -->\r\n    <input\r\n      #comboInput\r\n      class=\"scoular-form-input\"\r\n      [class.error]=\"errorMessage() !== null\"\r\n      [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n      [id]=\"controlId()\"\r\n      type=\"text\"\r\n      role=\"combobox\"\r\n      autocomplete=\"off\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      [attr.aria-controls]=\"controlId() + '-listbox'\"\r\n      [attr.aria-activedescendant]=\"activeOptionId()\"\r\n      aria-autocomplete=\"list\"\r\n      [value]=\"displayValue()\"\r\n      [readOnly]=\"readOnly()\"\r\n      [disabled]=\"disabled()\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"warningText()\"\r\n      (focus)=\"onFocus()\"\r\n      (input)=\"onInput($event)\"\r\n      (keydown)=\"onKeydown($event)\"\r\n      (blur)=\"onBlur()\"\r\n    />\r\n\r\n    @if (open()) {\r\n      <ul\r\n        class=\"scoular-dropdown cws:absolute cws:mt-1 cws:max-h-60 cws:w-full cws:overflow-auto\"\r\n        role=\"listbox\"\r\n        [id]=\"controlId() + '-listbox'\"\r\n        [attr.aria-label]=\"label()\"\r\n      >\r\n        @for (option of filtered(); track option.code; let i = $index) {\r\n          <!--\r\n            mousedown rather than click: blur fires first on click and would close the list before\r\n            the selection registered.\r\n          -->\r\n          <!--\r\n            ⚠ These rows deliberately do NOT use `.scoular-dropdown-item`. The whole class string\r\n            comes from `optionClass()`, and the reasoning — two contrast bugs, both caused by\r\n            unlayered design-system CSS beating Tailwind utilities — is documented there. Do not\r\n            \"restore\" the design-system class: it re-breaks both, and both look fine in review.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n          -->\r\n          <li\r\n            [class]=\"optionClass(i === activeIndex())\"\r\n            role=\"option\"\r\n            [id]=\"optionId(i)\"\r\n            [attr.aria-selected]=\"i === activeIndex()\"\r\n            (mousedown)=\"$event.preventDefault(); onOptionClick(option)\"\r\n          >\r\n            <span class=\"cws:font-mono cws:text-xs\">{{ option.code }}</span>\r\n            <span class=\"cws:mx-1\" aria-hidden=\"true\">—</span>\r\n            <span>{{ option.description }}</span>\r\n          </li>\r\n        } @empty {\r\n          <li\r\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\"\r\n            role=\"option\"\r\n            aria-disabled=\"true\"\r\n          >\r\n            No matches\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n</cms-field>\r\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: CodeComboComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-code-combo",
			imports: [FieldComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => CodeComboComponent),
				multi: true
			}],
			template: "<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n\r\n  <div class=\"cws:relative\">\r\n    <!--\r\n      ARIA combobox pattern: focus never leaves this input. The active option is conveyed by\r\n      aria-activedescendant, so arrow keys announce options without moving DOM focus.\r\n    -->\r\n    <input\r\n      #comboInput\r\n      class=\"scoular-form-input\"\r\n      [class.error]=\"errorMessage() !== null\"\r\n      [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n      [id]=\"controlId()\"\r\n      type=\"text\"\r\n      role=\"combobox\"\r\n      autocomplete=\"off\"\r\n      [attr.aria-expanded]=\"open()\"\r\n      [attr.aria-controls]=\"controlId() + '-listbox'\"\r\n      [attr.aria-activedescendant]=\"activeOptionId()\"\r\n      aria-autocomplete=\"list\"\r\n      [value]=\"displayValue()\"\r\n      [readOnly]=\"readOnly()\"\r\n      [disabled]=\"disabled()\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"warningText()\"\r\n      (focus)=\"onFocus()\"\r\n      (input)=\"onInput($event)\"\r\n      (keydown)=\"onKeydown($event)\"\r\n      (blur)=\"onBlur()\"\r\n    />\r\n\r\n    @if (open()) {\r\n      <ul\r\n        class=\"scoular-dropdown cws:absolute cws:mt-1 cws:max-h-60 cws:w-full cws:overflow-auto\"\r\n        role=\"listbox\"\r\n        [id]=\"controlId() + '-listbox'\"\r\n        [attr.aria-label]=\"label()\"\r\n      >\r\n        @for (option of filtered(); track option.code; let i = $index) {\r\n          <!--\r\n            mousedown rather than click: blur fires first on click and would close the list before\r\n            the selection registered.\r\n          -->\r\n          <!--\r\n            ⚠ These rows deliberately do NOT use `.scoular-dropdown-item`. The whole class string\r\n            comes from `optionClass()`, and the reasoning — two contrast bugs, both caused by\r\n            unlayered design-system CSS beating Tailwind utilities — is documented there. Do not\r\n            \"restore\" the design-system class: it re-breaks both, and both look fine in review.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n          -->\r\n          <li\r\n            [class]=\"optionClass(i === activeIndex())\"\r\n            role=\"option\"\r\n            [id]=\"optionId(i)\"\r\n            [attr.aria-selected]=\"i === activeIndex()\"\r\n            (mousedown)=\"$event.preventDefault(); onOptionClick(option)\"\r\n          >\r\n            <span class=\"cws:font-mono cws:text-xs\">{{ option.code }}</span>\r\n            <span class=\"cws:mx-1\" aria-hidden=\"true\">—</span>\r\n            <span>{{ option.description }}</span>\r\n          </li>\r\n        } @empty {\r\n          <li\r\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\"\r\n            role=\"option\"\r\n            aria-disabled=\"true\"\r\n          >\r\n            No matches\r\n          </li>\r\n        }\r\n      </ul>\r\n    }\r\n  </div>\r\n</cms-field>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		inputElement: [{
			type: i0.ViewChild,
			args: ["comboInput", { isSignal: true }]
		}]
	}
});
const OPTION_LAYOUT = "cws:flex cws:w-full cws:cursor-pointer cws:items-center cws:gap-3 cws:px-4 cws:py-2 cws:text-sm cws:transition-colors";
const ACTIVE_OPTION_CLASS = `${OPTION_LAYOUT} cws:bg-scoular-blue cws:text-white cws:hover:bg-scoular-blue-dark`;
const INACTIVE_OPTION_CLASS = `${OPTION_LAYOUT} cws:text-slate-700 cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700`;
const WEEKDAYS = [
	{
		short: "Su",
		full: "Sunday"
	},
	{
		short: "Mo",
		full: "Monday"
	},
	{
		short: "Tu",
		full: "Tuesday"
	},
	{
		short: "We",
		full: "Wednesday"
	},
	{
		short: "Th",
		full: "Thursday"
	},
	{
		short: "Fr",
		full: "Friday"
	},
	{
		short: "Sa",
		full: "Saturday"
	}
];
const MONTHS = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
const CELLS = 42;
var DatePickerComponent = class DatePickerComponent {
	value = input(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	today = input(toIsoDate(nowParts()), ...ngDevMode ? [{ debugName: "today" }] : /* istanbul ignore next */ []);
	dateSelected = output();
	cleared = output();
	dismissed = output();
	grid = viewChild("grid", ...ngDevMode ? [{ debugName: "grid" }] : /* istanbul ignore next */ []);
	host = inject(ElementRef);
	view = signal("day", ...ngDevMode ? [{ debugName: "view" }] : /* istanbul ignore next */ []);
	focused = signal(this.today(), ...ngDevMode ? [{ debugName: "focused" }] : /* istanbul ignore next */ []);
	viewMonth = computed(() => {
		const parsed = fromIsoDate(this.focused());
		return parsed === null ? this.today() : toIsoDate({
			year: parsed.year,
			month: parsed.month,
			day: 1
		});
	}, ...ngDevMode ? [{ debugName: "viewMonth" }] : /* istanbul ignore next */ []);
	weekdays = WEEKDAYS;
	months = MONTHS;
	monthLabel = computed(() => {
		const parsed = fromIsoDate(this.viewMonth());
		return parsed === null ? "" : `${MONTHS[parsed.month - 1]} ${parsed.year}`;
	}, ...ngDevMode ? [{ debugName: "monthLabel" }] : /* istanbul ignore next */ []);
	decadeStart = computed(() => {
		const parsed = fromIsoDate(this.focused());
		const year = parsed === null ? nowParts().year : parsed.year;
		return year - (year % 12 + 12) % 12;
	}, ...ngDevMode ? [{ debugName: "decadeStart" }] : /* istanbul ignore next */ []);
	decadeYears = computed(() => Array.from({ length: 12 }, (_, index) => this.decadeStart() + index), ...ngDevMode ? [{ debugName: "decadeYears" }] : /* istanbul ignore next */ []);
	decadeLabel = computed(() => `${this.decadeStart()} – ${this.decadeStart() + 11}`, ...ngDevMode ? [{ debugName: "decadeLabel" }] : /* istanbul ignore next */ []);
	days = computed(() => {
		const first = this.viewMonth();
		const parsedFirst = fromIsoDate(first);
		if (parsedFirst === null) return [];
		const offset = dayOfWeek(first) ?? 0;
		const start = addDays(first, -offset);
		if (start === null) return [];
		const selected = this.value();
		const today = this.today();
		const focused = this.focused();
		const cells = [];
		for (let index = 0; index < CELLS; index += 1) {
			const iso = addDays(start, index);
			if (iso === null) continue;
			const parsed = fromIsoDate(iso);
			if (parsed === null) continue;
			cells.push({
				iso,
				day: parsed.day,
				adjacent: parsed.month !== parsedFirst.month,
				today: iso === today,
				selected: selected !== null && iso === selected,
				focused: iso === focused,
				label: `${MONTHS[parsed.month - 1]} ${parsed.day}, ${parsed.year}`
			});
		}
		return cells;
	}, ...ngDevMode ? [{ debugName: "days" }] : /* istanbul ignore next */ []);
	showClear = computed(() => !this.required() && this.value() !== null, ...ngDevMode ? [{ debugName: "showClear" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const value = this.value();
			this.focused.set(value !== null && fromIsoDate(value) !== null ? value : this.today());
		});
	}
	focusActiveCell() {
		queueMicrotask(() => {
			this.host.nativeElement.querySelector("[data-active=\"true\"]")?.focus();
		});
	}
	select(iso) {
		const parsed = fromIsoDate(iso);
		if (parsed === null || !isRealDate(parsed)) return;
		this.dateSelected.emit(iso);
	}
	step(days) {
		const next = addDays(this.focused(), days);
		if (next !== null) {
			this.focused.set(next);
			this.focusActiveCell();
		}
	}
	stepMonths(count) {
		const next = addMonths(this.focused(), count);
		if (next !== null) {
			this.focused.set(next);
			this.focusActiveCell();
		}
	}
	page(direction) {
		const view = this.view();
		if (view === "day") {
			this.stepMonths(direction);
			return;
		}
		if (view === "month") {
			this.stepMonths(direction * 12);
			return;
		}
		this.stepMonths(direction * 12 * 12);
	}
	pageLabel(direction) {
		const unit = this.view() === "day" ? "month" : this.view() === "month" ? "year" : "decade";
		return `${direction === -1 ? "Previous" : "Next"} ${unit}`;
	}
	cycleView() {
		this.view.update((current) => current === "day" ? "month" : current === "month" ? "year" : "day");
	}
	chooseMonth(monthIndex) {
		const parsed = fromIsoDate(this.focused());
		if (parsed === null) return;
		const lastDay = new Date(Date.UTC(parsed.year, monthIndex + 1, 0)).getUTCDate();
		this.focused.set(toIsoDate({
			year: parsed.year,
			month: monthIndex + 1,
			day: Math.min(parsed.day, lastDay)
		}));
		this.view.set("day");
		this.focusActiveCell();
	}
	chooseYear(year) {
		const parsed = fromIsoDate(this.focused());
		if (parsed === null) return;
		const lastDay = new Date(Date.UTC(year, parsed.month, 0)).getUTCDate();
		this.focused.set(toIsoDate({
			year,
			month: parsed.month,
			day: Math.min(parsed.day, lastDay)
		}));
		this.view.set("month");
	}
	onToday() {
		this.focused.set(this.today());
		this.view.set("day");
		this.select(this.today());
	}
	onClear() {
		this.cleared.emit();
	}
	onGridKeydown(event) {
		const key = event.key;
		if (key === "ArrowLeft") this.step(-1);
		else if (key === "ArrowRight") this.step(1);
		else if (key === "ArrowUp") this.step(-7);
		else if (key === "ArrowDown") this.step(7);
		else if (key === "Home") this.step(-(dayOfWeek(this.focused()) ?? 0));
		else if (key === "End") this.step(6 - (dayOfWeek(this.focused()) ?? 0));
		else if (key === "PageUp") this.stepMonths(event.shiftKey ? -12 : -1);
		else if (key === "PageDown") this.stepMonths(event.shiftKey ? 12 : 1);
		else if (key === "Enter" || key === " ") this.select(this.focused());
		else return;
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: DatePickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: DatePickerComponent,
		isStandalone: true,
		selector: "cms-date-picker",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			today: {
				classPropertyName: "today",
				publicName: "today",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			dateSelected: "dateSelected",
			cleared: "cleared",
			dismissed: "dismissed"
		},
		host: { classAttribute: "cws:block" },
		viewQueries: [{
			propertyName: "grid",
			first: true,
			predicate: ["grid"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<!--\r\n  🔴 Utilities composed directly, never layered over a `scoular-*` class.\r\n\r\n  The design system compiles UNLAYERED while Tailwind utilities land in `@layer utilities`, so a\r\n  utility beside a design-system class silently loses and looks entirely correct in review. The day\r\n  cells therefore wear no `scoular-*` class at all -- their size, radius and fill are all utilities,\r\n  so nothing is contested. The two footer buttons DO use `scoular-btn`, and add only height, which\r\n  the design system leaves undeclared.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n-->\r\n<div\r\n  class=\"cws:w-72 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-3 cws:shadow-lg cws:dark:border-slate-700 cws:dark:bg-slate-800\"\r\n  role=\"dialog\"\r\n  aria-label=\"Choose a date\"\r\n  aria-modal=\"true\"\r\n>\r\n  <!--\r\n    The header. Chevrons FLANK the label rather than sitting together at one end: the native picker\r\n    put both arrows in the top-right corner, so paging back meant aiming at a control nowhere near\r\n    the month it changed.\r\n  -->\r\n  <div class=\"cws:mb-2 cws:flex cws:items-center cws:justify-between cws:gap-1\">\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\r\n      [attr.aria-label]=\"pageLabel(-1)\"\r\n      (click)=\"page(-1)\"\r\n    >\r\n      <span aria-hidden=\"true\">&#8249;</span>\r\n    </button>\r\n\r\n    <!--\r\n      One button, cycling day -> month -> year. A separate month menu and year menu would be two\r\n      controls for one question (\"show me a different month\"), and the drill-up is what every\r\n      calendar the user has met already does.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:flex-1 cws:rounded cws:px-2 cws:py-1 cws:text-sm cws:font-semibold cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\r\n      [attr.aria-label]=\"'Showing ' + (view() === 'year' ? decadeLabel() : monthLabel()) + '. Change view.'\"\r\n      (click)=\"cycleView()\"\r\n    >\r\n      {{ view() === 'year' ? decadeLabel() : monthLabel() }}\r\n    </button>\r\n\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\r\n      [attr.aria-label]=\"pageLabel(1)\"\r\n      (click)=\"page(1)\"\r\n    >\r\n      <span aria-hidden=\"true\">&#8250;</span>\r\n    </button>\r\n  </div>\r\n\r\n  @if (view() === 'day') {\r\n    <!--\r\n      `abbr` on the short weekday names, so a screen reader says \"Monday\" where a sighted reader\r\n      sees \"Mo\". Two letters is what keeps the column 2.25rem wide.\r\n    -->\r\n    <div class=\"cws:grid cws:grid-cols-7\" aria-hidden=\"true\">\r\n      @for (weekday of weekdays; track weekday.short) {\r\n        <div class=\"cws:flex cws:h-7 cws:w-9 cws:items-center cws:justify-center cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <abbr class=\"cws:no-underline\" [title]=\"weekday.full\">{{ weekday.short }}</abbr>\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <!--\r\n      🔴 Roving tabindex: exactly ONE cell is tabbable and the arrows move which. Making every cell\r\n      tabbable would put 42 stops between the grid and the footer.\r\n\r\n      `data-active` is what `focusActiveCell` aims at -- an attribute rather than a class so that\r\n      restyling a cell can never change which one receives focus.\r\n    -->\r\n    <!--\r\n      🔴 The colour choices here are MEASURED, not picked. In Edge against the built stylesheet:\r\n\r\n        selected text on its fill    7.54 light / 7.54 dark\r\n        selected chip vs surface     7.54 light / ring at 6.71 dark\r\n        today ring on the surface    7.54 light / 6.71 dark\r\n        plain in-month day           17.83 light / 14.62 dark\r\n        adjacent-month day            4.76 light /  5.56 dark\r\n\r\n      ⚠ Three of those were failures first time, and the dark-mode one is a genuine tension\r\n      rather than a slip. `bg-scoular-blue` measures **1.94:1** against the dark panel -- the\r\n      brand blue IS a dark blue -- so the selected chip nearly vanished and the 1px today ring\r\n      was invisible. But every blue light enough to separate from that panel is too light to\r\n      carry white text: `sky-600` fixed the surface (3.63) and broke the text (4.02).\r\n\r\n      🔑 So the fill keeps the brand blue, which white text clears at 7.54, and the chip is\r\n      separated from the dark panel by a `sky-400` RING at 6.71 -- a boundary rather than a fill,\r\n      which is what WCAG 1.4.11 asks for on a non-text component. `sky-400` is also what the rest\r\n      of the application already uses for a blue accent in the dark theme.\r\n\r\n      ⚠ Adjacent-month days were `slate-400`/`slate-500` and measured 2.63 and 3.07. They are\r\n      meant to be quiet, but they are CLICKABLE, so they have to be legible: one step in each\r\n      theme clears 4.5:1 while staying visibly dimmer than an in-month day.\r\n\r\n      🔴 **Each class below is bound EXACTLY ONCE.** Two `[class.x]` bindings for one class do not\r\n      combine -- Angular applies the last, so the first condition is silently dead. `ring-1`,\r\n      `ring-inset` and `dark:ring-sky-400` were each bound twice here, and the selected day lost\r\n      its ring entirely: the markup read correctly and the DOM simply did not have the class.\r\n      Caught by dumping the rendered cell and grepping it, not by reading the template.\r\n\r\n      ⚠ Today keeps a ring even when it is also the selected day, which is why the ring colour\r\n      switches to white there -- a brand-blue ring on a brand-blue fill is invisible, so \"today\"\r\n      would disappear on exactly the day a user is most likely to be looking at.\r\n\r\n      ⚠ The dark selected chip is separated by a BORDER rather than a ring, because the ring is\r\n      already spoken for by today. Different property, no collision, and the cell is a fixed\r\n      `h-9 w-9` under border-box so a 1px border cannot move the grid.\r\n    -->\r\n    <div #grid role=\"grid\" class=\"cws:grid cws:grid-cols-7\" (keydown)=\"onGridKeydown($event)\">\r\n      @for (cell of days(); track cell.iso) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"gridcell\"\r\n          class=\"cws:flex cws:h-9 cws:w-9 cws:items-center cws:justify-center cws:rounded-full cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue\"\r\n          [class.cws:bg-scoular-blue]=\"cell.selected\"\r\n          [class.cws:text-white]=\"cell.selected\"\r\n          [class.cws:font-semibold]=\"cell.selected\"\r\n\r\n          [class.cws:ring-1]=\"cell.today\"\r\n          [class.cws:ring-inset]=\"cell.today\"\r\n          [class.cws:ring-white]=\"cell.today && cell.selected\"\r\n          [class.cws:ring-scoular-blue]=\"cell.today && !cell.selected\"\r\n          [class.cws:dark:ring-sky-400]=\"cell.today && !cell.selected\"\r\n\r\n          [class.cws:dark:border]=\"cell.selected\"\r\n          [class.cws:dark:border-sky-400]=\"cell.selected\"\r\n          [class.cws:text-slate-900]=\"!cell.selected && !cell.adjacent\"\r\n          [class.cws:dark:text-white]=\"!cell.selected && !cell.adjacent\"\r\n          [class.cws:text-slate-500]=\"!cell.selected && cell.adjacent\"\r\n          [class.cws:dark:text-slate-400]=\"!cell.selected && cell.adjacent\"\r\n          [class.cws:hover:bg-slate-100]=\"!cell.selected\"\r\n          [class.cws:dark:hover:bg-slate-700]=\"!cell.selected\"\r\n          [attr.data-active]=\"cell.focused ? 'true' : null\"\r\n          [attr.tabindex]=\"cell.focused ? 0 : -1\"\r\n          [attr.aria-label]=\"cell.label\"\r\n          [attr.aria-selected]=\"cell.selected ? 'true' : 'false'\"\r\n          [attr.aria-current]=\"cell.today ? 'date' : null\"\r\n          (click)=\"select(cell.iso)\"\r\n        >\r\n          {{ cell.day }}\r\n        </button>\r\n      }\r\n    </div>\r\n  } @else if (view() === 'month') {\r\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a month\">\r\n      @for (month of months; track month; let index = $index) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"gridcell\"\r\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\r\n          (click)=\"chooseMonth(index)\"\r\n        >\r\n          {{ month.slice(0, 3) }}\r\n        </button>\r\n      }\r\n    </div>\r\n  } @else {\r\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a year\">\r\n      @for (year of decadeYears(); track year) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"gridcell\"\r\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\r\n          (click)=\"chooseYear(year)\"\r\n        >\r\n          {{ year }}\r\n        </button>\r\n      }\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    ⚠ Real buttons in a row, both left-aligned. The native picker splits \"Clear\" and \"Today\" into\r\n    opposite corners as text links, which reads as one destructive control and one navigational one\r\n    when they are two peers.\r\n\r\n    `h-8` is added to `scoular-btn-sm` because the design system sets that variant's padding and font\r\n    size and never its height -- supplying a property nobody else declares applies normally, where\r\n    one that fought `py-1` would lose to the unlayered rule.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <div class=\"cws:mt-2 cws:flex cws:items-center cws:gap-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:dark:border-slate-700\">\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\r\n      (click)=\"onToday()\"\r\n    >\r\n      Today\r\n    </button>\r\n\r\n    @if (showClear()) {\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\r\n        (click)=\"onClear()\"\r\n      >\r\n        Clear\r\n      </button>\r\n    }\r\n  </div>\r\n</div>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: DatePickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-date-picker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: "<!--\r\n  🔴 Utilities composed directly, never layered over a `scoular-*` class.\r\n\r\n  The design system compiles UNLAYERED while Tailwind utilities land in `@layer utilities`, so a\r\n  utility beside a design-system class silently loses and looks entirely correct in review. The day\r\n  cells therefore wear no `scoular-*` class at all -- their size, radius and fill are all utilities,\r\n  so nothing is contested. The two footer buttons DO use `scoular-btn`, and add only height, which\r\n  the design system leaves undeclared.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n-->\r\n<div\r\n  class=\"cws:w-72 cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:p-3 cws:shadow-lg cws:dark:border-slate-700 cws:dark:bg-slate-800\"\r\n  role=\"dialog\"\r\n  aria-label=\"Choose a date\"\r\n  aria-modal=\"true\"\r\n>\r\n  <!--\r\n    The header. Chevrons FLANK the label rather than sitting together at one end: the native picker\r\n    put both arrows in the top-right corner, so paging back meant aiming at a control nowhere near\r\n    the month it changed.\r\n  -->\r\n  <div class=\"cws:mb-2 cws:flex cws:items-center cws:justify-between cws:gap-1\">\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\r\n      [attr.aria-label]=\"pageLabel(-1)\"\r\n      (click)=\"page(-1)\"\r\n    >\r\n      <span aria-hidden=\"true\">&#8249;</span>\r\n    </button>\r\n\r\n    <!--\r\n      One button, cycling day -> month -> year. A separate month menu and year menu would be two\r\n      controls for one question (\"show me a different month\"), and the drill-up is what every\r\n      calendar the user has met already does.\r\n    -->\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:flex-1 cws:rounded cws:px-2 cws:py-1 cws:text-sm cws:font-semibold cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\r\n      [attr.aria-label]=\"'Showing ' + (view() === 'year' ? decadeLabel() : monthLabel()) + '. Change view.'\"\r\n      (click)=\"cycleView()\"\r\n    >\r\n      {{ view() === 'year' ? decadeLabel() : monthLabel() }}\r\n    </button>\r\n\r\n    <button\r\n      type=\"button\"\r\n      class=\"cws:flex cws:h-7 cws:w-7 cws:items-center cws:justify-center cws:rounded cws:text-slate-600 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700\"\r\n      [attr.aria-label]=\"pageLabel(1)\"\r\n      (click)=\"page(1)\"\r\n    >\r\n      <span aria-hidden=\"true\">&#8250;</span>\r\n    </button>\r\n  </div>\r\n\r\n  @if (view() === 'day') {\r\n    <!--\r\n      `abbr` on the short weekday names, so a screen reader says \"Monday\" where a sighted reader\r\n      sees \"Mo\". Two letters is what keeps the column 2.25rem wide.\r\n    -->\r\n    <div class=\"cws:grid cws:grid-cols-7\" aria-hidden=\"true\">\r\n      @for (weekday of weekdays; track weekday.short) {\r\n        <div class=\"cws:flex cws:h-7 cws:w-9 cws:items-center cws:justify-center cws:text-xs cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <abbr class=\"cws:no-underline\" [title]=\"weekday.full\">{{ weekday.short }}</abbr>\r\n        </div>\r\n      }\r\n    </div>\r\n\r\n    <!--\r\n      🔴 Roving tabindex: exactly ONE cell is tabbable and the arrows move which. Making every cell\r\n      tabbable would put 42 stops between the grid and the footer.\r\n\r\n      `data-active` is what `focusActiveCell` aims at -- an attribute rather than a class so that\r\n      restyling a cell can never change which one receives focus.\r\n    -->\r\n    <!--\r\n      🔴 The colour choices here are MEASURED, not picked. In Edge against the built stylesheet:\r\n\r\n        selected text on its fill    7.54 light / 7.54 dark\r\n        selected chip vs surface     7.54 light / ring at 6.71 dark\r\n        today ring on the surface    7.54 light / 6.71 dark\r\n        plain in-month day           17.83 light / 14.62 dark\r\n        adjacent-month day            4.76 light /  5.56 dark\r\n\r\n      ⚠ Three of those were failures first time, and the dark-mode one is a genuine tension\r\n      rather than a slip. `bg-scoular-blue` measures **1.94:1** against the dark panel -- the\r\n      brand blue IS a dark blue -- so the selected chip nearly vanished and the 1px today ring\r\n      was invisible. But every blue light enough to separate from that panel is too light to\r\n      carry white text: `sky-600` fixed the surface (3.63) and broke the text (4.02).\r\n\r\n      🔑 So the fill keeps the brand blue, which white text clears at 7.54, and the chip is\r\n      separated from the dark panel by a `sky-400` RING at 6.71 -- a boundary rather than a fill,\r\n      which is what WCAG 1.4.11 asks for on a non-text component. `sky-400` is also what the rest\r\n      of the application already uses for a blue accent in the dark theme.\r\n\r\n      ⚠ Adjacent-month days were `slate-400`/`slate-500` and measured 2.63 and 3.07. They are\r\n      meant to be quiet, but they are CLICKABLE, so they have to be legible: one step in each\r\n      theme clears 4.5:1 while staying visibly dimmer than an in-month day.\r\n\r\n      🔴 **Each class below is bound EXACTLY ONCE.** Two `[class.x]` bindings for one class do not\r\n      combine -- Angular applies the last, so the first condition is silently dead. `ring-1`,\r\n      `ring-inset` and `dark:ring-sky-400` were each bound twice here, and the selected day lost\r\n      its ring entirely: the markup read correctly and the DOM simply did not have the class.\r\n      Caught by dumping the rendered cell and grepping it, not by reading the template.\r\n\r\n      ⚠ Today keeps a ring even when it is also the selected day, which is why the ring colour\r\n      switches to white there -- a brand-blue ring on a brand-blue fill is invisible, so \"today\"\r\n      would disappear on exactly the day a user is most likely to be looking at.\r\n\r\n      ⚠ The dark selected chip is separated by a BORDER rather than a ring, because the ring is\r\n      already spoken for by today. Different property, no collision, and the cell is a fixed\r\n      `h-9 w-9` under border-box so a 1px border cannot move the grid.\r\n    -->\r\n    <div #grid role=\"grid\" class=\"cws:grid cws:grid-cols-7\" (keydown)=\"onGridKeydown($event)\">\r\n      @for (cell of days(); track cell.iso) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"gridcell\"\r\n          class=\"cws:flex cws:h-9 cws:w-9 cws:items-center cws:justify-center cws:rounded-full cws:text-sm cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue\"\r\n          [class.cws:bg-scoular-blue]=\"cell.selected\"\r\n          [class.cws:text-white]=\"cell.selected\"\r\n          [class.cws:font-semibold]=\"cell.selected\"\r\n\r\n          [class.cws:ring-1]=\"cell.today\"\r\n          [class.cws:ring-inset]=\"cell.today\"\r\n          [class.cws:ring-white]=\"cell.today && cell.selected\"\r\n          [class.cws:ring-scoular-blue]=\"cell.today && !cell.selected\"\r\n          [class.cws:dark:ring-sky-400]=\"cell.today && !cell.selected\"\r\n\r\n          [class.cws:dark:border]=\"cell.selected\"\r\n          [class.cws:dark:border-sky-400]=\"cell.selected\"\r\n          [class.cws:text-slate-900]=\"!cell.selected && !cell.adjacent\"\r\n          [class.cws:dark:text-white]=\"!cell.selected && !cell.adjacent\"\r\n          [class.cws:text-slate-500]=\"!cell.selected && cell.adjacent\"\r\n          [class.cws:dark:text-slate-400]=\"!cell.selected && cell.adjacent\"\r\n          [class.cws:hover:bg-slate-100]=\"!cell.selected\"\r\n          [class.cws:dark:hover:bg-slate-700]=\"!cell.selected\"\r\n          [attr.data-active]=\"cell.focused ? 'true' : null\"\r\n          [attr.tabindex]=\"cell.focused ? 0 : -1\"\r\n          [attr.aria-label]=\"cell.label\"\r\n          [attr.aria-selected]=\"cell.selected ? 'true' : 'false'\"\r\n          [attr.aria-current]=\"cell.today ? 'date' : null\"\r\n          (click)=\"select(cell.iso)\"\r\n        >\r\n          {{ cell.day }}\r\n        </button>\r\n      }\r\n    </div>\r\n  } @else if (view() === 'month') {\r\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a month\">\r\n      @for (month of months; track month; let index = $index) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"gridcell\"\r\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\r\n          (click)=\"chooseMonth(index)\"\r\n        >\r\n          {{ month.slice(0, 3) }}\r\n        </button>\r\n      }\r\n    </div>\r\n  } @else {\r\n    <div class=\"cws:grid cws:grid-cols-3 cws:gap-1\" role=\"grid\" aria-label=\"Choose a year\">\r\n      @for (year of decadeYears(); track year) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"gridcell\"\r\n          class=\"cws:rounded cws:px-2 cws:py-2 cws:text-sm cws:text-slate-900 cws:hover:bg-slate-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-white cws:dark:hover:bg-slate-700\"\r\n          (click)=\"chooseYear(year)\"\r\n        >\r\n          {{ year }}\r\n        </button>\r\n      }\r\n    </div>\r\n  }\r\n\r\n  <!--\r\n    ⚠ Real buttons in a row, both left-aligned. The native picker splits \"Clear\" and \"Today\" into\r\n    opposite corners as text links, which reads as one destructive control and one navigational one\r\n    when they are two peers.\r\n\r\n    `h-8` is added to `scoular-btn-sm` because the design system sets that variant's padding and font\r\n    size and never its height -- supplying a property nobody else declares applies normally, where\r\n    one that fought `py-1` would lose to the unlayered rule.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <div class=\"cws:mt-2 cws:flex cws:items-center cws:gap-2 cws:border-t cws:border-slate-200 cws:pt-2 cws:dark:border-slate-700\">\r\n    <button\r\n      type=\"button\"\r\n      class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\r\n      (click)=\"onToday()\"\r\n    >\r\n      Today\r\n    </button>\r\n\r\n    @if (showClear()) {\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-outline scoular-btn-sm cws:h-8\"\r\n        (click)=\"onClear()\"\r\n      >\r\n        Clear\r\n      </button>\r\n    }\r\n  </div>\r\n</div>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		today: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "today",
				required: false
			}]
		}],
		dateSelected: [{
			type: i0.Output,
			args: ["dateSelected"]
		}],
		cleared: [{
			type: i0.Output,
			args: ["cleared"]
		}],
		dismissed: [{
			type: i0.Output,
			args: ["dismissed"]
		}],
		grid: [{
			type: i0.ViewChild,
			args: ["grid", { isSignal: true }]
		}]
	}
});
function nowParts() {
	const now = /* @__PURE__ */ new Date();
	return {
		year: now.getFullYear(),
		month: now.getMonth() + 1,
		day: now.getDate()
	};
}
var DateInputComponent = class DateInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = signal(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	rawText = signal(null, ...ngDevMode ? [{ debugName: "rawText" }] : /* istanbul ignore next */ []);
	parseError = signal(false, ...ngDevMode ? [{ debugName: "parseError" }] : /* istanbul ignore next */ []);
	displayValue = computed(() => {
		const raw = this.rawText();
		if (raw !== null) return raw;
		return this.formatForDisplay(this.value());
	}, ...ngDevMode ? [{ debugName: "displayValue" }] : /* istanbul ignore next */ []);
	effectiveError = computed(() => this.parseError() ? "Enter a date as MMDDYYYY, MMDDYY or MM/DD/YYYY." : this.errorMessage(), ...ngDevMode ? [{ debugName: "effectiveError" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		if (this.effectiveError()) return `${this.controlId()}-error`;
		return this.warningText() ? `${this.controlId()}-hint` : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	overlay = inject(Overlay);
	pickerScroll = this.overlay.scrollStrategies.reposition();
	pickerOpen = signal(false, ...ngDevMode ? [{ debugName: "pickerOpen" }] : /* istanbul ignore next */ []);
	textInput = viewChild("textInput", ...ngDevMode ? [{ debugName: "textInput" }] : /* istanbul ignore next */ []);
	picker = viewChild(DatePickerComponent, ...ngDevMode ? [{ debugName: "picker" }] : /* istanbul ignore next */ []);
	pickerValue = computed(() => this.value(), ...ngDevMode ? [{ debugName: "pickerValue" }] : /* istanbul ignore next */ []);
	showTrigger = computed(() => !this.readOnly() && !this.disabled(), ...ngDevMode ? [{ debugName: "showTrigger" }] : /* istanbul ignore next */ []);
	pickerPositions = [{
		originX: "start",
		originY: "bottom",
		overlayX: "start",
		overlayY: "top",
		offsetY: 4
	}, {
		originX: "start",
		originY: "top",
		overlayX: "start",
		overlayY: "bottom",
		offsetY: -4
	}];
	onOverlayKeydown(event) {
		if (event.key !== "Escape") return;
		this.closePicker();
		event.preventDefault();
		event.stopPropagation();
	}
	togglePicker() {
		this.pickerOpen() ? this.closePicker() : this.openPicker();
	}
	openPicker() {
		if (!this.showTrigger()) return;
		this.pickerOpen.set(true);
	}
	closePicker() {
		if (!this.pickerOpen()) return;
		this.pickerOpen.set(false);
		this.textInput()?.nativeElement.focus();
	}
	onPickerAttached() {
		this.picker()?.focusActiveCell();
	}
	onPicked(iso) {
		this.value.set(iso);
		this.rawText.set(null);
		this.parseError.set(false);
		this.onChange(iso);
		this.onTouched();
		this.closePicker();
	}
	onPickerCleared() {
		this.value.set(null);
		this.rawText.set(null);
		this.parseError.set(false);
		this.onChange(null);
		this.onTouched();
		this.closePicker();
	}
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "string" && value !== "" ? value : null);
		this.rawText.set(null);
		this.parseError.set(false);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		this.rawText.set(event.target.value);
		this.parseError.set(false);
	}
	onBlur() {
		const raw = this.rawText();
		if (raw !== null) {
			const trimmed = raw.trim();
			if (trimmed === "") {
				this.value.set(null);
				this.rawText.set(null);
				this.parseError.set(false);
				this.onChange(null);
			} else {
				const parsed = parseShipPeriodDate(trimmed, (/* @__PURE__ */ new Date()).getFullYear());
				if (parsed === null) {
					this.parseError.set(true);
					this.onChange(null);
				} else {
					this.value.set(parsed);
					this.rawText.set(null);
					this.parseError.set(false);
					this.onChange(parsed);
				}
			}
		}
		this.onTouched();
	}
	formatForDisplay(iso) {
		if (iso === null) return "";
		const parsed = fromIsoDate(iso);
		if (parsed === null) return iso;
		const pad = (n) => String(n).padStart(2, "0");
		return `${pad(parsed.month)}/${pad(parsed.day)}/${parsed.year}`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: DateInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: DateInputComponent,
		isStandalone: true,
		selector: "cms-date-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => DateInputComponent),
			multi: true
		}],
		viewQueries: [{
			propertyName: "textInput",
			first: true,
			predicate: ["textInput"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "picker",
			first: true,
			predicate: DatePickerComponent,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"effectiveError()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n\r\n  <!--\r\n    🔴 `relative` so the trigger can sit inside the input's right edge, and `cdkOverlayOrigin` so the\r\n    popover attaches to the FIELD rather than to the button — a panel anchored to a 28px button\r\n    drifts left of the control it belongs to.\r\n  -->\r\n  <div class=\"cws:relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\r\n    <!--\r\n      type=\"text\", not type=\"date\". A native date input imposes its own picker and rejects the\r\n      MMDDYYYY / MMDDYY shapes BR-020 requires, which is precisely the green-screen entry speed\r\n      02a §1.1 exists to preserve. The calendar below is ours, for the same reason: the browser's\r\n      is unstyleable, differs per engine, and shows a locale-driven display form.\r\n    -->\r\n    <input\r\n      #textInput\r\n      class=\"scoular-form-input\"\r\n      [class.error]=\"effectiveError() !== null\"\r\n      [class.cws:border-scoular-yellow]=\"borderWarning() && effectiveError() === null\"\r\n      [class.cws:pr-9]=\"showTrigger()\"\r\n      [id]=\"controlId()\"\r\n      type=\"text\"\r\n      inputmode=\"numeric\"\r\n      autocomplete=\"off\"\r\n      placeholder=\"MM/DD/YYYY\"\r\n      [value]=\"displayValue()\"\r\n      [readOnly]=\"readOnly()\"\r\n      [disabled]=\"disabled()\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"effectiveError() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"warningText()\"\r\n      (input)=\"onInput($event)\"\r\n      (blur)=\"onBlur()\"\r\n    />\r\n\r\n    @if (showTrigger()) {\r\n      <!--\r\n        ⚠ **No trigger at all on a read-only or disabled field**, rather than a disabled one. A\r\n        greyed calendar button invites a click that can never do anything; its absence says the\r\n        field is not editable, which is the truth.\r\n\r\n        `type=\"button\"` so it cannot submit the form it sits in.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:absolute cws:top-1/2 cws:right-2 cws:flex cws:h-7 cws:w-7 cws:-translate-y-1/2 cws:items-center cws:justify-center cws:rounded cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-200\"\r\n        aria-label=\"Choose date\"\r\n        aria-haspopup=\"dialog\"\r\n        [attr.aria-expanded]=\"pickerOpen()\"\r\n        [attr.aria-controls]=\"controlId() + '-picker'\"\r\n        (click)=\"togglePicker()\"\r\n      >\r\n        <!-- An inline SVG rather than a glyph: a text calendar character renders differently per font. -->\r\n        <svg\r\n          aria-hidden=\"true\"\r\n          class=\"cws:h-4 cws:w-4\"\r\n          viewBox=\"0 0 20 20\"\r\n          fill=\"none\"\r\n          stroke=\"currentColor\"\r\n          stroke-width=\"1.6\"\r\n        >\r\n          <rect x=\"3\" y=\"4.5\" width=\"14\" height=\"12\" rx=\"2\" />\r\n          <path d=\"M3 8.5h14M7 3v3M13 3v3\" />\r\n        </svg>\r\n      </button>\r\n    }\r\n  </div>\r\n\r\n</cms-field>\r\n\r\n<!--\r\n  🔴 CDK overlay rather than an absolutely-positioned panel, and rather than the repo's own\r\n  `cmsDropdown` directive.\r\n\r\n  `cmsDropdown` gives dismissal and Escape handling and is used by five other panels, but it cannot\r\n  be used here: a CDK panel renders in a container appended to `<body>`, so the directive's\r\n  outside-click test — \"is the click inside my host element?\" — is false for every click INSIDE the\r\n  popover, and the calendar would close on its own first day cell.\r\n\r\n  What CDK buys that neither `cmsDropdown` nor CSS can: the panel **flips above the field** when\r\n  there is no room below, which for a date field near the foot of a long form is the difference\r\n  between a usable control and one whose footer is off-screen. `reposition` keeps it attached while\r\n  the page scrolls instead of leaving it behind.\r\n\r\n  ⚠ `(overlayKeydown)` handles Escape here rather than a document listener, and deliberately calls\r\n  `preventDefault`: the contract record screen uses Escape to navigate back to the grid, so an\r\n  Escape spent closing this popover must not also leave the record. That is the same reasoning\r\n  `cmsDropdown` carries, reproduced because the directive itself could not be.\r\n-->\r\n<ng-template\r\n  cdkConnectedOverlay\r\n  [cdkConnectedOverlayOrigin]=\"origin\"\r\n  [cdkConnectedOverlayOpen]=\"pickerOpen()\"\r\n  [cdkConnectedOverlayPositions]=\"pickerPositions\"\r\n  [cdkConnectedOverlayScrollStrategy]=\"pickerScroll\"\r\n  (attach)=\"onPickerAttached()\"\r\n  (overlayOutsideClick)=\"closePicker()\"\r\n  (detach)=\"closePicker()\"\r\n>\r\n  <!--\r\n    ⚠ Focus is trapped while the popover is open, and `cdkTrapFocusAutoCapture` is deliberately NOT\r\n    set: the picker puts focus on the active day cell itself once attached, and letting the trap\r\n    capture first would land focus on the header's previous-month chevron instead.\r\n  -->\r\n  <div cdkTrapFocus [id]=\"controlId() + '-picker'\" (keydown)=\"onOverlayKeydown($event)\">\r\n    <cms-date-picker\r\n      [value]=\"pickerValue()\"\r\n      [required]=\"required()\"\r\n      (dateSelected)=\"onPicked($event)\"\r\n      (cleared)=\"onPickerCleared()\"\r\n      (dismissed)=\"closePicker()\"\r\n    />\r\n  </div>\r\n</ng-template>\r\n",
		dependencies: [
			{
				kind: "directive",
				type: CdkConnectedOverlay,
				selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]",
				inputs: [
					"cdkConnectedOverlayOrigin",
					"cdkConnectedOverlayPositions",
					"cdkConnectedOverlayPositionStrategy",
					"cdkConnectedOverlayOffsetX",
					"cdkConnectedOverlayOffsetY",
					"cdkConnectedOverlayWidth",
					"cdkConnectedOverlayHeight",
					"cdkConnectedOverlayMinWidth",
					"cdkConnectedOverlayMinHeight",
					"cdkConnectedOverlayBackdropClass",
					"cdkConnectedOverlayPanelClass",
					"cdkConnectedOverlayViewportMargin",
					"cdkConnectedOverlayScrollStrategy",
					"cdkConnectedOverlayOpen",
					"cdkConnectedOverlayDisableClose",
					"cdkConnectedOverlayTransformOriginOn",
					"cdkConnectedOverlayHasBackdrop",
					"cdkConnectedOverlayLockPosition",
					"cdkConnectedOverlayFlexibleDimensions",
					"cdkConnectedOverlayGrowAfterOpen",
					"cdkConnectedOverlayPush",
					"cdkConnectedOverlayDisposeOnNavigation",
					"cdkConnectedOverlayUsePopover",
					"cdkConnectedOverlayMatchWidth",
					"cdkConnectedOverlay"
				],
				outputs: [
					"backdropClick",
					"positionChange",
					"attach",
					"detach",
					"overlayKeydown",
					"overlayOutsideClick"
				],
				exportAs: ["cdkConnectedOverlay"]
			},
			{
				kind: "directive",
				type: CdkOverlayOrigin,
				selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]",
				exportAs: ["cdkOverlayOrigin"]
			},
			{
				kind: "directive",
				type: CdkTrapFocus,
				selector: "[cdkTrapFocus]",
				inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"],
				exportAs: ["cdkTrapFocus"]
			},
			{
				kind: "component",
				type: DatePickerComponent,
				selector: "cms-date-picker",
				inputs: [
					"value",
					"required",
					"today"
				],
				outputs: [
					"dateSelected",
					"cleared",
					"dismissed"
				]
			},
			{
				kind: "component",
				type: FieldComponent,
				selector: "cms-field",
				inputs: [
					"label",
					"controlId",
					"required",
					"hideLabel",
					"errorMessage",
					"hint",
					"labelFor"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: DateInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-date-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				CdkConnectedOverlay,
				CdkOverlayOrigin,
				CdkTrapFocus,
				DatePickerComponent,
				FieldComponent
			],
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => DateInputComponent),
				multi: true
			}],
			template: "<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"effectiveError()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n\r\n  <!--\r\n    🔴 `relative` so the trigger can sit inside the input's right edge, and `cdkOverlayOrigin` so the\r\n    popover attaches to the FIELD rather than to the button — a panel anchored to a 28px button\r\n    drifts left of the control it belongs to.\r\n  -->\r\n  <div class=\"cws:relative\" cdkOverlayOrigin #origin=\"cdkOverlayOrigin\">\r\n    <!--\r\n      type=\"text\", not type=\"date\". A native date input imposes its own picker and rejects the\r\n      MMDDYYYY / MMDDYY shapes BR-020 requires, which is precisely the green-screen entry speed\r\n      02a §1.1 exists to preserve. The calendar below is ours, for the same reason: the browser's\r\n      is unstyleable, differs per engine, and shows a locale-driven display form.\r\n    -->\r\n    <input\r\n      #textInput\r\n      class=\"scoular-form-input\"\r\n      [class.error]=\"effectiveError() !== null\"\r\n      [class.cws:border-scoular-yellow]=\"borderWarning() && effectiveError() === null\"\r\n      [class.cws:pr-9]=\"showTrigger()\"\r\n      [id]=\"controlId()\"\r\n      type=\"text\"\r\n      inputmode=\"numeric\"\r\n      autocomplete=\"off\"\r\n      placeholder=\"MM/DD/YYYY\"\r\n      [value]=\"displayValue()\"\r\n      [readOnly]=\"readOnly()\"\r\n      [disabled]=\"disabled()\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"effectiveError() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"warningText()\"\r\n      (input)=\"onInput($event)\"\r\n      (blur)=\"onBlur()\"\r\n    />\r\n\r\n    @if (showTrigger()) {\r\n      <!--\r\n        ⚠ **No trigger at all on a read-only or disabled field**, rather than a disabled one. A\r\n        greyed calendar button invites a click that can never do anything; its absence says the\r\n        field is not editable, which is the truth.\r\n\r\n        `type=\"button\"` so it cannot submit the form it sits in.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:absolute cws:top-1/2 cws:right-2 cws:flex cws:h-7 cws:w-7 cws:-translate-y-1/2 cws:items-center cws:justify-center cws:rounded cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-slate-700 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-1 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700 cws:dark:hover:text-slate-200\"\r\n        aria-label=\"Choose date\"\r\n        aria-haspopup=\"dialog\"\r\n        [attr.aria-expanded]=\"pickerOpen()\"\r\n        [attr.aria-controls]=\"controlId() + '-picker'\"\r\n        (click)=\"togglePicker()\"\r\n      >\r\n        <!-- An inline SVG rather than a glyph: a text calendar character renders differently per font. -->\r\n        <svg\r\n          aria-hidden=\"true\"\r\n          class=\"cws:h-4 cws:w-4\"\r\n          viewBox=\"0 0 20 20\"\r\n          fill=\"none\"\r\n          stroke=\"currentColor\"\r\n          stroke-width=\"1.6\"\r\n        >\r\n          <rect x=\"3\" y=\"4.5\" width=\"14\" height=\"12\" rx=\"2\" />\r\n          <path d=\"M3 8.5h14M7 3v3M13 3v3\" />\r\n        </svg>\r\n      </button>\r\n    }\r\n  </div>\r\n\r\n</cms-field>\r\n\r\n<!--\r\n  🔴 CDK overlay rather than an absolutely-positioned panel, and rather than the repo's own\r\n  `cmsDropdown` directive.\r\n\r\n  `cmsDropdown` gives dismissal and Escape handling and is used by five other panels, but it cannot\r\n  be used here: a CDK panel renders in a container appended to `<body>`, so the directive's\r\n  outside-click test — \"is the click inside my host element?\" — is false for every click INSIDE the\r\n  popover, and the calendar would close on its own first day cell.\r\n\r\n  What CDK buys that neither `cmsDropdown` nor CSS can: the panel **flips above the field** when\r\n  there is no room below, which for a date field near the foot of a long form is the difference\r\n  between a usable control and one whose footer is off-screen. `reposition` keeps it attached while\r\n  the page scrolls instead of leaving it behind.\r\n\r\n  ⚠ `(overlayKeydown)` handles Escape here rather than a document listener, and deliberately calls\r\n  `preventDefault`: the contract record screen uses Escape to navigate back to the grid, so an\r\n  Escape spent closing this popover must not also leave the record. That is the same reasoning\r\n  `cmsDropdown` carries, reproduced because the directive itself could not be.\r\n-->\r\n<ng-template\r\n  cdkConnectedOverlay\r\n  [cdkConnectedOverlayOrigin]=\"origin\"\r\n  [cdkConnectedOverlayOpen]=\"pickerOpen()\"\r\n  [cdkConnectedOverlayPositions]=\"pickerPositions\"\r\n  [cdkConnectedOverlayScrollStrategy]=\"pickerScroll\"\r\n  (attach)=\"onPickerAttached()\"\r\n  (overlayOutsideClick)=\"closePicker()\"\r\n  (detach)=\"closePicker()\"\r\n>\r\n  <!--\r\n    ⚠ Focus is trapped while the popover is open, and `cdkTrapFocusAutoCapture` is deliberately NOT\r\n    set: the picker puts focus on the active day cell itself once attached, and letting the trap\r\n    capture first would land focus on the header's previous-month chevron instead.\r\n  -->\r\n  <div cdkTrapFocus [id]=\"controlId() + '-picker'\" (keydown)=\"onOverlayKeydown($event)\">\r\n    <cms-date-picker\r\n      [value]=\"pickerValue()\"\r\n      [required]=\"required()\"\r\n      (dateSelected)=\"onPicked($event)\"\r\n      (cleared)=\"onPickerCleared()\"\r\n      (dismissed)=\"closePicker()\"\r\n    />\r\n  </div>\r\n</ng-template>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}],
		textInput: [{
			type: i0.ViewChild,
			args: ["textInput", { isSignal: true }]
		}],
		picker: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => DatePickerComponent), { isSignal: true }]
		}]
	}
});
var NoteInputComponent = class NoteInputComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	maxLength = input.required(...ngDevMode ? [{ debugName: "maxLength" }] : /* istanbul ignore next */ []);
	rows = input(3, ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = signal("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	remaining = computed(() => this.maxLength() - this.value().length, ...ngDevMode ? [{ debugName: "remaining" }] : /* istanbul ignore next */ []);
	nearLimit = computed(() => {
		const threshold = Math.max(5, Math.floor(this.maxLength() * .1));
		return this.remaining() <= threshold;
	}, ...ngDevMode ? [{ debugName: "nearLimit" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		const ids = [`${this.controlId()}-counter`];
		if (this.errorMessage()) ids.push(`${this.controlId()}-error`);
		else if (this.warningText()) ids.push(`${this.controlId()}-hint`);
		return ids.join(" ");
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.value.set(typeof value === "string" ? value.slice(0, this.maxLength()) : "");
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	onInput(event) {
		const element = event.target;
		const clamped = element.value.slice(0, this.maxLength());
		if (element.value !== clamped) element.value = clamped;
		this.value.set(clamped);
		this.onChange(clamped === "" ? null : clamped);
	}
	onBlur() {
		this.onTouched();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: NoteInputComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: NoteInputComponent,
		isStandalone: true,
		selector: "cms-note-input",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			maxLength: {
				classPropertyName: "maxLength",
				publicName: "maxLength",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => NoteInputComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<!-- Label row, required marker and the error/hint line come from `cms-field` (2026-09-16). -->\r\n<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n  <ng-container cmsFieldAside>\r\n    <!-- Hidden when read-only, for the reason `text-input` records: the count answers a question a\r\n         read-only field cannot raise, and it was the loudest thing on the record screen. -->\r\n    @if (!readOnly()) {\r\n      <span\r\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\r\n        [class.cws:text-slate-500]=\"!nearLimit()\"\r\n        [class.cws:text-scoular-yellow-dark]=\"nearLimit()\"\r\n        [id]=\"controlId() + '-counter'\"\r\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\r\n        >{{ remaining() }} left</span\r\n      >\r\n    }\r\n  </ng-container>\r\n\r\n  <!--\r\n    field-sizing:content grows the textarea with its content where the browser supports it, with\r\n    the rows attribute as both the floor and the fallback. No scroll-height measurement and no\r\n    resize observer — a lot of machinery to avoid a scrollbar.\r\n  -->\r\n  <textarea\r\n    class=\"scoular-form-textarea cws:[field-sizing:content]\"\r\n    [class.error]=\"errorMessage() !== null\"\r\n    [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n    [id]=\"controlId()\"\r\n    [rows]=\"rows()\"\r\n    [value]=\"value()\"\r\n    [attr.maxlength]=\"maxLength()\"\r\n    [readOnly]=\"readOnly()\"\r\n    [disabled]=\"disabled()\"\r\n    [attr.aria-required]=\"required() ? 'true' : null\"\r\n    [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n    [attr.aria-describedby]=\"describedBy()\"\r\n    [attr.title]=\"warningText()\"\r\n    (input)=\"onInput($event)\"\r\n    (blur)=\"onBlur()\"\r\n  ></textarea>\r\n\r\n</cms-field>\r\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NoteInputComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-note-input",
			imports: [FieldComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => NoteInputComponent),
				multi: true
			}],
			template: "<!-- Label row, required marker and the error/hint line come from `cms-field` (2026-09-16). -->\r\n<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n  <ng-container cmsFieldAside>\r\n    <!-- Hidden when read-only, for the reason `text-input` records: the count answers a question a\r\n         read-only field cannot raise, and it was the loudest thing on the record screen. -->\r\n    @if (!readOnly()) {\r\n      <span\r\n        class=\"cws:shrink-0 cws:text-xs cws:whitespace-nowrap cws:tabular-nums\"\r\n        [class.cws:text-slate-500]=\"!nearLimit()\"\r\n        [class.cws:text-scoular-yellow-dark]=\"nearLimit()\"\r\n        [id]=\"controlId() + '-counter'\"\r\n        [attr.aria-live]=\"nearLimit() ? 'polite' : 'off'\"\r\n        >{{ remaining() }} left</span\r\n      >\r\n    }\r\n  </ng-container>\r\n\r\n  <!--\r\n    field-sizing:content grows the textarea with its content where the browser supports it, with\r\n    the rows attribute as both the floor and the fallback. No scroll-height measurement and no\r\n    resize observer — a lot of machinery to avoid a scrollbar.\r\n  -->\r\n  <textarea\r\n    class=\"scoular-form-textarea cws:[field-sizing:content]\"\r\n    [class.error]=\"errorMessage() !== null\"\r\n    [class.cws:border-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n    [id]=\"controlId()\"\r\n    [rows]=\"rows()\"\r\n    [value]=\"value()\"\r\n    [attr.maxlength]=\"maxLength()\"\r\n    [readOnly]=\"readOnly()\"\r\n    [disabled]=\"disabled()\"\r\n    [attr.aria-required]=\"required() ? 'true' : null\"\r\n    [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n    [attr.aria-describedby]=\"describedBy()\"\r\n    [attr.title]=\"warningText()\"\r\n    (input)=\"onInput($event)\"\r\n    (blur)=\"onBlur()\"\r\n  ></textarea>\r\n\r\n</cms-field>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		maxLength: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLength",
				required: true
			}]
		}],
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}]
	}
});
var ToggleComponent = class ToggleComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	controlId = input.required(...ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []);
	onLabel = input("Yes", ...ngDevMode ? [{ debugName: "onLabel" }] : /* istanbul ignore next */ []);
	offLabel = input("No", ...ngDevMode ? [{ debugName: "offLabel" }] : /* istanbul ignore next */ []);
	required = input(false, ...ngDevMode ? [{ debugName: "required" }] : /* istanbul ignore next */ []);
	readOnly = input(false, ...ngDevMode ? [{ debugName: "readOnly" }] : /* istanbul ignore next */ []);
	borderWarning = input(false, ...ngDevMode ? [{ debugName: "borderWarning" }] : /* istanbul ignore next */ []);
	warningText = input(null, ...ngDevMode ? [{ debugName: "warningText" }] : /* istanbul ignore next */ []);
	errorMessage = input(null, ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	disabled = signal(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	checked = signal(false, ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	stateLabel = computed(() => this.checked() ? this.onLabel() : this.offLabel(), ...ngDevMode ? [{ debugName: "stateLabel" }] : /* istanbul ignore next */ []);
	describedBy = computed(() => {
		if (this.errorMessage()) return `${this.controlId()}-error`;
		return this.warningText() ? `${this.controlId()}-hint` : null;
	}, ...ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []);
	onChange = () => void 0;
	onTouched = () => void 0;
	writeValue(value) {
		this.checked.set(value === true);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	setDisabledState(isDisabled) {
		this.disabled.set(isDisabled);
	}
	toggle() {
		if (this.readOnly() || this.disabled()) return;
		const next = !this.checked();
		this.checked.set(next);
		this.onChange(next);
		this.onTouched();
	}
	onKeydown(event) {
		if (event.key === " " || event.key === "Enter") {
			event.preventDefault();
			this.toggle();
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ToggleComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: ToggleComponent,
		isStandalone: true,
		selector: "cms-toggle",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			controlId: {
				classPropertyName: "controlId",
				publicName: "controlId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			onLabel: {
				classPropertyName: "onLabel",
				publicName: "onLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			offLabel: {
				classPropertyName: "offLabel",
				publicName: "offLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			required: {
				classPropertyName: "required",
				publicName: "required",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			readOnly: {
				classPropertyName: "readOnly",
				publicName: "readOnly",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			borderWarning: {
				classPropertyName: "borderWarning",
				publicName: "borderWarning",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			warningText: {
				classPropertyName: "warningText",
				publicName: "warningText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		providers: [{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => ToggleComponent),
			multi: true
		}],
		ngImport: i0,
		template: "<!--\r\n  Label row, required marker and the error/hint line come from `cms-field` (2026-09-16).\r\n\r\n  🔴 `[labelFor]=\"false\"` is the whole reason that input exists. `role=\"switch\"` is a button, and a\r\n  <label for> pointing at a button is not an accessible-name association — so the heading has to be a\r\n  <span> with an id that the button's `aria-labelledby` points at. Flipping this to the default would\r\n  leave the control looking perfectly labelled and unnamed to a screen reader.\r\n-->\r\n<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [labelFor]=\"false\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n  <div class=\"cws:flex cws:items-center cws:gap-3\">\r\n    <!--\r\n      The inactive look for `readOnly` — the record screen's view mode.\r\n\r\n      Tailwind utilities work here, unlike on the text controls: every class on this button is already a\r\n      utility, so there is no unlayered design-system declaration to lose to. The text controls carry\r\n      `scoular-form-input`, whose `bg-white` is unlayered and therefore beats any utility — their\r\n      inactive styling has to live in the shell's `styles.css` for that reason. See the note there.\r\n\r\n      `!cursor-default` carries the important flag because the base class list sets `cursor-pointer`,\r\n      and between two utilities in the same layer Tailwind's own ordering decides — not source order.\r\n      Not `not-allowed`: the switch keeps its place in the tab sequence and stays readable, which is\r\n      what `readOnly` means here — `toggle()` returns early rather than the button being disabled.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <button\r\n      class=\"cws:relative cws:inline-flex cws:h-6 cws:w-11 cws:shrink-0 cws:cursor-pointer cws:rounded-full cws:border-2 cws:border-transparent cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:focus-visible:ring-offset-2 cws:disabled:cursor-not-allowed cws:disabled:opacity-50\"\r\n      [class.cws:bg-scoular-blue]=\"checked()\"\r\n      [class.cws:bg-slate-300]=\"!checked()\"\r\n      [class.cws:dark:bg-slate-600]=\"!checked()\"\r\n      [class.cws:ring-2]=\"borderWarning() && errorMessage() === null\"\r\n      [class.cws:ring-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n      [class.cws:ring-scoular-red]=\"errorMessage() !== null\"\r\n      [class.cws:opacity-70]=\"readOnly() && !disabled()\"\r\n      [class.cws:!cursor-default]=\"readOnly()\"\r\n      [id]=\"controlId()\"\r\n      type=\"button\"\r\n      role=\"switch\"\r\n      [attr.aria-checked]=\"checked()\"\r\n      [attr.aria-labelledby]=\"controlId() + '-label'\"\r\n      [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"warningText()\"\r\n      [disabled]=\"disabled()\"\r\n      (click)=\"toggle()\"\r\n      (keydown)=\"onKeydown($event)\"\r\n    >\r\n      <!-- Decorative: the state is already conveyed by aria-checked and the visible text label. -->\r\n      <span\r\n        class=\"cws:pointer-events-none cws:inline-block cws:h-5 cws:w-5 cws:transform cws:rounded-full cws:bg-white cws:shadow cws:ring-0 cws:transition-transform\"\r\n        [class.cws:translate-x-5]=\"checked()\"\r\n        [class.cws:translate-x-0]=\"!checked()\"\r\n        aria-hidden=\"true\"\r\n      ></span>\r\n    </button>\r\n\r\n    <!-- 02a C9: an explicit Yes/No label, never the switch position alone. -->\r\n    <span class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" aria-hidden=\"true\">{{\r\n      stateLabel()\r\n    }}</span>\r\n  </div>\r\n\r\n</cms-field>\r\n",
		dependencies: [{
			kind: "component",
			type: FieldComponent,
			selector: "cms-field",
			inputs: [
				"label",
				"controlId",
				"required",
				"hideLabel",
				"errorMessage",
				"hint",
				"labelFor"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ToggleComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-toggle",
			imports: [FieldComponent],
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: NG_VALUE_ACCESSOR,
				useExisting: forwardRef(() => ToggleComponent),
				multi: true
			}],
			template: "<!--\r\n  Label row, required marker and the error/hint line come from `cms-field` (2026-09-16).\r\n\r\n  🔴 `[labelFor]=\"false\"` is the whole reason that input exists. `role=\"switch\"` is a button, and a\r\n  <label for> pointing at a button is not an accessible-name association — so the heading has to be a\r\n  <span> with an id that the button's `aria-labelledby` points at. Flipping this to the default would\r\n  leave the control looking perfectly labelled and unnamed to a screen reader.\r\n-->\r\n<cms-field\r\n  [label]=\"label()\"\r\n  [controlId]=\"controlId()\"\r\n  [required]=\"required()\"\r\n  [labelFor]=\"false\"\r\n  [errorMessage]=\"errorMessage()\"\r\n  [hint]=\"warningText()\"\r\n>\r\n  <div class=\"cws:flex cws:items-center cws:gap-3\">\r\n    <!--\r\n      The inactive look for `readOnly` — the record screen's view mode.\r\n\r\n      Tailwind utilities work here, unlike on the text controls: every class on this button is already a\r\n      utility, so there is no unlayered design-system declaration to lose to. The text controls carry\r\n      `scoular-form-input`, whose `bg-white` is unlayered and therefore beats any utility — their\r\n      inactive styling has to live in the shell's `styles.css` for that reason. See the note there.\r\n\r\n      `!cursor-default` carries the important flag because the base class list sets `cursor-pointer`,\r\n      and between two utilities in the same layer Tailwind's own ordering decides — not source order.\r\n      Not `not-allowed`: the switch keeps its place in the tab sequence and stays readable, which is\r\n      what `readOnly` means here — `toggle()` returns early rather than the button being disabled.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n    -->\r\n    <button\r\n      class=\"cws:relative cws:inline-flex cws:h-6 cws:w-11 cws:shrink-0 cws:cursor-pointer cws:rounded-full cws:border-2 cws:border-transparent cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:focus-visible:ring-offset-2 cws:disabled:cursor-not-allowed cws:disabled:opacity-50\"\r\n      [class.cws:bg-scoular-blue]=\"checked()\"\r\n      [class.cws:bg-slate-300]=\"!checked()\"\r\n      [class.cws:dark:bg-slate-600]=\"!checked()\"\r\n      [class.cws:ring-2]=\"borderWarning() && errorMessage() === null\"\r\n      [class.cws:ring-scoular-yellow]=\"borderWarning() && errorMessage() === null\"\r\n      [class.cws:ring-scoular-red]=\"errorMessage() !== null\"\r\n      [class.cws:opacity-70]=\"readOnly() && !disabled()\"\r\n      [class.cws:!cursor-default]=\"readOnly()\"\r\n      [id]=\"controlId()\"\r\n      type=\"button\"\r\n      role=\"switch\"\r\n      [attr.aria-checked]=\"checked()\"\r\n      [attr.aria-labelledby]=\"controlId() + '-label'\"\r\n      [attr.aria-readonly]=\"readOnly() ? 'true' : null\"\r\n      [attr.aria-required]=\"required() ? 'true' : null\"\r\n      [attr.aria-invalid]=\"errorMessage() !== null ? 'true' : null\"\r\n      [attr.aria-describedby]=\"describedBy()\"\r\n      [attr.title]=\"warningText()\"\r\n      [disabled]=\"disabled()\"\r\n      (click)=\"toggle()\"\r\n      (keydown)=\"onKeydown($event)\"\r\n    >\r\n      <!-- Decorative: the state is already conveyed by aria-checked and the visible text label. -->\r\n      <span\r\n        class=\"cws:pointer-events-none cws:inline-block cws:h-5 cws:w-5 cws:transform cws:rounded-full cws:bg-white cws:shadow cws:ring-0 cws:transition-transform\"\r\n        [class.cws:translate-x-5]=\"checked()\"\r\n        [class.cws:translate-x-0]=\"!checked()\"\r\n        aria-hidden=\"true\"\r\n      ></span>\r\n    </button>\r\n\r\n    <!-- 02a C9: an explicit Yes/No label, never the switch position alone. -->\r\n    <span class=\"cws:text-sm cws:text-slate-700 cws:dark:text-slate-300\" aria-hidden=\"true\">{{\r\n      stateLabel()\r\n    }}</span>\r\n  </div>\r\n\r\n</cms-field>\r\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		controlId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "controlId",
				required: true
			}]
		}],
		onLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "onLabel",
				required: false
			}]
		}],
		offLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "offLabel",
				required: false
			}]
		}],
		required: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "required",
				required: false
			}]
		}],
		readOnly: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "readOnly",
				required: false
			}]
		}],
		borderWarning: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "borderWarning",
				required: false
			}]
		}],
		warningText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "warningText",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}]
	}
});
function sameSortChain(left, right) {
	return left.length === right.length && left.every((sort, index) => sort.key === right[index].key && sort.direction === right[index].direction);
}
const DEFAULT_COLUMN_WIDTH = 140;
const MIN_COLUMN_WIDTH = 56;
const flipDirection = (direction) => direction === "asc" ? "desc" : "asc";
function compareRows(column, left, right, direction) {
	const key = column.sortValue ?? column.format;
	const a = key(left);
	const b = key(right);
	const sign = direction === "asc" ? 1 : -1;
	if (typeof a === "number" && typeof b === "number") return (a - b) * sign;
	return String(a).localeCompare(String(b)) * sign;
}
function nextSort(current, key) {
	const existing = current.find((sort) => sort.key === key);
	if (!existing) return [...current, {
		key,
		direction: "asc"
	}];
	if (existing.direction === "asc") return current.map((sort) => sort.key === key ? {
		key,
		direction: "desc"
	} : sort);
	return current.filter((sort) => sort.key !== key);
}
function ariaSort(current, key) {
	const existing = current.find((sort) => sort.key === key);
	if (!existing) return "none";
	return existing.direction === "asc" ? "ascending" : "descending";
}
function sortRank(current, key) {
	const index = current.findIndex((sort) => sort.key === key);
	return index === -1 ? null : index + 1;
}
function compareBySorts(columns, sorts, left, right) {
	for (const sort of sorts) {
		const column = columns.find((candidate) => candidate.key === sort.key);
		if (!column) continue;
		const result = compareRows(column, left, right, sort.direction);
		if (result !== 0) return result;
	}
	return 0;
}
const TONE_CLASS = {
	positive: "scoular-badge-success",
	caution: "scoular-badge-warning",
	negative: "scoular-badge-error",
	info: "scoular-badge-info",
	neutral: "scoular-badge-neutral cws:border-slate-300 cws:dark:border-slate-500 cws:dark:bg-slate-800 cws:dark:text-slate-300"
};
function statusBadgeClass(tone, small = false) {
	return small ? `${TONE_CLASS[tone]} scoular-badge-sm` : TONE_CLASS[tone];
}
var StatusBadgeComponent = class StatusBadgeComponent {
	tone = input.required(...ngDevMode ? [{ debugName: "tone" }] : /* istanbul ignore next */ []);
	small = input(false, ...ngDevMode ? [{ debugName: "small" }] : /* istanbul ignore next */ []);
	classes = computed(() => `scoular-badge ${statusBadgeClass(this.tone(), this.small())}`, ...ngDevMode ? [{ debugName: "classes" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: StatusBadgeComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: StatusBadgeComponent,
		isStandalone: true,
		selector: "cms-status-badge",
		inputs: {
			tone: {
				classPropertyName: "tone",
				publicName: "tone",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			small: {
				classPropertyName: "small",
				publicName: "small",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { properties: { "class": "classes()" } },
		ngImport: i0,
		template: `<ng-content />`,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: StatusBadgeComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-status-badge",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { "[class]": "classes()" },
			template: `<ng-content />`
		}]
	}],
	propDecorators: {
		tone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "tone",
				required: true
			}]
		}],
		small: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "small",
				required: false
			}]
		}]
	}
});
const SELECTED_CELL_CLASS = "cws:bg-scoular-blue/10 cws:outline cws:outline-2 cws:-outline-offset-2 cws:outline-scoular-blue cws:dark:bg-sky-400/20 cws:dark:outline-sky-400";
const SELECTED_ROW_CLASS = "cws:bg-scoular-blue/5 cws:focus:outline-none cws:dark:bg-sky-400/10";
const UNSELECTED_ROW_CLASS = "cws:hover:bg-slate-100 cws:focus:outline-2 cws:focus:outline-offset-[-2px] cws:focus:outline-scoular-blue cws:dark:hover:bg-slate-700/70";
const ROW_TONE_CLASS = {
	negative: "cws:bg-scoular-red/4 cws:dark:bg-scoular-red/15",
	caution: "cws:bg-scoular-yellow/5 cws:dark:bg-scoular-yellow/10"
};
const STRIPE_CLASS = "cws:bg-slate-50/70 cws:dark:bg-slate-800/40";
const SORTED_HEADER_CLASS = "cws:bg-scoular-blue/10 cws:text-scoular-blue cws:hover:bg-scoular-blue/15 cws:dark:bg-sky-400/15 cws:dark:text-sky-400 cws:dark:hover:bg-sky-400/20";
const UNSORTED_HEADER_CLASS = "cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700/70";
const CELL_HEIGHT_CLASS = "cws:h-11";
var DataGridComponent = class DataGridComponent {
	cellHeightClass = CELL_HEIGHT_CLASS;
	rows = input.required(...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	striped = input(false, ...ngDevMode ? [{ debugName: "striped" }] : /* istanbul ignore next */ []);
	actions = input([], ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
	actionsHeader = input("Actions", ...ngDevMode ? [{ debugName: "actionsHeader" }] : /* istanbul ignore next */ []);
	actionsWidth = input(170, ...ngDevMode ? [{ debugName: "actionsWidth" }] : /* istanbul ignore next */ []);
	hasActions = computed(() => this.actions().length > 0, ...ngDevMode ? [{ debugName: "hasActions" }] : /* istanbul ignore next */ []);
	sorts = input([], ...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	rowTone = input(() => null, ...ngDevMode ? [{ debugName: "rowTone" }] : /* istanbul ignore next */ []);
	trackBy = input((row) => row, ...ngDevMode ? [{ debugName: "trackBy" }] : /* istanbul ignore next */ []);
	focusKey = input(null, ...ngDevMode ? [{ debugName: "focusKey" }] : /* istanbul ignore next */ []);
	sortChange = output();
	rowActivate = output();
	cellCopy = output();
	pageStep = output();
	body = viewChild("body", ...ngDevMode ? [{ debugName: "body" }] : /* istanbul ignore next */ []);
	honouredFocusKey = null;
	constructor() {
		afterRenderEffect(() => {
			const key = this.focusKey();
			const rows = this.rows();
			const columns = this.columns();
			if (key === null || key === void 0 || key === this.honouredFocusKey) return;
			if (columns.length === 0) return;
			const index = rows.findIndex((row, position) => this.trackBy()(row, position) === key);
			if (index === -1) return;
			this.honouredFocusKey = key;
			this.selected.set({
				row: rows[index],
				key: columns[0].key
			});
			this.focusRow(index);
		});
	}
	hasRows = computed(() => this.rows().length > 0, ...ngDevMode ? [{ debugName: "hasRows" }] : /* istanbul ignore next */ []);
	selected = signal(null, ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	isSelected(row, column) {
		const selected = this.selected();
		return selected !== null && selected.row === row && selected.key === column.key;
	}
	cellClassFor(row, column) {
		const selection = this.isSelected(row, column) ? ` ${SELECTED_CELL_CLASS}` : "";
		return `${CELL_HEIGHT_CLASS}${selection}`;
	}
	resized = signal({}, ...ngDevMode ? [{ debugName: "resized" }] : /* istanbul ignore next */ []);
	drag = null;
	widths = computed(() => this.columns().map((column) => ({
		key: column.key,
		width: this.resized()[column.key] ?? column.width ?? 140
	})), ...ngDevMode ? [{ debugName: "widths" }] : /* istanbul ignore next */ []);
	widthOf(column) {
		return this.resized()[column.key] ?? column.width ?? 140;
	}
	onResizeStart(event, column) {
		event.preventDefault();
		event.stopPropagation();
		this.drag = {
			key: column.key,
			startX: event.clientX,
			startWidth: this.widthOf(column)
		};
		event.target.setPointerCapture(event.pointerId);
	}
	onResizeMove(event, column) {
		if (this.drag?.key !== column.key) return;
		const floor = column.minWidth ?? 56;
		const width = Math.max(floor, this.drag.startWidth + (event.clientX - this.drag.startX));
		this.resized.update((widths) => ({
			...widths,
			[column.key]: width
		}));
	}
	onResizeEnd() {
		this.drag = null;
	}
	onResizeKeydown(event, column) {
		const step = 16;
		const floor = column.minWidth ?? 56;
		const current = this.widthOf(column);
		switch (event.key) {
			case "ArrowLeft":
				this.resized.update((w) => ({
					...w,
					[column.key]: Math.max(floor, current - step)
				}));
				break;
			case "ArrowRight":
				this.resized.update((w) => ({
					...w,
					[column.key]: current + step
				}));
				break;
			case "Home":
				this.resized.update((w) => {
					const { [column.key]: _removed, ...rest } = w;
					return rest;
				});
				break;
			default: return;
		}
		event.preventDefault();
		event.stopPropagation();
	}
	titleFor(column, row) {
		return column.tooltip?.(row) ?? column.format(row);
	}
	ariaSortFor(key) {
		return ariaSort(this.sorts(), key);
	}
	sortRankFor(key) {
		return this.sorts().length > 1 ? sortRank(this.sorts(), key) : null;
	}
	headerClassFor(column) {
		const state = this.ariaSortFor(column.key) === "none" ? UNSORTED_HEADER_CLASS : SORTED_HEADER_CLASS;
		return `${CELL_HEIGHT_CLASS} ${state}`;
	}
	badgeToneFor(column, row) {
		return column.badge?.(row)?.tone ?? null;
	}
	badgeLabelFor(column, row) {
		return column.badge?.(row)?.label ?? null;
	}
	rowToneClassFor(row) {
		const tone = this.rowTone()(row);
		return tone === null ? "" : ROW_TONE_CLASS[tone];
	}
	holdsSelection(row) {
		return this.selected()?.row === row;
	}
	rowClassFor(row, index) {
		if (this.holdsSelection(row)) return SELECTED_ROW_CLASS;
		const tone = this.rowToneClassFor(row);
		const stripe = this.striped() && tone === "" && index % 2 === 1 ? STRIPE_CLASS : "";
		return `${UNSELECTED_ROW_CLASS} ${tone} ${stripe}`;
	}
	onHeaderActivate(column) {
		if (column.sortable) this.sortChange.emit(nextSort(this.sorts(), column.key));
	}
	onCellMousedown(row, index, column) {
		this.selected.set({
			row,
			key: column.key
		});
		this.focusRow(index);
	}
	onRowFocus(row) {
		const columns = this.columns();
		if (columns.length === 0 || this.holdsSelection(row)) return;
		this.selected.set({
			row,
			key: columns[0].key
		});
	}
	stepCell(row, step) {
		const columns = this.columns();
		if (columns.length === 0) return;
		const selected = this.selected();
		const current = selected !== null && selected.row === row ? columns.findIndex((column) => column.key === selected.key) : -1;
		const next = current === -1 ? step === 1 ? 0 : columns.length - 1 : Math.min(Math.max(current + step, 0), columns.length - 1);
		this.selected.set({
			row,
			key: columns[next].key
		});
		this.revealSelected();
	}
	revealSelected() {
		const selected = this.selected();
		if (selected === null) return;
		this.body()?.nativeElement.querySelector(`td[data-cell-key="${CSS.escape(selected.key)}"]`)?.scrollIntoView?.({
			block: "nearest",
			inline: "nearest"
		});
	}
	copySelected() {
		const selected = this.selected();
		if (selected === null || navigator.clipboard === void 0) return false;
		const column = this.columns().find((candidate) => candidate.key === selected.key);
		if (column === void 0) return false;
		const text = column.format(selected.row);
		navigator.clipboard.writeText(text).then(() => this.cellCopy.emit(text)).catch(() => void 0);
		return true;
	}
	onRowKeydown(event, row, index) {
		if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "c") {
			if ((window.getSelection()?.toString() ?? "") !== "") return;
			if (this.copySelected()) event.preventDefault();
			return;
		}
		if (!event.ctrlKey && !event.metaKey && !event.altKey && event.key.length === 1) {
			const letter = event.key.toLowerCase();
			const action = this.actions().find((candidate) => candidate.accessKey?.toLowerCase() === letter);
			if (action !== void 0) {
				event.preventDefault();
				if ((action.disabled?.(row) ?? false) === false && (action.busy?.(row) ?? false) === false) action.run(row);
				return;
			}
		}
		switch (event.key) {
			case "ArrowDown":
				this.focusRow(index + 1, row);
				break;
			case "ArrowUp":
				this.focusRow(index - 1, row);
				break;
			case "ArrowRight":
				this.stepCell(row, 1);
				break;
			case "ArrowLeft":
				this.stepCell(row, -1);
				break;
			case "Home":
				this.focusRow(0, row);
				break;
			case "End":
				this.focusRow(this.rows().length - 1, row);
				break;
			case "PageDown":
				this.pageStep.emit(1);
				break;
			case "PageUp":
				this.pageStep.emit(-1);
				break;
			case "Enter":
				this.rowActivate.emit(row);
				break;
			default: return;
		}
		event.preventDefault();
	}
	focusRow(index, from) {
		const rows = this.body()?.nativeElement.querySelectorAll("tr");
		if (!rows || rows.length === 0) return;
		const clamped = Math.min(Math.max(index, 0), rows.length - 1);
		if (from !== void 0) {
			const selected = this.selected();
			const target = this.rows()[clamped];
			if (selected !== null && selected.row === from && target !== void 0) this.selected.set({
				row: target,
				key: selected.key
			});
		}
		rows[clamped]?.focus();
	}
	refusalFor(action, row) {
		const refusal = action.disabled?.(row) ?? false;
		return refusal === false ? null : refusal;
	}
	isActionDisabled(action, row) {
		return this.refusalFor(action, row) !== null || (action.busy?.(row) ?? false);
	}
	actionClassFor(action) {
		switch (action.tone) {
			case "primary": return "scoular-btn scoular-btn-sm scoular-btn-primary cws:border cws:border-transparent";
			case "outline": return "scoular-btn scoular-btn-sm scoular-btn-outline";
			default: return "scoular-btn scoular-btn-sm scoular-btn-secondary";
		}
	}
	runAction(event, action, row) {
		event.stopPropagation();
		if (this.isActionDisabled(action, row)) return;
		action.run(row);
	}
	onActionKeydown(event) {
		if (event.key === "Enter" || event.key === " " || event.key === "Spacebar") event.stopPropagation();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: DataGridComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: DataGridComponent,
		isStandalone: true,
		selector: "cms-data-grid",
		inputs: {
			rows: {
				classPropertyName: "rows",
				publicName: "rows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			striped: {
				classPropertyName: "striped",
				publicName: "striped",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actions: {
				classPropertyName: "actions",
				publicName: "actions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actionsHeader: {
				classPropertyName: "actionsHeader",
				publicName: "actionsHeader",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			actionsWidth: {
				classPropertyName: "actionsWidth",
				publicName: "actionsWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sorts: {
				classPropertyName: "sorts",
				publicName: "sorts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowTone: {
				classPropertyName: "rowTone",
				publicName: "rowTone",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			trackBy: {
				classPropertyName: "trackBy",
				publicName: "trackBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			focusKey: {
				classPropertyName: "focusKey",
				publicName: "focusKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			sortChange: "sortChange",
			rowActivate: "rowActivate",
			cellCopy: "cellCopy",
			pageStep: "pageStep"
		},
		viewQueries: [{
			propertyName: "body",
			first: true,
			predicate: ["body"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<!--\r\n  A real <table>, not a div grid. Semantics come free (row/column relationships announced, headers\r\n  associated with cells), and the design system already styles `scoular-table`.\r\n\r\n  `tabindex=\"0\"` on every row rather than a roving tabindex: the grid is one page of at most 200 rows\r\n  (ContractListQuery.MaxPageSize), so the simpler model costs nothing and cannot desynchronise from\r\n  the focused row the way a roving index can.\r\n\r\n  The rounded, bordered wrapper is what makes the table read as one surface in dark mode. Without it\r\n  the striped rows run into the page background and the grid loses its edges. Square corners were\r\n  tried on 2026-08-25 and reverted the same day — rounded reads better against the page.\r\n-->\r\n<div\r\n  class=\"cws:overflow-x-auto cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-900 cws:dark:shadow-none\"\r\n>\r\n  <!--\r\n    `table-fixed` is load-bearing, not tidiness. `text-overflow: ellipsis` needs a cell whose width\r\n    does not depend on its content, so auto layout — which sizes columns to the longest value — can\r\n    never truncate. Fixed layout is also what makes a dragged width stick instead of being\r\n    recalculated from the text.\r\n\r\n    The consequence to know about: every column takes its declared width and content no longer\r\n    influences it, so a column with no width falls back to DEFAULT_COLUMN_WIDTH rather than sizing\r\n    itself.\r\n  -->\r\n  <!--\r\n    **Never `scoular-table-striped`, even when `striped` is on.**\r\n\r\n    `.scoular-table-striped tbody tr:nth-child(even)` has specificity (0,2,2); a Tailwind background\r\n    utility like `.bg-scoular-red\\/5` has (0,1,0). So that class beat the row tint on every *even*\r\n    row — half the rejected and unapproved contracts showed no tint at all — and because it is\r\n    declared after the design system's own `tbody tr:hover`, even rows did not highlight on hover\r\n    either. Raising the tint's specificity would then have had to beat hover as well, which is a\r\n    fight with no end.\r\n\r\n    ⚠ **Striping returned as an opt-in input** (JFrisbie, 2026-09-14) and is emitted from\r\n    `rowClassFor`, where tone, hover, focus and selection are already arbitrated — so the stripe can\r\n    be made to lose to all of them by simply not being emitted.\r\n\r\n    ⚠ **This comment used to end \"a grid using tones must not stripe\". That is now too strong** — the\r\n    workspace grid stripes with tones on measured evidence (2026-09-15). The tone still always wins,\r\n    and the two remain distinguishable because the stripe is *cool* and both tints are *warm*. See\r\n    the `striped` input for the two conditions a grid has to meet before combining them.\r\n\r\n    Rows remain separable without it via the `divide-y` borders the design system already applies,\r\n    which is why `striped` defaults to off.\r\n  -->\r\n  <table class=\"scoular-table scoular-table-compact cws:table-fixed\" [attr.aria-label]=\"label()\">\r\n    <colgroup>\r\n      @for (column of widths(); track column.key) {\r\n        <col [style.width.px]=\"column.width\" />\r\n      }\r\n      <!--\r\n        The actions column's width. Needed here as well as on the cells because the table is\r\n        `table-fixed`, so the colgroup is what sizes it — without this the browser divides the\r\n        remaining space and the buttons wrap.\r\n      -->\r\n      @if (hasActions()) {\r\n        <col [style.width.px]=\"actionsWidth()\" />\r\n      }\r\n    </colgroup>\r\n\r\n    <!--\r\n      A single firm rule under the header, so the headings read as a separate band from the data.\r\n      Heavier than the row dividers on purpose: `divide-y` between rows is a hairline, and matching it\r\n      here would leave the header floating.\r\n    -->\r\n    <!--\r\n      A tinted header band (2026-09-03). It was white on white in light mode, so the only thing\r\n      separating the column names from the first row of data was the 2px rule underneath — the header\r\n      read as another row rather than as the table's chrome. Dark mode already had the separation for\r\n      free, which is why this only shows up in light.\r\n\r\n      A `bg-*` on `<thead>` rather than on each `<th>`: one declaration, and it cannot fall out of step\r\n      with the header hover, which is a `hover:bg-*` on the cell and still wins over this (0,2,0)\r\n      against (0,1,0).\r\n    -->\r\n    <thead class=\"cws:border-b-2 cws:border-slate-300 cws:bg-slate-50 cws:dark:border-slate-600 cws:dark:bg-slate-800/60\">\r\n      <tr>\r\n        @for (column of columns(); track column.key) {\r\n          <!--\r\n            Hover tints the whole header cell rather than just its text. `group` so the resize handle\r\n            can reveal itself with the same hover, and `relative` so the handle can sit on the cell's\r\n            trailing edge.\r\n\r\n            Hover lives in `headerClassFor` rather than here, because the sorted and unsorted variants\r\n            both declare one and only one may be emitted — see SORTED_HEADER_CLASS.\r\n          -->\r\n          <th\r\n            scope=\"col\"\r\n            class=\"cws:group cws:relative cws:transition-colors\"\r\n            [class]=\"headerClassFor(column)\"\r\n            [class.scoular-table-sortable]=\"column.sortable\"\r\n            [class.cws:text-right]=\"column.align === 'end'\"\r\n            [attr.aria-sort]=\"column.sortable ? ariaSortFor(column.key) : null\"\r\n          >\r\n            <div class=\"truncate\" [class.cws:text-right]=\"column.align === 'end'\">\r\n              @if (column.sortable) {\r\n                <!--\r\n                  A real <button> inside the <th>: the sort must be reachable by Tab and activated by\r\n                  Enter *and* Space, which a click handler on the <th> gives you neither of.\r\n                -->\r\n                <!--\r\n                  `cursor-pointer` explicitly. `.scoular-table-sortable` already sets it on the\r\n                  `<th>`, and cursor inherits — but a `<button>` resets it to the default arrow, so\r\n                  the one part of the header a user actually aims at was the one part not showing a\r\n                  click pointer. The resize handle keeps its own `cursor-col-resize`.\r\n                -->\r\n                <!--\r\n                  `before:absolute before:inset-0` stretches the button's HIT AREA over the whole\r\n                  header cell, so clicking anywhere in the tinted box sorts — not just the label and\r\n                  the arrow (JFrisbie, 2026-08-26). The `<th>`'s own padding and any width left over\r\n                  after a short label are the parts that used to swallow a click, and\r\n                  `.scoular-table-sortable` already put a `cursor-pointer` across all of it, so the\r\n                  cursor was promising a click the hit area did not deliver.\r\n\r\n                  Done as a stretched pseudo-element rather than by widening the button or moving the\r\n                  click onto the `<th>`, and both alternatives are worse:\r\n                    - `w-full` still cannot cover the `<th>`'s padding, and the design system's\r\n                      table CSS is unlayered, so that padding cannot be moved onto the button with a\r\n                      Tailwind utility anyway;\r\n                    - a handler on the `<th>` is not reachable by Tab and answers neither Enter nor\r\n                      Space, and it would double-fire when the click landed on the button too.\r\n\r\n                  ⚠ Two couplings this depends on, both silent if broken:\r\n                    1. the overlay anchors to the nearest positioned ancestor, which is the `<th>`\r\n                       (`relative`). **Do not add `relative` to this button** — the overlay would\r\n                       shrink back to the button's own box and the hit area would quietly revert.\r\n                    2. the resize handle carries `z-10` and so stays above the overlay; with\r\n                       `stopPropagation` in `onResizeStart`, a drag on the trailing edge still\r\n                       resizes rather than sorting.\r\n                  Both are pinned by tests, because neither has any visual symptom.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n                -->\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"cws:inline-flex cws:max-w-full cws:cursor-pointer cws:items-center cws:gap-1 truncate cws:font-medium cws:before:absolute cws:before:inset-0 cws:before:content-['']\"\r\n                  (click)=\"onHeaderActivate(column)\"\r\n                >\r\n                  <span class=\"truncate\">{{ column.header }}</span>\r\n\r\n                  <!--\r\n                    A permanent affordance, then the state. An arrow that appears only once a column\r\n                    is sorted gives no hint that the others can be sorted at all, which is why every\r\n                    sortable header carries the neutral double arrow until it becomes the active one.\r\n\r\n                    aria-hidden throughout: `aria-sort` on the <th> is what assistive technology\r\n                    reads, and announcing \"up down arrow\" beside every header would be pure noise.\r\n                  -->\r\n                  <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-[0.65rem] cws:leading-none\">\r\n                    @if (ariaSortFor(column.key) === 'ascending') {\r\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9650;</span>\r\n                    } @else if (ariaSortFor(column.key) === 'descending') {\r\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9660;</span>\r\n                    } @else {\r\n                      <span class=\"cws:text-slate-400 cws:dark:text-slate-500\">&#8645;</span>\r\n                    }\r\n                  </span>\r\n\r\n                  <!--\r\n                    The sort rank, shown only once more than one column is sorted. Without it a\r\n                    multi-column sort is indistinguishable from the grid ignoring the click that\r\n                    added the second key — which is exactly what accumulating sorts feels like\r\n                    otherwise.\r\n                  -->\r\n                  @if (sortRankFor(column.key); as rank) {\r\n                    <span\r\n                      aria-hidden=\"true\"\r\n                      class=\"cws:shrink-0 cws:rounded-sm cws:bg-scoular-blue/15 cws:px-1 cws:text-[0.6rem] cws:font-semibold cws:leading-none cws:text-scoular-blue cws:dark:bg-sky-400/20 cws:dark:text-sky-400\"\r\n                    >\r\n                      {{ rank }}\r\n                    </span>\r\n                  }\r\n\r\n                  <!--\r\n                    The rank for assistive technology. `aria-sort` reports the direction but has no\r\n                    way to express \"second key\", so without this a screen-reader user hears three\r\n                    columns each \"sorted descending\" and no order between them.\r\n                  -->\r\n                  @if (sortRankFor(column.key); as rank) {\r\n                    <span class=\"sr-only\">sort {{ rank }} of {{ sorts().length }}</span>\r\n                  }\r\n                </button>\r\n              } @else {\r\n                {{ column.header }}\r\n              }\r\n            </div>\r\n\r\n            <!--\r\n              Column resize handle, on the trailing edge of the header cell.\r\n\r\n              A <button> rather than a bare <div>: it has to be focusable and driveable by keyboard,\r\n              because a mouse-only resize is unavailable to anyone navigating by keyboard (02a §4.3).\r\n              Arrow keys nudge, Home resets to the caller's width.\r\n\r\n              `touch-none` stops the browser scrolling the table instead of reporting the drag on a\r\n              touch device, which is what makes this work on a laptop trackpad in tablet mode too.\r\n            -->\r\n            @if (!$last) {\r\n              <button\r\n                type=\"button\"\r\n                class=\"cws:absolute cws:-right-px cws:top-0 cws:z-10 cws:h-full cws:w-1.5 cws:cursor-col-resize cws:touch-none cws:bg-transparent cws:opacity-0 cws:transition-opacity cws:hover:bg-scoular-blue/40 cws:focus-visible:bg-scoular-blue/60 cws:focus-visible:opacity-100 cws:focus-visible:outline-none cws:group-hover:opacity-100 cws:dark:hover:bg-sky-400/40\"\r\n                [attr.aria-label]=\"'Resize ' + column.header + ' column'\"\r\n                (pointerdown)=\"onResizeStart($event, column)\"\r\n                (pointermove)=\"onResizeMove($event, column)\"\r\n                (pointerup)=\"onResizeEnd()\"\r\n                (pointercancel)=\"onResizeEnd()\"\r\n                (keydown)=\"onResizeKeydown($event, column)\"\r\n              ></button>\r\n            }\r\n          </th>\r\n        }\r\n\r\n        <!--\r\n          The actions heading. Not sortable and carries no resize handle — there is nothing to sort\r\n          and nothing to measure — so it is a plain `<th>` rather than going through the header\r\n          button that every data column uses.\r\n        -->\r\n        @if (hasActions()) {\r\n          <!--\r\n            🔴 **Pinned to the right edge, and this is a correctness point rather than a flourish.**\r\n\r\n            The approval queue is 15 columns and ~1900px wide inside an `overflow-x-auto` wrapper, so\r\n            without `sticky right-0` the buttons sit past the viewport and the primary action on the\r\n            screen can only be reached by scrolling right past fourteen columns of data. Measured:\r\n            they rendered off-screen at every width tested.\r\n\r\n            `bg-slate-50` matches the header band exactly, because a sticky cell needs its own opaque\r\n            background or the columns scroll through underneath it. `z-20` clears the resize handles\r\n            (`z-10`) so a handle cannot be dragged out from under it.\r\n          -->\r\n          <!--\r\n            ⚠ **The height comes from `cellHeightClass`, the same constant every other cell uses**, so\r\n            this cell cannot end up a different height from the data headers beside it.\r\n\r\n            ⚠ **It carried `px-3 py-2` and both were DEAD** (measured 2026-09-15: this cell computes\r\n            `8px 16px`, i.e. the design system's `px-4 py-2`). `.scoular-table-compact thead th` is\r\n            unlayered CSS at specificity (0,1,2) and beats a Tailwind utility in `@layer utilities`, so\r\n            the padding declared here never applied. Removed rather than left asserting something\r\n            untrue — and note the corollary: **padding is not available as a lever on these cells at\r\n            all**, which is why the uniform height is a `height`.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n          -->\r\n          <th\r\n            scope=\"col\"\r\n            class=\"cws:sticky cws:right-0 cws:z-20 cws:border-l cws:border-slate-300 cws:bg-slate-50 cws:text-left cws:font-medium cws:dark:border-slate-600 cws:dark:bg-slate-800\"\r\n            [class]=\"cellHeightClass\"\r\n          >\r\n            {{ actionsHeader() }}\r\n          </th>\r\n        }\r\n      </tr>\r\n    </thead>\r\n\r\n    <tbody #body>\r\n      @for (row of rows(); track trackBy()(row, $index); let index = $index) {\r\n        <!--\r\n          The tint is on the <tr> so it covers every cell. Hover is declared here rather than left to\r\n          the design system's own `tbody tr:hover`, because a tinted row needs a hover that is\r\n          brighter than its tint — otherwise the row a user is pointing at is the one that stops\r\n          responding.\r\n        -->\r\n        <!--\r\n          ⚠ **`dblclick`, not `click`** (2026-08-27). A single click now selects the cell under it, and\r\n          the two cannot both be true: a click that activates the row cannot leave a highlighted cell\r\n          behind to look at. Enter still activates, so the keyboard path is unchanged.\r\n        -->\r\n        <!--\r\n          Hover, focus, tone and selection all resolve in `rowClassFor` rather than being layered here,\r\n          because the tone tint and the selection tint are both plain `bg-*` on this element and the\r\n          winner would otherwise depend on stylesheet order. See that method for which wins and why.\r\n\r\n          `(focus)` selects the first column when focus lands on a row with nothing selected in it —\r\n          which is what makes **Tab** land on a cell rather than on a bare row.\r\n        -->\r\n        <tr\r\n          tabindex=\"0\"\r\n          class=\"cws:cursor-pointer cws:transition-colors\"\r\n          [class]=\"rowClassFor(row, index)\"\r\n          (focus)=\"onRowFocus(row)\"\r\n          (keydown)=\"onRowKeydown($event, row, index)\"\r\n          (dblclick)=\"rowActivate.emit(row)\"\r\n        >\r\n          @for (column of columns(); track column.key) {\r\n            <!--\r\n              `truncate` on every cell: one uniform row height is the point, so a long value is cut\r\n              with an ellipsis rather than wrapping and making its row taller than its neighbours. The\r\n              `title` carries the full text so nothing is unreachable — see GridColumn.tooltip for why\r\n              that is a convenience and not an accessibility answer.\r\n            -->\r\n            <!--\r\n              Cell hover and cell selection (JFrisbie, 2026-08-27).\r\n\r\n              **Hover is one step darker than the row's**, so pointing at a cell reads as \"this cell,\r\n              within this highlighted row\" rather than as a second, competing row highlight. The cell's\r\n              background paints over the row's because it is the inner element — no specificity contest,\r\n              and it deliberately covers the row *tint* for that one cell too.\r\n\r\n              **Selection is carried by the OUTLINE, not the background**, and that is on purpose:\r\n              `hover:bg-*` is a class-plus-pseudo-class (0,2,0) and beats a plain `bg-*` (0,1,0), so\r\n              hovering the selected cell repaints its background. The outline is untouched by hover, so\r\n              the selected cell stays identifiable while still giving hover feedback. Swapping the cue\r\n              to a background would make the selection vanish under the pointer.\r\n\r\n              `-outline-offset-2` draws the outline inside the cell, so it is not clipped by the\r\n              neighbouring cell or by the scroll container at the row's edges.\r\n\r\n              `data-cell-key` is how the component finds a keyboard-selected cell to scroll into view —\r\n              focus stays on the `<tr>`, so the browser will not do it.\r\n\r\n              🔴 `tabular-nums` on the end-aligned columns (2026-09-03). The model's own remarks say\r\n              these columns right-align \"so digits line up down the column, which is what makes a\r\n              column of figures scannable\" — and right-alignment alone does not deliver that in a\r\n              proportional font, where 1 is narrower than 8: 14,000 over 29,500 put its thousands\r\n              separator in a different place on each row.\r\n\r\n              Tied to `align === 'end'` rather than listed per column, so it cannot fall out of step —\r\n              the columns that right-align are exactly the numeric and date ones.\r\n            -->\r\n            <td\r\n              class=\"truncate cws:transition-colors cws:hover:bg-slate-200 cws:dark:hover:bg-slate-600/60\"\r\n              [attr.data-cell-key]=\"column.key\"\r\n              [class.cws:text-right]=\"column.align === 'end'\"\r\n              [class.cws:tabular-nums]=\"column.align === 'end'\"\r\n              [class]=\"cellClassFor(row, column)\"\r\n              (mousedown)=\"onCellMousedown(row, index, column)\"\r\n            >\r\n              @if (column.cell; as cellComponent) {\r\n                <!--\r\n                  A column that paints its own cell (F4.3b). The component gets the row and nothing\r\n                  else; `format` still decides what sorting, filtering and CSV read, so a component\r\n                  changes what is painted and never what the grid knows.\r\n                -->\r\n                <ng-container *ngComponentOutlet=\"cellComponent; inputs: { row: row }\" />\r\n              } @else if (badgeLabelFor(column, row); as badgeLabel) {\r\n                <!--\r\n                  The tone-to-class mapping lives in `cms-status-badge` (2026-09-16). It was one of\r\n                  three copies of the same five strings, and the copy that had dark-mode colours was\r\n                  the one in the shell's identity menu, so the grid's neutral pill did not.\r\n                -->\r\n                <cms-status-badge [tone]=\"badgeToneFor(column, row)!\" [small]=\"true\">\r\n                  {{ badgeLabel }}\r\n                </cms-status-badge>\r\n              } @else {\r\n                <span [attr.title]=\"titleFor(column, row) || null\">{{ column.format(row) }}</span>\r\n              }\r\n            </td>\r\n          }\r\n\r\n          <!--\r\n            🔴 The actions cell, and the two guards on it are load-bearing — each proven by a control\r\n            test that goes red without it.\r\n\r\n              • `(dblclick)` stopped: **the row** is double-click-to-activate. A double press — which\r\n                is exactly what someone does when a button appears not to have worked — would\r\n                otherwise navigate off the queue in the middle of the action it had just started.\r\n              • `(keydown)` stopped for Enter and Space: the row treats Enter as activate, and a\r\n                `<button>` fires `click` on both keys, so a keyboard user would do the action *and*\r\n                navigate.\r\n\r\n            ⚠ **There is deliberately NO `mousedown` guard, and the reason is worth recording because\r\n            the opposite looks obviously right.** Cell selection is bound per data `<td>`\r\n            (`onCellMousedown` on each one), not on the row — so a mousedown inside this cell reaches\r\n            no selection handler at all and a guard here would be a no-op. A first version had one,\r\n            with a comment calling it load-bearing; the control test for it passed with the guard\r\n            removed, which is what exposed the claim as false.\r\n\r\n            ⚠ This `<td>` also deliberately does not carry `data-cell-key`, the hover class or the\r\n            selection class. It is not a value, so it must not join cell selection or Ctrl+C —\r\n            copying a cell whose content is two buttons would put an empty string on the clipboard\r\n            and read as a broken copy.\r\n          -->\r\n          @if (hasActions()) {\r\n            <!--\r\n              ⚠ **`px-3 py-1` was here and both were DEAD**, overridden by\r\n              `.scoular-table-compact tbody td`'s `px-4 py-2` — unlayered CSS, so a Tailwind utility\r\n              cannot win. Measured 2026-09-15: this cell computed `8px 16px`, not `4px 12px`.\r\n\r\n              🔑 **That dead `py-1` is why the rows were ~6px taller than the header.** The Review\r\n              button is a 26px `scoular-btn-sm`, and with the design system supplying 16px of vertical\r\n              padding instead of the 8px this asked for, the cell measured **43.5px** while every\r\n              other cell in the grid topped out at 36px.\r\n\r\n              ⚠ **This cell is still the tallest thing in the table, and that is what set the\r\n              standard's floor.** Its 43.5px requirement is intrinsic — measured identical with and\r\n              without a declared height — so `cellHeightClass` is **44px**, the smallest value that\r\n              clears it. Do not lower it without shrinking this button first; see\r\n              `CELL_HEIGHT_CLASS`.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n            -->\r\n            <td\r\n              class=\"cws:sticky cws:right-0 cws:z-10 cws:border-l cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-900\"\r\n              [class]=\"cellHeightClass\"\r\n              (dblclick)=\"$event.stopPropagation()\"\r\n              (keydown)=\"onActionKeydown($event)\"\r\n            >\r\n              <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n                @for (action of actions(); track action.label) {\r\n                  <!--\r\n                    ⚠ **The access-key letter is rendered, not merely handled.** CTRM's option codes\r\n                    are the precedent — `2`=Update, `4`=Delete typed against a subfile row — and the\r\n                    study's finding about them is that an unlabelled key is a key nobody learns.\r\n                    `aria-keyshortcuts` carries the same letter for a screen reader, from one source.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    [class]=\"actionClassFor(action)\"\r\n                    [disabled]=\"isActionDisabled(action, row)\"\r\n                    [attr.title]=\"refusalFor(action, row)\"\r\n                    [attr.aria-busy]=\"action.busy?.(row) ? 'true' : null\"\r\n                    [attr.aria-keyshortcuts]=\"action.accessKey ? action.accessKey.toUpperCase() : null\"\r\n                    (click)=\"runAction($event, action, row)\"\r\n                  >\r\n                    {{ action.label }}\r\n\r\n                    @if (action.accessKey) {\r\n                      <!--\r\n                        `aria-hidden` because `aria-keyshortcuts` above already announces it — without\r\n                        this a screen reader reads \"Edit E\", which sounds like a typo rather than a\r\n                        shortcut.\r\n                      -->\r\n                      <span\r\n                        aria-hidden=\"true\"\r\n                        class=\"cws:ml-1 cws:font-mono cws:text-[10px] cws:uppercase cws:opacity-60\"\r\n                        >{{ action.accessKey }}</span\r\n                      >\r\n                    }\r\n                  </button>\r\n                }\r\n              </div>\r\n            </td>\r\n          }\r\n        </tr>\r\n      }\r\n    </tbody>\r\n  </table>\r\n</div>\r\n",
		dependencies: [{
			kind: "directive",
			type: NgComponentOutlet,
			selector: "[ngComponentOutlet]",
			inputs: [
				"ngComponentOutlet",
				"ngComponentOutletInputs",
				"ngComponentOutletInjector",
				"ngComponentOutletEnvironmentInjector",
				"ngComponentOutletContent",
				"ngComponentOutletNgModule"
			],
			exportAs: ["ngComponentOutlet"]
		}, {
			kind: "component",
			type: StatusBadgeComponent,
			selector: "cms-status-badge",
			inputs: ["tone", "small"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: DataGridComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-data-grid",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgComponentOutlet, StatusBadgeComponent],
			template: "<!--\r\n  A real <table>, not a div grid. Semantics come free (row/column relationships announced, headers\r\n  associated with cells), and the design system already styles `scoular-table`.\r\n\r\n  `tabindex=\"0\"` on every row rather than a roving tabindex: the grid is one page of at most 200 rows\r\n  (ContractListQuery.MaxPageSize), so the simpler model costs nothing and cannot desynchronise from\r\n  the focused row the way a roving index can.\r\n\r\n  The rounded, bordered wrapper is what makes the table read as one surface in dark mode. Without it\r\n  the striped rows run into the page background and the grid loses its edges. Square corners were\r\n  tried on 2026-08-25 and reverted the same day — rounded reads better against the page.\r\n-->\r\n<div\r\n  class=\"cws:overflow-x-auto cws:rounded-lg cws:border cws:border-slate-200 cws:bg-white cws:shadow-sm cws:dark:border-slate-700 cws:dark:bg-slate-900 cws:dark:shadow-none\"\r\n>\r\n  <!--\r\n    `table-fixed` is load-bearing, not tidiness. `text-overflow: ellipsis` needs a cell whose width\r\n    does not depend on its content, so auto layout — which sizes columns to the longest value — can\r\n    never truncate. Fixed layout is also what makes a dragged width stick instead of being\r\n    recalculated from the text.\r\n\r\n    The consequence to know about: every column takes its declared width and content no longer\r\n    influences it, so a column with no width falls back to DEFAULT_COLUMN_WIDTH rather than sizing\r\n    itself.\r\n  -->\r\n  <!--\r\n    **Never `scoular-table-striped`, even when `striped` is on.**\r\n\r\n    `.scoular-table-striped tbody tr:nth-child(even)` has specificity (0,2,2); a Tailwind background\r\n    utility like `.bg-scoular-red\\/5` has (0,1,0). So that class beat the row tint on every *even*\r\n    row — half the rejected and unapproved contracts showed no tint at all — and because it is\r\n    declared after the design system's own `tbody tr:hover`, even rows did not highlight on hover\r\n    either. Raising the tint's specificity would then have had to beat hover as well, which is a\r\n    fight with no end.\r\n\r\n    ⚠ **Striping returned as an opt-in input** (JFrisbie, 2026-09-14) and is emitted from\r\n    `rowClassFor`, where tone, hover, focus and selection are already arbitrated — so the stripe can\r\n    be made to lose to all of them by simply not being emitted.\r\n\r\n    ⚠ **This comment used to end \"a grid using tones must not stripe\". That is now too strong** — the\r\n    workspace grid stripes with tones on measured evidence (2026-09-15). The tone still always wins,\r\n    and the two remain distinguishable because the stripe is *cool* and both tints are *warm*. See\r\n    the `striped` input for the two conditions a grid has to meet before combining them.\r\n\r\n    Rows remain separable without it via the `divide-y` borders the design system already applies,\r\n    which is why `striped` defaults to off.\r\n  -->\r\n  <table class=\"scoular-table scoular-table-compact cws:table-fixed\" [attr.aria-label]=\"label()\">\r\n    <colgroup>\r\n      @for (column of widths(); track column.key) {\r\n        <col [style.width.px]=\"column.width\" />\r\n      }\r\n      <!--\r\n        The actions column's width. Needed here as well as on the cells because the table is\r\n        `table-fixed`, so the colgroup is what sizes it — without this the browser divides the\r\n        remaining space and the buttons wrap.\r\n      -->\r\n      @if (hasActions()) {\r\n        <col [style.width.px]=\"actionsWidth()\" />\r\n      }\r\n    </colgroup>\r\n\r\n    <!--\r\n      A single firm rule under the header, so the headings read as a separate band from the data.\r\n      Heavier than the row dividers on purpose: `divide-y` between rows is a hairline, and matching it\r\n      here would leave the header floating.\r\n    -->\r\n    <!--\r\n      A tinted header band (2026-09-03). It was white on white in light mode, so the only thing\r\n      separating the column names from the first row of data was the 2px rule underneath — the header\r\n      read as another row rather than as the table's chrome. Dark mode already had the separation for\r\n      free, which is why this only shows up in light.\r\n\r\n      A `bg-*` on `<thead>` rather than on each `<th>`: one declaration, and it cannot fall out of step\r\n      with the header hover, which is a `hover:bg-*` on the cell and still wins over this (0,2,0)\r\n      against (0,1,0).\r\n    -->\r\n    <thead class=\"cws:border-b-2 cws:border-slate-300 cws:bg-slate-50 cws:dark:border-slate-600 cws:dark:bg-slate-800/60\">\r\n      <tr>\r\n        @for (column of columns(); track column.key) {\r\n          <!--\r\n            Hover tints the whole header cell rather than just its text. `group` so the resize handle\r\n            can reveal itself with the same hover, and `relative` so the handle can sit on the cell's\r\n            trailing edge.\r\n\r\n            Hover lives in `headerClassFor` rather than here, because the sorted and unsorted variants\r\n            both declare one and only one may be emitted — see SORTED_HEADER_CLASS.\r\n          -->\r\n          <th\r\n            scope=\"col\"\r\n            class=\"cws:group cws:relative cws:transition-colors\"\r\n            [class]=\"headerClassFor(column)\"\r\n            [class.scoular-table-sortable]=\"column.sortable\"\r\n            [class.cws:text-right]=\"column.align === 'end'\"\r\n            [attr.aria-sort]=\"column.sortable ? ariaSortFor(column.key) : null\"\r\n          >\r\n            <div class=\"truncate\" [class.cws:text-right]=\"column.align === 'end'\">\r\n              @if (column.sortable) {\r\n                <!--\r\n                  A real <button> inside the <th>: the sort must be reachable by Tab and activated by\r\n                  Enter *and* Space, which a click handler on the <th> gives you neither of.\r\n                -->\r\n                <!--\r\n                  `cursor-pointer` explicitly. `.scoular-table-sortable` already sets it on the\r\n                  `<th>`, and cursor inherits — but a `<button>` resets it to the default arrow, so\r\n                  the one part of the header a user actually aims at was the one part not showing a\r\n                  click pointer. The resize handle keeps its own `cursor-col-resize`.\r\n                -->\r\n                <!--\r\n                  `before:absolute before:inset-0` stretches the button's HIT AREA over the whole\r\n                  header cell, so clicking anywhere in the tinted box sorts — not just the label and\r\n                  the arrow (JFrisbie, 2026-08-26). The `<th>`'s own padding and any width left over\r\n                  after a short label are the parts that used to swallow a click, and\r\n                  `.scoular-table-sortable` already put a `cursor-pointer` across all of it, so the\r\n                  cursor was promising a click the hit area did not deliver.\r\n\r\n                  Done as a stretched pseudo-element rather than by widening the button or moving the\r\n                  click onto the `<th>`, and both alternatives are worse:\r\n                    - `w-full` still cannot cover the `<th>`'s padding, and the design system's\r\n                      table CSS is unlayered, so that padding cannot be moved onto the button with a\r\n                      Tailwind utility anyway;\r\n                    - a handler on the `<th>` is not reachable by Tab and answers neither Enter nor\r\n                      Space, and it would double-fire when the click landed on the button too.\r\n\r\n                  ⚠ Two couplings this depends on, both silent if broken:\r\n                    1. the overlay anchors to the nearest positioned ancestor, which is the `<th>`\r\n                       (`relative`). **Do not add `relative` to this button** — the overlay would\r\n                       shrink back to the button's own box and the hit area would quietly revert.\r\n                    2. the resize handle carries `z-10` and so stays above the overlay; with\r\n                       `stopPropagation` in `onResizeStart`, a drag on the trailing edge still\r\n                       resizes rather than sorting.\r\n                  Both are pinned by tests, because neither has any visual symptom.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n                -->\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"cws:inline-flex cws:max-w-full cws:cursor-pointer cws:items-center cws:gap-1 truncate cws:font-medium cws:before:absolute cws:before:inset-0 cws:before:content-['']\"\r\n                  (click)=\"onHeaderActivate(column)\"\r\n                >\r\n                  <span class=\"truncate\">{{ column.header }}</span>\r\n\r\n                  <!--\r\n                    A permanent affordance, then the state. An arrow that appears only once a column\r\n                    is sorted gives no hint that the others can be sorted at all, which is why every\r\n                    sortable header carries the neutral double arrow until it becomes the active one.\r\n\r\n                    aria-hidden throughout: `aria-sort` on the <th> is what assistive technology\r\n                    reads, and announcing \"up down arrow\" beside every header would be pure noise.\r\n                  -->\r\n                  <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-[0.65rem] cws:leading-none\">\r\n                    @if (ariaSortFor(column.key) === 'ascending') {\r\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9650;</span>\r\n                    } @else if (ariaSortFor(column.key) === 'descending') {\r\n                      <span class=\"cws:text-scoular-blue cws:dark:text-sky-400\">&#9660;</span>\r\n                    } @else {\r\n                      <span class=\"cws:text-slate-400 cws:dark:text-slate-500\">&#8645;</span>\r\n                    }\r\n                  </span>\r\n\r\n                  <!--\r\n                    The sort rank, shown only once more than one column is sorted. Without it a\r\n                    multi-column sort is indistinguishable from the grid ignoring the click that\r\n                    added the second key — which is exactly what accumulating sorts feels like\r\n                    otherwise.\r\n                  -->\r\n                  @if (sortRankFor(column.key); as rank) {\r\n                    <span\r\n                      aria-hidden=\"true\"\r\n                      class=\"cws:shrink-0 cws:rounded-sm cws:bg-scoular-blue/15 cws:px-1 cws:text-[0.6rem] cws:font-semibold cws:leading-none cws:text-scoular-blue cws:dark:bg-sky-400/20 cws:dark:text-sky-400\"\r\n                    >\r\n                      {{ rank }}\r\n                    </span>\r\n                  }\r\n\r\n                  <!--\r\n                    The rank for assistive technology. `aria-sort` reports the direction but has no\r\n                    way to express \"second key\", so without this a screen-reader user hears three\r\n                    columns each \"sorted descending\" and no order between them.\r\n                  -->\r\n                  @if (sortRankFor(column.key); as rank) {\r\n                    <span class=\"sr-only\">sort {{ rank }} of {{ sorts().length }}</span>\r\n                  }\r\n                </button>\r\n              } @else {\r\n                {{ column.header }}\r\n              }\r\n            </div>\r\n\r\n            <!--\r\n              Column resize handle, on the trailing edge of the header cell.\r\n\r\n              A <button> rather than a bare <div>: it has to be focusable and driveable by keyboard,\r\n              because a mouse-only resize is unavailable to anyone navigating by keyboard (02a §4.3).\r\n              Arrow keys nudge, Home resets to the caller's width.\r\n\r\n              `touch-none` stops the browser scrolling the table instead of reporting the drag on a\r\n              touch device, which is what makes this work on a laptop trackpad in tablet mode too.\r\n            -->\r\n            @if (!$last) {\r\n              <button\r\n                type=\"button\"\r\n                class=\"cws:absolute cws:-right-px cws:top-0 cws:z-10 cws:h-full cws:w-1.5 cws:cursor-col-resize cws:touch-none cws:bg-transparent cws:opacity-0 cws:transition-opacity cws:hover:bg-scoular-blue/40 cws:focus-visible:bg-scoular-blue/60 cws:focus-visible:opacity-100 cws:focus-visible:outline-none cws:group-hover:opacity-100 cws:dark:hover:bg-sky-400/40\"\r\n                [attr.aria-label]=\"'Resize ' + column.header + ' column'\"\r\n                (pointerdown)=\"onResizeStart($event, column)\"\r\n                (pointermove)=\"onResizeMove($event, column)\"\r\n                (pointerup)=\"onResizeEnd()\"\r\n                (pointercancel)=\"onResizeEnd()\"\r\n                (keydown)=\"onResizeKeydown($event, column)\"\r\n              ></button>\r\n            }\r\n          </th>\r\n        }\r\n\r\n        <!--\r\n          The actions heading. Not sortable and carries no resize handle — there is nothing to sort\r\n          and nothing to measure — so it is a plain `<th>` rather than going through the header\r\n          button that every data column uses.\r\n        -->\r\n        @if (hasActions()) {\r\n          <!--\r\n            🔴 **Pinned to the right edge, and this is a correctness point rather than a flourish.**\r\n\r\n            The approval queue is 15 columns and ~1900px wide inside an `overflow-x-auto` wrapper, so\r\n            without `sticky right-0` the buttons sit past the viewport and the primary action on the\r\n            screen can only be reached by scrolling right past fourteen columns of data. Measured:\r\n            they rendered off-screen at every width tested.\r\n\r\n            `bg-slate-50` matches the header band exactly, because a sticky cell needs its own opaque\r\n            background or the columns scroll through underneath it. `z-20` clears the resize handles\r\n            (`z-10`) so a handle cannot be dragged out from under it.\r\n          -->\r\n          <!--\r\n            ⚠ **The height comes from `cellHeightClass`, the same constant every other cell uses**, so\r\n            this cell cannot end up a different height from the data headers beside it.\r\n\r\n            ⚠ **It carried `px-3 py-2` and both were DEAD** (measured 2026-09-15: this cell computes\r\n            `8px 16px`, i.e. the design system's `px-4 py-2`). `.scoular-table-compact thead th` is\r\n            unlayered CSS at specificity (0,1,2) and beats a Tailwind utility in `@layer utilities`, so\r\n            the padding declared here never applied. Removed rather than left asserting something\r\n            untrue — and note the corollary: **padding is not available as a lever on these cells at\r\n            all**, which is why the uniform height is a `height`.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n          -->\r\n          <th\r\n            scope=\"col\"\r\n            class=\"cws:sticky cws:right-0 cws:z-20 cws:border-l cws:border-slate-300 cws:bg-slate-50 cws:text-left cws:font-medium cws:dark:border-slate-600 cws:dark:bg-slate-800\"\r\n            [class]=\"cellHeightClass\"\r\n          >\r\n            {{ actionsHeader() }}\r\n          </th>\r\n        }\r\n      </tr>\r\n    </thead>\r\n\r\n    <tbody #body>\r\n      @for (row of rows(); track trackBy()(row, $index); let index = $index) {\r\n        <!--\r\n          The tint is on the <tr> so it covers every cell. Hover is declared here rather than left to\r\n          the design system's own `tbody tr:hover`, because a tinted row needs a hover that is\r\n          brighter than its tint — otherwise the row a user is pointing at is the one that stops\r\n          responding.\r\n        -->\r\n        <!--\r\n          ⚠ **`dblclick`, not `click`** (2026-08-27). A single click now selects the cell under it, and\r\n          the two cannot both be true: a click that activates the row cannot leave a highlighted cell\r\n          behind to look at. Enter still activates, so the keyboard path is unchanged.\r\n        -->\r\n        <!--\r\n          Hover, focus, tone and selection all resolve in `rowClassFor` rather than being layered here,\r\n          because the tone tint and the selection tint are both plain `bg-*` on this element and the\r\n          winner would otherwise depend on stylesheet order. See that method for which wins and why.\r\n\r\n          `(focus)` selects the first column when focus lands on a row with nothing selected in it —\r\n          which is what makes **Tab** land on a cell rather than on a bare row.\r\n        -->\r\n        <tr\r\n          tabindex=\"0\"\r\n          class=\"cws:cursor-pointer cws:transition-colors\"\r\n          [class]=\"rowClassFor(row, index)\"\r\n          (focus)=\"onRowFocus(row)\"\r\n          (keydown)=\"onRowKeydown($event, row, index)\"\r\n          (dblclick)=\"rowActivate.emit(row)\"\r\n        >\r\n          @for (column of columns(); track column.key) {\r\n            <!--\r\n              `truncate` on every cell: one uniform row height is the point, so a long value is cut\r\n              with an ellipsis rather than wrapping and making its row taller than its neighbours. The\r\n              `title` carries the full text so nothing is unreachable — see GridColumn.tooltip for why\r\n              that is a convenience and not an accessibility answer.\r\n            -->\r\n            <!--\r\n              Cell hover and cell selection (JFrisbie, 2026-08-27).\r\n\r\n              **Hover is one step darker than the row's**, so pointing at a cell reads as \"this cell,\r\n              within this highlighted row\" rather than as a second, competing row highlight. The cell's\r\n              background paints over the row's because it is the inner element — no specificity contest,\r\n              and it deliberately covers the row *tint* for that one cell too.\r\n\r\n              **Selection is carried by the OUTLINE, not the background**, and that is on purpose:\r\n              `hover:bg-*` is a class-plus-pseudo-class (0,2,0) and beats a plain `bg-*` (0,1,0), so\r\n              hovering the selected cell repaints its background. The outline is untouched by hover, so\r\n              the selected cell stays identifiable while still giving hover feedback. Swapping the cue\r\n              to a background would make the selection vanish under the pointer.\r\n\r\n              `-outline-offset-2` draws the outline inside the cell, so it is not clipped by the\r\n              neighbouring cell or by the scroll container at the row's edges.\r\n\r\n              `data-cell-key` is how the component finds a keyboard-selected cell to scroll into view —\r\n              focus stays on the `<tr>`, so the browser will not do it.\r\n\r\n              🔴 `tabular-nums` on the end-aligned columns (2026-09-03). The model's own remarks say\r\n              these columns right-align \"so digits line up down the column, which is what makes a\r\n              column of figures scannable\" — and right-alignment alone does not deliver that in a\r\n              proportional font, where 1 is narrower than 8: 14,000 over 29,500 put its thousands\r\n              separator in a different place on each row.\r\n\r\n              Tied to `align === 'end'` rather than listed per column, so it cannot fall out of step —\r\n              the columns that right-align are exactly the numeric and date ones.\r\n            -->\r\n            <td\r\n              class=\"truncate cws:transition-colors cws:hover:bg-slate-200 cws:dark:hover:bg-slate-600/60\"\r\n              [attr.data-cell-key]=\"column.key\"\r\n              [class.cws:text-right]=\"column.align === 'end'\"\r\n              [class.cws:tabular-nums]=\"column.align === 'end'\"\r\n              [class]=\"cellClassFor(row, column)\"\r\n              (mousedown)=\"onCellMousedown(row, index, column)\"\r\n            >\r\n              @if (column.cell; as cellComponent) {\r\n                <!--\r\n                  A column that paints its own cell (F4.3b). The component gets the row and nothing\r\n                  else; `format` still decides what sorting, filtering and CSV read, so a component\r\n                  changes what is painted and never what the grid knows.\r\n                -->\r\n                <ng-container *ngComponentOutlet=\"cellComponent; inputs: { row: row }\" />\r\n              } @else if (badgeLabelFor(column, row); as badgeLabel) {\r\n                <!--\r\n                  The tone-to-class mapping lives in `cms-status-badge` (2026-09-16). It was one of\r\n                  three copies of the same five strings, and the copy that had dark-mode colours was\r\n                  the one in the shell's identity menu, so the grid's neutral pill did not.\r\n                -->\r\n                <cms-status-badge [tone]=\"badgeToneFor(column, row)!\" [small]=\"true\">\r\n                  {{ badgeLabel }}\r\n                </cms-status-badge>\r\n              } @else {\r\n                <span [attr.title]=\"titleFor(column, row) || null\">{{ column.format(row) }}</span>\r\n              }\r\n            </td>\r\n          }\r\n\r\n          <!--\r\n            🔴 The actions cell, and the two guards on it are load-bearing — each proven by a control\r\n            test that goes red without it.\r\n\r\n              • `(dblclick)` stopped: **the row** is double-click-to-activate. A double press — which\r\n                is exactly what someone does when a button appears not to have worked — would\r\n                otherwise navigate off the queue in the middle of the action it had just started.\r\n              • `(keydown)` stopped for Enter and Space: the row treats Enter as activate, and a\r\n                `<button>` fires `click` on both keys, so a keyboard user would do the action *and*\r\n                navigate.\r\n\r\n            ⚠ **There is deliberately NO `mousedown` guard, and the reason is worth recording because\r\n            the opposite looks obviously right.** Cell selection is bound per data `<td>`\r\n            (`onCellMousedown` on each one), not on the row — so a mousedown inside this cell reaches\r\n            no selection handler at all and a guard here would be a no-op. A first version had one,\r\n            with a comment calling it load-bearing; the control test for it passed with the guard\r\n            removed, which is what exposed the claim as false.\r\n\r\n            ⚠ This `<td>` also deliberately does not carry `data-cell-key`, the hover class or the\r\n            selection class. It is not a value, so it must not join cell selection or Ctrl+C —\r\n            copying a cell whose content is two buttons would put an empty string on the clipboard\r\n            and read as a broken copy.\r\n          -->\r\n          @if (hasActions()) {\r\n            <!--\r\n              ⚠ **`px-3 py-1` was here and both were DEAD**, overridden by\r\n              `.scoular-table-compact tbody td`'s `px-4 py-2` — unlayered CSS, so a Tailwind utility\r\n              cannot win. Measured 2026-09-15: this cell computed `8px 16px`, not `4px 12px`.\r\n\r\n              🔑 **That dead `py-1` is why the rows were ~6px taller than the header.** The Review\r\n              button is a 26px `scoular-btn-sm`, and with the design system supplying 16px of vertical\r\n              padding instead of the 8px this asked for, the cell measured **43.5px** while every\r\n              other cell in the grid topped out at 36px.\r\n\r\n              ⚠ **This cell is still the tallest thing in the table, and that is what set the\r\n              standard's floor.** Its 43.5px requirement is intrinsic — measured identical with and\r\n              without a declared height — so `cellHeightClass` is **44px**, the smallest value that\r\n              clears it. Do not lower it without shrinking this button first; see\r\n              `CELL_HEIGHT_CLASS`.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n            -->\r\n            <td\r\n              class=\"cws:sticky cws:right-0 cws:z-10 cws:border-l cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-900\"\r\n              [class]=\"cellHeightClass\"\r\n              (dblclick)=\"$event.stopPropagation()\"\r\n              (keydown)=\"onActionKeydown($event)\"\r\n            >\r\n              <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n                @for (action of actions(); track action.label) {\r\n                  <!--\r\n                    ⚠ **The access-key letter is rendered, not merely handled.** CTRM's option codes\r\n                    are the precedent — `2`=Update, `4`=Delete typed against a subfile row — and the\r\n                    study's finding about them is that an unlabelled key is a key nobody learns.\r\n                    `aria-keyshortcuts` carries the same letter for a screen reader, from one source.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    [class]=\"actionClassFor(action)\"\r\n                    [disabled]=\"isActionDisabled(action, row)\"\r\n                    [attr.title]=\"refusalFor(action, row)\"\r\n                    [attr.aria-busy]=\"action.busy?.(row) ? 'true' : null\"\r\n                    [attr.aria-keyshortcuts]=\"action.accessKey ? action.accessKey.toUpperCase() : null\"\r\n                    (click)=\"runAction($event, action, row)\"\r\n                  >\r\n                    {{ action.label }}\r\n\r\n                    @if (action.accessKey) {\r\n                      <!--\r\n                        `aria-hidden` because `aria-keyshortcuts` above already announces it — without\r\n                        this a screen reader reads \"Edit E\", which sounds like a typo rather than a\r\n                        shortcut.\r\n                      -->\r\n                      <span\r\n                        aria-hidden=\"true\"\r\n                        class=\"cws:ml-1 cws:font-mono cws:text-[10px] cws:uppercase cws:opacity-60\"\r\n                        >{{ action.accessKey }}</span\r\n                      >\r\n                    }\r\n                  </button>\r\n                }\r\n              </div>\r\n            </td>\r\n          }\r\n        </tr>\r\n      }\r\n    </tbody>\r\n  </table>\r\n</div>\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		rows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rows",
				required: true
			}]
		}],
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		striped: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "striped",
				required: false
			}]
		}],
		actions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actions",
				required: false
			}]
		}],
		actionsHeader: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actionsHeader",
				required: false
			}]
		}],
		actionsWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "actionsWidth",
				required: false
			}]
		}],
		sorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sorts",
				required: false
			}]
		}],
		rowTone: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowTone",
				required: false
			}]
		}],
		trackBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "trackBy",
				required: false
			}]
		}],
		focusKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "focusKey",
				required: false
			}]
		}],
		sortChange: [{
			type: i0.Output,
			args: ["sortChange"]
		}],
		rowActivate: [{
			type: i0.Output,
			args: ["rowActivate"]
		}],
		cellCopy: [{
			type: i0.Output,
			args: ["cellCopy"]
		}],
		pageStep: [{
			type: i0.Output,
			args: ["pageStep"]
		}],
		body: [{
			type: i0.ViewChild,
			args: ["body", { isSignal: true }]
		}]
	}
});
function toCsv(columns, rows) {
	return [columns.map((column) => escapeCell(column.header)), ...rows.map((row) => columns.map((column) => escapeCell(column.format(row))))].map((cells) => cells.join(",")).join("\r\n");
}
function escapeCell(value) {
	const guarded = /^[=+\-@\t\r]/.test(value) ? `\t${value}` : value;
	return /[",\r\n]|^\s|\s$/.test(guarded) ? `"${guarded.replace(/"/g, "\"\"")}"` : guarded;
}
function downloadCsv(filename, csv) {
	downloadBlob(filename, new Blob([`﻿${csv}`], { type: "text/csv;charset=utf-8" }));
}
function downloadBlob(filename, blob) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
function exportFieldsFor(columns) {
	return columns.map((column) => ({
		key: column.key,
		header: column.header,
		included: true
	}));
}
function reconcileExportFields(fields, columns) {
	const byKey = new Map(columns.map((column) => [column.key, column]));
	const seen = /* @__PURE__ */ new Set();
	const kept = [];
	for (const field of fields) {
		const column = byKey.get(field.key);
		if (column !== void 0 && !seen.has(field.key)) {
			seen.add(field.key);
			kept.push({
				key: field.key,
				header: column.header,
				included: field.included
			});
		}
	}
	for (const column of columns) if (!seen.has(column.key)) kept.push({
		key: column.key,
		header: column.header,
		included: true
	});
	return kept;
}
function applyExportFields(columns, fields) {
	const byKey = new Map(columns.map((column) => [column.key, column]));
	return fields.filter((field) => field.included).map((field) => byKey.get(field.key)).filter((column) => column !== void 0);
}
function toggleExportField(fields, key) {
	return fields.map((field) => field.key === key ? {
		...field,
		included: !field.included
	} : field);
}
function setAllExportFields(fields, included) {
	return fields.map((field) => ({
		...field,
		included
	}));
}
function moveExportField(fields, from, to) {
	if (from === to || from < 0 || to < 0 || from >= fields.length || to >= fields.length) return fields;
	const next = [...fields];
	const [moved] = next.splice(from, 1);
	next.splice(to, 0, moved);
	return next;
}
function includedExportFieldCount(fields) {
	return fields.filter((field) => field.included).length;
}
var ExportFieldsComponent = class ExportFieldsComponent {
	fields = input.required(...ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []);
	fieldsChange = output();
	draggingIndex = signal(null, ...ngDevMode ? [{ debugName: "draggingIndex" }] : /* istanbul ignore next */ []);
	dropIndex = signal(null, ...ngDevMode ? [{ debugName: "dropIndex" }] : /* istanbul ignore next */ []);
	includedCount = computed(() => includedExportFieldCount(this.fields()), ...ngDevMode ? [{ debugName: "includedCount" }] : /* istanbul ignore next */ []);
	total = computed(() => this.fields().length, ...ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []);
	canExport = computed(() => this.includedCount() > 0, ...ngDevMode ? [{ debugName: "canExport" }] : /* istanbul ignore next */ []);
	onToggle(key) {
		this.fieldsChange.emit(toggleExportField(this.fields(), key));
	}
	onSelectAll() {
		this.fieldsChange.emit(setAllExportFields(this.fields(), true));
	}
	onClearAll() {
		this.fieldsChange.emit(setAllExportFields(this.fields(), false));
	}
	onMove(from, to) {
		this.fieldsChange.emit(moveExportField(this.fields(), from, to));
	}
	onDragStart(index, event) {
		this.draggingIndex.set(index);
		event.dataTransfer?.setData("text/plain", String(index));
		if (event.dataTransfer) event.dataTransfer.effectAllowed = "move";
	}
	onDragOver(index, event) {
		event.preventDefault();
		this.dropIndex.set(index);
	}
	onDrop(index, event) {
		event.preventDefault();
		const from = this.draggingIndex();
		this.draggingIndex.set(null);
		this.dropIndex.set(null);
		if (from !== null) this.onMove(from, index);
	}
	onDragEnd() {
		this.draggingIndex.set(null);
		this.dropIndex.set(null);
	}
	onKeydown(index, event) {
		if (!event.altKey) return;
		if (event.key === "ArrowUp" && index > 0) {
			event.preventDefault();
			this.onMove(index, index - 1);
		} else if (event.key === "ArrowDown" && index < this.fields().length - 1) {
			event.preventDefault();
			this.onMove(index, index + 1);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ExportFieldsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ExportFieldsComponent,
		isStandalone: true,
		selector: "cms-export-fields",
		inputs: { fields: {
			classPropertyName: "fields",
			publicName: "fields",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		outputs: { fieldsChange: "fieldsChange" },
		ngImport: i0,
		template: "<div class=\"cws:flex cws:flex-col cws:gap-2\">\r\n  <!--\r\n    The count is the answer to \"what am I about to get\", and it is stated rather than left to be\r\n    counted off the list — 24 rows is more than anyone tallies by eye, and the whole point of the\r\n    panel is that the file no longer matches the grid.\r\n  -->\r\n  <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\r\n    <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n      {{ includedCount() }} of {{ total() }} fields\r\n    </span>\r\n\r\n    <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\r\n        [disabled]=\"includedCount() === total()\"\r\n        (click)=\"onSelectAll()\"\r\n      >\r\n        Select all\r\n      </button>\r\n      <span aria-hidden=\"true\" class=\"cws:text-xs cws:text-slate-400\">·</span>\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\r\n        [disabled]=\"includedCount() === 0\"\r\n        (click)=\"onClearAll()\"\r\n      >\r\n        Clear\r\n      </button>\r\n    </div>\r\n  </div>\r\n\r\n  <!--\r\n    🔴 A LIST, not a table, and `role=\"list\"` is explicit because `list-none` removes the implicit\r\n    one in Safari and VoiceOver. The order is the meaning here, so a screen reader announcing \"list,\r\n    24 items, item 3 of 24\" is carrying the information the drag gesture conveys visually.\r\n\r\n    Capped height with its own scroll: the workspace grid has 24 columns, and a panel that grows to\r\n    fit them pushes its own export buttons off the bottom of the viewport — the one thing the user\r\n    opened it to reach.\r\n  -->\r\n  <!--\r\n    ⚠ **`select-none` is load-bearing here too, and it is the same defect the filter chips had**\r\n    (JFrisbie, 2026-09-14). These rows are `draggable`, and a press inside a TEXT SELECTION makes\r\n    Chrome drag the selection rather than the row -- so once a user has selected anything across\r\n    this list, reordering stops working until the selection is cleared. Measured on the chip row,\r\n    where the same cause could not be dragged out of without reloading the page.\r\n  -->\r\n  <ul\r\n    role=\"list\"\r\n    class=\"cws:max-h-64 cws:select-none cws:overflow-y-auto cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\"\r\n    aria-label=\"Fields to export, in order\"\r\n  >\r\n    @for (field of fields(); track field.key) {\r\n      <li\r\n        class=\"cws:flex cws:items-center cws:gap-2 cws:border-b cws:border-slate-100 cws:px-2 cws:py-1.5 cws:last:border-b-0 cws:dark:border-slate-800\"\r\n        [class.cws:bg-slate-100]=\"draggingIndex() === $index\"\r\n        [class.cws:dark:bg-slate-800]=\"draggingIndex() === $index\"\r\n        [class.cws:border-t-2]=\"dropIndex() === $index && draggingIndex() !== $index\"\r\n        [class.cws:border-t-scoular-blue]=\"dropIndex() === $index && draggingIndex() !== $index\"\r\n        draggable=\"true\"\r\n        tabindex=\"0\"\r\n        [attr.aria-label]=\"\r\n          field.header\r\n            + ', position ' + ($index + 1) + ' of ' + total()\r\n            + (field.included ? ', included' : ', not included')\r\n            + '. Alt+Arrow Up or Alt+Arrow Down to reorder.'\r\n        \"\r\n        (dragstart)=\"onDragStart($index, $event)\"\r\n        (dragover)=\"onDragOver($index, $event)\"\r\n        (drop)=\"onDrop($index, $event)\"\r\n        (dragend)=\"onDragEnd()\"\r\n        (keydown)=\"onKeydown($index, $event)\"\r\n      >\r\n        <!--\r\n          The grip is `aria-hidden` and has no tab stop: it is an affordance for the pointer, and the\r\n          keyboard equivalent is the two buttons at the end of the row. A focusable grip would add a\r\n          tab stop per field — 24 extra stops — that does nothing when activated.\r\n        -->\r\n        <span aria-hidden=\"true\" class=\"cws:cursor-grab cws:select-none cws:text-slate-400\" title=\"Drag to reorder\">\r\n          ⠿\r\n        </span>\r\n\r\n        <label class=\"cws:flex cws:min-w-0 cws:flex-1 cws:items-center cws:gap-2\">\r\n          <input\r\n            type=\"checkbox\"\r\n            [checked]=\"field.included\"\r\n            (change)=\"onToggle(field.key)\"\r\n          />\r\n          <!--\r\n            `truncate` with the header also in `title`: a long heading must not wrap the row, because\r\n            a variable row height makes the drop indicator land somewhere other than where the pointer\r\n            is.\r\n          -->\r\n          <span class=\"truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" [title]=\"field.header\">\r\n            {{ field.header }}\r\n          </span>\r\n        </label>\r\n\r\n        <span class=\"cws:flex cws:shrink-0 cws:items-center\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-1 cws:text-xs cws:text-slate-500 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\r\n            [disabled]=\"$first\"\r\n            [attr.aria-label]=\"'Move ' + field.header + ' up'\"\r\n            (click)=\"onMove($index, $index - 1)\"\r\n          >\r\n            ▲\r\n          </button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-1 cws:text-xs cws:text-slate-500 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\r\n            [disabled]=\"$last\"\r\n            [attr.aria-label]=\"'Move ' + field.header + ' down'\"\r\n            (click)=\"onMove($index, $index + 1)\"\r\n          >\r\n            ▼\r\n          </button>\r\n        </span>\r\n      </li>\r\n    }\r\n  </ul>\r\n\r\n  @if (!canExport()) {\r\n    <!--\r\n      Stated where the choice was made, rather than as a disabled button with no explanation. An\r\n      export of no fields produces a file of empty lines, which reads as missing data rather than as\r\n      the user's own selection.\r\n    -->\r\n    <p role=\"status\" class=\"cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n      Select at least one field to export.\r\n    </p>\r\n  }\r\n</div>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ExportFieldsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-export-fields",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"cws:flex cws:flex-col cws:gap-2\">\r\n  <!--\r\n    The count is the answer to \"what am I about to get\", and it is stated rather than left to be\r\n    counted off the list — 24 rows is more than anyone tallies by eye, and the whole point of the\r\n    panel is that the file no longer matches the grid.\r\n  -->\r\n  <div class=\"cws:flex cws:items-center cws:justify-between cws:gap-2\">\r\n    <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n      {{ includedCount() }} of {{ total() }} fields\r\n    </span>\r\n\r\n    <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\r\n        [disabled]=\"includedCount() === total()\"\r\n        (click)=\"onSelectAll()\"\r\n      >\r\n        Select all\r\n      </button>\r\n      <span aria-hidden=\"true\" class=\"cws:text-xs cws:text-slate-400\">·</span>\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:text-xs cws:text-scoular-blue cws:underline-offset-2 cws:hover:underline cws:disabled:opacity-40 cws:disabled:no-underline\"\r\n        [disabled]=\"includedCount() === 0\"\r\n        (click)=\"onClearAll()\"\r\n      >\r\n        Clear\r\n      </button>\r\n    </div>\r\n  </div>\r\n\r\n  <!--\r\n    🔴 A LIST, not a table, and `role=\"list\"` is explicit because `list-none` removes the implicit\r\n    one in Safari and VoiceOver. The order is the meaning here, so a screen reader announcing \"list,\r\n    24 items, item 3 of 24\" is carrying the information the drag gesture conveys visually.\r\n\r\n    Capped height with its own scroll: the workspace grid has 24 columns, and a panel that grows to\r\n    fit them pushes its own export buttons off the bottom of the viewport — the one thing the user\r\n    opened it to reach.\r\n  -->\r\n  <!--\r\n    ⚠ **`select-none` is load-bearing here too, and it is the same defect the filter chips had**\r\n    (JFrisbie, 2026-09-14). These rows are `draggable`, and a press inside a TEXT SELECTION makes\r\n    Chrome drag the selection rather than the row -- so once a user has selected anything across\r\n    this list, reordering stops working until the selection is cleared. Measured on the chip row,\r\n    where the same cause could not be dragged out of without reloading the page.\r\n  -->\r\n  <ul\r\n    role=\"list\"\r\n    class=\"cws:max-h-64 cws:select-none cws:overflow-y-auto cws:rounded cws:border cws:border-slate-200 cws:dark:border-slate-700\"\r\n    aria-label=\"Fields to export, in order\"\r\n  >\r\n    @for (field of fields(); track field.key) {\r\n      <li\r\n        class=\"cws:flex cws:items-center cws:gap-2 cws:border-b cws:border-slate-100 cws:px-2 cws:py-1.5 cws:last:border-b-0 cws:dark:border-slate-800\"\r\n        [class.cws:bg-slate-100]=\"draggingIndex() === $index\"\r\n        [class.cws:dark:bg-slate-800]=\"draggingIndex() === $index\"\r\n        [class.cws:border-t-2]=\"dropIndex() === $index && draggingIndex() !== $index\"\r\n        [class.cws:border-t-scoular-blue]=\"dropIndex() === $index && draggingIndex() !== $index\"\r\n        draggable=\"true\"\r\n        tabindex=\"0\"\r\n        [attr.aria-label]=\"\r\n          field.header\r\n            + ', position ' + ($index + 1) + ' of ' + total()\r\n            + (field.included ? ', included' : ', not included')\r\n            + '. Alt+Arrow Up or Alt+Arrow Down to reorder.'\r\n        \"\r\n        (dragstart)=\"onDragStart($index, $event)\"\r\n        (dragover)=\"onDragOver($index, $event)\"\r\n        (drop)=\"onDrop($index, $event)\"\r\n        (dragend)=\"onDragEnd()\"\r\n        (keydown)=\"onKeydown($index, $event)\"\r\n      >\r\n        <!--\r\n          The grip is `aria-hidden` and has no tab stop: it is an affordance for the pointer, and the\r\n          keyboard equivalent is the two buttons at the end of the row. A focusable grip would add a\r\n          tab stop per field — 24 extra stops — that does nothing when activated.\r\n        -->\r\n        <span aria-hidden=\"true\" class=\"cws:cursor-grab cws:select-none cws:text-slate-400\" title=\"Drag to reorder\">\r\n          ⠿\r\n        </span>\r\n\r\n        <label class=\"cws:flex cws:min-w-0 cws:flex-1 cws:items-center cws:gap-2\">\r\n          <input\r\n            type=\"checkbox\"\r\n            [checked]=\"field.included\"\r\n            (change)=\"onToggle(field.key)\"\r\n          />\r\n          <!--\r\n            `truncate` with the header also in `title`: a long heading must not wrap the row, because\r\n            a variable row height makes the drop indicator land somewhere other than where the pointer\r\n            is.\r\n          -->\r\n          <span class=\"truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\" [title]=\"field.header\">\r\n            {{ field.header }}\r\n          </span>\r\n        </label>\r\n\r\n        <span class=\"cws:flex cws:shrink-0 cws:items-center\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-1 cws:text-xs cws:text-slate-500 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\r\n            [disabled]=\"$first\"\r\n            [attr.aria-label]=\"'Move ' + field.header + ' up'\"\r\n            (click)=\"onMove($index, $index - 1)\"\r\n          >\r\n            ▲\r\n          </button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-1 cws:text-xs cws:text-slate-500 cws:hover:text-scoular-blue cws:disabled:opacity-30 cws:disabled:hover:text-slate-500\"\r\n            [disabled]=\"$last\"\r\n            [attr.aria-label]=\"'Move ' + field.header + ' down'\"\r\n            (click)=\"onMove($index, $index + 1)\"\r\n          >\r\n            ▼\r\n          </button>\r\n        </span>\r\n      </li>\r\n    }\r\n  </ul>\r\n\r\n  @if (!canExport()) {\r\n    <!--\r\n      Stated where the choice was made, rather than as a disabled button with no explanation. An\r\n      export of no fields produces a file of empty lines, which reads as missing data rather than as\r\n      the user's own selection.\r\n    -->\r\n    <p role=\"status\" class=\"cws:text-xs cws:text-scoular-red cws:dark:text-scoular-yellow\">\r\n      Select at least one field to export.\r\n    </p>\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		fields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fields",
				required: true
			}]
		}],
		fieldsChange: [{
			type: i0.Output,
			args: ["fieldsChange"]
		}]
	}
});
var PagerComponent = class PagerComponent {
	page = input.required(...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	totalPages = input.required(...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	position = input.required(...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	goTo = output();
	canPrevious = computed(() => this.page() > 1, ...ngDevMode ? [{ debugName: "canPrevious" }] : /* istanbul ignore next */ []);
	canNext = computed(() => this.page() < this.totalPages(), ...ngDevMode ? [{ debugName: "canNext" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: PagerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: PagerComponent,
		isStandalone: true,
		selector: "cms-pager",
		inputs: {
			page: {
				classPropertyName: "page",
				publicName: "page",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			totalPages: {
				classPropertyName: "totalPages",
				publicName: "totalPages",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { goTo: "goTo" },
		ngImport: i0,
		template: `
    <!--
      A nav landmark with a label, because there are two of these on the page: assistive technology
      announces "Pagination, top" and "Pagination, bottom" rather than two identical unnamed regions.
    -->
    <nav class="cws:flex cws:items-center cws:gap-1" [attr.aria-label]="'Pagination ' + position()">
      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="First page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(1)"
      >
        <span aria-hidden="true">&laquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Previous page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(page() - 1)"
      >
        <span aria-hidden="true">&lsaquo;</span>
      </button>

      <!--
        leading-none plus the flex container's items-center is what actually centres this against the
        38px buttons. Left to its own line-height the text sits a pixel or two high, which is the kind
        of misalignment you cannot unsee once noticed.

        aria-live="polite" so a screen reader hears the new position after a page change — the button
        that was activated does not itself announce where you landed.

        (No backticks in this comment on purpose: the template is a template literal, and a backtick
        here terminates it. That cost one broken build.)
      -->
      <span
        class="cws:px-3 cws:text-sm cws:leading-none cws:whitespace-nowrap cws:text-slate-700 cws:dark:text-slate-300"
        aria-live="polite"
      >
        Page {{ page() }} of {{ totalPages() }}
      </span>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Next page"
        [disabled]="!canNext()"
        (click)="goTo.emit(page() + 1)"
      >
        <span aria-hidden="true">&rsaquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Last page"
        [disabled]="!canNext()"
        (click)="goTo.emit(totalPages())"
      >
        <span aria-hidden="true">&raquo;</span>
      </button>
    </nav>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: PagerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-pager",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <!--
      A nav landmark with a label, because there are two of these on the page: assistive technology
      announces "Pagination, top" and "Pagination, bottom" rather than two identical unnamed regions.
    -->
    <nav class="cws:flex cws:items-center cws:gap-1" [attr.aria-label]="'Pagination ' + position()">
      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="First page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(1)"
      >
        <span aria-hidden="true">&laquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Previous page"
        [disabled]="!canPrevious()"
        (click)="goTo.emit(page() - 1)"
      >
        <span aria-hidden="true">&lsaquo;</span>
      </button>

      <!--
        leading-none plus the flex container's items-center is what actually centres this against the
        38px buttons. Left to its own line-height the text sits a pixel or two high, which is the kind
        of misalignment you cannot unsee once noticed.

        aria-live="polite" so a screen reader hears the new position after a page change — the button
        that was activated does not itself announce where you landed.

        (No backticks in this comment on purpose: the template is a template literal, and a backtick
        here terminates it. That cost one broken build.)
      -->
      <span
        class="cws:px-3 cws:text-sm cws:leading-none cws:whitespace-nowrap cws:text-slate-700 cws:dark:text-slate-300"
        aria-live="polite"
      >
        Page {{ page() }} of {{ totalPages() }}
      </span>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Next page"
        [disabled]="!canNext()"
        (click)="goTo.emit(page() + 1)"
      >
        <span aria-hidden="true">&rsaquo;</span>
      </button>

      <button
        type="button"
        class="scoular-btn scoular-btn-secondary"
        aria-label="Last page"
        [disabled]="!canNext()"
        (click)="goTo.emit(totalPages())"
      >
        <span aria-hidden="true">&raquo;</span>
      </button>
    </nav>
  `
		}]
	}],
	propDecorators: {
		page: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "page",
				required: true
			}]
		}],
		totalPages: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "totalPages",
				required: true
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: true
			}]
		}],
		goTo: [{
			type: i0.Output,
			args: ["goTo"]
		}]
	}
});
var DropdownDirective = class DropdownDirective {
	host = inject(ElementRef);
	previouslyFocused = null;
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	toggle() {
		this.open() ? this.close() : this.show();
	}
	show() {
		this.previouslyFocused = document.activeElement;
		this.open.set(true);
	}
	close(restoreFocus = false) {
		if (!this.open()) return;
		this.open.set(false);
		if (restoreFocus) this.previouslyFocused?.focus();
	}
	onDocumentClick(event) {
		if (this.open() && !this.host.nativeElement.contains(event.target)) this.close();
	}
	onEscape(event) {
		if (!this.open()) return;
		this.close(true);
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: DropdownDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: DropdownDirective,
		isStandalone: true,
		selector: "[cmsDropdown]",
		host: { listeners: {
			"document:click": "onDocumentClick($event)",
			"document:keydown.escape": "onEscape($event)"
		} },
		exportAs: ["cmsDropdown"],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: DropdownDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[cmsDropdown]",
			exportAs: "cmsDropdown"
		}]
	}],
	propDecorators: {
		onDocumentClick: [{
			type: HostListener,
			args: ["document:click", ["$event"]]
		}],
		onEscape: [{
			type: HostListener,
			args: ["document:keydown.escape", ["$event"]]
		}]
	}
});
var GridExportComponent = class GridExportComponent {
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	pageRows = input.required(...ngDevMode ? [{ debugName: "pageRows" }] : /* istanbul ignore next */ []);
	totalCount = input.required(...ngDevMode ? [{ debugName: "totalCount" }] : /* istanbul ignore next */ []);
	allRows = input.required(...ngDevMode ? [{ debugName: "allRows" }] : /* istanbul ignore next */ []);
	filename = input.required(...ngDevMode ? [{ debugName: "filename" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	serverExport = input(null, ...ngDevMode ? [{ debugName: "serverExport" }] : /* istanbul ignore next */ []);
	completed = output();
	failed = output();
	scope = signal(null, ...ngDevMode ? [{ debugName: "scope" }] : /* istanbul ignore next */ []);
	fields = signal([], ...ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	canExport = computed(() => includedExportFieldCount(this.fields()) > 0, ...ngDevMode ? [{ debugName: "canExport" }] : /* istanbul ignore next */ []);
	onToggle() {
		this.scope.set(null);
	}
	onPickScope(scope) {
		this.fields.set(exportFieldsFor(this.columns()));
		this.scope.set(scope);
	}
	onBack() {
		this.scope.set(null);
	}
	onFieldsChange(fields) {
		this.fields.set(fields);
	}
	run() {
		const scope = this.scope();
		if (scope === "page") this.exportPage();
		else if (scope === "all") this.exportAll();
	}
	selectedColumns() {
		return applyExportFields(this.columns(), this.fields());
	}
	exportPage() {
		if (!this.canExport()) return;
		this.failed.emit(null);
		downloadCsv(`${this.filename()("page")}.csv`, toCsv(this.selectedColumns(), this.pageRows()));
		this.completed.emit({
			ran: "screen",
			scope: "page",
			rows: this.pageRows().length,
			reason: null
		});
	}
	async exportAll() {
		if (this.busy() || !this.canExport()) return;
		this.busy.set(true);
		this.failed.emit(null);
		try {
			const server = this.serverExport();
			let reason = null;
			if (server !== null) {
				const outcome = await server("all", this.selectedColumns().map((column) => column.key));
				if (outcome.ran === "server") {
					this.completed.emit({
						ran: "server",
						scope: "all",
						rows: this.totalCount(),
						reason: null
					});
					return;
				}
				if (outcome.ran === "failed") {
					this.failed.emit(outcome.message);
					return;
				}
				reason = outcome.reason;
			}
			const rows = await this.allRows()();
			if (rows === null) {
				this.failed.emit("We could not export every page. Nothing was downloaded.");
				return;
			}
			downloadCsv(`${this.filename()("all")}.csv`, toCsv(this.selectedColumns(), rows));
			this.completed.emit({
				ran: "screen",
				scope: "all",
				rows: rows.length,
				reason
			});
		} catch {
			this.failed.emit("The export could not be completed. Nothing was downloaded.");
		} finally {
			this.busy.set(false);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: GridExportComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: GridExportComponent,
		isStandalone: true,
		selector: "cms-grid-export",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			pageRows: {
				classPropertyName: "pageRows",
				publicName: "pageRows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			totalCount: {
				classPropertyName: "totalCount",
				publicName: "totalCount",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			allRows: {
				classPropertyName: "allRows",
				publicName: "allRows",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			filename: {
				classPropertyName: "filename",
				publicName: "filename",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			serverExport: {
				classPropertyName: "serverExport",
				publicName: "serverExport",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			completed: "completed",
			failed: "failed"
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<!--\r\n  🔴 The directive goes on a wrapper that contains BOTH the trigger and the panel, never on the\r\n  button. Its outside-click check is `host.contains(event.target)`, so with the directive on the\r\n  button every click *inside* the panel would read as outside and close it — the field picker would\r\n  shut on its first checkbox.\r\n-->\r\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative\">\r\n  <!--\r\n    The trigger. `scoular-btn-secondary` rather than a size variant, so the box model matches the\r\n    refresh button and the pager beside it: all three are `px-4 py-2 text-sm` with a 1px border,\r\n    which is what keeps them the same height without a hard-coded pixel value that would drift when\r\n    the design system changes its own padding.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"scoular-btn scoular-btn-secondary\"\r\n    [disabled]=\"disabled() || busy()\"\r\n    [attr.aria-expanded]=\"menu.open()\"\r\n    aria-haspopup=\"menu\"\r\n    (click)=\"menu.toggle(); onToggle()\"\r\n  >\r\n    <!--\r\n      An inline SVG rather than a glyph: the arrow-out-of-tray mark is the conventional \"export\"\r\n      icon and no single Unicode character carries it. `currentColor` so it inherits the button's\r\n      text colour in both themes, and aria-hidden because the button already says what it does.\r\n    -->\r\n    <svg\r\n      aria-hidden=\"true\"\r\n      viewBox=\"0 0 24 24\"\r\n      fill=\"none\"\r\n      stroke=\"currentColor\"\r\n      stroke-width=\"2\"\r\n      stroke-linecap=\"round\"\r\n      stroke-linejoin=\"round\"\r\n      class=\"cws:size-4 cws:shrink-0\"\r\n    >\r\n      <path d=\"M12 15V3\" />\r\n      <path d=\"m8 7 4-4 4 4\" />\r\n      <path d=\"M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4\" />\r\n    </svg>\r\n    {{ busy() ? 'Exporting…' : 'Export data' }}\r\n    <span aria-hidden=\"true\" class=\"cws:text-xs\">{{ menu.open() ? '▲' : '▼' }}</span>\r\n  </button>\r\n\r\n  @if (menu.open()) {\r\n    <!--\r\n      🔴 A GROUP, not a `role=\"menu\"`, and the change is required rather than cosmetic. A menu's\r\n      children must be `menuitem`s, and the second step holds checkboxes, reorder buttons and\r\n      draggable rows — announcing those as menu items tells a screen-reader user they are about to\r\n      activate a command when they are about to toggle a field. The export actions are still\r\n      buttons; they simply are not menu items any more.\r\n\r\n      ⚠ The role stays `group` on BOTH steps even though step one is only two buttons and would\r\n      qualify as a menu. Switching role with the step would change what a screen reader announces\r\n      part-way through one gesture, which is worse than the slightly loose fit.\r\n    -->\r\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\" role=\"group\" aria-label=\"Export\">\r\n      @if (scope() === null) {\r\n        <div class=\"scoular-dropdown-header\">Export as CSV</div>\r\n\r\n        <!--\r\n          🔴 SCOPE FIRST, fields second. The two scopes differ by orders of magnitude in cost on the\r\n          workspace — the current page is already in memory, every page is one CTRM read per 200\r\n          rows — so that is the choice every export has to make, and it is asked on its own. The\r\n          field picker is a refinement most exports do not need, and putting it first made every\r\n          export pay for it.\r\n\r\n          The row counts stay in the labels: the choice is made with the numbers visible.\r\n        -->\r\n        <!--\r\n          `text-left` on the item is load-bearing. `.scoular-dropdown-item` is a `<button>`, and a\r\n          button inherits `text-align: center` — so a subtext short enough to fit looked fine while\r\n          the longer one *wrapped* and centred its second line. `items-start` does not fix that: it\r\n          aligns the flex children, not the text inside a child that wraps.\r\n        -->\r\n        <button type=\"button\" class=\"scoular-dropdown-item cws:text-left\" (click)=\"onPickScope('page')\">\r\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n            <span>This page</span>\r\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              {{ pageRows().length }} rows, as sorted on screen\r\n            </span>\r\n          </span>\r\n        </button>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-dropdown-item cws:text-left\"\r\n          [disabled]=\"busy()\"\r\n          (click)=\"onPickScope('all')\"\r\n        >\r\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n            <span>All pages</span>\r\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              {{ totalCount() }} rows — every row this filter matches\r\n            </span>\r\n          </span>\r\n        </button>\r\n      } @else {\r\n        <!--\r\n          ⚠ The header names the scope rather than repeating \"Export as CSV\". Once the field list is\r\n          on screen it is the only thing saying which of the two exports is about to run, and the two\r\n          differ by every row in the result set.\r\n        -->\r\n        <div class=\"scoular-dropdown-header cws:flex cws:items-center cws:gap-2\">\r\n          <!--\r\n            Back rather than only Escape: Escape closes the whole panel, which throws away the scope\r\n            AND the fields. A wrong pick must not cost the gesture.\r\n          -->\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:shrink-0 cws:text-scoular-blue cws:hover:underline\"\r\n            aria-label=\"Back to choosing what to export\"\r\n            (click)=\"onBack()\"\r\n          >\r\n            ‹\r\n          </button>\r\n          <span class=\"truncate\">{{ scope() === 'page' ? 'This page' : 'All pages' }}</span>\r\n        </div>\r\n\r\n        <div class=\"cws:px-3 cws:py-2\">\r\n          <cms-export-fields [fields]=\"fields()\" (fieldsChange)=\"onFieldsChange($event)\" />\r\n        </div>\r\n\r\n        <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n        <!--\r\n          The confirm, and the only place the export actually runs. `canExport()` gates it here\r\n          rather than on the scope buttons: at scope-choosing time every field is ticked by\r\n          construction, so a disabled scope button could only ever confuse.\r\n        -->\r\n        <div class=\"cws:px-3 cws:pb-2 cws:pt-1\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"scoular-btn scoular-btn-primary cws:w-full cws:justify-center\"\r\n            [disabled]=\"!canExport() || busy()\"\r\n            (click)=\"menu.close(); run()\"\r\n          >\r\n            {{\r\n              scope() === 'page'\r\n                ? 'Export ' + pageRows().length + ' rows'\r\n                : 'Export ' + totalCount() + ' rows'\r\n            }}\r\n          </button>\r\n        </div>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
		dependencies: [{
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}, {
			kind: "component",
			type: ExportFieldsComponent,
			selector: "cms-export-fields",
			inputs: ["fields"],
			outputs: ["fieldsChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: GridExportComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-grid-export",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownDirective, ExportFieldsComponent],
			host: { class: "cws:block" },
			template: "<!--\r\n  🔴 The directive goes on a wrapper that contains BOTH the trigger and the panel, never on the\r\n  button. Its outside-click check is `host.contains(event.target)`, so with the directive on the\r\n  button every click *inside* the panel would read as outside and close it — the field picker would\r\n  shut on its first checkbox.\r\n-->\r\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative\">\r\n  <!--\r\n    The trigger. `scoular-btn-secondary` rather than a size variant, so the box model matches the\r\n    refresh button and the pager beside it: all three are `px-4 py-2 text-sm` with a 1px border,\r\n    which is what keeps them the same height without a hard-coded pixel value that would drift when\r\n    the design system changes its own padding.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"scoular-btn scoular-btn-secondary\"\r\n    [disabled]=\"disabled() || busy()\"\r\n    [attr.aria-expanded]=\"menu.open()\"\r\n    aria-haspopup=\"menu\"\r\n    (click)=\"menu.toggle(); onToggle()\"\r\n  >\r\n    <!--\r\n      An inline SVG rather than a glyph: the arrow-out-of-tray mark is the conventional \"export\"\r\n      icon and no single Unicode character carries it. `currentColor` so it inherits the button's\r\n      text colour in both themes, and aria-hidden because the button already says what it does.\r\n    -->\r\n    <svg\r\n      aria-hidden=\"true\"\r\n      viewBox=\"0 0 24 24\"\r\n      fill=\"none\"\r\n      stroke=\"currentColor\"\r\n      stroke-width=\"2\"\r\n      stroke-linecap=\"round\"\r\n      stroke-linejoin=\"round\"\r\n      class=\"cws:size-4 cws:shrink-0\"\r\n    >\r\n      <path d=\"M12 15V3\" />\r\n      <path d=\"m8 7 4-4 4 4\" />\r\n      <path d=\"M3 15v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4\" />\r\n    </svg>\r\n    {{ busy() ? 'Exporting…' : 'Export data' }}\r\n    <span aria-hidden=\"true\" class=\"cws:text-xs\">{{ menu.open() ? '▲' : '▼' }}</span>\r\n  </button>\r\n\r\n  @if (menu.open()) {\r\n    <!--\r\n      🔴 A GROUP, not a `role=\"menu\"`, and the change is required rather than cosmetic. A menu's\r\n      children must be `menuitem`s, and the second step holds checkboxes, reorder buttons and\r\n      draggable rows — announcing those as menu items tells a screen-reader user they are about to\r\n      activate a command when they are about to toggle a field. The export actions are still\r\n      buttons; they simply are not menu items any more.\r\n\r\n      ⚠ The role stays `group` on BOTH steps even though step one is only two buttons and would\r\n      qualify as a menu. Switching role with the step would change what a screen reader announces\r\n      part-way through one gesture, which is worse than the slightly loose fit.\r\n    -->\r\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-80\" role=\"group\" aria-label=\"Export\">\r\n      @if (scope() === null) {\r\n        <div class=\"scoular-dropdown-header\">Export as CSV</div>\r\n\r\n        <!--\r\n          🔴 SCOPE FIRST, fields second. The two scopes differ by orders of magnitude in cost on the\r\n          workspace — the current page is already in memory, every page is one CTRM read per 200\r\n          rows — so that is the choice every export has to make, and it is asked on its own. The\r\n          field picker is a refinement most exports do not need, and putting it first made every\r\n          export pay for it.\r\n\r\n          The row counts stay in the labels: the choice is made with the numbers visible.\r\n        -->\r\n        <!--\r\n          `text-left` on the item is load-bearing. `.scoular-dropdown-item` is a `<button>`, and a\r\n          button inherits `text-align: center` — so a subtext short enough to fit looked fine while\r\n          the longer one *wrapped* and centred its second line. `items-start` does not fix that: it\r\n          aligns the flex children, not the text inside a child that wraps.\r\n        -->\r\n        <button type=\"button\" class=\"scoular-dropdown-item cws:text-left\" (click)=\"onPickScope('page')\">\r\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n            <span>This page</span>\r\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              {{ pageRows().length }} rows, as sorted on screen\r\n            </span>\r\n          </span>\r\n        </button>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-dropdown-item cws:text-left\"\r\n          [disabled]=\"busy()\"\r\n          (click)=\"onPickScope('all')\"\r\n        >\r\n          <span class=\"cws:flex cws:flex-col cws:items-start cws:text-left\">\r\n            <span>All pages</span>\r\n            <span class=\"cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n              {{ totalCount() }} rows — every row this filter matches\r\n            </span>\r\n          </span>\r\n        </button>\r\n      } @else {\r\n        <!--\r\n          ⚠ The header names the scope rather than repeating \"Export as CSV\". Once the field list is\r\n          on screen it is the only thing saying which of the two exports is about to run, and the two\r\n          differ by every row in the result set.\r\n        -->\r\n        <div class=\"scoular-dropdown-header cws:flex cws:items-center cws:gap-2\">\r\n          <!--\r\n            Back rather than only Escape: Escape closes the whole panel, which throws away the scope\r\n            AND the fields. A wrong pick must not cost the gesture.\r\n          -->\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:shrink-0 cws:text-scoular-blue cws:hover:underline\"\r\n            aria-label=\"Back to choosing what to export\"\r\n            (click)=\"onBack()\"\r\n          >\r\n            ‹\r\n          </button>\r\n          <span class=\"truncate\">{{ scope() === 'page' ? 'This page' : 'All pages' }}</span>\r\n        </div>\r\n\r\n        <div class=\"cws:px-3 cws:py-2\">\r\n          <cms-export-fields [fields]=\"fields()\" (fieldsChange)=\"onFieldsChange($event)\" />\r\n        </div>\r\n\r\n        <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n        <!--\r\n          The confirm, and the only place the export actually runs. `canExport()` gates it here\r\n          rather than on the scope buttons: at scope-choosing time every field is ticked by\r\n          construction, so a disabled scope button could only ever confuse.\r\n        -->\r\n        <div class=\"cws:px-3 cws:pb-2 cws:pt-1\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"scoular-btn scoular-btn-primary cws:w-full cws:justify-center\"\r\n            [disabled]=\"!canExport() || busy()\"\r\n            (click)=\"menu.close(); run()\"\r\n          >\r\n            {{\r\n              scope() === 'page'\r\n                ? 'Export ' + pageRows().length + ' rows'\r\n                : 'Export ' + totalCount() + ' rows'\r\n            }}\r\n          </button>\r\n        </div>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		pageRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageRows",
				required: true
			}]
		}],
		totalCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "totalCount",
				required: true
			}]
		}],
		allRows: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "allRows",
				required: true
			}]
		}],
		filename: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filename",
				required: true
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		serverExport: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "serverExport",
				required: false
			}]
		}],
		completed: [{
			type: i0.Output,
			args: ["completed"]
		}],
		failed: [{
			type: i0.Output,
			args: ["failed"]
		}]
	}
});
const SCOPE_RANK = {
	shell: 0,
	feature: 1,
	control: 2,
	dialog: 3
};
function scopeRank(scope) {
	return SCOPE_RANK[scope];
}
function defaultGroup(scope) {
	switch (scope) {
		case "shell": return "Navigation";
		case "feature": return "This screen";
		case "control": return "The control you are in";
		case "dialog": return "This dialog";
	}
}
function formatShortcut(keys) {
	return keys.split("+").map((part) => {
		switch (part) {
			case "ctrl": return "Ctrl";
			case "alt": return "Alt";
			case "shift": return "Shift";
			case "pagedown": return "Page Down";
			case "pageup": return "Page Up";
			case "escape": return "Esc";
			case "enter": return "Enter";
			case "space": return "Space";
			default: return part.length === 1 ? part.toUpperCase() : part.replace(/^f(\d+)$/, "F$1");
		}
	}).join(" + ");
}
function ariaKeyShortcuts(keys) {
	return keys.split("+").map((part) => {
		switch (part) {
			case "ctrl": return "Control";
			case "alt": return "Alt";
			case "shift": return "Shift";
			default: return part.length === 1 ? part.toUpperCase() : part.replace(/^f(\d+)$/, "F$1");
		}
	}).join("+");
}
function shortcutTokens(event) {
	const modifiers = [];
	if (event.ctrlKey || event.metaKey) modifiers.push("ctrl");
	if (event.altKey) modifiers.push("alt");
	const names = /* @__PURE__ */ new Set();
	const fromKey = normaliseKeyName(event.key);
	if (fromKey !== null) names.add(fromKey);
	const fromCode = normaliseCodeName(event.code);
	if (fromCode !== null) names.add(fromCode);
	const shiftVariants = event.shiftKey ? ["shift", null] : [null];
	const tokens = [];
	for (const name of names) for (const shift of shiftVariants) tokens.push([
		...modifiers,
		...shift === null ? [] : [shift],
		name
	].join("+"));
	return tokens;
}
function normaliseKeyName(key) {
	if (key === "" || key === "Control" || key === "Alt" || key === "Shift" || key === "Meta") return null;
	return key === " " ? "space" : key.toLowerCase();
}
function normaliseCodeName(code) {
	const letter = /^Key([A-Z])$/.exec(code);
	if (letter !== null) return letter[1].toLowerCase();
	const digit = /^Digit([0-9])$/.exec(code);
	return digit === null ? null : digit[1];
}
function isTextEditable(target) {
	const element = target;
	if (element === null || typeof element.tagName !== "string") return false;
	if (element.isContentEditable) return true;
	if (element.tagName === "TEXTAREA") return true;
	if (element.tagName !== "INPUT") return false;
	const type = element.type;
	return ![
		"button",
		"checkbox",
		"color",
		"file",
		"image",
		"radio",
		"range",
		"reset",
		"submit"
	].includes(type);
}
var ShortcutRegistry = class ShortcutRegistry {
	registrations = signal([], ...ngDevMode ? [{ debugName: "registrations" }] : /* istanbul ignore next */ []);
	sequence = 0;
	visible = computed(() => this.registrations().filter((entry) => entry.binding.available?.() ?? true), ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	constructor() {
		document.addEventListener("keydown", this.onKeydown);
		inject(DestroyRef).onDestroy(() => {
			document.removeEventListener("keydown", this.onKeydown);
		});
	}
	register(bindings) {
		const added = bindings.map((binding) => {
			this.sequence += 1;
			return {
				binding,
				sequence: this.sequence
			};
		});
		if (isDevMode()) {
			const existing = this.registrations();
			for (const entry of added) {
				const clash = existing.find((other) => other.binding.keys === entry.binding.keys && other.binding.scope === entry.binding.scope);
				if (clash !== void 0) throw new Error(`Shortcut "${entry.binding.keys}" is already registered at scope "${entry.binding.scope}" ("${clash.binding.label}"). Two meanings for one key is the defect this registry exists to prevent — pick a different key, or a different scope if one genuinely outranks the other.`);
			}
		}
		this.registrations.update((current) => [...current, ...added]);
		return () => {
			this.registrations.update((current) => current.filter((entry) => !added.includes(entry)));
		};
	}
	onKeydown = (event) => {
		if (event.defaultPrevented) return;
		const tokens = shortcutTokens(event);
		const editable = isTextEditable(event.target);
		let best = null;
		for (const entry of this.registrations()) {
			const binding = entry.binding;
			if (binding.run === void 0) continue;
			if (!tokens.includes(binding.keys)) continue;
			if (editable && binding.allowInTextInput !== true) continue;
			if (!(binding.available?.() ?? true)) continue;
			if (!targetsWithin(event.target, binding.within?.())) continue;
			if (best === null || rank(entry) > rank(best)) best = entry;
		}
		if (best === null) return;
		event.preventDefault();
		best.binding.run?.(event);
	};
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ShortcutRegistry,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ShortcutRegistry,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ShortcutRegistry,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
function targetsWithin(target, root) {
	if (root === void 0 || root === null || !(target instanceof Element)) return true;
	const document = target.ownerDocument;
	return target === document.body || target === document.documentElement || root.contains(target);
}
function rank(entry) {
	return scopeRank(entry.binding.scope) * 1e6 + entry.sequence;
}
function registerShortcuts(bindings) {
	const disposer = inject(ShortcutRegistry).register(bindings);
	inject(DestroyRef).onDestroy(disposer);
}
var ShortcutOverlayComponent = class ShortcutOverlayComponent {
	registry = inject(ShortcutRegistry);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	constructor() {
		registerShortcuts([
			{
				keys: "?",
				scope: "shell",
				label: "Show this list of keys",
				group: "Help",
				run: () => this.toggle()
			},
			{
				keys: "f1",
				scope: "shell",
				label: "Show this list of keys",
				group: "Help",
				run: () => this.toggle()
			},
			{
				keys: "escape",
				scope: "dialog",
				label: "Close this list",
				group: "Help",
				available: () => this.open(),
				run: () => this.open.set(false)
			},
			{
				keys: "escape",
				scope: "shell",
				label: "Go back without saving",
				group: "Navigation",
				note: "F12 on the green screen"
			}
		]);
	}
	toggle() {
		this.open.update((value) => !value);
	}
	groups = computed(() => {
		const byHeading = /* @__PURE__ */ new Map();
		for (const entry of this.registry.visible()) {
			const binding = entry.binding;
			const heading = binding.group ?? defaultGroup(binding.scope);
			const rows = byHeading.get(heading) ?? [];
			rows.push({
				keys: formatShortcut(binding.keys),
				label: binding.label,
				note: binding.note ?? null
			});
			byHeading.set(heading, rows);
		}
		return [...byHeading.entries()].map(([heading, rows]) => ({
			heading,
			rows
		}));
	}, ...ngDevMode ? [{ debugName: "groups" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ShortcutOverlayComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ShortcutOverlayComponent,
		isStandalone: true,
		selector: "cms-shortcut-overlay",
		host: { classAttribute: "cws:contents" },
		ngImport: i0,
		template: "@if (open()) {\r\n  <!--\r\n    A modal panel over a scrim. `role=\"dialog\"` with `aria-modal` so a screen reader treats it as one,\r\n    and the scrim is a plain div rather than a button: a click anywhere dismisses it, which is what the\r\n    overlay's own Escape binding does, and an interactive element there would land in the tab order\r\n    ahead of the content it covers.\r\n  -->\r\n  <div\r\n    class=\"cws:fixed cws:inset-0 cws:z-50 cws:flex cws:items-start cws:justify-center cws:overflow-y-auto cws:bg-slate-900/40 cws:p-4 cws:pt-16\"\r\n    (click)=\"open.set(false)\"\r\n  >\r\n    <!--\r\n      ⚠ `stopPropagation` so a click inside the panel does not dismiss it — the same shape as the\r\n      export panel's wrapper, for the same reason.\r\n    -->\r\n    <div\r\n      role=\"dialog\"\r\n      aria-modal=\"true\"\r\n      aria-labelledby=\"cms-shortcut-overlay-title\"\r\n      class=\"scoular-card cws:w-full cws:max-w-2xl cws:p-6\"\r\n      (click)=\"$event.stopPropagation()\"\r\n    >\r\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\r\n        <div>\r\n          <h2\r\n            id=\"cms-shortcut-overlay-title\"\r\n            class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\"\r\n          >\r\n            Keyboard shortcuts\r\n          </h2>\r\n\r\n          <!--\r\n            🔴 Names the green screen explicitly. The population this is for has spent years on\r\n            CTRM's 5250 screens, and the single most useful sentence in this panel is the one that\r\n            says which of their four reliable keys still works and what replaced the rest.\r\n          -->\r\n          <p class=\"cws:mt-1 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Press <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">?</kbd> or <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">F1</kbd> to open this at any\r\n            time. Keys are listed only while they apply.\r\n          </p>\r\n        </div>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\r\n          (click)=\"open.set(false)\"\r\n        >\r\n          Close\r\n        </button>\r\n      </div>\r\n\r\n      <div class=\"cws:mt-5 cws:flex cws:flex-col cws:gap-5\">\r\n        @for (group of groups(); track group.heading) {\r\n          <section>\r\n            <h3\r\n              class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\"\r\n            >\r\n              {{ group.heading }}\r\n            </h3>\r\n\r\n            <dl class=\"cws:mt-2 cws:flex cws:flex-col cws:gap-1\">\r\n              @for (row of group.rows; track row.keys + row.label) {\r\n                <div class=\"cws:flex cws:items-baseline cws:gap-3 cws:text-sm\">\r\n                  <dt class=\"cws:w-40 cws:shrink-0\">\r\n                    <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ row.keys }}</kbd>\r\n                  </dt>\r\n\r\n                  <dd class=\"cws:text-slate-700 cws:dark:text-slate-200\">\r\n                    {{ row.label }}\r\n\r\n                    @if (row.note) {\r\n                      <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ row.note }})</span>\r\n                    }\r\n                  </dd>\r\n                </div>\r\n              }\r\n            </dl>\r\n          </section>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n}\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ShortcutOverlayComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-shortcut-overlay",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:contents" },
			template: "@if (open()) {\r\n  <!--\r\n    A modal panel over a scrim. `role=\"dialog\"` with `aria-modal` so a screen reader treats it as one,\r\n    and the scrim is a plain div rather than a button: a click anywhere dismisses it, which is what the\r\n    overlay's own Escape binding does, and an interactive element there would land in the tab order\r\n    ahead of the content it covers.\r\n  -->\r\n  <div\r\n    class=\"cws:fixed cws:inset-0 cws:z-50 cws:flex cws:items-start cws:justify-center cws:overflow-y-auto cws:bg-slate-900/40 cws:p-4 cws:pt-16\"\r\n    (click)=\"open.set(false)\"\r\n  >\r\n    <!--\r\n      ⚠ `stopPropagation` so a click inside the panel does not dismiss it — the same shape as the\r\n      export panel's wrapper, for the same reason.\r\n    -->\r\n    <div\r\n      role=\"dialog\"\r\n      aria-modal=\"true\"\r\n      aria-labelledby=\"cms-shortcut-overlay-title\"\r\n      class=\"scoular-card cws:w-full cws:max-w-2xl cws:p-6\"\r\n      (click)=\"$event.stopPropagation()\"\r\n    >\r\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\r\n        <div>\r\n          <h2\r\n            id=\"cms-shortcut-overlay-title\"\r\n            class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\"\r\n          >\r\n            Keyboard shortcuts\r\n          </h2>\r\n\r\n          <!--\r\n            🔴 Names the green screen explicitly. The population this is for has spent years on\r\n            CTRM's 5250 screens, and the single most useful sentence in this panel is the one that\r\n            says which of their four reliable keys still works and what replaced the rest.\r\n          -->\r\n          <p class=\"cws:mt-1 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n            Press <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">?</kbd> or <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">F1</kbd> to open this at any\r\n            time. Keys are listed only while they apply.\r\n          </p>\r\n        </div>\r\n\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-secondary cws:shrink-0\"\r\n          (click)=\"open.set(false)\"\r\n        >\r\n          Close\r\n        </button>\r\n      </div>\r\n\r\n      <div class=\"cws:mt-5 cws:flex cws:flex-col cws:gap-5\">\r\n        @for (group of groups(); track group.heading) {\r\n          <section>\r\n            <h3\r\n              class=\"cws:text-xs cws:font-semibold cws:uppercase cws:tracking-wide cws:text-slate-500 cws:dark:text-slate-400\"\r\n            >\r\n              {{ group.heading }}\r\n            </h3>\r\n\r\n            <dl class=\"cws:mt-2 cws:flex cws:flex-col cws:gap-1\">\r\n              @for (row of group.rows; track row.keys + row.label) {\r\n                <div class=\"cws:flex cws:items-baseline cws:gap-3 cws:text-sm\">\r\n                  <dt class=\"cws:w-40 cws:shrink-0\">\r\n                    <kbd class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:font-mono cws:text-xs cws:text-slate-700 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-200\">{{ row.keys }}</kbd>\r\n                  </dt>\r\n\r\n                  <dd class=\"cws:text-slate-700 cws:dark:text-slate-200\">\r\n                    {{ row.label }}\r\n\r\n                    @if (row.note) {\r\n                      <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">({{ row.note }})</span>\r\n                    }\r\n                  </dd>\r\n                </div>\r\n              }\r\n            </dl>\r\n          </section>\r\n        }\r\n      </div>\r\n    </div>\r\n  </div>\r\n}\r\n"
		}]
	}],
	ctorParameters: () => []
});
var ShortcutHintsComponent = class ShortcutHintsComponent {
	registry = inject(ShortcutRegistry);
	hints = computed(() => [...this.registry.visible()].sort((left, right) => scopeWeight(right) - scopeWeight(left)).slice(0, 6).map((entry) => ({
		keys: formatShortcut(entry.binding.keys),
		label: entry.binding.label
	})), ...ngDevMode ? [{ debugName: "hints" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ShortcutHintsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ShortcutHintsComponent,
		isStandalone: true,
		selector: "cms-shortcut-hints",
		host: { classAttribute: "cws:sticky cws:bottom-0 cws:z-30 cws:block" },
		ngImport: i0,
		template: "<!--\r\n  ⚠ `aria-hidden`, deliberately. Every key here is already announced by the control it belongs to\r\n  through `aria-keyshortcuts`, and the overlay lists them all in a structure a screen reader can\r\n  navigate — so reading this strip out on every page is duplication rather than access.\r\n\r\n  ⚠ Rendered as an empty bar when nothing is registered rather than hidden, so the chrome does not\r\n  change height as a user moves between screens.\r\n-->\r\n<div\r\n  aria-hidden=\"true\"\r\n  class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-x-4 cws:gap-y-1 cws:border-t cws:border-slate-200 cws:bg-slate-50 cws:px-4 cws:py-1.5 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-400\"\r\n>\r\n  @for (hint of hints(); track hint.keys + hint.label) {\r\n    <span class=\"cws:flex cws:items-center cws:gap-1.5\">\r\n      <kbd\r\n        class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:px-1 cws:py-0.5 cws:font-mono cws:text-[11px] cws:text-slate-600 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n        >{{ hint.keys }}</kbd\r\n      >\r\n      {{ hint.label }}\r\n    </span>\r\n  }\r\n</div>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ShortcutHintsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-shortcut-hints",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:sticky cws:bottom-0 cws:z-30 cws:block" },
			template: "<!--\r\n  ⚠ `aria-hidden`, deliberately. Every key here is already announced by the control it belongs to\r\n  through `aria-keyshortcuts`, and the overlay lists them all in a structure a screen reader can\r\n  navigate — so reading this strip out on every page is duplication rather than access.\r\n\r\n  ⚠ Rendered as an empty bar when nothing is registered rather than hidden, so the chrome does not\r\n  change height as a user moves between screens.\r\n-->\r\n<div\r\n  aria-hidden=\"true\"\r\n  class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-x-4 cws:gap-y-1 cws:border-t cws:border-slate-200 cws:bg-slate-50 cws:px-4 cws:py-1.5 cws:text-xs cws:text-slate-500 cws:dark:border-slate-700 cws:dark:bg-slate-800 cws:dark:text-slate-400\"\r\n>\r\n  @for (hint of hints(); track hint.keys + hint.label) {\r\n    <span class=\"cws:flex cws:items-center cws:gap-1.5\">\r\n      <kbd\r\n        class=\"cws:rounded cws:border cws:border-slate-300 cws:bg-white cws:px-1 cws:py-0.5 cws:font-mono cws:text-[11px] cws:text-slate-600 cws:dark:border-slate-600 cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n        >{{ hint.keys }}</kbd\r\n      >\r\n      {{ hint.label }}\r\n    </span>\r\n  }\r\n</div>\r\n"
		}]
	}]
});
function scopeWeight(entry) {
	switch (entry.binding.scope) {
		case "dialog": return 3;
		case "feature": return 2;
		case "control": return 1;
		default: return 0;
	}
}
var SearchShortcutDirective = class SearchShortcutDirective {
	host = inject(ElementRef);
	constructor() {
		registerShortcuts([{
			keys: "/",
			scope: "feature",
			label: "Search this grid",
			group: "Grids",
			run: () => {
				const input = this.host.nativeElement;
				input.focus();
				input.select();
			}
		}]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SearchShortcutDirective,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: SearchShortcutDirective,
		isStandalone: true,
		selector: "input[cmsSearchShortcut]",
		host: { properties: { "attr.aria-keyshortcuts": "\"/\"" } },
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SearchShortcutDirective,
	decorators: [{
		type: Directive,
		args: [{
			selector: "input[cmsSearchShortcut]",
			host: { "[attr.aria-keyshortcuts]": "\"/\"" }
		}]
	}],
	ctorParameters: () => []
});
var GridToolbarComponent = class GridToolbarComponent {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: GridToolbarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: GridToolbarComponent,
		isStandalone: true,
		selector: "cms-grid-toolbar",
		host: { classAttribute: "scoular-card cws:flex cws:flex-wrap cws:items-end cws:gap-2 cws:p-3" },
		ngImport: i0,
		template: "<ng-content />",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: GridToolbarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-grid-toolbar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<ng-content />",
			host: { class: "scoular-card cws:flex cws:flex-wrap cws:items-end cws:gap-2 cws:p-3" }
		}]
	}]
});
var RefreshButtonComponent = class RefreshButtonComponent {
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	busy = input(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	refresh = output();
	isDisabled = computed(() => this.busy() || this.disabled(), ...ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RefreshButtonComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: RefreshButtonComponent,
		isStandalone: true,
		selector: "cms-refresh-button",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			busy: {
				classPropertyName: "busy",
				publicName: "busy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { refresh: "refresh" },
		ngImport: i0,
		template: `
    <button
      type="button"
      class="scoular-btn scoular-btn-secondary"
      [attr.aria-label]="label()"
      [attr.title]="label()"
      [attr.aria-busy]="busy() ? 'true' : null"
      [disabled]="isDisabled()"
      (click)="refresh.emit()"
    >
      <!--
        The 20px line box the button's missing text would have had — see the class remarks. The icon
        itself stays 16px, so it matches the Export data mark beside it rather than growing to fill.
      -->
      <span class="cws:flex cws:h-5 cws:items-center" aria-hidden="true">
        <!--
          Two arcs with their arrowheads: the conventional "refresh" mark, and no single Unicode
          character carries it (U+21BB is a single arc and renders at wildly different weights across
          fonts). Stroked in currentColor so it inherits the button's text colour in both themes.

          It spins while a refresh is in flight. That is the only feedback this control gives — the
          screen's own loading state is what says the data is coming — and it is why aria-busy is set
          rather than the label changing: a label that becomes "Refreshing…" on an icon-only button is
          announced but invisible.

          (No backticks anywhere in this template. It is a template literal, so one would end it —
          the same warning the pager carries, and this component walked into it on the first build.)
        -->
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          class="cws:size-4 cws:shrink-0"
          [class.animate-spin]="busy()"
        >
          <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
          <path d="M21 3v5h-5" />
          <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
          <path d="M8 16H3v5" />
        </svg>
      </span>
    </button>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RefreshButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-refresh-button",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button
      type="button"
      class="scoular-btn scoular-btn-secondary"
      [attr.aria-label]="label()"
      [attr.title]="label()"
      [attr.aria-busy]="busy() ? 'true' : null"
      [disabled]="isDisabled()"
      (click)="refresh.emit()"
    >
      <!--
        The 20px line box the button's missing text would have had — see the class remarks. The icon
        itself stays 16px, so it matches the Export data mark beside it rather than growing to fill.
      -->
      <span class="cws:flex cws:h-5 cws:items-center" aria-hidden="true">
        <!--
          Two arcs with their arrowheads: the conventional "refresh" mark, and no single Unicode
          character carries it (U+21BB is a single arc and renders at wildly different weights across
          fonts). Stroked in currentColor so it inherits the button's text colour in both themes.

          It spins while a refresh is in flight. That is the only feedback this control gives — the
          screen's own loading state is what says the data is coming — and it is why aria-busy is set
          rather than the label changing: a label that becomes "Refreshing…" on an icon-only button is
          announced but invisible.

          (No backticks anywhere in this template. It is a template literal, so one would end it —
          the same warning the pager carries, and this component walked into it on the first build.)
        -->
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          class="cws:size-4 cws:shrink-0"
          [class.animate-spin]="busy()"
        >
          <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
          <path d="M21 3v5h-5" />
          <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
          <path d="M8 16H3v5" />
        </svg>
      </span>
    </button>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		busy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "busy",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		refresh: [{
			type: i0.Output,
			args: ["refresh"]
		}]
	}
});
var ClearSortButtonComponent = class ClearSortButtonComponent {
	sorts = input.required(...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	defaultSorts = input([], ...ngDevMode ? [{ debugName: "defaultSorts" }] : /* istanbul ignore next */ []);
	clear = output();
	visible = computed(() => !this.same(this.sorts(), this.defaultSorts()), ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	hint = computed(() => this.defaultSorts().length === 0 ? "Remove the sort and return to the order the rows arrived in" : "Return to this queue's default order", ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	same(left, right) {
		return left.length === right.length && left.every((sort, index) => sort.key === right[index]?.key && sort.direction === right[index]?.direction);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ClearSortButtonComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: ClearSortButtonComponent,
		isStandalone: true,
		selector: "cms-clear-sort-button",
		inputs: {
			sorts: {
				classPropertyName: "sorts",
				publicName: "sorts",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			defaultSorts: {
				classPropertyName: "defaultSorts",
				publicName: "defaultSorts",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { clear: "clear" },
		ngImport: i0,
		template: `
    @if (visible()) {
      <button
        type="button"
        class="scoular-btn scoular-btn-outline"
        [attr.title]="hint()"
        (click)="clear.emit(defaultSorts())"
      >
        <!--
          The same double arrow the grid puts on an unsorted header, so the button shows the state it
          returns you to. aria-hidden because the label already says it.
        -->
        <span aria-hidden="true">&#8645;</span>
        Clear sort
        @if (sorts().length > 1) {
          <!--
            🔴 The h-5 rides on the shared badge rather than being replaced by it. The tone classes
            come from cms-status-badge; the height is this button's own, and is why the badge does
            not make it 2px taller than its neighbours - see the class docstring. Angular merges a
            consumer class with the component's host binding, and the primitive has a test for it.

            ⚠ No backticks in this comment, deliberately: an inline template IS a template literal,
            so one would end it. That is Known Issue 37, and it cost a build on the way in here.
          -->
          <cms-status-badge tone="info" [small]="true" class="cws:h-5">
            {{ sorts().length }}
          </cms-status-badge>
        }
      </button>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: StatusBadgeComponent,
			selector: "cms-status-badge",
			inputs: ["tone", "small"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ClearSortButtonComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-clear-sort-button",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [StatusBadgeComponent],
			template: `
    @if (visible()) {
      <button
        type="button"
        class="scoular-btn scoular-btn-outline"
        [attr.title]="hint()"
        (click)="clear.emit(defaultSorts())"
      >
        <!--
          The same double arrow the grid puts on an unsorted header, so the button shows the state it
          returns you to. aria-hidden because the label already says it.
        -->
        <span aria-hidden="true">&#8645;</span>
        Clear sort
        @if (sorts().length > 1) {
          <!--
            🔴 The h-5 rides on the shared badge rather than being replaced by it. The tone classes
            come from cms-status-badge; the height is this button's own, and is why the badge does
            not make it 2px taller than its neighbours - see the class docstring. Angular merges a
            consumer class with the component's host binding, and the primitive has a test for it.

            ⚠ No backticks in this comment, deliberately: an inline template IS a template literal,
            so one would end it. That is Known Issue 37, and it cost a build on the way in here.
          -->
          <cms-status-badge tone="info" [small]="true" class="cws:h-5">
            {{ sorts().length }}
          </cms-status-badge>
        }
      </button>
    }
  `
		}]
	}],
	propDecorators: {
		sorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sorts",
				required: true
			}]
		}],
		defaultSorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "defaultSorts",
				required: false
			}]
		}],
		clear: [{
			type: i0.Output,
			args: ["clear"]
		}]
	}
});
let nextPanelId = 0;
var NoticesPanelComponent = class NoticesPanelComponent {
	detailId = `cms-notices-detail-${nextPanelId++}`;
	summaries = input.required(...ngDevMode ? [{ debugName: "summaries" }] : /* istanbul ignore next */ []);
	heading = input("Environment & System Notices", ...ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []);
	initiallyExpanded = input(false, ...ngDevMode ? [{ debugName: "initiallyExpanded" }] : /* istanbul ignore next */ []);
	expanded = linkedSignal(() => this.initiallyExpanded(), ...ngDevMode ? [{ debugName: "expanded" }] : /* istanbul ignore next */ []);
	count = computed(() => this.summaries().length, ...ngDevMode ? [{ debugName: "count" }] : /* istanbul ignore next */ []);
	hasNotices = computed(() => this.count() > 0, ...ngDevMode ? [{ debugName: "hasNotices" }] : /* istanbul ignore next */ []);
	toggle() {
		this.expanded.update((open) => !open);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: NoticesPanelComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: NoticesPanelComponent,
		isStandalone: true,
		selector: "cms-notices-panel",
		inputs: {
			summaries: {
				classPropertyName: "summaries",
				publicName: "summaries",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			heading: {
				classPropertyName: "heading",
				publicName: "heading",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initiallyExpanded: {
				classPropertyName: "initiallyExpanded",
				publicName: "initiallyExpanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "@if (hasNotices()) {\r\n  <!--\r\n    One bordered block rather than a stack of full-width alerts.\r\n\r\n    ⚠ **Amber, not red.** These are standing conditions a user works alongside, not failures — and a\r\n    red block at the top of every visit trains people to skip the place errors will one day appear.\r\n\r\n    🔴 **Collapsed, it is ONE LINE: the heading, the count, and the disclosure** (JFrisbie,\r\n    2026-09-29). The summary bullets that used to sit under the heading in both states are gone —\r\n    the panel said too much before anyone asked. `py-2` rather than `py-3` for the same reason;\r\n    `px-4` still matches the cards and toolbar around it.\r\n  -->\r\n  <section\r\n    class=\"cws:rounded-md cws:border cws:border-amber-200 cws:bg-amber-50/60 cws:px-4 cws:py-2 cws:dark:border-amber-900/60 cws:dark:bg-amber-950/20\"\r\n    [attr.aria-label]=\"heading()\"\r\n  >\r\n    <!--\r\n      ⚠ **The header row is NOT the button** (JFrisbie, 2026-09-14). It was, on the reasoning that a\r\n      small target is easy to miss — but a whole row that toggles on click is a row you cannot select\r\n      text in, and the heading and count are the two things a reader is most likely to want to read\r\n      rather than press. Only the control is the control.\r\n    -->\r\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\r\n      <span aria-hidden=\"true\" class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">⚠</span>\r\n\r\n      <!--\r\n        The heading and its count, as one line of text: \"Environment & System Notices (3)\".\r\n\r\n        ⚠ The visible count is `aria-hidden` and the screen-reader text says \"active notices\",\r\n        because a bare \"(3)\" beside a heading is ambiguous read aloud — it could as easily be a step\r\n        or a version.\r\n      -->\r\n      <span class=\"cws:text-sm cws:font-medium cws:text-amber-900 cws:dark:text-amber-200\">\r\n        {{ heading() }} <span aria-hidden=\"true\">({{ count() }})</span>\r\n        <span class=\"sr-only\">{{ count() }} active notices</span>\r\n      </span>\r\n\r\n      <!--\r\n        The disclosure, and the whole of it is the target: the words and the triangle sit inside one\r\n        button so the hit area is the label rather than the 12px glyph.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:ml-auto cws:flex cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-800 cws:hover:bg-amber-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-amber-700 cws:dark:text-amber-300 cws:dark:hover:bg-amber-900/40\"\r\n        [attr.aria-expanded]=\"expanded()\"\r\n        [attr.aria-controls]=\"detailId\"\r\n        (click)=\"toggle()\"\r\n      >\r\n        {{ expanded() ? 'Hide' : 'Show' }} details\r\n\r\n        <!--\r\n          ⚠ `aria-hidden`, because the button already announces its state through `aria-expanded`\r\n          and the word beside it. Announcing a triangle as well would read as a third control.\r\n        -->\r\n        <span\r\n          aria-hidden=\"true\"\r\n          class=\"cws:text-[10px] cws:transition-transform\"\r\n          [class.cws:rotate-90]=\"expanded()\"\r\n        >\r\n          ▶\r\n        </span>\r\n      </button>\r\n    </div>\r\n\r\n    <!--\r\n      The detail: rendered ALWAYS and hidden, rather than removed.\r\n\r\n      ⚠ `aria-controls` must name an element that exists. Pointing it at a node the collapsed state\r\n      has removed is a dangling reference, and assistive technology then has nothing to move to when\r\n      the panel is opened.\r\n\r\n      🔴 **Every projected `scoular-alert` renders as a plain BULLET here, not as a card**\r\n      (JFrisbie, 2026-09-29). Callers project design-system alerts, and inside this panel the\r\n      coloured, bordered, padded boxes read as a second stack of banners — the thing the panel\r\n      exists to replace. Restyling them in ONE place keeps each caller's text, links and controls\r\n      (the create screen's template picker is one) while every screen gets the same list, so no\r\n      caller had to be rewritten. The title runs into its description on one line.\r\n\r\n      ⚠ This works because the design system's alert rules sit in the `components` layer and these\r\n      are utilities, which win by layer order rather than by specificity. If `components.css` is\r\n      ever imported unlayered, the cards come back.\r\n\r\n      `pl-6` lines the bullets up under the heading text rather than under the warning glyph, and\r\n      leaves room for the outside marker.\r\n    -->\r\n    <div\r\n      [id]=\"detailId\"\r\n      [hidden]=\"!expanded()\"\r\n      class=\"cws:mt-1.5 cws:space-y-1 cws:pb-1 cws:pl-6 cws:text-xs cws:text-amber-900/90 cws:dark:text-amber-200/90 cws:[&_.scoular-alert]:list-item cws:[&_.scoular-alert]:list-disc cws:[&_.scoular-alert]:rounded-none cws:[&_.scoular-alert]:border-0 cws:[&_.scoular-alert]:bg-transparent cws:[&_.scoular-alert]:p-0 cws:[&_.scoular-alert]:text-xs cws:[&_.scoular-alert]:text-amber-900/90 cws:dark:[&_.scoular-alert]:bg-transparent cws:dark:[&_.scoular-alert]:text-amber-200/90 cws:[&_.scoular-alert-description]:mt-0 cws:[&_.scoular-alert-description]:inline cws:[&_.scoular-alert-description]:text-xs cws:[&_.scoular-alert-title]:inline cws:[&_.scoular-alert-title]:font-medium cws:[&_.scoular-alert-title]:after:content-[':_']\"\r\n    >\r\n      <ng-content />\r\n    </div>\r\n  </section>\r\n}\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: NoticesPanelComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-notices-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: "@if (hasNotices()) {\r\n  <!--\r\n    One bordered block rather than a stack of full-width alerts.\r\n\r\n    ⚠ **Amber, not red.** These are standing conditions a user works alongside, not failures — and a\r\n    red block at the top of every visit trains people to skip the place errors will one day appear.\r\n\r\n    🔴 **Collapsed, it is ONE LINE: the heading, the count, and the disclosure** (JFrisbie,\r\n    2026-09-29). The summary bullets that used to sit under the heading in both states are gone —\r\n    the panel said too much before anyone asked. `py-2` rather than `py-3` for the same reason;\r\n    `px-4` still matches the cards and toolbar around it.\r\n  -->\r\n  <section\r\n    class=\"cws:rounded-md cws:border cws:border-amber-200 cws:bg-amber-50/60 cws:px-4 cws:py-2 cws:dark:border-amber-900/60 cws:dark:bg-amber-950/20\"\r\n    [attr.aria-label]=\"heading()\"\r\n  >\r\n    <!--\r\n      ⚠ **The header row is NOT the button** (JFrisbie, 2026-09-14). It was, on the reasoning that a\r\n      small target is easy to miss — but a whole row that toggles on click is a row you cannot select\r\n      text in, and the heading and count are the two things a reader is most likely to want to read\r\n      rather than press. Only the control is the control.\r\n    -->\r\n    <div class=\"cws:flex cws:items-center cws:gap-2\">\r\n      <span aria-hidden=\"true\" class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">⚠</span>\r\n\r\n      <!--\r\n        The heading and its count, as one line of text: \"Environment & System Notices (3)\".\r\n\r\n        ⚠ The visible count is `aria-hidden` and the screen-reader text says \"active notices\",\r\n        because a bare \"(3)\" beside a heading is ambiguous read aloud — it could as easily be a step\r\n        or a version.\r\n      -->\r\n      <span class=\"cws:text-sm cws:font-medium cws:text-amber-900 cws:dark:text-amber-200\">\r\n        {{ heading() }} <span aria-hidden=\"true\">({{ count() }})</span>\r\n        <span class=\"sr-only\">{{ count() }} active notices</span>\r\n      </span>\r\n\r\n      <!--\r\n        The disclosure, and the whole of it is the target: the words and the triangle sit inside one\r\n        button so the hit area is the label rather than the 12px glyph.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:ml-auto cws:flex cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-800 cws:hover:bg-amber-100 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-amber-700 cws:dark:text-amber-300 cws:dark:hover:bg-amber-900/40\"\r\n        [attr.aria-expanded]=\"expanded()\"\r\n        [attr.aria-controls]=\"detailId\"\r\n        (click)=\"toggle()\"\r\n      >\r\n        {{ expanded() ? 'Hide' : 'Show' }} details\r\n\r\n        <!--\r\n          ⚠ `aria-hidden`, because the button already announces its state through `aria-expanded`\r\n          and the word beside it. Announcing a triangle as well would read as a third control.\r\n        -->\r\n        <span\r\n          aria-hidden=\"true\"\r\n          class=\"cws:text-[10px] cws:transition-transform\"\r\n          [class.cws:rotate-90]=\"expanded()\"\r\n        >\r\n          ▶\r\n        </span>\r\n      </button>\r\n    </div>\r\n\r\n    <!--\r\n      The detail: rendered ALWAYS and hidden, rather than removed.\r\n\r\n      ⚠ `aria-controls` must name an element that exists. Pointing it at a node the collapsed state\r\n      has removed is a dangling reference, and assistive technology then has nothing to move to when\r\n      the panel is opened.\r\n\r\n      🔴 **Every projected `scoular-alert` renders as a plain BULLET here, not as a card**\r\n      (JFrisbie, 2026-09-29). Callers project design-system alerts, and inside this panel the\r\n      coloured, bordered, padded boxes read as a second stack of banners — the thing the panel\r\n      exists to replace. Restyling them in ONE place keeps each caller's text, links and controls\r\n      (the create screen's template picker is one) while every screen gets the same list, so no\r\n      caller had to be rewritten. The title runs into its description on one line.\r\n\r\n      ⚠ This works because the design system's alert rules sit in the `components` layer and these\r\n      are utilities, which win by layer order rather than by specificity. If `components.css` is\r\n      ever imported unlayered, the cards come back.\r\n\r\n      `pl-6` lines the bullets up under the heading text rather than under the warning glyph, and\r\n      leaves room for the outside marker.\r\n    -->\r\n    <div\r\n      [id]=\"detailId\"\r\n      [hidden]=\"!expanded()\"\r\n      class=\"cws:mt-1.5 cws:space-y-1 cws:pb-1 cws:pl-6 cws:text-xs cws:text-amber-900/90 cws:dark:text-amber-200/90 cws:[&_.scoular-alert]:list-item cws:[&_.scoular-alert]:list-disc cws:[&_.scoular-alert]:rounded-none cws:[&_.scoular-alert]:border-0 cws:[&_.scoular-alert]:bg-transparent cws:[&_.scoular-alert]:p-0 cws:[&_.scoular-alert]:text-xs cws:[&_.scoular-alert]:text-amber-900/90 cws:dark:[&_.scoular-alert]:bg-transparent cws:dark:[&_.scoular-alert]:text-amber-200/90 cws:[&_.scoular-alert-description]:mt-0 cws:[&_.scoular-alert-description]:inline cws:[&_.scoular-alert-description]:text-xs cws:[&_.scoular-alert-title]:inline cws:[&_.scoular-alert-title]:font-medium cws:[&_.scoular-alert-title]:after:content-[':_']\"\r\n    >\r\n      <ng-content />\r\n    </div>\r\n  </section>\r\n}\r\n"
		}]
	}],
	propDecorators: {
		summaries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "summaries",
				required: true
			}]
		}],
		heading: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "heading",
				required: false
			}]
		}],
		initiallyExpanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "initiallyExpanded",
				required: false
			}]
		}]
	}
});
const DRAG_THRESHOLD_PX = 5;
function elementUnder(x, y, selector) {
	return document.elementFromPoint(x, y)?.closest(selector) ?? null;
}
var PointerDragGesture = class {
	handlers;
	pending = null;
	active = false;
	current = null;
	stop = null;
	constructor(handlers) {
		this.handlers = handlers;
	}
	dragging() {
		return this.active;
	}
	press(event) {
		const target = event.target;
		if (event.button !== 0 || target === null || typeof target.closest !== "function") return;
		if (target.closest(this.handlers.ignoreSelector ?? "button") !== null) return;
		const handle = target.closest(this.handlers.handleSelector);
		if (handle === null) return;
		const source = this.handlers.source(handle);
		if (source === null) return;
		this.end();
		this.pending = {
			source,
			x: event.clientX,
			y: event.clientY,
			pointerId: event.pointerId
		};
		this.listen();
	}
	cancel() {
		if (this.pending !== null || this.stop !== null) this.end();
	}
	listen() {
		const move = (event) => this.onMove(event);
		const up = (event) => this.onUp(event);
		const cancel = () => this.end();
		const key = (event) => {
			if (event.key === "Escape") this.end();
		};
		window.addEventListener("pointermove", move);
		window.addEventListener("pointerup", up);
		window.addEventListener("pointercancel", cancel);
		window.addEventListener("blur", cancel);
		window.addEventListener("keydown", key);
		this.stop = () => {
			window.removeEventListener("pointermove", move);
			window.removeEventListener("pointerup", up);
			window.removeEventListener("pointercancel", cancel);
			window.removeEventListener("blur", cancel);
			window.removeEventListener("keydown", key);
			this.stop = null;
		};
	}
	onMove(event) {
		const pending = this.pending;
		if (pending === null || event.pointerId !== pending.pointerId) return;
		if (!this.active) {
			if (Math.abs(event.clientX - pending.x) + Math.abs(event.clientY - pending.y) < (this.handlers.threshold ?? 5)) return;
			this.active = true;
			this.handlers.started(pending.source);
		}
		event.preventDefault();
		this.current = this.handlers.target(event.clientX, event.clientY);
		this.handlers.over(this.current);
	}
	onUp(event) {
		const pending = this.pending;
		if (pending === null || event.pointerId !== pending.pointerId) return;
		const wasDragging = this.active;
		const target = this.current;
		this.end();
		if (wasDragging && target !== null) this.handlers.dropped(pending.source, target);
	}
	end() {
		const wasFollowing = this.pending !== null;
		this.pending = null;
		this.active = false;
		this.current = null;
		this.stop?.();
		if (wasFollowing) this.handlers.ended();
	}
};
const EMPTY_FILTER = {
	combinator: "and",
	rules: []
};
function isRuleNode(node) {
	return typeof node.columnKey === "string";
}
function isGroupNode(node) {
	return !isRuleNode(node);
}
function isLive(node) {
	return isRuleNode(node) ? isComplete(node) : node.rules.some(isLive);
}
const OPERATORS_BY_KIND = {
	text: [
		"contains",
		"notContains",
		"equals",
		"notEquals",
		"startsWith",
		"endsWith",
		"isBlank",
		"isNotBlank"
	],
	number: [
		"equals",
		"notEquals",
		"gt",
		"gte",
		"lt",
		"lte",
		"isBlank",
		"isNotBlank"
	],
	date: [
		"equals",
		"notEquals",
		"gt",
		"gte",
		"lt",
		"lte",
		"isBlank",
		"isNotBlank"
	]
};
const OPERATOR_LABELS = {
	text: {
		contains: "contains",
		notContains: "does not contain",
		equals: "is",
		notEquals: "is not",
		startsWith: "starts with",
		endsWith: "ends with",
		gt: "is after",
		gte: "is at or after",
		lt: "is before",
		lte: "is at or before",
		isBlank: "is blank",
		isNotBlank: "is not blank"
	},
	number: {
		contains: "contains",
		notContains: "does not contain",
		equals: "equals",
		notEquals: "does not equal",
		startsWith: "starts with",
		endsWith: "ends with",
		gt: "is greater than",
		gte: "is at least",
		lt: "is less than",
		lte: "is at most",
		isBlank: "is blank",
		isNotBlank: "is not blank"
	},
	date: {
		contains: "contains",
		notContains: "does not contain",
		equals: "is on",
		notEquals: "is not on",
		gt: "is after",
		gte: "is on or after",
		lt: "is before",
		lte: "is on or before",
		startsWith: "starts with",
		endsWith: "ends with",
		isBlank: "is blank",
		isNotBlank: "is not blank"
	}
};
const VALUELESS = /* @__PURE__ */ new Set(["isBlank", "isNotBlank"]);
function needsValue(operator) {
	return !VALUELESS.has(operator);
}
function operatorsFor(kind) {
	return OPERATORS_BY_KIND[kind];
}
function operatorLabel(kind, operator) {
	return OPERATOR_LABELS[kind][operator];
}
function matchesGroup(row, columns, group) {
	const active = group.rules.filter(isLive);
	if (active.length === 0) return true;
	const results = active.map((node) => isRuleNode(node) ? matchesRule(row, columns, node) : matchesGroup(row, columns, node));
	return group.combinator === "and" ? results.every(Boolean) : results.some(Boolean);
}
function isComplete(rule) {
	if (rule.columnKey === "") return false;
	return !needsValue(rule.operator) || rule.value.trim() !== "";
}
function matchesRule(row, columns, rule) {
	const column = columns.find((candidate) => candidate.key === rule.columnKey);
	if (column === void 0) return false;
	const text = column.format(row) ?? "";
	const kind = column.filterKind ?? "text";
	switch (rule.operator) {
		case "isBlank": return text.trim() === "";
		case "isNotBlank": return text.trim() !== "";
		case "contains": return includes(text, rule.value);
		case "notContains": return !includes(text, rule.value);
		case "startsWith": return normalise(text).startsWith(normalise(rule.value));
		case "endsWith": return normalise(text).endsWith(normalise(rule.value));
		default: return compares(row, column, kind, rule);
	}
}
function compares(row, column, kind, rule) {
	const left = column.sortValue?.(row) ?? column.format(row) ?? "";
	const right = rule.value.trim();
	if (kind === "number") {
		const leftNumber = typeof left === "number" ? left : Number.parseFloat(String(left).replace(/,/g, ""));
		const rightNumber = Number.parseFloat(right.replace(/,/g, ""));
		if (!Number.isFinite(leftNumber) || !Number.isFinite(rightNumber)) return false;
		return orders(leftNumber, rightNumber, rule.operator);
	}
	if (kind === "date") {
		const leftDate = String(left);
		const rightDate = right;
		if (leftDate === "" || rightDate === "") return false;
		return orders(leftDate, rightDate, rule.operator);
	}
	return orders(normalise(String(left)), normalise(right), rule.operator);
}
function orders(left, right, operator) {
	switch (operator) {
		case "equals": return left === right;
		case "notEquals": return left !== right;
		case "gt": return left > right;
		case "gte": return left >= right;
		case "lt": return left < right;
		case "lte": return left <= right;
		default: return false;
	}
}
function normalise(value) {
	return value.trim().toLocaleLowerCase();
}
function includes(haystack, needle) {
	return normalise(haystack).includes(normalise(needle));
}
function matchesSearch(row, columns, term) {
	const needle = normalise(term);
	if (needle === "") return true;
	return columns.some((column) => includes(column.format(row) ?? "", needle));
}
function describeGroup(columns, group) {
	return group.rules.filter(isLive).map((node) => {
		if (isGroupNode(node)) {
			const inner = describeGroup(columns, node);
			return node.rules.filter(isLive).length > 1 ? `(${inner})` : inner;
		}
		const column = columns.find((candidate) => candidate.key === node.columnKey);
		const kind = column?.filterKind ?? "text";
		const header = column?.header ?? node.columnKey;
		const operator = operatorLabel(kind, node.operator);
		return needsValue(node.operator) ? `${header} ${operator} "${node.value.trim()}"` : `${header} ${operator}`;
	}).join(group.combinator === "and" ? " and " : " or ");
}
function activeRuleCount(group) {
	return group.rules.reduce((total, node) => total + (isRuleNode(node) ? isComplete(node) ? 1 : 0 : activeRuleCount(node)), 0);
}
function sameGroup(left, right) {
	const active = (group) => group.rules.filter(isLive);
	const a = active(left);
	const b = active(right);
	if (a.length > 1 && left.combinator !== right.combinator) return false;
	return a.length === b.length && a.every((node, index) => {
		const other = b[index];
		if (other === void 0) return false;
		if (isGroupNode(node) !== isGroupNode(other)) return false;
		if (isGroupNode(node) && isGroupNode(other)) return sameGroup(node, other);
		const rule = node;
		const otherRule = other;
		return rule.columnKey === otherRule.columnKey && rule.operator === otherRule.operator && rule.value.trim() === otherRule.value.trim();
	});
}
function nodeAt(group, path) {
	let current = group;
	for (const index of path) {
		if (isRuleNode(current)) return null;
		const next = current.rules[index];
		if (next === void 0) return null;
		current = next;
	}
	return current;
}
function setAt(group, path, replacement) {
	const [head, ...rest] = path;
	if (head === void 0) return group;
	const rules = [...group.rules];
	if (rest.length === 0) {
		if (replacement === null) rules.splice(head, 1);
		else rules[head] = replacement;
		return {
			...group,
			rules
		};
	}
	const child = rules[head];
	if (child === void 0 || isRuleNode(child)) return group;
	rules[head] = setAt(child, rest, replacement);
	return {
		...group,
		rules
	};
}
function removeAt(group, path) {
	return setAt(group, path, null);
}
function replaceRuleById(group, rule) {
	return {
		...group,
		rules: group.rules.map((node) => {
			if (isRuleNode(node)) return node.id === rule.id ? rule : node;
			return replaceRuleById(node, rule);
		})
	};
}
function normaliseGroup(group) {
	const rules = [];
	for (const node of group.rules) {
		if (isRuleNode(node)) {
			rules.push(node);
			continue;
		}
		const child = normaliseGroup(node);
		if (child.rules.length === 0) continue;
		if (child.rules.length === 1) {
			const only = child.rules[0];
			if (only !== void 0) rules.push(only);
			continue;
		}
		rules.push(child);
	}
	return {
		...group,
		rules
	};
}
function toggleCombinatorAt(group, path) {
	const target = path.length === 0 ? group : nodeAt(group, path);
	if (target === null || isRuleNode(target)) return group;
	const flipped = {
		...target,
		combinator: target.combinator === "and" ? "or" : "and"
	};
	return path.length === 0 ? flipped : setAt(group, path, flipped);
}
function moveNode(group, from, to, mode) {
	if (from.length === 0 || to.length === 0) return group;
	if (samePath(from, to) || isAncestor(from, to)) return group;
	const moving = nodeAt(group, from);
	if (moving === null) return group;
	const target = nodeAt(group, to);
	const parentPath = to.slice(0, -1);
	const parent = parentPath.length === 0 ? group : nodeAt(group, parentPath);
	if (parent === null || isRuleNode(parent)) return group;
	let next;
	if (mode === "onto") {
		if (target === null) return group;
		next = isGroupNode(target) ? setAt(group, to, {
			...target,
			rules: [...target.rules, moving]
		}) : setAt(group, to, {
			combinator: parent.combinator === "and" ? "or" : "and",
			rules: [target, moving]
		});
	} else {
		const rules = [...parent.rules];
		const index = Math.min(to[to.length - 1] ?? rules.length, rules.length);
		rules.splice(index, 0, moving);
		next = parentPath.length === 0 ? {
			...group,
			rules
		} : setAt(group, parentPath, {
			...parent,
			rules
		});
	}
	return normaliseGroup(setAt(next, shiftForInsert(from, to, mode), null));
}
function samePath(a, b) {
	return a.length === b.length && a.every((value, index) => value === b[index]);
}
function isAncestor(ancestor, descendant) {
	return ancestor.length <= descendant.length && ancestor.every((value, index) => value === descendant[index]);
}
function shiftForInsert(from, to, mode) {
	if (mode !== "before") return from;
	const toParent = to.slice(0, -1);
	const toIndex = to[to.length - 1] ?? 0;
	if (from.length <= toParent.length || !samePath(toParent, from.slice(0, toParent.length))) return from;
	const component = from[toParent.length] ?? 0;
	return component >= toIndex ? [
		...from.slice(0, toParent.length),
		component + 1,
		...from.slice(toParent.length + 1)
	] : from;
}
function ungroupAt(group, path) {
	if (path.length < 2) return group;
	const node = nodeAt(group, path);
	if (node === null) return group;
	const parentPath = path.slice(0, -1);
	const grandParentPath = parentPath.slice(0, -1);
	const parentIndex = parentPath[parentPath.length - 1] ?? 0;
	const without = removeAt(group, path);
	const container = grandParentPath.length === 0 ? without : nodeAt(without, grandParentPath);
	if (container === null || !isGroupNode(container)) return group;
	const rules = [...container.rules];
	rules.splice(parentIndex + 1, 0, node);
	return normaliseGroup(grandParentPath.length === 0 ? {
		...without,
		rules
	} : setAt(without, grandParentPath, {
		...container,
		rules
	}));
}
function groupNodes(group, first, second) {
	return moveNode(group, second, first, "onto");
}
const SAVED_FILTER_STORE = new InjectionToken("SAVED_FILTER_STORE");
const SAVED_FILTER_OWNER = new InjectionToken("SAVED_FILTER_OWNER");
const PREFIX = "cws.savedFilters";
var LocalSavedFilterStore = class LocalSavedFilterStore {
	changed = signal(0, ...ngDevMode ? [{ debugName: "changed" }] : /* istanbul ignore next */ []);
	revision = () => this.changed();
	owner = inject(SAVED_FILTER_OWNER, { optional: true }) ?? (() => "shared");
	list(scope) {
		return this.read(scope);
	}
	save(scope, name, group, sort) {
		const trimmed = name.trim();
		const existing = this.read(scope);
		const match = existing.find((filter) => filter.name.toLocaleLowerCase() === trimmed.toLocaleLowerCase());
		const saved = {
			id: match?.id ?? `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
			name: trimmed,
			group,
			scope,
			...sort === void 0 ? {} : { sort: [...sort] }
		};
		const next = match ? existing.map((filter) => filter.id === match.id ? saved : filter) : [...existing, saved];
		this.write(scope, next);
		return saved;
	}
	remove(scope, id) {
		this.write(scope, this.read(scope).filter((filter) => filter.id !== id));
		if (this.defaultId(scope) === id) this.setDefault(scope, null);
	}
	defaultId(scope) {
		this.changed();
		try {
			const raw = localStorage.getItem(this.defaultKey(scope));
			return raw !== null && this.read(scope).some((filter) => filter.id === raw) ? raw : null;
		} catch {
			return null;
		}
	}
	setDefault(scope, id) {
		try {
			if (id === null) localStorage.removeItem(this.defaultKey(scope));
			else localStorage.setItem(this.defaultKey(scope), id);
		} catch {}
		this.changed.update((value) => value + 1);
	}
	key(scope) {
		return `${PREFIX}.${this.owner()}.${scope}`;
	}
	defaultKey(scope) {
		return `${this.key(scope)}.default`;
	}
	read(scope) {
		this.changed();
		try {
			const raw = localStorage.getItem(this.key(scope));
			if (raw === null) return [];
			const parsed = JSON.parse(raw);
			return Array.isArray(parsed) ? parsed.filter(isSavedFilter) : [];
		} catch {
			return [];
		}
	}
	write(scope, filters) {
		try {
			localStorage.setItem(this.key(scope), JSON.stringify(filters));
		} catch {}
		this.changed.update((value) => value + 1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: LocalSavedFilterStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: LocalSavedFilterStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: LocalSavedFilterStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
function isSavedFilter(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return typeof candidate.id === "string" && typeof candidate.name === "string" && typeof candidate.scope === "string" && typeof candidate.group === "object" && candidate.group !== null && isGroup(candidate.group) && isSort(candidate.sort);
}
function isGroup(value) {
	if (typeof value !== "object" || value === null) return false;
	const candidate = value;
	return Array.isArray(candidate.rules) && candidate.rules.every(isNode);
}
function isNode(value) {
	if (typeof value !== "object" || value === null) return false;
	if (typeof value.columnKey !== "string") return isGroup(value);
	const rule = value;
	return typeof rule["id"] === "string" && typeof rule["operator"] === "string" && typeof rule["value"] === "string";
}
function isSort(value) {
	if (value === void 0) return true;
	return Array.isArray(value) && value.every((entry) => typeof entry === "object" && entry !== null && typeof entry.key === "string" && (entry.direction === "asc" || entry.direction === "desc"));
}
const SAVED_FILTER_SCOPES = {
	contracts: "contracts",
	approvals: "approvals",
	pricing: "pricing",
	pricingApprovals: "pricing-approvals"
};
var SelectComponent = class SelectComponent {
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	value = input("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	label = input.required(...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	labelledBy = input(null, ...ngDevMode ? [{ debugName: "labelledBy" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	valueChange = output();
	selectedLabel = computed(() => {
		const options = this.options();
		return options.find((option) => option.value === this.value())?.label ?? options[0]?.label ?? "";
	}, ...ngDevMode ? [{ debugName: "selectedLabel" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: SelectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: SelectComponent,
		isStandalone: true,
		selector: "cms-select",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			labelledBy: {
				classPropertyName: "labelledBy",
				publicName: "labelledBy",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { valueChange: "valueChange" },
		ngImport: i0,
		template: "<div cmsDropdown #panel=\"cmsDropdown\" class=\"cws:relative\">\r\n  <!--\r\n    `text-left` is load-bearing: a `<button>` inherits `text-align: center`, so the value would sit\r\n    centred while every input beside it is left-aligned.\r\n\r\n    The trigger wears `scoular-form-input` so it matches the bordered filter inputs it sits among.\r\n    ⚠ That class is `@apply w-full`, so its width comes from the wrapper — see the component's own\r\n    remarks. Sizing this button directly does nothing.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"scoular-form-input cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\r\n    [attr.aria-label]=\"labelledBy() === null ? label() : null\"\r\n    [attr.aria-labelledby]=\"labelledBy()\"\r\n    aria-haspopup=\"listbox\"\r\n    [attr.aria-expanded]=\"panel.open()\"\r\n    [disabled]=\"disabled()\"\r\n    (click)=\"panel.toggle()\"\r\n  >\r\n    <span class=\"truncate\">{{ selectedLabel() }}</span>\r\n    <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-xs\">{{ panel.open() ? '▲' : '▼' }}</span>\r\n  </button>\r\n\r\n  @if (panel.open()) {\r\n    <!--\r\n      `w-full min-w-max` so the panel is at least as wide as its trigger and never narrower than its\r\n      longest option — an operator list reading \"does not contain\" cannot fit a 144px field, and\r\n      clipping the choices is worse than a panel wider than the control that opened it.\r\n\r\n      `max-h-64 overflow-y-auto` because a column list is as long as the grid has columns.\r\n    -->\r\n    <div\r\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:max-h-64 cws:w-full cws:min-w-max cws:overflow-y-auto\"\r\n      role=\"listbox\"\r\n      [attr.aria-label]=\"labelledBy() === null ? label() : null\"\r\n      [attr.aria-labelledby]=\"labelledBy()\"\r\n    >\r\n      @for (option of options(); track option.value) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"option\"\r\n          class=\"scoular-dropdown-item cws:w-full cws:text-left\"\r\n          [class.active]=\"option.value === value()\"\r\n          [attr.aria-selected]=\"option.value === value()\"\r\n          (click)=\"panel.close(); valueChange.emit(option.value)\"\r\n        >\r\n          {{ option.label }}\r\n        </button>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
		dependencies: [{
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: SelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownDirective],
			template: "<div cmsDropdown #panel=\"cmsDropdown\" class=\"cws:relative\">\r\n  <!--\r\n    `text-left` is load-bearing: a `<button>` inherits `text-align: center`, so the value would sit\r\n    centred while every input beside it is left-aligned.\r\n\r\n    The trigger wears `scoular-form-input` so it matches the bordered filter inputs it sits among.\r\n    ⚠ That class is `@apply w-full`, so its width comes from the wrapper — see the component's own\r\n    remarks. Sizing this button directly does nothing.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"scoular-form-input cws:flex cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\r\n    [attr.aria-label]=\"labelledBy() === null ? label() : null\"\r\n    [attr.aria-labelledby]=\"labelledBy()\"\r\n    aria-haspopup=\"listbox\"\r\n    [attr.aria-expanded]=\"panel.open()\"\r\n    [disabled]=\"disabled()\"\r\n    (click)=\"panel.toggle()\"\r\n  >\r\n    <span class=\"truncate\">{{ selectedLabel() }}</span>\r\n    <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-xs\">{{ panel.open() ? '▲' : '▼' }}</span>\r\n  </button>\r\n\r\n  @if (panel.open()) {\r\n    <!--\r\n      `w-full min-w-max` so the panel is at least as wide as its trigger and never narrower than its\r\n      longest option — an operator list reading \"does not contain\" cannot fit a 144px field, and\r\n      clipping the choices is worse than a panel wider than the control that opened it.\r\n\r\n      `max-h-64 overflow-y-auto` because a column list is as long as the grid has columns.\r\n    -->\r\n    <div\r\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:max-h-64 cws:w-full cws:min-w-max cws:overflow-y-auto\"\r\n      role=\"listbox\"\r\n      [attr.aria-label]=\"labelledBy() === null ? label() : null\"\r\n      [attr.aria-labelledby]=\"labelledBy()\"\r\n    >\r\n      @for (option of options(); track option.value) {\r\n        <button\r\n          type=\"button\"\r\n          role=\"option\"\r\n          class=\"scoular-dropdown-item cws:w-full cws:text-left\"\r\n          [class.active]=\"option.value === value()\"\r\n          [attr.aria-selected]=\"option.value === value()\"\r\n          (click)=\"panel.close(); valueChange.emit(option.value)\"\r\n        >\r\n          {{ option.label }}\r\n        </button>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: true
			}]
		}],
		labelledBy: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelledBy",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
var FilterChipsComponent = class FilterChipsComponent {
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	group = input.required(...ngDevMode ? [{ debugName: "group" }] : /* istanbul ignore next */ []);
	path = input([], ...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	markedPath = input(null, ...ngDevMode ? [{ debugName: "markedPath" }] : /* istanbul ignore next */ []);
	draggingPath = input(null, ...ngDevMode ? [{ debugName: "draggingPath" }] : /* istanbul ignore next */ []);
	dropTarget = input(null, ...ngDevMode ? [{ debugName: "dropTarget" }] : /* istanbul ignore next */ []);
	editingId = input(null, ...ngDevMode ? [{ debugName: "editingId" }] : /* istanbul ignore next */ []);
	removeNode = output();
	toggleCombinator = output();
	markNode = output();
	editNode = output();
	ungroupNode = output();
	nodes = computed(() => this.group().rules, ...ngDevMode ? [{ debugName: "nodes" }] : /* istanbul ignore next */ []);
	combinatorLabel = computed(() => this.group().combinator === "and" ? "AND" : "OR", ...ngDevMode ? [{ debugName: "combinatorLabel" }] : /* istanbul ignore next */ []);
	nested = computed(() => this.path().length > 0, ...ngDevMode ? [{ debugName: "nested" }] : /* istanbul ignore next */ []);
	dragActive = computed(() => this.draggingPath() !== null, ...ngDevMode ? [{ debugName: "dragActive" }] : /* istanbul ignore next */ []);
	childPath(index) {
		return [...this.path(), index];
	}
	isRule(node) {
		return isRuleNode(node);
	}
	asRule(node) {
		return node;
	}
	asGroup(node) {
		return node;
	}
	isMarked(index) {
		return this.samePath(this.markedPath(), this.childPath(index));
	}
	isDragging(index) {
		return this.samePath(this.draggingPath(), this.childPath(index));
	}
	isEditing(node) {
		const id = this.editingId();
		return id !== null && isRuleNode(node) && node.id === id;
	}
	gapClassFor(index) {
		if (this.dropModeFor(index) === "before") return "cws:bg-scoular-blue";
		return this.dragActive() ? "cws:bg-slate-300 cws:dark:bg-slate-600" : "cws:bg-transparent";
	}
	dropModeFor(index) {
		const target = this.dropTarget();
		if (target === null || target.mode === "ungroup") return null;
		return this.samePath(target.path, this.childPath(index)) ? target.mode : null;
	}
	describe(node) {
		const rule = this.asRule(node);
		const column = this.columns().find((candidate) => candidate.key === rule.columnKey);
		const kind = column?.filterKind ?? "text";
		return {
			header: column?.header ?? rule.columnKey,
			operator: operatorLabel(kind, rule.operator),
			value: needsValue(rule.operator) ? rule.value : null
		};
	}
	isUnknown(node) {
		const rule = this.asRule(node);
		return rule.columnKey !== "" && !this.columns().some((column) => column.key === rule.columnKey);
	}
	liveCount(node) {
		return isGroupNode(node) ? node.rules.filter(isLive).length : 1;
	}
	combinatorOf(node) {
		return this.asGroup(node).combinator;
	}
	pathAttr(index) {
		return this.childPath(index).join(".");
	}
	onChipKeydown(index, event) {
		if (event.key === " " || event.key === "Spacebar") {
			event.preventDefault();
			this.markNode.emit(this.childPath(index));
			return;
		}
		if (event.key === "Enter") {
			event.preventDefault();
			this.editNode.emit(this.childPath(index));
			return;
		}
		if (event.key === "Delete" || event.key === "Backspace") {
			event.preventDefault();
			this.removeNode.emit(this.childPath(index));
		}
	}
	samePath(a, b) {
		return a !== null && a.length === b.length && a.every((value, index) => value === b[index]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FilterChipsComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: FilterChipsComponent,
		isStandalone: true,
		selector: "cms-filter-chips",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			group: {
				classPropertyName: "group",
				publicName: "group",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			path: {
				classPropertyName: "path",
				publicName: "path",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			markedPath: {
				classPropertyName: "markedPath",
				publicName: "markedPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			draggingPath: {
				classPropertyName: "draggingPath",
				publicName: "draggingPath",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			dropTarget: {
				classPropertyName: "dropTarget",
				publicName: "dropTarget",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			editingId: {
				classPropertyName: "editingId",
				publicName: "editingId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			removeNode: "removeNode",
			toggleCombinator: "toggleCombinator",
			markNode: "markNode",
			editNode: "editNode",
			ungroupNode: "ungroupNode"
		},
		host: { classAttribute: "cws:contents" },
		ngImport: i0,
		template: "<!--\r\n  One level of the filter tree. A group renders `cms-filter-chips` again, which is what makes the\r\n  nesting arbitrary rather than a fixed number of hand-written levels.\r\n\r\n  ⚠ The host is `display: contents`, so these chips join their parent's flex row rather than forming\r\n  a box of their own. A nested group needs its own box — it draws the parentheses — so that one\r\n  wraps its children in a bordered span.\r\n-->\r\n@for (node of nodes(); track $index; let last = $last) {\r\n  @if ($first) {\r\n    <!--\r\n      The insertion point BEFORE the first chip, so a chip can be moved to the front.\r\n\r\n      🔴 **Rendered ALWAYS, never conditionally on the drag** (JFrisbie, 2026-09-14 — reported as\r\n      \"it shows this and doesn't let me drag it around\", in Chrome).\r\n\r\n      These gaps used to appear on `dragstart`, which inserts nodes **immediately beside the element\r\n      being dragged, inside the dragstart handler**. Chromium takes its drag image and starts its\r\n      native drag loop at the end of that handler, and a DOM mutation there aborts the drag: the\r\n      chip never follows the pointer, and the only visible result is the gaps themselves appearing —\r\n      exactly what the screenshot showed.\r\n\r\n      ⚠ **Measured, because it cannot be reproduced through Playwright**: its synthetic drag goes\r\n      through CDP and skips the drag-image capture, so it completed happily in both browsers while a\r\n      real mouse could not. What IS measurable is the cause — four DOM mutations during `dragstart`\r\n      before this change, zero after. That number is the regression test a browser cannot be.\r\n\r\n      So only the *colour* changes now. The space is reserved from first paint, which also means the\r\n      row does not reflow the instant a drag begins.\r\n\r\n      🔴 **Reordering lives in the gaps now, and grouping owns the chip.** It used to be split by\r\n      arithmetic inside the chip — outer quarter \"before\", middle \"onto\" — which made the common\r\n      gesture fail silently: a grouping drag that landed in the first quarter of the target was read\r\n      as a reorder, and a reorder onto your own neighbour is a no-op, so nothing happened at all.\r\n      See the component's own note on `onDragOver`.\r\n\r\n      ⚠ **The padding is the hit area, and it is deliberately much wider than the bar it draws.**\r\n      A drop is only permitted on an element that received a `dragover` and cancelled it, so a\r\n      target narrow enough to fall between two pointer samples is a target a quick flick misses\r\n      entirely — and the gesture then ends in nothing, which is the same silent failure this whole\r\n      change exists to remove. The bar stays 6px because that is what reads as an insertion point;\r\n      the span around it is 26px because that is what can be hit. The connectors need no such\r\n      padding, being ~46px already.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\r\n      data-drop-gap\r\n      data-drop-mode=\"before\"\r\n      [attr.data-drop-path]=\"pathAttr($index)\"\r\n      [attr.aria-hidden]=\"true\"\r\n    >\r\n      <span\r\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\r\n        [class]=\"gapClassFor($index)\"\r\n      ></span>\r\n    </span>\r\n  }\r\n\r\n  @if (isRule(node)) {\r\n    <!--\r\n      A chip.\r\n\r\n      🔴 **Draggable, focusable, double-clickable and hoverable.** `draggable` gives the mouse\r\n      gesture; `tabindex=\"0\"` plus the keydown handler gives the keyboard one; `dblclick` opens the\r\n      editor (JFrisbie, 2026-09-11) with Enter as its keyboard twin; the hover colour is what tells\r\n      someone the chip is a thing you can pick up at all, which a static label does not.\r\n    -->\r\n    <span\r\n      data-drop-mode=\"onto\"\r\n      [attr.data-drop-path]=\"pathAttr($index)\"\r\n      [attr.data-drag-path]=\"pathAttr($index)\"\r\n      tabindex=\"0\"\r\n      role=\"button\"\r\n      class=\"cws:inline-flex cws:cursor-grab cws:items-center cws:gap-1.5 cws:rounded cws:border cws:px-2 cws:py-1 cws:text-xs cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:active:cursor-grabbing\"\r\n      [class]=\"\r\n        isMarked($index) || isEditing(node)\r\n          ? 'cws:border-scoular-blue cws:bg-sky-100 cws:text-sky-900 cws:ring-1 cws:ring-scoular-blue cws:dark:bg-sky-900 cws:dark:text-sky-100'\r\n          : 'cws:border-transparent cws:bg-sky-50 cws:text-sky-900 cws:hover:border-sky-300 cws:hover:bg-sky-100 cws:dark:bg-sky-950/50 cws:dark:text-sky-200 cws:dark:hover:bg-sky-900/70'\r\n      \"\r\n      [class.cws:opacity-40]=\"isDragging($index)\"\r\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\r\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\r\n      [attr.aria-pressed]=\"isMarked($index)\"\r\n      title=\"Double-click to edit. Drag onto another filter to group them, or into the gap between two to reorder.\"\r\n      [attr.aria-label]=\"\r\n        describe(node).header +\r\n        ' ' +\r\n        describe(node).operator +\r\n        (describe(node).value === null ? '' : ' ' + describe(node).value) +\r\n        (isEditing(node) ? ' — being edited' : '') +\r\n        (isMarked($index) ? ' — marked for grouping' : '') +\r\n        '. Press Enter to edit, Space to mark for grouping, Delete to remove.'\r\n      \"\r\n      (dblclick)=\"editNode.emit(childPath($index))\"\r\n      (keydown)=\"onChipKeydown($index, $event)\"\r\n    >\r\n      <span class=\"cws:font-medium\">{{ describe(node).header }}</span>\r\n      <span class=\"cws:italic cws:opacity-80\">{{ describe(node).operator }}</span>\r\n      @if (describe(node).value !== null) {\r\n        <span class=\"cws:font-medium\">{{ describe(node).value }}</span>\r\n      }\r\n\r\n      @if (isUnknown(node)) {\r\n        <!--\r\n          A saved filter can name a column this grid no longer has. Such a rule matches NOTHING, so\r\n          the chip says so rather than looking like an ordinary filter that happens to return little.\r\n        -->\r\n        <span\r\n          class=\"cws:rounded cws:bg-amber-100 cws:px-1 cws:text-[10px] cws:font-semibold cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n          title=\"This column is not in this grid, so this rule matches nothing.\"\r\n        >\r\n          not in grid\r\n        </span>\r\n      }\r\n\r\n      @if (nested()) {\r\n        <!--\r\n          Move out of the group — the keyboard's version of dragging the chip clear, and a target for\r\n          anyone who would rather click than drag.\r\n\r\n          🔴 **Only rendered inside a group**, because at the top level there is nothing to move out\r\n          of. That is also what keeps the chip uncluttered in the common case: the button appears\r\n          exactly when it has something to do.\r\n        -->\r\n        <button\r\n          type=\"button\"\r\n          class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\r\n          title=\"Move out of the group\"\r\n          [attr.aria-label]=\"\r\n            'Move ' + describe(node).header + ' ' + describe(node).operator + ' out of its group'\r\n          \"\r\n          (click)=\"ungroupNode.emit(childPath($index))\"\r\n        >\r\n          ⤴\r\n        </button>\r\n      }\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\r\n        [attr.aria-label]=\"'Remove filter ' + describe(node).header + ' ' + describe(node).operator\"\r\n        (click)=\"removeNode.emit(childPath($index))\"\r\n      >\r\n        ✕\r\n      </button>\r\n    </span>\r\n  } @else {\r\n    <!--\r\n      A nested group — the parentheses.\r\n\r\n      🔴 **Also a drop target.** Dropping onto a group JOINS it, which is how a third rule reaches an\r\n      existing pair; dropping onto a rule pairs the two. Both read the same gesture and differ only\r\n      in what is underneath, which is why the mode is decided by the target rather than by the drag.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:items-center cws:gap-1.5 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-1.5 cws:py-1 cws:dark:border-slate-600\"\r\n      data-drop-mode=\"onto\"\r\n      [attr.data-drop-path]=\"pathAttr($index)\"\r\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\r\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\r\n      [class.cws:opacity-40]=\"isDragging($index)\"\r\n    >\r\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">(</span>\r\n\r\n      <cms-filter-chips\r\n        [columns]=\"columns()\"\r\n        [group]=\"asGroup(node)\"\r\n        [path]=\"childPath($index)\"\r\n        [markedPath]=\"markedPath()\"\r\n        [draggingPath]=\"draggingPath()\"\r\n        [dropTarget]=\"dropTarget()\"\r\n        [editingId]=\"editingId()\"\r\n        (removeNode)=\"removeNode.emit($event)\"\r\n        (toggleCombinator)=\"toggleCombinator.emit($event)\"\r\n        (markNode)=\"markNode.emit($event)\"\r\n        (editNode)=\"editNode.emit($event)\"\r\n        (ungroupNode)=\"ungroupNode.emit($event)\"\r\n      />\r\n\r\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">)</span>\r\n    </span>\r\n  }\r\n\r\n  @if (!last) {\r\n    <!--\r\n      The connector, and it is a BUTTON now (JFrisbie, 2026-09-10) — clicking it flips this group's\r\n      combinator.\r\n\r\n      ⚠ **One combinator governs a whole group**, so every connector in this row is the same control\r\n      shown more than once: clicking any of them flips them all. That is what the model holds, and\r\n      mixed logic comes from grouping rather than from per-position operators. Stated in the title so\r\n      the behaviour is not a surprise on a three-chip filter.\r\n\r\n      🔴 **It is also the insertion point between these two chips.** That space measured 52px and was\r\n      completely dead: nothing in it called `preventDefault` on `dragover`, so the browser refused\r\n      the drop and a chip released between two others simply went back where it came from. The\r\n      wrapper is what makes the gap a target; the button inside it still toggles on click.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:items-center cws:gap-1 cws:self-stretch\"\r\n      data-drop-gap\r\n      data-drop-mode=\"before\"\r\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\r\n    >\r\n      <!--\r\n        The same insertion bar the ends of the row carry, so all three gaps read alike: a bar means\r\n        \"it lands here\", a ring around a chip means \"it groups with that one\". One signal per\r\n        gesture — the chip used to carry a left border for `before` as well, which made a reorder\r\n        look like a group target on the chip next to the gap.\r\n\r\n        ⚠ Always present, colour-only — see the leading gap. Inserting this on `dragstart` put a new\r\n        node beside the chip being dragged and Chromium abandoned the drag.\r\n      -->\r\n      <span\r\n        class=\"cws:w-1.5 cws:self-stretch cws:rounded cws:transition-colors\"\r\n        [attr.aria-hidden]=\"true\"\r\n        [class]=\"gapClassFor($index + 1)\"\r\n      ></span>\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-[11px] cws:font-semibold cws:uppercase cws:text-slate-500 cws:transition-colors cws:hover:bg-scoular-blue cws:hover:text-white cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n        [title]=\"\r\n          'Switch this group to ' +\r\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND') +\r\n          ' — one connector governs the whole group'\r\n        \"\r\n        [attr.aria-label]=\"\r\n          'Switch this group from ' +\r\n          combinatorLabel() +\r\n          ' to ' +\r\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND')\r\n        \"\r\n        (click)=\"toggleCombinator.emit(path())\"\r\n      >\r\n        {{ combinatorLabel() }}\r\n      </button>\r\n    </span>\r\n  }\r\n\r\n  @if (last) {\r\n    <!--\r\n      The insertion point AFTER the last chip.\r\n\r\n      ⚠ Always present, colour-only — see the leading gap.\r\n\r\n      🔴 **Without it the end of the row is unreachable**, because every other target is an existing\r\n      node and \"before the last one\" still lands short of it. Its path is one past the end, which\r\n      `moveNode` accepts for a `before` drop precisely because that path names a gap rather than a\r\n      node. Padded to a hittable width for the reason given on the leading gap.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\r\n      data-drop-gap\r\n      data-drop-mode=\"before\"\r\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\r\n      [attr.aria-hidden]=\"true\"\r\n    >\r\n      <span\r\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\r\n        [class]=\"gapClassFor($index + 1)\"\r\n      ></span>\r\n    </span>\r\n  }\r\n}\r\n",
		dependencies: [{
			kind: "component",
			type: FilterChipsComponent,
			selector: "cms-filter-chips",
			inputs: [
				"columns",
				"group",
				"path",
				"markedPath",
				"draggingPath",
				"dropTarget",
				"editingId"
			],
			outputs: [
				"removeNode",
				"toggleCombinator",
				"markNode",
				"editNode",
				"ungroupNode"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: FilterChipsComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-filter-chips",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FilterChipsComponent],
			host: { class: "cws:contents" },
			template: "<!--\r\n  One level of the filter tree. A group renders `cms-filter-chips` again, which is what makes the\r\n  nesting arbitrary rather than a fixed number of hand-written levels.\r\n\r\n  ⚠ The host is `display: contents`, so these chips join their parent's flex row rather than forming\r\n  a box of their own. A nested group needs its own box — it draws the parentheses — so that one\r\n  wraps its children in a bordered span.\r\n-->\r\n@for (node of nodes(); track $index; let last = $last) {\r\n  @if ($first) {\r\n    <!--\r\n      The insertion point BEFORE the first chip, so a chip can be moved to the front.\r\n\r\n      🔴 **Rendered ALWAYS, never conditionally on the drag** (JFrisbie, 2026-09-14 — reported as\r\n      \"it shows this and doesn't let me drag it around\", in Chrome).\r\n\r\n      These gaps used to appear on `dragstart`, which inserts nodes **immediately beside the element\r\n      being dragged, inside the dragstart handler**. Chromium takes its drag image and starts its\r\n      native drag loop at the end of that handler, and a DOM mutation there aborts the drag: the\r\n      chip never follows the pointer, and the only visible result is the gaps themselves appearing —\r\n      exactly what the screenshot showed.\r\n\r\n      ⚠ **Measured, because it cannot be reproduced through Playwright**: its synthetic drag goes\r\n      through CDP and skips the drag-image capture, so it completed happily in both browsers while a\r\n      real mouse could not. What IS measurable is the cause — four DOM mutations during `dragstart`\r\n      before this change, zero after. That number is the regression test a browser cannot be.\r\n\r\n      So only the *colour* changes now. The space is reserved from first paint, which also means the\r\n      row does not reflow the instant a drag begins.\r\n\r\n      🔴 **Reordering lives in the gaps now, and grouping owns the chip.** It used to be split by\r\n      arithmetic inside the chip — outer quarter \"before\", middle \"onto\" — which made the common\r\n      gesture fail silently: a grouping drag that landed in the first quarter of the target was read\r\n      as a reorder, and a reorder onto your own neighbour is a no-op, so nothing happened at all.\r\n      See the component's own note on `onDragOver`.\r\n\r\n      ⚠ **The padding is the hit area, and it is deliberately much wider than the bar it draws.**\r\n      A drop is only permitted on an element that received a `dragover` and cancelled it, so a\r\n      target narrow enough to fall between two pointer samples is a target a quick flick misses\r\n      entirely — and the gesture then ends in nothing, which is the same silent failure this whole\r\n      change exists to remove. The bar stays 6px because that is what reads as an insertion point;\r\n      the span around it is 26px because that is what can be hit. The connectors need no such\r\n      padding, being ~46px already.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\r\n      data-drop-gap\r\n      data-drop-mode=\"before\"\r\n      [attr.data-drop-path]=\"pathAttr($index)\"\r\n      [attr.aria-hidden]=\"true\"\r\n    >\r\n      <span\r\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\r\n        [class]=\"gapClassFor($index)\"\r\n      ></span>\r\n    </span>\r\n  }\r\n\r\n  @if (isRule(node)) {\r\n    <!--\r\n      A chip.\r\n\r\n      🔴 **Draggable, focusable, double-clickable and hoverable.** `draggable` gives the mouse\r\n      gesture; `tabindex=\"0\"` plus the keydown handler gives the keyboard one; `dblclick` opens the\r\n      editor (JFrisbie, 2026-09-11) with Enter as its keyboard twin; the hover colour is what tells\r\n      someone the chip is a thing you can pick up at all, which a static label does not.\r\n    -->\r\n    <span\r\n      data-drop-mode=\"onto\"\r\n      [attr.data-drop-path]=\"pathAttr($index)\"\r\n      [attr.data-drag-path]=\"pathAttr($index)\"\r\n      tabindex=\"0\"\r\n      role=\"button\"\r\n      class=\"cws:inline-flex cws:cursor-grab cws:items-center cws:gap-1.5 cws:rounded cws:border cws:px-2 cws:py-1 cws:text-xs cws:transition-colors cws:focus:outline-none cws:focus-visible:ring-2 cws:focus-visible:ring-scoular-blue cws:active:cursor-grabbing\"\r\n      [class]=\"\r\n        isMarked($index) || isEditing(node)\r\n          ? 'cws:border-scoular-blue cws:bg-sky-100 cws:text-sky-900 cws:ring-1 cws:ring-scoular-blue cws:dark:bg-sky-900 cws:dark:text-sky-100'\r\n          : 'cws:border-transparent cws:bg-sky-50 cws:text-sky-900 cws:hover:border-sky-300 cws:hover:bg-sky-100 cws:dark:bg-sky-950/50 cws:dark:text-sky-200 cws:dark:hover:bg-sky-900/70'\r\n      \"\r\n      [class.cws:opacity-40]=\"isDragging($index)\"\r\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\r\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\r\n      [attr.aria-pressed]=\"isMarked($index)\"\r\n      title=\"Double-click to edit. Drag onto another filter to group them, or into the gap between two to reorder.\"\r\n      [attr.aria-label]=\"\r\n        describe(node).header +\r\n        ' ' +\r\n        describe(node).operator +\r\n        (describe(node).value === null ? '' : ' ' + describe(node).value) +\r\n        (isEditing(node) ? ' — being edited' : '') +\r\n        (isMarked($index) ? ' — marked for grouping' : '') +\r\n        '. Press Enter to edit, Space to mark for grouping, Delete to remove.'\r\n      \"\r\n      (dblclick)=\"editNode.emit(childPath($index))\"\r\n      (keydown)=\"onChipKeydown($index, $event)\"\r\n    >\r\n      <span class=\"cws:font-medium\">{{ describe(node).header }}</span>\r\n      <span class=\"cws:italic cws:opacity-80\">{{ describe(node).operator }}</span>\r\n      @if (describe(node).value !== null) {\r\n        <span class=\"cws:font-medium\">{{ describe(node).value }}</span>\r\n      }\r\n\r\n      @if (isUnknown(node)) {\r\n        <!--\r\n          A saved filter can name a column this grid no longer has. Such a rule matches NOTHING, so\r\n          the chip says so rather than looking like an ordinary filter that happens to return little.\r\n        -->\r\n        <span\r\n          class=\"cws:rounded cws:bg-amber-100 cws:px-1 cws:text-[10px] cws:font-semibold cws:text-amber-800 cws:dark:bg-amber-950 cws:dark:text-amber-300\"\r\n          title=\"This column is not in this grid, so this rule matches nothing.\"\r\n        >\r\n          not in grid\r\n        </span>\r\n      }\r\n\r\n      @if (nested()) {\r\n        <!--\r\n          Move out of the group — the keyboard's version of dragging the chip clear, and a target for\r\n          anyone who would rather click than drag.\r\n\r\n          🔴 **Only rendered inside a group**, because at the top level there is nothing to move out\r\n          of. That is also what keeps the chip uncluttered in the common case: the button appears\r\n          exactly when it has something to do.\r\n        -->\r\n        <button\r\n          type=\"button\"\r\n          class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\r\n          title=\"Move out of the group\"\r\n          [attr.aria-label]=\"\r\n            'Move ' + describe(node).header + ' ' + describe(node).operator + ' out of its group'\r\n          \"\r\n          (click)=\"ungroupNode.emit(childPath($index))\"\r\n        >\r\n          ⤴\r\n        </button>\r\n      }\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:rounded cws:px-0.5 cws:text-sky-700 cws:hover:bg-sky-200 cws:hover:text-sky-900 cws:dark:text-sky-300 cws:dark:hover:bg-sky-800\"\r\n        [attr.aria-label]=\"'Remove filter ' + describe(node).header + ' ' + describe(node).operator\"\r\n        (click)=\"removeNode.emit(childPath($index))\"\r\n      >\r\n        ✕\r\n      </button>\r\n    </span>\r\n  } @else {\r\n    <!--\r\n      A nested group — the parentheses.\r\n\r\n      🔴 **Also a drop target.** Dropping onto a group JOINS it, which is how a third rule reaches an\r\n      existing pair; dropping onto a rule pairs the two. Both read the same gesture and differ only\r\n      in what is underneath, which is why the mode is decided by the target rather than by the drag.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:items-center cws:gap-1.5 cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-1.5 cws:py-1 cws:dark:border-slate-600\"\r\n      data-drop-mode=\"onto\"\r\n      [attr.data-drop-path]=\"pathAttr($index)\"\r\n      [class.cws:ring-2]=\"dropModeFor($index) === 'onto'\"\r\n      [class.cws:ring-scoular-blue]=\"dropModeFor($index) === 'onto'\"\r\n      [class.cws:opacity-40]=\"isDragging($index)\"\r\n    >\r\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">(</span>\r\n\r\n      <cms-filter-chips\r\n        [columns]=\"columns()\"\r\n        [group]=\"asGroup(node)\"\r\n        [path]=\"childPath($index)\"\r\n        [markedPath]=\"markedPath()\"\r\n        [draggingPath]=\"draggingPath()\"\r\n        [dropTarget]=\"dropTarget()\"\r\n        [editingId]=\"editingId()\"\r\n        (removeNode)=\"removeNode.emit($event)\"\r\n        (toggleCombinator)=\"toggleCombinator.emit($event)\"\r\n        (markNode)=\"markNode.emit($event)\"\r\n        (editNode)=\"editNode.emit($event)\"\r\n        (ungroupNode)=\"ungroupNode.emit($event)\"\r\n      />\r\n\r\n      <span aria-hidden=\"true\" class=\"cws:font-mono cws:text-sm cws:text-slate-400\">)</span>\r\n    </span>\r\n  }\r\n\r\n  @if (!last) {\r\n    <!--\r\n      The connector, and it is a BUTTON now (JFrisbie, 2026-09-10) — clicking it flips this group's\r\n      combinator.\r\n\r\n      ⚠ **One combinator governs a whole group**, so every connector in this row is the same control\r\n      shown more than once: clicking any of them flips them all. That is what the model holds, and\r\n      mixed logic comes from grouping rather than from per-position operators. Stated in the title so\r\n      the behaviour is not a surprise on a three-chip filter.\r\n\r\n      🔴 **It is also the insertion point between these two chips.** That space measured 52px and was\r\n      completely dead: nothing in it called `preventDefault` on `dragover`, so the browser refused\r\n      the drop and a chip released between two others simply went back where it came from. The\r\n      wrapper is what makes the gap a target; the button inside it still toggles on click.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:items-center cws:gap-1 cws:self-stretch\"\r\n      data-drop-gap\r\n      data-drop-mode=\"before\"\r\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\r\n    >\r\n      <!--\r\n        The same insertion bar the ends of the row carry, so all three gaps read alike: a bar means\r\n        \"it lands here\", a ring around a chip means \"it groups with that one\". One signal per\r\n        gesture — the chip used to carry a left border for `before` as well, which made a reorder\r\n        look like a group target on the chip next to the gap.\r\n\r\n        ⚠ Always present, colour-only — see the leading gap. Inserting this on `dragstart` put a new\r\n        node beside the chip being dragged and Chromium abandoned the drag.\r\n      -->\r\n      <span\r\n        class=\"cws:w-1.5 cws:self-stretch cws:rounded cws:transition-colors\"\r\n        [attr.aria-hidden]=\"true\"\r\n        [class]=\"gapClassFor($index + 1)\"\r\n      ></span>\r\n\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:rounded cws:bg-slate-100 cws:px-1.5 cws:py-0.5 cws:text-[11px] cws:font-semibold cws:uppercase cws:text-slate-500 cws:transition-colors cws:hover:bg-scoular-blue cws:hover:text-white cws:dark:bg-slate-700 cws:dark:text-slate-300\"\r\n        [title]=\"\r\n          'Switch this group to ' +\r\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND') +\r\n          ' — one connector governs the whole group'\r\n        \"\r\n        [attr.aria-label]=\"\r\n          'Switch this group from ' +\r\n          combinatorLabel() +\r\n          ' to ' +\r\n          (combinatorLabel() === 'AND' ? 'OR' : 'AND')\r\n        \"\r\n        (click)=\"toggleCombinator.emit(path())\"\r\n      >\r\n        {{ combinatorLabel() }}\r\n      </button>\r\n    </span>\r\n  }\r\n\r\n  @if (last) {\r\n    <!--\r\n      The insertion point AFTER the last chip.\r\n\r\n      ⚠ Always present, colour-only — see the leading gap.\r\n\r\n      🔴 **Without it the end of the row is unreachable**, because every other target is an existing\r\n      node and \"before the last one\" still lands short of it. Its path is one past the end, which\r\n      `moveNode` accepts for a `before` drop precisely because that path names a gap rather than a\r\n      node. Padded to a hittable width for the reason given on the leading gap.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:select-none cws:items-stretch cws:self-stretch cws:px-2.5\"\r\n      data-drop-gap\r\n      data-drop-mode=\"before\"\r\n      [attr.data-drop-path]=\"pathAttr($index + 1)\"\r\n      [attr.aria-hidden]=\"true\"\r\n    >\r\n      <span\r\n        class=\"cws:w-1.5 cws:rounded cws:transition-colors\"\r\n        [class]=\"gapClassFor($index + 1)\"\r\n      ></span>\r\n    </span>\r\n  }\r\n}\r\n"
		}]
	}],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		group: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "group",
				required: true
			}]
		}],
		path: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "path",
				required: false
			}]
		}],
		markedPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "markedPath",
				required: false
			}]
		}],
		draggingPath: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "draggingPath",
				required: false
			}]
		}],
		dropTarget: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "dropTarget",
				required: false
			}]
		}],
		editingId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editingId",
				required: false
			}]
		}],
		removeNode: [{
			type: i0.Output,
			args: ["removeNode"]
		}],
		toggleCombinator: [{
			type: i0.Output,
			args: ["toggleCombinator"]
		}],
		markNode: [{
			type: i0.Output,
			args: ["markNode"]
		}],
		editNode: [{
			type: i0.Output,
			args: ["editNode"]
		}],
		ungroupNode: [{
			type: i0.Output,
			args: ["ungroupNode"]
		}]
	}
});
function parsePathAttr(attribute) {
	return attribute === null || attribute === "" ? [] : attribute.split(".").map(Number);
}
function dropUnder(x, y) {
	const zone = elementUnder(x, y, "[data-drop-mode]");
	if (zone === null) return null;
	const mode = zone.getAttribute("data-drop-mode");
	if (mode === "ungroup") return {
		path: [],
		mode: "ungroup"
	};
	if (mode !== "onto" && mode !== "before") return null;
	const path = parsePathAttr(zone.getAttribute("data-drop-path"));
	return path.length === 0 ? null : {
		path,
		mode
	};
}
var FilterBuilderComponent = class FilterBuilderComponent {
	columns = input.required(...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	filter = input(EMPTY_FILTER, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	showAddButton = input(true, ...ngDevMode ? [{ debugName: "showAddButton" }] : /* istanbul ignore next */ []);
	filterChange = output();
	activeConnector = "cws:bg-scoular-blue cws:text-white";
	inactiveConnector = "cws:bg-white cws:text-slate-600 cws:hover:bg-slate-50 cws:dark:bg-slate-700 cws:dark:text-slate-200 cws:dark:hover:bg-slate-600";
	editing = signal(null, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	rules = computed(() => this.filter().rules, ...ngDevMode ? [{ debugName: "rules" }] : /* istanbul ignore next */ []);
	combinator = computed(() => this.filter().combinator, ...ngDevMode ? [{ debugName: "combinator" }] : /* istanbul ignore next */ []);
	activeCount = computed(() => activeRuleCount(this.filter()), ...ngDevMode ? [{ debugName: "activeCount" }] : /* istanbul ignore next */ []);
	showChipsRow = computed(() => this.rules().length > 0 || this.showAddButton() && this.editing() === null, ...ngDevMode ? [{ debugName: "showChipsRow" }] : /* istanbul ignore next */ []);
	hasContent = computed(() => this.showAddButton() || this.rules().length > 0 || this.editing() !== null, ...ngDevMode ? [{ debugName: "hasContent" }] : /* istanbul ignore next */ []);
	showConnector = computed(() => {
		const draft = this.editing();
		const editingExisting = draft !== null && draft.id !== "";
		return activeRuleCount(this.filter()) - (editingExisting ? 1 : 0) > 0;
	}, ...ngDevMode ? [{ debugName: "showConnector" }] : /* istanbul ignore next */ []);
	editingId = computed(() => {
		const draft = this.editing();
		return draft !== null && draft.id !== "" ? draft.id : null;
	}, ...ngDevMode ? [{ debugName: "editingId" }] : /* istanbul ignore next */ []);
	byKey = computed(() => new Map(this.columns().map((column) => [column.key, column])), ...ngDevMode ? [{ debugName: "byKey" }] : /* istanbul ignore next */ []);
	columnOptions = computed(() => this.columns().map((column) => ({
		value: column.key,
		label: column.header
	})), ...ngDevMode ? [{ debugName: "columnOptions" }] : /* istanbul ignore next */ []);
	kindFor(columnKey) {
		return this.byKey().get(columnKey)?.filterKind ?? "text";
	}
	headerFor(rule) {
		return this.byKey().get(rule.columnKey)?.header ?? rule.columnKey;
	}
	operatorTextFor(rule) {
		return operatorLabel(this.kindFor(rule.columnKey), rule.operator);
	}
	showsValue(rule) {
		return needsValue(rule.operator);
	}
	isUnknown(rule) {
		return rule.columnKey !== "" && !this.byKey().has(rule.columnKey);
	}
	draftOperatorOptions = computed(() => {
		const draft = this.editing();
		if (draft === null) return [];
		const kind = this.kindFor(draft.columnKey);
		return operatorsFor(kind).map((operator) => ({
			value: operator,
			label: operatorLabel(kind, operator)
		}));
	}, ...ngDevMode ? [{ debugName: "draftOperatorOptions" }] : /* istanbul ignore next */ []);
	draftInputType = computed(() => {
		const kind = this.kindFor(this.editing()?.columnKey ?? "");
		return kind === "date" ? "date" : kind === "number" ? "number" : "text";
	}, ...ngDevMode ? [{ debugName: "draftInputType" }] : /* istanbul ignore next */ []);
	beginAdd() {
		const first = this.columns()[0];
		this.editing.set({
			id: "",
			columnKey: first?.key ?? "",
			operator: "contains",
			value: ""
		});
	}
	cancelDraft() {
		this.editing.set(null);
	}
	setDraftColumn(columnKey) {
		this.editing.update((draft) => {
			if (draft === null) return draft;
			const allowed = operatorsFor(this.kindFor(columnKey));
			return {
				...draft,
				columnKey,
				operator: allowed.includes(draft.operator) ? draft.operator : allowed[0]
			};
		});
	}
	setDraftOperator(operator) {
		this.editing.update((draft) => draft === null ? draft : {
			...draft,
			operator
		});
	}
	setDraftValue(value) {
		this.editing.update((draft) => draft === null ? draft : {
			...draft,
			value
		});
	}
	canCommit = computed(() => {
		const draft = this.editing();
		return draft !== null && isComplete(draft);
	}, ...ngDevMode ? [{ debugName: "canCommit" }] : /* istanbul ignore next */ []);
	commitDraft() {
		const draft = this.editing();
		if (draft === null || !isComplete(draft)) return;
		const existing = draft.id !== "";
		const committed = existing ? draft : {
			...draft,
			id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
		};
		this.emit({
			...this.filter(),
			rules: existing ? replaceRuleById(this.filter(), committed).rules : [...this.rules(), committed]
		});
		this.editing.set(null);
	}
	marked = signal(null, ...ngDevMode ? [{ debugName: "marked" }] : /* istanbul ignore next */ []);
	dragging = signal(null, ...ngDevMode ? [{ debugName: "dragging" }] : /* istanbul ignore next */ []);
	dropTarget = signal(null, ...ngDevMode ? [{ debugName: "dropTarget" }] : /* istanbul ignore next */ []);
	onRemove(path) {
		const target = nodeAt(this.filter(), path);
		const removedId = target !== null && isRuleNode(target) ? target.id : null;
		this.emit(normaliseGroup(removeAt(this.filter(), path)));
		this.clearGestures();
		if (removedId !== null && this.editing()?.id === removedId) this.editing.set(null);
	}
	onToggleCombinator(path) {
		this.emit(toggleCombinatorAt(this.filter(), path));
	}
	onMark(path) {
		const first = this.marked();
		if (first === null) {
			this.marked.set(path);
			return;
		}
		if (first.length === path.length && first.every((value, index) => value === path[index])) {
			this.marked.set(null);
			return;
		}
		this.emit(groupNodes(this.filter(), path, first));
		this.marked.set(null);
	}
	onEdit(path) {
		const node = nodeAt(this.filter(), path);
		if (node === null || !isRuleNode(node)) return;
		this.clearGestures();
		this.editing.set({ ...node });
	}
	onUngroup(path) {
		this.emit(ungroupAt(this.filter(), path));
		this.clearGestures();
	}
	draggingNested = computed(() => (this.dragging()?.length ?? 0) > 1, ...ngDevMode ? [{ debugName: "draggingNested" }] : /* istanbul ignore next */ []);
	gesture = new PointerDragGesture({
		handleSelector: "[data-drag-path]",
		source: (handle) => parsePathAttr(handle.getAttribute("data-drag-path")),
		target: dropUnder,
		started: (path) => this.dragging.set(path),
		over: (target) => this.dropTarget.set(target),
		ended: () => this.clearGestures(),
		dropped: (from, target) => {
			if (target.mode === "ungroup") {
				this.onUngroup(from);
				return;
			}
			this.applyDrop(from, {
				to: target.path,
				mode: target.mode
			});
		}
	});
	constructor() {
		inject(DestroyRef).onDestroy(() => this.gesture.cancel());
	}
	onPointerDown(event) {
		this.gesture.press(event);
	}
	applyDrop(from, drop) {
		const current = this.filter();
		const next = moveNode(current, from, drop.to, drop.mode);
		if (!sameGroup(next, current)) this.emit(next);
	}
	onEscape() {
		this.clearGestures();
	}
	clearGestures() {
		this.marked.set(null);
		this.dragging.set(null);
		this.dropTarget.set(null);
	}
	setCombinator(combinator) {
		this.emit({
			...this.filter(),
			combinator
		});
	}
	clear() {
		this.editing.set(null);
		this.clearGestures();
		this.emit(EMPTY_FILTER);
	}
	emit(group) {
		this.filterChange.emit(group);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FilterBuilderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: FilterBuilderComponent,
		isStandalone: true,
		selector: "cms-filter-builder",
		inputs: {
			columns: {
				classPropertyName: "columns",
				publicName: "columns",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			filter: {
				classPropertyName: "filter",
				publicName: "filter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showAddButton: {
				classPropertyName: "showAddButton",
				publicName: "showAddButton",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { filterChange: "filterChange" },
		host: {
			listeners: {
				"pointerdown": "onPointerDown($event)",
				"keydown.escape": "onEscape()"
			},
			properties: { "class.cws:block": "hasContent()" }
		},
		ngImport: i0,
		template: "@if (hasContent()) {\r\n<div class=\"cws:space-y-2\">\r\n  <!--\r\n    🔴 **The chips are a TREE now** (JFrisbie, 2026-09-10), rendered by `cms-filter-chips`, which\r\n    recurses. This row used to be a flat `@for` over rules with one connector for the whole set.\r\n\r\n    What that buys: `A AND (B OR C)`, built by dragging one chip onto another. The model was always\r\n    a tree away from allowing it — the old docstring said so — and this is the interface for it.\r\n  -->\r\n  @if (showChipsRow()) {\r\n  <!--\r\n    🔴 **`select-none` is load-bearing, and it is the whole of the Chrome drag defect**\r\n    (JFrisbie, 2026-09-14).\r\n\r\n    Dragging a chip leaves a text SELECTION across this row. Press inside that selection and\r\n    Chrome does not start our gesture at all -- it starts a native drag of the selected text, and\r\n    announces it by firing `pointercancel`, which correctly tears our gesture down. So the first\r\n    drag of a session worked and every one after it did nothing, and the row appeared stuck.\r\n\r\n    Measured, with a control: clearing the selection by hand between the two drags makes the\r\n    second one work, and `user-select: none` makes both work with nothing else changed.\r\n\r\n    ⚠ It is also why the same gesture failed under HTML5 drag-and-drop, which is what this row\r\n    used before: a press inside a selection drags the selection rather than the `draggable`\r\n    element, so the chip never lifted and the drag could not be cancelled. Two earlier fixes aimed\r\n    at DOM mutation during `dragstart`; that is a real Chromium rule and it was not this.\r\n\r\n    ⚠ The cost is that the chip text can no longer be selected for copying. Chips are controls\r\n    rather than prose, and the filter is in the URL, so nothing needs to be copied out of here.\r\n  -->\r\n  <div class=\"cws:flex cws:select-none cws:flex-wrap cws:items-center cws:gap-2\">\r\n    @if (activeCount() > 0) {\r\n      <!--\r\n        Clear all, with the count — the screenshot's own leading control. Destructive, so it wears\r\n        the danger colouring rather than looking like the neutral chips beside it.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:border-red-200 cws:px-2 cws:py-1 cws:text-xs cws:font-medium cws:text-red-700 cws:hover:bg-red-50 cws:dark:border-red-900 cws:dark:text-red-400 cws:dark:hover:bg-red-950/40\"\r\n        (click)=\"clear()\"\r\n      >\r\n        <span aria-hidden=\"true\">✕</span>\r\n        Clear all filters ({{ activeCount() }})\r\n      </button>\r\n    }\r\n\r\n    <cms-filter-chips\r\n      [columns]=\"columns()\"\r\n      [group]=\"filter()\"\r\n      [markedPath]=\"marked()\"\r\n      [draggingPath]=\"dragging()\"\r\n      [dropTarget]=\"dropTarget()\"\r\n      [editingId]=\"editingId()\"\r\n      (removeNode)=\"onRemove($event)\"\r\n      (toggleCombinator)=\"onToggleCombinator($event)\"\r\n      (markNode)=\"onMark($event)\"\r\n      (editNode)=\"onEdit($event)\"\r\n      (ungroupNode)=\"onUngroup($event)\"\r\n    />\r\n\r\n    <!--\r\n      The way OUT of a group, shown only while a chip that is inside one is being dragged.\r\n\r\n      Every other drop target is a node, so a filter whose chips are all inside one set of\r\n      parentheses had nowhere to aim -- there was no chip outside the group to drop before, and the\r\n      row read as permanently grouped.\r\n\r\n      ⚠ **`[hidden]`, not `@if`.** A hidden element is not returned by `elementFromPoint`, so it\r\n      cannot be hit while it does not apply -- which is the whole of the guard, and it costs no\r\n      structural change when a drag begins.\r\n\r\n      ⚠ **Its original reason is SUPERSEDED and is corrected rather than deleted.** This was written\r\n      as a fix for Chromium abandoning a native drag when the DOM changes inside `dragstart`. That is\r\n      a real rule and it was not the defect: the row no longer uses native drag at all, and the cause\r\n      was the text selection recorded on the chip row above. Kept as `[hidden]` on its own merits.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:items-center cws:rounded cws:border cws:border-dashed cws:border-scoular-blue cws:bg-sky-50 cws:px-3 cws:py-1 cws:text-xs cws:font-medium cws:text-scoular-blue cws:dark:bg-sky-950/40\"\r\n      data-drop-mode=\"ungroup\"\r\n      [hidden]=\"!draggingNested()\"\r\n      [class.cws:ring-2]=\"dropTarget()?.mode === 'ungroup'\"\r\n      [class.cws:ring-scoular-blue]=\"dropTarget()?.mode === 'ungroup'\"\r\n    >\r\n      Drop here to take it out of the group\r\n    </span>\r\n\r\n    @if (showAddButton() && !editing()) {\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:border-scoular-blue cws:hover:text-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-300\"\r\n        (click)=\"beginAdd()\"\r\n      >\r\n        + Add filter\r\n      </button>\r\n    }\r\n  </div>\r\n  }\r\n\r\n  <!--\r\n    What the chips can DO, which nothing else on screen says.\r\n\r\n    Double-click to edit is the line that has to be there: a chip looks like a label, and nothing\r\n    about it suggests it opens the editor. The grouping half appears only once a second chip exists,\r\n    because grouping needs two and before that it is an instruction for something impossible.\r\n\r\n    It is not decoration. Drag-and-drop is unreachable from a keyboard and \"fully keyboard operable\"\r\n    is a standing acceptance criterion here (docs/05): Space marks a chip and Space on a second\r\n    groups them, Enter opens the editor, and a chip inside a group carries its own Move out button.\r\n  -->\r\n  @if (activeCount() > 0) {\r\n    <p class=\"cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\r\n      @if (marked() !== null) {\r\n        <span class=\"cws:font-medium cws:text-scoular-blue\">One filter marked.</span>\r\n        Press Space on another to group them, or Escape to cancel.\r\n      } @else if (activeCount() > 1) {\r\n        Double-click a filter to edit it. Drag one onto another to group them, drop one between two\r\n        to reorder, or press Space on one and then on a second.\r\n      } @else {\r\n        Double-click a filter to edit it.\r\n      }\r\n    </p>\r\n  }\r\n\r\n  <!--\r\n    The editor row. Appears on \"+ Add filter\" and on editing a chip, and commits explicitly.\r\n\r\n    Laid out as the screenshot has it: Connect with · Field · Operator · Value · Add filter · Cancel,\r\n    each control under its own label.\r\n  -->\r\n  @if (editing(); as draft) {\r\n    <div\r\n      class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:dark:bg-slate-800/60\"\r\n      role=\"group\"\r\n      aria-label=\"Add a filter\"\r\n    >\r\n      <!--\r\n        🔴 **Only from the SECOND rule onward** (JFrisbie, 2026-09-10). AND/OR describes how a rule\r\n        combines with another rule, so on the first one the control asks a question with no\r\n        consequence — and whichever way it is answered then silently governs every rule added after.\r\n\r\n        See `showConnector`: it counts the rules OTHER than the one being edited, so picking up the\r\n        only chip to edit it hides the control again rather than offering the same empty choice.\r\n      -->\r\n      @if (showConnector()) {\r\n      <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n        <!--\r\n          ⚠ The caption is `sr-only` rather than removed. The AND/OR pair is a `role=\"group\"` whose\r\n          own `aria-label` says what it does, but the two buttons read as bare \"AND\" / \"OR\" without\r\n          something naming the choice they belong to.\r\n\r\n          The (i) hint that sat here was removed at JFrisbie's request (2026-09-10). Nothing asserted\r\n          it, and the group's label carries the same information to assistive technology.\r\n        -->\r\n        <span class=\"sr-only\">Connect with</span>\r\n\r\n        <div class=\"cws:flex cws:overflow-hidden cws:rounded cws:border cws:border-slate-300 cws:dark:border-slate-600\" role=\"group\" aria-label=\"How rules combine\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\r\n            [class]=\"combinator() === 'and' ? activeConnector : inactiveConnector\"\r\n            [attr.aria-pressed]=\"combinator() === 'and'\"\r\n            (click)=\"setCombinator('and')\"\r\n          >\r\n            AND\r\n          </button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\r\n            [class]=\"combinator() === 'or' ? activeConnector : inactiveConnector\"\r\n            [attr.aria-pressed]=\"combinator() === 'or'\"\r\n            (click)=\"setCombinator('or')\"\r\n          >\r\n            OR\r\n          </button>\r\n        </div>\r\n      </div>\r\n      }\r\n\r\n      <div class=\"cws:w-44\">\r\n        <cms-select\r\n          [options]=\"columnOptions()\"\r\n          [value]=\"draft.columnKey\"\r\n          label=\"Field\"\r\n          (valueChange)=\"setDraftColumn($event)\"\r\n        />\r\n      </div>\r\n\r\n      <div class=\"cws:w-40\">\r\n        <cms-select\r\n          [options]=\"draftOperatorOptions()\"\r\n          [value]=\"draft.operator\"\r\n          label=\"Operator\"\r\n          (valueChange)=\"setDraftOperator($event)\"\r\n        />\r\n      </div>\r\n\r\n      <!--\r\n        Hidden for `is blank` / `is not blank`, which take no value. A disabled box there would\r\n        invite someone to type into it and wonder why nothing changed.\r\n      -->\r\n      @if (showsValue(draft)) {\r\n        <label class=\"cws:w-44\">\r\n          <span class=\"sr-only\">Value</span>\r\n          <input\r\n            [type]=\"draftInputType()\"\r\n            class=\"scoular-form-input cws:w-full\"\r\n            autocomplete=\"off\"\r\n            placeholder=\"Enter value…\"\r\n            [value]=\"draft.value\"\r\n            (input)=\"setDraftValue($any($event.target).value)\"\r\n            (keydown.enter)=\"commitDraft()\"\r\n          />\r\n        </label>\r\n      }\r\n\r\n      <!--\r\n        ⚠ Add is disabled until the draft is complete, and `commitDraft` refuses a blank a second\r\n        time — the attribute is a courtesy, not a guarantee. A rule committed without a value would\r\n        sit in the chip row filtering nothing and reading as though it were.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n        [disabled]=\"!canCommit()\"\r\n        (click)=\"commitDraft()\"\r\n      >\r\n        {{ draft.id === '' ? 'Add filter' : 'Update filter' }}\r\n      </button>\r\n\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelDraft()\">\r\n        Cancel\r\n      </button>\r\n    </div>\r\n  }\r\n</div>\r\n}\r\n",
		dependencies: [{
			kind: "component",
			type: FilterChipsComponent,
			selector: "cms-filter-chips",
			inputs: [
				"columns",
				"group",
				"path",
				"markedPath",
				"draggingPath",
				"dropTarget",
				"editingId"
			],
			outputs: [
				"removeNode",
				"toggleCombinator",
				"markNode",
				"editNode",
				"ungroupNode"
			]
		}, {
			kind: "component",
			type: SelectComponent,
			selector: "cms-select",
			inputs: [
				"options",
				"value",
				"label",
				"labelledBy",
				"disabled"
			],
			outputs: ["valueChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: FilterBuilderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-filter-builder",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FilterChipsComponent, SelectComponent],
			host: {
				"(pointerdown)": "onPointerDown($event)",
				"[class.cws:block]": "hasContent()",
				"(keydown.escape)": "onEscape()"
			},
			template: "@if (hasContent()) {\r\n<div class=\"cws:space-y-2\">\r\n  <!--\r\n    🔴 **The chips are a TREE now** (JFrisbie, 2026-09-10), rendered by `cms-filter-chips`, which\r\n    recurses. This row used to be a flat `@for` over rules with one connector for the whole set.\r\n\r\n    What that buys: `A AND (B OR C)`, built by dragging one chip onto another. The model was always\r\n    a tree away from allowing it — the old docstring said so — and this is the interface for it.\r\n  -->\r\n  @if (showChipsRow()) {\r\n  <!--\r\n    🔴 **`select-none` is load-bearing, and it is the whole of the Chrome drag defect**\r\n    (JFrisbie, 2026-09-14).\r\n\r\n    Dragging a chip leaves a text SELECTION across this row. Press inside that selection and\r\n    Chrome does not start our gesture at all -- it starts a native drag of the selected text, and\r\n    announces it by firing `pointercancel`, which correctly tears our gesture down. So the first\r\n    drag of a session worked and every one after it did nothing, and the row appeared stuck.\r\n\r\n    Measured, with a control: clearing the selection by hand between the two drags makes the\r\n    second one work, and `user-select: none` makes both work with nothing else changed.\r\n\r\n    ⚠ It is also why the same gesture failed under HTML5 drag-and-drop, which is what this row\r\n    used before: a press inside a selection drags the selection rather than the `draggable`\r\n    element, so the chip never lifted and the drag could not be cancelled. Two earlier fixes aimed\r\n    at DOM mutation during `dragstart`; that is a real Chromium rule and it was not this.\r\n\r\n    ⚠ The cost is that the chip text can no longer be selected for copying. Chips are controls\r\n    rather than prose, and the filter is in the URL, so nothing needs to be copied out of here.\r\n  -->\r\n  <div class=\"cws:flex cws:select-none cws:flex-wrap cws:items-center cws:gap-2\">\r\n    @if (activeCount() > 0) {\r\n      <!--\r\n        Clear all, with the count — the screenshot's own leading control. Destructive, so it wears\r\n        the danger colouring rather than looking like the neutral chips beside it.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:inline-flex cws:items-center cws:gap-1 cws:rounded cws:border cws:border-red-200 cws:px-2 cws:py-1 cws:text-xs cws:font-medium cws:text-red-700 cws:hover:bg-red-50 cws:dark:border-red-900 cws:dark:text-red-400 cws:dark:hover:bg-red-950/40\"\r\n        (click)=\"clear()\"\r\n      >\r\n        <span aria-hidden=\"true\">✕</span>\r\n        Clear all filters ({{ activeCount() }})\r\n      </button>\r\n    }\r\n\r\n    <cms-filter-chips\r\n      [columns]=\"columns()\"\r\n      [group]=\"filter()\"\r\n      [markedPath]=\"marked()\"\r\n      [draggingPath]=\"dragging()\"\r\n      [dropTarget]=\"dropTarget()\"\r\n      [editingId]=\"editingId()\"\r\n      (removeNode)=\"onRemove($event)\"\r\n      (toggleCombinator)=\"onToggleCombinator($event)\"\r\n      (markNode)=\"onMark($event)\"\r\n      (editNode)=\"onEdit($event)\"\r\n      (ungroupNode)=\"onUngroup($event)\"\r\n    />\r\n\r\n    <!--\r\n      The way OUT of a group, shown only while a chip that is inside one is being dragged.\r\n\r\n      Every other drop target is a node, so a filter whose chips are all inside one set of\r\n      parentheses had nowhere to aim -- there was no chip outside the group to drop before, and the\r\n      row read as permanently grouped.\r\n\r\n      ⚠ **`[hidden]`, not `@if`.** A hidden element is not returned by `elementFromPoint`, so it\r\n      cannot be hit while it does not apply -- which is the whole of the guard, and it costs no\r\n      structural change when a drag begins.\r\n\r\n      ⚠ **Its original reason is SUPERSEDED and is corrected rather than deleted.** This was written\r\n      as a fix for Chromium abandoning a native drag when the DOM changes inside `dragstart`. That is\r\n      a real rule and it was not the defect: the row no longer uses native drag at all, and the cause\r\n      was the text selection recorded on the chip row above. Kept as `[hidden]` on its own merits.\r\n    -->\r\n    <span\r\n      class=\"cws:inline-flex cws:items-center cws:rounded cws:border cws:border-dashed cws:border-scoular-blue cws:bg-sky-50 cws:px-3 cws:py-1 cws:text-xs cws:font-medium cws:text-scoular-blue cws:dark:bg-sky-950/40\"\r\n      data-drop-mode=\"ungroup\"\r\n      [hidden]=\"!draggingNested()\"\r\n      [class.cws:ring-2]=\"dropTarget()?.mode === 'ungroup'\"\r\n      [class.cws:ring-scoular-blue]=\"dropTarget()?.mode === 'ungroup'\"\r\n    >\r\n      Drop here to take it out of the group\r\n    </span>\r\n\r\n    @if (showAddButton() && !editing()) {\r\n      <button\r\n        type=\"button\"\r\n        class=\"cws:rounded cws:border cws:border-dashed cws:border-slate-300 cws:px-3 cws:py-1.5 cws:text-sm cws:font-medium cws:text-slate-600 cws:hover:border-scoular-blue cws:hover:text-scoular-blue cws:dark:border-slate-600 cws:dark:text-slate-300\"\r\n        (click)=\"beginAdd()\"\r\n      >\r\n        + Add filter\r\n      </button>\r\n    }\r\n  </div>\r\n  }\r\n\r\n  <!--\r\n    What the chips can DO, which nothing else on screen says.\r\n\r\n    Double-click to edit is the line that has to be there: a chip looks like a label, and nothing\r\n    about it suggests it opens the editor. The grouping half appears only once a second chip exists,\r\n    because grouping needs two and before that it is an instruction for something impossible.\r\n\r\n    It is not decoration. Drag-and-drop is unreachable from a keyboard and \"fully keyboard operable\"\r\n    is a standing acceptance criterion here (docs/05): Space marks a chip and Space on a second\r\n    groups them, Enter opens the editor, and a chip inside a group carries its own Move out button.\r\n  -->\r\n  @if (activeCount() > 0) {\r\n    <p class=\"cws:text-[11px] cws:text-slate-500 cws:dark:text-slate-400\">\r\n      @if (marked() !== null) {\r\n        <span class=\"cws:font-medium cws:text-scoular-blue\">One filter marked.</span>\r\n        Press Space on another to group them, or Escape to cancel.\r\n      } @else if (activeCount() > 1) {\r\n        Double-click a filter to edit it. Drag one onto another to group them, drop one between two\r\n        to reorder, or press Space on one and then on a second.\r\n      } @else {\r\n        Double-click a filter to edit it.\r\n      }\r\n    </p>\r\n  }\r\n\r\n  <!--\r\n    The editor row. Appears on \"+ Add filter\" and on editing a chip, and commits explicitly.\r\n\r\n    Laid out as the screenshot has it: Connect with · Field · Operator · Value · Add filter · Cancel,\r\n    each control under its own label.\r\n  -->\r\n  @if (editing(); as draft) {\r\n    <div\r\n      class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-2 cws:rounded cws:bg-slate-50 cws:px-3 cws:py-2 cws:dark:bg-slate-800/60\"\r\n      role=\"group\"\r\n      aria-label=\"Add a filter\"\r\n    >\r\n      <!--\r\n        🔴 **Only from the SECOND rule onward** (JFrisbie, 2026-09-10). AND/OR describes how a rule\r\n        combines with another rule, so on the first one the control asks a question with no\r\n        consequence — and whichever way it is answered then silently governs every rule added after.\r\n\r\n        See `showConnector`: it counts the rules OTHER than the one being edited, so picking up the\r\n        only chip to edit it hides the control again rather than offering the same empty choice.\r\n      -->\r\n      @if (showConnector()) {\r\n      <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n        <!--\r\n          ⚠ The caption is `sr-only` rather than removed. The AND/OR pair is a `role=\"group\"` whose\r\n          own `aria-label` says what it does, but the two buttons read as bare \"AND\" / \"OR\" without\r\n          something naming the choice they belong to.\r\n\r\n          The (i) hint that sat here was removed at JFrisbie's request (2026-09-10). Nothing asserted\r\n          it, and the group's label carries the same information to assistive technology.\r\n        -->\r\n        <span class=\"sr-only\">Connect with</span>\r\n\r\n        <div class=\"cws:flex cws:overflow-hidden cws:rounded cws:border cws:border-slate-300 cws:dark:border-slate-600\" role=\"group\" aria-label=\"How rules combine\">\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\r\n            [class]=\"combinator() === 'and' ? activeConnector : inactiveConnector\"\r\n            [attr.aria-pressed]=\"combinator() === 'and'\"\r\n            (click)=\"setCombinator('and')\"\r\n          >\r\n            AND\r\n          </button>\r\n          <button\r\n            type=\"button\"\r\n            class=\"cws:px-3 cws:py-2 cws:text-sm cws:font-medium\"\r\n            [class]=\"combinator() === 'or' ? activeConnector : inactiveConnector\"\r\n            [attr.aria-pressed]=\"combinator() === 'or'\"\r\n            (click)=\"setCombinator('or')\"\r\n          >\r\n            OR\r\n          </button>\r\n        </div>\r\n      </div>\r\n      }\r\n\r\n      <div class=\"cws:w-44\">\r\n        <cms-select\r\n          [options]=\"columnOptions()\"\r\n          [value]=\"draft.columnKey\"\r\n          label=\"Field\"\r\n          (valueChange)=\"setDraftColumn($event)\"\r\n        />\r\n      </div>\r\n\r\n      <div class=\"cws:w-40\">\r\n        <cms-select\r\n          [options]=\"draftOperatorOptions()\"\r\n          [value]=\"draft.operator\"\r\n          label=\"Operator\"\r\n          (valueChange)=\"setDraftOperator($event)\"\r\n        />\r\n      </div>\r\n\r\n      <!--\r\n        Hidden for `is blank` / `is not blank`, which take no value. A disabled box there would\r\n        invite someone to type into it and wonder why nothing changed.\r\n      -->\r\n      @if (showsValue(draft)) {\r\n        <label class=\"cws:w-44\">\r\n          <span class=\"sr-only\">Value</span>\r\n          <input\r\n            [type]=\"draftInputType()\"\r\n            class=\"scoular-form-input cws:w-full\"\r\n            autocomplete=\"off\"\r\n            placeholder=\"Enter value…\"\r\n            [value]=\"draft.value\"\r\n            (input)=\"setDraftValue($any($event.target).value)\"\r\n            (keydown.enter)=\"commitDraft()\"\r\n          />\r\n        </label>\r\n      }\r\n\r\n      <!--\r\n        ⚠ Add is disabled until the draft is complete, and `commitDraft` refuses a blank a second\r\n        time — the attribute is a courtesy, not a guarantee. A rule committed without a value would\r\n        sit in the chip row filtering nothing and reading as though it were.\r\n      -->\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary cws:border cws:border-transparent\"\r\n        [disabled]=\"!canCommit()\"\r\n        (click)=\"commitDraft()\"\r\n      >\r\n        {{ draft.id === '' ? 'Add filter' : 'Update filter' }}\r\n      </button>\r\n\r\n      <button type=\"button\" class=\"scoular-btn scoular-btn-secondary\" (click)=\"cancelDraft()\">\r\n        Cancel\r\n      </button>\r\n    </div>\r\n  }\r\n</div>\r\n}\r\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		columns: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "columns",
				required: true
			}]
		}],
		filter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: false
			}]
		}],
		showAddButton: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showAddButton",
				required: false
			}]
		}],
		filterChange: [{
			type: i0.Output,
			args: ["filterChange"]
		}]
	}
});
var FilterSelectComponent = class FilterSelectComponent {
	store = inject(SAVED_FILTER_STORE);
	scope = input.required(...ngDevMode ? [{ debugName: "scope" }] : /* istanbul ignore next */ []);
	filter = input.required(...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	sorts = input.required(...ngDevMode ? [{ debugName: "sorts" }] : /* istanbul ignore next */ []);
	baselineLabel = input("All Open Contracts", ...ngDevMode ? [{ debugName: "baselineLabel" }] : /* istanbul ignore next */ []);
	viewChange = output();
	panel = signal("list", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	draftName = signal("", ...ngDevMode ? [{ debugName: "draftName" }] : /* istanbul ignore next */ []);
	includeSort = signal(false, ...ngDevMode ? [{ debugName: "includeSort" }] : /* istanbul ignore next */ []);
	savedFilters = computed(() => {
		this.store.revision();
		return this.store.list(this.scope());
	}, ...ngDevMode ? [{ debugName: "savedFilters" }] : /* istanbul ignore next */ []);
	defaultId = computed(() => {
		this.store.revision();
		return this.store.defaultId(this.scope());
	}, ...ngDevMode ? [{ debugName: "defaultId" }] : /* istanbul ignore next */ []);
	activeFilter = computed(() => {
		const candidates = this.savedFilters().filter((saved) => sameGroup(saved.group, this.filter()));
		if (candidates.length <= 1) return candidates[0] ?? null;
		const sorts = this.sorts();
		return candidates.find((saved) => sameSortChain(saved.sort ?? [], sorts)) ?? candidates[0];
	}, ...ngDevMode ? [{ debugName: "activeFilter" }] : /* istanbul ignore next */ []);
	isCustom = computed(() => this.activeFilter() === null && activeRuleCount(this.filter()) > 0, ...ngDevMode ? [{ debugName: "isCustom" }] : /* istanbul ignore next */ []);
	label = computed(() => {
		const active = this.activeFilter();
		if (active !== null) return active.name;
		return this.isCustom() ? "Custom view" : this.baselineLabel();
	}, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	adHocCount = computed(() => this.isCustom() ? activeRuleCount(this.filter()) : 0, ...ngDevMode ? [{ debugName: "adHocCount" }] : /* istanbul ignore next */ []);
	sortSummary = computed(() => {
		const sorts = this.sorts();
		return sorts.length === 0 ? "currently unsorted" : sorts.map((sort) => `${sort.key} ${sort.direction === "asc" ? "asc" : "desc"}`).join(", ");
	}, ...ngDevMode ? [{ debugName: "sortSummary" }] : /* istanbul ignore next */ []);
	canSave = computed(() => this.draftName().trim().length > 0, ...ngDevMode ? [{ debugName: "canSave" }] : /* istanbul ignore next */ []);
	openSave() {
		this.draftName.set(this.activeFilter()?.name ?? "");
		this.includeSort.set(this.sorts().length > 0);
		this.panel.set("save");
	}
	openManage() {
		this.panel.set("manage");
	}
	backToList() {
		this.panel.set("list");
	}
	reset() {
		this.panel.set("list");
		this.draftName.set("");
	}
	apply(saved) {
		this.viewChange.emit(saved === null ? {
			group: {
				combinator: "and",
				rules: []
			},
			sort: []
		} : {
			group: saved.group,
			sort: saved.sort ?? []
		});
	}
	commitSave() {
		if (!this.canSave()) return;
		this.store.save(this.scope(), this.draftName(), this.filter(), this.includeSort() ? this.sorts() : void 0);
		this.reset();
	}
	remove(saved) {
		this.store.remove(this.scope(), saved.id);
	}
	toggleDefault(saved) {
		this.store.setDefault(this.scope(), this.defaultId() === saved.id ? null : saved.id);
	}
	onNameInput(value) {
		this.draftName.set(value);
	}
	onIncludeSortChange(checked) {
		this.includeSort.set(checked);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: FilterSelectComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: FilterSelectComponent,
		isStandalone: true,
		selector: "cms-filter-select",
		inputs: {
			scope: {
				classPropertyName: "scope",
				publicName: "scope",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			filter: {
				classPropertyName: "filter",
				publicName: "filter",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			sorts: {
				classPropertyName: "sorts",
				publicName: "sorts",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			baselineLabel: {
				classPropertyName: "baselineLabel",
				publicName: "baselineLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { viewChange: "viewChange" },
		ngImport: i0,
		template: "<!--\r\n  The view selector. Sits where the Status dropdown used to (JFrisbie, 2026-09-10).\r\n\r\n  🔴 A disclosure, not a `role=\"menu\"`. Two of the three panels contain a form — a name box, a\r\n  checkbox, a Save button — and menu semantics promise arrow-key item navigation that a form inside\r\n  breaks. `aria-expanded` + `aria-controls` on the trigger describes what this actually is.\r\n-->\r\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:flex-col cws:gap-1\">\r\n  <span id=\"view-select-label\" class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n    View\r\n  </span>\r\n\r\n  <!--\r\n    `scoular-form-input` for the box model, so this matches the search box's height exactly without a\r\n    hard-coded pixel value.\r\n\r\n    ⚠ That class is `@apply w-full`, so a `w-56` here would be overridden — the design system compiles\r\n    unlayered and beats a Tailwind utility at equal specificity. The width goes on the wrapper this\r\n    component is placed in, where nothing contests it. Seventh instance of that trap.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"scoular-form-input cws:flex cws:w-full cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\r\n    aria-haspopup=\"true\"\r\n    aria-controls=\"view-select-panel\"\r\n    aria-labelledby=\"view-select-label\"\r\n    [attr.aria-expanded]=\"menu.open()\"\r\n    (click)=\"menu.toggle(); reset()\"\r\n  >\r\n    <span class=\"truncate\">\r\n      {{ label() }}\r\n      @if (adHocCount() > 0) {\r\n        <!--\r\n          The qualifier beside \"Custom view\". The name already says the grid is filtered; this says\r\n          by how much, which is what tells someone whether the chips below are all of it.\r\n        -->\r\n        <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n          · {{ adHocCount() }} {{ adHocCount() === 1 ? 'filter' : 'filters' }}\r\n        </span>\r\n      }\r\n    </span>\r\n    <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-slate-400\">▾</span>\r\n  </button>\r\n\r\n  @if (menu.open()) {\r\n    <div\r\n      id=\"view-select-panel\"\r\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:w-80 cws:p-2\"\r\n      [attr.aria-label]=\"panel() === 'manage' ? 'Manage filters' : 'Views'\"\r\n    >\r\n      @switch (panel()) {\r\n        @case ('list') {\r\n          <ul class=\"cws:space-y-1\">\r\n            <li>\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\r\n                (click)=\"menu.close(); apply(null)\"\r\n              >\r\n                <!--\r\n                  ⚠ Ticked only when the grid really is unfiltered. `activeFilter() === null` is\r\n                  true of a custom view too, so ticking on that alone would mark the baseline as\r\n                  selected while the grid showed a filtered set — and selecting it would then look\r\n                  like a no-op rather than the way back to everything.\r\n                -->\r\n                <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\r\n                  {{ activeFilter() === null && !isCustom() ? '✓' : '' }}\r\n                </span>\r\n                <span class=\"cws:flex-1\">{{ baselineLabel() }}</span>\r\n              </button>\r\n            </li>\r\n\r\n            @if (savedFilters().length > 0) {\r\n              <li aria-hidden=\"true\"><div class=\"scoular-dropdown-divider\"></div></li>\r\n            }\r\n\r\n            @for (saved of savedFilters(); track saved.id) {\r\n              <li>\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\r\n                  (click)=\"menu.close(); apply(saved)\"\r\n                >\r\n                  <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\r\n                    {{ activeFilter()?.id === saved.id ? '✓' : '' }}\r\n                  </span>\r\n                  <span class=\"cws:flex-1 truncate\">{{ saved.name }}</span>\r\n                  @if (defaultId() === saved.id) {\r\n                    <!--\r\n                      The star is the only place the default is visible from the list. Titled rather\r\n                      than left to be inferred: a marked row with no explanation reads as decoration.\r\n                    -->\r\n                    <span\r\n                      class=\"cws:shrink-0 cws:text-amber-500\"\r\n                      title=\"Applied automatically when you open this screen\"\r\n                      >★</span\r\n                    >\r\n                  }\r\n                  @if (saved.sort !== undefined) {\r\n                    <span\r\n                      class=\"cws:shrink-0 cws:text-[11px] cws:text-slate-400 cws:dark:text-slate-500\"\r\n                      title=\"Selecting this view also sets its sorting\"\r\n                      >sorted</span\r\n                    >\r\n                  }\r\n                </button>\r\n              </li>\r\n            }\r\n          </ul>\r\n\r\n          <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n          <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n            <button\r\n              type=\"button\"\r\n              class=\"scoular-dropdown-item cws:flex-1 cws:text-left\"\r\n              (click)=\"openSave()\"\r\n            >\r\n              + Save current filter…\r\n            </button>\r\n\r\n            <!--\r\n              The gear, per the ask. `title` gives the hover text and `aria-label` gives it a name —\r\n              both, because a `title` alone is not an accessible name and an icon-only control with\r\n              neither is unreachable by anything but a mouse.\r\n            -->\r\n            <button\r\n              type=\"button\"\r\n              class=\"cws:rounded cws:px-2 cws:py-1 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700\"\r\n              title=\"Manage filters\"\r\n              aria-label=\"Manage filters\"\r\n              (click)=\"openManage()\"\r\n            >\r\n              ⚙\r\n            </button>\r\n          </div>\r\n\r\n          <!--\r\n            🔴 Not boilerplate. These live in this browser's `localStorage` — there is no preferences\r\n            endpoint — so they do NOT follow the user to another machine or profile, and clearing site\r\n            data loses them. Someone who names a view will look for it again, and finding it missing\r\n            on a second machine reads as the feature being broken.\r\n          -->\r\n          <p class=\"cws:px-2 cws:pt-1 cws:text-[11px] cws:text-slate-400 cws:dark:text-slate-500\">\r\n            Saved for you, in this browser only.\r\n          </p>\r\n        }\r\n\r\n        @case ('save') {\r\n          <p class=\"cws:px-2 cws:pb-2 cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Save current filter\r\n          </p>\r\n\r\n          <div class=\"cws:space-y-2 cws:px-2\">\r\n            <label class=\"cws:flex cws:flex-col cws:gap-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Name</span>\r\n              <input\r\n                type=\"text\"\r\n                class=\"scoular-form-input cws:w-full\"\r\n                placeholder=\"My unpriced corn\"\r\n                [value]=\"draftName()\"\r\n                (input)=\"onNameInput($any($event.target).value)\"\r\n                (keydown.enter)=\"commitSave()\"\r\n              />\r\n            </label>\r\n\r\n            <!--\r\n              The sorting checkbox, per the ask.\r\n\r\n              ⚠ Checked by default only when something IS sorted. Saving an empty sort chain is\r\n              legitimate — it makes selecting the view *clear* the sort — but it is not what someone\r\n              means when they name a view on an unsorted grid, and a checkbox that silently arms that\r\n              would make an unrelated view reset the user's sorting later.\r\n            -->\r\n            <label class=\"cws:flex cws:items-start cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n              <input\r\n                type=\"checkbox\"\r\n                class=\"cws:mt-0.5\"\r\n                [checked]=\"includeSort()\"\r\n                (change)=\"onIncludeSortChange($any($event.target).checked)\"\r\n              />\r\n              <span>\r\n                Also save the sorting\r\n                <span class=\"cws:text-slate-400 cws:dark:text-slate-500\">({{ sortSummary() }})</span>\r\n              </span>\r\n            </label>\r\n\r\n            @if (activeFilter(); as active) {\r\n              <p class=\"cws:text-[11px] cws:text-amber-700 cws:dark:text-amber-500\">\r\n                Saving under the name “{{ active.name }}” replaces that view.\r\n              </p>\r\n            }\r\n          </div>\r\n\r\n          <div class=\"cws:mt-2 cws:flex cws:justify-end cws:gap-2 cws:px-2\">\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-outline\" (click)=\"backToList()\">\r\n              Cancel\r\n            </button>\r\n            <button\r\n              type=\"button\"\r\n              class=\"scoular-btn scoular-btn-primary\"\r\n              [disabled]=\"!canSave()\"\r\n              (click)=\"commitSave()\"\r\n            >\r\n              Save\r\n            </button>\r\n          </div>\r\n        }\r\n\r\n        @case ('manage') {\r\n          <div class=\"cws:flex cws:items-center cws:justify-between cws:px-2 cws:pb-2\">\r\n            <p class=\"cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">Manage filters</p>\r\n            <button\r\n              type=\"button\"\r\n              class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\r\n              (click)=\"backToList()\"\r\n            >\r\n              Back\r\n            </button>\r\n          </div>\r\n\r\n          @if (savedFilters().length === 0) {\r\n            <p class=\"cws:px-2 cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Nothing saved yet.</p>\r\n          } @else {\r\n            <ul class=\"cws:space-y-1\">\r\n              @for (saved of savedFilters(); track saved.id) {\r\n                <li class=\"cws:flex cws:items-center cws:gap-1 cws:px-1\">\r\n                  <!--\r\n                    A toggle rather than a radio group with a fourth \"none\" row: the star that makes a\r\n                    view the default also clears it, and a list of filters stays a list of filters.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\r\n                    [class.cws:text-amber-500]=\"defaultId() === saved.id\"\r\n                    [class.cws:text-slate-400]=\"defaultId() !== saved.id\"\r\n                    [attr.aria-pressed]=\"defaultId() === saved.id\"\r\n                    [title]=\"\r\n                      defaultId() === saved.id\r\n                        ? 'Stop applying this on load'\r\n                        : 'Apply this automatically on load'\r\n                    \"\r\n                    [attr.aria-label]=\"\r\n                      (defaultId() === saved.id ? 'Unset default filter ' : 'Set default filter ') +\r\n                      saved.name\r\n                    \"\r\n                    (click)=\"toggleDefault(saved)\"\r\n                  >\r\n                    ★\r\n                  </button>\r\n\r\n                  <span class=\"cws:flex-1 truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                    {{ saved.name }}\r\n                  </span>\r\n\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-red-700 cws:dark:hover:bg-slate-700\"\r\n                    [attr.aria-label]=\"'Delete saved filter ' + saved.name\"\r\n                    title=\"Delete\"\r\n                    (click)=\"remove(saved)\"\r\n                  >\r\n                    ✕\r\n                  </button>\r\n                </li>\r\n              }\r\n            </ul>\r\n\r\n            <p class=\"cws:px-2 cws:pt-2 cws:text-[11px] cws:text-slate-400 cws:dark:text-slate-500\">\r\n              ★ marks the view applied when you open this screen.\r\n            </p>\r\n          }\r\n        }\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
		dependencies: [{
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: FilterSelectComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-filter-select",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownDirective],
			template: "<!--\r\n  The view selector. Sits where the Status dropdown used to (JFrisbie, 2026-09-10).\r\n\r\n  🔴 A disclosure, not a `role=\"menu\"`. Two of the three panels contain a form — a name box, a\r\n  checkbox, a Save button — and menu semantics promise arrow-key item navigation that a form inside\r\n  breaks. `aria-expanded` + `aria-controls` on the trigger describes what this actually is.\r\n-->\r\n<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:flex-col cws:gap-1\">\r\n  <span id=\"view-select-label\" class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">\r\n    View\r\n  </span>\r\n\r\n  <!--\r\n    `scoular-form-input` for the box model, so this matches the search box's height exactly without a\r\n    hard-coded pixel value.\r\n\r\n    ⚠ That class is `@apply w-full`, so a `w-56` here would be overridden — the design system compiles\r\n    unlayered and beats a Tailwind utility at equal specificity. The width goes on the wrapper this\r\n    component is placed in, where nothing contests it. Seventh instance of that trap.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"scoular-form-input cws:flex cws:w-full cws:items-center cws:justify-between cws:gap-2 cws:text-left\"\r\n    aria-haspopup=\"true\"\r\n    aria-controls=\"view-select-panel\"\r\n    aria-labelledby=\"view-select-label\"\r\n    [attr.aria-expanded]=\"menu.open()\"\r\n    (click)=\"menu.toggle(); reset()\"\r\n  >\r\n    <span class=\"truncate\">\r\n      {{ label() }}\r\n      @if (adHocCount() > 0) {\r\n        <!--\r\n          The qualifier beside \"Custom view\". The name already says the grid is filtered; this says\r\n          by how much, which is what tells someone whether the chips below are all of it.\r\n        -->\r\n        <span class=\"cws:text-slate-500 cws:dark:text-slate-400\">\r\n          · {{ adHocCount() }} {{ adHocCount() === 1 ? 'filter' : 'filters' }}\r\n        </span>\r\n      }\r\n    </span>\r\n    <span aria-hidden=\"true\" class=\"cws:shrink-0 cws:text-slate-400\">▾</span>\r\n  </button>\r\n\r\n  @if (menu.open()) {\r\n    <div\r\n      id=\"view-select-panel\"\r\n      class=\"scoular-dropdown cws:left-0 cws:top-full cws:w-80 cws:p-2\"\r\n      [attr.aria-label]=\"panel() === 'manage' ? 'Manage filters' : 'Views'\"\r\n    >\r\n      @switch (panel()) {\r\n        @case ('list') {\r\n          <ul class=\"cws:space-y-1\">\r\n            <li>\r\n              <button\r\n                type=\"button\"\r\n                class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\r\n                (click)=\"menu.close(); apply(null)\"\r\n              >\r\n                <!--\r\n                  ⚠ Ticked only when the grid really is unfiltered. `activeFilter() === null` is\r\n                  true of a custom view too, so ticking on that alone would mark the baseline as\r\n                  selected while the grid showed a filtered set — and selecting it would then look\r\n                  like a no-op rather than the way back to everything.\r\n                -->\r\n                <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\r\n                  {{ activeFilter() === null && !isCustom() ? '✓' : '' }}\r\n                </span>\r\n                <span class=\"cws:flex-1\">{{ baselineLabel() }}</span>\r\n              </button>\r\n            </li>\r\n\r\n            @if (savedFilters().length > 0) {\r\n              <li aria-hidden=\"true\"><div class=\"scoular-dropdown-divider\"></div></li>\r\n            }\r\n\r\n            @for (saved of savedFilters(); track saved.id) {\r\n              <li>\r\n                <button\r\n                  type=\"button\"\r\n                  class=\"scoular-dropdown-item cws:flex cws:w-full cws:items-center cws:gap-2 cws:text-left\"\r\n                  (click)=\"menu.close(); apply(saved)\"\r\n                >\r\n                  <span class=\"cws:w-4 cws:shrink-0 cws:text-scoular-blue\">\r\n                    {{ activeFilter()?.id === saved.id ? '✓' : '' }}\r\n                  </span>\r\n                  <span class=\"cws:flex-1 truncate\">{{ saved.name }}</span>\r\n                  @if (defaultId() === saved.id) {\r\n                    <!--\r\n                      The star is the only place the default is visible from the list. Titled rather\r\n                      than left to be inferred: a marked row with no explanation reads as decoration.\r\n                    -->\r\n                    <span\r\n                      class=\"cws:shrink-0 cws:text-amber-500\"\r\n                      title=\"Applied automatically when you open this screen\"\r\n                      >★</span\r\n                    >\r\n                  }\r\n                  @if (saved.sort !== undefined) {\r\n                    <span\r\n                      class=\"cws:shrink-0 cws:text-[11px] cws:text-slate-400 cws:dark:text-slate-500\"\r\n                      title=\"Selecting this view also sets its sorting\"\r\n                      >sorted</span\r\n                    >\r\n                  }\r\n                </button>\r\n              </li>\r\n            }\r\n          </ul>\r\n\r\n          <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n          <div class=\"cws:flex cws:items-center cws:gap-1\">\r\n            <button\r\n              type=\"button\"\r\n              class=\"scoular-dropdown-item cws:flex-1 cws:text-left\"\r\n              (click)=\"openSave()\"\r\n            >\r\n              + Save current filter…\r\n            </button>\r\n\r\n            <!--\r\n              The gear, per the ask. `title` gives the hover text and `aria-label` gives it a name —\r\n              both, because a `title` alone is not an accessible name and an icon-only control with\r\n              neither is unreachable by anything but a mouse.\r\n            -->\r\n            <button\r\n              type=\"button\"\r\n              class=\"cws:rounded cws:px-2 cws:py-1 cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-scoular-blue cws:dark:text-slate-400 cws:dark:hover:bg-slate-700\"\r\n              title=\"Manage filters\"\r\n              aria-label=\"Manage filters\"\r\n              (click)=\"openManage()\"\r\n            >\r\n              ⚙\r\n            </button>\r\n          </div>\r\n\r\n          <!--\r\n            🔴 Not boilerplate. These live in this browser's `localStorage` — there is no preferences\r\n            endpoint — so they do NOT follow the user to another machine or profile, and clearing site\r\n            data loses them. Someone who names a view will look for it again, and finding it missing\r\n            on a second machine reads as the feature being broken.\r\n          -->\r\n          <p class=\"cws:px-2 cws:pt-1 cws:text-[11px] cws:text-slate-400 cws:dark:text-slate-500\">\r\n            Saved for you, in this browser only.\r\n          </p>\r\n        }\r\n\r\n        @case ('save') {\r\n          <p class=\"cws:px-2 cws:pb-2 cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">\r\n            Save current filter\r\n          </p>\r\n\r\n          <div class=\"cws:space-y-2 cws:px-2\">\r\n            <label class=\"cws:flex cws:flex-col cws:gap-1\">\r\n              <span class=\"cws:text-xs cws:font-medium cws:text-slate-600 cws:dark:text-slate-300\">Name</span>\r\n              <input\r\n                type=\"text\"\r\n                class=\"scoular-form-input cws:w-full\"\r\n                placeholder=\"My unpriced corn\"\r\n                [value]=\"draftName()\"\r\n                (input)=\"onNameInput($any($event.target).value)\"\r\n                (keydown.enter)=\"commitSave()\"\r\n              />\r\n            </label>\r\n\r\n            <!--\r\n              The sorting checkbox, per the ask.\r\n\r\n              ⚠ Checked by default only when something IS sorted. Saving an empty sort chain is\r\n              legitimate — it makes selecting the view *clear* the sort — but it is not what someone\r\n              means when they name a view on an unsorted grid, and a checkbox that silently arms that\r\n              would make an unrelated view reset the user's sorting later.\r\n            -->\r\n            <label class=\"cws:flex cws:items-start cws:gap-2 cws:text-xs cws:text-slate-600 cws:dark:text-slate-300\">\r\n              <input\r\n                type=\"checkbox\"\r\n                class=\"cws:mt-0.5\"\r\n                [checked]=\"includeSort()\"\r\n                (change)=\"onIncludeSortChange($any($event.target).checked)\"\r\n              />\r\n              <span>\r\n                Also save the sorting\r\n                <span class=\"cws:text-slate-400 cws:dark:text-slate-500\">({{ sortSummary() }})</span>\r\n              </span>\r\n            </label>\r\n\r\n            @if (activeFilter(); as active) {\r\n              <p class=\"cws:text-[11px] cws:text-amber-700 cws:dark:text-amber-500\">\r\n                Saving under the name “{{ active.name }}” replaces that view.\r\n              </p>\r\n            }\r\n          </div>\r\n\r\n          <div class=\"cws:mt-2 cws:flex cws:justify-end cws:gap-2 cws:px-2\">\r\n            <button type=\"button\" class=\"scoular-btn scoular-btn-outline\" (click)=\"backToList()\">\r\n              Cancel\r\n            </button>\r\n            <button\r\n              type=\"button\"\r\n              class=\"scoular-btn scoular-btn-primary\"\r\n              [disabled]=\"!canSave()\"\r\n              (click)=\"commitSave()\"\r\n            >\r\n              Save\r\n            </button>\r\n          </div>\r\n        }\r\n\r\n        @case ('manage') {\r\n          <div class=\"cws:flex cws:items-center cws:justify-between cws:px-2 cws:pb-2\">\r\n            <p class=\"cws:text-xs cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">Manage filters</p>\r\n            <button\r\n              type=\"button\"\r\n              class=\"cws:rounded cws:px-1.5 cws:py-0.5 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\r\n              (click)=\"backToList()\"\r\n            >\r\n              Back\r\n            </button>\r\n          </div>\r\n\r\n          @if (savedFilters().length === 0) {\r\n            <p class=\"cws:px-2 cws:py-1 cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">Nothing saved yet.</p>\r\n          } @else {\r\n            <ul class=\"cws:space-y-1\">\r\n              @for (saved of savedFilters(); track saved.id) {\r\n                <li class=\"cws:flex cws:items-center cws:gap-1 cws:px-1\">\r\n                  <!--\r\n                    A toggle rather than a radio group with a fourth \"none\" row: the star that makes a\r\n                    view the default also clears it, and a list of filters stays a list of filters.\r\n                  -->\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-sm cws:hover:bg-slate-100 cws:dark:hover:bg-slate-700\"\r\n                    [class.cws:text-amber-500]=\"defaultId() === saved.id\"\r\n                    [class.cws:text-slate-400]=\"defaultId() !== saved.id\"\r\n                    [attr.aria-pressed]=\"defaultId() === saved.id\"\r\n                    [title]=\"\r\n                      defaultId() === saved.id\r\n                        ? 'Stop applying this on load'\r\n                        : 'Apply this automatically on load'\r\n                    \"\r\n                    [attr.aria-label]=\"\r\n                      (defaultId() === saved.id ? 'Unset default filter ' : 'Set default filter ') +\r\n                      saved.name\r\n                    \"\r\n                    (click)=\"toggleDefault(saved)\"\r\n                  >\r\n                    ★\r\n                  </button>\r\n\r\n                  <span class=\"cws:flex-1 truncate cws:text-sm cws:text-slate-700 cws:dark:text-slate-200\">\r\n                    {{ saved.name }}\r\n                  </span>\r\n\r\n                  <button\r\n                    type=\"button\"\r\n                    class=\"cws:shrink-0 cws:rounded cws:px-1.5 cws:py-1 cws:text-xs cws:text-slate-500 cws:hover:bg-slate-100 cws:hover:text-red-700 cws:dark:hover:bg-slate-700\"\r\n                    [attr.aria-label]=\"'Delete saved filter ' + saved.name\"\r\n                    title=\"Delete\"\r\n                    (click)=\"remove(saved)\"\r\n                  >\r\n                    ✕\r\n                  </button>\r\n                </li>\r\n              }\r\n            </ul>\r\n\r\n            <p class=\"cws:px-2 cws:pt-2 cws:text-[11px] cws:text-slate-400 cws:dark:text-slate-500\">\r\n              ★ marks the view applied when you open this screen.\r\n            </p>\r\n          }\r\n        }\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}],
	propDecorators: {
		scope: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "scope",
				required: true
			}]
		}],
		filter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filter",
				required: true
			}]
		}],
		sorts: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sorts",
				required: true
			}]
		}],
		baselineLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "baselineLabel",
				required: false
			}]
		}],
		viewChange: [{
			type: i0.Output,
			args: ["viewChange"]
		}]
	}
});
var PageHeaderComponent = class PageHeaderComponent {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input(null, ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: PageHeaderComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: PageHeaderComponent,
		isStandalone: true,
		selector: "cms-page-header",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<header class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n  <!--\r\n    `min-w-0` so a long title truncates inside the flex row rather than refusing to shrink and\r\n    pushing the actions off the end. A flex item will not go below its content width without it.\r\n  -->\r\n  <div class=\"cws:min-w-0\">\r\n    <ng-content select=\"[cmsPageHeaderBreadcrumb]\" />\r\n\r\n    <h2 class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\">{{ title() }}</h2>\r\n\r\n    @if (description(); as text) {\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ text }}</p>\r\n    }\r\n  </div>\r\n\r\n  <!--\r\n    🔴 `self-start` aligns the actions with the TOP of the header rather than with the baseline of\r\n    the description (JFrisbie, 2026-08-26). The row keeps `items-end` so the heading block is\r\n    unaffected — aligning one child is `self-*`, never a change to the row.\r\n\r\n    Always rendered rather than gated on whether anything was projected: `ng-content` cannot sit\r\n    inside a conditional without losing its content, and an empty flex item of zero width changes\r\n    nothing under `justify-between`.\r\n  -->\r\n  <div class=\"cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-2 cws:self-start\">\r\n    <ng-content select=\"[cmsPageHeaderActions]\" />\r\n  </div>\r\n</header>\r\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: PageHeaderComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-page-header",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			template: "<header class=\"cws:flex cws:flex-wrap cws:items-end cws:justify-between cws:gap-3\">\r\n  <!--\r\n    `min-w-0` so a long title truncates inside the flex row rather than refusing to shrink and\r\n    pushing the actions off the end. A flex item will not go below its content width without it.\r\n  -->\r\n  <div class=\"cws:min-w-0\">\r\n    <ng-content select=\"[cmsPageHeaderBreadcrumb]\" />\r\n\r\n    <h2 class=\"cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-white\">{{ title() }}</h2>\r\n\r\n    @if (description(); as text) {\r\n      <p class=\"cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">{{ text }}</p>\r\n    }\r\n  </div>\r\n\r\n  <!--\r\n    🔴 `self-start` aligns the actions with the TOP of the header rather than with the baseline of\r\n    the description (JFrisbie, 2026-08-26). The row keeps `items-end` so the heading block is\r\n    unaffected — aligning one child is `self-*`, never a change to the row.\r\n\r\n    Always rendered rather than gated on whether anything was projected: `ng-content` cannot sit\r\n    inside a conditional without losing its content, and an empty flex item of zero width changes\r\n    nothing under `justify-between`.\r\n  -->\r\n  <div class=\"cws:flex cws:shrink-0 cws:flex-wrap cws:items-center cws:gap-2 cws:self-start\">\r\n    <ng-content select=\"[cmsPageHeaderActions]\" />\r\n  </div>\r\n</header>\r\n"
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}]
	}
});
var ConfirmDialogComponent = class ConfirmDialogComponent {
	data = inject(DIALOG_DATA);
	ref = inject(DialogRef);
	confirm() {
		this.ref.close(true);
	}
	cancel() {
		this.ref.close(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ConfirmDialogComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: ConfirmDialogComponent,
		isStandalone: true,
		selector: "cms-confirm-dialog",
		host: {
			attributes: {
				"role": "alertdialog",
				"aria-modal": "true"
			},
			listeners: { "keydown.escape": "cancel()" },
			properties: {
				"attr.aria-labelledby": "\"confirm-dialog-title\"",
				"attr.aria-describedby": "\"confirm-dialog-message\""
			},
			classAttribute: "cws:block cws:max-w-md cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800"
		},
		ngImport: i0,
		template: `
    <h2
      id="confirm-dialog-title"
      class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100"
    >
      {{ data.title }}
    </h2>

    <p id="confirm-dialog-message" class="cws:mt-2 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
      {{ data.message }}
    </p>

    <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
      <!--
        ⚠ The cancelling button is FIRST in the DOM and carries the initial focus, so the default
        answer to "you are about to lose your work" is to keep it. Autofocusing the destructive
        button would make Enter the fastest way to discard.
      -->
      <button type="button" class="scoular-btn scoular-btn-secondary" cdkFocusInitial (click)="cancel()">
        {{ data.cancelLabel ?? 'Cancel' }}
      </button>
      <button
        type="button"
        class="scoular-btn"
        [class.scoular-btn-danger]="data.destructive === true"
        [class.scoular-btn-primary]="data.destructive !== true"
        (click)="confirm()"
      >
        {{ data.confirmLabel }}
      </button>
    </div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ConfirmDialogComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-confirm-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "cws:block cws:max-w-md cws:rounded-lg cws:bg-white cws:p-6 cws:shadow-xl cws:dark:bg-slate-800",
				role: "alertdialog",
				"aria-modal": "true",
				"[attr.aria-labelledby]": "\"confirm-dialog-title\"",
				"[attr.aria-describedby]": "\"confirm-dialog-message\"",
				"(keydown.escape)": "cancel()"
			},
			template: `
    <h2
      id="confirm-dialog-title"
      class="cws:text-lg cws:font-semibold cws:text-slate-900 cws:dark:text-slate-100"
    >
      {{ data.title }}
    </h2>

    <p id="confirm-dialog-message" class="cws:mt-2 cws:text-sm cws:text-slate-600 cws:dark:text-slate-300">
      {{ data.message }}
    </p>

    <div class="cws:mt-6 cws:flex cws:justify-end cws:gap-2">
      <!--
        ⚠ The cancelling button is FIRST in the DOM and carries the initial focus, so the default
        answer to "you are about to lose your work" is to keep it. Autofocusing the destructive
        button would make Enter the fastest way to discard.
      -->
      <button type="button" class="scoular-btn scoular-btn-secondary" cdkFocusInitial (click)="cancel()">
        {{ data.cancelLabel ?? 'Cancel' }}
      </button>
      <button
        type="button"
        class="scoular-btn"
        [class.scoular-btn-danger]="data.destructive === true"
        [class.scoular-btn-primary]="data.destructive !== true"
        (click)="confirm()"
      >
        {{ data.confirmLabel }}
      </button>
    </div>
  `
		}]
	}]
});
function injectConfirm() {
	const dialog = inject(Dialog);
	return (request) => dialog.open(ConfirmDialogComponent, {
		data: request,
		disableClose: true
	}).closed.pipe(map((result) => result === true));
}
const confirmed = () => of(true);
const confirmNavigationGuard = (component) => component.confirmNavigation();
var BreadcrumbComponent = class BreadcrumbComponent {
	crumbs = input.required(...ngDevMode ? [{ debugName: "crumbs" }] : /* istanbul ignore next */ []);
	current = input.required(...ngDevMode ? [{ debugName: "current" }] : /* istanbul ignore next */ []);
	context = input(null, ...ngDevMode ? [{ debugName: "context" }] : /* istanbul ignore next */ []);
	queryParams = input(null, ...ngDevMode ? [{ debugName: "queryParams" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: BreadcrumbComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: BreadcrumbComponent,
		isStandalone: true,
		selector: "cms-breadcrumb",
		inputs: {
			crumbs: {
				classPropertyName: "crumbs",
				publicName: "crumbs",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			current: {
				classPropertyName: "current",
				publicName: "current",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			context: {
				classPropertyName: "context",
				publicName: "context",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			queryParams: {
				classPropertyName: "queryParams",
				publicName: "queryParams",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "cws:block" },
		ngImport: i0,
		template: "<!--\r\n  A real `<nav>` with an ordered list, because that is what a breadcrumb is, and the ARIA breadcrumb\r\n  pattern is what tells a screen-reader user this is navigation rather than a heading. The last crumb\r\n  is the current page and so is not a link.\r\n-->\r\n<nav aria-label=\"Breadcrumb\">\r\n  <ol class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1 cws:text-sm\">\r\n    @if (context(); as scope) {\r\n      <!-- The trade unit leads, inline. Context, and deliberately not a link. -->\r\n      <li class=\"cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ scope }}</li>\r\n      <li aria-hidden=\"true\" class=\"cws:text-slate-400 cws:dark:text-slate-500\">&rsaquo;</li>\r\n    }\r\n\r\n    <!--\r\n      ⚠ Tracked by `label`, not by `path`. A path may be a segment ARRAY, which is a fresh object\r\n      identity on every change-detection pass, so tracking it would tear down and rebuild every\r\n      anchor in the trail each time — including the one the user is tabbing through.\r\n    -->\r\n    @for (crumb of crumbs(); track crumb.label) {\r\n      <li>\r\n        @if (crumb.link; as link) {\r\n          <!-- The host decides this one (an embeddable screen): its href, and a click handed to it. -->\r\n          <a\r\n            [attr.href]=\"link.href\"\r\n            (click)=\"link.follow($event)\"\r\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\r\n          >\r\n            {{ crumb.label }}\r\n          </a>\r\n        } @else {\r\n          <a\r\n            [routerLink]=\"crumb.path\"\r\n            [queryParams]=\"queryParams()\"\r\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\r\n          >\r\n            {{ crumb.label }}\r\n          </a>\r\n        }\r\n      </li>\r\n      <li aria-hidden=\"true\" class=\"cws:text-slate-400 cws:dark:text-slate-500\">&rsaquo;</li>\r\n    }\r\n\r\n    <li aria-current=\"page\" class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">{{ current() }}</li>\r\n  </ol>\r\n</nav>\r\n",
		dependencies: [{
			kind: "directive",
			type: RouterLink,
			selector: "[routerLink]",
			inputs: [
				"target",
				"queryParams",
				"fragment",
				"queryParamsHandling",
				"state",
				"info",
				"relativeTo",
				"preserveFragment",
				"skipLocationChange",
				"replaceUrl",
				"browserUrl",
				"routerLink"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: BreadcrumbComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-breadcrumb",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "cws:block" },
			imports: [RouterLink],
			template: "<!--\r\n  A real `<nav>` with an ordered list, because that is what a breadcrumb is, and the ARIA breadcrumb\r\n  pattern is what tells a screen-reader user this is navigation rather than a heading. The last crumb\r\n  is the current page and so is not a link.\r\n-->\r\n<nav aria-label=\"Breadcrumb\">\r\n  <ol class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1 cws:text-sm\">\r\n    @if (context(); as scope) {\r\n      <!-- The trade unit leads, inline. Context, and deliberately not a link. -->\r\n      <li class=\"cws:font-medium cws:text-slate-500 cws:dark:text-slate-400\">{{ scope }}</li>\r\n      <li aria-hidden=\"true\" class=\"cws:text-slate-400 cws:dark:text-slate-500\">&rsaquo;</li>\r\n    }\r\n\r\n    <!--\r\n      ⚠ Tracked by `label`, not by `path`. A path may be a segment ARRAY, which is a fresh object\r\n      identity on every change-detection pass, so tracking it would tear down and rebuild every\r\n      anchor in the trail each time — including the one the user is tabbing through.\r\n    -->\r\n    @for (crumb of crumbs(); track crumb.label) {\r\n      <li>\r\n        @if (crumb.link; as link) {\r\n          <!-- The host decides this one (an embeddable screen): its href, and a click handed to it. -->\r\n          <a\r\n            [attr.href]=\"link.href\"\r\n            (click)=\"link.follow($event)\"\r\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\r\n          >\r\n            {{ crumb.label }}\r\n          </a>\r\n        } @else {\r\n          <a\r\n            [routerLink]=\"crumb.path\"\r\n            [queryParams]=\"queryParams()\"\r\n            class=\"cws:rounded cws:font-medium cws:text-scoular-blue cws:hover:underline cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-sky-400\"\r\n          >\r\n            {{ crumb.label }}\r\n          </a>\r\n        }\r\n      </li>\r\n      <li aria-hidden=\"true\" class=\"cws:text-slate-400 cws:dark:text-slate-500\">&rsaquo;</li>\r\n    }\r\n\r\n    <li aria-current=\"page\" class=\"cws:font-medium cws:text-slate-700 cws:dark:text-slate-200\">{{ current() }}</li>\r\n  </ol>\r\n</nav>\r\n"
		}]
	}],
	propDecorators: {
		crumbs: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "crumbs",
				required: true
			}]
		}],
		current: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "current",
				required: true
			}]
		}],
		context: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "context",
				required: false
			}]
		}],
		queryParams: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "queryParams",
				required: false
			}]
		}]
	}
});
export { AsyncContainerComponent, BreadcrumbComponent, ClearSortButtonComponent, CodeComboComponent, ConfirmDialogComponent, DEFAULT_COLUMN_WIDTH, DRAG_THRESHOLD_PX, DataGridComponent, DateInputComponent, DatePickerComponent, DropdownDirective, EMPTY_FILTER, ExportFieldsComponent, FieldComponent, FilterBuilderComponent, FilterSelectComponent, GridExportComponent, GridToolbarComponent, LocalSavedFilterStore, MIN_COLUMN_WIDTH, NoteInputComponent, NoticesPanelComponent, OPERATORS_BY_KIND, OPERATOR_LABELS, PageHeaderComponent, PagerComponent, PointerDragGesture, QuantityInputComponent, RefreshButtonComponent, SAVED_FILTER_OWNER, SAVED_FILTER_SCOPES, SAVED_FILTER_STORE, SearchShortcutDirective, SelectComponent, ShortcutHintsComponent, ShortcutOverlayComponent, ShortcutRegistry, StatusBadgeComponent, TextInputComponent, ToggleComponent, activeRuleCount, applyExportFields, ariaKeyShortcuts, ariaSort, compareBySorts, compareRows, confirmNavigationGuard, confirmed, defaultGroup, describeGroup, downloadBlob, downloadCsv, elementUnder, exportFieldsFor, flipDirection, formatShortcut, groupNodes, includedExportFieldCount, injectConfirm, isComplete, isGroupNode, isLive, isRuleNode, isTextEditable, matchesGroup, matchesSearch, moveExportField, moveNode, needsValue, nextSort, nodeAt, normaliseGroup, operatorLabel, operatorsFor, reconcileExportFields, registerShortcuts, remoteError, remoteIdle, remoteLoaded, remoteLoading, remoteValue, removeAt, replaceRuleById, sameGroup, sameSortChain, scopeRank, setAllExportFields, shortcutTokens, sortRank, statusBadgeClass, toCsv, toggleCombinatorAt, toggleExportField, ungroupAt };

//# sourceMappingURL=cws-shared-ui.mjs.map
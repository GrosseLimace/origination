import { HttpErrorResponse } from "@angular/common/http";
import { catchError, throwError } from "rxjs";
const ProblemKind = {
	Validation: "Validation",
	Unauthenticated: "Unauthenticated",
	Forbidden: "Forbidden",
	CtrmFault: "CtrmFault",
	CtrmUnavailable: "CtrmUnavailable",
	Unknown: "Unknown"
};
const CTRM_FAULT_TYPE = "ctrm-fault";
const CTRM_UNAVAILABLE_TYPE = "ctrm-unavailable";
function text(value) {
	return typeof value === "string" && value.trim() !== "" ? value : null;
}
function messages(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((entry) => typeof entry === "string" && entry.trim() !== "");
}
function readErrors(value) {
	if (value === null || typeof value !== "object" || Array.isArray(value)) return {};
	const result = {};
	for (const [key, entry] of Object.entries(value)) {
		const reasons = messages(entry);
		if (reasons.length > 0) result[key] = reasons;
	}
	return result;
}
function classify(status, type) {
	if (status === 422) return ProblemKind.Validation;
	if (status === 401) return ProblemKind.Unauthenticated;
	if (status === 403) return ProblemKind.Forbidden;
	if (type === CTRM_FAULT_TYPE || status === 502) return ProblemKind.CtrmFault;
	if (type === CTRM_UNAVAILABLE_TYPE || status === 503) return ProblemKind.CtrmUnavailable;
	return ProblemKind.Unknown;
}
function parseProblem(error) {
	const body = error.error !== null && typeof error.error === "object" ? error.error : {};
	const type = text(body.type);
	return {
		status: error.status,
		kind: classify(error.status, type),
		title: text(body.title),
		detail: text(body.detail),
		type,
		traceId: text(body.traceId),
		errors: readErrors(body.errors),
		formErrors: messages(body.formErrors)
	};
}
function problemFrom(error) {
	if (error instanceof HttpErrorResponse) return parseProblem(error);
	if (error === null || typeof error !== "object") return parseProblem(new HttpErrorResponse({
		status: 0,
		error: null
	}));
	const candidate = error;
	return parseProblem(new HttpErrorResponse({
		status: typeof candidate.status === "number" ? candidate.status : 0,
		error: candidate.error ?? null
	}));
}
const CtrmWriteProblemType = {
	NotApplied: "ctrm-write-not-applied",
	OutcomeUnknown: "ctrm-write-outcome-unknown"
};
function writeOutcomeOf(problem) {
	if (problem.type === CtrmWriteProblemType.NotApplied) return "not-applied";
	if (problem.type === CtrmWriteProblemType.OutcomeUnknown) return "outcome-unknown";
	if (problem.type === CTRM_UNAVAILABLE_TYPE) return "refused";
	return problem.status === 0 || problem.status >= 500 ? "outcome-unknown" : "refused";
}
function isCwsProblem(value) {
	return value !== null && typeof value === "object" && "kind" in value && "formErrors" in value && "errors" in value;
}
const problemDetailsInterceptor = (request, next) => next(request).pipe(catchError((error) => {
	if (!(error instanceof HttpErrorResponse)) return throwError(() => error);
	const described = new HttpErrorResponse({
		error: parseProblem(error),
		headers: error.headers,
		status: error.status,
		statusText: error.statusText,
		url: error.url ?? void 0
	});
	return throwError(() => described);
}));
export { CtrmWriteProblemType, ProblemKind, isCwsProblem, parseProblem, problemDetailsInterceptor, problemFrom, writeOutcomeOf };

//# sourceMappingURL=cws-core-http.mjs.map
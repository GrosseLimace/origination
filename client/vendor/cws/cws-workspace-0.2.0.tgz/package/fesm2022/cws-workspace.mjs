import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, ElementRef, ErrorHandler, Injectable, InjectionToken, computed, effect, inject, makeEnvironmentProviders, signal } from "@angular/core";
import { APPROVAL_ACTION_SOURCE, APPROVAL_CONTRACT_SOURCE, AVAILABILITY_SOURCE, AvailabilityGate, CONTRACTS_API_URL, CONTRACT_DETAIL_SOURCE, CONTRACT_EXPORT_SOURCE, CONTRACT_LIST_SOURCE, CONTRACT_LOG_SOURCE, CONTRACT_NUMBER_SOURCE, CONTRACT_STATE_SOURCE, CONTRACT_TEMPLATE_SOURCE, CONTRACT_WRITE_SOURCE, CUSTOMER_SOURCE, FORM_CONFIG_ADMIN_SOURCE, FORM_CONFIG_SOURCE, HttpApprovalContractSource, HttpAvailabilitySource, HttpContractDetailSource, HttpContractExportSource, HttpContractListSource, HttpContractLogSource, HttpContractNumberSource, HttpContractStateSource, HttpContractTemplateSource, HttpContractWriteSource, HttpCustomerSource, HttpFormConfigAdminSource, HttpLocationSource, HttpMarketReferenceSource, HttpMeSource, HttpPricingSource, HttpTradeUnitValuesSource, LOCATION_SOURCE, MARKET_REFERENCE_SOURCE, ME_SOURCE, PRICING_SOURCE, SimulatedApprovalActionSource, TRADE_UNIT_VALUES_SOURCE, defaultTradeUnitOf, groupByCompany, recordOrigin } from "@cws/domain-contracts";
import { CMS_HOST_CONTEXT, routerHostContext } from "@cws/core-host-context";
import { takeUntilDestroyed, toSignal } from "@angular/core/rxjs-interop";
import { CmsAuthService, cwsAuthGuard, cwsTokenInterceptor, provideCmsAuth, provideCwsHostTokenAuth } from "@cws/core-auth";
import { AccessNotice, PERMISSION_CONTEXT, TRADE_UNIT_CONTEXT, TradeUnitStore } from "@cws/core-state";
import { DropdownDirective, LocalSavedFilterStore, SAVED_FILTER_OWNER, SAVED_FILTER_STORE, ShortcutHintsComponent, ShortcutOverlayComponent, StatusBadgeComponent, registerShortcuts, remoteLoading } from "@cws/shared-ui";
import { filter, firstValueFrom, map, of, startWith } from "rxjs";
import { ActivatedRoute, NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from "@angular/router";
import { provideHttpClient, withInterceptors } from "@angular/common/http";
import { problemDetailsInterceptor } from "@cws/core-http";
import { APP_INSIGHTS_CONNECTION_STRING, APP_INSIGHTS_ROLE_NAME, AppInsightsErrorHandler } from "@cws/core-telemetry";
import { HttpFormConfigSource } from "@cws/features-contract-entry";
const CWS_ENVIRONMENT_NAME = new InjectionToken("CWS_ENVIRONMENT_NAME");
const CWS_THEME_MODE = new InjectionToken("CWS_THEME_MODE");
const CWS_EMBEDDED = new InjectionToken("CWS_EMBEDDED", { factory: () => false });
const STORAGE_KEY = "cms.theme";
const DARK_CLASS = "dark";
var ThemeStore = class ThemeStore {
	mode = inject(CWS_THEME_MODE, { optional: true }) ?? "own";
	preference = signal(read(), ...ngDevMode ? [{ debugName: "preference" }] : /* istanbul ignore next */ []);
	hostDark = signal(false, ...ngDevMode ? [{ debugName: "hostDark" }] : /* istanbul ignore next */ []);
	selected = computed(() => this.preference(), ...ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []);
	isDark = computed(() => this.mode === "host" ? this.hostDark() : resolve(this.preference()), ...ngDevMode ? [{ debugName: "isDark" }] : /* istanbul ignore next */ []);
	constructor() {
		if (this.mode === "host") {
			this.followHost();
			return;
		}
		this.apply();
	}
	set(preference) {
		this.preference.set(preference);
		write(preference);
		this.apply();
	}
	toggle() {
		this.set(this.isDark() ? "light" : "dark");
	}
	apply() {
		if (this.mode === "host") return;
		const root = globalThis.document?.documentElement;
		if (!root) return;
		root.classList.toggle(DARK_CLASS, this.isDark());
	}
	followHost() {
		const root = globalThis.document?.documentElement;
		if (!root || typeof MutationObserver === "undefined") return;
		this.hostDark.set(root.classList.contains(DARK_CLASS));
		const observer = new MutationObserver(() => this.hostDark.set(root.classList.contains(DARK_CLASS)));
		observer.observe(root, {
			attributes: true,
			attributeFilter: ["class"]
		});
		inject(DestroyRef).onDestroy(() => observer.disconnect());
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ThemeStore,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: ThemeStore,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: ThemeStore,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}],
	ctorParameters: () => []
});
function resolve(preference) {
	if (preference !== "system") return preference === "dark";
	return globalThis.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
}
function read() {
	try {
		const stored = globalThis.localStorage?.getItem(STORAGE_KEY);
		return stored === "light" || stored === "dark" || stored === "system" ? stored : "system";
	} catch {
		return "system";
	}
}
function write(preference) {
	try {
		globalThis.localStorage?.setItem(STORAGE_KEY, preference);
	} catch {}
}
function mountBaseOf(mountRoute) {
	return "/" + mountRoute.pathFromRoot.flatMap((route) => route.url.map((segment) => segment.path)).join("/");
}
var CwsMountBase = class CwsMountBase {
	base = signal("/", ...ngDevMode ? [{ debugName: "base" }] : /* istanbul ignore next */ []);
	path = this.base.asReadonly();
	set(path) {
		this.base.set(path);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: CwsMountBase,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: CwsMountBase
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: CwsMountBase,
	decorators: [{ type: Injectable }]
});
function workspaceRoutes(base) {
	const under = (...segments) => [base(), ...segments];
	return {
		contract: (contractNumber) => under("contracts", contractNumber),
		origin: (origin) => under(...segmentsOf(recordOrigin(origin).path)),
		editContract: (contractNumber) => under("contracts", contractNumber, "edit"),
		newContract: () => under("contracts", "new"),
		review: (origin, contractNumber) => {
			const descriptor = recordOrigin(origin);
			return under(...segmentsOf(descriptor.review?.path(contractNumber) ?? descriptor.path));
		},
		module: (module) => under(...MODULE_SEGMENTS[module])
	};
}
const MODULE_SEGMENTS = {
	home: [],
	approvals: ["approvals"],
	pricing: ["pricing"],
	"pricing-approvals": ["pricing", "approvals"],
	admin: ["admin"]
};
function segmentsOf(path) {
	return path.split("/").filter((segment) => segment !== "");
}
function workspaceHostContext(router, auth, tradeUnits, theme, base) {
	return routerHostContext(router, {
		tradeUnit: () => tradeUnits.code(),
		user: () => auth.isSignedIn() ? {
			id: auth.userId(),
			username: auth.username(),
			displayName: auth.displayName()
		} : null,
		theme: () => theme.isDark() ? "dark" : "light",
		baseHref: () => globalThis.document?.baseURI ?? "/",
		auth: {
			isSignedIn: () => auth.isSignedIn(),
			accessToken: (scopes) => auth.accessToken(scopes)
		},
		routes: workspaceRoutes(base)
	});
}
var MePermissionContext = class MePermissionContext {
	auth = inject(CmsAuthService);
	tradeUnit = inject(TRADE_UNIT_CONTEXT);
	source = inject(ME_SOURCE, { optional: true });
	me = toSignal(this.source?.get() ?? of(remoteLoading()), { initialValue: remoteLoading() });
	tokenIsAdmin = computed(() => this.auth.roles().includes("Admin"), ...ngDevMode ? [{ debugName: "tokenIsAdmin" }] : /* istanbul ignore next */ []);
	grants = computed(() => {
		const answer = this.me();
		return answer.status === "loaded" && answer.value.status === "Available" ? answer.value : null;
	}, ...ngDevMode ? [{ debugName: "grants" }] : /* istanbul ignore next */ []);
	isAdmin = () => this.tokenIsAdmin() || (this.grants()?.isAdmin ?? false);
	has = (key) => {
		if (this.isAdmin()) return true;
		const active = this.tradeUnit.code();
		return this.grants()?.tradeUnits.find((unit) => unit.code === active)?.permissions.includes(key) ?? false;
	};
	canWriteContracts = () => this.has("contracts:update");
	canEditPricing = () => this.has("prices:update");
	canApproveContracts = () => this.has("contracts:approve");
	canAccessAdmin = () => this.isAdmin() || (this.grants()?.tradeUnits.some((unit) => unit.permissions.includes("settings:manage")) ?? false);
	settled() {
		if (this.source === null) return Promise.resolve();
		return firstValueFrom(this.source.get().pipe(filter((answer) => answer.status !== "loading"), map(() => void 0)));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: MePermissionContext,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: MePermissionContext
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: MePermissionContext,
	decorators: [{ type: Injectable }]
});
const ADMIN_REFUSAL = "Administration needs the Admin role on this application. Your account can view contracts but not administer them.";
const canAccessAdminGuard = async (route) => {
	const auth = inject(CmsAuthService);
	const permissions = inject(PERMISSION_CONTEXT);
	const notice = inject(AccessNotice);
	const router = inject(Router);
	const base = route.parent ? mountBaseOf(route.parent) : "/";
	if (!await auth.ensureSignedIn()) return false;
	if (permissions.canAccessAdmin()) return true;
	await permissions.settled?.();
	if (permissions.canAccessAdmin()) return true;
	notice.refuse(ADMIN_REFUSAL);
	return router.createUrlTree([base]);
};
var TradeUnitPickerComponent = class TradeUnitPickerComponent {
	store = inject(TradeUnitStore);
	source = inject(LOCATION_SOURCE);
	router = inject(Router);
	data = toSignal(this.source.list(), { initialValue: remoteLoading() });
	meSource = inject(ME_SOURCE, { optional: true });
	me = toSignal(this.meSource?.get() ?? of(remoteLoading()), { initialValue: remoteLoading() });
	identity = computed(() => {
		const state = this.me();
		return state.status === "loaded" ? state.value : null;
	}, ...ngDevMode ? [{ debugName: "identity" }] : /* istanbul ignore next */ []);
	mine = computed(() => new Map((this.identity()?.tradeUnits ?? []).map((unit) => [unit.code, unit])), ...ngDevMode ? [{ debugName: "mine" }] : /* istanbul ignore next */ []);
	notOnboarded(code) {
		const unit = this.mine().get(code);
		return unit !== void 0 && !unit.onboarded;
	}
	applyDefault = effect(() => {
		const preferred = defaultTradeUnitOf(this.identity());
		if (preferred !== null && this.store.code() === null) this.store.select(preferred.code);
	}, ...ngDevMode ? [{ debugName: "applyDefault" }] : /* istanbul ignore next */ []);
	companies = computed(() => {
		const data = this.data();
		return data.status === "loaded" ? groupByCompany(data.value.locations) : [];
	}, ...ngDevMode ? [{ debugName: "companies" }] : /* istanbul ignore next */ []);
	term = signal("", ...ngDevMode ? [{ debugName: "term" }] : /* istanbul ignore next */ []);
	filtered = computed(() => {
		const term = this.term().trim().toLowerCase();
		if (!term) return this.companies();
		return this.companies().map((company) => {
			const companyMatches = company.code.toLowerCase().includes(term) || company.name.toLowerCase().includes(term);
			return {
				...company,
				locations: companyMatches ? company.locations : company.locations.filter((location) => location.code.toLowerCase().includes(term) || (location.name ?? "").toLowerCase().includes(term))
			};
		}).filter((company) => company.locations.length > 0);
	}, ...ngDevMode ? [{ debugName: "filtered" }] : /* istanbul ignore next */ []);
	matchCount = computed(() => this.filtered().reduce((total, company) => total + company.locations.length, 0), ...ngDevMode ? [{ debugName: "matchCount" }] : /* istanbul ignore next */ []);
	resetSearch() {
		this.term.set("");
	}
	failed = computed(() => this.data().status === "error", ...ngDevMode ? [{ debugName: "failed" }] : /* istanbul ignore next */ []);
	failure = computed(() => {
		const data = this.data();
		return data.status === "error" ? data.error : null;
	}, ...ngDevMode ? [{ debugName: "failure" }] : /* istanbul ignore next */ []);
	label = computed(() => {
		const code = this.store.code();
		if (!code) return this.failed() ? "Trade units unavailable" : "Select trade unit…";
		const match = this.companies().flatMap((company) => company.locations).find((location) => location.code === code);
		return match?.name ? `${code} · ${match.name}` : code;
	}, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	locked = toSignal(this.router.events.pipe(filter((event) => event instanceof NavigationEnd), startWith(null), map(() => isLocked(this.router.routerState.snapshot.root))), { initialValue: false });
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: TradeUnitPickerComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: TradeUnitPickerComponent,
		isStandalone: true,
		selector: "cms-trade-unit-picker",
		ngImport: i0,
		template: "<div cmsDropdown #picker=\"cmsDropdown\" class=\"cws:relative\">\r\n  <!--\r\n    A ghost button, matching the identity menu, rather than a bordered <select>. The select was the\r\n    only filled block in a row of text and ~10px taller than everything else, which is most of what\r\n    made the bar look heavy.\r\n\r\n    No visible label: chosen it reads \"0210 · Omaha Terminal\", empty it reads \"Select trade unit…\".\r\n    The accessible name comes from aria-label so screen-reader users lose nothing.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"cws:flex cws:h-9 cws:max-w-64 cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:text-[15px] cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:disabled:cursor-not-allowed cws:disabled:opacity-60 cws:disabled:hover:bg-transparent cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\r\n    aria-label=\"Trade unit\"\r\n    [attr.aria-expanded]=\"picker.open()\"\r\n    aria-haspopup=\"listbox\"\r\n    [disabled]=\"locked()\"\r\n    [attr.title]=\"locked() ? 'Trade unit is fixed while you are working on a contract' : null\"\r\n    (click)=\"picker.toggle(); resetSearch()\"\r\n  >\r\n    <!-- Truncated: some CTRM location names are long enough to shove the identity menu around. -->\r\n    <span class=\"truncate\">{{ label() }}</span>\r\n    <span aria-hidden=\"true\" class=\"cws:text-xs\">{{ picker.open() ? '▲' : '▼' }}</span>\r\n  </button>\r\n\r\n  @if (picker.open()) {\r\n    <!--\r\n      Scrolls rather than growing: this list is ~1044 entries against live CTRM, and a panel sized\r\n      to its content would run off the screen.\r\n    -->\r\n    <div\r\n      class=\"scoular-dropdown cws:right-0 cws:top-full cws:max-h-96 cws:w-80 cws:overflow-y-auto\"\r\n      role=\"listbox\"\r\n      aria-label=\"Trade unit\"\r\n    >\r\n      <!--\r\n        Typeahead over 1044 locations (C-15). Sticky so it stays reachable while the list scrolls —\r\n        a search box that disappears once you scroll past it is worse than none, because you have to\r\n        scroll back up to change a query that produced too many results.\r\n\r\n        `type=\"search\"` for the browser's own clear affordance. Not autofocused: the panel is opened\r\n        by a click, and stealing focus into a text field means the arrow keys stop moving through the\r\n        list for anyone browsing rather than searching.\r\n      -->\r\n      <div\r\n        class=\"cws:sticky cws:top-0 cws:z-10 cws:border-b cws:border-slate-200 cws:bg-white cws:p-2 cws:dark:border-slate-700 cws:dark:bg-slate-800\"\r\n      >\r\n        <input\r\n          type=\"search\"\r\n          class=\"scoular-form-input\"\r\n          placeholder=\"Search code, name or company\"\r\n          aria-label=\"Search trade units\"\r\n          [value]=\"term()\"\r\n          (input)=\"term.set($any($event.target).value)\"\r\n        />\r\n      </div>\r\n\r\n      @if (failure(); as failure) {\r\n        <!--\r\n          The reason, not just the fact. \"Sign in again\" and \"your account has no role\" call for\r\n          opposite actions, and this used to show one fixed sentence for both (#65).\r\n        -->\r\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <p>{{ failure.message }}</p>\r\n          @if (failure.correlationId; as correlationId) {\r\n            <!-- docs/02 §9: every user-visible error carries a correlation id to quote to support. -->\r\n            <p class=\"cws:mt-1 cws:font-mono cws:text-xs cws:text-slate-400 cws:dark:text-slate-500\">\r\n              Reference: {{ correlationId }}\r\n            </p>\r\n          }\r\n        </div>\r\n      } @else if (matchCount() === 0) {\r\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          No trade unit matches “{{ term() }}”.\r\n        </div>\r\n      } @else {\r\n        @for (company of filtered(); track company.code) {\r\n          <!--\r\n            Grouped by company *code*, not name: names repeat across codes — 22 and 42 are both\r\n            \"SCOULAR CANADA, ULC\" — so grouping by name would silently merge two companies (C-15).\r\n\r\n            🔴 **`role=\"group\"`, and it is required rather than decorative (#193).** A `listbox` may\r\n            own only `option`s and `group`s, so a bare `<div>` between the options is an invalid\r\n            child: assistive technology is free to drop it, and the grouping that earns this panel\r\n            its place over a flat 1,044-row list disappears for exactly the users who most need the\r\n            list narrowed.\r\n\r\n            ⚠ **Only locations are trade units** (C-15). The company level exists to navigate, never\r\n            to be chosen — so the heading must not be reachable. It is a `<div>` with no handler and\r\n            no tabindex, so it is already unclickable and already skipped by Tab; the group role is\r\n            what makes that true for a screen reader as well, rather than only for the pointer.\r\n          -->\r\n          <div role=\"group\" [attr.aria-label]=\"company.code + ' — ' + company.name\">\r\n            <!--\r\n              `aria-hidden` because the group's own label already carries this text. Without it the\r\n              company is announced twice on entering the group — once as the label, once as stray\r\n              text — which reads as a duplicated row.\r\n            -->\r\n            <div class=\"scoular-dropdown-header\" aria-hidden=\"true\">\r\n              {{ company.code }} — {{ company.name }}\r\n            </div>\r\n\r\n            @for (location of company.locations; track location.code) {\r\n              <button\r\n                type=\"button\"\r\n                role=\"option\"\r\n                [attr.aria-selected]=\"store.code() === location.code\"\r\n                class=\"scoular-dropdown-item\"\r\n                [class.active]=\"store.code() === location.code\"\r\n                (click)=\"store.select(location.code); picker.close()\"\r\n              >\r\n                <span class=\"cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ location.code }}\r\n                </span>\r\n                <span class=\"truncate\">{{ location.name }}</span>\r\n                @if (notOnboarded(location.code)) {\r\n                  <!--\r\n                    C-15 (d) — one of the caller's own trade units that this application cannot\r\n                    configure yet.\r\n\r\n                    🔴 **Marked, never hidden.** Hiding a trade unit somebody knows they have reads\r\n                    as a permissions fault, and they would go and ask for access they already hold.\r\n                    The marker says the truth instead: it is yours, and we are not ready for it.\r\n\r\n                    ⚠ Only ever on the caller's OWN units. The panel lists every CTRM location\r\n                    because reads are deliberately unscoped, so marking the rest would put a warning\r\n                    on almost every row and make the real ones invisible.\r\n                  -->\r\n                  <span\r\n                    class=\"cws:ml-auto cws:shrink-0 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\r\n                    title=\"This trade unit is not set up in this application yet\"\r\n                  >Not set up</span>\r\n                }\r\n              </button>\r\n            }\r\n          </div>\r\n        }\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
		dependencies: [{
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: TradeUnitPickerComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-trade-unit-picker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownDirective],
			template: "<div cmsDropdown #picker=\"cmsDropdown\" class=\"cws:relative\">\r\n  <!--\r\n    A ghost button, matching the identity menu, rather than a bordered <select>. The select was the\r\n    only filled block in a row of text and ~10px taller than everything else, which is most of what\r\n    made the bar look heavy.\r\n\r\n    No visible label: chosen it reads \"0210 · Omaha Terminal\", empty it reads \"Select trade unit…\".\r\n    The accessible name comes from aria-label so screen-reader users lose nothing.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"cws:flex cws:h-9 cws:max-w-64 cws:items-center cws:gap-1.5 cws:rounded cws:px-2 cws:text-[15px] cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:disabled:cursor-not-allowed cws:disabled:opacity-60 cws:disabled:hover:bg-transparent cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\r\n    aria-label=\"Trade unit\"\r\n    [attr.aria-expanded]=\"picker.open()\"\r\n    aria-haspopup=\"listbox\"\r\n    [disabled]=\"locked()\"\r\n    [attr.title]=\"locked() ? 'Trade unit is fixed while you are working on a contract' : null\"\r\n    (click)=\"picker.toggle(); resetSearch()\"\r\n  >\r\n    <!-- Truncated: some CTRM location names are long enough to shove the identity menu around. -->\r\n    <span class=\"truncate\">{{ label() }}</span>\r\n    <span aria-hidden=\"true\" class=\"cws:text-xs\">{{ picker.open() ? '▲' : '▼' }}</span>\r\n  </button>\r\n\r\n  @if (picker.open()) {\r\n    <!--\r\n      Scrolls rather than growing: this list is ~1044 entries against live CTRM, and a panel sized\r\n      to its content would run off the screen.\r\n    -->\r\n    <div\r\n      class=\"scoular-dropdown cws:right-0 cws:top-full cws:max-h-96 cws:w-80 cws:overflow-y-auto\"\r\n      role=\"listbox\"\r\n      aria-label=\"Trade unit\"\r\n    >\r\n      <!--\r\n        Typeahead over 1044 locations (C-15). Sticky so it stays reachable while the list scrolls —\r\n        a search box that disappears once you scroll past it is worse than none, because you have to\r\n        scroll back up to change a query that produced too many results.\r\n\r\n        `type=\"search\"` for the browser's own clear affordance. Not autofocused: the panel is opened\r\n        by a click, and stealing focus into a text field means the arrow keys stop moving through the\r\n        list for anyone browsing rather than searching.\r\n      -->\r\n      <div\r\n        class=\"cws:sticky cws:top-0 cws:z-10 cws:border-b cws:border-slate-200 cws:bg-white cws:p-2 cws:dark:border-slate-700 cws:dark:bg-slate-800\"\r\n      >\r\n        <input\r\n          type=\"search\"\r\n          class=\"scoular-form-input\"\r\n          placeholder=\"Search code, name or company\"\r\n          aria-label=\"Search trade units\"\r\n          [value]=\"term()\"\r\n          (input)=\"term.set($any($event.target).value)\"\r\n        />\r\n      </div>\r\n\r\n      @if (failure(); as failure) {\r\n        <!--\r\n          The reason, not just the fact. \"Sign in again\" and \"your account has no role\" call for\r\n          opposite actions, and this used to show one fixed sentence for both (#65).\r\n        -->\r\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          <p>{{ failure.message }}</p>\r\n          @if (failure.correlationId; as correlationId) {\r\n            <!-- docs/02 §9: every user-visible error carries a correlation id to quote to support. -->\r\n            <p class=\"cws:mt-1 cws:font-mono cws:text-xs cws:text-slate-400 cws:dark:text-slate-500\">\r\n              Reference: {{ correlationId }}\r\n            </p>\r\n          }\r\n        </div>\r\n      } @else if (matchCount() === 0) {\r\n        <div class=\"cws:px-4 cws:py-3 cws:text-sm cws:text-slate-500 cws:dark:text-slate-400\">\r\n          No trade unit matches “{{ term() }}”.\r\n        </div>\r\n      } @else {\r\n        @for (company of filtered(); track company.code) {\r\n          <!--\r\n            Grouped by company *code*, not name: names repeat across codes — 22 and 42 are both\r\n            \"SCOULAR CANADA, ULC\" — so grouping by name would silently merge two companies (C-15).\r\n\r\n            🔴 **`role=\"group\"`, and it is required rather than decorative (#193).** A `listbox` may\r\n            own only `option`s and `group`s, so a bare `<div>` between the options is an invalid\r\n            child: assistive technology is free to drop it, and the grouping that earns this panel\r\n            its place over a flat 1,044-row list disappears for exactly the users who most need the\r\n            list narrowed.\r\n\r\n            ⚠ **Only locations are trade units** (C-15). The company level exists to navigate, never\r\n            to be chosen — so the heading must not be reachable. It is a `<div>` with no handler and\r\n            no tabindex, so it is already unclickable and already skipped by Tab; the group role is\r\n            what makes that true for a screen reader as well, rather than only for the pointer.\r\n          -->\r\n          <div role=\"group\" [attr.aria-label]=\"company.code + ' — ' + company.name\">\r\n            <!--\r\n              `aria-hidden` because the group's own label already carries this text. Without it the\r\n              company is announced twice on entering the group — once as the label, once as stray\r\n              text — which reads as a duplicated row.\r\n            -->\r\n            <div class=\"scoular-dropdown-header\" aria-hidden=\"true\">\r\n              {{ company.code }} — {{ company.name }}\r\n            </div>\r\n\r\n            @for (location of company.locations; track location.code) {\r\n              <button\r\n                type=\"button\"\r\n                role=\"option\"\r\n                [attr.aria-selected]=\"store.code() === location.code\"\r\n                class=\"scoular-dropdown-item\"\r\n                [class.active]=\"store.code() === location.code\"\r\n                (click)=\"store.select(location.code); picker.close()\"\r\n              >\r\n                <span class=\"cws:font-mono cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\">\r\n                  {{ location.code }}\r\n                </span>\r\n                <span class=\"truncate\">{{ location.name }}</span>\r\n                @if (notOnboarded(location.code)) {\r\n                  <!--\r\n                    C-15 (d) — one of the caller's own trade units that this application cannot\r\n                    configure yet.\r\n\r\n                    🔴 **Marked, never hidden.** Hiding a trade unit somebody knows they have reads\r\n                    as a permissions fault, and they would go and ask for access they already hold.\r\n                    The marker says the truth instead: it is yours, and we are not ready for it.\r\n\r\n                    ⚠ Only ever on the caller's OWN units. The panel lists every CTRM location\r\n                    because reads are deliberately unscoped, so marking the rest would put a warning\r\n                    on almost every row and make the real ones invisible.\r\n                  -->\r\n                  <span\r\n                    class=\"cws:ml-auto cws:shrink-0 cws:rounded cws:bg-amber-100 cws:px-1.5 cws:py-0.5 cws:text-xs cws:font-medium cws:text-amber-900 cws:dark:bg-amber-900 cws:dark:text-amber-100\"\r\n                    title=\"This trade unit is not set up in this application yet\"\r\n                  >Not set up</span>\r\n                }\r\n              </button>\r\n            }\r\n          </div>\r\n        }\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}]
});
function isLocked(route) {
	return route.data["tradeUnitLocked"] === true || route.children.some(isLocked);
}
var UserMenuComponent = class UserMenuComponent {
	auth = inject(CmsAuthService);
	sortedRoles = computed(() => [...this.auth.roles()].sort((a, b) => rankOf(a) - rankOf(b)), ...ngDevMode ? [{ debugName: "sortedRoles" }] : /* istanbul ignore next */ []);
	badgeTone(role) {
		return role === ADMIN ? "negative" : "neutral";
	}
	theme = inject(ThemeStore);
	themeMode = inject(CWS_THEME_MODE, { optional: true }) ?? "own";
	embedded = inject(CWS_EMBEDDED);
	themeOptions = [
		{
			value: "light",
			label: "Light"
		},
		{
			value: "dark",
			label: "Dark"
		},
		{
			value: "system",
			label: "System"
		}
	];
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: UserMenuComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: UserMenuComponent,
		isStandalone: true,
		selector: "cms-user-menu",
		ngImport: i0,
		template: "<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:items-center cws:gap-2\">\r\n  <!--\r\n    \"No role\" stays OUTSIDE the menu, deliberately.\r\n\r\n    Its whole value is being visible without a click: a signed-in user with no app role gets a 403\r\n    on every request (#36), and that is indistinguishable from a broken application unless the\r\n    missing role is on screen. The normal role sits inside the menu, where it is reference rather\r\n    than a warning — so the common case is uncluttered and the failure case is loud.\r\n  -->\r\n  @if (!auth.canReadContracts()) {\r\n    <cms-status-badge tone=\"caution\" title=\"Your account has no CWS app role\">\r\n      No role\r\n    </cms-status-badge>\r\n  }\r\n\r\n  <!--\r\n    An avatar rather than the full name. The name was the widest thing in the bar and it tells you\r\n    something you already know; the avatar is the conventional affordance and the name is one click\r\n    away inside.\r\n\r\n    The accessible name still carries it — a circle reading \"JF\" would otherwise announce as \"JF\"\r\n    and tell a screen-reader user nothing.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"cws:flex cws:h-9 cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\r\n    [attr.aria-label]=\"auth.displayName() + ' — account menu'\"\r\n    [attr.aria-expanded]=\"menu.open()\"\r\n    aria-haspopup=\"menu\"\r\n    (click)=\"menu.toggle()\"\r\n  >\r\n    <!--\r\n      No chevron. An avatar in the top-right corner is a near-universal affordance for an account\r\n      menu, so the arrow was restating it. The machine-readable cue is unaffected: the button still\r\n      carries aria-haspopup and aria-expanded, so assistive technology announces it as a menu button\r\n      and reports its state — which is what the arrow was doing for sighted users only.\r\n    -->\r\n    <!--\r\n      The Outlook profile photo where the account has one, initials where it does not.\r\n\r\n      Not a progressive enhancement on top of the initials but a straight either/or, because the two\r\n      must never both paint: a photo layered over a coloured circle flashes the initials on every\r\n      load, and a transparent PNG would show them through it permanently.\r\n\r\n      `auth.photoUrl()` is null until Graph answers, so initials render first and are replaced. That\r\n      swap is the intended behaviour rather than a flicker to fix — blocking the shell's first paint\r\n      on a decorative image would be the worse trade (see CmsAuthService.refresh).\r\n\r\n      aria-hidden on both: the button's own aria-label already carries the user's name, so announcing\r\n      \"JF\" or an image alt beside it would say the same thing twice. The <img> keeps an empty alt as\r\n      well, which is what marks it decorative to any tool that ignores aria-hidden.\r\n    -->\r\n    @if (auth.photoUrl(); as photo) {\r\n      <img\r\n        [src]=\"photo\"\r\n        alt=\"\"\r\n        aria-hidden=\"true\"\r\n        width=\"32\"\r\n        height=\"32\"\r\n        class=\"cws:size-8 cws:rounded-full cws:object-cover\"\r\n      />\r\n    } @else {\r\n      <span\r\n        aria-hidden=\"true\"\r\n        class=\"cws:flex cws:size-8 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-[13px] cws:font-semibold cws:text-white\"\r\n      >\r\n        {{ auth.initials() }}\r\n      </span>\r\n    }\r\n  </button>\r\n\r\n  @if (menu.open()) {\r\n    <!--\r\n      `w-72` because the identity block is now a 48px avatar beside a full email address, and the\r\n      panel's own `min-w-[12rem]` would wrap `JFrisbie@scoular.com` onto two lines.\r\n    -->\r\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-72\" role=\"menu\" aria-label=\"Account\">\r\n      <!--\r\n        Photo, name and sign-in address as one row — the Originations arrangement.\r\n\r\n        The avatar is repeated from the trigger deliberately: at 48px it is the confirmation that you\r\n        are on the right account, which a 32px chip in the corner cannot be. Same either/or as the\r\n        trigger, so the initials never paint behind a photo.\r\n\r\n        aria-hidden on both, because the name is right beside them in text — announcing an avatar and\r\n        then the name it stands for says the same thing twice.\r\n\r\n        `min-w-0` and `truncate` are load-bearing: a flex child defaults to `min-width: auto`, so\r\n        without it a long address widens the panel instead of ellipsing.\r\n      -->\r\n      <div class=\"cws:flex cws:items-center cws:gap-3 cws:px-4 cws:py-3\">\r\n        @if (auth.photoUrl(); as photo) {\r\n          <img\r\n            [src]=\"photo\"\r\n            alt=\"\"\r\n            aria-hidden=\"true\"\r\n            width=\"48\"\r\n            height=\"48\"\r\n            class=\"cws:size-12 cws:shrink-0 cws:rounded-full cws:object-cover\"\r\n          />\r\n        } @else {\r\n          <span\r\n            aria-hidden=\"true\"\r\n            class=\"cws:flex cws:size-12 cws:shrink-0 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-base cws:font-semibold cws:text-white\"\r\n          >\r\n            {{ auth.initials() }}\r\n          </span>\r\n        }\r\n\r\n        <div class=\"cws:min-w-0\">\r\n          <div class=\"truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n            {{ auth.displayName() }}\r\n          </div>\r\n          @if (auth.username(); as username) {\r\n            <!--\r\n              The sign-in name, not just the display name: two people can share a display name, and\r\n              someone opening this menu is usually trying to work out *which* account they are on.\r\n            -->\r\n            <div class=\"truncate cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" [title]=\"username\">\r\n              {{ username }}\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n      <!--\r\n        Roles as badges rather than a comma-joined string (JFrisbie, 2026-08-31).\r\n\r\n        Admin carries the same variant as the environment indicator, because it is the one role that\r\n        changes what the application will let you do — it should read as a flag, not as a label.\r\n        Everything else is neutral grey: reference rather than a warning.\r\n\r\n        Ordered most-privileged-first by the component, NOT in arrival order. `roles` is a JSON array\r\n        whose sequence Entra does not specify, so an account holding both could read \"User, Admin\"\r\n        one session and \"Admin, User\" the next.\r\n\r\n        The text is 12px, matching the environment indicator (JFrisbie, 2026-08-31). That is\r\n        `.scoular-badge`'s own size, so there is nothing to override — an earlier revision kept the\r\n        list's original 14px and needed an inner <span> to carry it, because `text-sm` on the badge\r\n        itself is silently overruled by the unlayered design-system rule. Taking the badge's own size\r\n        removes that workaround rather than inverting it.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n      -->\r\n      <div class=\"scoular-dropdown-header\">Role</div>\r\n      <div class=\"cws:px-4 cws:pb-2\">\r\n        @if (auth.canReadContracts()) {\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1.5\">\r\n            @for (role of sortedRoles(); track role) {\r\n              <cms-status-badge [tone]=\"badgeTone(role)\">{{ role }}</cms-status-badge>\r\n            }\r\n          </div>\r\n        } @else {\r\n          <span class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">\r\n            None — contract data will not load\r\n          </span>\r\n        }\r\n      </div>\r\n\r\n      <!--\r\n        Appearance. Three explicit choices rather than a two-state switch, because \"System\" is a real\r\n        answer and not a synonym for either: someone whose OS flips to dark at sunset wants the app to\r\n        follow, and a plain toggle cannot express that.\r\n\r\n        `aria-pressed` on each, and the menu stays open — changing theme is something you want to see\r\n        the result of, and closing the menu would hide most of the surface that just changed.\r\n\r\n        Absent in host theme mode (D-9): the host owns the page's theme.\r\n      -->\r\n      @if (themeMode === 'own') {\r\n        <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n        <div class=\"scoular-dropdown-header\">Appearance</div>\r\n        <div role=\"group\" aria-label=\"Appearance\" class=\"cws:flex cws:gap-1 cws:px-4 cws:pb-2\">\r\n          @for (option of themeOptions; track option.value) {\r\n            <button\r\n              type=\"button\"\r\n              class=\"scoular-btn scoular-btn-sm cws:flex-1\"\r\n              [class.scoular-btn-primary]=\"theme.selected() === option.value\"\r\n              [class.scoular-btn-outline]=\"theme.selected() !== option.value\"\r\n              [attr.aria-pressed]=\"theme.selected() === option.value\"\r\n              (click)=\"theme.set(option.value)\"\r\n            >\r\n              {{ option.label }}\r\n            </button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n      <!-- Absent when embedded (D-18): the host owns the session. -->\r\n      @if (!embedded) {\r\n        <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n        <button\r\n          type=\"button\"\r\n          role=\"menuitem\"\r\n          class=\"scoular-dropdown-item\"\r\n          (click)=\"menu.close(); auth.signOut()\"\r\n        >\r\n          Sign out\r\n        </button>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n",
		dependencies: [{
			kind: "directive",
			type: DropdownDirective,
			selector: "[cmsDropdown]",
			exportAs: ["cmsDropdown"]
		}, {
			kind: "component",
			type: StatusBadgeComponent,
			selector: "cms-status-badge",
			inputs: ["tone", "small"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: UserMenuComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cms-user-menu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [DropdownDirective, StatusBadgeComponent],
			template: "<div cmsDropdown #menu=\"cmsDropdown\" class=\"cws:relative cws:flex cws:items-center cws:gap-2\">\r\n  <!--\r\n    \"No role\" stays OUTSIDE the menu, deliberately.\r\n\r\n    Its whole value is being visible without a click: a signed-in user with no app role gets a 403\r\n    on every request (#36), and that is indistinguishable from a broken application unless the\r\n    missing role is on screen. The normal role sits inside the menu, where it is reference rather\r\n    than a warning — so the common case is uncluttered and the failure case is loud.\r\n  -->\r\n  @if (!auth.canReadContracts()) {\r\n    <cms-status-badge tone=\"caution\" title=\"Your account has no CWS app role\">\r\n      No role\r\n    </cms-status-badge>\r\n  }\r\n\r\n  <!--\r\n    An avatar rather than the full name. The name was the widest thing in the bar and it tells you\r\n    something you already know; the avatar is the conventional affordance and the name is one click\r\n    away inside.\r\n\r\n    The accessible name still carries it — a circle reading \"JF\" would otherwise announce as \"JF\"\r\n    and tell a screen-reader user nothing.\r\n  -->\r\n  <button\r\n    type=\"button\"\r\n    class=\"cws:flex cws:h-9 cws:items-center cws:gap-1 cws:rounded cws:px-1 cws:text-slate-600 cws:hover:bg-slate-50 cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\r\n    [attr.aria-label]=\"auth.displayName() + ' — account menu'\"\r\n    [attr.aria-expanded]=\"menu.open()\"\r\n    aria-haspopup=\"menu\"\r\n    (click)=\"menu.toggle()\"\r\n  >\r\n    <!--\r\n      No chevron. An avatar in the top-right corner is a near-universal affordance for an account\r\n      menu, so the arrow was restating it. The machine-readable cue is unaffected: the button still\r\n      carries aria-haspopup and aria-expanded, so assistive technology announces it as a menu button\r\n      and reports its state — which is what the arrow was doing for sighted users only.\r\n    -->\r\n    <!--\r\n      The Outlook profile photo where the account has one, initials where it does not.\r\n\r\n      Not a progressive enhancement on top of the initials but a straight either/or, because the two\r\n      must never both paint: a photo layered over a coloured circle flashes the initials on every\r\n      load, and a transparent PNG would show them through it permanently.\r\n\r\n      `auth.photoUrl()` is null until Graph answers, so initials render first and are replaced. That\r\n      swap is the intended behaviour rather than a flicker to fix — blocking the shell's first paint\r\n      on a decorative image would be the worse trade (see CmsAuthService.refresh).\r\n\r\n      aria-hidden on both: the button's own aria-label already carries the user's name, so announcing\r\n      \"JF\" or an image alt beside it would say the same thing twice. The <img> keeps an empty alt as\r\n      well, which is what marks it decorative to any tool that ignores aria-hidden.\r\n    -->\r\n    @if (auth.photoUrl(); as photo) {\r\n      <img\r\n        [src]=\"photo\"\r\n        alt=\"\"\r\n        aria-hidden=\"true\"\r\n        width=\"32\"\r\n        height=\"32\"\r\n        class=\"cws:size-8 cws:rounded-full cws:object-cover\"\r\n      />\r\n    } @else {\r\n      <span\r\n        aria-hidden=\"true\"\r\n        class=\"cws:flex cws:size-8 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-[13px] cws:font-semibold cws:text-white\"\r\n      >\r\n        {{ auth.initials() }}\r\n      </span>\r\n    }\r\n  </button>\r\n\r\n  @if (menu.open()) {\r\n    <!--\r\n      `w-72` because the identity block is now a 48px avatar beside a full email address, and the\r\n      panel's own `min-w-[12rem]` would wrap `JFrisbie@scoular.com` onto two lines.\r\n    -->\r\n    <div class=\"scoular-dropdown cws:right-0 cws:top-full cws:w-72\" role=\"menu\" aria-label=\"Account\">\r\n      <!--\r\n        Photo, name and sign-in address as one row — the Originations arrangement.\r\n\r\n        The avatar is repeated from the trigger deliberately: at 48px it is the confirmation that you\r\n        are on the right account, which a 32px chip in the corner cannot be. Same either/or as the\r\n        trigger, so the initials never paint behind a photo.\r\n\r\n        aria-hidden on both, because the name is right beside them in text — announcing an avatar and\r\n        then the name it stands for says the same thing twice.\r\n\r\n        `min-w-0` and `truncate` are load-bearing: a flex child defaults to `min-width: auto`, so\r\n        without it a long address widens the panel instead of ellipsing.\r\n      -->\r\n      <div class=\"cws:flex cws:items-center cws:gap-3 cws:px-4 cws:py-3\">\r\n        @if (auth.photoUrl(); as photo) {\r\n          <img\r\n            [src]=\"photo\"\r\n            alt=\"\"\r\n            aria-hidden=\"true\"\r\n            width=\"48\"\r\n            height=\"48\"\r\n            class=\"cws:size-12 cws:shrink-0 cws:rounded-full cws:object-cover\"\r\n          />\r\n        } @else {\r\n          <span\r\n            aria-hidden=\"true\"\r\n            class=\"cws:flex cws:size-12 cws:shrink-0 cws:items-center cws:justify-center cws:rounded-full cws:bg-scoular-blue cws:text-base cws:font-semibold cws:text-white\"\r\n          >\r\n            {{ auth.initials() }}\r\n          </span>\r\n        }\r\n\r\n        <div class=\"cws:min-w-0\">\r\n          <div class=\"truncate cws:text-sm cws:font-semibold cws:text-slate-900 cws:dark:text-white\">\r\n            {{ auth.displayName() }}\r\n          </div>\r\n          @if (auth.username(); as username) {\r\n            <!--\r\n              The sign-in name, not just the display name: two people can share a display name, and\r\n              someone opening this menu is usually trying to work out *which* account they are on.\r\n            -->\r\n            <div class=\"truncate cws:text-xs cws:text-slate-500 cws:dark:text-slate-400\" [title]=\"username\">\r\n              {{ username }}\r\n            </div>\r\n          }\r\n        </div>\r\n      </div>\r\n\r\n      <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n      <!--\r\n        Roles as badges rather than a comma-joined string (JFrisbie, 2026-08-31).\r\n\r\n        Admin carries the same variant as the environment indicator, because it is the one role that\r\n        changes what the application will let you do — it should read as a flag, not as a label.\r\n        Everything else is neutral grey: reference rather than a warning.\r\n\r\n        Ordered most-privileged-first by the component, NOT in arrival order. `roles` is a JSON array\r\n        whose sequence Entra does not specify, so an account holding both could read \"User, Admin\"\r\n        one session and \"Admin, User\" the next.\r\n\r\n        The text is 12px, matching the environment indicator (JFrisbie, 2026-08-31). That is\r\n        `.scoular-badge`'s own size, so there is nothing to override — an earlier revision kept the\r\n        list's original 14px and needed an inner <span> to carry it, because `text-sm` on the badge\r\n        itself is silently overruled by the unlayered design-system rule. Taking the badge's own size\r\n        removes that workaround rather than inverting it.\r\n    \r\n    ✅ **Superseded 2026-09-16 — the constraint above is GONE.** `components.css` is now imported\r\n    into `@layer components`, so a Tailwind utility beats a `scoular-*` class. The reasoning is kept\r\n    because it explains why this code looks the way it does, and the code is unchanged: each of these\r\n    shapes has a second justification that has nothing to do with layers. See the header of the\r\n    shell's `styles.css` for what the change does and does not mean — in particular, it is scoped to\r\n    the shell, so an embedded host may still supply the old cascade.\r\n      -->\r\n      <div class=\"scoular-dropdown-header\">Role</div>\r\n      <div class=\"cws:px-4 cws:pb-2\">\r\n        @if (auth.canReadContracts()) {\r\n          <div class=\"cws:flex cws:flex-wrap cws:items-center cws:gap-1.5\">\r\n            @for (role of sortedRoles(); track role) {\r\n              <cms-status-badge [tone]=\"badgeTone(role)\">{{ role }}</cms-status-badge>\r\n            }\r\n          </div>\r\n        } @else {\r\n          <span class=\"cws:text-sm cws:text-amber-700 cws:dark:text-amber-400\">\r\n            None — contract data will not load\r\n          </span>\r\n        }\r\n      </div>\r\n\r\n      <!--\r\n        Appearance. Three explicit choices rather than a two-state switch, because \"System\" is a real\r\n        answer and not a synonym for either: someone whose OS flips to dark at sunset wants the app to\r\n        follow, and a plain toggle cannot express that.\r\n\r\n        `aria-pressed` on each, and the menu stays open — changing theme is something you want to see\r\n        the result of, and closing the menu would hide most of the surface that just changed.\r\n\r\n        Absent in host theme mode (D-9): the host owns the page's theme.\r\n      -->\r\n      @if (themeMode === 'own') {\r\n        <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n        <div class=\"scoular-dropdown-header\">Appearance</div>\r\n        <div role=\"group\" aria-label=\"Appearance\" class=\"cws:flex cws:gap-1 cws:px-4 cws:pb-2\">\r\n          @for (option of themeOptions; track option.value) {\r\n            <button\r\n              type=\"button\"\r\n              class=\"scoular-btn scoular-btn-sm cws:flex-1\"\r\n              [class.scoular-btn-primary]=\"theme.selected() === option.value\"\r\n              [class.scoular-btn-outline]=\"theme.selected() !== option.value\"\r\n              [attr.aria-pressed]=\"theme.selected() === option.value\"\r\n              (click)=\"theme.set(option.value)\"\r\n            >\r\n              {{ option.label }}\r\n            </button>\r\n          }\r\n        </div>\r\n      }\r\n\r\n      <!-- Absent when embedded (D-18): the host owns the session. -->\r\n      @if (!embedded) {\r\n        <div class=\"scoular-dropdown-divider\"></div>\r\n\r\n        <button\r\n          type=\"button\"\r\n          role=\"menuitem\"\r\n          class=\"scoular-dropdown-item\"\r\n          (click)=\"menu.close(); auth.signOut()\"\r\n        >\r\n          Sign out\r\n        </button>\r\n      }\r\n    </div>\r\n  }\r\n</div>\r\n"
		}]
	}]
});
const ADMIN = "Admin";
const ROLE_RANK = {
	[ADMIN]: 0,
	User: 1
};
function rankOf(role) {
	return ROLE_RANK[role] ?? Number.MAX_SAFE_INTEGER;
}
const MODULES = [
	{
		module: "home",
		label: "Home",
		exact: true,
		accessKey: "h"
	},
	{
		module: "approvals",
		label: "Approvals",
		exact: false,
		accessKey: "a"
	},
	{
		module: "pricing",
		label: "Pricing",
		exact: false,
		accessKey: "p"
	},
	{
		module: "admin",
		label: "Admin",
		exact: false,
		allowed: (p) => p.canAccessAdmin()
	}
];
const MODULE_PATHS = MODULES.map((entry) => `/${MODULE_SEGMENTS[entry.module].join("/")}`);
var CwsWorkspaceComponent = class CwsWorkspaceComponent {
	auth = inject(CmsAuthService);
	host = inject(ElementRef);
	embedded = inject(CWS_EMBEDDED);
	availability = inject(AvailabilityGate);
	permissions = inject(PERMISSION_CONTEXT);
	accessNotice = inject(AccessNotice);
	modules = computed(() => MODULES.filter((entry) => entry.allowed?.(this.permissions) ?? true).map((entry) => ({
		...entry,
		commands: this.commandsFor(entry.module)
	})), ...ngDevMode ? [{ debugName: "modules" }] : /* istanbul ignore next */ []);
	mountBase = inject(CwsMountBase);
	accessMessage = this.accessNotice.message;
	logoUnavailable = signal(false, ...ngDevMode ? [{ debugName: "logoUnavailable" }] : /* istanbul ignore next */ []);
	environmentLabel = signal(environmentLabelOf(inject(CWS_ENVIRONMENT_NAME)), ...ngDevMode ? [{ debugName: "environmentLabel" }] : /* istanbul ignore next */ []);
	constructor() {
		inject(CwsMountBase).set(mountBaseOf(inject(ActivatedRoute).snapshot));
		let painted = false;
		inject(Router).events.pipe(filter((event) => event instanceof NavigationEnd), takeUntilDestroyed()).subscribe(() => {
			if (this.accessNotice.message() === null) {
				painted = false;
				return;
			}
			if (painted) {
				this.accessNotice.clear();
				painted = false;
			} else painted = true;
		});
		this.registerGlobalShortcuts();
	}
	registerGlobalShortcuts() {
		const router = inject(Router);
		const within = () => this.host.nativeElement;
		const navigation = MODULES.filter((module) => module.accessKey !== void 0).map((module) => ({
			keys: `alt+${module.accessKey}`,
			scope: "shell",
			label: `Go to ${module.label}`,
			group: "Navigation",
			allowInTextInput: true,
			within,
			available: () => this.modules().some((entry) => entry.module === module.module),
			run: () => {
				router.navigate([...this.commandsFor(module.module)]);
			}
		}));
		registerShortcuts([
			...navigation,
			{
				keys: "alt+n",
				scope: "shell",
				label: "New contract",
				group: "Navigation",
				allowInTextInput: true,
				within,
				available: () => this.permissions.canWriteContracts(),
				run: () => {
					router.navigate([
						this.mountBase.path(),
						"contracts",
						"new"
					]);
				}
			},
			{
				keys: "f5",
				scope: "shell",
				label: "Refresh the grid you are on",
				group: "Navigation",
				note: "browser reload elsewhere",
				within
			}
		]);
	}
	dismissAccessNotice() {
		this.accessNotice.clear();
	}
	commandsFor(module) {
		return [this.mountBase.path(), ...MODULE_SEGMENTS[module]];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: CwsWorkspaceComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: CwsWorkspaceComponent,
		isStandalone: true,
		selector: "cws-workspace",
		host: { classAttribute: "cws:flex cws:min-h-dvh cws:flex-col" },
		ngImport: i0,
		template: "<!--\r\n  Shell chrome (docs/02 §1.1, 02a §6).\r\n\r\n  Top bar rather than a left rail. docs/02 §1.1 says \"Left rail / top bar navigation (final layout\r\n  in 02a)\" and 02a never resolved it, so this fills a gap rather than contradicting a decision — but\r\n  it is a decision, and a rail is still a live option if the module count grows.\r\n\r\n  Grouped by meaning rather than by convenience:\r\n    left   — the Scoular mark and the environment instance\r\n    then   — the modules you move between\r\n    middle — CONTEXT: what you are operating on (the trade unit)\r\n    right  — IDENTITY: who you are, and how to stop being them\r\n\r\n  The logo is the tallest thing here at 40px, so it sets the bar height at roughly 66px. Every\r\n  *control* is 32px, so nothing else sets an accidental maximum: the trade-unit picker used to be a\r\n  bordered <select> at ~38px and was most of why the bar looked heavy.\r\n\r\n  `py-2` was tried and reverted when the bar was single-line: at 49px it left 8px around a 32px\r\n  control and read cramped, and the 8px reclaimed is about one sixth of a table row.\r\n\r\n  The h1 is the brand link, so the heading and the primary navigation are one element rather than\r\n  two things competing for the same corner. Routed content starts at h2.\r\n-->\r\n<header class=\"cws:border-b cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-800\">\r\n  <!--\r\n    Width is capped at 1800px here and on <main>, and the two must stay in step — a top bar wider or\r\n    narrower than the content below it makes the nav and the grid look misaligned by a few pixels,\r\n    which reads as a rendering bug rather than a layout choice.\r\n\r\n    Widened from `max-w-7xl` (1280px), which left large margins on the monitors people actually use\r\n    (JFrisbie, 2026-08-26). Still capped rather than uncapped: this bar is chrome, but <main> also\r\n    carries the contract form, and an unbounded container puts its labelled fields on 2000px+ lines\r\n    on an ultrawide. 1800px fills a 1920 screen nearly edge to edge and leaves margins beyond that.\r\n  -->\r\n  <div class=\"cws:mx-auto cws:flex cws:max-w-[1800px] cws:flex-wrap cws:items-center cws:gap-x-6 cws:gap-y-3 cws:px-6 cws:py-3\">\r\n    <!--\r\n      Brand lockup, matching the Originations header: the Scoular mark and wordmark with the\r\n      application name beneath it.\r\n\r\n      Deliberately mirroring a sibling Scoular application rather than inventing our own arrangement.\r\n\r\n      🔴 Standalone only (D-17): when CWS_EMBEDDED is true the host's own header carries the brand,\r\n      and this lockup is not rendered at all. Its two images resolve relative to the page, so under a\r\n      host's prefix they would 404 and it would degrade to the text fallback below.\r\n\r\n      The h1 is a direct child of the header row, with no wrapper. It had one while the environment\r\n      chip sat beside the application name and the pair needed `items-end`; the chip now sits with the\r\n      module links, so the wrapper was a div that grouped one element.\r\n\r\n      The column is a FIXED 232px, and that number is derived rather than chosen: `scoular-logo.webp`\r\n      is 1692×292, so at `h-10` (40px) it renders 1692 ÷ 292 × 40 = 231.7px. Pinning it lets the\r\n      wordmark alignment below be expressed in the logo's own coordinate space, which is the only way\r\n      to line text up with a glyph inside a raster image.\r\n    -->\r\n    @if (!embedded) {\r\n    <h1 class=\"cws:m-0 cws:w-[232px] cws:shrink-0\">\r\n        <a\r\n          [routerLink]=\"[mountBase.path()]\"\r\n          class=\"cws:block cws:rounded cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n          aria-label=\"Contract Workspace — contract list\"\r\n        >\r\n          @if (logoUnavailable()) {\r\n            <span class=\"cws:text-xl cws:font-semibold cws:text-scoular-gray cws:dark:text-slate-200\">SCOULAR</span>\r\n          } @else {\r\n            <img\r\n              src=\"scoular-logo.webp\"\r\n              alt=\"\"\r\n              class=\"cws:h-10 cws:w-full cws:dark:hidden\"\r\n              (error)=\"logoUnavailable.set(true)\"\r\n            />\r\n            <img\r\n              src=\"scoular-logo-dark.webp\"\r\n              alt=\"\"\r\n              class=\"cws:hidden cws:h-10 cws:w-full cws:dark:block\"\r\n              (error)=\"logoUnavailable.set(true)\"\r\n            />\r\n          }\r\n\r\n          <!--\r\n            The application name, under the mark and aligned to the wordmark (JFrisbie, 2026-08-31).\r\n\r\n            ### Why this is an <svg> and not a <span>\r\n\r\n            Two requirements a span cannot meet: it must start under the **S** of SCOULAR — not at\r\n            the logo's left edge, which is the pinwheel — and it must not run past the **R**. Both\r\n            are positions *inside a raster image*, so they can only be expressed as fractions of that\r\n            image, and the right edge additionally depends on font metrics that differ by platform.\r\n\r\n            The viewBox is the logo's own pixel grid (1692 wide), so the two numbers below are\r\n            measured in the same units as the image and scale with it automatically:\r\n\r\n              x=378         the left edge of the S      (22.3% of 1692)\r\n              textLength    ends at 1600, short of the R's right edge at ~1620\r\n\r\n            `lengthAdjust=\"spacing\"` makes the text span exactly that width by distributing the\r\n            difference **between** glyphs — it stretches the tracking, never the letterforms, so the\r\n            type is not distorted. That is what fills the wordmark's width regardless of which font\r\n            actually resolves, which a hand-tuned `tracking-[…]` cannot promise.\r\n\r\n            aria-hidden, because the link's own aria-label already reads \"Contract Workspace —\r\n            contract list\"; without it the accessible name is computed from the label AND this text\r\n            and a screen reader says the words twice.\r\n          -->\r\n          <svg\r\n            aria-hidden=\"true\"\r\n            focusable=\"false\"\r\n            class=\"cws:mt-0.5 cws:block cws:w-full\"\r\n            viewBox=\"0 0 1692 92\"\r\n          >\r\n            <text\r\n              x=\"378\"\r\n              y=\"76\"\r\n              textLength=\"1222\"\r\n              lengthAdjust=\"spacing\"\r\n              font-size=\"84\"\r\n              font-weight=\"600\"\r\n              class=\"cws:fill-scoular-gray cws:dark:fill-slate-300\"\r\n            >\r\n              CONTRACT WORKSPACE\r\n            </text>\r\n          </svg>\r\n        </a>\r\n    </h1>\r\n    }\r\n\r\n    <!--\r\n      Which *instance* you are in, where the trade unit says what you are operating on. Absent in\r\n      production, where saying so adds nothing — so the clutter only exists where it earns its place.\r\n      Fixed height and a minimum width so a two-letter DEV and a five-letter LOCAL read as the same\r\n      control rather than one being a nub.\r\n\r\n      A sibling of the brand and the module nav rather than a child of either (JFrisbie, 2026-08-31),\r\n      so the header row's own `items-center` centres it against the full bar height and it sits on the\r\n      module links' line. Deliberately outside `<nav aria-label=\"Modules\">`: it is not somewhere you\r\n      can navigate to, and putting it inside would offer it to a screen-reader user as a fifth module.\r\n    -->\r\n    @if (environmentLabel(); as label) {\r\n      <!--\r\n        The `info` tone — a teal tint.\r\n\r\n        A solid `scoular-blue` fill with white text was tried on 2026-08-31 to match the Originations\r\n        header and reverted the same day: JFrisbie preferred the original. Recorded so it is not\r\n        re-proposed as an obvious improvement. It was not a contrast problem — white on #00588E is\r\n        7.5:1 — it simply looked wrong here, where the chip sits on a white bar rather than a dark one.\r\n\r\n        ⚠ **This is a CHIP borrowing the badge's tint, not a status.** It says which instance you are\r\n        in; nothing about it has a state that could be positive or negative. It goes through\r\n        `cms-status-badge` anyway so the tone-to-class mapping stays in one file — but if a future\r\n        change makes the tone vocabulary mean something narrower, this is the call site to reconsider\r\n        rather than the one to bend the vocabulary around.\r\n\r\n        The sizing utilities are this chip's own: a fixed height and a minimum width so a three-letter\r\n        DEV and a five-letter LOCAL read as the same control. They compose with the component's host\r\n        classes rather than replacing them (the primitive has a test for that).\r\n\r\n        ⚠ `font-semibold` USED TO DO NOTHING here. `.scoular-badge` sets `font-medium`, and before the\r\n        design system was layered on 2026-09-16 the class beat the utility — measured in Edge at\r\n        weight 500 before and 600 after. This chip is the one place in the application where that\r\n        change is visible.\r\n      -->\r\n      <cms-status-badge\r\n        tone=\"info\"\r\n        class=\"cws:h-6 cws:min-w-16 cws:shrink-0 cws:justify-center cws:px-3 cws:font-semibold cws:uppercase cws:tracking-wide\"\r\n      >\r\n        {{ label }}\r\n      </cms-status-badge>\r\n    }\r\n\r\n    @if (auth.isSignedIn()) {\r\n      <!--\r\n        The modules of docs/02 §1.1 this caller may see — the list is MODULES in workspace.component.ts.\r\n\r\n        🔴 **Admin is gated and the other three are not**, which is deliberate rather than partial\r\n        work. Approvals and Pricing are READABLE by any signed-in user, so hiding those queues would\r\n        withhold information a User is entitled to; what is gated there is the decision controls\r\n        inside them. Admin differs in kind — every request it makes carries CwsAdmin and would 403.\r\n\r\n        ⚠ **The route is guarded too, and the nav alone would not be enough.** Hiding a link does\r\n        nothing about a bookmark, a pasted URL or the back button. See permission.guards.ts.\r\n\r\n        ⚠ Still NOT the per-trade-unit matrix — that is F1.3 / #138, BACKEND, blocked on a business\r\n        ruling. This is one boolean resolved in one file, shaped so the matrix can replace it without\r\n        touching a screen.\r\n\r\n        `routerLinkActive` with `exact` on Home only — otherwise \"/\" matches every route and Home\r\n        would look active everywhere.\r\n\r\n        `text-[15px]`, one step up from `text-sm` (JFrisbie, 2026-08-31). The bar is ~66px tall\r\n        because the 40px logo sets it, and 14px links left it looking under-filled. 15px rather than\r\n        `text-base`: 16px starts competing with the page's own headings for weight, and the ask was\r\n        \"a little bigger\", not a size class up. The trade-unit picker and the avatar move with it, so\r\n        the row still reads as one set of controls rather than three different sizes.\r\n      -->\r\n      <!--\r\n        🔴 **The active module is marked three ways, and none of them moves the layout**\r\n        (JFrisbie, 2026-09-14). It was a pale tint and a colour change, which on a white bar was\r\n        easy to miss — and on a four-item nav \"which section am I in\" is the one question the bar\r\n        exists to answer.\r\n\r\n        Now: a **2px bottom accent**, a stronger background, and higher-contrast text.\r\n\r\n        ⚠ **The border is always present and only changes colour.** Adding a 2px border on\r\n        activation would shift every link up by 2px as you navigate, and the whole bar with it.\r\n        `rounded-t` rather than `rounded` for the same reason the accent is at the bottom — a\r\n        rounded bottom edge would clip it.\r\n\r\n        ⚠ **The font weight deliberately does NOT change.** `font-medium` to `font-semibold` widens\r\n        the text, which moves every sibling along the bar on each navigation — a jitter that reads\r\n        as the page settling badly.\r\n\r\n        🔴 **`ariaCurrentWhenActive` is not decoration.** Three visual cues say nothing to a screen\r\n        reader; `aria-current=\"page\"` is what makes the active module obvious without sight of it,\r\n        and it was missing entirely.\r\n      -->\r\n      <nav aria-label=\"Modules\" class=\"cws:flex cws:items-center cws:gap-1\">\r\n        @for (entry of modules(); track entry.module) {\r\n          <a\r\n            [routerLink]=\"entry.commands\"\r\n            routerLinkActive=\"border-scoular-blue bg-slate-100 text-scoular-blue dark:border-sky-400 dark:bg-slate-700 dark:text-sky-300\"\r\n            [routerLinkActiveOptions]=\"{ exact: entry.exact }\"\r\n            ariaCurrentWhenActive=\"page\"\r\n            class=\"cws:rounded-t cws:border-b-2 cws:border-transparent cws:px-3 cws:py-1.5 cws:text-[15px] cws:font-medium cws:text-slate-600 cws:transition-colors cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\r\n          >\r\n            {{ entry.label }}\r\n          </a>\r\n        }\r\n      </nav>\r\n\r\n      <!-- CONTEXT: what you are operating as. Pushed right of the modules, left of identity. -->\r\n      <div class=\"cws:ml-auto cws:flex cws:items-center cws:gap-3\">\r\n        <cms-trade-unit-picker />\r\n\r\n        <!--\r\n          No CTRM availability light here, deliberately.\r\n\r\n          docs/02a §5 handles unavailability with *gates*, not a status dot: CTRM down is a\r\n          full-screen block page, the night run is a persistent amber banner with mutations\r\n          disabled. Both are far louder than a dot, so the dot's only remaining job would be saying\r\n          \"fine\" during the normal case — the least informative thing a control can do. There is\r\n          also no signal to bind it to: `operation/statuses` reports only the night run, so\r\n          reachability has to be inferred from a call succeeding (#40 finding 5).\r\n        -->\r\n      </div>\r\n\r\n      <!--\r\n        IDENTITY: who you are, and how to stop being them — collapsed into one control.\r\n\r\n        Role, name and sign-out were three separate items here and crowded out the things people\r\n        actually navigate with. The exception is the \"No role\" warning, which the menu deliberately\r\n        keeps outside itself; see user-menu.component.html.\r\n\r\n        🔴 Sign in beside it while sign-in is BLOCKED (D-15): the account is still known, but a token\r\n        could not be had without an interaction, which may only come from a gesture. This button is\r\n        that gesture; without it every request would fail with nothing on screen saying why.\r\n      -->\r\n      @if (auth.signInBlocked()) {\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:mr-4\"\r\n          (click)=\"auth.signIn()\"\r\n        >\r\n          Sign in\r\n        </button>\r\n      }\r\n      <div class=\"cws:flex cws:items-center cws:border-l cws:border-slate-200 cws:pl-4 cws:dark:border-slate-700\">\r\n        <cms-user-menu />\r\n      </div>\r\n    } @else {\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:ml-auto\"\r\n        (click)=\"auth.signIn()\"\r\n      >\r\n        Sign in\r\n      </button>\r\n    }\r\n  </div>\r\n</header>\r\n\r\n<!--\r\n  F1.4 — the availability banner, on every screen.\r\n\r\n  🔴 **It NAMES the state rather than collapsing the five into \"CTRM is unavailable\".** They mean\r\n  different things to whoever reads this: a night run ends on its own, a closed CTRM is an\r\n  administrative decision, unreachable is an incident somebody should be told about, and unknown\r\n  means we cannot say. One sentence for all of them tells a trader nothing about whether to wait,\r\n  retry or call someone.\r\n\r\n  ⚠ Rendered in the SHELL rather than per screen, because the gate applies to every write in the\r\n  application and a banner a feature had to remember to add is one a feature will forget.\r\n\r\n  ⚠ Hidden only while CTRM is available — a permanent green bar is chrome nobody reads, and it\r\n  would make the states that matter less visible rather than more.\r\n-->\r\n@if (availability.notice(); as notice) {\r\n  @if (availability.state() !== 'Available') {\r\n    <!--\r\n      🔴 `role=\"status\"` even when it blocks writes, and that is this repository's own rule rather\r\n      than a concession: the panel convention is that an ALERT is the outcome of something the user\r\n      just did, and a STATUS is a standing condition of the screen. CTRM being closed is a standing\r\n      condition — it was true before they arrived and will be true after they leave.\r\n\r\n      ⚠ It was written as a conditional `alert` first, and the shell's access-notice tests caught it\r\n      immediately: two `role=\"alert\"` regions on one screen, so `getByRole('alert')` became\r\n      ambiguous. The collision is what surfaced it; the convention is why it stays `status`.\r\n    -->\r\n    <!--\r\n      ⚠ #485: a night run blocks CTRM writes now, and it stays AMBER. It is scheduled and ends on its\r\n      own, which is what docs/02a calls the soft gate; red is for a CTRM that is closed, unreachable\r\n      or unknown, where somebody may need to act.\r\n    -->\r\n    @let soft = !notice.blocksWrites || availability.state() === 'NightRun';\r\n    <div class=\"cws:mx-auto cws:max-w-[1800px] cws:px-6 cws:pt-4\" role=\"status\">\r\n      <div\r\n        class=\"cws:rounded-lg cws:border cws:px-4 cws:py-3 cws:text-sm\"\r\n        [class.cws:border-red-300]=\"!soft\"\r\n        [class.cws:bg-red-50]=\"!soft\"\r\n        [class.cws:text-red-900]=\"!soft\"\r\n        [class.cws:border-amber-300]=\"soft\"\r\n        [class.cws:bg-amber-50]=\"soft\"\r\n        [class.cws:text-amber-900]=\"soft\"\r\n      >\r\n        <p class=\"cws:font-semibold\">{{ notice.title }}</p>\r\n        <p class=\"cws:mt-0.5\">{{ notice.detail }}</p>\r\n        @if (availability.message(); as ctrmMessage) {\r\n          <!-- CTRM's own sentence, quoted rather than parsed: two producers share this channel. -->\r\n          <p class=\"cws:mt-0.5 cws:italic\">{{ ctrmMessage }}</p>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n}\r\n\r\n<!--\r\n  Same 1800px cap as the top bar — see the note there for why they have to match.\r\n  `flex-1` fills the shell's full-height column, so the shortcut strip sits on the viewport's bottom\r\n  edge even when a screen is shorter than the window; `w-full`, because a flex item with auto margins\r\n  otherwise shrinks to its content.\r\n-->\r\n<main class=\"cws:mx-auto cws:w-full cws:max-w-[1800px] cws:flex-1 cws:px-6 cws:py-8\">\r\n  <!--\r\n    🔴 A refused navigation, stated once and then cleared — see AccessNotice for why this is a\r\n    banner rather than a line in cms-notices-panel. That panel is for STANDING conditions of a\r\n    screen; being bounced out of Admin is an EVENT, and it belongs to the shell that refused it\r\n    rather than to the workspace that happens to be where you land.\r\n\r\n    role=\"alert\" rather than \"status\": the user asked to go somewhere and did not arrive, so it\r\n    should interrupt. That is the opposite call from the record screen's Save gate, which is a\r\n    standing property of a screen you meant to be on.\r\n  -->\r\n  @if (accessMessage(); as message) {\r\n    <div class=\"scoular-alert scoular-alert-warning cws:mb-6\" role=\"alert\">\r\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\r\n        <div>\r\n          <div class=\"scoular-alert-title\">That module is not available to your account</div>\r\n          <div class=\"scoular-alert-description\">{{ message }}</div>\r\n        </div>\r\n\r\n        <!--\r\n          Dismissible as well as self-clearing: the automatic clear happens on the NEXT navigation,\r\n          so a user who stays put has no other way to put it down.\r\n        -->\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary cws:shrink-0\"\r\n          (click)=\"dismissAccessNotice()\"\r\n        >\r\n          Dismiss\r\n        </button>\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <router-outlet />\r\n</main>\r\n\r\n<!--\r\n  The line-23 equivalent and the cheat-sheet behind `?`, both rendered by the workspace rather than by a\r\n  feature.\r\n\r\n  Rendered by the workspace in both delivery models (ADR-18); the bindings are scoped `within` the\r\n  workspace element so a host's own inputs never trigger them.\r\n\r\n  ⚠ The strip is after `<main>` rather than inside it, and it is `sticky bottom-0` (its own host\r\n  class), so it does not scroll with the content — the green screen's own line 23 does not scroll\r\n  either, and a legend that leaves the viewport is a legend nobody reads. Being after `<main>` was\r\n  never enough on its own: in normal flow it simply sat at the end of the page and scrolled away\r\n  with a long grid (JFrisbie, 2026-09-29).\r\n-->\r\n<cms-shortcut-hints />\r\n<cms-shortcut-overlay />\r\n",
		dependencies: [
			{
				kind: "directive",
				type: RouterLink,
				selector: "[routerLink]",
				inputs: [
					"target",
					"queryParams",
					"fragment",
					"queryParamsHandling",
					"state",
					"info",
					"relativeTo",
					"preserveFragment",
					"skipLocationChange",
					"replaceUrl",
					"browserUrl",
					"routerLink"
				]
			},
			{
				kind: "directive",
				type: RouterLinkActive,
				selector: "[routerLinkActive]",
				inputs: [
					"routerLinkActiveOptions",
					"ariaCurrentWhenActive",
					"routerLinkActive"
				],
				outputs: ["isActiveChange"],
				exportAs: ["routerLinkActive"]
			},
			{
				kind: "directive",
				type: RouterOutlet,
				selector: "router-outlet",
				inputs: ["name", "routerOutletData"],
				outputs: [
					"activate",
					"deactivate",
					"attach",
					"detach"
				],
				exportAs: ["outlet"]
			},
			{
				kind: "component",
				type: ShortcutHintsComponent,
				selector: "cms-shortcut-hints"
			},
			{
				kind: "component",
				type: ShortcutOverlayComponent,
				selector: "cms-shortcut-overlay"
			},
			{
				kind: "component",
				type: StatusBadgeComponent,
				selector: "cms-status-badge",
				inputs: ["tone", "small"]
			},
			{
				kind: "component",
				type: TradeUnitPickerComponent,
				selector: "cms-trade-unit-picker"
			},
			{
				kind: "component",
				type: UserMenuComponent,
				selector: "cms-user-menu"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: CwsWorkspaceComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "cws-workspace",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				RouterLink,
				RouterLinkActive,
				RouterOutlet,
				ShortcutHintsComponent,
				ShortcutOverlayComponent,
				StatusBadgeComponent,
				TradeUnitPickerComponent,
				UserMenuComponent
			],
			host: { class: "cws:flex cws:min-h-dvh cws:flex-col" },
			template: "<!--\r\n  Shell chrome (docs/02 §1.1, 02a §6).\r\n\r\n  Top bar rather than a left rail. docs/02 §1.1 says \"Left rail / top bar navigation (final layout\r\n  in 02a)\" and 02a never resolved it, so this fills a gap rather than contradicting a decision — but\r\n  it is a decision, and a rail is still a live option if the module count grows.\r\n\r\n  Grouped by meaning rather than by convenience:\r\n    left   — the Scoular mark and the environment instance\r\n    then   — the modules you move between\r\n    middle — CONTEXT: what you are operating on (the trade unit)\r\n    right  — IDENTITY: who you are, and how to stop being them\r\n\r\n  The logo is the tallest thing here at 40px, so it sets the bar height at roughly 66px. Every\r\n  *control* is 32px, so nothing else sets an accidental maximum: the trade-unit picker used to be a\r\n  bordered <select> at ~38px and was most of why the bar looked heavy.\r\n\r\n  `py-2` was tried and reverted when the bar was single-line: at 49px it left 8px around a 32px\r\n  control and read cramped, and the 8px reclaimed is about one sixth of a table row.\r\n\r\n  The h1 is the brand link, so the heading and the primary navigation are one element rather than\r\n  two things competing for the same corner. Routed content starts at h2.\r\n-->\r\n<header class=\"cws:border-b cws:border-slate-200 cws:bg-white cws:dark:border-slate-700 cws:dark:bg-slate-800\">\r\n  <!--\r\n    Width is capped at 1800px here and on <main>, and the two must stay in step — a top bar wider or\r\n    narrower than the content below it makes the nav and the grid look misaligned by a few pixels,\r\n    which reads as a rendering bug rather than a layout choice.\r\n\r\n    Widened from `max-w-7xl` (1280px), which left large margins on the monitors people actually use\r\n    (JFrisbie, 2026-08-26). Still capped rather than uncapped: this bar is chrome, but <main> also\r\n    carries the contract form, and an unbounded container puts its labelled fields on 2000px+ lines\r\n    on an ultrawide. 1800px fills a 1920 screen nearly edge to edge and leaves margins beyond that.\r\n  -->\r\n  <div class=\"cws:mx-auto cws:flex cws:max-w-[1800px] cws:flex-wrap cws:items-center cws:gap-x-6 cws:gap-y-3 cws:px-6 cws:py-3\">\r\n    <!--\r\n      Brand lockup, matching the Originations header: the Scoular mark and wordmark with the\r\n      application name beneath it.\r\n\r\n      Deliberately mirroring a sibling Scoular application rather than inventing our own arrangement.\r\n\r\n      🔴 Standalone only (D-17): when CWS_EMBEDDED is true the host's own header carries the brand,\r\n      and this lockup is not rendered at all. Its two images resolve relative to the page, so under a\r\n      host's prefix they would 404 and it would degrade to the text fallback below.\r\n\r\n      The h1 is a direct child of the header row, with no wrapper. It had one while the environment\r\n      chip sat beside the application name and the pair needed `items-end`; the chip now sits with the\r\n      module links, so the wrapper was a div that grouped one element.\r\n\r\n      The column is a FIXED 232px, and that number is derived rather than chosen: `scoular-logo.webp`\r\n      is 1692×292, so at `h-10` (40px) it renders 1692 ÷ 292 × 40 = 231.7px. Pinning it lets the\r\n      wordmark alignment below be expressed in the logo's own coordinate space, which is the only way\r\n      to line text up with a glyph inside a raster image.\r\n    -->\r\n    @if (!embedded) {\r\n    <h1 class=\"cws:m-0 cws:w-[232px] cws:shrink-0\">\r\n        <a\r\n          [routerLink]=\"[mountBase.path()]\"\r\n          class=\"cws:block cws:rounded cws:focus-visible:outline-2 cws:focus-visible:outline-offset-2 cws:focus-visible:outline-scoular-blue\"\r\n          aria-label=\"Contract Workspace — contract list\"\r\n        >\r\n          @if (logoUnavailable()) {\r\n            <span class=\"cws:text-xl cws:font-semibold cws:text-scoular-gray cws:dark:text-slate-200\">SCOULAR</span>\r\n          } @else {\r\n            <img\r\n              src=\"scoular-logo.webp\"\r\n              alt=\"\"\r\n              class=\"cws:h-10 cws:w-full cws:dark:hidden\"\r\n              (error)=\"logoUnavailable.set(true)\"\r\n            />\r\n            <img\r\n              src=\"scoular-logo-dark.webp\"\r\n              alt=\"\"\r\n              class=\"cws:hidden cws:h-10 cws:w-full cws:dark:block\"\r\n              (error)=\"logoUnavailable.set(true)\"\r\n            />\r\n          }\r\n\r\n          <!--\r\n            The application name, under the mark and aligned to the wordmark (JFrisbie, 2026-08-31).\r\n\r\n            ### Why this is an <svg> and not a <span>\r\n\r\n            Two requirements a span cannot meet: it must start under the **S** of SCOULAR — not at\r\n            the logo's left edge, which is the pinwheel — and it must not run past the **R**. Both\r\n            are positions *inside a raster image*, so they can only be expressed as fractions of that\r\n            image, and the right edge additionally depends on font metrics that differ by platform.\r\n\r\n            The viewBox is the logo's own pixel grid (1692 wide), so the two numbers below are\r\n            measured in the same units as the image and scale with it automatically:\r\n\r\n              x=378         the left edge of the S      (22.3% of 1692)\r\n              textLength    ends at 1600, short of the R's right edge at ~1620\r\n\r\n            `lengthAdjust=\"spacing\"` makes the text span exactly that width by distributing the\r\n            difference **between** glyphs — it stretches the tracking, never the letterforms, so the\r\n            type is not distorted. That is what fills the wordmark's width regardless of which font\r\n            actually resolves, which a hand-tuned `tracking-[…]` cannot promise.\r\n\r\n            aria-hidden, because the link's own aria-label already reads \"Contract Workspace —\r\n            contract list\"; without it the accessible name is computed from the label AND this text\r\n            and a screen reader says the words twice.\r\n          -->\r\n          <svg\r\n            aria-hidden=\"true\"\r\n            focusable=\"false\"\r\n            class=\"cws:mt-0.5 cws:block cws:w-full\"\r\n            viewBox=\"0 0 1692 92\"\r\n          >\r\n            <text\r\n              x=\"378\"\r\n              y=\"76\"\r\n              textLength=\"1222\"\r\n              lengthAdjust=\"spacing\"\r\n              font-size=\"84\"\r\n              font-weight=\"600\"\r\n              class=\"cws:fill-scoular-gray cws:dark:fill-slate-300\"\r\n            >\r\n              CONTRACT WORKSPACE\r\n            </text>\r\n          </svg>\r\n        </a>\r\n    </h1>\r\n    }\r\n\r\n    <!--\r\n      Which *instance* you are in, where the trade unit says what you are operating on. Absent in\r\n      production, where saying so adds nothing — so the clutter only exists where it earns its place.\r\n      Fixed height and a minimum width so a two-letter DEV and a five-letter LOCAL read as the same\r\n      control rather than one being a nub.\r\n\r\n      A sibling of the brand and the module nav rather than a child of either (JFrisbie, 2026-08-31),\r\n      so the header row's own `items-center` centres it against the full bar height and it sits on the\r\n      module links' line. Deliberately outside `<nav aria-label=\"Modules\">`: it is not somewhere you\r\n      can navigate to, and putting it inside would offer it to a screen-reader user as a fifth module.\r\n    -->\r\n    @if (environmentLabel(); as label) {\r\n      <!--\r\n        The `info` tone — a teal tint.\r\n\r\n        A solid `scoular-blue` fill with white text was tried on 2026-08-31 to match the Originations\r\n        header and reverted the same day: JFrisbie preferred the original. Recorded so it is not\r\n        re-proposed as an obvious improvement. It was not a contrast problem — white on #00588E is\r\n        7.5:1 — it simply looked wrong here, where the chip sits on a white bar rather than a dark one.\r\n\r\n        ⚠ **This is a CHIP borrowing the badge's tint, not a status.** It says which instance you are\r\n        in; nothing about it has a state that could be positive or negative. It goes through\r\n        `cms-status-badge` anyway so the tone-to-class mapping stays in one file — but if a future\r\n        change makes the tone vocabulary mean something narrower, this is the call site to reconsider\r\n        rather than the one to bend the vocabulary around.\r\n\r\n        The sizing utilities are this chip's own: a fixed height and a minimum width so a three-letter\r\n        DEV and a five-letter LOCAL read as the same control. They compose with the component's host\r\n        classes rather than replacing them (the primitive has a test for that).\r\n\r\n        ⚠ `font-semibold` USED TO DO NOTHING here. `.scoular-badge` sets `font-medium`, and before the\r\n        design system was layered on 2026-09-16 the class beat the utility — measured in Edge at\r\n        weight 500 before and 600 after. This chip is the one place in the application where that\r\n        change is visible.\r\n      -->\r\n      <cms-status-badge\r\n        tone=\"info\"\r\n        class=\"cws:h-6 cws:min-w-16 cws:shrink-0 cws:justify-center cws:px-3 cws:font-semibold cws:uppercase cws:tracking-wide\"\r\n      >\r\n        {{ label }}\r\n      </cms-status-badge>\r\n    }\r\n\r\n    @if (auth.isSignedIn()) {\r\n      <!--\r\n        The modules of docs/02 §1.1 this caller may see — the list is MODULES in workspace.component.ts.\r\n\r\n        🔴 **Admin is gated and the other three are not**, which is deliberate rather than partial\r\n        work. Approvals and Pricing are READABLE by any signed-in user, so hiding those queues would\r\n        withhold information a User is entitled to; what is gated there is the decision controls\r\n        inside them. Admin differs in kind — every request it makes carries CwsAdmin and would 403.\r\n\r\n        ⚠ **The route is guarded too, and the nav alone would not be enough.** Hiding a link does\r\n        nothing about a bookmark, a pasted URL or the back button. See permission.guards.ts.\r\n\r\n        ⚠ Still NOT the per-trade-unit matrix — that is F1.3 / #138, BACKEND, blocked on a business\r\n        ruling. This is one boolean resolved in one file, shaped so the matrix can replace it without\r\n        touching a screen.\r\n\r\n        `routerLinkActive` with `exact` on Home only — otherwise \"/\" matches every route and Home\r\n        would look active everywhere.\r\n\r\n        `text-[15px]`, one step up from `text-sm` (JFrisbie, 2026-08-31). The bar is ~66px tall\r\n        because the 40px logo sets it, and 14px links left it looking under-filled. 15px rather than\r\n        `text-base`: 16px starts competing with the page's own headings for weight, and the ask was\r\n        \"a little bigger\", not a size class up. The trade-unit picker and the avatar move with it, so\r\n        the row still reads as one set of controls rather than three different sizes.\r\n      -->\r\n      <!--\r\n        🔴 **The active module is marked three ways, and none of them moves the layout**\r\n        (JFrisbie, 2026-09-14). It was a pale tint and a colour change, which on a white bar was\r\n        easy to miss — and on a four-item nav \"which section am I in\" is the one question the bar\r\n        exists to answer.\r\n\r\n        Now: a **2px bottom accent**, a stronger background, and higher-contrast text.\r\n\r\n        ⚠ **The border is always present and only changes colour.** Adding a 2px border on\r\n        activation would shift every link up by 2px as you navigate, and the whole bar with it.\r\n        `rounded-t` rather than `rounded` for the same reason the accent is at the bottom — a\r\n        rounded bottom edge would clip it.\r\n\r\n        ⚠ **The font weight deliberately does NOT change.** `font-medium` to `font-semibold` widens\r\n        the text, which moves every sibling along the bar on each navigation — a jitter that reads\r\n        as the page settling badly.\r\n\r\n        🔴 **`ariaCurrentWhenActive` is not decoration.** Three visual cues say nothing to a screen\r\n        reader; `aria-current=\"page\"` is what makes the active module obvious without sight of it,\r\n        and it was missing entirely.\r\n      -->\r\n      <nav aria-label=\"Modules\" class=\"cws:flex cws:items-center cws:gap-1\">\r\n        @for (entry of modules(); track entry.module) {\r\n          <a\r\n            [routerLink]=\"entry.commands\"\r\n            routerLinkActive=\"border-scoular-blue bg-slate-100 text-scoular-blue dark:border-sky-400 dark:bg-slate-700 dark:text-sky-300\"\r\n            [routerLinkActiveOptions]=\"{ exact: entry.exact }\"\r\n            ariaCurrentWhenActive=\"page\"\r\n            class=\"cws:rounded-t cws:border-b-2 cws:border-transparent cws:px-3 cws:py-1.5 cws:text-[15px] cws:font-medium cws:text-slate-600 cws:transition-colors cws:hover:bg-slate-50 cws:dark:text-slate-300 cws:dark:hover:bg-slate-700/60\"\r\n          >\r\n            {{ entry.label }}\r\n          </a>\r\n        }\r\n      </nav>\r\n\r\n      <!-- CONTEXT: what you are operating as. Pushed right of the modules, left of identity. -->\r\n      <div class=\"cws:ml-auto cws:flex cws:items-center cws:gap-3\">\r\n        <cms-trade-unit-picker />\r\n\r\n        <!--\r\n          No CTRM availability light here, deliberately.\r\n\r\n          docs/02a §5 handles unavailability with *gates*, not a status dot: CTRM down is a\r\n          full-screen block page, the night run is a persistent amber banner with mutations\r\n          disabled. Both are far louder than a dot, so the dot's only remaining job would be saying\r\n          \"fine\" during the normal case — the least informative thing a control can do. There is\r\n          also no signal to bind it to: `operation/statuses` reports only the night run, so\r\n          reachability has to be inferred from a call succeeding (#40 finding 5).\r\n        -->\r\n      </div>\r\n\r\n      <!--\r\n        IDENTITY: who you are, and how to stop being them — collapsed into one control.\r\n\r\n        Role, name and sign-out were three separate items here and crowded out the things people\r\n        actually navigate with. The exception is the \"No role\" warning, which the menu deliberately\r\n        keeps outside itself; see user-menu.component.html.\r\n\r\n        🔴 Sign in beside it while sign-in is BLOCKED (D-15): the account is still known, but a token\r\n        could not be had without an interaction, which may only come from a gesture. This button is\r\n        that gesture; without it every request would fail with nothing on screen saying why.\r\n      -->\r\n      @if (auth.signInBlocked()) {\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:mr-4\"\r\n          (click)=\"auth.signIn()\"\r\n        >\r\n          Sign in\r\n        </button>\r\n      }\r\n      <div class=\"cws:flex cws:items-center cws:border-l cws:border-slate-200 cws:pl-4 cws:dark:border-slate-700\">\r\n        <cms-user-menu />\r\n      </div>\r\n    } @else {\r\n      <button\r\n        type=\"button\"\r\n        class=\"scoular-btn scoular-btn-primary scoular-btn-sm cws:ml-auto\"\r\n        (click)=\"auth.signIn()\"\r\n      >\r\n        Sign in\r\n      </button>\r\n    }\r\n  </div>\r\n</header>\r\n\r\n<!--\r\n  F1.4 — the availability banner, on every screen.\r\n\r\n  🔴 **It NAMES the state rather than collapsing the five into \"CTRM is unavailable\".** They mean\r\n  different things to whoever reads this: a night run ends on its own, a closed CTRM is an\r\n  administrative decision, unreachable is an incident somebody should be told about, and unknown\r\n  means we cannot say. One sentence for all of them tells a trader nothing about whether to wait,\r\n  retry or call someone.\r\n\r\n  ⚠ Rendered in the SHELL rather than per screen, because the gate applies to every write in the\r\n  application and a banner a feature had to remember to add is one a feature will forget.\r\n\r\n  ⚠ Hidden only while CTRM is available — a permanent green bar is chrome nobody reads, and it\r\n  would make the states that matter less visible rather than more.\r\n-->\r\n@if (availability.notice(); as notice) {\r\n  @if (availability.state() !== 'Available') {\r\n    <!--\r\n      🔴 `role=\"status\"` even when it blocks writes, and that is this repository's own rule rather\r\n      than a concession: the panel convention is that an ALERT is the outcome of something the user\r\n      just did, and a STATUS is a standing condition of the screen. CTRM being closed is a standing\r\n      condition — it was true before they arrived and will be true after they leave.\r\n\r\n      ⚠ It was written as a conditional `alert` first, and the shell's access-notice tests caught it\r\n      immediately: two `role=\"alert\"` regions on one screen, so `getByRole('alert')` became\r\n      ambiguous. The collision is what surfaced it; the convention is why it stays `status`.\r\n    -->\r\n    <!--\r\n      ⚠ #485: a night run blocks CTRM writes now, and it stays AMBER. It is scheduled and ends on its\r\n      own, which is what docs/02a calls the soft gate; red is for a CTRM that is closed, unreachable\r\n      or unknown, where somebody may need to act.\r\n    -->\r\n    @let soft = !notice.blocksWrites || availability.state() === 'NightRun';\r\n    <div class=\"cws:mx-auto cws:max-w-[1800px] cws:px-6 cws:pt-4\" role=\"status\">\r\n      <div\r\n        class=\"cws:rounded-lg cws:border cws:px-4 cws:py-3 cws:text-sm\"\r\n        [class.cws:border-red-300]=\"!soft\"\r\n        [class.cws:bg-red-50]=\"!soft\"\r\n        [class.cws:text-red-900]=\"!soft\"\r\n        [class.cws:border-amber-300]=\"soft\"\r\n        [class.cws:bg-amber-50]=\"soft\"\r\n        [class.cws:text-amber-900]=\"soft\"\r\n      >\r\n        <p class=\"cws:font-semibold\">{{ notice.title }}</p>\r\n        <p class=\"cws:mt-0.5\">{{ notice.detail }}</p>\r\n        @if (availability.message(); as ctrmMessage) {\r\n          <!-- CTRM's own sentence, quoted rather than parsed: two producers share this channel. -->\r\n          <p class=\"cws:mt-0.5 cws:italic\">{{ ctrmMessage }}</p>\r\n        }\r\n      </div>\r\n    </div>\r\n  }\r\n}\r\n\r\n<!--\r\n  Same 1800px cap as the top bar — see the note there for why they have to match.\r\n  `flex-1` fills the shell's full-height column, so the shortcut strip sits on the viewport's bottom\r\n  edge even when a screen is shorter than the window; `w-full`, because a flex item with auto margins\r\n  otherwise shrinks to its content.\r\n-->\r\n<main class=\"cws:mx-auto cws:w-full cws:max-w-[1800px] cws:flex-1 cws:px-6 cws:py-8\">\r\n  <!--\r\n    🔴 A refused navigation, stated once and then cleared — see AccessNotice for why this is a\r\n    banner rather than a line in cms-notices-panel. That panel is for STANDING conditions of a\r\n    screen; being bounced out of Admin is an EVENT, and it belongs to the shell that refused it\r\n    rather than to the workspace that happens to be where you land.\r\n\r\n    role=\"alert\" rather than \"status\": the user asked to go somewhere and did not arrive, so it\r\n    should interrupt. That is the opposite call from the record screen's Save gate, which is a\r\n    standing property of a screen you meant to be on.\r\n  -->\r\n  @if (accessMessage(); as message) {\r\n    <div class=\"scoular-alert scoular-alert-warning cws:mb-6\" role=\"alert\">\r\n      <div class=\"cws:flex cws:items-start cws:justify-between cws:gap-4\">\r\n        <div>\r\n          <div class=\"scoular-alert-title\">That module is not available to your account</div>\r\n          <div class=\"scoular-alert-description\">{{ message }}</div>\r\n        </div>\r\n\r\n        <!--\r\n          Dismissible as well as self-clearing: the automatic clear happens on the NEXT navigation,\r\n          so a user who stays put has no other way to put it down.\r\n        -->\r\n        <button\r\n          type=\"button\"\r\n          class=\"scoular-btn scoular-btn-sm scoular-btn-secondary cws:shrink-0\"\r\n          (click)=\"dismissAccessNotice()\"\r\n        >\r\n          Dismiss\r\n        </button>\r\n      </div>\r\n    </div>\r\n  }\r\n\r\n  <router-outlet />\r\n</main>\r\n\r\n<!--\r\n  The line-23 equivalent and the cheat-sheet behind `?`, both rendered by the workspace rather than by a\r\n  feature.\r\n\r\n  Rendered by the workspace in both delivery models (ADR-18); the bindings are scoped `within` the\r\n  workspace element so a host's own inputs never trigger them.\r\n\r\n  ⚠ The strip is after `<main>` rather than inside it, and it is `sticky bottom-0` (its own host\r\n  class), so it does not scroll with the content — the green screen's own line 23 does not scroll\r\n  either, and a legend that leaves the viewport is a legend nobody reads. Being after `<main>` was\r\n  never enough on its own: in normal flow it simply sat at the end of the page and scrolled away\r\n  with a long grid (JFrisbie, 2026-09-29).\r\n-->\r\n<cms-shortcut-hints />\r\n<cms-shortcut-overlay />\r\n"
		}]
	}],
	ctorParameters: () => []
});
function environmentLabelOf(name) {
	return name === "prod" ? null : name;
}
function cwsRoutes() {
	return [
		{
			path: "",
			pathMatch: "full",
			title: "Contracts",
			canActivate: [cwsAuthGuard],
			loadComponent: () => import("@cws/features-home").then((m) => m.HomePageComponent)
		},
		{
			path: "contracts/new",
			title: "New contract",
			canActivate: [cwsAuthGuard],
			data: {
				tradeUnitLocked: true,
				mode: "create"
			},
			loadChildren: () => import("./cws-workspace-record.routes-CVZBYc-n.mjs").then((m) => m.CREATE_RECORD_ROUTES)
		},
		{
			path: "contracts/:contractNumber/edit",
			title: "Edit contract",
			canActivate: [cwsAuthGuard],
			data: {
				tradeUnitLocked: true,
				mode: "edit"
			},
			loadChildren: () => import("./cws-workspace-record.routes-CVZBYc-n.mjs").then((m) => m.EDIT_RECORD_ROUTES)
		},
		{
			path: "contracts/:contractNumber",
			title: "Contract",
			canActivate: [cwsAuthGuard],
			data: {
				tradeUnitLocked: true,
				mode: "view"
			},
			loadChildren: () => import("./cws-workspace-record.routes-CVZBYc-n.mjs").then((m) => m.VIEW_RECORD_ROUTES)
		},
		{
			path: "approvals",
			title: "Approvals",
			canActivate: [cwsAuthGuard],
			loadComponent: () => import("@cws/features-approvals").then((m) => m.ApprovalsPageComponent)
		},
		{
			path: "approvals/:contractNumber",
			title: "Approve contract",
			canActivate: [cwsAuthGuard],
			loadComponent: () => import("@cws/features-approvals").then((m) => m.ApprovalDetailPageComponent)
		},
		{
			path: "pricing",
			title: "Pricing",
			canActivate: [cwsAuthGuard],
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PricingPageComponent)
		},
		{
			path: "pricing/approvals",
			title: "Pricing approvals",
			canActivate: [cwsAuthGuard],
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PricingApprovalsPageComponent)
		},
		{
			path: "pricing/:contractNumber",
			title: "Price sequences",
			canActivate: [cwsAuthGuard],
			loadComponent: () => import("@cws/features-pricing").then((m) => m.PricingDetailPageComponent)
		},
		{
			path: "admin",
			title: "Admin",
			canActivate: [cwsAuthGuard, canAccessAdminGuard],
			loadChildren: () => import("./cws-workspace-record.routes-CVZBYc-n.mjs").then((m) => m.ADMIN_ROUTES)
		}
	];
}
function provideCwsWorkspace(config) {
	return makeEnvironmentProviders([
		...authProvidersFor(config),
		provideHttpClient(withInterceptors([cwsTokenInterceptor, problemDetailsInterceptor])),
		{
			provide: CONTRACTS_API_URL,
			useValue: config.apiUrl
		},
		...config.telemetry ? [
			{
				provide: APP_INSIGHTS_CONNECTION_STRING,
				useValue: config.telemetry.connectionString
			},
			{
				provide: APP_INSIGHTS_ROLE_NAME,
				useValue: config.telemetry.roleName
			},
			{
				provide: ErrorHandler,
				useClass: AppInsightsErrorHandler
			}
		] : [],
		{
			provide: CONTRACT_LIST_SOURCE,
			useClass: HttpContractListSource
		},
		{
			provide: AVAILABILITY_SOURCE,
			useClass: HttpAvailabilitySource
		},
		{
			provide: ME_SOURCE,
			useClass: HttpMeSource
		},
		{
			provide: CUSTOMER_SOURCE,
			useClass: HttpCustomerSource
		},
		{
			provide: CONTRACT_STATE_SOURCE,
			useClass: HttpContractStateSource
		},
		{
			provide: CONTRACT_LOG_SOURCE,
			useClass: HttpContractLogSource
		},
		{
			provide: CONTRACT_TEMPLATE_SOURCE,
			useClass: HttpContractTemplateSource
		},
		{
			provide: CONTRACT_EXPORT_SOURCE,
			useClass: HttpContractExportSource
		},
		{
			provide: PRICING_SOURCE,
			useClass: HttpPricingSource
		},
		{
			provide: MARKET_REFERENCE_SOURCE,
			useClass: HttpMarketReferenceSource
		},
		{
			provide: TRADE_UNIT_VALUES_SOURCE,
			useClass: HttpTradeUnitValuesSource
		},
		{
			provide: TRADE_UNIT_CONTEXT,
			useExisting: TradeUnitStore
		},
		MePermissionContext,
		{
			provide: PERMISSION_CONTEXT,
			useExisting: MePermissionContext
		},
		{
			provide: LOCATION_SOURCE,
			useClass: HttpLocationSource
		},
		{
			provide: CMS_HOST_CONTEXT,
			useFactory: () => {
				const base = inject(CwsMountBase);
				return workspaceHostContext(inject(Router), inject(CmsAuthService), inject(TradeUnitStore), inject(ThemeStore), () => base.path());
			}
		},
		CwsMountBase,
		ThemeStore,
		AvailabilityGate,
		{
			provide: CWS_THEME_MODE,
			useValue: config.theme
		},
		{
			provide: CWS_ENVIRONMENT_NAME,
			useValue: config.environmentName
		},
		{
			provide: CWS_EMBEDDED,
			useValue: config.embedded ?? false
		},
		{
			provide: CONTRACT_DETAIL_SOURCE,
			useClass: HttpContractDetailSource
		},
		{
			provide: APPROVAL_CONTRACT_SOURCE,
			useClass: HttpApprovalContractSource
		},
		{
			provide: FORM_CONFIG_SOURCE,
			useClass: HttpFormConfigSource
		},
		{
			provide: CONTRACT_WRITE_SOURCE,
			useClass: HttpContractWriteSource
		},
		{
			provide: CONTRACT_NUMBER_SOURCE,
			useClass: HttpContractNumberSource
		},
		{
			provide: FORM_CONFIG_ADMIN_SOURCE,
			useClass: HttpFormConfigAdminSource
		},
		{
			provide: APPROVAL_ACTION_SOURCE,
			useClass: SimulatedApprovalActionSource
		},
		{
			provide: SAVED_FILTER_STORE,
			useClass: LocalSavedFilterStore
		},
		{
			provide: SAVED_FILTER_OWNER,
			useFactory: () => {
				const auth = inject(CmsAuthService);
				return () => auth.username() ?? "anonymous";
			}
		}
	]);
}
function authProvidersFor(config) {
	const auth = config.auth;
	if (auth.tokenProvider) return [provideCwsHostTokenAuth({
		apiUrl: config.apiUrl,
		apiScopes: auth.apiScopes,
		tokenProvider: auth.tokenProvider
	})];
	return [provideCmsAuth({
		...auth,
		apiUrl: config.apiUrl
	})];
}
export { ADMIN_REFUSAL, CWS_EMBEDDED, CWS_ENVIRONMENT_NAME, CWS_THEME_MODE, CwsMountBase, CwsWorkspaceComponent, MODULE_PATHS, MODULE_SEGMENTS, MePermissionContext, ThemeStore, TradeUnitPickerComponent, UserMenuComponent, canAccessAdminGuard, cwsRoutes, mountBaseOf, provideCwsWorkspace, workspaceHostContext, workspaceRoutes };

//# sourceMappingURL=cws-workspace.mjs.map
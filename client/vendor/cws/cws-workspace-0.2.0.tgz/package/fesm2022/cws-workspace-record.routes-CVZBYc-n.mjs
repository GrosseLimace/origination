import { ADDENDUM_GENERATION_SOURCE, ADDENDUM_TEMPLATE_SOURCE, CONTRACT_DOCUMENTS_SOURCE, HttpAddendumGenerationSource, HttpAddendumTemplateSource, HttpContractDocumentsSource } from "@cws/domain-contracts";
import { confirmNavigationGuard } from "@cws/shared-ui";
import { AdminPageComponent } from "@cws/features-admin";
import { ContractRecordPageComponent } from "@cws/features-contract-summary";
const ADDENDUM_PROVIDERS = [{
	provide: ADDENDUM_TEMPLATE_SOURCE,
	useClass: HttpAddendumTemplateSource
}, {
	provide: ADDENDUM_GENERATION_SOURCE,
	useClass: HttpAddendumGenerationSource
}];
const RECORD_PROVIDERS = [...ADDENDUM_PROVIDERS, {
	provide: CONTRACT_DOCUMENTS_SOURCE,
	useClass: HttpContractDocumentsSource
}];
const CREATE_RECORD_ROUTES = [{
	path: "",
	canDeactivate: [confirmNavigationGuard],
	providers: ADDENDUM_PROVIDERS,
	component: ContractRecordPageComponent
}];
const EDIT_RECORD_ROUTES = [{
	path: "",
	canDeactivate: [confirmNavigationGuard],
	providers: RECORD_PROVIDERS,
	component: ContractRecordPageComponent
}];
const VIEW_RECORD_ROUTES = [{
	path: "",
	providers: RECORD_PROVIDERS,
	component: ContractRecordPageComponent
}];
const ADMIN_ROUTES = [{
	path: "",
	providers: [{
		provide: ADDENDUM_TEMPLATE_SOURCE,
		useClass: HttpAddendumTemplateSource
	}],
	component: AdminPageComponent
}];
export { ADMIN_ROUTES, CREATE_RECORD_ROUTES, EDIT_RECORD_ROUTES, VIEW_RECORD_ROUTES };

//# sourceMappingURL=cws-workspace-record.routes-CVZBYc-n.mjs.map